/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas.
 * 
 * Created on:   17 June 2016	
 * 
 * Purpose:      Transaction Service Interface
 * 
 * Change History: 
 * Date                                    Author                                                                               Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 17 June 2016						    Bala Murugan Elangovan														 	 Service Interface
 * 13 July 2016						    Purushothaman														 	        Service Interface for S144 - Discount Approval
 * 21 Feb 2017							Sathishkumar B																	FO 10.0 - S008, S009, S010, S011, S012, S013, S014
 * *****************************************************************************************************************************************************************/
package com.bnp.bnpux.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.bnp.bnpux.common.vo.ApproveRequestVo;
import com.bnp.bnpux.common.vo.ApproveResponseVo;
import com.bnp.bnpux.common.vo.CommitmentFeeUxVO;
import com.bnp.bnpux.common.vo.TransactionListVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.vo.errorMessageVO.ErrorMessageVO;
import com.bnp.bnpux.vo.requestVO.TransactionRequestVO;
import com.bnp.bnpux.vo.responseVO.TransactionResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface ITransactionService {

	/**
	 * Service Method to get Transaction Information
	 * @param transactionReqVO
	 * @return
	 * @throws DataAccessException 
	 * @throws BNPApplicationException 
	 */
	TransactionResponseVO getTransactionInfo(TransactionRequestVO transactionReqVO) throws BNPApplicationException;

	/**
	 * Service Method to Approve Discount Requests
	 * @param transactionListVO
	 * @param userVo
	 * @return
	 * @throws BNPApplicationException 
	 */
	ApproveResponseVo approveDiscountRequest(List<TransactionListVO> transactionListVO, UserInfoVO userVo) throws BNPApplicationException;
	
	/**
	 * Service Method to Approve Discount Requests
	 * @param transactionListVO
	 * @param userVo
	 * @param apprvReqVo 
	 * @return
	 * @throws BNPApplicationException 
	 */
	ApproveResponseVo proceedApproveDiscountRequest(List<TransactionListVO> transactionListVO, UserInfoVO userVo, ApproveRequestVo apprvReqVo) throws BNPApplicationException;
	
	/**
	 * Service Method to Reject Discount Requests
	 * @param transactionListVO
	 * @param userVo
	 * @param apprvReqVo 
	 * @return
	 * @throws BNPApplicationException 
	 */
	List<ErrorMessageVO> returnDiscountRequest(List<TransactionListVO> transactionListVO, UserInfoVO userVo, ApproveRequestVo apprvReqVo) throws BNPApplicationException;
	
	/**
	 * Service Method to Reject Discount Requests
	 * @param transactionListVO
	 * @param userVo
	 * @return
	 * @throws BNPApplicationException 
	 */
	List<ErrorMessageVO> rejectDiscountRequest(List<TransactionListVO> transactionListVO, UserInfoVO userVo) throws BNPApplicationException;
	
	/**
	 * This method for cancelling discount request
	 * 
	 * @param tlvo
	 * @param userVo
	 * @return
	 * @throws BNPApplicationException
	 */
	String cancelDiscountRequest(TransactionListVO tlvo, UserInfoVO userVo) throws BNPApplicationException;
	
	/**
	 * This method for undo transaction
	 * 
	 * @param transRecords
	 * @param userInfo
	 * @return
	 */
	List<ErrorMessageVO>  undoTransactionRecord(List<TransactionListVO> transRecords,UserInfoVO userInfo);
	
	
	/**
	 * Service Method to Approve Discount Requests
	 * @param transactionListVO
	 * @param userVo
	 * @return
	 * @throws BNPApplicationException 
	 */
	ApproveResponseVo acceptBuyerAcceptanceDetails(List<TransactionListVO> transactionListVO, UserInfoVO userVo) throws BNPApplicationException;
	
	/**
	 * Service Method to Approve Discount Requests
	 * @param transactionListVO
	 * @param userVo
	 * @return
	 * @throws BNPApplicationException 
	 */
	TransactionResponseVO getTransactionCallOutInfo(TransactionRequestVO transactionReqVO) throws BNPApplicationException;
	
	
	/**
	 * Service Method for getting Discount Popup Details - FO 10.0 - S008, S009, S010, S011, S012, S013, S014
	 * @param transactionReqVO
	 * @return
	 * @throws BNPApplicationException
	 */
	TransactionRequestVO getDiscountPopupDetails(TransactionRequestVO transactionReqVO) throws BNPApplicationException;

	CommitmentFeeUxVO fetchDebitNoteRef(TransactionRequestVO transactionReqVO) throws BNPApplicationException;
	
	TransactionResponseVO getAdvancedFilterCount(TransactionRequestVO transactionReqVO) throws BNPApplicationException;	
	
}
