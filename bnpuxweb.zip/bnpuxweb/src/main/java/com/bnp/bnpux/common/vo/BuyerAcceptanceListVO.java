/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   29 Mar 2017	
 * 
 * Purpose:       Buyer Acceptance screen
 * 
 * Change History: 
 * Date                       Author                                    Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 29 Mar 2017			      kmanimar					                Initial Version - FO 10.0 - S2098
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;
import java.util.Date;

public class BuyerAcceptanceListVO {
	
	private String referenceNumber; 
	private String buyerOrgName;
	private String supplierOrgName;
	private String buyerOrgId;
	private String supplierOrgId;
	private Date issueDate;
	private String ccyCode;
	private BigDecimal amount;
	private Date dueDate;
	private String status;
	private String checkBoxFlag;	
	private String orderSeq;
	private String lotNumber;
	private int decimalPoint;
	private int attachmentFlag;
	private String refNoUnique;
	private String statusValue;
	private String statusKey;
	
	/*BA concurrency to compare UI status and DB status before commonservice call start*/
	private String docStatus;
	private String ctrlStatus;
	
	/**
	 * @return the docStatus
	 */
	public String getDocStatus() {
		return docStatus;
	}
	/**
	 * @param docStatus the docStatus to set
	 */
	public void setDocStatus(String docStatus) {
		this.docStatus = docStatus;
	}
	/**
	 * @return the ctrlStatus
	 */
	public String getCtrlStatus() {
		return ctrlStatus;
	}
	/**
	 * @param ctrlStatus the ctrlStatus to set
	 */
	public void setCtrlStatus(String ctrlStatus) {
		this.ctrlStatus = ctrlStatus;
	}
	
	/*BA concurrency to compare UI status and DB status before commonservice call end*/
	
	public Date getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}
	public Date getDueDate() {
		return dueDate;
	}
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}
	public int getDecimalPoint() {
		return decimalPoint;
	}
	public void setDecimalPoint(int decimalPoint) {
		this.decimalPoint = decimalPoint;
	}
	public String getReferenceNumber() {
		return referenceNumber;
	}
	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}
	public String getBuyerOrgName() {
		return buyerOrgName;
	}
	public void setBuyerOrgName(String buyerOrgName) {
		this.buyerOrgName = buyerOrgName;
	}
	public String getSupplierOrgName() {
		return supplierOrgName;
	}
	public void setSupplierOrgName(String supplierOrgName) {
		this.supplierOrgName = supplierOrgName;
	}
	public String getBuyerOrgId() {
		return buyerOrgId;
	}
	public void setBuyerOrgId(String buyerOrgId) {
		this.buyerOrgId = buyerOrgId;
	}
	public String getSupplierOrgId() {
		return supplierOrgId;
	}
	public void setSupplierOrgId(String supplierOrgId) {
		this.supplierOrgId = supplierOrgId;
	}
	public String getCcyCode() {
		return ccyCode;
	}
	public void setCcyCode(String ccyCode) {
		this.ccyCode = ccyCode;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCheckBoxFlag() {
		return checkBoxFlag;
	}
	public void setCheckBoxFlag(String checkBoxFlag) {
		this.checkBoxFlag = checkBoxFlag;
	}
	public String getOrderSeq() {
		return orderSeq;
	}
	public void setOrderSeq(String orderSeq) {
		this.orderSeq = orderSeq;
	}
	public String getLotNumber() {
		return lotNumber;
	}
	public void setLotNumber(String lotNumber) {
		this.lotNumber = lotNumber;
	}
	public int getAttachmentFlag() {
		return attachmentFlag;
	}
	public void setAttachmentFlag(int attachmentFlag) {
		this.attachmentFlag = attachmentFlag;
	}
	public String getRefNoUnique() {
		return refNoUnique;
	}
	public void setRefNoUnique(String refNoUnique) {
		this.refNoUnique = refNoUnique;
	}
	/**
	 * @return the statusValue
	 */
	public String getStatusValue() {
		return statusValue;
	}
	/**
	 * @param statusValue the statusValue to set
	 */
	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}
	/**
	 * @return the statusKey
	 */
	public String getStatusKey() {
		return statusKey;
	}
	/**
	 * @param statusKey the statusKey to set
	 */
	public void setStatusKey(String statusKey) {
		this.statusKey = statusKey;
	}
	
	/**
	 * Getter methods introduced to send the amounts as
	 * String to avoid amount > 16 digits getting truncated
	 * Added as part of defect Fix CSC-7835
	 */
	
	public String getAmountStr() {
		return (amount!=null)?amount.toPlainString():"";
	}
	
	
}
