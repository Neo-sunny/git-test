package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;

public class ReportsCreditNoteLineItemVO {
	public ReportsCreditNoteLineItemVO(){		
	}
	
	private String critSuppItmNo;
	private String critSuppPartNo;
	private String critItmDesc;
	private String critUOM;
	private int critQTY;
	private BigDecimal critPrice;
	private BigDecimal critTotalPrice;	
	private String critPoNo;
	private String error_result;
	private String error_msg;
	public String getCritSuppItmNo() {
		return critSuppItmNo;
	}
	public void setCritSuppItmNo(String critSuppItmNo) {
		this.critSuppItmNo = critSuppItmNo;
	}
	public String getCritSuppPartNo() {
		return critSuppPartNo;
	}
	public void setCritSuppPartNo(String critSuppPartNo) {
		this.critSuppPartNo = critSuppPartNo;
	}
	public String getCritItmDesc() {
		return critItmDesc;
	}
	public void setCritItmDesc(String critItmDesc) {
		this.critItmDesc = critItmDesc;
	}
	public String getCritUOM() {
		return critUOM;
	}
	public void setCritUOM(String critUOM) {
		this.critUOM = critUOM;
	}
	public int getCritQTY() {
		return critQTY;
	}
	public void setCritQTY(int critQTY) {
		this.critQTY = critQTY;
	}
	public BigDecimal getCritPrice() {
		return critPrice;
	}
	public void setCritPrice(BigDecimal critPrice) {
		this.critPrice = critPrice;
	}
	public BigDecimal getCritTotalPrice() {
		return critTotalPrice;
	}
	public void setCritTotalPrice(BigDecimal critTotalPrice) {
		this.critTotalPrice = critTotalPrice;
	}
	public String getCritPoNo() {
		return critPoNo;
	}
	public void setCritPoNo(String critPoNo) {
		this.critPoNo = critPoNo;
	}
	public String getError_result() {
		return error_result;
	}
	public void setError_result(String error_result) {
		this.error_result = error_result;
	}
	public String getError_msg() {
		return error_msg;
	}
	public void setError_msg(String error_msg) {
		this.error_msg = error_msg;
	}

}
