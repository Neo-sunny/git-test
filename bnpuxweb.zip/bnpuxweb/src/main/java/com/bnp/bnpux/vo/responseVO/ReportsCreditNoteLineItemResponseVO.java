package com.bnp.bnpux.vo.responseVO;

import java.util.List;

import com.bnp.bnpux.common.vo.ReportsCreditNoteLineItemVO;

public class ReportsCreditNoteLineItemResponseVO {
	private String error_result;
	private String error_msg;
	private List<ReportsCreditNoteLineItemVO> reportsCreditNoteLineItemVO;
	public String getError_result() {
		return error_result;
	}

	public void setError_result(String error_result) {
		this.error_result = error_result;
	}

	public String getError_msg() {
		return error_msg;
	}

	public void setError_msg(String error_msg) {
		this.error_msg = error_msg;
	}

	public List<ReportsCreditNoteLineItemVO> getReportsCreditNoteLineItemVO() {
		return reportsCreditNoteLineItemVO;
	}

	public void setReportsCreditNoteLineItemVO(List<ReportsCreditNoteLineItemVO> reportsCreditNoteLineItemVO) {
		this.reportsCreditNoteLineItemVO = reportsCreditNoteLineItemVO;
	}
}
