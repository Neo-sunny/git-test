/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  21 June 2017
 * 
 * Purpose:      Credit Note Inquiry Report Summary VO
 * 
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 21 June 2017       Rameshwar Khedekar, Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/

package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;
import java.util.Date;

public class CreditNoteInqDetailsVO {
	
private String buyerOrgId;
	
	private String suppOrgId;
	
	private String buyerOrgName;
	
	private String suppOrgName;
	
	private String buyerErpId;
	
	private String suppErpId;
	
	private String currencyCode;
	
	private String bandRecordCnt;
	
	private String errorMessage;
	
	private String cntId;
	
	private String cntRefNo;
	
	private Date issueDate;
	
	private Date effectiveDate;
	
	private String status;
	
	private BigDecimal originalAmount;
	
	private BigDecimal outstandingAmount;
	
	private BigDecimal utilizedAmount;
	
	private BigDecimal blockedAmount;
	
	private int decimalPoint;
	
	private String attachmentCount;
	
	private String invoiceRefNo;
	
	private String isLinked;

	private String expandAllowed;
	
	private String isLineDetFlg;
	
	private String  statusValue;
	
	private String  statusKey;

	public String getIsLineDetFlg() {
		return isLineDetFlg;
	}

	public void setIsLineDetFlg(String isLineDetFlg) {
		this.isLineDetFlg = isLineDetFlg;
	}
	
	public String getExpandAllowed() {
		return expandAllowed;
	}

	public void setExpandAllowed(String expandAllowed) {
		this.expandAllowed = expandAllowed;
	}

	public String getCntId() {
		return cntId;
	}

	public void setCntId(String cntId) {
		this.cntId = cntId;
	}

	public String getCntRefNo() {
		return cntRefNo;
	}

	public void setCntRefNo(String cntRefNo) {
		this.cntRefNo = cntRefNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getDecimalPoint() {
		return decimalPoint;
	}

	public void setDecimalPoint(int decimalPoint) {
		this.decimalPoint = decimalPoint;
	}

	public String getAttachmentCount() {
		return attachmentCount;
	}

	public void setAttachmentCount(String attachmentCount) {
		this.attachmentCount = attachmentCount;
	}

	public String getInvoiceRefNo() {
		return invoiceRefNo;
	}

	public void setInvoiceRefNo(String invoiceRefNo) {
		this.invoiceRefNo = invoiceRefNo;
	}

	public String getIsLinked() {
		return isLinked;
	}

	public void setIsLinked(String isLinked) {
		this.isLinked = isLinked;
	}

	public String getBuyerOrgId() {
		return buyerOrgId;
	}

	public void setBuyerOrgId(String buyerOrgId) {
		this.buyerOrgId = buyerOrgId;
	}

	public String getSuppOrgId() {
		return suppOrgId;
	}

	public void setSuppOrgId(String suppOrgId) {
		this.suppOrgId = suppOrgId;
	}

	public String getBuyerOrgName() {
		return buyerOrgName;
	}

	public void setBuyerOrgName(String buyerOrgName) {
		this.buyerOrgName = buyerOrgName;
	}

	public String getSuppOrgName() {
		return suppOrgName;
	}

	public void setSuppOrgName(String suppOrgName) {
		this.suppOrgName = suppOrgName;
	}

	public String getBuyerErpId() {
		return buyerErpId;
	}

	public void setBuyerErpId(String buyerErpId) {
		this.buyerErpId = buyerErpId;
	}

	public String getSuppErpId() {
		return suppErpId;
	}

	public void setSuppErpId(String suppErpId) {
		this.suppErpId = suppErpId;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getBandRecordCnt() {
		return bandRecordCnt;
	}

	public void setBandRecordCnt(String bandRecordCnt) {
		this.bandRecordCnt = bandRecordCnt;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Date getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public BigDecimal getOriginalAmount() {
		return originalAmount;
	}

	public void setOriginalAmount(BigDecimal originalAmount) {
		this.originalAmount = originalAmount;
	}

	public BigDecimal getOutstandingAmount() {
		return outstandingAmount;
	}

	public void setOutstandingAmount(BigDecimal outstandingAmount) {
		this.outstandingAmount = outstandingAmount;
	}

	public BigDecimal getUtilizedAmount() {
		return utilizedAmount;
	}

	public void setUtilizedAmount(BigDecimal utilizedAmount) {
		this.utilizedAmount = utilizedAmount;
	}

	public BigDecimal getBlockedAmount() {
		return blockedAmount;
	}

	public void setBlockedAmount(BigDecimal blockedAmount) {
		this.blockedAmount = blockedAmount;
	}

	/**
	 * @return the statusValue
	 */
	public String getStatusValue() {
		return statusValue;
	}

	/**
	 * @param statusValue the statusValue to set
	 */
	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}

	/**
	 * @return the statusKey
	 */
	public String getStatusKey() {
		return statusKey;
	}

	/**
	 * @param statusKey the statusKey to set
	 */
	public void setStatusKey(String statusKey) {
		this.statusKey = statusKey;
	}
	
	
	
	public String getOriginalAmountStr() {
		return (originalAmount != null)? originalAmount.toPlainString():"";
	}
	
	public String getOutstandingAmountStr() {
		return (outstandingAmount != null)? outstandingAmount.toPlainString():"";
	}
	
	public String getUtilizedAmountStr() {
		return (utilizedAmount != null)? utilizedAmount.toPlainString():"";
	}
	
	public String getBlockedAmountStr() {
		return (blockedAmount != null)? blockedAmount.toPlainString():"";
	}

}
