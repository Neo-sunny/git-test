/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas.
 * 
 * Created on:   17 June 2016	
 * 
 * Purpose:      Transaction Constants 
 * 
 * Change History: 
 * Date                                    Author                                                                               Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
	 * 19 July 2016							Rohit Chopra																	 Helper Class for Ststus Message Displays	
 * *****************************************************************************************************************************************************************/
package com.bnp.bnpux.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.bnp.bnpux.common.vo.TransactionListVO;
import com.bnp.bnpux.vo.errorMessageVO.ErrorMessageVO;



@Service("errorMessageHelper")
@Scope("request")
public class ErrorMessageHelper {

private List<TransactionListVO> transactionList;
	
	private List<ErrorMessageVO> errorMessageVOList=new ArrayList<ErrorMessageVO>();

	public List<ErrorMessageVO> getErrorMessageVOList() {
		return errorMessageVOList;
	}

	public void setErrorMessageVOList(List<ErrorMessageVO> errorMessageVOList) {
		this.errorMessageVOList = errorMessageVOList;
	}

	
}
