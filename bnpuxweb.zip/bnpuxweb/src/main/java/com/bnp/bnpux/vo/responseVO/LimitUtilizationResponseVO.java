/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  21 June 2017
 * 
 * Purpose:      Limit Utilization Report Response VO
 * 
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 21 June 2017       Ratna Gokhale, Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/

package com.bnp.bnpux.vo.responseVO;

import java.util.List;

import com.bnp.bnpux.common.vo.CreditNoteInqDetailsVO;
import com.bnp.bnpux.common.vo.CreditNoteInqVO;
import com.bnp.bnpux.common.vo.CreditNoteUtilizationVO;
import com.bnp.bnpux.common.vo.LimitUtilizationReportDetailsVO;
import com.bnp.bnpux.common.vo.LimitUtilizationReportVO;

public class LimitUtilizationResponseVO{

	
	private String errorMessage;
	
	private List<LimitUtilizationReportVO> limitUtilizationReportList;
	
	private List<LimitUtilizationReportDetailsVO> limitUtilizationReportDetails;
		
	private List<ReportChartResponseVO> reportChartList;
	
	private List<LimitUtilizationReportDetailsVO> entityLimitDetails;
	
	private List<LimitUtilizationReportDetailsVO> groupEntityLimitDetails;
	
	private List<LimitUtilizationReportDetailsVO> groupThirdPartyLimitDetails;
	
	private List<LimitUtilizationReportDetailsVO> thirdPartyLimitDetails;
	
	private List<LimitUtilizationReportDetailsVO> counterpartyLimitDetails;
	
	private List<LimitUtilizationReportDetailsVO> groupCounterpartyLimitDetails;
	
	private List<LimitUtilizationReportDetailsVO> groupCounterpartyThirdPartyLimitDetails;
	
	private List<LimitUtilizationReportDetailsVO> counterpartyThirdPartyLimitDetails;
	
	
	
	public List<LimitUtilizationReportDetailsVO> getEntityLimitDetails() {
		return entityLimitDetails;
	}

	public void setEntityLimitDetails(List<LimitUtilizationReportDetailsVO> entityLimitDetails) {
		this.entityLimitDetails = entityLimitDetails;
	}

	public List<LimitUtilizationReportDetailsVO> getGroupEntityLimitDetails() {
		return groupEntityLimitDetails;
	}

	public void setGroupEntityLimitDetails(List<LimitUtilizationReportDetailsVO> groupEntityLimitDetails) {
		this.groupEntityLimitDetails = groupEntityLimitDetails;
	}

	public List<LimitUtilizationReportDetailsVO> getGroupThirdPartyLimitDetails() {
		return groupThirdPartyLimitDetails;
	}

	public void setGroupThirdPartyLimitDetails(List<LimitUtilizationReportDetailsVO> groupThirdPartyLimitDetails) {
		this.groupThirdPartyLimitDetails = groupThirdPartyLimitDetails;
	}

	public List<LimitUtilizationReportDetailsVO> getThirdPartyLimitDetails() {
		return thirdPartyLimitDetails;
	}

	public void setThirdPartyLimitDetails(List<LimitUtilizationReportDetailsVO> thirdPartyLimitDetails) {
		this.thirdPartyLimitDetails = thirdPartyLimitDetails;
	}

	public List<LimitUtilizationReportDetailsVO> getCounterpartyLimitDetails() {
		return counterpartyLimitDetails;
	}

	public void setCounterpartyLimitDetails(List<LimitUtilizationReportDetailsVO> counterpartyLimitDetails) {
		this.counterpartyLimitDetails = counterpartyLimitDetails;
	}

	public List<LimitUtilizationReportDetailsVO> getGroupCounterpartyLimitDetails() {
		return groupCounterpartyLimitDetails;
	}

	public void setGroupCounterpartyLimitDetails(List<LimitUtilizationReportDetailsVO> groupCounterpartyLimitDetails) {
		this.groupCounterpartyLimitDetails = groupCounterpartyLimitDetails;
	}

	public List<LimitUtilizationReportDetailsVO> getGroupCounterpartyThirdPartyLimitDetails() {
		return groupCounterpartyThirdPartyLimitDetails;
	}

	public void setGroupCounterpartyThirdPartyLimitDetails(
			List<LimitUtilizationReportDetailsVO> groupCounterpartyThirdPartyLimitDetails) {
		this.groupCounterpartyThirdPartyLimitDetails = groupCounterpartyThirdPartyLimitDetails;
	}

	public List<LimitUtilizationReportDetailsVO> getCounterpartyThirdPartyLimitDetails() {
		return counterpartyThirdPartyLimitDetails;
	}

	public void setCounterpartyThirdPartyLimitDetails(
			List<LimitUtilizationReportDetailsVO> counterpartyThirdPartyLimitDetails) {
		this.counterpartyThirdPartyLimitDetails = counterpartyThirdPartyLimitDetails;
	}
	
	public List<LimitUtilizationReportVO> getLimitUtilizationReportList() {
		return limitUtilizationReportList;
	}

	public void setLimitUtilizationReportList(List<LimitUtilizationReportVO> limitUtilizationReportList) {
		this.limitUtilizationReportList = limitUtilizationReportList;
	}

	public List<LimitUtilizationReportDetailsVO> getLimitUtilizationReportDetails() {
		return limitUtilizationReportDetails;
	}

	public void setLimitUtilizationReportDetails(List<LimitUtilizationReportDetailsVO> limitUtilizationReportDetails) {
		this.limitUtilizationReportDetails = limitUtilizationReportDetails;
	}

	public List<ReportChartResponseVO> getReportChartList() {
		return reportChartList;
	}

	public void setReportChartList(List<ReportChartResponseVO> reportChartList) {
		this.reportChartList = reportChartList;
	}


	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}



}
