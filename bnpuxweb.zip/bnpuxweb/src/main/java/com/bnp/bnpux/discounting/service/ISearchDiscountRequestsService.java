/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Interface for Discount Request button actions
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.discounting.service;

import java.util.List;

import com.bnp.bnpux.common.vo.PaymentOrderListVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.discounting.vo.DiscountRequestVO;

public interface ISearchDiscountRequestsService {
	
	/**
	 * This method is for Recalculate Discount Request
	 * 
	 * @param selectedDiscountReqVO
	 * @return
	 */
	public DiscountRequestVO recalculateDiscountRequest(DiscountRequestVO selectedDiscountReqVO);
	
	/**
	 * This method is for getting view page 
	 * 
	 * @return
	 */
	abstract String getViewPage();
	
	/**
	 * This method is for getting Discount Request
	 * 
	 * @param paymentOrderListtVO
	 * @return
	 * @throws BNPApplicationException
	 */
	public DiscountRequestVO getDiscRequestVO(PaymentOrderListVO paymentOrderListtVO) throws BNPApplicationException;
}
