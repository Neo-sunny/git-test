/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Approve Response Grid Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.io.Serializable;
import java.math.BigDecimal;

public class ApproveResponseGridVo implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String discountRefNo;
	
	private BigDecimal availableAmt;
	
	private BigDecimal indicativeDiscountRate;
	
	private BigDecimal indicativeDiscountAmt;
	
	private BigDecimal indicativeChargeAmt;
	
	private BigDecimal indicativeNetAmt;
	
    private String discountRefNoLbl;
	
	private String availableAmtLbl;
	
	private String indicativeDiscountRateLbl;
	
	private String indicativeDiscountAmtLbl;
	
	private String indicativeChargeAmtLbl;
	
	private String indicativeNetAmtLbl;
	
	private String remarks;
	
	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	/**
	 * @return the discountRefNo
	 */
	public String getDiscountRefNo() {
		return discountRefNo;
	}
	
	/**
	 * @param discountRefNo the discountRefNo to set
	 */
	public void setDiscountRefNo(String discountRefNo) {
		this.discountRefNo = discountRefNo;
	}
	
	/**
	 * @return the availableAmt
	 */
	public BigDecimal getAvailableAmt() {
		return availableAmt;
	}
	
	/**
	 * @param availableAmt the availableAmt to set
	 */
	public void setAvailableAmt(BigDecimal availableAmt) {
		this.availableAmt = availableAmt;
	}
	
	/**
	 * @return the indicativeDiscountRate
	 */
	public BigDecimal getIndicativeDiscountRate() {
		return indicativeDiscountRate;
	}

	/**
	 * @param indicativeDiscountRate the indicativeDiscountRate to set
	 */
	public void setIndicativeDiscountRate(BigDecimal indicativeDiscountRate) {
		this.indicativeDiscountRate = indicativeDiscountRate;
	}

	
	/**
	 * @return the indicativeDiscountAmt
	 */
	public BigDecimal getIndicativeDiscountAmt() {
		return indicativeDiscountAmt;
	}

	/**
	 * @param indicativeDiscountAmt the indicativeDiscountAmt to set
	 */
	public void setIndicativeDiscountAmt(BigDecimal indicativeDiscountAmt) {
		this.indicativeDiscountAmt = indicativeDiscountAmt;
	}

	
	public BigDecimal getIndicativeChargeAmt() {
		return indicativeChargeAmt;
	}

	public void setIndicativeChargeAmt(BigDecimal indicativeChargeAmt) {
		this.indicativeChargeAmt = indicativeChargeAmt;
	}
	
	/**
	 * @return the indicativeNetAmt
	 */
	public BigDecimal getIndicativeNetAmt() {
		return indicativeNetAmt;
	}

	/**
	 * @param indicativeNetAmt the indicativeNetAmt to set
	 */
	public void setIndicativeNetAmt(BigDecimal indicativeNetAmt) {
		this.indicativeNetAmt = indicativeNetAmt;
	}
	
	
	/**
	 * @return the discountRefNoLbl
	 */
	public String getDiscountRefNoLbl() {
		return discountRefNoLbl;
	}
	
	/**
	 * @param discountRefNo the discountRefNo to set
	 */
	public void setDiscountRefNoLbl(String discountRefNoLbl) {
		this.discountRefNoLbl = discountRefNoLbl;
	}
	
	/**
	 * @return the availableAmtlbl
	 */
	public String getAvailableAmtLbl() {
		return availableAmtLbl;
	}
	
	/**
	 * @param availableAmtlbl the availableAmtlbl to set
	 */
	public void setAvailableAmtLbl(String availableAmtLbl) {
		this.availableAmtLbl = availableAmtLbl;
	}
	
	/**
	 * @return the indicativeDiscountRateLbl
	 */
	public String getIndicativeDiscountRateLbl() {
		return indicativeDiscountRateLbl;
	}

	/**
	 * @param indicativeDiscountRatelbl the indicativeDiscountRatelbl to set
	 */
	public void setIndicativeDiscountRatelbl(String indicativeDiscountRateLbl) {
		this.indicativeDiscountRateLbl = indicativeDiscountRateLbl;
	}

	
	/**
	 * @return the indicativeDiscountAmtLbl
	 */
	public String getIndicativeDiscountAmtLbl() {
		return indicativeDiscountAmtLbl;
	}

	/**
	 * @param indicativeDiscountAmtLbl the indicativeDiscountAmtLbl to set
	 */
	public void setIndicativeDiscountAmtLbl(String indicativeDiscountAmtLbl) {
		this.indicativeDiscountAmtLbl = indicativeDiscountAmtLbl;
	}

	
	public String getIndicativeChargeAmtLbl() {
		return indicativeChargeAmtLbl;
	}

	public void setIndicativeChargeAmtLbl(String indicativeChargeAmtLbl) {
		this.indicativeChargeAmtLbl = indicativeChargeAmtLbl;
	}
	
	/**
	 * @return the indicativeNetAmtLbl
	 */
	public String getIndicativeNetAmtLbl() {
		return indicativeNetAmtLbl;
	}

	/**
	 * @param indicativeNetAmt the indicativeNetAmt to set
	 */
	public void setIndicativeNetAmtLbl(String indicativeNetAmtLbl) {
		this.indicativeNetAmtLbl = indicativeNetAmtLbl;
	}


}
