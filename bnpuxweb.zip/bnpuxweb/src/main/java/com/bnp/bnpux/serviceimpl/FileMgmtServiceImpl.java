/*******************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas.
 * 
 * Created on:   14 Mar 2017		
 * 
 * Purpose:      File Management Service Implementation
 * 
 * Change History: 
 * Date                              Author                                             Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 14 Mar 2017			             skbhaska					                	    Initial Version - FO 10.0 - S2005, S2007
 * 27 March 2017            	    Bhuvaneswari                                            S2034 File managementUndo action 
 * 28 Mar 2017						 belangov											PO / Invoice / Credit note  List view - S2013
 * 29 Mar 2017                       srreshmi                                           S2022, S2024-Pre approved supplier and Discount type attachment list
 * 27 March 2017            		Bhuvaneswari                                        S2034 File managementUndo action -code review comment fix  
 * 04-Apr-2017                      Divyashri											S2020 - Invoice Settlements List Details
 * 08-May-2017				        Bala Murugan Elangovan							    File Upload - Polling Logic implementation
 * 28-Mar-2018				        Bala Murugan Elangovan							    R11.0 - User Story - S2018X1803 - Rejected Valid Records introduction
 * *****************************************************************************************************************************************************************/
package com.bnp.bnpux.serviceimpl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.common.vo.FileMgmtAttachmentListVO;
import com.bnp.bnpux.common.vo.FileMgmtInvoiceListVO;
import com.bnp.bnpux.common.vo.FileMgmtListVO;
import com.bnp.bnpux.common.vo.FileMgmtRejectedRecVO;
import com.bnp.bnpux.common.vo.FileMgmtSummaryVO;
import com.bnp.bnpux.common.vo.ReleaseFileMgmtResponseVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.constants.AttachmentConstants;
import com.bnp.bnpux.constants.ErrorConstants;
import com.bnp.bnpux.constants.FileMgmtConstants;
import com.bnp.bnpux.dao.IFileMgmtDAO;
import com.bnp.bnpux.service.IFileMgmtService;
import com.bnp.bnpux.util.CommonUtil;
import com.bnp.bnpux.vo.requestVO.FileMgmtRequestVO;
import com.bnp.bnpux.vo.requestVO.FileUploadRequestVO;
import com.bnp.bnpux.vo.requestVO.ReleaseFileMgmtRequestVO;
import com.bnp.bnpux.vo.responseVO.FileMgmtResponseVO;
import com.bnp.bnpux.vo.responseVO.FileUploadResponseVO;
import com.bnp.bnpux.wrappers.service.IReleaseFileInqService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;

@Component
public class FileMgmtServiceImpl implements IFileMgmtService{
	
	/**
	 * Logger log for FileMgmtServiceImpl class
	 */
	public static final Logger log = LoggerFactory.getLogger(FileMgmtServiceImpl.class);
	
	/**
	 * IFileMgmtrDAO fileMgmtDAO;
	 */
	@Autowired
	private IFileMgmtDAO fileMgmtDAO;
	
	@Autowired
	private IReleaseFileInqService releaseFileInqService;

	@Autowired
	private CommonUtil commonUtil;
	/**
	 * This method is for getting File Management Details
	 * 
	 * @param fileMgmtRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public FileMgmtResponseVO getFileManagementDetails(FileMgmtRequestVO fileMgmtRequestVO)
			throws BNPApplicationException {
		log.debug("Entry into the getFileManagementDetails API " + System.currentTimeMillis());
		FileMgmtResponseVO fileMgmtResponseVO = new FileMgmtResponseVO();
		String errorFlag = null;	
		try{
			if(fileMgmtRequestVO.getGroupIndicator() != null && fileMgmtRequestVO.getGroupIndicator().equals(FileMgmtConstants.FILE_MANAGEMENT_GROUPBY_UD)){
				if(fileMgmtRequestVO.getUploadDate() != null){
					 fileMgmtRequestVO.setGroupValue(commonUtil.getSimpleFormattedDateString(fileMgmtRequestVO.getUploadDate()));
				}
			}
			if(FileMgmtConstants.VIEW_TYPE_FILEMGMT.equalsIgnoreCase(fileMgmtRequestVO.getViewType())
					|| FileMgmtConstants.VIEW_TYPE_UPLOAD_DATE.equalsIgnoreCase(fileMgmtRequestVO.getViewType())){
				List<FileMgmtSummaryVO> fileMgmtSummaryVOList;
				if(fileMgmtRequestVO.getAdvancedFilterListVO() != null && !fileMgmtRequestVO.getAdvancedFilterListVO().isEmpty()){
					fileMgmtRequestVO.setQuickSearchText("");
					fileMgmtDAO.getFileMgmtSummaryWithAdvFilter(fileMgmtRequestVO);
				}else{
					fileMgmtDAO.getFileMgmtSummary(fileMgmtRequestVO);
				}
				
				fileMgmtSummaryVOList = fileMgmtRequestVO.getFileMgmtSummaryVOList();
				if(fileMgmtSummaryVOList != null){
					fileMgmtResponseVO.setFileMgmtSummaryVOList(fileMgmtSummaryVOList);
				}else{
					errorFlag = fileMgmtRequestVO.getErrorFlag();
					log.error(FileMgmtConstants.FILE_MANAGEMENT_ERROR_DETAILS + errorFlag);
				}			
			}else if(FileMgmtConstants.VIEW_TYPE_FILEMGMT_LIST.equalsIgnoreCase(fileMgmtRequestVO.getViewType())){
				List<FileMgmtListVO> fileMgmtListVO;
				if(fileMgmtRequestVO.getAdvancedFilterListVO() != null && !fileMgmtRequestVO.getAdvancedFilterListVO().isEmpty()){
					fileMgmtRequestVO.setQuickSearchText("");
					fileMgmtDAO.getFileMgmtListWithAdvFilter(fileMgmtRequestVO);
				}else{
					fileMgmtDAO.getFileMgmtList(fileMgmtRequestVO);
				}
				
				fileMgmtListVO = fileMgmtRequestVO.getFileMgmtListVO();
				if(fileMgmtListVO != null){
					fileMgmtResponseVO.setFileMgmtListVO(fileMgmtListVO);
				}		
			}else if(FileMgmtConstants.VIEW_TYPE_FILEMGMT_SUBGRID_DATA.equalsIgnoreCase(fileMgmtRequestVO.getViewType()) && fileMgmtRequestVO.getDocType() != null){
				if(FileMgmtConstants.DISCOUNT_DOC_DOCTYPECODE_1.equals(fileMgmtRequestVO.getDocType())){
					fileMgmtRequestVO.setErrorFlag(fileMgmtRequestVO.getUserId());
					fileMgmtDAO.getFileManagementPODetails(fileMgmtRequestVO);
					fileMgmtResponseVO.setFileMgmtPOListVO(fileMgmtRequestVO.getFileMgmtPOListVO());					
					fileMgmtResponseVO = checkRejectedRecords(fileMgmtResponseVO,fileMgmtRequestVO);
				}else if(FileMgmtConstants.DISCOUNT_DOC_ATTACH_DOCTYPECODE_2.equals(fileMgmtRequestVO.getDocType())){
					fileMgmtDAO.getFileManagementDADetails(fileMgmtRequestVO);
					fileMgmtResponseVO.setFileMgmtAttachmentListVO(fileMgmtRequestVO.getFileMgmtAttachmentListVO());
					fileMgmtResponseVO = checkRejectedRecords(fileMgmtResponseVO,fileMgmtRequestVO);
				}else if(FileMgmtConstants.INVOICE_SETTLEMENT_DOCTYPECODE_3.equals(fileMgmtRequestVO.getDocType())){
					fileMgmtDAO.getFileManagementInvSettleDetails(fileMgmtRequestVO);
					fileMgmtResponseVO.setFileMgmtInvSettleListVO(fileMgmtRequestVO.getFileMgmtInvSettleListVO());
					fileMgmtResponseVO = checkRejectedRecords(fileMgmtResponseVO,fileMgmtRequestVO);
				}else if(FileMgmtConstants.ROLLOVER_SETTLE_DOCTYPECODE_4.equals(fileMgmtRequestVO.getDocType())){
					fileMgmtDAO.getFileManagementRSDetails(fileMgmtRequestVO);
					fileMgmtResponseVO.setFileMgmtRolloverStlListVO(fileMgmtRequestVO.getFileMgmtRolloverStlListVO());
					fileMgmtResponseVO = checkRejectedRecords(fileMgmtResponseVO,fileMgmtRequestVO);
				}else if(FileMgmtConstants.PREAPPROVED_SUPP_DOCTYPECODE_5.equals(fileMgmtRequestVO.getDocType())){
					fileMgmtDAO.getFileManagementPSDetails(fileMgmtRequestVO);
					fileMgmtResponseVO.setFileMgmtPreAppSuppListVO(fileMgmtRequestVO.getFileMgmtPreAppSuppListVO());
					fileMgmtResponseVO = checkRejectedRecords(fileMgmtResponseVO,fileMgmtRequestVO);
				}
			}else if(FileMgmtConstants.VIEW_TYPE_FILEMGMT_LIST_INVOICE.equalsIgnoreCase(fileMgmtRequestVO.getViewType())){
				List<FileMgmtInvoiceListVO> invoiceListVO;
				fileMgmtRequestVO.setErrorFlag(fileMgmtRequestVO.getUserId()+ ":"+fileMgmtRequestVO.getErrorFlag());
				invoiceListVO = fileMgmtDAO.getFileManagementInvoiceDetails(fileMgmtRequestVO);
				fileMgmtResponseVO.setFileMgmtInvoiceListVO(fileMgmtRequestVO.getFileMgmtInvoiceListVO());
				fileMgmtResponseVO = checkRejectedRecords(fileMgmtResponseVO,fileMgmtRequestVO);
			}
		}catch(Exception exception){
			log.error(FileMgmtConstants.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(FileMgmtConstants.EXCEPTION_UNABLE_TO_PROCESS);
		}
		
		log.debug("Exit into the getFileManagementDetails API " + System.currentTimeMillis());
		return fileMgmtResponseVO;			
	}
	
	/**
	 * Method is used to categories valid and invalid rejected records
	 * @param fileMgmtResponseVO
	 * @param fileMgmtRequestVO
	 * @return
	 */
	private FileMgmtResponseVO checkRejectedRecords(FileMgmtResponseVO fileMgmtResponseVO,FileMgmtRequestVO fileMgmtRequestVO){
		List<FileMgmtRejectedRecVO> rejectedValidRecords =  null;
		List<FileMgmtRejectedRecVO> rejectedInValidRecords =  null;
		for(FileMgmtRejectedRecVO rejectionVO : fileMgmtRequestVO.getFileMgmtRejectionListVO()){
			if(FileMgmtConstants.FILE_MANAGEMENT_REJECTED_VALID.equals(rejectionVO.getRecordType())){
				rejectedValidRecords = (rejectedValidRecords != null) ? rejectedValidRecords : new ArrayList<FileMgmtRejectedRecVO>();			
				rejectedValidRecords.add(rejectionVO);								
			}else{
				rejectedInValidRecords = (rejectedInValidRecords != null) ? rejectedInValidRecords : new ArrayList<FileMgmtRejectedRecVO>();
				rejectedInValidRecords.add(rejectionVO);								
			}
		}
		fileMgmtResponseVO.setFileMgmtRejectionListVO(rejectedInValidRecords);
		fileMgmtResponseVO.setFileMgmtValidRejectionListVO(rejectedValidRecords);
		return fileMgmtResponseVO;
	}
	
	
	/**
	 * This method is for getting File Management Details count for Advanced filter
	 * 
	 * @param fileMgmtRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public FileMgmtResponseVO getAdvancedFilterCount(FileMgmtRequestVO fileMgmtRequestVO)
			throws BNPApplicationException {
		log.debug("Entry into the getFileManagementDetails API " + System.currentTimeMillis());
		FileMgmtResponseVO fileMgmtResponseVO = new FileMgmtResponseVO();
		String errorFlag = null;	
		try{
				List<FileMgmtSummaryVO> fileMgmtSummaryVOList;
				fileMgmtDAO.getAdvancedFilterCount(fileMgmtRequestVO);	
				fileMgmtSummaryVOList = fileMgmtRequestVO.getFileMgmtSummaryVOList();
				if(fileMgmtSummaryVOList != null){
					fileMgmtResponseVO.setFileMgmtSummaryVOList(fileMgmtSummaryVOList);
				}else{
					errorFlag = fileMgmtRequestVO.getErrorFlag();
					log.error(FileMgmtConstants.FILE_MANAGEMENT_ERROR_DETAILS + errorFlag);
				}			
		}catch(Exception exception){
			log.error(FileMgmtConstants.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(FileMgmtConstants.EXCEPTION_UNABLE_TO_PROCESS);
		}
		
		log.debug("Exit into the getFileManagementDetails API " + System.currentTimeMillis());
		return fileMgmtResponseVO;			
	}
	

	/* (non-Javadoc)
	 * @see com.bnp.bnpux.service.IFileMgmtService#undoFileUploadRequest(com.bnp.bnpux.vo.requestVO.ReleaseFileMgmtRequestVO)
	 */
	public ReleaseFileMgmtResponseVO undoFileUploadRequest(ReleaseFileMgmtRequestVO releaseFileMgmtRequestVo ,UserInfoVO user) throws BNPApplicationException{
		ReleaseFileMgmtResponseVO releaseFileMgmtResponseVO = new ReleaseFileMgmtResponseVO();
		log.debug("Entry into the undoFileUploadRequest API " + System.currentTimeMillis());
		List<FileDetailsVO> fileDetailsVOList = fileMgmtDAO.getReleaseFileDetailsVO(releaseFileMgmtRequestVo);		
		if(fileDetailsVOList.size()>0){
			releaseFileMgmtResponseVO = releaseFileInqService.deleteFile(fileDetailsVOList, user);
			
		}
		commonUtil.checkEligibleRecordsForFileMgmtAction(releaseFileMgmtResponseVO, releaseFileMgmtRequestVo.getFileListVO(), fileDetailsVOList, "Please select the valid record for File Undo");
		
		log.debug("Exit into the undoFileUploadRequest API " + System.currentTimeMillis());
		return releaseFileMgmtResponseVO;
	};
	
	/* (non-Javadoc)
	 * @see com.bnp.bnpux.service.IFileMgmtService#releaseFileUploadRequest(com.bnp.bnpux.vo.requestVO.ReleaseFileMgmtRequestVO)
	 */
	public ReleaseFileMgmtResponseVO releaseFileUploadRequest(ReleaseFileMgmtRequestVO releaseFileMgmtRequestVo, UserInfoVO user) throws BNPApplicationException{
		ReleaseFileMgmtResponseVO releaseFileMgmtResponseVO = new ReleaseFileMgmtResponseVO();
		log.debug("Entry into the releaseFileUploadRequest API " + System.currentTimeMillis());
		List<FileDetailsVO> fileDetailsVOList = fileMgmtDAO.getReleaseFileDetailsVO(releaseFileMgmtRequestVo);	
		if(fileDetailsVOList.size()>0){
			releaseFileMgmtResponseVO = releaseFileInqService.releaseFile(fileDetailsVOList, user);
		}
		commonUtil.checkEligibleRecordsForFileMgmtAction(releaseFileMgmtResponseVO, releaseFileMgmtRequestVo.getFileListVO(), fileDetailsVOList, "Please select the valid record for File Undo");
		
		
		log.debug("Exit into the releaseFileUploadRequest API " + System.currentTimeMillis());
		return releaseFileMgmtResponseVO;
	}
	
	/**
	 * @param releaseFileMgmtRequestVO
	 * @param userInfoVO
	 * @return
	 * @throws BNPApplicationException
	 */
	public ReleaseFileMgmtResponseVO authorizeFileUploadRequest(ReleaseFileMgmtRequestVO releaseFileMgmtRequestVO, UserInfoVO userInfoVO) throws BNPApplicationException{
		ReleaseFileMgmtResponseVO releaseFileMgmtResponseVO = new ReleaseFileMgmtResponseVO();
		List<FileDetailsVO> fileDetailsVOList = fileMgmtDAO.getReleaseFileDetailsVO(releaseFileMgmtRequestVO);
		if(fileDetailsVOList.size() > 0)
		{
			releaseFileMgmtResponseVO = releaseFileInqService.authorizeFile(fileDetailsVOList, userInfoVO);
		}
		return releaseFileMgmtResponseVO;
	}
	
	/**
	 * @param releaseFileMgmtRequestVO
	 * @param userInfoVO
	 * @return
	 * @throws BNPApplicationException
	 */
	public ReleaseFileMgmtResponseVO rejectFile(ReleaseFileMgmtRequestVO releaseFileMgmtRequestVO, UserInfoVO userInfoVO) throws BNPApplicationException{
		ReleaseFileMgmtResponseVO releaseFileMgmtResponseVO = new ReleaseFileMgmtResponseVO();
		List<FileDetailsVO> fileDetailsVOList = fileMgmtDAO.getReleaseFileDetailsVO(releaseFileMgmtRequestVO);
		if(fileDetailsVOList.size() > 0)
		{
			releaseFileMgmtResponseVO = releaseFileInqService.rejectFile(fileDetailsVOList, userInfoVO);
		}
		return releaseFileMgmtResponseVO;
	}
	

	/**
	 * This method is for getting attachment information for the file and Download operations
	 * 
	 * @param fileMgmtRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public FileMgmtResponseVO getAttachmentList(FileMgmtRequestVO fileMgmtRequestVO) throws BNPApplicationException {
		FileMgmtResponseVO fileMgmtResponseVO = new FileMgmtResponseVO();
		try{			
			fileMgmtDAO.getFMAttachmentList(fileMgmtRequestVO);			
			fileMgmtResponseVO.setFileMgmtAttachmentListVO(fileMgmtRequestVO.getFileMgmtAttachmentListVO());	
			if(!FileMgmtConstants.FILE_MANAGMENT_ATTACHEMENT_DTL.equals(fileMgmtRequestVO.getGetWhat())){
				fileMgmtResponseVO = downLoadAll(fileMgmtRequestVO.getFileMgmtAttachmentListVO());
			}
		}catch(DataAccessException exception){
			log.error(FileMgmtConstants.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(FileMgmtConstants.EXCEPTION_UNABLE_TO_PROCESS);
		}
		return fileMgmtResponseVO;
	}
	
	/**
	 * This method is for downloading all
	 * 
	 * @param listAttachmentDetails
	 * @return AttachmentResponseVO
	 * @throws BNPApplicationException 
	 * @Description downLoad All Attachment
	 */
	public FileMgmtResponseVO downLoadAll(List<FileMgmtAttachmentListVO> listAttachmentDetails)throws BNPApplicationException
	{
		FileMgmtResponseVO attachmentresponse = new FileMgmtResponseVO();
		try
		{
			byte[] readBuff;	
			readBuff =compressFiles(listAttachmentDetails);
			attachmentresponse.setData(readBuff);
			attachmentresponse.setFileName(FileMgmtConstants.SCF_FILE_NAME);
		}catch (Exception e) {
			log.error(FileMgmtConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL,e);
			throw new BNPApplicationException(FileMgmtConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL);
		}
		return attachmentresponse;
	}
	
	/**
	 * This method is for compressing files
	 * 
	 * @param listdownLoadAll
	 * @return byte[]
	 * @throws BNPApplicationException 
	 * @Description Compress List of Attachment
	 */
	public byte[] compressFiles(List<FileMgmtAttachmentListVO> listdownLoadAll) 
	throws BNPApplicationException{

		ByteArrayOutputStream objbyteArrayStream = null;
		ZipOutputStream outputStream = null;
		byte[] objByteoutput = null;
		
		try{
			if(!listdownLoadAll.isEmpty()){
				objbyteArrayStream = new ByteArrayOutputStream();
				outputStream = new ZipOutputStream(objbyteArrayStream);
				for ( int i = 0; i<listdownLoadAll.size();i++)
				{
					FileMgmtAttachmentListVO objFileVO = listdownLoadAll.get(i);
					String fileName = objFileVO.getFileName();
					outputStream.putNextEntry(new ZipEntry(getFileName(fileName,i)));
					outputStream.write(objFileVO.getData());
					outputStream.closeEntry();
					objFileVO = null;
				}
				outputStream.finish();
				outputStream.flush();
				objByteoutput = objbyteArrayStream.toByteArray();

			}
		}
		catch (IOException ioe) {
			log.error(FileMgmtConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL,ioe);
			throw new BNPApplicationException(FileMgmtConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL);
		}
		finally
		{
			try{
				if(objbyteArrayStream!=null){
					objbyteArrayStream.close();
				}
				if(outputStream!=null)
				{
				outputStream.finish();
				outputStream.flush();
				outputStream.close();
				}
			}
			catch (IOException ioe) {
				log.error(AttachmentConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL,ioe);
			}
		}
		return objByteoutput;
	}
	
	/**
	 * @param fileName
	 * @param num
	 * @return String
	 * @Description Get File Name
	 */
	private String getFileName(String fileName, int num){
		StringBuilder fileNameTemp = new StringBuilder(fileName);
		StringBuilder toAppend = new StringBuilder();
		toAppend.append("(").append(num+1).append(")");
		fileNameTemp.insert(fileName.length()-(fileName.length()-fileName.lastIndexOf(".")),toAppend);
		return fileNameTemp.toString();
	}
	
	/**
	 * @param objAttachVO
	 * @return byte[]
	 * @throws BNPApplicationException 
	 * @Description Compress Single File
	 */
	public byte[] compressSingleFile(FileMgmtAttachmentListVO objAttachVO)throws BNPApplicationException
	{
		List<FileMgmtAttachmentListVO> alSingleFileList;
		alSingleFileList =new ArrayList<FileMgmtAttachmentListVO>();
		alSingleFileList.add(objAttachVO);
		return compressFiles(alSingleFileList);
	}


	/**
	 * @param fileUploadRequestVO
	 * @return fileMgmtResponseVO
	 * @throws BNPApplicationException 
	 * @Description This is an service implementation method which is used to get Updated file upload status
	 */
	@Override
	public FileUploadResponseVO getUpdatedFileUploadStatus(FileUploadRequestVO fileUploadRequestVO) throws BNPApplicationException {
		FileUploadResponseVO fileUploadResponseVO = new FileUploadResponseVO();
		try{
			fileMgmtDAO.getUpdatedFileUploadStatus(fileUploadRequestVO);
		}catch(DataAccessException exception){
			log.error(FileMgmtConstants.EXCEPTION_UNABLE_TO_GET_UPDATED_FILE_UPLOAD_STATUS,exception);
			throw new BNPApplicationException(FileMgmtConstants.EXCEPTION_UNABLE_TO_GET_UPDATED_FILE_UPLOAD_STATUS);
		}
		return fileUploadResponseVO;
	}

 


}
