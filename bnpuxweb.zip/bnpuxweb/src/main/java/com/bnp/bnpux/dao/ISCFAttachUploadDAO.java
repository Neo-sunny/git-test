/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   15-JUL-2017
 * 
 * Purpose:      SCF Attach Upload DAO
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 15-JUL-2017				Divyashri Subramaniam						To call Mybatis Query for Attach SCF Upload Functionality
************************************************************************************************************************************************************/
package com.bnp.bnpux.dao;

import java.util.List;
import com.bnp.bnpux.vo.requestVO.SCFAttachUploadRequestVO;
import com.bnp.scm.services.attachment.vo.SCFAttachmentUploadVO;

public interface ISCFAttachUploadDAO {

	List<SCFAttachmentUploadVO> getAttachUploadPOData(SCFAttachUploadRequestVO scfAttachUploadRequestVO);
	
}
