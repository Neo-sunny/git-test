/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:      Transaction Response Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 * 21 Feb 2017						Sathishkumar B														      FO 10.0 - S008, S009, S010, S011, S012, S013, S014
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.responseVO;

import java.util.List;

import com.bnp.bnpux.common.vo.TransactionChargeAmtVO;
import com.bnp.bnpux.common.vo.TransactionConfimedAmtVO;
import com.bnp.bnpux.common.vo.TransactionListVO;
import com.bnp.bnpux.common.vo.TransactionSummaryVO;


public class TransactionResponseVO {
	
	private String errorFlag;
	
	private String errorMsg;
	
	private List<TransactionSummaryVO> summaryList;
	
	private List<TransactionListVO> transactionList;
	
	private List<TransactionChargeAmtVO> transactionChargeAmtVOList;
	
	private TransactionConfimedAmtVO transactionConfirmedAmtVO;
		

	public String getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	public List<TransactionSummaryVO> getSummaryList() {
		return summaryList;
	}

	public void setSummaryList(List<TransactionSummaryVO> summaryList) {
		this.summaryList = summaryList;
	}

	public List<TransactionListVO> getTransactionList() {
		return transactionList;
	}

	public void setTransactionList(List<TransactionListVO> transactionList) {
		this.transactionList = transactionList;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public List<TransactionChargeAmtVO> getTransactionChargeAmtVOList() {
		return transactionChargeAmtVOList;
	}

	public void setTransactionChargeAmtVOList(List<TransactionChargeAmtVO> transactionChargeAmtVOList) {
		this.transactionChargeAmtVOList = transactionChargeAmtVOList;
	}

	public TransactionConfimedAmtVO getTransactionConfirmedAmtVO() {
		return transactionConfirmedAmtVO;
	}

	public void setTransactionConfirmedAmtVO(TransactionConfimedAmtVO transactionConfirmedAmtVO) {
		this.transactionConfirmedAmtVO = transactionConfirmedAmtVO;
	}


}
