package com.bnp.bnpux.vo.responseVO;

import java.util.List;

import com.bnp.bnpux.common.vo.PaymentReportDetailsVO;
import com.bnp.bnpux.common.vo.PaymentReportVO;

public class PaymentReportResponseVO {

	
    private String errorMessage;
	
	private List<PaymentReportVO> paymentReportList;
	
	private List<PaymentReportDetailsVO> paymentReportDetailsList;

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public List<PaymentReportVO> getPaymentReportList() {
		return paymentReportList;
	}

	public void setPaymentReportList(List<PaymentReportVO> paymentReportList) {
		this.paymentReportList = paymentReportList;
	}

	public List<PaymentReportDetailsVO> getPaymentReportDetailsList() {
		return paymentReportDetailsList;
	}

	public void setPaymentReportDetailsList(List<PaymentReportDetailsVO> paymentReportDetailsList) {
		this.paymentReportDetailsList = paymentReportDetailsList;
	}

	

}
