/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas.
 *
 * Created on:   17 June 2016
 *
 * Purpose:      Transaction Service Implementation Class
 *
 * Change History:
 * Date                                    Author                                                                               Reason
 * ----------------------------------------------------------------------------------------------------------------------------------------------------
 * 17 June 2016						    Bala Murugan Elangovan														 	 Service Implementation
 * 13 July 2016						    Purushothaman														 	        Service Interface for S144 - Discount Approval
 * 18 July 2016						    Purushothaman														 	        Service Interface for S145 & S146 - Discount Rejection
 * 25 July 2016							Nirmal Palani																	Removed ErrorMsg.add as per Code Review comment
 * 21 Feb 2017							Sathishkumar B																	FO 10.0 - S008, S009, S010, S011, S012, S013, S014 
 * 16 Mar 2017							aasriniv																		FO 10.0 Advanced Filter Implementation - Transaction
 * *****************************************************************************************************************************************************************/
package com.bnp.bnpux.serviceimpl;

import java.sql.Blob;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.common.vo.ApproveRequestVo;
import com.bnp.bnpux.common.vo.ApproveResponseVo;
import com.bnp.bnpux.common.vo.CommitmentFeeUxVO;
import com.bnp.bnpux.common.vo.OrganizationVO;
import com.bnp.bnpux.common.vo.TransactionChargeAmtVO;
import com.bnp.bnpux.common.vo.TransactionConfimedAmtVO;
import com.bnp.bnpux.common.vo.TransactionListVO;
import com.bnp.bnpux.common.vo.TransactionSummaryVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.constants.TransactionConstants;
import com.bnp.bnpux.dao.ILoginDAO;
import com.bnp.bnpux.dao.ITransactionDAO;
import com.bnp.bnpux.discounting.service.IDiscountApproveSummaryService;
import com.bnp.bnpux.discounting.service.IDiscountCancelSummaryService;
import com.bnp.bnpux.service.ITransactionService;
import com.bnp.bnpux.vo.errorMessageVO.ErrorMessageVO;
import com.bnp.bnpux.vo.requestVO.TransactionRequestVO;
import com.bnp.bnpux.vo.responseVO.TransactionResponseVO;
import com.bnp.scm.common.IResourceManager;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.discounting.IDiscountRequestService;
import com.bnp.scm.services.discounting.IDiscountService;
import com.bnp.scm.services.discounting.vo.DiscountRequestVO;

@Component
public class TransactionServiceImpl implements ITransactionService{

	/**
	 * Logger log for TransactionController class
	 */
	public static final Logger log = LoggerFactory.getLogger(TransactionServiceImpl.class);

	/**
	 * ITransactionDAO transactionDAO;
	 */
	@Autowired
	private ITransactionDAO transactionDAO;

	@Autowired
	private IDiscountApproveSummaryService discountApproveSummaryService;
	@Autowired
	private IDiscountCancelSummaryService discountCancelSummaryService;

	@Autowired
	private IDiscountService discountService;

	@Autowired
	protected IResourceManager resourceManager;

	@Autowired
	private IDiscountRequestService discountRequestService;
	
	@Autowired
	private ILoginDAO iLoginDAO;
	
	/**
	 * Service Method to get Transaction Information
	 * @param transactionReqVO
	 * @return
	 * @throws DataAccessException 
	 * @throws BNPApplicationException 
	 */
	@Override
	public TransactionResponseVO getTransactionInfo(TransactionRequestVO transactionReqVO) throws BNPApplicationException{
		TransactionResponseVO transactionResponseVO = new TransactionResponseVO();
		String errorMsg = null;


		try{
			if(TransactionConstants.VIEW_TYPE_TRANSACTION_SUMMARY.equals(transactionReqVO.getViewType())){
				List<TransactionSummaryVO> summaryVOList = new ArrayList<TransactionSummaryVO>();
				/*Commented below Hashmap Implementation for code review comments(HashMap to RequestVO  in service layer)*/
				/*Map<String,Object> paramMap = new HashMap<String, Object>();
				paramMap.put(TransactionConstants.PARAM_USER_ID, transactionReqVO.getUserId());
				paramMap.put(TransactionConstants.PARAM_USER_TYPE_ID, transactionReqVO.getUserType());
				paramMap.put(TransactionConstants.PARAM_RECORD_FROM, transactionReqVO.getRecordFrom());
				paramMap.put(TransactionConstants.PARAM_RECORD_TO, transactionReqVO.getRecordTo());
				paramMap.put(TransactionConstants.PARAM_GROUP_INDICATOR, transactionReqVO.getGroupIndicator());
				paramMap.put(TransactionConstants.PARAM_BUYER_REF_NO_UNIQUE, transactionReqVO.getBuyerRefNoUniqueValue());
				paramMap.put(TransactionConstants.PARAM_PAYMENT_DATE, transactionReqVO.getPaymentDate());
				paramMap.put(TransactionConstants.PARAM_PAYMENT_FLAG, transactionReqVO.getPaymentFlagValue());
				paramMap.put(TransactionConstants.PARAM_LEAD_ORG_VALUE, transactionReqVO.getLeadOrgIdValue());
				paramMap.put(TransactionConstants.FILTER_STATUS, transactionReqVO.getStatusFilter());
				paramMap.put(TransactionConstants.FILTER_PERIOD, transactionReqVO.getPeriodFilter());
				paramMap.put(TransactionConstants.FILTER_BRANCH, transactionReqVO.getBranchFilter());
				paramMap.put(TransactionConstants.QUICK_SEARCH, transactionReqVO.getQuickSearchText());
				transactionDAO.getTransactionSummaryInfo(paramMap);
				summaryVOList = (List<TransactionSummaryVO>)paramMap.get(TransactionConstants.PARAM_TRANSACTION_SUMMARY);*/
				
				if(transactionReqVO.getAdvancedFilterListVO() !=null && !transactionReqVO.getAdvancedFilterListVO().isEmpty())
				{
					transactionReqVO.setQuickSearchText("");
					transactionDAO.getTransactionSummaryInfoWithAdvFilter(transactionReqVO);
				}
				else
				{
					transactionDAO.getTransactionSummaryInfo(transactionReqVO);
				}
				summaryVOList = (List<TransactionSummaryVO>)transactionReqVO.getTransactionSummary();
				if(summaryVOList != null && summaryVOList.size() > 0){
					transactionResponseVO.setSummaryList(summaryVOList);
				}else{
					errorMsg = (String)transactionReqVO.getErrorFlag();
					transactionResponseVO.setErrorFlag(errorMsg);
				}
			}else if(TransactionConstants.VIEW_TYPE_TRANSACTION_LIST.equals(transactionReqVO.getViewType())){
				List<TransactionListVO> transactionVOList = new ArrayList<TransactionListVO>();
				/*Commented below Hashmap Implementation for code review comments(HashMap to RequestVO  in service layer)*/
			/*	Map<String,Object> transactionListMap = new HashMap<String, Object>();
				transactionListMap.put(TransactionConstants.PARAM_USER_ID, transactionReqVO.getUserId());
				transactionListMap.put(TransactionConstants.PARAM_USER_TYPE_ID, transactionReqVO.getUserType());
				transactionListMap.put(TransactionConstants.PARAM_RECORD_FROM, transactionReqVO.getRecordFrom());
				transactionListMap.put(TransactionConstants.PARAM_RECORD_TO, transactionReqVO.getRecordTo());
				transactionListMap.put(TransactionConstants.PARAM_GROUP_INDICATOR, transactionReqVO.getGroupIndicator());
				transactionListMap.put(TransactionConstants.PARAM_BUYER_REF_NO_UNIQUE, transactionReqVO.getBuyerRefNoUniqueValue());
				transactionListMap.put(TransactionConstants.PARAM_PAYMENT_FLAG, transactionReqVO.getPaymentFlagValue());
				transactionListMap.put(TransactionConstants.PARAM_PAYMENT_DATE, transactionReqVO.getPaymentDate());
				transactionListMap.put(TransactionConstants.PARAM_BUYER_ORG_ID, transactionReqVO.getBuyerOrgId());
				transactionListMap.put(TransactionConstants.PARAM_SUPPLIER_ORG_ID, transactionReqVO.getSupplierOrgId());
				transactionListMap.put(TransactionConstants.PARAM_LEAD_ORG_ID, transactionReqVO.getLeadOrgId());
				transactionListMap.put(TransactionConstants.PARAM_CURRENCY_CODE, transactionReqVO.getCurrencyCode());
				transactionListMap.put(TransactionConstants.FILTER_STATUS, transactionReqVO.getStatusFilter());
				transactionListMap.put(TransactionConstants.FILTER_PERIOD, transactionReqVO.getPeriodFilter());
				if(transactionReqVO.getBranchFilter()==null || transactionReqVO.getBranchFilter().trim()==""){
					transactionListMap.put(TransactionConstants.FILTER_BRANCH, "null");
				}else{
					transactionListMap.put(TransactionConstants.FILTER_BRANCH, transactionReqVO.getBranchFilter());
				}
				transactionListMap.put(TransactionConstants.QUICK_SEARCH, transactionReqVO.getQuickSearchText());
				transactionDAO.getTransactionListInfo(transactionListMap);
				transactionVOList = (List<TransactionListVO>)transactionListMap.get(TransactionConstants.PARAM_TRANSACTION_LIST);*/
				if(transactionReqVO.getBranchFilter()==null || transactionReqVO.getBranchFilter().trim()==""){
					transactionReqVO.setBranchFilter(null);
				}
				if(transactionReqVO.getAdvancedFilterListVO() !=null && !transactionReqVO.getAdvancedFilterListVO().isEmpty())
				{	
					transactionReqVO.setQuickSearchText("");
					transactionDAO.getTransactionListInfoWithAdvFilter(transactionReqVO);
				}
				else
				{
					transactionDAO.getTransactionListInfo(transactionReqVO);
				}
				
				transactionVOList = (List<TransactionListVO>)transactionReqVO.getTransactionListDetails();
				if(transactionVOList != null && transactionVOList.size() > 0){
					transactionResponseVO.setTransactionList(transactionVOList);
				}else{

					errorMsg = (String)transactionReqVO.getErrorFlag();
					transactionResponseVO.setErrorFlag(errorMsg);
				}

			}
		}catch(DataAccessException dataAccessException){
			log.error(TransactionConstants.EXCEPTION_TRANSACTION_INFORMATION,dataAccessException);
			throw new BNPApplicationException(TransactionConstants.EXCEPTION_TRANSACTION_INFORMATION);
		}
		return transactionResponseVO;
	}
	
	/**
	 * This method is for getting Adv filter count details
	 * 
	 * @param PaymentOrderRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public TransactionResponseVO getAdvancedFilterCount(TransactionRequestVO transactionReqVO) throws BNPApplicationException{
		log.debug("Entry into the getAdvancedFilterCount API " + System.currentTimeMillis());
		TransactionResponseVO transactionResponseVO = new TransactionResponseVO();
		String errorFlag = null;	
		try{
			
				List<TransactionSummaryVO> transactionVOList = new ArrayList<TransactionSummaryVO>();
							
				if(transactionReqVO.getBranchFilter()==null || transactionReqVO.getBranchFilter().trim()==""){
					transactionReqVO.setBranchFilter(null);
				}
				if(transactionReqVO.getAdvancedFilterListVO() !=null && !transactionReqVO.getAdvancedFilterListVO().isEmpty())
				{
					transactionDAO.getAdvFilterIndicatorCount(transactionReqVO);
				}
				transactionVOList = (List<TransactionSummaryVO>)transactionReqVO.getTransactionSummary();
				if(transactionVOList != null && transactionVOList.size() > 0){
					transactionResponseVO.setSummaryList(transactionVOList);
				}else{

					errorFlag = (String)transactionReqVO.getErrorFlag();
					transactionResponseVO.setErrorFlag(errorFlag);
				}
				}			
			
		catch(DataAccessException dataAccessException){
			log.error(TransactionConstants.EXCEPTION_TRANSACTION_INFORMATION,dataAccessException);
			throw new BNPApplicationException(TransactionConstants.EXCEPTION_TRANSACTION_INFORMATION);
		}
		
		return transactionResponseVO;			
	}

   // Added for User Stories S144(Discount Approval) by Purushoth
	/**
	 * Service Method to Approve Discount Requests
	 * @param transactionListVO
	 * @param userVo
	 * @return
	 * @throws BNPApplicationException 
	 */
	public ApproveResponseVo approveDiscountRequest(List<TransactionListVO> transactionListVO, UserInfoVO user) throws BNPApplicationException{
		//List<DiscountRequestVO> discVOList = new ArrayList<DiscountRequestVO>();
		List<DiscountRequestVO> discVOList = transactionDAO.getDiscountRequestVO(transactionListVO);
		ApproveResponseVo approveResponseVo = null;
		//discVOList.add(transactionDAO.getDiscountRequestVO(transactionListVO));
		try {
			// Added for CSC-5697 - to fix the multiple error message while concurrent users
			if(discVOList!=null && discVOList.size()>0){
				approveResponseVo = discountApproveSummaryService.approve(discVOList, user);
			// Added for CSC-5697 - changes ends	
			// Added for CSC-5697 - to fix the multiple error message while concurrent users - changes starts			
			}else{
				 approveResponseVo = new ApproveResponseVo();
				 List<ErrorMessageVO> objErrorMsgVOLst  = new ArrayList<ErrorMessageVO>();
			     for(TransactionListVO txnOrderVO :transactionListVO ){
					 ErrorMessageVO objErrorMessageVO  = new ErrorMessageVO();
					 objErrorMessageVO.setUniqueID(txnOrderVO.getDiscRefNo());
				     objErrorMessageVO.setMessage("Please select the valid record for Approval");
				     objErrorMessageVO.setError(true);
				     objErrorMsgVOLst.add(objErrorMessageVO);
				     

				 }
			     approveResponseVo.seterrMessageVO(objErrorMsgVOLst);
			}
			// Added for CSC-5697 - changes ends
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.error(e.getMessage(),e);
		}
		//return paymentOrderDAO.getDiscountRequestVO(paymentOrderListtVO);
		//ErrorMsg = "Discount Request has been approved Successfully";
		return approveResponseVo;
	}

	/**
	 * Service Method to Approve Discount Requests
	 * @param transactionListVO
	 * @param userVo
	 * @return
	 * @throws BNPApplicationException 
	 */
	public ApproveResponseVo proceedApproveDiscountRequest(List<TransactionListVO> transactionListVO, UserInfoVO user,ApproveRequestVo apprvReqVo) throws BNPApplicationException{
		//List<DiscountRequestVO> discVOList = new ArrayList<DiscountRequestVO>();
		List<DiscountRequestVO> discVOList = transactionDAO.getDiscountRequestVO(transactionListVO);
		List<String> ErrorMsg= new ArrayList<String>();
		ApproveResponseVo approveResponseVo = null;
		//discVOList.add(transactionDAO.getDiscountRequestVO(transactionListVO));
		try {
			//Added below for fortify fix - Do not maintain sigleton object
			approveResponseVo = discountApproveSummaryService.proceedApproveDiscountRequest(discVOList, user, apprvReqVo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.error(e.getMessage(),e);
		}
		//return paymentOrderDAO.getDiscountRequestVO(paymentOrderListtVO);
		//ErrorMsg = "Discount Request has been approved Successfully";
		return approveResponseVo;
	}

	/**
	 * This method for cancelling discount request
	 * 
	 * @param tlvo
	 * @param userVo
	 * @return
	 * @throws BNPApplicationException
	 */
	public String cancelDiscountRequest(TransactionListVO transactionListVO, UserInfoVO user) throws BNPApplicationException{
		List<DiscountRequestVO> discVOList = new ArrayList<DiscountRequestVO>();
		String ErrorMsg = "";
		/*Modified below condition for UAT defect CSC-5673*/
		DiscountRequestVO discReqVO= transactionDAO.getDiscountRequestCancelVO(transactionListVO); 
		if(discReqVO == null){
			ErrorMsg = "Please select a APPROVED/RELEASE PENDING/PENDING DISCOUNT REJECTED record to Cancel";
			return ErrorMsg; 
		}
		discVOList.add(discReqVO);
		try {
			

			ErrorMsg = discountCancelSummaryService.cancel(discVOList, user.getUserId());


		} catch (Exception e) {
			// TODO Auto-generated catch block
			ErrorMsg = "Error Occurred in Discount Request Cancel. Please Try Later.";
			log.error(e.getMessage(),e);
		}
		//return paymentOrderDAO.getDiscountRequestVO(paymentOrderListtVO);
		//ErrorMsg = "Discount Request Cancelled Successfully";
		return ErrorMsg;
	}

	//Added For User Stories S145 and S146 - Discount Rejection

	/**
	 * Service Method to Reject Discount Requests
	 * @param transactionListVO
	 * @param userVo
	 * @return
	 * @throws BNPApplicationException 
	 */
	public List<ErrorMessageVO> returnDiscountRequest(List<TransactionListVO> transactionListVO, UserInfoVO user,ApproveRequestVo apprvReqVo) throws BNPApplicationException{
		List<DiscountRequestVO> discVOList = transactionDAO.getDiscountRequestVO(transactionListVO);
		List<ErrorMessageVO> ErrorMsg= new ArrayList<ErrorMessageVO>();
		try {
			//Added below for fortify fix - Do not maintain sigleton object
			ErrorMsg = discountApproveSummaryService.returnDiscountRequest(discVOList, user, apprvReqVo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//ErrorMsg.add("Discount Request Reject has been failed with exception");
			log.error(e.getMessage(),e);
		}
		return ErrorMsg;
	}

	/**
	 * Service Method to Reject Discount Requests
	 * @param transactionListVO
	 * @param userVo
	 * @return
	 * @throws BNPApplicationException 
	 */
	public List<ErrorMessageVO> rejectDiscountRequest(List<TransactionListVO> transactionListVO, UserInfoVO user) throws BNPApplicationException{
		List<DiscountRequestVO> discVOList = transactionDAO.getDiscountRequestVO(transactionListVO);
		List<ErrorMessageVO> ErrorMsg= new ArrayList<ErrorMessageVO>();
		try {
			ErrorMsg = discountApproveSummaryService.reject(discVOList, user);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//ErrorMsg.add("Discount Request Reject has been failed with exception");
			log.error(e.getMessage(),e);
		}
		return ErrorMsg;
	}

	/**
	 * This method for undo transaction
	 * 
	 * @param transRecords
	 * @param userInfo
	 * @return
	 */
	@Override
	public List<ErrorMessageVO> undoTransactionRecord(List<TransactionListVO> transRecords,UserInfoVO userInfo) {
		List<ErrorMessageVO> statusResponse  = new ArrayList<ErrorMessageVO>();;
		List<TransactionListVO> buyerAccpUndo = getBuyerAccpUndoList(transRecords,statusResponse);
		List<TransactionListVO> pendingCanUndo = getPendingCancelUndoList(transRecords,statusResponse);
		if(!buyerAccpUndo.isEmpty())
		{
			statusResponse = undoBuyerAcceptanceRecord(buyerAccpUndo,userInfo.getUserId());
		}
		if(!pendingCanUndo.isEmpty())
		{
			statusResponse = undoPendingCancelRecord(pendingCanUndo,userInfo.getUserId());
		}
		return statusResponse;
	}

	/**
	 * @param tRecs
	 * @param statusResponse
	 * @return TransactionListVO List
	 * @Description Get List of Transaction which are pending for Buyer Approval
	 */
	private List<TransactionListVO> getBuyerAccpUndoList(List<TransactionListVO> tRecs,List<ErrorMessageVO> statusResponse)
	{
		List<TransactionListVO> buyerAccpUndo = new ArrayList<TransactionListVO>();
		for (TransactionListVO t : tRecs) {
			String discStatus = t.getDiscStatus();
			if(StatusConstants.PENDING_BUYER_ACCEPTANCE_APPROVAL.equals(discStatus) || StatusConstants.PENDING_BUYER_REJECTION_APPROVAL.equals(discStatus))
			{
				buyerAccpUndo.add(t);
			}
			else
			{
				String disReqStatus = resourceManager.getMessage(ErrorConstants.UNDO_ERROR_MSG);
				ErrorMessageVO errorMsg = new ErrorMessageVO();
				errorMsg.setUniqueID(t.getDiscRefNo());
			    errorMsg.setError(true);
			    errorMsg.setMessage(disReqStatus);
			    statusResponse.add(errorMsg);
			}
		}
		return buyerAccpUndo;
	}

	/**
	 * @param tRecs
	 * @param statusResponse
	 * @return TransactionListVO List
	 * @Description get Pending Cancel Undo List
	 */
	private List<TransactionListVO> getPendingCancelUndoList(List<TransactionListVO> tRecs,List<ErrorMessageVO> statusResponse){
		List<TransactionListVO> pendingCancelUndoLst = new ArrayList<TransactionListVO>();
		for (TransactionListVO t : tRecs) {
			String discStatus = t.getDiscStatus();
			if(StatusConstants.CANCEL_PENDING_FOR_APPROVAL.equals(discStatus))
			{
				pendingCancelUndoLst.add(t);
			}
			else
			{
				String disReqStatus = resourceManager.getMessage(ErrorConstants.UNDO_ERROR_MSG);
				ErrorMessageVO errorMsg = new ErrorMessageVO();
				errorMsg.setUniqueID(t.getDiscRefNo());
			    errorMsg.setError(true);
			    errorMsg.setMessage(disReqStatus);
			    statusResponse.add(errorMsg);
			}
		}
		return pendingCancelUndoLst;
	}

	/**
	 * @param recs
	 * @param userId
	 * @return ErrorMessageVO List
	 * @Description Revert Buyer Acceptance Record
	 */
	private List<ErrorMessageVO> undoBuyerAcceptanceRecord(List<TransactionListVO> recs,String userId)
	{
		List<ErrorMessageVO> statusResponseLst = new ArrayList<ErrorMessageVO>();
		for (TransactionListVO t : recs) {
			String disReqStatus = "";
			boolean isvalid = true;
			String discountStatus = t.getDiscStatus();
			ErrorMessageVO errorMsg = new ErrorMessageVO();
			DiscountRequestVO discRequestVO = new DiscountRequestVO();
			discRequestVO.setDiscountRefNo(t.getDiscRefNo());
			discRequestVO.setMbModel(t.getMbModel());
			 if(! StatusConstants.PENDING_BUYER_ACCEPTANCE_APPROVAL.equals(discountStatus) && ! StatusConstants.PENDING_BUYER_REJECTION_APPROVAL.equals(discountStatus)){
				    disReqStatus = resourceManager.getMessage(ErrorConstants.UNDO_ERROR_MSG);
					errorMsg.setUniqueID(t.getDiscRefNo());
				    errorMsg.setError(true);
				    errorMsg.setMessage(disReqStatus);
					isvalid = false;
				  }else if(!userId.equals(t.getMakerId())){
				    disReqStatus = resourceManager.getMessage(ErrorConstants.MAKER_CHECK_UNDO);
					errorMsg.setUniqueID(t.getDiscRefNo());
				    errorMsg.setError(true);
				    errorMsg.setMessage(disReqStatus);
					isvalid = false;
				  }
			if(isvalid)
			{
				try {
					discountService.undoBuyerAcceptanceRecord(discRequestVO, userId);
					disReqStatus = resourceManager.getMessage(ErrorConstants.UNDO_SUCCESS);
					errorMsg.setUniqueID(t.getDiscRefNo());
				    errorMsg.setError(false);
				    errorMsg.setMessage(disReqStatus);
				} catch (BNPApplicationException e) {
					disReqStatus = resourceManager.getMessage(ErrorConstants.REJECT_FAILURE);
					errorMsg.setUniqueID(t.getDiscRefNo());
				    errorMsg.setError(true);
				    errorMsg.setMessage(disReqStatus);
					log.error(e.getMessage(),e);
				}
			}
			statusResponseLst.add(errorMsg);
		}

		return statusResponseLst;
	}

	
	/**
	 * @param recs
	 * @param userId
	 * @return ErrorMessageVO List
	 * @Description Revert Pending Cancel Record
	 */
	private List<ErrorMessageVO> undoPendingCancelRecord(List<TransactionListVO> recs,String userId)
	{
		List<ErrorMessageVO> statusResponseLst = new ArrayList<ErrorMessageVO>();
		for (TransactionListVO t : recs) {
			String disReqStatus = "";
			boolean isvalid = true;
			String discountStatus = t.getDiscStatus();
			ErrorMessageVO errorMsg = new ErrorMessageVO();

			 if(!StatusConstants.CANCEL_PENDING_FOR_APPROVAL.equals(discountStatus)){
				    disReqStatus = resourceManager.getMessage(ErrorConstants.UNDO_ERROR_MSG);
					errorMsg.setUniqueID(t.getDiscRefNo());
				    errorMsg.setError(true);
				    errorMsg.setMessage(disReqStatus);
					isvalid = false;
				  }else if(userId !=  null && !userId.equals(t.getMakerId())){
				    disReqStatus = resourceManager.getMessage(ErrorConstants.MAKER_CHECK_UNDO);
					errorMsg.setUniqueID(t.getDiscRefNo());
				    errorMsg.setError(true);
				    errorMsg.setMessage(disReqStatus);
					isvalid = false;
				  }
			if(isvalid)
			{
				try {
					discountRequestService.undoCancelPendingRequest(t.getDiscRefNo());
					disReqStatus = resourceManager.getMessage(ErrorConstants.UNDO_SUCCESS);
					errorMsg.setUniqueID(t.getDiscRefNo());
				    errorMsg.setError(false);
				    errorMsg.setMessage(disReqStatus);
				} catch (BNPApplicationException e) {
					log.error(e.getMessage(),e);
					disReqStatus = resourceManager.getMessage(ErrorConstants.REJECT_FAILURE);
					errorMsg.setUniqueID(t.getDiscRefNo());
				    errorMsg.setError(true);
				    errorMsg.setMessage(disReqStatus);
				}
			}
			statusResponseLst.add(errorMsg);
		}

		return statusResponseLst;
	}


	 // Added for User Stories S148(Buyer Acceptance) by Rohit
		/**
		 * @param transactionListVO
		 * @param userVo
		 * @return ApproveResponseVo
		 * @throws BNPApplicationException
		 * @see com.bnp.bnpux.service.ITransactionService#acceptBuyerAcceptanceDetails(java.util.List, com.bnp.bnpux.common.vo.UserInfoVO)
		 * @Description Accept Buyer Acceptance Details
		 */
		public ApproveResponseVo acceptBuyerAcceptanceDetails(List<TransactionListVO> transactionListVO, UserInfoVO userVo) throws BNPApplicationException{
			ApproveResponseVo approveResponseVo = null;
			//discVOList.add(transactionDAO.getDiscountRequestVOBuyerAcceptance(transactionListVO));
			List<DiscountRequestVO> discVOList = transactionDAO.getDiscountRequestVO(transactionListVO);
			try {
				approveResponseVo = discountApproveSummaryService.accept(discVOList, userVo);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				log.error(e.getMessage(),e);
			}
			return approveResponseVo;
		}


		/**
		 * @param transactionReqVO
		 * @return TransactionResponseVO
		 * @throws BNPApplicationException
		 * @see com.bnp.bnpux.service.ITransactionService#getTransactionCallOutInfo(com.bnp.bnpux.vo.requestVO.TransactionRequestVO)
		 * @Description Get Transaction CallOut Information
		 */
		@Override
		public TransactionResponseVO getTransactionCallOutInfo(TransactionRequestVO transactionReqVO) throws BNPApplicationException {
			TransactionResponseVO transactionResponseVO = new TransactionResponseVO();
			String errorMsg = null;
			try{
				if(TransactionConstants.VIEW_TYPE_TRANSACTION_CHARGE_AMT.equals(transactionReqVO.getViewType())){
					List<TransactionChargeAmtVO> chargeAmountVOList = new ArrayList<TransactionChargeAmtVO>();
					Map<String,Object> paramMap = new HashMap<String, Object>();
					paramMap.put(TransactionConstants.PARAM_PAYMENT_REF_NO, transactionReqVO.getPaymentRefNo());
					paramMap.put(TransactionConstants.PARAM_USER_ID,transactionReqVO.getUserId());
					paramMap.put(TransactionConstants.PARAM_REC_TYPE, transactionReqVO.getRecType());
					transactionDAO.getTransactionChargeAmtInfo(paramMap);
					chargeAmountVOList = (List<TransactionChargeAmtVO>)paramMap.get(TransactionConstants.PARAM_TRANSACTION_CHARGE_AMOUNT);
					if(chargeAmountVOList != null && chargeAmountVOList.size() > 0){
						transactionResponseVO.setTransactionChargeAmtVOList(chargeAmountVOList);
					}else{
						errorMsg = (String)paramMap.get(TransactionConstants.PARAM_ERROR_MESSAGE);
						transactionResponseVO.setErrorFlag(errorMsg);
					}

				}else if(TransactionConstants.VIEW_TYPE_TRANSACTION_CONFIRMED_PYMNT_AMT.equals(transactionReqVO.getViewType())){
					List<TransactionConfimedAmtVO> confirmedAmountVO = new ArrayList<TransactionConfimedAmtVO>();
					Map<String,Object> paramMap = new HashMap<String, Object>();
					paramMap.put(TransactionConstants.PARAM_PAYMENT_REF_NO, transactionReqVO.getPaymentRefNo());
					paramMap.put(TransactionConstants.PARAM_REC_TYPE, transactionReqVO.getRecType());
					transactionDAO.getTransactionConfirmedAmtInfo(paramMap);
					confirmedAmountVO = (List<TransactionConfimedAmtVO>)paramMap.get(TransactionConstants.PARAM_TRANSACTION_CONFIRMED_PYMNT_AMOUNT);

					if(confirmedAmountVO != null && confirmedAmountVO.size() > 0){
						transactionResponseVO.setTransactionConfirmedAmtVO(confirmedAmountVO.get(0));
					}else{
						errorMsg = (String)paramMap.get(TransactionConstants.PARAM_ERROR_MESSAGE);
						transactionResponseVO.setErrorFlag(errorMsg);
					}

				}
			}catch(DataAccessException dataAccessException){
				log.error(TransactionConstants.EXCEPTION_TRANSACTION_INFORMATION);
				throw new BNPApplicationException(TransactionConstants.EXCEPTION_TRANSACTION_INFORMATION);
			}
			return transactionResponseVO;
		}
		
		// Added for CSC-5697 - to fix the multiple error message while concurrent users
		/**
		 * @param uniqueID
		 * @param message
		 * @param error
		 * @return ErrorMessageVO
		 * @Description Send Error Message / Approved Message
		 */
		private ErrorMessageVO addActionPopupApproveMessages(String uniqueID, String message, boolean error){
			 ErrorMessageVO objErrorMessageVO  = new ErrorMessageVO();
		     objErrorMessageVO.setUniqueID(uniqueID);
		     objErrorMessageVO.setMessage(message);
		     objErrorMessageVO.setError(error);
		     return objErrorMessageVO;
			
		}	
		// Added for CSC-5697 - changes ends
		
		/**
		 * @param transactionReqVO
		 * @return TransactionResponseVO
		 * @throws BNPApplicationException
		 * @see com.bnp.bnpux.service.ITransactionService#getDiscountPopupDetails(com.bnp.bnpux.vo.requestVO.TransactionRequestVO)
		 * @Description Service Method for getting Discount Popup Details - S271, S273, S274, S275, S276, S277
		 */
		@Override
	public TransactionRequestVO getDiscountPopupDetails(TransactionRequestVO transactionReqVO)
			throws BNPApplicationException {

			log.debug("TransactionServiceImpl:: Enter getDiscountPopupDetails");
		OrganizationVO organizationVO;
		String errorFlag;
		try {
			log.debug("TransactionServiceImpl:: Calling DAO getDiscountPopupDetails");

			transactionDAO.getDiscountPopupDetails(transactionReqVO);

			log.debug("TransactionServiceImpl:: Setting Data getDiscountPopupDetails - Start");

			if (transactionReqVO.getDiscountDetailsUxVOList() != null && !transactionReqVO.getDiscountDetailsUxVOList().isEmpty()) {

				transactionReqVO.setDiscountDetailsUxVO(transactionReqVO.getDiscountDetailsUxVOList().get(0));

			} else {
				errorFlag = transactionReqVO.getErrorFlag();
				if (errorFlag != null) {
					log.error(TransactionConstants.TXN_UNABLE_TO_GET_DETAILS + errorFlag);
				}
			}
			
			organizationVO = transactionReqVO.getOrganizationVOList().get(0);
			
			if(organizationVO != null){
				
				log.debug("TransactionServiceImpl:: Getting buyer org logo");

				OrganizationVO org = iLoginDAO.getOrgLogo(transactionReqVO.getBuyerOrgId());
	
				if (org != null) {
					organizationVO.setBuyerlogoFileType(org.getLogoFileType());
					organizationVO.setBuyerOrgLogo(org.getOrgLogo());
				}
				
				log.debug("TransactionServiceImpl:: Getting Supplier org logo");
	
				org = iLoginDAO.getOrgLogo(transactionReqVO.getSupplierOrgId());
	
				if (org != null) {
					organizationVO.setSupplierlogoFileType(org.getLogoFileType());
					organizationVO.setSupplierOrgLogo(org.getOrgLogo());
				}
				
				log.debug("TransactionServiceImpl:: Setting org logo in org vo");
	
				transactionReqVO.setOrganizationVO(organizationVO);
			}

			log.debug("TransactionServiceImpl:: Setting Data getDiscountPopupDetails - End");

		} catch (DataAccessException dataAccessException) {
			log.error(TransactionConstants.EXCEPTION_TRANSACTION_INFORMATION, dataAccessException);
			throw new BNPApplicationException(TransactionConstants.EXCEPTION_TRANSACTION_INFORMATION);
		}

		log.debug("TransactionServiceImpl:: Exit getDiscountPopupDetails");
		return transactionReqVO;
	}
		
	@Override
	public CommitmentFeeUxVO fetchDebitNoteRef(TransactionRequestVO transactionReqVO) throws BNPApplicationException 
	{
		return transactionDAO.fetchDebitNoteRef(transactionReqVO);
	}

}

