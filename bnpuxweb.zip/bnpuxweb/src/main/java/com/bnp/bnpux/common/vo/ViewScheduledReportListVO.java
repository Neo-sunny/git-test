package com.bnp.bnpux.common.vo;

import java.util.Date;

public class ViewScheduledReportListVO {
	
	private String generatedReportId;
	private String reportScheduleId;
	private String report;
	private String reportFileName;
	private String reportOrgId;
	private String frequency;
	private String lastGenerated;
	private String lastViewedBy;
	private byte[] reportData;
	private String reportFormat;
	private String attachmentName;
	private String recordcount;
	private String recoredNo;
	private String lastViewed;
	/**
	 * @return the generatedReportId
	 */
	public String getGeneratedReportId() {
		return generatedReportId;
	}
	/**
	 * @param generatedReportId the generatedReportId to set
	 */
	public void setGeneratedReportId(String generatedReportId) {
		this.generatedReportId = generatedReportId;
	}
	/**
	 * @return the reportScheduleId
	 */
	public String getReportScheduleId() {
		return reportScheduleId;
	}
	/**
	 * @param reportScheduleId the reportScheduleId to set
	 */
	public void setReportScheduleId(String reportScheduleId) {
		this.reportScheduleId = reportScheduleId;
	}
	/**
	 * @return the report
	 */
	public String getReport() {
		return report;
	}
	/**
	 * @param report the report to set
	 */
	public void setReport(String report) {
		this.report = report;
	}
	/**
	 * @return the reportFileName
	 */
	public String getReportFileName() {
		return reportFileName;
	}
	/**
	 * @param reportFileName the reportFileName to set
	 */
	public void setReportFileName(String reportFileName) {
		this.reportFileName = reportFileName;
	}
	/**
	 * @return the reportOrgId
	 */
	public String getReportOrgId() {
		return reportOrgId;
	}
	/**
	 * @param reportOrgId the reportOrgId to set
	 */
	public void setReportOrgId(String reportOrgId) {
		this.reportOrgId = reportOrgId;
	}
	/**
	 * @return the frequency
	 */
	public String getFrequency() {
		return frequency;
	}
	/**
	 * @param frequency the frequency to set
	 */
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	/**
	 * @return the lastGenerated
	 */
	public String getLastGenerated() {
		return lastGenerated;
	}
	/**
	 * @param lastGenerated the lastGenerated to set
	 */
	public void setLastGenerated(String lastGenerated) {
		this.lastGenerated = lastGenerated;
	}

	/**
	 * @return the lastViewedBy
	 */
	public String getLastViewedBy() {
		return lastViewedBy;
	}
	/**
	 * @param lastViewedBy the lastViewedBy to set
	 */
	public void setLastViewedBy(String lastViewedBy) {
		this.lastViewedBy = lastViewedBy;
	}
	/**
	 * @return the reportData
	 */
	public byte[] getReportData() {
		return reportData;
	}
	/**
	 * @param reportData the reportData to set
	 */
	public void setReportData(byte[] reportData) {
		this.reportData = reportData;
	}
	/**
	 * @return the reportFormat
	 */
	public String getReportFormat() {
		return reportFormat;
	}
	/**
	 * @param reportFormat the reportFormat to set
	 */
	public void setReportFormat(String reportFormat) {
		this.reportFormat = reportFormat;
	}
	/**
	 * @return the attachmentName
	 */
	public String getAttachmentName() {
		return attachmentName;
	}
	/**
	 * @param attachmentName the attachmentName to set
	 */
	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}
	/**
	 * @return the recordcount
	 */
	public String getRecordcount() {
		return recordcount;
	}
	/**
	 * @param recordcount the recordcount to set
	 */
	public void setRecordcount(String recordcount) {
		this.recordcount = recordcount;
	}
	/**
	 * @return the recoredNo
	 */
	public String getRecoredNo() {
		return recoredNo;
	}
	/**
	 * @param recoredNo the recoredNo to set
	 */
	public void setRecoredNo(String recoredNo) {
		this.recoredNo = recoredNo;
	}
	/**
	 * @return the lastViewed
	 */
	public String getLastViewed() {
		return lastViewed;
	}
	/**
	 * @param lastViewed the lastViewed to set
	 */
	public void setLastViewed(String lastViewed) {
		this.lastViewed = lastViewed;
	}
	
}
