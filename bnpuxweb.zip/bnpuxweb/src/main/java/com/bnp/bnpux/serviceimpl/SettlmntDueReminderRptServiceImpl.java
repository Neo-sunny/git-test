package com.bnp.bnpux.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.constants.ReportsConstant;
import com.bnp.bnpux.constants.SettlmntDueReminderConstants;
import com.bnp.bnpux.dao.ISettlmntDueReminderRptDAO;
import com.bnp.bnpux.service.ISettlmntDueReminderRptService;
import com.bnp.bnpux.vo.requestVO.SettlmntDueReminderRptRequestVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;
import com.bnp.bnpux.vo.responseVO.SettlmntDueReminderRptResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@Component
public class SettlmntDueReminderRptServiceImpl implements ISettlmntDueReminderRptService {
	
	@Autowired
	ISettlmntDueReminderRptDAO settlmntDueReminderRptDAO;
	
	/**
	 * Logger log for SettlmntDueReminderRptServiceImpl class
	 */
	private static final Logger log = LoggerFactory.getLogger(SettlmntDueReminderRptServiceImpl.class);
	
	/**
	 * Constant for Exception message
	 */
	public static final String EXCEPTION_UNABLE_TO_PROCESS = "Unable to process action - Database Exception";
	
	/**
	 * This service implementation method is used to fetch latest Settlement Due Reminder Report list
	 * 
	 * @param SettlmntDueReminderRptRequestVO 
	 * @return SettlmntDueReminderRptResponseVO
	 */
	public SettlmntDueReminderRptResponseVO getSettlmntReportList(SettlmntDueReminderRptRequestVO settlmntDueReminderRptRequestVO) throws BNPApplicationException {
		SettlmntDueReminderRptResponseVO settlmntDueReminderRptResponseVO =null;
		try{
			settlmntDueReminderRptResponseVO = new SettlmntDueReminderRptResponseVO();
			
			if(SettlmntDueReminderConstants.SETTLEMENT_DUE_RMDR_LIST.equalsIgnoreCase(settlmntDueReminderRptRequestVO.getViewType())) {
				settlmntDueReminderRptDAO.getSettlmntDueReminder(settlmntDueReminderRptRequestVO);
				if(settlmntDueReminderRptRequestVO.getSettlmntDueReminder() != null) {
					settlmntDueReminderRptResponseVO.setSettlmntDueReminderList(settlmntDueReminderRptRequestVO.getSettlmntDueReminder());
				}
			}else if(SettlmntDueReminderConstants.SETTLEMENT_DUE_RMDR_LIST_DETAILS.equalsIgnoreCase(settlmntDueReminderRptRequestVO.getViewType())) {
				settlmntDueReminderRptDAO.getSettlmntDueReminderDetails(settlmntDueReminderRptRequestVO);
				if(settlmntDueReminderRptRequestVO.getSettlmntDueReminderDetails() != null) {
					settlmntDueReminderRptResponseVO.setSettlmntDueReminderDetailsList(settlmntDueReminderRptRequestVO.getSettlmntDueReminderDetails());
				}
			
			if(settlmntDueReminderRptRequestVO.getErrorMsg() != null){				
				log.error(EXCEPTION_UNABLE_TO_PROCESS + settlmntDueReminderRptRequestVO.getErrorMsg());
			 }
		   }
		 } catch(Exception exception) {
			log.error(EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(EXCEPTION_UNABLE_TO_PROCESS);	
		}
		return settlmntDueReminderRptResponseVO;
	}
	
	/**
	 * This method is for getting report chart axis 
	 * 
	 * @param requestVo
	 * @return
	 * @throws BNPApplicationException
	 */
	public List<ReportChartResponseVO> getReportChartAxis (SettlmntDueReminderRptRequestVO settlmntDueReminderRptRequestVO)throws BNPApplicationException {
		List<ReportChartResponseVO> reportVOList = new ArrayList<ReportChartResponseVO>();
		try{
			
			settlmntDueReminderRptDAO.getChartAxis(settlmntDueReminderRptRequestVO);
		reportVOList = (List<ReportChartResponseVO>) settlmntDueReminderRptRequestVO.getReportChartList();
		/*if(reportVOList != null){
			settlementResponseVO.setSettlementListVO(settlementVOList);
		}*/	
		}catch(Exception exception){
			log.error(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS);
		}
		return reportVOList;
   }	
}
