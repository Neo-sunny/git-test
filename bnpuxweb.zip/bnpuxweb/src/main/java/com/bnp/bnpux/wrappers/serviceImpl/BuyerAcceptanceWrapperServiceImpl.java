/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 March 2017
 * 
 * Purpose:      Release File Functionality
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
* 24 April 2017         Oracle Financial Services Software Ltd                  Initial Version 
* 24 April 2017			Oracle Financial Services Software Ltd					Release 1.1 I2			Copied from Old UX	
* 27 March 2017			Oracle Financial Services Software Ltd					Release 1.1 I2			Updated undo Buyer Acceptance functionality for New UX
* 8 August 2017			Oracle Financial Services Software Ltd					Release 1.1 I2			R10.0 US 131305- BA concurrency Accept/Reject/Approve
**********************************************************************************************************************/
package com.bnp.bnpux.wrappers.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.util.CommonUtil;
import com.bnp.bnpux.vo.responseVO.BuyerAcceptanceResponseVO;
import com.bnp.bnpux.wrappers.service.IBuyerAcceptanceWrapperService;
import com.bnp.scm.common.IResourceManager;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.BNPReloadableResourceBundleMessageSource;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.ScreenConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.discounting.IDiscountProcessService;
import com.bnp.scm.services.invoice.IBuyerAcceptanceService;
import com.bnp.scm.services.invoice.vo.BuyerAcceptanceVO;

@Component
@Scope("request")
public class BuyerAcceptanceWrapperServiceImpl implements IBuyerAcceptanceWrapperService{

	private static Logger LOGGER =LoggerFactory.getLogger(BuyerAcceptanceWrapperServiceImpl.class);

	@Autowired
	private IBuyerAcceptanceService buyerAcceptanceService;
	@Autowired
	private IDiscountProcessService discPymtService;
	@Autowired
	protected IResourceManager resourceManager;
	
	@Autowired
	protected BNPPropertyLoaderConfigurer propertyLoader;
	
	
	@Autowired
	protected BNPReloadableResourceBundleMessageSource resourceBundle;
	
	@Autowired
	protected CommonUtil commonUtil;

	@Override
	public BuyerAcceptanceResponseVO acceptInvoice(List<BuyerAcceptanceVO> detailsVOList, UserInfoVO user, BuyerAcceptanceResponseVO baActionsResponseVO) {
		LOGGER.debug("BuyerAcceptanceWrapperServiceImpl  acceptInvoice  - Start");
		String message = null;
		boolean isError = true;
		List<BuyerAcceptanceVO> validList = null;
		List<BuyerAcceptanceVO> validBAList = null;	
		
			
			validList= getValidRecordsForAction(StatusConstants.BUTTON_ACCEPT,detailsVOList,user ,baActionsResponseVO);
			if(!validList.isEmpty()){
				
						
				 for(BuyerAcceptanceVO baVO : validList){
					 validBAList = new ArrayList<BuyerAcceptanceVO>();
					 try {
					 	int errorCode = buyerAcceptanceService.checkAndLockRecordForProcessing(baVO);												
						if (errorCode <= 0 ){
							validBAList.add(baVO);
							buyerAcceptanceService.updateStatus(validBAList,StatusConstants.BUTTON_ACCEPT,user.getUserId());
							buyerAcceptanceService.updateStatusForLocking(String.valueOf(baVO.getInvoiceId()), BNPConstants.NO);
							message = resourceManager.getMessage(ErrorConstants.INVOICE_ACCEPTENCE_SUCCESS);
							isError = false;
						}else{
							message = resourceManager.getMessage(errorCode);
							
						}
				        				        
				 }  catch (BNPApplicationException e) {			
						message = resourceManager.getMessage(ErrorConstants.ERROR_ACCEPT_BUYER_ACCEPTANCE);
						LOGGER.error("BNPApplicationException in acceptInvoice : "+message);
						
					}
					 commonUtil.addBAResponseVO(baVO.getInvRefNo(), message, isError, baActionsResponseVO);
					 
			}
			}
		
		LOGGER.debug("BuyerAcceptanceWrapperServiceImpl  acceptInvoice  - End");
		return baActionsResponseVO;
}

	/* (non-Javadoc)
	 * @see com.bnp.bnpux.buyerAcceptance.service.IBuyerAcceptanceWrapperService#undoInvoice(java.util.List, com.bnp.bnpux.common.vo.UserInfoVO)
	 */
	@Override
	public BuyerAcceptanceResponseVO undoInvoice(List<BuyerAcceptanceVO> detailsVOList, UserInfoVO user, BuyerAcceptanceResponseVO baActionsResponseVO) {	
		LOGGER.debug("BuyerAcceptanceWrapperServiceImpl  undoInvoice  - Start");
		String message = null;
		boolean isError = true;
		List<BuyerAcceptanceVO> validList = null;
		List<BuyerAcceptanceVO> validBAList = null;
		
			validList= getValidRecordsForAction(StatusConstants.BUTTON_UNDO,detailsVOList,user ,baActionsResponseVO);
			if(!validList.isEmpty()){
					
				 for(BuyerAcceptanceVO baVO : validList){
				validBAList = new ArrayList<BuyerAcceptanceVO>();
				 try {
					 int errorCode = buyerAcceptanceService.checkAndLockRecordForProcessing(baVO);												
						if (errorCode <= 0 ){
							validBAList.add(baVO);					
							buyerAcceptanceService.updateStatus(validBAList,StatusConstants.BUTTON_UNDO,user.getUserId());	
							buyerAcceptanceService.updateStatusForLocking(String.valueOf(baVO.getInvoiceId()), BNPConstants.NO);
							message = resourceManager.getMessage(ErrorConstants.RECORD_UNDONE_SUCCESSFULLY);
							isError = false;
						}else{
							message = resourceManager.getMessage(errorCode);
						}						
				 }catch (BNPApplicationException e) {			
						message = resourceManager.getMessage(ErrorConstants.ERROR_UNDO_BUYER_ACCEPTANCE);
						LOGGER.error("BNPApplicationException in undoInvoice : "+message);
						
					}
				  commonUtil.addBAResponseVO(baVO.getInvRefNo(), message, isError, baActionsResponseVO);
				}
		} 
		LOGGER.debug("BuyerAcceptanceWrapperServiceImpl  undoInvoice  - End");
		return baActionsResponseVO;
}
	/**
	 * @param validList
	 * @param baActionsResponseVO
	 * @param b
	 * @param message
	 */
	@Override
	public BuyerAcceptanceResponseVO rejectInvoice(List<BuyerAcceptanceVO> detailsVOList, UserInfoVO user, BuyerAcceptanceResponseVO baActionsResponseVO) {
		LOGGER.debug("BuyerAcceptanceWrapperServiceImpl  rejectInvoice  - Start");
		String message = null;
		boolean isError = true;
		List<BuyerAcceptanceVO> validList = null;
		List<BuyerAcceptanceVO> validBAList = null;
			validList= getValidRecordsForAction(StatusConstants.BUTTON_REJECT,detailsVOList,user ,baActionsResponseVO);
			if(!validList.isEmpty()){
				 		
				
				 for(BuyerAcceptanceVO baVO : validList){
					 validBAList = new ArrayList<BuyerAcceptanceVO>();
				 try {
					 int errorCode = buyerAcceptanceService.checkAndLockRecordForProcessing(baVO);												
						if (errorCode <= 0 ){
							validBAList.add(baVO);
							buyerAcceptanceService.updateStatus(validBAList,StatusConstants.BUTTON_REJECT,user.getUserId());
							buyerAcceptanceService.updateStatusForLocking(String.valueOf(baVO.getInvoiceId()), BNPConstants.NO);
							message = resourceManager.getMessage(ErrorConstants.INVOICE_REJECTION_SUCCESS);
							isError = false;
						}else{
							message = resourceManager.getMessage(errorCode);
						}						
				 		
				 } catch (BNPApplicationException e) {			
						message = resourceManager.getMessage(ErrorConstants.ERROR_REJECT_BUYER_ACCEPTANCE);
						LOGGER.error("BNPApplicationException in rejectInvoice : "+message);
						
					}
				 commonUtil.addBAResponseVO(baVO.getInvRefNo(), message, isError, baActionsResponseVO);
				}
			}
		
		LOGGER.debug("BuyerAcceptanceWrapperServiceImpl  rejectInvoice  - End");
		return baActionsResponseVO;
	}

	@Override
	public BuyerAcceptanceResponseVO approveInvoice(List<BuyerAcceptanceVO> detailsVOList, UserInfoVO user, BuyerAcceptanceResponseVO baActionsResponseVO) {
		LOGGER.debug("BuyerAcceptanceWrapperServiceImpl  rejectInvoice  - Start");
		String message = null;
		boolean isError = true;
		List<BuyerAcceptanceVO> validList = null;
		List<BuyerAcceptanceVO> validBAList = null;
			
			validList= getValidRecordsForAction(StatusConstants.BUTTON_APPROVE,detailsVOList,user ,baActionsResponseVO);
			if(!validList.isEmpty()){
				
				 
				 for(BuyerAcceptanceVO baVO : validList){
					 validBAList = new ArrayList<BuyerAcceptanceVO>();
						try {
					 	int errorCode = buyerAcceptanceService.checkAndLockRecordForProcessing(baVO);												
						if (errorCode <= 0 ){
							 validBAList.add(baVO);
							 buyerAcceptanceService.updateStatus(validBAList,StatusConstants.BUTTON_APPROVE,user.getUserId());							 
							 discPymtService.raiseDiscountBuyerAcceptance(validBAList);
							 buyerAcceptanceService.updateStatusForLocking(String.valueOf(baVO.getInvoiceId()), BNPConstants.NO);
							 message = resourceManager.getMessage(ErrorConstants.DATA_COMMON_APPROVE);	
							 isError = false;				
						}else{
							message = resourceManager.getMessage(errorCode);
						}				 				
						} catch (BNPApplicationException e) {			
							message = resourceManager.getMessage(e.errorCode);
							if(message == null || message.equals("")){
								message = resourceManager.getMessage(ErrorConstants.ERROR_APPROVE_BUYER_ACCEPTANCE);
							}
							LOGGER.error("BNPApplicationException in approveInvoice : "+message);		
							
							
						}
						commonUtil.addBAResponseVO(baVO.getInvRefNo(), message, isError, baActionsResponseVO);
				 }		
				 
					
			}
	
		LOGGER.debug("BuyerAcceptanceWrapperServiceImpl  rejectInvoice  - End");
		return baActionsResponseVO;
	}
	public List<BuyerAcceptanceVO> getValidRecordsForAction(String action, List<BuyerAcceptanceVO> buyerAcceptanceVOList, UserInfoVO user, BuyerAcceptanceResponseVO baActionsResponseVO){
		final List<BuyerAcceptanceVO> validList=new ArrayList<BuyerAcceptanceVO>();
			
		int statusCode = 0;
		
		for(BuyerAcceptanceVO buyerAcceptanceVO:buyerAcceptanceVOList){
			if(action.equals(StatusConstants.BUTTON_ACCEPT) || action.equals(StatusConstants.BUTTON_REJECT)) 
			{
				statusCode=buyerAcceptanceVO.canSaveData();
			}
			if(action.equals(StatusConstants.BUTTON_APPROVE))
			{
				
				statusCode=buyerAcceptanceVO.canApproveRecord(user.getUserId());
			}
			else if(action.equals(StatusConstants.BUTTON_UNDO))
			{
				statusCode=buyerAcceptanceVO.canUndoRecord();
			}
			if(statusCode >0)
			{
				commonUtil.addBAResponseVO(buyerAcceptanceVO.getInvRefNo() , resourceManager.getMessage(statusCode) , true , baActionsResponseVO);
			}
			else if(checkForValidRecord(buyerAcceptanceVO,action)){				
				buyerAcceptanceVO.setSessionId(user.getSessionId());
				buyerAcceptanceVO.setCurrentUserId(user.getUserId());
				buyerAcceptanceVO.setScreenId(ScreenConstants.BUYERACCEPTANCE);
				validList.add(buyerAcceptanceVO);
			}
		}
		return validList;
	}
   public boolean checkForValidRecord(BuyerAcceptanceVO acceptanceVO,String action){
		String userId = null;
		if((action.equals(StatusConstants.BUTTON_ACCEPT) || action.equals(StatusConstants.BUTTON_REJECT)) && (acceptanceVO.getCtrlStatus().equals(StatusConstants.BUTTON_NEW))){
			if(action.equals(StatusConstants.BUTTON_ACCEPT))
			{
				acceptanceVO.setCheckPoint(StatusConstants.ACCESSLOG_ACCEPT_NEW);
			}
			else
			{
				acceptanceVO.setCheckPoint(StatusConstants.ACCESSLOG_REJECT_NEW);
			}
			return true;		
		}else if(action.equals(StatusConstants.BUTTON_UNDO) && acceptanceVO.getCtrlStatus().equals(StatusConstants.DISCOUNT_PENDING_APPROVAL) ){
			acceptanceVO.setCheckPoint(StatusConstants.ACCESSLOG_UNDO_MODIFICATION);
			return true;	
		}else if(action.equals(StatusConstants.BUTTON_APPROVE)&& acceptanceVO.getCtrlStatus().equals(StatusConstants.DISCOUNT_PENDING_APPROVAL) && !(acceptanceVO.getMakerId().equals(userId))){
			acceptanceVO.setCheckPoint(StatusConstants.ACCESSLOG_APPROVE_MODIFICATION);
			return true;
		}
		return false;
	}
		
}