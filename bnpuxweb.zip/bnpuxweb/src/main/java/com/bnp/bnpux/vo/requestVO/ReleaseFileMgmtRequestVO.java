/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 March 2017
 * 
 * Purpose:      Release File Functionality
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 March 2017            Oracle Financial Services Software Ltd                  Initial Version 
 * 27 March 2017            Bhuvaneswari                                            S2034 File managementUndo action 
 *  *  *************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.requestVO;

import java.io.Serializable;
import java.util.List;

import com.bnp.bnpux.common.vo.FileMgmtListVO;

public class ReleaseFileMgmtRequestVO implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * fileListVO
	 */
	private  List<FileMgmtListVO> fileListVO;
	

	/**
	 * userId
	 */
	private String userId;
	
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the fileListVO
	 */
	public List<FileMgmtListVO> getFileListVO() {
		return fileListVO;
	}
	/**
	 * @param fileListVO the fileListVO to set
	 */
	public void setFileListVO(List<FileMgmtListVO> fileListVO) {
		this.fileListVO = fileListVO;
	}
	

}
