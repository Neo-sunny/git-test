/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Transaction Controller
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 21 Feb 2017				Sathishkumar B										FO 10.0 - S008, S009, S010, S011, S012, S013, S014
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.common.vo.ApproveRequestVo;
import com.bnp.bnpux.common.vo.ApproveResponseGridVo;
import com.bnp.bnpux.common.vo.ApproveResponseVo;
import com.bnp.bnpux.common.vo.BuyerAcceptanceDetailsVO;
import com.bnp.bnpux.common.vo.CancelRequestVo;
import com.bnp.bnpux.common.vo.CommitmentFeeUxVO;
import com.bnp.bnpux.common.vo.TransactionListVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.constants.TransactionConstants;
import com.bnp.bnpux.service.IAuditService;
import com.bnp.bnpux.service.ITransactionService;
import com.bnp.bnpux.util.RequestIdentityValidator;
import com.bnp.bnpux.vo.errorMessageVO.ErrorMessageVO;
import com.bnp.bnpux.vo.requestVO.AuditRequestVO;
import com.bnp.bnpux.vo.requestVO.TransactionRequestVO;
import com.bnp.bnpux.vo.responseVO.TransactionResponseVO;
import com.bnp.scm.services.admin.vo.AuditTrailVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.discounting.vo.DiscountRequestVO;

@RestController
@RequestMapping("/transactionCtrl")
public class TransactionController {
	
	/**
	 * Logger log for TransactionController class
	 */
	public static final Logger log = LoggerFactory.getLogger(TransactionController.class);
	
	/**
	 * ITransactionService transactionService;
	 */
	@Autowired
	private ITransactionService transactionService;
	
	@Autowired
	private IAuditService auditService;
	
	@Autowired
	RequestIdentityValidator validateRequest;
	/**
	 * This method is for getting the Transaction details
	 * 
	 * @param transactionReqVO
	 * @param request
	 * @return
	 */
	@RequestMapping(value="getTransactionInfo.rest",method = RequestMethod.POST)
	public TransactionResponseVO getTransactionInfo(@RequestBody TransactionRequestVO transactionReqVO,HttpServletRequest request,HttpServletResponse response){		
		TransactionResponseVO transactionVO = new TransactionResponseVO();
		
		try{
			boolean requestValidatedFlag = validateRequest.validate(transactionReqVO.getUserId(),request.getSession());
			if(requestValidatedFlag){
				transactionVO = transactionService.getTransactionInfo(transactionReqVO);
			}
			else{
				transactionVO = null;
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		}catch(BNPApplicationException exception){
			transactionVO.setErrorMsg(exception.getMessage());
			log.error(exception.getMessage(),exception);
		}
		return transactionVO;		
	}
	
	@RequestMapping(value = "getAdvancedFilterIndicatorCount.rest", method = RequestMethod.POST)
	public TransactionResponseVO getAdvancedFilterIndicatorCount(@RequestBody TransactionRequestVO transactionReqVO,HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		TransactionResponseVO transactionVO = null;
		try {
			boolean requestValidatedFlag = validateRequest.validate(transactionReqVO.getUserId(),httpServletRequest.getSession());
			if(requestValidatedFlag){
				transactionVO = new TransactionResponseVO();
				transactionVO = transactionService.getAdvancedFilterCount(transactionReqVO);
			}
			else{
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (BNPApplicationException exception) {
			transactionVO.setErrorMsg(exception.getMessage());
			log.error(exception.getMessage(),exception);
		}
		return transactionVO;
	}
	
	
	/**
	 * This method is for Approving the Discount Request details
	 * 
	 * @param apprvReqVo
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value ="discRequestApprovalDetails.rest", method = RequestMethod.POST)
		public ApproveResponseVo approveDiscountRequestDetails(@RequestBody ApproveRequestVo apprvReqVo,HttpServletRequest request,HttpServletResponse response) throws BNPApplicationException {
		ApproveResponseVo approveResponseVo= new ApproveResponseVo();
		HttpSession session = request.getSession();
		
		try {
			boolean requestValidatedFlag = validateRequest.validate(apprvReqVo.getTransReqVO().getUserId(),session);
			if(requestValidatedFlag){
				UserInfoVO userVo = apprvReqVo.getTransReqVO();
				userVo.setSessionId((String) session.getAttribute("USER_AUTH_TOKEN"));
				List<TransactionListVO> transactionListVO = apprvReqVo.getTransListVO();
				approveResponseVo = transactionService.approveDiscountRequest(transactionListVO,userVo);
				//Added below session attributes for fortify fix - Do not maintain sigleton object
				if(approveResponseVo.getCutOffValidationVO() != null){
					session.setAttribute("TEMP_REQUEST_DISCVO", approveResponseVo.getTempDiscReqVO());
					session.setAttribute("TEMP_GRIDLIST_VO", approveResponseVo.getapproveGridListVO());
				}
				AuditRequestVO auditVo = new AuditRequestVO();
				auditVo.setUserId(userVo.getUserId());
				auditVo.setSessionId(userVo.getSessionId());
				auditVo.setFuncId(TransactionConstants.APPROVE_DISCOUNT);
				auditVo.setOrgId(userVo.getOrgId());
				auditService.insertAuditLog(auditVo);
			}
			else{
				approveResponseVo = null;
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (Exception exception) {
			response.setHeader("isError", "true");			
			log.error(exception.getMessage(),exception);
			throw new BNPApplicationException(); 
		}

		return approveResponseVo;
	}
	
	/**
	 * This method is for Approving the Discount Request details
	 * 
	 * @param apprvReqVo
	 * @param request
	 * @return
	 */
	@RequestMapping(value ="discRequestProceedApprovalDetails.rest", method = RequestMethod.POST)
		public ApproveResponseVo proceedApproveDiscountRequestDetails(@RequestBody ApproveRequestVo apprvReqVo,HttpServletRequest request,HttpServletResponse response) {
		ApproveResponseVo approveResponseVo= new ApproveResponseVo();
		HttpSession session = request.getSession();
		
		try {
			boolean requestValidatedFlag = validateRequest.validate(apprvReqVo.getTransReqVO().getUserId(),session);
			if(requestValidatedFlag){
				UserInfoVO userVo = apprvReqVo.getTransReqVO();
				userVo.setSessionId((String) session.getAttribute("USER_AUTH_TOKEN"));
				List<TransactionListVO> transactionListVO = apprvReqVo.getTransListVO();
				//Added below session attributes for fortify fix - Do not maintain sigleton object
				apprvReqVo.setTempDiscReqVO((DiscountRequestVO) session.getAttribute("TEMP_REQUEST_DISCVO"));
				apprvReqVo.setApprvdResGridListVO( (List<ApproveResponseGridVo>) session.getAttribute("TEMP_GRIDLIST_VO"));
				approveResponseVo = transactionService.proceedApproveDiscountRequest(transactionListVO,userVo,apprvReqVo);
			}
			else{
				approveResponseVo = null;
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (Exception exception) {
			//paymentOrderResponseVO.setErrorMsg(exception.getMessage());
			log.error(exception.getMessage(),exception);
		}finally{
			session.removeAttribute("TEMP_REQUEST_DISCVO");
			session.removeAttribute("TEMP_GRIDLIST_VO");
		}
		return approveResponseVo;
	}
	
	/**
	 * This method is for performing Undo action on Transaction Details
	 * 
	 * @param transListVO
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="undoTrasnactionRecord.rest",method=RequestMethod.POST)
	public @ResponseBody Set<ErrorMessageVO> undoTransactionRecords(@RequestBody ApproveRequestVo apprvReqVo,HttpServletRequest request,HttpServletResponse response) throws BNPApplicationException
	{
		
		HttpSession session = request.getSession();
	    UserInfoVO user = (UserInfoVO) session.getAttribute("userInfo");
		List<ErrorMessageVO> statusResponseLst =  new ArrayList<ErrorMessageVO>();
		Set<ErrorMessageVO> statusResponse = null;
		try {
			boolean requestValidatedFlag = validateRequest.validate(apprvReqVo.getTransReqVO().getUserId(),session);
			if(requestValidatedFlag){
				statusResponseLst =  transactionService.undoTransactionRecord(apprvReqVo.getTransListVO(), user);
				AuditRequestVO auditVo = new AuditRequestVO();
				auditVo.setUserId(user.getUserId());
				// Added changes for CSCDEV - 5697 - starts
				auditVo.setSessionId(session.getAttribute("USER_AUTH_TOKEN")!=null?session.getAttribute("USER_AUTH_TOKEN").toString():null);
				// Added changes for CSCDEV - 5697 - ends
				auditVo.setFuncId(TransactionConstants.UNDO_DISCOUNT);
				auditVo.setOrgId(user.getOrgId());
				auditService.insertAuditLog(auditVo);
				statusResponse = new HashSet<ErrorMessageVO>(statusResponseLst);
			}
			else{
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (Exception exception) {
			response.setHeader("isError", "true");			
			log.error(exception.getMessage(),exception);
			throw new BNPApplicationException(); 
		}
		return statusResponse;
	}
	
	/**
	 * This method is for cancelling the Discount Request details
	 * 
	 * @param canclReqVo
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value ="putCancelDiscountRequest.rest", method = RequestMethod.POST, produces = MediaType.TEXT_PLAIN_VALUE)
	public String cancelDiscountRequest(@RequestBody CancelRequestVo canclReqVo,HttpServletRequest request,HttpServletResponse response) {	
		String ErrorMsg="";
		//TransactionListVO transactionListVO1 = new TransactionListVO();
		DiscountRequestVO discountRequestVO = new DiscountRequestVO();
        HttpSession session = request.getSession();
       // UserInfoVO user = (UserInfoVO) session.getAttribute("userInfo");
		try {
			boolean requestValidatedFlag = validateRequest.validate(canclReqVo.getTransReqVO().getUserId(),session);
			if(requestValidatedFlag){
				UserInfoVO userVo = canclReqVo.getTransReqVO();
				userVo.setSessionId((String) session.getAttribute("USER_AUTH_TOKEN"));
				for(TransactionListVO tlvo : canclReqVo.getTransListVO()){				
					ErrorMsg = transactionService.cancelDiscountRequest(tlvo,userVo);
					AuditRequestVO auditVo = new AuditRequestVO();
					auditVo.setUserId(userVo.getUserId());
					auditVo.setSessionId(userVo.getSessionId());
					auditVo.setFuncId(TransactionConstants.CANCEL_DISCOUNT);
					auditVo.setOrgId(userVo.getOrgId());
					auditService.insertAuditLog(auditVo);
				}
			}
			else{
				ErrorMsg = null;
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (Exception exception) {
			response.setHeader("isError", "true");			
			ErrorMsg = "Discount Request cancel has been failed";
			log.error(exception.getMessage(),exception);
		}
		//ErrorMsg = "Discount Request has been cancelled Successfully";
		return ErrorMsg;
	}
	
	/**
	 * This method is for rejecting Discount Request Details
	 * 
	 * @param apprvReqVo
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value ="discRequestRejectDetails.rest", method = RequestMethod.POST)
		public List<ErrorMessageVO> rejectDiscountRequestDetails(@RequestBody ApproveRequestVo apprvReqVo,HttpServletRequest request,HttpServletResponse response) throws BNPApplicationException {
		List<ErrorMessageVO> ErrorMsg= new ArrayList<ErrorMessageVO>();
		HttpSession session = request.getSession();
		try {
			boolean requestValidatedFlag = validateRequest.validate(apprvReqVo.getTransReqVO().getUserId(),session);
			if(requestValidatedFlag){
				UserInfoVO userVo = apprvReqVo.getTransReqVO();
				List<TransactionListVO> transactionListVO = apprvReqVo.getTransListVO();
				userVo.setSessionId((String) session.getAttribute("USER_AUTH_TOKEN"));
				ErrorMsg = transactionService.rejectDiscountRequest(transactionListVO,userVo);
				AuditRequestVO auditVo = new AuditRequestVO();
				auditVo.setUserId(userVo.getUserId());
				auditVo.setSessionId(userVo.getSessionId());
				auditVo.setFuncId(TransactionConstants.REJECT_DISCOUNT);
				auditVo.setOrgId(userVo.getOrgId());
				auditService.insertAuditLog(auditVo);
			}
			else{
				ErrorMsg = null;
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (Exception exception) {
			response.setHeader("isError", "true");			
			log.error(exception.getMessage(),exception);
			throw new BNPApplicationException(); 
		}		
		return ErrorMsg;
	}
	
	/**
	 * This method is for Approving Discount Request details
	 * 
	 * @param apprvReqVo
	 * @param request
	 * @return
	 */
	@RequestMapping(value ="discRequestReturnApprovalDetails.rest", method = RequestMethod.POST)
		public List<ErrorMessageVO> returnDiscountRequestDetails(@RequestBody ApproveRequestVo apprvReqVo,HttpServletRequest request,HttpServletResponse response) {
		List<ErrorMessageVO> ErrorMsg= new ArrayList<ErrorMessageVO>();
		HttpSession session = request.getSession();
		try {
			boolean requestValidatedFlag = validateRequest.validate(apprvReqVo.getTransReqVO().getUserId(),session);
			if(requestValidatedFlag){
				UserInfoVO userVo = apprvReqVo.getTransReqVO();
				List<TransactionListVO> transactionListVO = apprvReqVo.getTransListVO();
				userVo.setSessionId((String) session.getAttribute("USER_AUTH_TOKEN"));
				//Added below session attributes for fortify fix - Do not maintain sigleton object
				apprvReqVo.setTempDiscReqVO((DiscountRequestVO) session.getAttribute("TEMP_REQUEST_DISCVO"));
				ErrorMsg = transactionService.returnDiscountRequest(transactionListVO,userVo,apprvReqVo);
				AuditRequestVO auditVo = new AuditRequestVO();
				auditVo.setUserId(userVo.getUserId());
				auditVo.setSessionId(userVo.getSessionId());
				auditVo.setFuncId(TransactionConstants.REJECT_DISCOUNT);
				auditVo.setOrgId(userVo.getOrgId());
				auditService.insertAuditLog(auditVo);
			}
			else{
				ErrorMsg = null;
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (Exception exception) {
			//paymentOrderResponseVO.setErrorMsg(exception.getMessage());
			log.error(exception.getMessage(),exception);
		}finally{
			session.removeAttribute("TEMP_REQUEST_DISCVO");
		}
		
		return ErrorMsg;
	}
//Ends For User Stories  S145 and S146 - Discount Rejection	

//Added for User Stories S148 by Rohit	
	/**
	 * This method is for accepting buyer details
	 * 
	 * @param apprvReqVo
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value ="postBuyerAcceptanceDetails.rest", method = RequestMethod.POST)
	public @ResponseBody ApproveResponseVo  postBuyerAcceptanceDetails(@RequestBody ApproveRequestVo apprvReqVo,HttpServletRequest request,HttpServletResponse response) throws BNPApplicationException {	
		
		ApproveResponseVo approveResponseVo= new ApproveResponseVo();
		HttpSession session = request.getSession();

		try {
			boolean requestValidatedFlag = validateRequest.validate(apprvReqVo.getTransReqVO().getUserId(),session);
			if(requestValidatedFlag){
				UserInfoVO userVo = apprvReqVo.getTransReqVO();
				userVo.setSessionId((String) session.getAttribute("USER_AUTH_TOKEN"));
				List<TransactionListVO> transactionListVO = apprvReqVo.getTransListVO();
				approveResponseVo = transactionService.acceptBuyerAcceptanceDetails(transactionListVO,userVo);
				AuditRequestVO auditVo = new AuditRequestVO();
				auditVo.setUserId(userVo.getUserId());
				auditVo.setSessionId(userVo.getSessionId());
				auditVo.setFuncId(TransactionConstants.ACCEPT_DISCOUNT);
				auditVo.setOrgId(userVo.getOrgId());
				auditService.insertAuditLog(auditVo);
			}
			else{
				approveResponseVo = null;
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (Exception exception) {
			response.setHeader("isError", "true");			
			log.error(exception.getMessage(),exception);
			throw new BNPApplicationException();
		}

		return approveResponseVo;
	}
	
	/**
	 * This method is for getting transaction call out info
	 * 
	 * @param transactionReqVO
	 * @param request
	 * @return
	 */
	@RequestMapping(value="getTransactionCallOutInfo.rest",method = RequestMethod.POST)
	public TransactionResponseVO getTransactionCallOutInfo(@RequestBody TransactionRequestVO transactionReqVO,HttpServletRequest request,HttpServletResponse response){		
		TransactionResponseVO transactionVO = new TransactionResponseVO();		
		try{
			boolean requestValidatedFlag = validateRequest.validate(transactionReqVO.getUserId(),request.getSession());
			if(requestValidatedFlag){
				transactionVO = transactionService.getTransactionCallOutInfo(transactionReqVO);
			}
			else{
				transactionVO = null;
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		}catch(BNPApplicationException exception){
			transactionVO.setErrorMsg(exception.getMessage());
			log.error(exception.getMessage());
		}
		return transactionVO;		
	}
	
	/**
	 * This method is for getting Discount Popup Details - FO 10.0 - S008, S009, S010, S011, S012, S013, S014
	 * 
	 * @param transactionReqVO
	 * @param request
	 * @return
	 */
	@RequestMapping(value="getDiscountPopupDetails.rest",method = RequestMethod.POST)
	public TransactionRequestVO getDiscountPopupDetails(@RequestBody TransactionRequestVO transactionReqVO,HttpServletRequest request,HttpServletResponse response){
		
		log.debug("TransactionController:: Enter getDiscountPopupDetails");
		HttpSession session = request.getSession();
		UserInfoVO user = (UserInfoVO) session.getAttribute("userInfo");
		
		try{
			boolean requestValidatedFlag = validateRequest.validate(transactionReqVO.getUserId(),request.getSession());
			if(requestValidatedFlag){
				log.debug("TransactionController:: calling service method getDiscountPopupDetails");
				transactionService.getDiscountPopupDetails(transactionReqVO);
				
				log.debug("TransactionController:: adding Audit entries");
				AuditRequestVO auditVo = new AuditRequestVO();
				auditVo.setUserId(user.getUserId());
				auditVo.setSessionId(user.getSessionId());
				auditVo.setFuncId(TransactionConstants.FUNCID_TXN_DISCDETAILS_POPUP);
				auditVo.setOrgId(user.getOrgId());
				auditService.insertAuditLog(auditVo);
			}
			else{
				log.debug("TransactionController:: " + BNPConstants.UNAUTHORIZED_ACCESS);
				transactionReqVO = null;
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		}catch(BNPApplicationException exception){
			transactionReqVO.setErrorMsg(exception.getMessage());
			log.error(exception.getMessage());
		}
		log.debug("TransactionController:: Exit getDiscountPopupDetails");
		return transactionReqVO;		
	}
	
	@RequestMapping(value="downloadDebitNoteRef.rest", method=RequestMethod.POST)
	public void downloadDebitNoteRef(@RequestBody TransactionRequestVO transactionReqVO, HttpServletRequest request, HttpServletResponse response)
	{
		log.debug("TransactionController:: Enter getDiscountPopupDetails");
		HttpSession session = request.getSession();
		UserInfoVO user = (UserInfoVO) session.getAttribute("userInfo");
		CommitmentFeeUxVO commitmentFeeVO = null;
		String fileName = null;
		try{
			boolean requestValidatedFlag = validateRequest.validate(user.getUserId(),request.getSession());
			if(requestValidatedFlag){
				log.debug("TransactionController:: calling service method getDiscountPopupDetails");
				commitmentFeeVO = transactionService.fetchDebitNoteRef(transactionReqVO);
				fileName = commitmentFeeVO.getFileName();
				
				response.setContentType("application/pdf");
				response.setHeader("Content-Disposition","attachment;filename=\"" + fileName + ".pdf\"");
				response.setHeader("fileName", fileName+".pdf");
				response.setContentLength(commitmentFeeVO.getData().length);
				response.getOutputStream().write(commitmentFeeVO.getData());
				response.getOutputStream().close();
			}
		}
		catch (IOException e) {
			response.setHeader("errorMessage", e.getMessage());
			response.setHeader("isError", "true");
			log.error(e.getMessage(),e);
		}
		catch(Exception e){
			response.setHeader("errorMessage", e.getMessage());
			response.setHeader("isError", "true");
			log.error(e.getMessage());
		}
	}
}