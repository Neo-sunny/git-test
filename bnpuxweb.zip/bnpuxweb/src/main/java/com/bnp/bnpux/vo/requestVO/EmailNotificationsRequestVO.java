package com.bnp.bnpux.vo.requestVO;

import java.util.Date;
import java.util.List;

import com.bnp.bnpux.common.vo.EmailNotificationsVO;

public class EmailNotificationsRequestVO{
	
	private String userId;
	
	private String userType;
	
	private String errorMsg;
	
	
	private String orgId;
	private Date emailFrmDate;
	private Date emailToDate;
	private String ftrStatus;
	private String fltrPeriod;
	private String fltrBranch;
	private String eventName;
	private String messageId;
	private String emailCat;
	private String orgName;
	private String refNum;
	private Integer dataFrom;
	private Integer dataTo;

	private List<EmailNotificationsVO> notificationsList;
	
	private String pollingTime;
	
	private boolean canEmailPollingStart;
	
	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public Date getEmailFrmDate() {
		return emailFrmDate;
	}

	public void setEmailFrmDate(Date emailFrmDate) {
		this.emailFrmDate = emailFrmDate;
	}

	public Date getEmailToDate() {
		return emailToDate;
	}

	public void setEmailToDate(Date emailToDate) {
		this.emailToDate = emailToDate;
	}

	public String getFtrStatus() {
		return ftrStatus;
	}

	public void setFtrStatus(String ftrStatus) {
		this.ftrStatus = ftrStatus;
	}

	public String getFltrPeriod() {
		return fltrPeriod;
	}

	public void setFltrPeriod(String fltrPeriod) {
		this.fltrPeriod = fltrPeriod;
	}

	public String getFltrBranch() {
		return fltrBranch;
	}

	public void setFltrBranch(String fltrBranch) {
		this.fltrBranch = fltrBranch;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getEmailCat() {
		return emailCat;
	}

	public void setEmailCat(String emailCat) {
		this.emailCat = emailCat;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getRefNum() {
		return refNum;
	}

	public void setRefNum(String refNum) {
		this.refNum = refNum;
	}


	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public List<EmailNotificationsVO> getNotificationsList() {
		return notificationsList;
	}

	public void setNotificationsList(List<EmailNotificationsVO> notificationsList) {
		this.notificationsList = notificationsList;
	}
	
	
	public String getPollingTime() {
		return pollingTime;
	}

	public void setPollingTime(String pollingTime) {
		this.pollingTime = pollingTime;
	}

	public boolean isCanEmailPollingStart() {
		return canEmailPollingStart;
	}

	public void setCanEmailPollingStart(boolean canEmailPollingStart) {
		this.canEmailPollingStart = canEmailPollingStart;
	}

	public Integer getDataFrom() {
		return dataFrom;
	}

	public void setDataFrom(Integer dataFrom) {
		this.dataFrom = dataFrom;
	}

	public Integer getDataTo() {
		return dataTo;
	}

	public void setDataTo(Integer dataTo) {
		this.dataTo = dataTo;
	}
	

	
}
