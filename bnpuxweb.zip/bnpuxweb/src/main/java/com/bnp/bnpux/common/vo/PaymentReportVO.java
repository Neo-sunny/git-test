package com.bnp.bnpux.common.vo;

public class PaymentReportVO {
	
	private String leadOrgName;
	private String cptyOrgName;	
	private String orgId;
	private String linkedOrgId;
	private String ccyCode;
	private String buyerErpId;
	private String sellerErpId;
	private String bandRecordCnt;
	/**
	 * @return the leadOrgName
	 */
	public String getLeadOrgName() {
		return leadOrgName;
	}
	/**
	 * @param leadOrgName the leadOrgName to set
	 */
	public void setLeadOrgName(String leadOrgName) {
		this.leadOrgName = leadOrgName;
	}
	/**
	 * @return the cptyOrgName
	 */
	public String getCptyOrgName() {
		return cptyOrgName;
	}
	/**
	 * @param cptyOrgName the cptyOrgName to set
	 */
	public void setCptyOrgName(String cptyOrgName) {
		this.cptyOrgName = cptyOrgName;
	}
	/**
	 * @return the orgId
	 */
	public String getOrgId() {
		return orgId;
	}
	/**
	 * @param orgId the orgId to set
	 */
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	/**
	 * @return the linkedOrgId
	 */
	public String getLinkedOrgId() {
		return linkedOrgId;
	}
	/**
	 * @param linkedOrgId the linkedOrgId to set
	 */
	public void setLinkedOrgId(String linkedOrgId) {
		this.linkedOrgId = linkedOrgId;
	}
	/**
	 * @return the ccyCode
	 */
	public String getCcyCode() {
		return ccyCode;
	}
	/**
	 * @param ccyCode the ccyCode to set
	 */
	public void setCcyCode(String ccyCode) {
		this.ccyCode = ccyCode;
	}
	/**
	 * @return the buyerErpId
	 */
	public String getBuyerErpId() {
		return buyerErpId;
	}
	/**
	 * @param buyerErpId the buyerErpId to set
	 */
	public void setBuyerErpId(String buyerErpId) {
		this.buyerErpId = buyerErpId;
	}
	/**
	 * @return the sellerErpId
	 */
	public String getSellerErpId() {
		return sellerErpId;
	}
	/**
	 * @param sellerErpId the sellerErpId to set
	 */
	public void setSellerErpId(String sellerErpId) {
		this.sellerErpId = sellerErpId;
	}
	/**
	 * @return the bandRecordCnt
	 */
	public String getBandRecordCnt() {
		return bandRecordCnt;
	}
	/**
	 * @param bandRecordCnt the bandRecordCnt to set
	 */
	public void setBandRecordCnt(String bandRecordCnt) {
		this.bandRecordCnt = bandRecordCnt;
	}

}
