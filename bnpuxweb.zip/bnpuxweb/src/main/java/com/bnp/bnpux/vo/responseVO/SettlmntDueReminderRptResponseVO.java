package com.bnp.bnpux.vo.responseVO;

import java.util.List;

import com.bnp.bnpux.common.vo.SettlmntDueReminderDetailsVO;
import com.bnp.bnpux.common.vo.SettlmntDueReminderVO;

public class SettlmntDueReminderRptResponseVO {

	
    private String errorMessage;
	
	private List<SettlmntDueReminderVO> settlmntDueReminderList;
	
	private List<SettlmntDueReminderDetailsVO> settlmntDueReminderDetailsList;

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * @return the settlmntDueReminderList
	 */
	public List<SettlmntDueReminderVO> getSettlmntDueReminderList() {
		return settlmntDueReminderList;
	}

	/**
	 * @param settlmntDueReminderList the settlmntDueReminderList to set
	 */
	public void setSettlmntDueReminderList(
			List<SettlmntDueReminderVO> settlmntDueReminderList) {
		this.settlmntDueReminderList = settlmntDueReminderList;
	}

	/**
	 * @return the settlmntDueReminderDetailsList
	 */
	public List<SettlmntDueReminderDetailsVO> getSettlmntDueReminderDetailsList() {
		return settlmntDueReminderDetailsList;
	}

	/**
	 * @param settlmntDueReminderDetailsList the settlmntDueReminderDetailsList to set
	 */
	public void setSettlmntDueReminderDetailsList(
			List<SettlmntDueReminderDetailsVO> settlmntDueReminderDetailsList) {
		this.settlmntDueReminderDetailsList = settlmntDueReminderDetailsList;
	}

}
