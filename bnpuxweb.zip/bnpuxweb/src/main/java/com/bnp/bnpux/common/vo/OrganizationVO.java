/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Organization Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 21 Feb 2017				Sathishkumar B										FO 10.0 - S008, S009, S010, S011, S012, S013, S014 
************************************************************************************************************************************************************/

package com.bnp.bnpux.common.vo;

public class OrganizationVO extends AbstractVO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private byte [] orgLogo;
	
	private String logoFileType;
	
	private String buyerShortName;
	
	private String buyerPostalAddress;
	
	private String buyerCity;
	
	private String buyerState;
	
	private String buyerPostalCode;
	
	private String buyerCountry;
	
	private byte [] buyerOrgLogo;
	
	private String buyerlogoFileType;
	
	private String supplierShortName;
	
	private String supplierPostalAddress;
	
	private String supplierCity;
	
	private String supplierState;
	
	private String supplierPostalCode;
	
	private String supplierCountry;
	
	private byte [] supplierOrgLogo;
	
	private String supplierlogoFileType;

	public String getLogoFileType() {
		return logoFileType;
	}

	public void setLogoFileType(String logoFileType) {
		this.logoFileType = logoFileType;
	}

	public byte[] getOrgLogo() {
		return orgLogo;
	}

	public void setOrgLogo(byte[] orgLogo) {
		this.orgLogo = orgLogo;
	}

	public String getBuyerShortName() {
		return buyerShortName;
	}

	public void setBuyerShortName(String buyerShortName) {
		this.buyerShortName = buyerShortName;
	}

	public String getBuyerPostalAddress() {
		return buyerPostalAddress;
	}

	public void setBuyerPostalAddress(String buyerPostalAddress) {
		this.buyerPostalAddress = buyerPostalAddress;
	}

	public String getBuyerCity() {
		return buyerCity;
	}

	public void setBuyerCity(String buyerCity) {
		this.buyerCity = buyerCity;
	}

	public String getBuyerState() {
		return buyerState;
	}

	public void setBuyerState(String buyerState) {
		this.buyerState = buyerState;
	}

	public String getBuyerPostalCode() {
		return buyerPostalCode;
	}

	public void setBuyerPostalCode(String buyerPostalCode) {
		this.buyerPostalCode = buyerPostalCode;
	}

	public byte[] getBuyerOrgLogo() {
		return buyerOrgLogo;
	}

	public void setBuyerOrgLogo(byte[] buyerOrgLogo) {
		this.buyerOrgLogo = buyerOrgLogo;
	}

	public String getBuyerlogoFileType() {
		return buyerlogoFileType;
	}

	public void setBuyerlogoFileType(String buyerlogoFileType) {
		this.buyerlogoFileType = buyerlogoFileType;
	}

	public String getSupplierShortName() {
		return supplierShortName;
	}

	public void setSupplierShortName(String supplierShortName) {
		this.supplierShortName = supplierShortName;
	}

	public String getSupplierPostalAddress() {
		return supplierPostalAddress;
	}

	public void setSupplierPostalAddress(String supplierPostalAddress) {
		this.supplierPostalAddress = supplierPostalAddress;
	}

	public String getSupplierCity() {
		return supplierCity;
	}

	public void setSupplierCity(String supplierCity) {
		this.supplierCity = supplierCity;
	}

	public String getSupplierState() {
		return supplierState;
	}

	public void setSupplierState(String supplierState) {
		this.supplierState = supplierState;
	}

	public String getSupplierPostalCode() {
		return supplierPostalCode;
	}

	public void setSupplierPostalCode(String supplierPostalCode) {
		this.supplierPostalCode = supplierPostalCode;
	}

	public byte[] getSupplierOrgLogo() {
		return supplierOrgLogo;
	}

	public void setSupplierOrgLogo(byte[] supplierOrgLogo) {
		this.supplierOrgLogo = supplierOrgLogo;
	}

	public String getSupplierlogoFileType() {
		return supplierlogoFileType;
	}

	public void setSupplierlogoFileType(String supplierlogoFileType) {
		this.supplierlogoFileType = supplierlogoFileType;
	}

	public String getBuyerCountry() {
		return buyerCountry;
	}

	public void setBuyerCountry(String buyerCountry) {
		this.buyerCountry = buyerCountry;
	}

	public String getSupplierCountry() {
		return supplierCountry;
	}

	public void setSupplierCountry(String supplierCountry) {
		this.supplierCountry = supplierCountry;
	}
	
	
	
}
