/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  14 Mar 2017
 * 
 * Purpose:     File Management Request Object
 * 
 * Change History: 
 * Date                       		Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 *  14 Mar 2017			             skbhaska					                	    Initial Version - FO 10.0 - S2005, S2007
 *  23-MAR-2017                   Divyashri S                                       R10.0 S2 - Added new attribute groupVal for S2093
 *  04-APR-2017                   Divyashri S                                       R10.0 S2 - S2020 - Invoice Settlement Detaisl 
 *  08 Apr 2017						belangov											Attachment POPup and Download - S2013,S2014
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.requestVO;

import java.util.Date;
import java.util.List;

import com.bnp.bnpux.common.vo.AdvancedFilterVO;
import com.bnp.bnpux.common.vo.FileMgmtAttachmentListVO;
import com.bnp.bnpux.common.vo.FileMgmtInvSettleListVO;
import com.bnp.bnpux.common.vo.FileMgmtInvoiceListVO;
import com.bnp.bnpux.common.vo.FileMgmtListVO;
import com.bnp.bnpux.common.vo.FileMgmtPOListVO;
import com.bnp.bnpux.common.vo.FileMgmtPreAppSuppListVO;
import com.bnp.bnpux.common.vo.FileMgmtRejectedRecVO;
import com.bnp.bnpux.common.vo.FileMgmtRolloverStlVO;
import com.bnp.bnpux.common.vo.FileMgmtSummaryVO;

public class FileMgmtRequestVO {

	private String userId;
	private String userType;
	private String groupIndicator;
	private String periodFilter;
	private String statusFilter;
	private String branchFilter;
	private String quickSearchText;
	private String viewType;
	private String errorFlag;
	private String docType;
    private String groupValue;
	private Date uploadDate;
	private Long recordFrom;
	private Long recordTo;
	private Integer docTypeCode;
	private String groupVal;
	List<AdvancedFilterVO> advancedFilterListVO;
	private List<FileMgmtSummaryVO> fileMgmtSummaryVOList;
	private List<FileMgmtListVO> fileMgmtListVO;
	
	private String fileId;
    private String invGroupCode;
    private String getWhat;
    private List<FileMgmtPOListVO> fileMgmtPOListVO;
    private List<FileMgmtInvSettleListVO> fileMgmtInvSettleListVO;
	private List<FileMgmtInvoiceListVO> fileMgmtInvoiceListVO;
	private List<FileMgmtRejectedRecVO> fileMgmtRejectionListVO;
	private List<FileMgmtPreAppSuppListVO> fileMgmtPreAppSuppListVO;
	private List<FileMgmtAttachmentListVO> fileMgmtAttachmentListVO;
	private List<FileMgmtRolloverStlVO> fileMgmtRolloverStlListVO;
	private String paymentRefNo;
	private List<FileMgmtAttachmentListVO> fileMgmtAttachmentListVO1;
	private String refId;
	private String refNo;
	private String recType;
	
	public Date getUploadDate() {
		return uploadDate;
	}

	public void setUploadDate(Date uploadDate) {
		this.uploadDate = uploadDate;
	}
	
	public String getRefId() {
		return refId;
	}

	public void setRefId(String refId) {
		this.refId = refId;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public String getRecType() {
		return recType;
	}

	public void setRecType(String recType) {
		this.recType = recType;
	}

	public List<FileMgmtAttachmentListVO> getFileMgmtAttachmentListVO1() {
		return fileMgmtAttachmentListVO1;
	}

	public void setFileMgmtAttachmentListVO1(List<FileMgmtAttachmentListVO> fileMgmtAttachmentListVO1) {
		this.fileMgmtAttachmentListVO1 = fileMgmtAttachmentListVO1;
	}

	public List<FileMgmtRolloverStlVO> getFileMgmtRolloverStlListVO() {
		return fileMgmtRolloverStlListVO;
	}

	public void setFileMgmtRolloverStlListVO(List<FileMgmtRolloverStlVO> fileMgmtRolloverStlListVO) {
		this.fileMgmtRolloverStlListVO = fileMgmtRolloverStlListVO;
	}
	
	

	
	public String getPaymentRefNo() {
		return paymentRefNo;
	}

	public void setPaymentRefNo(String paymentRefNo) {
		this.paymentRefNo = paymentRefNo;
	}

	public List<FileMgmtRejectedRecVO> getFileMgmtRejectionListVO() {
		return fileMgmtRejectionListVO;
	}

	public void setFileMgmtRejectionListVO(List<FileMgmtRejectedRecVO> fileMgmtRejectionListVO) {
		this.fileMgmtRejectionListVO = fileMgmtRejectionListVO;
	}

	public String getGroupVal() {
		return groupVal;
	}

	public void setGroupVal(String groupVal) {
		this.groupVal = groupVal;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getInvGroupCode() {
		return invGroupCode;
	}

	public void setInvGroupCode(String invGroupCode) {
		this.invGroupCode = invGroupCode;
	}

	public String getGetWhat() {
		return getWhat;
	}

	public void setGetWhat(String getWhat) {
		this.getWhat = getWhat;
	}

	public List<FileMgmtPOListVO> getFileMgmtPOListVO() {
		return fileMgmtPOListVO;
	}

	public void setFileMgmtPOListVO(List<FileMgmtPOListVO> fileMgmtPOListVO) {
		this.fileMgmtPOListVO = fileMgmtPOListVO;
	}

	public List<FileMgmtInvoiceListVO> getFileMgmtInvoiceListVO() {
		return fileMgmtInvoiceListVO;
	}

	public void setFileMgmtInvoiceListVO(List<FileMgmtInvoiceListVO> fileMgmtInvoiceListVO) {
		this.fileMgmtInvoiceListVO = fileMgmtInvoiceListVO;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getGroupIndicator() {
		return groupIndicator;
	}

	public void setGroupIndicator(String groupIndicator) {
		this.groupIndicator = groupIndicator;
	}

	public String getPeriodFilter() {
		return periodFilter;
	}

	public void setPeriodFilter(String periodFilter) {
		this.periodFilter = periodFilter;
	}

	public String getStatusFilter() {
		return statusFilter;
	}

	public void setStatusFilter(String statusFilter) {
		this.statusFilter = statusFilter;
	}

	public String getBranchFilter() {
		return branchFilter;
	}

	public void setBranchFilter(String branchFilter) {
		this.branchFilter = branchFilter;
	}

	public String getQuickSearchText() {
		return quickSearchText;
	}

	public void setQuickSearchText(String quickSearchText) {
		this.quickSearchText = quickSearchText;
	}

	public String getViewType() {
		return viewType;
	}

	public void setViewType(String viewType) {
		this.viewType = viewType;
	}

	public String getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}



	public Integer getDocTypeCode() {
		return docTypeCode;
	}

	public void setDocTypeCode(Integer docTypeCode) {
		this.docTypeCode = docTypeCode;
	}

	public List<AdvancedFilterVO> getAdvancedFilterListVO() {
		return advancedFilterListVO;
	}

	public void setAdvancedFilterListVO(List<AdvancedFilterVO> advancedFilterListVO) {
		this.advancedFilterListVO = advancedFilterListVO;
	}

	public List<FileMgmtSummaryVO> getFileMgmtSummaryVOList() {
		return fileMgmtSummaryVOList;
	}

	public void setFileMgmtSummaryVOList(List<FileMgmtSummaryVO> fileMgmtSummaryVOList) {
		this.fileMgmtSummaryVOList = fileMgmtSummaryVOList;
	}

	public List<FileMgmtListVO> getFileMgmtListVO() {
		return fileMgmtListVO;
	}

	public void setFileMgmtListVO(List<FileMgmtListVO> fileMgmtListVO) {
		this.fileMgmtListVO = fileMgmtListVO;
	}

	public String getGroupValue() {
		return groupValue;
	}

	public void setGroupValue(String groupValue) {
		this.groupValue = groupValue;
	}

	public List<FileMgmtPreAppSuppListVO> getFileMgmtPreAppSuppListVO() {
		return fileMgmtPreAppSuppListVO;
	}

	public void setFileMgmtPreAppSuppListVO(List<FileMgmtPreAppSuppListVO> fileMgmtPreAppSuppListVO) {
		this.fileMgmtPreAppSuppListVO = fileMgmtPreAppSuppListVO;
	}

	public List<FileMgmtAttachmentListVO> getFileMgmtAttachmentListVO() {
		return fileMgmtAttachmentListVO;
	}

	public void setFileMgmtAttachmentListVO(List<FileMgmtAttachmentListVO> fileMgmtAttachmentListVO) {
		this.fileMgmtAttachmentListVO = fileMgmtAttachmentListVO;
	}

	public List<FileMgmtInvSettleListVO> getFileMgmtInvSettleListVO() {
		return fileMgmtInvSettleListVO;
	}

	public void setFileMgmtInvSettleListVO(List<FileMgmtInvSettleListVO> fileMgmtInvSettleListVO) {
		this.fileMgmtInvSettleListVO = fileMgmtInvSettleListVO;
	}

	public Long getRecordFrom() {
		return recordFrom;
	}

	public void setRecordFrom(Long recordFrom) {
		this.recordFrom = recordFrom;
	}

	public Long getRecordTo() {
		return recordTo;
	}

	public void setRecordTo(Long recordTo) {
		this.recordTo = recordTo;
	}
	
	
}
