/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Export Constants
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 28 Feb 2017				 Sathishkumar B										 FO 10.0 - S011, S012
************************************************************************************************************************************************************/
package com.bnp.bnpux.constants;

public interface ExportConstants {
	
	public static final String CSV_FORMAT="CSV";
	public static final String COMMA_DELIMITER = ",";
	public static final String SEMI_COLON = ";";
	public static final String EMPTY ="";
	public static final String Yes="Yes";
	public static final String No="No";
	public static final String NULL_STR = "null";
	public static final String XLS_FORMAT="XLS"; 
	public static final String PDF_FORMAT = "PDF";
	public static final String PO_SECTIONS_LIST = "PAYMENT~INVOICE~CREDITNOTE~AUDIT";
	public static final String poBaseHeaderName = "PaymentPopupHeaders";
	public static final String EMPTY_ROWS_BW_SECTIONS = "2";
	
	/**FO 10.0 - S011, S012**/
	public static final String TXN_DISCDETAILSPOPOP_EXPORT_SECTIONS_LIST = "DISCOUNT~INDCHARGE~COMMFEEHDR~COMMFEE~PAYMENT~INVOICE~CREDITNOTE";
	public static final String TXN_DISCDETAILSPOPOP_EXPORT_BASE_HEADER_NAME = "TxnDiscDetailsPopupExportHeaders";
	
	public static final String RS_MAIN = "MAIN";
	public static final String RS_DISCOUNT = "DISCOUNT";
	public static final String RS_PAYMENT = "PAYMENT";
	public static final String RS_INVOICE = "INVOICE";
	public static final String RS_CREDITNOTE = "CREDITNOTE";
	public static final String RS_INDCHARGE = "INDCHARGE";
	public static final String RS_COMMFEE = "COMMFEE";
	public static final String RS_COMMFEE_HDR = "COMMFEEHDR";
	/**FO 10.0 - S011, S012**/
	
}


