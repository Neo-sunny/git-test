/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   26-Dec-2016
 * 
 * Purpose:     Form Sumbit Controller
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 26-Dec-2016			Bala Murugan Elangovan						Initial Version
 * 07-Feb-2017			Bala Murugan Elangovan						Removed CSRF Token check as it is Form submit
 * 04-Jul-2017			Purushothaman        						Fortify issue fix to validate the filename and the user id for export
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.bnp.bnpux.constants.ExportConstants;
import com.bnp.bnpux.service.IExportService;
import com.bnp.bnpux.util.ExportUtil;
import com.bnp.bnpux.vo.requestVO.ExportRequestVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * Servlet implementation class ExportServlet
 */
public class FormSubmitController extends HttpServlet {
	
	
	
	private static final long serialVersionUID = 1L;

	private static final String PARAMETER_PAGE = "page";
	
	private static final String PARAMETER_EXCEL_EXPORT = "excelExport";	
	
	private static final Logger log = LoggerFactory.getLogger(FormSubmitController.class);
			
	@Autowired
	private IExportService exportService ;
	
				
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FormSubmitController() {
        super();        
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {		
		super.init(config);
	    SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this,config.getServletContext());
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (request.getParameter(PARAMETER_PAGE).equalsIgnoreCase(PARAMETER_EXCEL_EXPORT)) {
			try {
				ExportRequestVO exportVO = new ExportRequestVO();
				String voUserId = request.getParameter("userId");
				String fileName = request.getParameter("fileName");
				if (validate(voUserId, request.getSession()) && !badFilename(fileName)) {
					exportVO.setUserId(voUserId);
					exportVO.setUserType(request.getParameter("userType"));
					exportVO.setGroupIndicator(request.getParameter("groupIndicator"));
					exportVO.setStatusFilter(request.getParameter("statusFilter"));
					exportVO.setPeriodFilter(request.getParameter("periodFilter"));
					exportVO.setBranchFilter(request.getParameter("branchFilter"));
					exportVO.setQuickSearch(request.getParameter("quickSearch"));
					exportVO.setPageInfo(request.getParameter("pageInfo"));
					exportVO.setLangPreferance(request.getParameter("langPreferance"));
					exportVO.setExportType(request.getParameter("exportTypeVal"));
					exportVO.setFileName(fileName);
					export(exportVO, request, response);
				}else{
					BNPApplicationException ex = new BNPApplicationException();
					ex.setErrorCode(30000102);
					throw ex;
				}
			} catch (BNPApplicationException e) {
				response.setHeader("errorMessage", Integer.toString(e.getErrorCode()));
				response.setHeader("isError", "true");
				log.error("errorMessage", Integer.toString(e.getErrorCode()));
			}catch (IOException e){					
				response.setHeader("errorMessage", e.getMessage());
				response.setHeader("isError", "true");
				log.error("errorMessage",e.getMessage());
			}			
	 	}
 	
	}
	
	/**
	 * @Method export
	 * @param exportVO
	 * @param request
	 * @param response
	 * @param buffer
	 * @throws IOException
	 * @throws BNPApplicationException
	 */
	private void export(ExportRequestVO exportVO,HttpServletRequest request, HttpServletResponse response) throws IOException, BNPApplicationException {						
				byte[] buffer = null;
				ServletOutputStream outputStream = null;
				try {					
					outputStream = response.getOutputStream();
					setContentType(exportVO, response);										
					if (ExportUtil.PAYMENT_ORDER_PAGE.equals(exportVO.getPageInfo())) {
						if(ExportUtil.PAYMENT_ORDER_PAGE_POPUP.equals(exportVO.getPagePopUpInfo())){
							exportService.getPaymentOrderExportPopUpDetails(exportVO,outputStream);
						}else{
							exportService.getPaymentOrderExportDetails(exportVO,outputStream);	
						}						 
					}
					else if (ExportUtil.TRANSACTION_PAGE.equals(exportVO.getPageInfo())) {
						exportService.getTransactionResultSet(exportVO,outputStream);
					}
					else if(ExportUtil.SETTLEMENT_PAGE.equals(exportVO.getPageInfo())) {
						exportService.getSettlementResults(exportVO,outputStream);
					}					
					else if(ExportUtil.REPORTS_PAGE.equals(exportVO.getPageInfo())) {
						exportService.getReportsExport(exportVO,outputStream,buffer);
					}										
				}
				finally{				
					if(outputStream != null){
						outputStream.close();
					}
				}			
			}
	
	/**
	 * @Method : setContentType
	 * @param exportVO
	 * @param response
	 */
	private void setContentType(ExportRequestVO exportVO,HttpServletResponse response) {
		if (ExportConstants.XLS_FORMAT.equalsIgnoreCase(exportVO.getExportType())) {
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");		
			response.setHeader( "Content-Disposition", "attachment;filename=" + exportVO.getFileName());
		}				
	}
	
	/**
	 * This method is used to validate whether the user id is valid or not
	 * @param voUserId
	 * @param session
	 * @return
	 */

	private boolean validate(String voUserId, HttpSession session) {
		boolean validateFlag = false;
		String sessionUserId = null;
		if (session != null) {
			sessionUserId = (String) session.getAttribute("USER_ID");
		}
		log.debug("voUserId : " + voUserId + " session UserID : " + sessionUserId);
		if (sessionUserId != null && voUserId != null) {
			if (sessionUserId.equalsIgnoreCase(voUserId)) {
				validateFlag = true;
			}
		}
		return validateFlag;
	}

/**
 * This method is used to validate whether the file name contains the special charactes other than the "_" "."
 * @param fileName
 * @return
 */
	private boolean badFilename(String fileName) {
		boolean validateFlag = false;
        Pattern p = Pattern.compile("[^A-Za-z0-9\\_\\.]");
        Matcher m = p.matcher(fileName);
        validateFlag = m.find();
		return validateFlag;
	}


}
