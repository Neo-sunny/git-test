/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   21 June 2017
 * 
 * Purpose:      Credit Note Inquiry Report Service Implementation
 * 
 * Change History:
 *  
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 21 June 2017       Rameshwar Khedekar, Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.constants;

public interface DiscTransConstants {
	
	public static final String VIEW_TYPE = "viewType";
	
	public static final String DISC_TRANS_LIST = "discTransList";
	
	public static final String DISC_TRANS_LIST_DETAILS = "discTransListDetails";


}
