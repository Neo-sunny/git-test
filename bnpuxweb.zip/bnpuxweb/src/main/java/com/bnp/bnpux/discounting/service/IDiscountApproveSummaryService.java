/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Interface for Discount Request Button Service
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.discounting.service;

import java.util.List;

import com.bnp.bnpux.common.vo.ApproveRequestVo;
import com.bnp.bnpux.common.vo.ApproveResponseVo;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.vo.errorMessageVO.ErrorMessageVO;
import com.bnp.scm.services.discounting.vo.DiscountRequestVO;

public interface IDiscountApproveSummaryService {
	
	/**
	 * This method is for Approve the Discount Request 
	 * 
	 * @param discVOList
	 * @param user
	 * @return
	 */
	public ApproveResponseVo approve(List<DiscountRequestVO> discVOList, UserInfoVO user);
	
	/**
	 * This method is for Rejecting the Discount Request 
	 * 
	 * @param discVOList
	 * @param user
	 * @return
	 */
	public List<ErrorMessageVO> reject(List<DiscountRequestVO> discVOList, UserInfoVO user);

	/**
	 * This method is for Accepting the Discount Request
	 * 
	 * @param discVOList
	 * @param user
	 * @return
	 */
	public ApproveResponseVo accept(List<DiscountRequestVO> discVOList, UserInfoVO user);
	
	/**
	 * This method is for Proceed approve the Discount Request
	 * 
	 * @param discVOList
	 * @param uservo
	 * @return
	 */
	public ApproveResponseVo proceedApproveDiscountRequest(List<DiscountRequestVO> discVOList, UserInfoVO uservo, ApproveRequestVo apprvReqVo);
	
	/**
	 * This method is for getting the Discount Request
	 * 
	 * @param discVOList
	 * @param user
	 * @return
	 */
	public List<ErrorMessageVO> returnDiscountRequest(List<DiscountRequestVO> discVOList, UserInfoVO user, ApproveRequestVo apprvReqVo);
	
}
