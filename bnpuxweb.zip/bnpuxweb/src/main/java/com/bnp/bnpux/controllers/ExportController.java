/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
* 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
* 
 * Created on:   27-OCT-2016
* 
 * Purpose:      Export Controller
* 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import java.io.IOException;
import java.io.InputStream;
import java.io.FileOutputStream;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.bind.annotation.RequestPart;

import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.constants.ExportConstants;
import com.bnp.bnpux.service.IAuditService;
import com.bnp.bnpux.service.IExportService;
import com.bnp.bnpux.util.ExportUtil;
import com.bnp.bnpux.util.RequestIdentityValidator;
import com.bnp.bnpux.vo.requestVO.AuditRequestVO;
import com.bnp.bnpux.vo.requestVO.ExportRequestVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@RestController
@RequestMapping("/exprtCntrl")
public class ExportController {

	public static final Logger log = LoggerFactory.getLogger(ExportController.class);

	@Autowired
	private IExportService exportService;
	
    @Autowired
	private IAuditService auditService;
    
    @Autowired
	RequestIdentityValidator validateRequest;
    /**
     * This method is for getting image data
     * 
     * @param exportVO
     * @param file
     * @param request
     * @param response
     * @throws IOException
     * @throws BNPApplicationException
     */
    @RequestMapping(value = "periodimg.rest", method = RequestMethod.POST, consumes = {"multipart/form-data"})
    public void getImageData( @RequestPart("data") ExportRequestVO exportVO, @RequestPart("file") MultipartFile file,HttpServletRequest request, HttpServletResponse response)throws IOException, BNPApplicationException {
    	boolean requestValidatedFlag = validateRequest.validate(exportVO.getUserId(),request.getSession());
		if(requestValidatedFlag){
    	   export(exportVO,request,response,file.getBytes());
		}
		else{
			log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
			response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		}
    }

	/**
	 * This method is for exporting records
	 * 
	 * @param exportVO
	 * @param request
	 * @param response
	 * @throws IOException
	 * @throws BNPApplicationException
	 */
	@RequestMapping(value = "exportController.rest", method = RequestMethod.POST)
	public void exportRecords(@RequestBody ExportRequestVO exportVO,
			HttpServletRequest request, HttpServletResponse response) throws IOException, BNPApplicationException {
		boolean requestValidatedFlag = validateRequest.validate(exportVO.getUserId(),request.getSession());
		if(requestValidatedFlag){
			export(exportVO,request,response,null);
		}
		else{
			log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
			response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		}
	}

	/**
	 * This method is setting response content type
	 * @param exportVO
	 * @param response
	 */
	private void setContentType(ExportRequestVO exportVO,
			HttpServletResponse response) {
		if (ExportConstants.XLS_FORMAT.equalsIgnoreCase(exportVO.getExportType())) {
			 response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
		} else if (ExportConstants.CSV_FORMAT.equalsIgnoreCase(exportVO.getExportType())) {
			 response.setContentType("application/csv");
		} else if (ExportConstants.PDF_FORMAT.equalsIgnoreCase(exportVO.getExportType())) {
			 response.setContentType("application/pdf");
		}
		
	}
	
	/**
	 * This is the main export method
	 * 
	 * @param exportVO
	 * @param request
	 * @param response
	 * @param buffer
	 * @throws IOException
	 * @throws BNPApplicationException
	 */
	private void export(ExportRequestVO exportVO,HttpServletRequest request, HttpServletResponse response,byte[] buffer) throws IOException, BNPApplicationException {
		
		//Getting the runtime reference from system
		Runtime runtime = Runtime.getRuntime();
		long startTime = System.currentTimeMillis();
		ServletOutputStream outputStream = null;
		try {
			//log.info("Page accessed" + exportVO.getPageInfo());
			//log.info("Format Requested" + exportVO.getExportType() );
			HttpSession session = request.getSession();
			UserInfoVO user = (UserInfoVO) session.getAttribute("userInfo");
			user.setSessionId((String) session.getAttribute("USER_AUTH_TOKEN"));			
			AuditRequestVO auditVo = new AuditRequestVO();
			auditVo.setUserId(user.getUserId());
			auditVo.setSessionId(user.getSessionId());
			auditVo.setFuncId(exportVO.getPageInfo()+ExportUtil.AUDIT_CONCATENATE+exportVO.getExportType());
			auditVo.setOrgId(user.getOrgId());
			auditService.insertAuditLog(auditVo);
						
			int mb = 1024*1024;
			
			log.debug("##### Heap utilization statistics [MB] #####");
			
			//Print total available memory
			log.debug("Total Memory:" + runtime.totalMemory() / mb);
			
			//Print free memory
			log.debug("Free Memory:"	+ runtime.freeMemory() / mb);
			outputStream = response.getOutputStream();
			setContentType(exportVO, response);
			if (null != exportVO.getPageInfo()	&& exportVO.getPageInfo().equals(ExportUtil.PAYMENT_ORDER_PAGE)) {
				
				if(ExportUtil.PAYMENT_ORDER_PAGE_POPUP.equals(exportVO.getPagePopUpInfo())){
					log.debug("Inside Payment Popup");
					exportService.getPaymentOrderExportPopUpDetails(exportVO,outputStream);
				}else{
					exportService.getPaymentOrderExportDetails(exportVO,outputStream);	
				}
			}

			if (null != exportVO.getPageInfo()	&& exportVO.getPageInfo().equals(ExportUtil.TRANSACTION_PAGE)) {
				
				
				
				if(ExportUtil.TRANSACTION_PAGE_POPUP.equals(exportVO.getPagePopUpInfo())){
					log.debug("Inside Transaction Popup");
					exportService.getTransactionExportPopUpDetails(exportVO,outputStream);
				}else{
					exportService.getTransactionResultSet(exportVO,outputStream);	
				}
				
				
			}

			if (null != exportVO.getPageInfo()	&& exportVO.getPageInfo().equals(ExportUtil.SETTLEMENT_PAGE)) {
				exportService.getSettlementResults(exportVO,outputStream);
			}
			
			if (null != exportVO.getPageInfo()	&& exportVO.getPageInfo().equals(ExportUtil.REPORTS_PAGE)) {
				exportService.getReportsExport(exportVO,outputStream,buffer);
			}
			
			if (null != exportVO.getPageInfo()	&& exportVO.getPageInfo().equals(ExportUtil.CREDIT_NOTE_REPORT)) {
				exportService.getCreditNoteReportsExport(exportVO,outputStream,buffer);
			}
			
			if (null != exportVO.getPageInfo()	&& exportVO.getPageInfo().equals(ExportUtil.LIMIT_UTIL_REPORT)) {//S39081 :Limit Util Report
				exportService.getLimitUtilReportsExport(exportVO,outputStream,buffer);
			}
			//Discount Transaction Report Export
			if (null != exportVO.getPageInfo()	&& exportVO.getPageInfo().equals(ExportUtil.DISC_TRANS_REPORT)) {
				exportService.getDiscTransReportsExport(exportVO,outputStream,buffer);
			}
			//CMA
			if (null != exportVO.getPageInfo()	&& exportVO.getPageInfo().equals(ExportUtil.SETTLEMENT_DUE_REPORT)) {
				exportService.getExportSettlementDueReminderReportsData(exportVO,outputStream,buffer);
			}
			if (null != exportVO.getPageInfo()	&& exportVO.getPageInfo().equals(ExportUtil.PAYMENT_REPORT)) {
				exportService.getExportPaymentReportsData(exportVO,outputStream,buffer);
			}
			
			
			if (null != exportVO.getPageInfo()	&& exportVO.getPageInfo().equals(ExportUtil.VIEW_SCHEDULED_REPORT)) {				
				exportService.getExportViewScheduledReportsData(exportVO,outputStream,buffer);
			}
			

			if (null != exportVO.getPageInfo()	&& exportVO.getPageInfo().equals(ExportUtil.AGING_REPORT)) {				
				exportService.getAgingReportExportData(exportVO,outputStream,buffer);
			}
			
			if (null != exportVO.getPageInfo()	&& exportVO.getPageInfo().equals(ExportUtil.REMITTANCE_REPORT)) {				
				exportService.getExportRemittanceReportsData(exportVO,outputStream,buffer);
			}

			long endTime = System.currentTimeMillis();
			log.debug("Total Time For Export-------------->>"	+ (endTime - startTime));

			//Print used memory
			log.debug("Used Memory After Export:" + (runtime.totalMemory() - runtime.freeMemory()) / mb);

			//Print Maximum available memory
			log.debug("Max Memory:" + runtime.maxMemory() / mb);
				
		}catch (BNPApplicationException e) {
			log.info(e.getErrorCode() + "          "+  e.getErrorMessage());
			response.setHeader("errorMessage", Integer.toString(e.getErrorCode()));
			response.setHeader("isError", "true");
		}catch (Exception e){
			response.setHeader("errorMessage", e.getMessage());
			response.setHeader("isError", "true");
		}
			finally{
			
			if(outputStream != null){
				outputStream.close();
			}
		}
	}
	
}
