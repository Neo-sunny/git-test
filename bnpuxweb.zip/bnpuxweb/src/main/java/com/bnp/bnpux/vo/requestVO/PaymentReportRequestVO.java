package com.bnp.bnpux.vo.requestVO;

import java.util.Date;
import java.util.List;

import com.bnp.bnpux.common.vo.PaymentReportDetailsVO;
import com.bnp.bnpux.common.vo.PaymentReportVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;

public class PaymentReportRequestVO {
	
	private String errorMsg;
	private String userId;
	private String userTypeId;
	private String orgId;		
	private String counterPtyOrgId;
	private String currencyCode;
	private String period;
	private String branch;
	private String exportType;
	private String viewType;
	private String getWhat;
	private Date frmDate;
	private Date toDate;
	private String reportType;
	private Integer recordFrom;
	private Integer recordTo;
	private List<PaymentReportVO> paymentReport;
	private List<PaymentReportDetailsVO> paymentReportDetails;
	private List<ReportChartResponseVO> reportChartList;
	
	/**
	 * @return the errorMsg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}
	/**
	 * @param errorMsg the errorMsg to set
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the userTypeId
	 */
	public String getUserTypeId() {
		return userTypeId;
	}
	/**
	 * @param userTypeId the userTypeId to set
	 */
	public void setUserTypeId(String userTypeId) {
		this.userTypeId = userTypeId;
	}
	/**
	 * @return the orgId
	 */
	public String getOrgId() {
		return orgId;
	}
	/**
	 * @param orgId the orgId to set
	 */
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	/**
	 * @return the counterPtyOrgId
	 */
	public String getCounterPtyOrgId() {
		return counterPtyOrgId;
	}
	/**
	 * @param counterPtyOrgId the counterPtyOrgId to set
	 */
	public void setCounterPtyOrgId(String counterPtyOrgId) {
		this.counterPtyOrgId = counterPtyOrgId;
	}
	/**
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}
	/**
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	/**
	 * @return the period
	 */
	public String getPeriod() {
		return period;
	}
	/**
	 * @param period the period to set
	 */
	public void setPeriod(String period) {
		this.period = period;
	}
	/**
	 * @return the branch
	 */
	public String getBranch() {
		return branch;
	}
	/**
	 * @param branch the branch to set
	 */
	public void setBranch(String branch) {
		this.branch = branch;
	}
	/**
	 * @return the exportType
	 */
	public String getExportType() {
		return exportType;
	}
	/**
	 * @param exportType the exportType to set
	 */
	public void setExportType(String exportType) {
		this.exportType = exportType;
	}
	/**
	 * @return the viewType
	 */
	public String getViewType() {
		return viewType;
	}
	/**
	 * @param viewType the viewType to set
	 */
	public void setViewType(String viewType) {
		this.viewType = viewType;
	}
	/**
	 * @return the getWhat
	 */
	public String getGetWhat() {
		return getWhat;
	}
	/**
	 * @param getWhat the getWhat to set
	 */
	public void setGetWhat(String getWhat) {
		this.getWhat = getWhat;
	}
	/**
	 * @return the frmDate
	 */
	public Date getFrmDate() {
		return frmDate;
	}
	/**
	 * @param frmDate the frmDate to set
	 */
	public void setFrmDate(Date frmDate) {
		this.frmDate = frmDate;
	}
	/**
	 * @return the toDate
	 */
	public Date getToDate() {
		return toDate;
	}
	/**
	 * @param toDate the toDate to set
	 */
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	/**
	 * @return the reportType
	 */
	public String getReportType() {
		return reportType;
	}
	/**
	 * @param reportType the reportType to set
	 */
	public void setReportType(String reportType) {
		this.reportType = reportType;
	}
	/**
	 * @return the recordFrom
	 */
	public Integer getRecordFrom() {
		return recordFrom;
	}
	/**
	 * @param recordFrom the recordFrom to set
	 */
	public void setRecordFrom(Integer recordFrom) {
		this.recordFrom = recordFrom;
	}
	/**
	 * @return the recordTo
	 */
	public Integer getRecordTo() {
		return recordTo;
	}
	/**
	 * @param recordTo the recordTo to set
	 */
	public void setRecordTo(Integer recordTo) {
		this.recordTo = recordTo;
	}
	/**
	 * @return the paymentReport
	 */
	public List<PaymentReportVO> getPaymentReport() {
		return paymentReport;
	}
	/**
	 * @param paymentReport the paymentReport to set
	 */
	public void setPaymentReport(List<PaymentReportVO> paymentReport) {
		this.paymentReport = paymentReport;
	}
	/**
	 * @return the paymentReportDetails
	 */
	public List<PaymentReportDetailsVO> getPaymentReportDetails() {
		return paymentReportDetails;
	}
	/**
	 * @param paymentReportDetails the paymentReportDetails to set
	 */
	public void setPaymentReportDetails(List<PaymentReportDetailsVO> paymentReportDetails) {
		this.paymentReportDetails = paymentReportDetails;
	}
	/**
	 * @return the reportChartList
	 */
	public List<ReportChartResponseVO> getReportChartList() {
		return reportChartList;
	}
	/**
	 * @param reportChartList the reportChartList to set
	 */
	public void setReportChartList(List<ReportChartResponseVO> reportChartList) {
		this.reportChartList = reportChartList;
	}
	
	

}
