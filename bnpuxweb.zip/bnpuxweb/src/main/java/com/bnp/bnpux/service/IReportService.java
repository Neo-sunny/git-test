/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     Report Service Interface
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 
 *****************************************************************************************************************************************************************/
package com.bnp.bnpux.service;

import java.util.List;

import com.bnp.bnpux.vo.requestVO.ReportRequestVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;
import com.bnp.bnpux.vo.responseVO.ReportResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface IReportService {

	/**
	 * This method is for getting Report details
	 * 
	 * @param ReportRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	ReportResponseVO getReportDetails(ReportRequestVO ReportRequestVO) throws BNPApplicationException;

	/**
	 * This method is for getting Report list
	 * 
	 * @param ReportRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	ReportResponseVO getReporList(ReportRequestVO ReportRequestVO)	throws BNPApplicationException;

	/**
	 * This method is for getting report chart axis 
	 * 
	 * @param requestVo
	 * @return
	 * @throws BNPApplicationException
	 */
	List<ReportChartResponseVO> getReportChartAxis (ReportRequestVO requestVo)throws BNPApplicationException;
}
