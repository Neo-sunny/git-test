/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Audit Interface for Data Access Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.dao;

import com.bnp.bnpux.vo.requestVO.AuditRequestVO;

public interface IAuditDAO {
	
	/**
	 * This method is for inserting audit info
	 * 
	 * @param auditVo
	 */
	public void insertAuditLog(AuditRequestVO auditVo);
}
