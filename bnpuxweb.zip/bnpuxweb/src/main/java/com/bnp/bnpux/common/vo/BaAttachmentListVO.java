/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   28 Mar 2017	
 * 
 * Purpose:       File Management attachment Value Object
 * 
 * Change History: 
 * Date                       Author                                    Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 10 April 2017			      sree reshmi					               Initial Version 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;




public class BaAttachmentListVO {
	
	private String reference;
	private String type;
	private String orgId;
	private String fileName;
	private Integer attachFlag;
	private int seqNo;
	private String refId;
	private String fileId;
	private byte[] data;
	private String refNo;
	private String recType;
	
	public String getReference() {
		return reference;
	}
	public void setReference(String reference) {
		this.reference = reference;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public Integer getAttachFlag() {
		return attachFlag;
	}
	public void setAttachFlag(Integer attachFlag) {
		this.attachFlag = attachFlag;
	}
	public int getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(int seqNo) {
		this.seqNo = seqNo;
	}
	public String getRefId() {
		return refId;
	}
	public void setRefId(String refId) {
		this.refId = refId;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public String getRecType() {
		return recType;
	}
	public void setRecType(String recType) {
		this.recType = recType;
	}
	public byte[] getData() {
		return data;
	}
	public byte[] copyArray(byte[] source) {
		byte[] dest = null;
		if (source != null) {
			dest = new byte[source.length];

			System.arraycopy(source, 0, dest, 0, source.length);
		}
		return dest;
	}

	/**
	 * @param data
	 *            the data to set
	 */
	public void setData(byte[] data) {
		this.data = copyArray(data);
	}

	

}
