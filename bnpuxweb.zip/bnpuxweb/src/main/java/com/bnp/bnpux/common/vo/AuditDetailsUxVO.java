package com.bnp.bnpux.common.vo;

public class AuditDetailsUxVO extends AbstractVO
{
	private String fileId;
	private String userId;
	private String releasedBy;
	private String releasedDate;
	private String fileName;
	private String fileStatus;
	
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getReleasedBy() {
		return releasedBy;
	}
	public void setReleasedBy(String releasedBy) {
		this.releasedBy = releasedBy;
	}
	public String getReleasedDate() {
		return releasedDate;
	}
	public void setReleasedDate(String releasedDate) {
		this.releasedDate = releasedDate;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileStatus() {
		return fileStatus;
	}
	public void setFileStatus(String fileStatus) {
		this.fileStatus = fileStatus;
	}
}
