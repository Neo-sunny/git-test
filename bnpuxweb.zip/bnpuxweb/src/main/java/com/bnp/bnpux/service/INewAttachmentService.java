/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     NewAttachment Service Interface
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 
 *****************************************************************************************************************************************************************/
package com.bnp.bnpux.service;

import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.AttachmentVO;

import java.util.List;

import com.bnp.bnpux.vo.requestVO.AttachmentRequestVO;
import com.bnp.bnpux.vo.responseVO.AttachmentResponseVO;

public interface INewAttachmentService {
	
	/**
	 * This method is for downloading attachment
	 * 
	 * @param attachmentRequest
	 * @return
	 * @throws BNPApplicationException
	 */
	AttachmentResponseVO downloadSCFAttachment(AttachmentRequestVO attachmentRequest) throws BNPApplicationException;
	
	/**
	 * This method is for getting attachment details
	 * 
	 * @param attachmentRequest
	 * @return
	 * @throws BNPApplicationException
	 */
	AttachmentResponseVO getSCFAttachmentDetails(AttachmentRequestVO attachmentRequest) throws BNPApplicationException;
	
	/**
	 * This method is for download all attachments
	 * 
	 * @param attachmentRequest
	 * @return
	 * @throws BNPApplicationException
	 */
	AttachmentResponseVO downloadAllSCFAttachment(AttachmentRequestVO attachmentRequest) throws BNPApplicationException;
	
	AttachmentResponseVO downLoadSingleSCFAttachment(List<AttachmentVO> selectedFileList)throws BNPApplicationException;
}
