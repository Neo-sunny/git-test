/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   07 Apr 2016
 * 
 * Purpose:     SCF Common Util
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 11 Apr 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 
 *****************************************************************************************************************************************************************/

package com.bnp.bnpux.util;

public enum TimeZoneIDEnum {
	
	BC("Europe/Brussels"), 
	BH("Asia/Bangkok"), 
	KY("Asia/Krasnoyarsk"), 
	HH("Asia/Hong_Kong"),
	T4("Asia/Singapore"), 
	PE("Australia/Perth"), 
	TA("Asia/Taipei"),
	TO("Asia/Tokyo"), 
	SE("Asia/Seoul"), 
	YA("Asia/Yakutsk"), 
	AE("Australia/Adelaide"),
	DA("Australia/Darwin"),
	BB("Australia/Brisbane"), 
	SY("Australia/Sydney"), 
	PM("Pacific/Port_Moresby"), 
	HO("Australia/Hobart"),
	VV("Asia/Vladivostok"),
	NC("Etc/GMT-11"),
	WT("Pacific/Auckland"),
	MS("Etc/GMT-12"),
	NU("Pacific/Tongatapu"),
	WZ("Europe/Warsaw"),
	ID("Etc/GMT+12"),
	MI("Pacific/Midway"),
	HW("US/Hawaii"),
	AL("US/Alaska"),
	CF("America/Tijuana"),
	PT("US/Pacific"),
	MT("US/Mountain"),
	MN("America/Chihuahua"),
	ME("America/Chihuahua"),
	AA("US/Arizona"),
	SS("Canada/Saskatchewan"),
	MC("America/Mexico_City"),
	CM("US/Central"),
	IN("US/East-Indiana"),
	QB("America/Bogota"),
	CC("America/Caracas"),
	ST("America/Santiago"),
	LP("America/La_Paz"),
	AT("America/Glace_Bay"),
	NL("Canada/Newfoundland"),
	MV("America/Montevideo"),
	GL("America/Godthab"),
	BA("America/Buenos_Aires"),
	BS("America/Sao_Paulo"),
	AC("Etc/GMT+2"),
	CV("Atlantic/Cape_Verde"),
	AR("Atlantic/Azores"),
	CS("Africa/Casablanca"),
	UK("Europe/London"),
	RV("Africa/Monrovia"),
	SV("Europe/Amsterdam"),
	WC("Africa/Algiers"),
	MM("Asia/Amman"),
	BI("Europe/Athens"),
	BT("Asia/Beirut"),
	CO("Africa/Cairo"),
	HP("Africa/Harare"),
	JM("Asia/Jerusalem"),
	MK("Europe/Minsk"),
	WK("Africa/Windhoek"),
	BD("Asia/Baghdad"),
	KR("Asia/Kuwait"),
	VG("Europe/Moscow"),
	NA("Africa/Nairobi"),
	TB("Asia/Tbilisi"),
	TE("Asia/Tehran"),
	AB("Asia/Dubai"),
	BK("Asia/Baku"),
	SU("Asia/Yerevan"),
	PL("Indian/Mauritius"),
	YE("Asia/Yerevan"),
	KL("Asia/Kabul"),
	EG("Asia/Yekaterinburg"),
	IS("Asia/Karachi"),
	TT("Asia/Tashkent"),
	CH("Asia/Kolkata"),
	KU("Asia/Kathmandu"),
	AN("Asia/Almaty"),
	AD("Asia/Dhaka"),
	YN("Asia/Rangoon"),
	MG("Asia/Magadan"),
	IR("Asia/Irkutsk"),
	UB("Asia/Ulaanbaatar");

    private String id;

    TimeZoneIDEnum(String id) {
        this.id = id;
    }

    public String getName() {
    	return id;
    }
    

}
