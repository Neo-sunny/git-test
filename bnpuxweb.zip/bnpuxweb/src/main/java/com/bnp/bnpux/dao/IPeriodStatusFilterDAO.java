/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Period Status Filter Interface for Data Access Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 08 Mar 2017                skbhaska                                    		FO 10.0 - S30 - Holiday Calendar
 * 07 Jun 2017                banandha                                    		FO 10.0 - S3024 , S3023
************************************************************************************************************************************************************/
package com.bnp.bnpux.dao;

import java.util.List;
import java.util.Map;

import com.bnp.bnpux.vo.requestVO.PaymentOrderRequestVO;
import com.bnp.bnpux.vo.responseVO.PeriodStatusResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface IPeriodStatusFilterDAO {

	/**
	 * This method is for getting Period Status Filter
	 * 
	 * @param paramMap
	 * @return
	 */
	public List<PeriodStatusResponseVO> getPeriodStatusFilter(Map<String, Object> paramMap);
	
	/**
	 * This method is for getting Period Status Filter for Report
	 * 
	 * @param paramMap
	 * @return
	 */
	public List<PeriodStatusResponseVO> getPeriodStatusFilterReport(Map<String, Object> paramMap);
	
	/**
	 * This method is for getting OrgId for Branch Report
	 * 
	 * @param paramMap
	 * @return
	 */
	public List<PeriodStatusResponseVO> getOrgIdForBranchReport(Map<String, Object> paramMap);
	/**
	 * This method is for getting ByerSupplier OrgId for Aging Report when branch changed.
	 * 
	 * @param paramMap
	 * @return
	 */
	public List<PeriodStatusResponseVO> getBuyerSupplierOrgIDForBranchAgingReport(Map<String, Object> paramMap);
	
	/***
	 * This method is for getting the filter values for Holiday Calendar - FO 10.0 - S30 - Holiday Calendar
	 * @param requsetVO
	 * @return List<PeriodStatusResponseVO>
	 * @throws BNPApplicationException
	 */
	public void getPeriodStatusFilterHolidayCal(PaymentOrderRequestVO requsetVO);
	
	/**
	 * This method is for getting EventList for Branch in Email Inquiry Report
	 * 
	 * @param paramMap
	 * @return
	 */

	public List<PeriodStatusResponseVO> getEmailEventForBranchReport(Map<String, Object> filterMap);
	
	/**
	 * This method is for getting List for CounterParty Org ID in Settlement Due Reminder Report
	 * for selected Client Org Id
	 * @param paramMap
	 * @return 
	 */

	public List<PeriodStatusResponseVO> getCptyOrgIdForClientReport(Map<String, Object> filterMap);
	
	/**
	 * This method is for getting List for Plotting Params based on Limit Type for Limit Utilization Report
	 * for 
	 * @param paramMap
	 * @return 
	 */

	public List<PeriodStatusResponseVO> getPlotParamForLmtUtlReport(Map<String, Object> filterMap);
	
	
}
