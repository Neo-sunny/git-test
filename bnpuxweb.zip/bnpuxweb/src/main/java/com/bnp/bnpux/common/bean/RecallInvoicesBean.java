/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Recall Invoices Bean
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/

package com.bnp.bnpux.common.bean;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.bnp.scm.services.discounting.IDiscountRequestService;
import com.bnp.scm.services.invoice.IRecallInvoiceService;
import com.bnp.scm.services.invoice.vo.RecallInvoiceVO;
import com.bnp.bnpux.dao.IPaymentOrderDAO;
import com.bnp.bnpux.common.vo.PaymentOrderListVO;
/**
 * This Bean is Intended to have all the methods which are exposed to the XHTML
 * directly which includes actions like Recall,Approve,Undo and View Records in
 * Detail. The Validation from all the buttons is consolidated in the method
 * isValidRecordToProceedAction() Method , If any validation should be added
 * that should be added under this respective block and the validation and
 * displaying the Error message is not as per the conventional approach , The
 * error message and Success message should be be shown the Grid , so when the
 * validation is done if the action is valid for the selected Data , the method
 * returns "VALID RECORD", else the scope of the method returns the exact error
 * message which is appended in the message List and Shown in the Modal Pop.
 * Entitlement are handled through conventional approach through Abstract Bean.
 * 
 * The Class RecallInvoicesBean.
 */
@Component("recallInvoicesBean")
@Scope("request")
public class RecallInvoicesBean  {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The logger. */
	private static Logger LOGGER = LoggerFactory.getLogger(RecallInvoicesBean.class);


	

	
	/** The recall invoice service. */
	@Autowired
	private IRecallInvoiceService recallInvoiceService;
	
	/** The discount service. */
	@Autowired
	IDiscountRequestService discountService;

	@Autowired
	private IPaymentOrderDAO paymentOrderDAO;
	/** The auto suggestion map. */
	Map<String, Object> autoSuggestionMap = new HashMap<String, Object>();	
	
	/** The branch id list. */
	private List<NameValueVO> branchIdList;
	
	/** The payment staus list. */
	private List<NameValueVO> paymentStausList;
	
	/** The lot size. */
	private int lotSize;
	
	/** The page no. */
	private int pageNo;
	
	/** The is details page. */
	private boolean isDetailsPage = false;
	
	/** The dependent invoice list. */
	private List<RecallInvoiceVO> dependentInvoiceList;
	
	/** The dependent crd note list. */
	private List<RecallInvoiceVO> dependentCrdNoteList;
	
	/** The dependent crd note list. */
	private List<NameValueVO> mesagesList;
	
	/** The dependent crd note list. */
	private List<NameValueVO> auditList;
	
	/** The is has next record. */
	private boolean isHasNextRecord=false;
	
	/** The Supplier Org list. */
	private List<NameValueVO> supplierOrgIds;
	
	/** The Buyer Org list. */
	private List<NameValueVO> buyerOrgIds;
	
	/** The Action from Summary. */
	private boolean actionFromSummary=false;
	
	/** The is message pop up hidden. */
	private boolean showMessagePopUp = false;
	
	/**
	 * Gets the auto suggestion map.
	 *
	 * @return the auto suggestion map
	 */
	public Map<String, Object> getAutoSuggestionMap() {
		return autoSuggestionMap;
	}

	/**
	 * Sets the auto suggestion map.
	 *
	 * @param autoSuggestionMap the auto suggestion map
	 */
	public void setAutoSuggestionMap(Map<String, Object> autoSuggestionMap) {
		this.autoSuggestionMap = autoSuggestionMap;
	}
	
	/**
	 * Checks if is show message pop up.
	 *
	 * @return true, if is show message pop up
	 */
	public boolean isShowMessagePopUp() {
		return showMessagePopUp;
	}

	/**
	 * Sets the show message pop up.
	 *
	 * @param showMessagePopUp the new show message pop up
	 */
	public void setShowMessagePopUp(boolean showMessagePopUp) {
		this.showMessagePopUp = showMessagePopUp;
	}


	
	
	
	/**
	 * Gets the logger.
	 *
	 * @return the logger
	 */
	public Logger getLogger(){
	  return LOGGER;
	}
	
	/**
	 * _debug information.
	 *
	 * @param information the information
	 */
	public void _debugInformation(String information){
	  getLogger().debug(information);
	}
	
	/**
	 * Gets the payment staus list.
	 *
	 * @return the payment staus list
	 */
	public List<NameValueVO> getPaymentStausList() {
		return paymentStausList;
	}

	/**
	 * Sets the payment staus list.
	 *
	 * @param paymentStausList the new payment staus list
	 */
	public void setPaymentStausList(List<NameValueVO> paymentStausList) {
		this.paymentStausList = paymentStausList;
	}

	/**
	 * Gets the branch id list.
	 *
	 * @return the branch id list
	 */
	public List<NameValueVO> getBranchIdList() {
		return branchIdList;
	}

	/**
	 * Sets the branch id list.
	 *
	 * @param branchIdList the new branch id list
	 */
	public void setBranchIdList(List<NameValueVO> branchIdList) {
		this.branchIdList = branchIdList;
	}
	
	/**
	 * Gets the page no.
	 *
	 * @return the page no
	 */
	public int getPageNo() {
		return pageNo;
	}

	/**
	 * Sets the page no.
	 *
	 * @param pageNo the new page no
	 */
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}
	
	/**
	 * Gets the lot size.
	 *
	 * @return the lot size
	 */
	public int getLotSize() {
	  return lotSize;
	}

	/**
	 * Sets the lot size.
	 *
	 * @param lotSize the new lot size
	 */
	public void setLotSize(int lotSize) {
	  this.lotSize = lotSize;
	}

	/**
	 * Checks if is details page.
	 *
	 * @return true, if is details page
	 */
	public boolean isDetailsPage() {
	  return isDetailsPage;
	}

	/**
	 * Sets the details page.
	 *
	 * @param isDetailsPage the new details page
	 */
	public void setDetailsPage(boolean isDetailsPage) {
	  this.isDetailsPage = isDetailsPage;
	}

	/**
	 * Gets the dependent invoice list.
	 *
	 * @return the dependent invoice list
	 */
	public List<RecallInvoiceVO> getDependentInvoiceList() {
	  return dependentInvoiceList;
	}

	/**
	 * Sets the dependent invoice list.
	 *
	 * @param dependentInvoiceList the new dependent invoice list
	 */
	public void setDependentInvoiceList(List<RecallInvoiceVO> dependentInvoiceList) {
	  this.dependentInvoiceList = dependentInvoiceList;
	}

	/**
	 * Gets the dependent crd note list.
	 *
	 * @return the dependent crd note list
	 */
	public List<RecallInvoiceVO> getDependentCrdNoteList() {
	  return dependentCrdNoteList;
	}

	/**
	 * Sets the dependent crd note list.
	 *
	 * @param dependentCrdNoteList the new dependent crd note list
	 */
	public void setDependentCrdNoteList(List<RecallInvoiceVO> dependentCrdNoteList) {
	  this.dependentCrdNoteList = dependentCrdNoteList;
	}

	/**
	 * Gets the mesages list.
	 *
	 * @return the mesages list
	 */
	public List<NameValueVO> getMesagesList() {
		return mesagesList;
	}

	/**
	 * Sets the mesages list.
	 *
	 * @param mesagesList the new mesages list
	 */
	public void setMesagesList(List<NameValueVO> mesagesList) {
		this.mesagesList = mesagesList;
	}
	
	/**
	 * Gets the audit list.
	 *
	 * @return the audit list
	 */
	public List<NameValueVO> getAuditList() {
		return auditList;
	}

	/**
	 * Sets the audit list.
	 *
	 * @param auditList the new audit list
	 */
	public void setAuditList(List<NameValueVO> auditList) {
		this.auditList = auditList;
	}
	
	/**
	 * @return the isHasNextRecord
	 */
	public boolean isHasNextRecord() {
		return isHasNextRecord;
	}

	/**
	 * @param isHasNextRecord the isHasNextRecord to set
	 */
	public void setHasNextRecord(boolean isHasNextRecord) {
		this.isHasNextRecord = isHasNextRecord;
	}
	
	/**
	 * @return the getSupplierOrgIds
	 */
	public List<NameValueVO> getSupplierOrgIds() {
		return supplierOrgIds;
	}

	/**
	 * @param supplierOrgIds
	 */
	public void setSupplierOrgIds(List<NameValueVO> supplierOrgIds) {
		this.supplierOrgIds = supplierOrgIds;
	}

	/**
	 * @return the getBuyerOrgIds
	 */
	public List<NameValueVO> getBuyerOrgIds() {
		return buyerOrgIds;
	}

	/**
	 * @param buyerOrgIds
	 */
	public void setBuyerOrgIds(List<NameValueVO> buyerOrgIds) {
		this.buyerOrgIds = buyerOrgIds;
	}


	/**
	 * @return the actionFromSummary
	 */
	public boolean isActionFromSummary() {
		return actionFromSummary;
	}

	/**
	 * @param actionFromSummary
	 */
	public void setActionFromSummary(boolean actionFromSummary) {
		this.actionFromSummary = actionFromSummary;
	}

	/**
	 * View details from link.
	 *
	 * @return the string
	 * @throws ParseException 
	 */
	public RecallInvoiceVO viewDetailsFromLink(PaymentOrderListVO paymentOrderRecalleDetailsRequestVO) throws ParseException{
	  _debugInformation("Entering method viewDetailsFromLink() from RecallInvoicesBean");
	 // getSelectedList().clear();
	  //setCheckAll(false);
	  //setHasNextRecord(true);
	 // selectedData.setRowSelected(true);
	  //addSelectedData();
	  //setDetailsPage(true); dependentCrdNoteList,auditList,dependentInvoiceList
	  //System.out.println("inside bean"+paymentOrderRecalleDetailsRequestVO.getBuyerRefNoUnique());
	  List<PaymentOrderListVO> paymentOrderListtVO = new ArrayList<PaymentOrderListVO>();
	  paymentOrderListtVO.add(paymentOrderRecalleDetailsRequestVO);
	  List<RecallInvoiceVO> recallInvoiceVOLst = new ArrayList<RecallInvoiceVO>();
	  recallInvoiceVOLst = paymentOrderDAO.getRecallPaymentOrdersVO(paymentOrderListtVO);
	  
	  //System.out.println("recallInvoiceVOLst "+recallInvoiceVOLst);
	  
	  RecallInvoiceVO recallInvoiceVO1 = new RecallInvoiceVO();
	  if(recallInvoiceVOLst!=null && recallInvoiceVOLst.size()>0){
		  recallInvoiceVO1 = recallInvoiceVOLst.get(0);
	  }
	  
	 //System.out.println(recallInvoiceVO1.getBranchId());
	  
	 /* RecallInvoiceVO recallInvoiceVO = new RecallInvoiceVO();
	  recallInvoiceVO.setBranchId("EN0100001-ENTIL");
	  recallInvoiceVO.setSeller("paybuysell");
	  recallInvoiceVO.setBuyer("PAYBUY2");
	  recallInvoiceVO.setPymtStatus(" PENDING FOR RECALL APPROVAL ");
	  recallInvoiceVO.setPaymntRefNumber("PAYBUY2_INV_10054");
	  recallInvoiceVO.setCcy("INR");
	  recallInvoiceVO.setInvoiceNumber("PAYBUY2_INV_10054");
	  SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy"); 
	  recallInvoiceVO.setInvoiceIssDate(sdf.parse("Tue Sep 16 00:00:00 IST 2014"));
	  recallInvoiceVO.setDueDate(sdf.parse("Tue Jun 30 00:00:00 IST 2015"));
	  recallInvoiceVO.setPymtAmount(new BigDecimal("1200"));
	  recallInvoiceVO.setPymtId("1117250");
	  recallInvoiceVO.setRecallIWthoutApproval(false);
	  recallInvoiceVO.setFileUploadDate(sdf.parse("Thu May 14 11:26:22 IST 2015"));
	  recallInvoiceVO.setFileRef("22754");
	  recallInvoiceVO.setBuyerShortName("PAYBUY2");
	  recallInvoiceVO.setSupplierShortName("JS");
	  recallInvoiceVO.setRemPymntAmt(new BigDecimal("12000"));
	  recallInvoiceVO.setAvailableAmount(new BigDecimal("0"));*/
	  /*recallInvoiceVO.setInvoiceDueDate(sdf.parse("Tue Jun 30 00:00:00 IST 2015"));
	  recallInvoiceVO.setUpdateInvAmount(new BigDecimal("0"));
	  recallInvoiceVO.setBillType("BT");
	  recallInvoiceVO.setCrdnoteAmount(new BigDecimal("0"));
	  recallInvoiceVO.setInvType("Part of Payment");
	  recallInvoiceVO.setRecallIWthoutApproval(false);
	  recallInvoiceVO.setDependentPaymentId("1117250");
	  recallInvoiceVO.setDependentInvoiceId("2075410");
	  recallInvoiceVO.setDependentRecallStatus("Not Recalled");
	  recallInvoiceVO.setLinkedCreditNoteUtilAmount("0");
	  recallInvoiceVO.setDependentPaymentRefNoUnique("PAYBUY2_INV_10054~*~paybuysell~*~~*~");
	  recallInvoiceVO.setDependentInvoiceRefNoUnique("PAYBUY2_INV_10054~*~paybuysell~*~~*~");
	  recallInvoiceVO.setInvoiceAmountOutStanding("12000");
	  recallInvoiceVO.setSettlementAmountBalance("12000");
	  recallInvoiceVO.setSettlementAmount("12000");
	
	  recallInvoiceVO.setInvoiceTotalAmt(new BigDecimal("12000"));
	  

	  List<RecallInvoiceVO> dependentInvoicesList = new ArrayList<RecallInvoiceVO>();
	  dependentInvoicesList.add(recallInvoiceVO);
	  recallInvoiceVO.setDependentInvoicesList(dependentInvoicesList);*/
	  getRecallInvoiceScreen(recallInvoiceVO1);
	 // RecallInvoiceVO invoiceVO = getRecallInvoiceScreen(recallInvoiceVO); 
	 // enableDisableButtons(selectedData.getPymtStatus());
	  //_logAccessDetails(BNPConstants.ACTION_VIEW_DETAIL_FROM_LINK,recallInvoiceVO.getPymtId());
	  _debugInformation("Exit of method viewDetailsFromLink() from RecallInvoicesBean");
	  
	  
	  return recallInvoiceVO1;
	}
	
	/**
	 * Gets the recall invoice screen.
	 *
	 * @param recallInvoiceVO the recall invoice vo
	 * @return the recall invoice screen
	 */
	private void getRecallInvoiceScreen(RecallInvoiceVO recallInvoiceVO) {
	  _debugInformation("Entering method getRecallInvoiceScreen() from RecallInvoicesBean");
	  try {
		setDependentInvoiceList(recallInvoiceService.getDependentInvoice(recallInvoiceVO));
		setDependentCrdNoteList(recallInvoiceService.getDependentCrdNote(recallInvoiceVO));
		setAuditList(recallInvoiceService.getRecallAudutList(recallInvoiceVO));
	    recallInvoiceVO.setDependentInvoicesList(getDependentInvoiceList());
	    recallInvoiceVO.setAuditList(getAuditList());
	    recallInvoiceVO.setDependentCreditNotesList(getDependentCrdNoteList());
	    recallInvoiceVO.setPymtId(recallInvoiceVO.getPymtId());
	    recallInvoiceVO.setInvoiceTotalAmt(calculateTotalAmt(dependentInvoiceList,BNPConstants.SCF_INVOICE));
	    recallInvoiceVO.setCnTotalAmt(calculateTotalAmt(dependentCrdNoteList,BNPConstants.SCF_CN));
	    recallInvoiceVO.setAuditListSize(auditList.size());//R8.0 - UAT Defect Fix - CSCDEV-5725 
	  }catch (BNPApplicationException exception) {
		getLogger().error("Exception occured whil executing method getRecallInvoiceScreen()");
	   // displayErrorMessage(exception.getErrorCode());
	  }
	  _debugInformation("Exit of method getRecallInvoiceScreen() from RecallInvoicesBean");
	}
	
	
	/**
     * This is is used to calculate total amount for dependent invoice and credit note.
     *
     * @param inputList the input list
     * @param type the type
     * @return the big decimal
     */
    private BigDecimal calculateTotalAmt(List<RecallInvoiceVO> inputList, String type){
      _debugInformation("Entering Method calculateTotalAmt() from RecallInvoicesBean");
      _debugInformation("The recall Invoices ist from calculateTotalAmt() Method is "+inputList+ " of type "+type);
	  BigDecimal totalAmount = new BigDecimal(0);
	  if(BNPConstants.SCF_INVOICE.equals(type)){
	    for(RecallInvoiceVO reInvoiceVO:inputList){
		  if(reInvoiceVO.getInvAmount().compareTo(BigDecimal.ZERO) > 0) totalAmount = totalAmount.add(reInvoiceVO.getInvAmount());
		}
	  }else if(BNPConstants.SCF_CN.equals(type)){
	    for(RecallInvoiceVO reInvoiceVO:inputList){
		  if(reInvoiceVO.getUtilzAmount().compareTo(BigDecimal.ZERO) > 0) totalAmount = totalAmount.add(reInvoiceVO.getUtilzAmount());
		}
	  }
	  _debugInformation("The Total Calculated Amount from the type : "+type+ "is :: "+totalAmount);
	  _debugInformation("Exit of Method calculateTotalAmt() from RecallInvoicesBean");
	  return totalAmount;
	}
    

	


    
    
}

