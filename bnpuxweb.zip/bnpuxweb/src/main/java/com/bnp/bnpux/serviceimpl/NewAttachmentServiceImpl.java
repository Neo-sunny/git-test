/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     NewAttachment Service Implementation
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 
 *****************************************************************************************************************************************************************/
package com.bnp.bnpux.serviceimpl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.scm.services.common.vo.AttachmentVO;
import com.bnp.bnpux.constants.AttachmentConstants;
import com.bnp.scm.services.invoice.dao.ISCFAttachmentDAO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.bnpux.service.INewAttachmentService;
import com.bnp.bnpux.vo.requestVO.AttachmentRequestVO;
import com.bnp.bnpux.vo.responseVO.AttachmentResponseVO;

@Component
public class NewAttachmentServiceImpl implements INewAttachmentService {
	
	/**
	 * Logger log for AttachmentServiceImpl class
	 */
	public static final Logger log = LoggerFactory.getLogger(NewAttachmentServiceImpl.class);
	
	
	/**
	 * IAttachmentDAO attachmentDAO;
	 */
	@Autowired
	private ISCFAttachmentDAO attachmentDAO;
	

	/**
	 * This method is for downloading attachment
	 * 
	 * @param attachmentRequest
	 * @return AttachmentResponseVO
	 * @throws BNPApplicationException
	 * @see com.bnp.bnpux.service.INewAttachmentService#downloadSCFAttachment(com.bnp.bnpux.vo.requestVO.AttachmentRequestVO)
	 * @Description Download SCF Attachment
	 */
	@Override
	public AttachmentResponseVO downloadSCFAttachment(AttachmentRequestVO attachmentRequest) throws BNPApplicationException {
		AttachmentResponseVO attachmentresponse = null;
			try{
				
				AttachmentVO selectedFile = new AttachmentVO();
				Map<String,Object> attachDataMap = new HashMap<String, Object>();
				attachDataMap.put(AttachmentConstants.ATTACHMENT_FILE_NAME, attachmentRequest.getFileName());
				attachDataMap.put(AttachmentConstants.ATTACHMENT_SEQ_NO, attachmentRequest.getSeqNo());
				selectedFile.setFileName(attachmentRequest.getFileName());
				selectedFile.setAttSeqNo(attachmentRequest.getSeqNo());
				List<AttachmentVO> selectedFileList = attachmentDAO.getAttachmentDetailsforDownload(attachmentRequest.getFileName(),attachmentRequest.getSeqNo());
				if(selectedFileList != null){
					attachmentresponse = downLoadSingleSCFAttachment(selectedFileList);
				}
			}catch(Exception e){
				log.error(AttachmentConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL,e);
				throw new BNPApplicationException(AttachmentConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL);
			}
			return attachmentresponse;
	}
	
	/**
	 * This method is for downloading all attachment
	 *  
	 * @param attachmentRequest
	 * @return AttachmentResponseVO
	 * @throws BNPApplicationException
	 * @see com.bnp.bnpux.service.INewAttachmentService#downloadAllSCFAttachment(com.bnp.bnpux.vo.requestVO.AttachmentRequestVO)
	 * @Description download All SCF Attachment
	 */
	@Override
	public AttachmentResponseVO downloadAllSCFAttachment(
			AttachmentRequestVO attachmentRequest)
			throws BNPApplicationException {
		AttachmentResponseVO attachmentresponse = null;
		try{
			
			List<AttachmentVO> selectedFileList = new ArrayList<AttachmentVO>();
			/*Map<String,Object> attachDataMap = new HashMap<String, Object>();
			attachDataMap.put(AttachmentConstants.ATTACHMENT_TYPE, attachmentRequest.getType());
			attachDataMap.put(AttachmentConstants.ATTACHMENT_FILE_ID, attachmentRequest.getFileId());
			attachDataMap.put(AttachmentConstants.ATTACHMENT_REF_ID, attachmentRequest.getRefId());*/
			selectedFileList = attachmentDAO.getAllSCFAttachmentDetails(attachmentRequest.getFileId(), attachmentRequest.getRefId(), attachmentRequest.getType());
			if(selectedFileList != null && selectedFileList.size() > 0){
				attachmentresponse = downLoadAll(selectedFileList);
			}
		}catch(Exception e){
			log.error(AttachmentConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL,e);
			throw new BNPApplicationException(AttachmentConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL);
		}
		return attachmentresponse;
	}
	
	/**
	 * This method is for getting attachment details
	 * 
	 * @param attachmentRequest
	 * @return AttachmentResponseVO
	 * @throws BNPApplicationException
	 * @see com.bnp.bnpux.service.INewAttachmentService#getSCFAttachmentDetails(com.bnp.bnpux.vo.requestVO.AttachmentRequestVO)
	 * @Description get SCF Attachment Details
	 */
	@Override
	public AttachmentResponseVO getSCFAttachmentDetails(
			AttachmentRequestVO attachmentRequest)
			throws BNPApplicationException {
			AttachmentResponseVO attachmentResponseVO = new AttachmentResponseVO();
			try{
				if(attachmentRequest.getType() != null && !attachmentRequest.getType().isEmpty()){
					List<AttachmentVO> attachmentDetailList = new ArrayList<AttachmentVO>();
					Map<String,Object> attachDataMap = new HashMap<String, Object>();
					/*attachDataMap.put(AttachmentConstants.ATTACH_PK_ID, attachmentRequest.getAttachPkId());
					attachDataMap.put(AttachmentConstants.TYPE, attachmentRequest.getType());*/
					attachmentDetailList = attachmentDAO.getAttachmentDetails(attachmentRequest.getType(),attachmentRequest.getAttachPkId());
					
					if(attachmentDetailList!=null && !attachmentDetailList.isEmpty()){
						if(attachmentDetailList.size() >= 1){
							attachmentResponseVO.setSingleAttachment(false);
							attachmentResponseVO.setAttachmentList(attachmentDetailList);
							attachmentResponseVO.setAttachmentRefNO(attachmentDetailList.get(0).getRefNo());
							if(attachmentDetailList.get(0).getType().equalsIgnoreCase("P")){
								attachmentResponseVO.setAttachmentType("Payment");
							}else if(attachmentDetailList.get(0).getType().equalsIgnoreCase("I")){
								attachmentResponseVO.setAttachmentType("Invoice");
							}else if(attachmentDetailList.get(0).getType().equalsIgnoreCase("C")){
								attachmentResponseVO.setAttachmentType("Credit"); 
							}
						}/*else if(attachmentDetailList.size()==1){
							AttachmentVO selectedFile = new AttachmentVO();
							/*Map<String,Object> attachmntDataMap = new HashMap<String, Object>();
							attachmntDataMap.put(AttachmentConstants.ATTACHMENT_FILE_NAME, attachmentRequest.getFileName());
							attachmntDataMap.put(AttachmentConstants.ATTACHMENT_SEQ_NO, attachmentRequest.getSeqNo());*/
							/*selectedFile.setFileName(attachmentRequest.getFileName());
							selectedFile.setSeqNo(attachmentRequest.getSeqNo());
							List<AttachmentVO> selectedFileList = attachmentDAO.getAttachmentDetailsforDownload(selectedFile);
							if(selectedFileList != null){
								attachmentResponseVO = downLoadSingleSCFAttachment(selectedFileList);
								attachmentResponseVO.setSingleAttachment(true);
							}
						}*/
					}
				}
			}catch(DataAccessException exception){
				log.error(AttachmentConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL,exception);
				throw new BNPApplicationException(AttachmentConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL);
			}
			return attachmentResponseVO;
	}
	
	
	/**
	 * This method is for downloading single
	 * 
	 * @param selectedFileList
	 * @return AttachmentResponseVO
	 * @throws BNPApplicationException 
	 * @Description download Single SCF Attachment
	 */
	@Override
	public AttachmentResponseVO downLoadSingleSCFAttachment(List<AttachmentVO> selectedFileList)throws BNPApplicationException
	{
		AttachmentResponseVO attachmentresponse;
		try
		{
			List<AttachmentVO> listAttachmentDetails =  new ArrayList<AttachmentVO>(selectedFileList);
			attachmentresponse = downLoadAll(listAttachmentDetails);
		}
		catch (Exception e) {	
			log.error(AttachmentConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL,e);
			throw new BNPApplicationException(AttachmentConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL);
		}
		return attachmentresponse;
	}
	
	/**
	 * This method is for downloading all
	 * 
	 * @param listAttachmentDetails
	 * @return AttachmentResponseVO
	 * @throws BNPApplicationException 
	 * @Description downLoad All Attachment
	 */
	public AttachmentResponseVO downLoadAll(List<AttachmentVO> listAttachmentDetails)throws BNPApplicationException
	{
		AttachmentResponseVO attachmentresponse = new AttachmentResponseVO();
		try
		{
			log.debug("Entered downLoadAttachment");
			byte[] readBuff;	
			readBuff =compressFiles(listAttachmentDetails);
			attachmentresponse.setData(readBuff);
			attachmentresponse.setFileName(AttachmentConstants.SCF_FILE_NAME);
		}catch (Exception e) {
			log.error(AttachmentConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL,e);
			throw new BNPApplicationException(AttachmentConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL);
		}
		return attachmentresponse;
	}
	
	/**
	 * This method is for compressing files
	 * 
	 * @param listdownLoadAll
	 * @return byte[]
	 * @throws BNPApplicationException 
	 * @Description Compress List of Attachment
	 */
	public byte[] compressFiles(List<AttachmentVO> listdownLoadAll) 
	throws BNPApplicationException{

		ByteArrayOutputStream objbyteArrayStream = null;
		ZipOutputStream outputStream = null;
		byte[] objByteoutput = null;
		
		try{
			if(listdownLoadAll!=null && listdownLoadAll.size()>0){
				objbyteArrayStream = new ByteArrayOutputStream();
				outputStream = new ZipOutputStream(objbyteArrayStream);
				for ( int i = 0; i<listdownLoadAll.size();i++)
				{
					AttachmentVO objFileVO = listdownLoadAll.get(i);
					String fileName = objFileVO.getFileName();
					outputStream.putNextEntry(new ZipEntry(getFileName(fileName,i)));
					outputStream.write(objFileVO.getData());
					outputStream.closeEntry();
					objFileVO = null;
				}
				outputStream.finish();
				outputStream.flush();
				objByteoutput = objbyteArrayStream.toByteArray();

			}
		}
		catch (IOException ioe) {
			log.error(AttachmentConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL,ioe);
			throw new BNPApplicationException(AttachmentConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL);
		}
		finally
		{
			try{
				if(objbyteArrayStream!=null){
					objbyteArrayStream.close();
				}
				if(outputStream!=null)
				{
				outputStream.finish();
				outputStream.flush();
				outputStream.close();
				}
			}
			catch (IOException ioe) {
				log.error(AttachmentConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL,ioe);
				//throw new BNPApplicationException(AttachmentConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL);
			}
		}
		log.debug(" Exit compressFiles() ::::::::: ");
		return objByteoutput;
	}
	
	/**
	 * @param fileName
	 * @param num
	 * @return String
	 * @Description Get File Name
	 */
	private String getFileName(String fileName, int num){
		StringBuilder fileNameTemp = new StringBuilder(fileName);
		StringBuilder toAppend = new StringBuilder();
		toAppend.append("(").append(num+1).append(")");
		fileNameTemp.insert(fileName.length()-(fileName.length()-fileName.lastIndexOf(".")),toAppend);
		return fileNameTemp.toString();
	}
	
	/**
	 * @param objAttachVO
	 * @return byte[]
	 * @throws BNPApplicationException 
	 * @Description Compress Single File
	 */
	public byte[] compressSingleFile(AttachmentVO objAttachVO)throws BNPApplicationException
	{
		List<AttachmentVO> alSingleFileList =null;
		log.debug(" Entered compressSingleFile() ::::::::: AttachmentServiceImpl ");
		alSingleFileList =new ArrayList<AttachmentVO>();
		alSingleFileList.add(objAttachVO);
		log.debug(" Exit compressSingleFile() ::::::::: AttachmentServiceImpl");
		return compressFiles(alSingleFileList);
	}

	
}
