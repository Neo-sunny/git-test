package com.bnp.bnpux.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.common.vo.ViewScheduledReportListVO;
import com.bnp.bnpux.constants.ReportsConstant;
import com.bnp.bnpux.dao.IViewScheduledReportDAO;
import com.bnp.bnpux.service.IViewScheduledReportService;
import com.bnp.bnpux.vo.requestVO.ViewScheduledReportRequestVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@Component
public class ViewScheduledReportServiceImpl implements IViewScheduledReportService {

	public static final Logger LOGGER = LoggerFactory.getLogger(ViewScheduledReportServiceImpl.class);

	/**
	 * IViewScheduledReportDAO viewScheduledReportDAO;
	 */
	@Autowired
	private IViewScheduledReportDAO viewScheduledReportDAO;

	/**
	 * This method fetches view scheduled reports records
	 * @param viewScheduleRptRequestVO
	 * @return List<ReportVO>
	 * @throws BNPApplicationException
	 */
	@Override
	public List<ViewScheduledReportListVO> getViewScheduleRptDetails(
			ViewScheduledReportRequestVO viewScheduleRptRequestVO) throws BNPApplicationException {
		LOGGER.debug("Class: ViewScheduledReportServiceImpl,  method:getViewScheduleRptDetails  - Start");
		List<ViewScheduledReportListVO> reportList = new ArrayList<ViewScheduledReportListVO>();
		try {
			viewScheduledReportDAO.getViewScheduleRptDetails(viewScheduleRptRequestVO);

			reportList = (List<ViewScheduledReportListVO>) viewScheduleRptRequestVO.getViewScheduledReportList();
		} catch (DataAccessException exception) {
			LOGGER.error(ReportsConstant.EXCEPTION_UNABLE_TO_PROCES, exception);
			throw new BNPApplicationException(ReportsConstant.EXCEPTION_UNABLE_TO_PROCES);
		}
		LOGGER.debug("Class: ViewScheduledReportServiceImpl,  method:getViewScheduleRptDetails  - End");
		return reportList;
	}
	
	/**
	 * update Last Viewed column
	 * @param viewScheduleRptRequestVO
	 * @throws BNPApplicationException
	 */
	@Override
	public void updateLastViewed(ViewScheduledReportRequestVO viewScheduleRptRequestVO) throws BNPApplicationException {
		LOGGER.debug("Class: ViewScheduledReportServiceImpl,  updateLastViewed  - Start");
		try {
			
			viewScheduledReportDAO.updateLastViewed(viewScheduleRptRequestVO);
		} catch (DataAccessException exception) {
			LOGGER.error(ReportsConstant.EXCEPTION_UNABLE_TO_PROCES, exception);
			throw new BNPApplicationException(ReportsConstant.EXCEPTION_UNABLE_TO_PROCES);
		}
		LOGGER.debug("Class: ViewScheduledReportServiceImpl,  updateLastViewed  - End");
	}

}
