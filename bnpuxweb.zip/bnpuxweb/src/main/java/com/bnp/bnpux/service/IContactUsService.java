/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   23-Feb-2017 by AnubhaJ
 * 
 * Purpose:      Contact Us pop Up object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 23-Feb-2017				AnubhaJ												Created FO 10.0 S015,S016,S017
************************************************************************************************************************************************************/

package com.bnp.bnpux.service;

import java.util.List;
import java.util.Map;

import com.bnp.bnpux.common.vo.ContactUsVO;
import com.bnp.bnpux.common.vo.CountryFlagVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface IContactUsService {

	/**
	 * This method is for getting Location DropDown
	 * 
	 * @param 
	 * @return List<CountryVO>
	 * @throws BNPApplicationException
	 */
	public List<CountryFlagVO> fetchLocationDropDwn() throws BNPApplicationException;
	
	
	/**
	 * This method is for sending Contact Details
	 * 
	 * @param ContactUsVO
	 * @return ContactUsVO
	 * @throws BNPApplicationException
	 */
	public ContactUsVO sendContactUsDetails(ContactUsVO contactUsVO)throws BNPApplicationException;


	
}
