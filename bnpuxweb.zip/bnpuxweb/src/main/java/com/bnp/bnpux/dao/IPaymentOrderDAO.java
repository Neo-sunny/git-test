/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Payment Order Interface for Data Access Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 23-FEB-2017				Divyashri Subramaniam					Added new method getPDFpopupDetails for S001
 * 10 Mar 2017				Bala Murugan Elangovan					Advanced Filter Apply functionality implementation 
 * 01-JAN-2018				Bala Murugan Elangovan					Added new method validateDiscDateWithHoliday for S101001 as part of FO10.1 Sprint 2
************************************************************************************************************************************************************/
package com.bnp.bnpux.dao;

import java.util.List;
import java.util.Map;

import com.bnp.bnpux.common.vo.PaymentOrderAvailableamtCalloutVO;
import com.bnp.bnpux.common.vo.PaymentOrderCreditNoteLineItemVO;
import com.bnp.bnpux.common.vo.PaymentOrderInvoiceDetailsCallOutVO;
import com.bnp.bnpux.common.vo.PaymentOrderListDetailsVO;
import com.bnp.bnpux.common.vo.PaymentOrderListVO;
import com.bnp.bnpux.common.vo.PaymentOrderSummaryVO;
import com.bnp.bnpux.vo.requestVO.PaymentOrderPopupRequestVO;
import com.bnp.bnpux.vo.requestVO.PaymentOrderRequestVO;
import com.bnp.bnpux.vo.responseVO.PaymentOrderResponseVO;
import com.bnp.scm.services.discounting.vo.DiscountRequestVO;
import com.bnp.scm.services.invoice.vo.RecallInvoiceVO;

public interface IPaymentOrderDAO {

	/**
	 * This method is for getting Payment Order Summary
	 * 
	 * @param paramMap
	 * @return
	 */
	
	/*Modified below method for code review comments(HashMap to RequestVO  in service layer)*/
	/*List<PaymentOrderSummaryVO> getPaymentOrderSummary(Map<String, Object> paramMap);*/
	
	List<PaymentOrderSummaryVO> getPaymentOrderSummary(PaymentOrderRequestVO paymentOrderRequestVO);
	
	/**
	 * This method is for getting Payment Order summary with Advanced Filters 
	 * @param paymentOrderRequestVO
	 * @return
	 */
	List<PaymentOrderSummaryVO> getPaymentOrderSummaryWithAdvFilter(PaymentOrderRequestVO paymentOrderRequestVO);
	
	
	/**
	 * This method is for getting Count of records fetched
	 * @param paymentOrderRequestVO
	 * @return
	 */
	List<PaymentOrderSummaryVO> getAdvFilterIndicatorCount(PaymentOrderRequestVO paymentOrderRequestVO);

	/**
	 * This method is for getting Payment Order List
	 * 
	 * @param paramMap
	 * @return
	 */
	/* Modified below method for code review comments(HashMap to RequestVO  in service layer)*/
	/*List<PaymentOrderListVO> getPaymentOrderList(Map<String, Object> paramMap);*/
	
	List<PaymentOrderListVO> getPaymentOrderList(PaymentOrderRequestVO paymentOrderRequestVO);
	
	/**
	 * This method is for getting Payment Order List with Advanced Filters 
	 * @param paymentOrderRequestVO
	 * @return
	 */
	List<PaymentOrderListVO> getPaymentOrderListWithAdvFilter(PaymentOrderRequestVO paymentOrderRequestVO);
	
	/**
	 * This method is for getting Payment Order List Details
	 * 
	 * @param paramMap
	 * @return
	 */
	/*Modified below method for code review comments(HashMap to RequestVO  in service layer)*/
	/*List<PaymentOrderListDetailsVO> getPaymentOrderListDetails(Map<String, Object> paramMap);*/
	
	List<PaymentOrderListDetailsVO> getPaymentOrderListDetails(PaymentOrderRequestVO paymentOrderRequestVO);
	
	/**
	 * This method is for getting Discount Request
	 * 
	 * @param paymentOrderListtVO
	 * @return
	 */
	List<DiscountRequestVO> getDiscountRequestVO(List<PaymentOrderListVO> paymentOrderListtVO);
	
	/**
	 * This method is for getting Payment Order Credit Note Line Item details
	 * 
	 * @param paramMap
	 * @return
	 */
	PaymentOrderCreditNoteLineItemVO getPaymentOrderCreditNoteLineItemdetails(Map<String, Object> paramMap);
	
	/**
	 * This method is for getting Payment Order Invoice Details Callout
	 * 
	 * @param paramMap
	 * @return
	 */
	PaymentOrderInvoiceDetailsCallOutVO getPaymentOrderInvoiceDetailsCallout(Map<String, Object> paramMap);

	/**
	 * This method is for getting Payment Order Available Amount Callout Details
	 * 
	 * @param paymentOrderAvailableamtCalloutVO
	 * @return
	 */
	PaymentOrderAvailableamtCalloutVO getPaymentOrderAvailableAmtCalloutDetals(PaymentOrderAvailableamtCalloutVO paymentOrderAvailableamtCalloutVO);
	
	// Added For User Stories - Recall - Starts
	/**
	 * This method is for getting Recall Payment Orders
	 * 
	 * @param paymentOrderListtVO
	 * @return
	 */
	List<RecallInvoiceVO> getRecallPaymentOrdersVO(List<PaymentOrderListVO> paymentOrderListtVO);
	// Added For User Stories - Recall - Ends

	/**
	 * This method is for Payment Order Popup details - S001
	 * 
	 * @param PaymentOrderPopupRequestVO
	 * @return void
	 */
	void getPDFpopupDetails(PaymentOrderPopupRequestVO paymentOrderPopupRequestVO);

	/**
	 * This method is for getting pending Approval Count 
	 * @return
	 */
	public int getPendAppovalCnt(String pmtId);

	/**
	 * Method is used to validate discount date with corresponding holiday
	 * @param paymentOrderRequestVO
	 */
	void validateDiscDateWithHoliday(PaymentOrderRequestVO paymentOrderRequestVO);
	
	/**
	 * Method is used to check currency holiday flag enabled or not
	 * @param paymentOrderRequestVO
	 * @return List<PaymentOrderResponseVO>
	 */
	List<PaymentOrderResponseVO> checkCurrencyHolidayEnabled(PaymentOrderRequestVO paymentOrderRequestVO);

}
