package com.bnp.bnpux.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.constants.ReportsConstant;
import com.bnp.bnpux.dao.IRemittanceReportDAO;
import com.bnp.bnpux.service.IRemittanceReportService;
import com.bnp.bnpux.vo.requestVO.RemittanceRequestVO;
import com.bnp.bnpux.vo.responseVO.RemittanceResponseVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@Component
public class RemittanceReportServiceImpl implements IRemittanceReportService{
	
	@Autowired
	private IRemittanceReportDAO remittanceReportDAO;
	
	/**
	 * Logger log for LimitUtilizationReportServiceImpl class
	 */
	private static final Logger log = LoggerFactory.getLogger(RemittanceReportServiceImpl.class);
	
	/**
	 * Constant for Exception message
	 */
	public static final String EXCEPTION_UNABLE_TO_PROCESS = "Unable to process action - Database Exception";
	
	@Override
	public RemittanceRequestVO getReportDetails(RemittanceRequestVO requestVo) throws BNPApplicationException {
		try{
			remittanceReportDAO.getReportList(requestVo);
			List<RemittanceResponseVO> remistRes = requestVo.getRemittDetailList();
			if("DTL_GRIDS".equals(requestVo.getGetWhat()) && remistRes != null && remistRes.size() >0){
				for (RemittanceResponseVO responsvO : remistRes){
					if("DISC".equals(responsvO.getGridName())){
						requestVo.getRemittDiscList().add(responsvO);
					}else if("CN_UTIL".equals(responsvO.getGridName())){
						requestVo.getRemittCnList().add(responsvO);
					}else if("INV_DTL".equals(responsvO.getGridName())){
						requestVo.getRemitInvList().add(responsvO);
					}else if("MATURITY_PYMT".equals(responsvO.getGridName())){
						requestVo.getRemitMatList().add(responsvO);
					}
				}
			}
		}catch(Exception exception){
			log.error(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS);
		}
		return requestVo;
	}

		@Override
	public List<ReportChartResponseVO> getReportChartAxis(RemittanceRequestVO requestVo)
			throws BNPApplicationException {
		List<ReportChartResponseVO> reportVOList = new ArrayList<ReportChartResponseVO>();
		try{
			remittanceReportDAO.getChartAxis(requestVo);
			reportVOList = (List<ReportChartResponseVO>) requestVo.getRemittChartData();
		}catch(Exception exception){
			log.error(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS);
		}
		return reportVOList;
	}
	@Override
	public RemittanceRequestVO getReportSummary(RemittanceRequestVO requestVo) throws BNPApplicationException {
		try{
			remittanceReportDAO.getReportSummary(requestVo);
		}catch(Exception exception){
			log.error(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS);
		}
		return requestVo;	}

}
