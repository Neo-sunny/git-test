/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Create User Interface for Data Access Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.dao;

import java.util.List;

import com.bnp.scm.services.common.vo.NameValueVO;

/**
 * The Interface ICreateUserDAO.
 */
public interface ICreateUserDAO 
{

	/**
	 * This method is for populating preference language list
	 * 
	 * @return
	 */
	List<NameValueVO> populatePrefLanguageList();

	/**
	 * This method is for populating country list
	 * 
	 * @return
	 */
	List<NameValueVO> populateCountryList();
	
}
