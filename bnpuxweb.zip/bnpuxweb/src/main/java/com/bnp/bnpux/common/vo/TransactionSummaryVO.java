/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Transaction Summary Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;
import java.util.Date;

public class TransactionSummaryVO {
	
	private String buyerOrgId;
	
	private String buyerOrgName;
	
	private String sellerOrgId;
	
	private String sellerOrgName;
	
	private String currencyCode;
	
	private BigDecimal supplierBalAmt;	
	
	private String recordCount;
	
	private Date paymentDate;
	
	private String rowNo;
	
	private String rowCnt;
	
	private String bandRecordCount;
	
	private String leadOrgId;
	
	private int decimalPoint;

	public String getBuyerOrgId() {
		return buyerOrgId;
	}

	public void setBuyerOrgId(String buyerOrgId) {
		this.buyerOrgId = buyerOrgId;
	}

	public String getBuyerOrgName() {
		return buyerOrgName;
	}

	public void setBuyerOrgName(String buyerOrgName) {
		this.buyerOrgName = buyerOrgName;
	}

	public String getSellerOrgId() {
		return sellerOrgId;
	}

	public void setSellerOrgId(String sellerOrgId) {
		this.sellerOrgId = sellerOrgId;
	}

	public String getSellerOrgName() {
		return sellerOrgName;
	}

	public void setSellerOrgName(String sellerOrgName) {
		this.sellerOrgName = sellerOrgName;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public BigDecimal getSupplierBalAmt() {
		return supplierBalAmt;
	}

	public void setSupplierBalAmt(BigDecimal supplierBalAmt) {
		this.supplierBalAmt = supplierBalAmt;
	}

	public String getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(String recordCount) {
		this.recordCount = recordCount;
	}

	public String getRowNo() {
		return rowNo;
	}

	public void setRowNo(String rowNo) {
		this.rowNo = rowNo;
	}

	public Date getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getRowCnt() {
		return rowCnt;
	}

	public void setRowCnt(String rowCnt) {
		this.rowCnt = rowCnt;
	}

	public String getBandRecordCount() {
		return bandRecordCount;
	}

	public void setBandRecordCount(String bandRecordCount) {
		this.bandRecordCount = bandRecordCount;
	}

	public String getLeadOrgId() {
		return leadOrgId;
	}

	public void setLeadOrgId(String leadOrgId) {
		this.leadOrgId = leadOrgId;
	}

	public int getDecimalPoint() {
		return decimalPoint;
	}

	public void setDecimalPoint(int decimalPoint) {
		this.decimalPoint = decimalPoint;
	}
	
	/**
	 * Getter methods introduced to send the amounts as
	 * String to avoid amount > 16 digits getting truncated
	 * Added as part of defect Fix CSC-7835
	 */
	
	public String getSupplierBalAmtStr() {
		return (supplierBalAmt!=null)?supplierBalAmt.toPlainString():"";
	}
	
	
}
