/**
 * 
 */
package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author banandha
 *
 */
public class AgingRptDetails {
	private String poRefNo;
	private String docStatus;
	private Date maturityDate;
	private String finBank;
	private BigDecimal payableAmt;
	private BigDecimal outStdAmt;
	private String InvRefNumber;
	private BigDecimal InvAmt;
	private String AddRef;
	private Date IssueDate;
	private String cnRefNo;
	private Date utilizedDate;
	private String docRefNo;
	private String utilizedType;
	private String utilizedAmt;
	private String agingType;
	private String currencyCd;
	private BigDecimal orgAmt;
	private String expandAllowed;
	private String deicmalPnt;
	
	
	
	/**
	 * @return the poRefNo
	 */
	public String getPoRefNo() {
		return poRefNo;
	}
	/**
	 * @param poRefNo the poRefNo to set
	 */
	public void setPoRefNo(String poRefNo) {
		this.poRefNo = poRefNo;
	}
	/**
	 * @return the docStatus
	 */
	public String getDocStatus() {
		return docStatus;
	}
	/**
	 * @param docStatus the docStatus to set
	 */
	public void setDocStatus(String docStatus) {
		this.docStatus = docStatus;
	}
	/**
	 * @return the maturityDate
	 */
	public Date getMaturityDate() {
		return maturityDate;
	}
	/**
	 * @param maturityDate the maturityDate to set
	 */
	public void setMaturityDate(Date maturityDate) {
		this.maturityDate = maturityDate;
	}
	/**
	 * @return the finBank
	 */
	public String getFinBank() {
		return finBank;
	}
	/**
	 * @param finBank the finBank to set
	 */
	public void setFinBank(String finBank) {
		this.finBank = finBank;
	}
	/**
	 * @return the payableAmt
	 */
	public BigDecimal getPayableAmt() {
		return payableAmt;
	}
	/**
	 * @param payableAmt the payableAmt to set
	 */
	public void setPayableAmt(BigDecimal payableAmt) {
		this.payableAmt = payableAmt;
	}
	/**
	 * @return the outStdAmt
	 */
	public BigDecimal getOutStdAmt()
	{
		return outStdAmt;
	}
	/**
	 * @param outStdAmt the outStdAmt to set
	 */
	public void setOutStdAmt(BigDecimal outStdAmt) {
		this.outStdAmt = outStdAmt;
	}
	/**
	 * @return the invRefNumber
	 */
	public String getInvRefNumber() {
		return InvRefNumber;
	}
	/**
	 * @param invRefNumber the invRefNumber to set
	 */
	public void setInvRefNumber(String invRefNumber) {
		InvRefNumber = invRefNumber;
	}
	/**
	 * @return the invAmt
	 */
	public BigDecimal getInvAmt() {
		return InvAmt;
	}
	/**
	 * @param invAmt the invAmt to set
	 */
	public void setInvAmt(BigDecimal invAmt) {
		InvAmt = invAmt;
	}
	/**
	 * @return the addRef
	 */
	public String getAddRef() {
		return AddRef;
	}
	/**
	 * @param addRef the addRef to set
	 */
	public void setAddRef(String addRef) {
		AddRef = addRef;
	}
	/**
	 * @return the issueDate
	 */
	public Date getIssueDate() {
		return IssueDate;
	}
	/**
	 * @param issueDate the issueDate to set
	 */
	public void setIssueDate(Date issueDate) {
		IssueDate = issueDate;
	}
	/**
	 * @return the cnRefNo
	 */
	public String getCnRefNo() {
		return cnRefNo;
	}
	/**
	 * @param cnRefNo the cnRefNo to set
	 */
	public void setCnRefNo(String cnRefNo) {
		this.cnRefNo = cnRefNo;
	}
	/**
	 * @return the utilizedDate
	 */
	public Date getUtilizedDate() {
		return utilizedDate;
	}
	/**
	 * @param utilizedDate the utilizedDate to set
	 */
	public void setUtilizedDate(Date utilizedDate) {
		this.utilizedDate = utilizedDate;
	}
	/**
	 * @return the docRefNo
	 */
	public String getDocRefNo() {
		return docRefNo;
	}
	/**
	 * @param docRefNo the docRefNo to set
	 */
	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}
	/**
	 * @return the utilizedType
	 */
	public String getUtilizedType() {
		return utilizedType;
	}
	/**
	 * @param utilizedType the utilizedType to set
	 */
	public void setUtilizedType(String utilizedType) {
		this.utilizedType = utilizedType;
	}
	/**
	 * @return the utilizedAmt
	 */
	public String getUtilizedAmt() {
		return utilizedAmt;
	}
	/**
	 * @param utilizedAmt the utilizedAmt to set
	 */
	public void setUtilizedAmt(String utilizedAmt) {
		this.utilizedAmt = utilizedAmt;
	}
	/**
	 * @return the agingType
	 */
	public String getAgingType() {
		return agingType;
	}
	/**
	 * @param agingType the agingType to set
	 */
	public void setAgingType(String agingType) {
		this.agingType = agingType;
	}
	/**
	 * @return the currencyCd
	 */
	public String getCurrencyCd() {
		return currencyCd;
	}
	/**
	 * @param currencyCd the currencyCd to set
	 */
	public void setCurrencyCd(String currencyCd) {
		this.currencyCd = currencyCd;
	}
	/**
	 * @return the orgAmt
	 */
	public BigDecimal getOrgAmt() {
		return orgAmt;
	}
	/**
	 * @param orgAmt the orgAmt to set
	 */
	public void setOrgAmt(BigDecimal orgAmt) {
		this.orgAmt = orgAmt;
	}
	/**
	 * @return the expandAllowed
	 */
	public String getExpandAllowed() {
		return expandAllowed;
	}
	/**
	 * @param expandAllowed the expandAllowed to set
	 */
	public void setExpandAllowed(String expandAllowed) {
		this.expandAllowed = expandAllowed;
	}
	/**
	 * @return the deicmalPnt
	 */
	public String getDeicmalPnt() {
		return deicmalPnt;
	}
	/**
	 * @param deicmalPnt the deicmalPnt to set
	 */
	public void setDeicmalPnt(String deicmalPnt) {
		this.deicmalPnt = deicmalPnt;
	}
	
	
	public String getPayableAmtStr() {
		return (payableAmt != null)?payableAmt.toPlainString():"";
	}
	
	public String getOutStdAmtStr() {
		return (outStdAmt != null)?outStdAmt.toPlainString():"";
	}
	
	public String getInvAmtStr() {
		return (InvAmt != null)?InvAmt.toPlainString():"";
	}
	
	public String getOrgAmtStr() {
		return (orgAmt != null)?orgAmt.toPlainString():"";
	}
	
}
