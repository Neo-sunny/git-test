/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  21 June 2017
 * 
 * Purpose:      Limit Utilization Report Details VO 
 * 
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 21 June 2017       Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/

package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;
import java.util.Date;

public class LimitUtilizationReportDetailsVO {

	private String errorMessage;
	
	
	
	private BigDecimal gridNo;
	
	private String cltOrgId;
	
	private String cltOrgName;
	
	private String convCcy;
	
	private String limitType;
	
	private String groupId;
	
	private String tpBankId;
	
	private String tpBankName;
	
	private String orgId;
	
	private String erpId;
	
	private String partyName;
	
	private String limitCcy;
	
	private String indicativeConversionRate;
	
	private BigDecimal grantedLimit;
	
	private BigDecimal utilizedLimit;
	
	private BigDecimal availableLimit;
	
	private BigDecimal indicativeEffectiveAvailableLimit;
	
	private BigDecimal grantedLimitEqui;
	
	private BigDecimal utilizedLimitEqui;
	
	private BigDecimal availableLimitEqui;
	
	private BigDecimal indicativeEffectiveAvailableLimitEqui;
	
	private int decimalPoint;
	
	private int decimalPointEqui;
	

	public int getDecimalPointEqui() {
		return decimalPointEqui;
	}

	public void setDecimalPointEqui(int decimalPointEqui) {
		this.decimalPointEqui = decimalPointEqui;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public int getDecimalPoint() {
		return decimalPoint;
	}

	public void setDecimalPoint(int decimalPoint) {
		this.decimalPoint = decimalPoint;
	}

	public String getLimitCcy() {
		return limitCcy;
	}

	public void setLimitCcy(String limitCcy) {
		this.limitCcy = limitCcy;
	}

	public String getIndicativeConversionRate() {
		return indicativeConversionRate;
	}

	public void setIndicativeConversionRate(String indicativeConversionRate) {
		this.indicativeConversionRate = indicativeConversionRate;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getTpBankId() {
		return tpBankId;
	}

	public void setTpBankId(String tpBankId) {
		this.tpBankId = tpBankId;
	}

	public String getTpBankName() {
		return tpBankName;
	}

	public void setTpBankName(String tpBankName) {
		this.tpBankName = tpBankName;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getErpId() {
		return erpId;
	}

	public void setErpId(String erpId) {
		this.erpId = erpId;
	}

	public String getPartyName() {
		return partyName;
	}

	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}


	public BigDecimal getGridNo() {
		return gridNo;
	}

	public void setGridNo(BigDecimal gridNo) {
		this.gridNo = gridNo;
	}

	public BigDecimal getGrantedLimit() {
		return grantedLimit;
	}

	public void setGrantedLimit(BigDecimal grantedLimit) {
		this.grantedLimit = grantedLimit;
	}

	public BigDecimal getUtilizedLimit() {
		return utilizedLimit;
	}

	public void setUtilizedLimit(BigDecimal utilizedLimit) {
		this.utilizedLimit = utilizedLimit;
	}

	public BigDecimal getAvailableLimit() {
		return availableLimit;
	}

	public void setAvailableLimit(BigDecimal availableLimit) {
		this.availableLimit = availableLimit;
	}

	public BigDecimal getIndicativeEffectiveAvailableLimit() {
		return indicativeEffectiveAvailableLimit;
	}

	public void setIndicativeEffectiveAvailableLimit(BigDecimal indicativeEffectiveAvailableLimit) {
		this.indicativeEffectiveAvailableLimit = indicativeEffectiveAvailableLimit;
	}

	public BigDecimal getGrantedLimitEqui() {
		return grantedLimitEqui;
	}

	public void setGrantedLimitEqui(BigDecimal grantedLimitEqui) {
		this.grantedLimitEqui = grantedLimitEqui;
	}

	public BigDecimal getUtilizedLimitEqui() {
		return utilizedLimitEqui;
	}

	public void setUtilizedLimitEqui(BigDecimal utilizedLimitEqui) {
		this.utilizedLimitEqui = utilizedLimitEqui;
	}

	public BigDecimal getAvailableLimitEqui() {
		return availableLimitEqui;
	}

	public void setAvailableLimitEqui(BigDecimal availableLimitEqui) {
		this.availableLimitEqui = availableLimitEqui;
	}

	public BigDecimal getIndicativeEffectiveAvailableLimitEqui() {
		return indicativeEffectiveAvailableLimitEqui;
	}

	public void setIndicativeEffectiveAvailableLimitEqui(BigDecimal indicativeEffectiveAvailableLimitEqui) {
		this.indicativeEffectiveAvailableLimitEqui = indicativeEffectiveAvailableLimitEqui;
	}

	public String getCltOrgId() {
		return cltOrgId;
	}

	public void setCltOrgId(String cltOrgId) {
		this.cltOrgId = cltOrgId;
	}

	public String getCltOrgName() {
		return cltOrgName;
	}

	public void setCltOrgName(String cltOrgName) {
		this.cltOrgName = cltOrgName;
	}

	public String getConvCcy() {
		return convCcy;
	}

	public void setConvCcy(String convCcy) {
		this.convCcy = convCcy;
	}

	public String getLimitType() {
		return limitType;
	}

	public void setLimitType(String limitType) {
		this.limitType = limitType;
	}
	
	/**
	 * Getter methods introduced to send the amounts as
	 * String to avoid amount > 16 digits getting truncated
	 * Added as part of defect Fix CSC-7835
	 */
	
	public String getGrantedLimitStr()
	{
		return (grantedLimit != null)?grantedLimit.toPlainString():"";
	}
	
	public String getUtilizedLimitStr()
	{
		return (utilizedLimit != null)?utilizedLimit.toPlainString():"";
	}
	
	public String getAvailableLimitStr()
	{
		return (availableLimit != null)?availableLimit.toPlainString():"";
	}
	
	public String getIndicativeEffectiveAvailableLimitStr()
	{
		return (indicativeEffectiveAvailableLimit != null)?indicativeEffectiveAvailableLimit.toPlainString():"";
	}
	
	public String getGrantedLimitEquiStr()
	{
		return (grantedLimitEqui != null)?grantedLimitEqui.toPlainString():"";
	}
	
	public String getUtilizedLimitEquiStr()
	{
		return (utilizedLimitEqui != null)?utilizedLimitEqui.toPlainString():"";
	}
	
	public String getAvailableLimitEquiStr()
	{
		return (availableLimitEqui != null)?availableLimitEqui.toPlainString():"";
	}
	
	public String getIndicativeEffectiveAvailableLimitEquiStr()
	{
		return (indicativeEffectiveAvailableLimitEqui != null)?indicativeEffectiveAvailableLimitEqui.toPlainString():"";
	}

}
