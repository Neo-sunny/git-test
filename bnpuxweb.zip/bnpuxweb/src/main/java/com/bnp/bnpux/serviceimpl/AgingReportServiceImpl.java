/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   21 June 2017
 * 
 * Purpose:      Credit Note Inquiry Report Service Implementation
 * 
 * Change History:
 *  
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 21 June 2017       Ratna Gokhale, Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.common.vo.AgingRptDetails;
import com.bnp.bnpux.constants.ScreenConstants;
import com.bnp.bnpux.dao.IAgingReportDAO;
import com.bnp.bnpux.service.IAgingReportService;
import com.bnp.bnpux.vo.requestVO.AgingRequestVO;
import com.bnp.bnpux.vo.responseVO.AgingResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@Component
public class AgingReportServiceImpl implements IAgingReportService{

	@Autowired
	private IAgingReportDAO agingReportDAO;
	
	/**
	 * Logger log for CreditNoteInqServiceImpl class
	 */
	private static final Logger log = LoggerFactory.getLogger(AgingReportServiceImpl.class);
	
	/**
	 * Constant for Exception message
	 */
	public static final String EXCEPTION_UNABLE_TO_PROCESS = "Unable to process action - Database Exception";	
	
	/* (non-Javadoc)
	 * @see com.bnp.bnpux.service.IAgingReportService#getReportList(com.bnp.bnpux.vo.requestVO.AgingRequestVO)
	 */
	@Override
	public AgingResponseVO getReportList(AgingRequestVO agingReqVO)
			throws BNPApplicationException {
		AgingResponseVO agingResponseVO = new AgingResponseVO(); 
		try{			
			
			if(ScreenConstants.AGING_RPT_SUMMARY.equalsIgnoreCase(agingReqVO.getViewType())) {
				agingReportDAO.getReportSummary(agingReqVO);
				if(agingReqVO.getAgingRptSummaryList() != null) {
					agingResponseVO.setAgingRptSummaryList(agingReqVO.getAgingRptSummaryList());
					
				}
			} else if(ScreenConstants.AGING_RPT_LIST.equalsIgnoreCase(agingReqVO.getViewType())) {
				agingReportDAO.getReportList(agingReqVO);
				if(agingReqVO.getAgingRptSummaryList() != null && agingReqVO.getAgingRptSummaryList().size() >0 ) {
					agingResponseVO.setAgingRptList(agingReqVO.getAgingRptSummaryList());
				}
			} else if(ScreenConstants.AGING_RPT_PO_DETAIL.equalsIgnoreCase(agingReqVO.getViewType())) {
				agingReportDAO.getReportListDetails(agingReqVO);
				if(agingReqVO.getAgingRptDetailsList() != null) {
					
					List<AgingRptDetails> agingPORptList = new ArrayList<AgingRptDetails>();
					
					
					for(AgingRptDetails agingRptDetails : agingReqVO.getAgingRptDetailsList() ){
						if(agingRptDetails.getAgingType().equalsIgnoreCase("PO_GRID")){
							agingPORptList.add(agingRptDetails);
						  }
						}
					agingResponseVO.setAgingRptPODetailsList(agingPORptList);	
				}
				
			}  else if(ScreenConstants.AGING_RPT_INV_CN_DETAIL.equalsIgnoreCase(agingReqVO.getViewType())) {
				agingReportDAO.getReportListDetails(agingReqVO);
				if(agingReqVO.getAgingRptDetailsList() != null) {
					
					List<AgingRptDetails> agingInvRptList = new ArrayList<AgingRptDetails>();
					List<AgingRptDetails> agingCNRptList = new ArrayList<AgingRptDetails>();
					
					
					for(AgingRptDetails agingRptDetails : agingReqVO.getAgingRptDetailsList() ){
						if(agingRptDetails.getAgingType().equalsIgnoreCase("INV_GRID")){
							agingInvRptList.add(agingRptDetails);
							
						  }else if(agingRptDetails.getAgingType().equalsIgnoreCase("CN_GRID")){
							  agingCNRptList.add(agingRptDetails);
							
						  }
						}
					agingResponseVO.setAgingRptCNDetailsList(agingCNRptList);
					agingResponseVO.setAgingRptInvDetailsList(agingInvRptList);
				}
				
			} 
			
			if(agingReqVO.getErrorMsg() != null){				
				log.error(EXCEPTION_UNABLE_TO_PROCESS + agingReqVO.getErrorMsg());
				//throw new BNPApplicationException(EXCEPTION_UNABLE_TO_PROCESS);	
			}
			
			
		} catch(DataAccessException exception) {
			log.error(EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(EXCEPTION_UNABLE_TO_PROCESS);	
		}
		return agingResponseVO;
	}
	
}