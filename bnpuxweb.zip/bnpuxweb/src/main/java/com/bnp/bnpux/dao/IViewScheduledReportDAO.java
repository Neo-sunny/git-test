package com.bnp.bnpux.dao;

import com.bnp.bnpux.vo.requestVO.ViewScheduledReportRequestVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface IViewScheduledReportDAO {
	/**
	 * This method fetches view scheduled reports records from DB
	 * @param viewScheduleRptRequestVO
	 * @return	ViewScheduledReportRequestVO
	 */
	ViewScheduledReportRequestVO getViewScheduleRptDetails(ViewScheduledReportRequestVO viewScheduleRptRequestVO);
	/**
	 * update Last Viewed column
	 * @param viewScheduleRptRequestVO
	 * @throws BNPApplicationException
	 */
	void updateLastViewed(ViewScheduledReportRequestVO viewScheduleRptRequestVO) throws BNPApplicationException;
	
}
