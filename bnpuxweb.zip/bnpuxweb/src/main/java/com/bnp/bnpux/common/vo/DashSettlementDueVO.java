package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;
import java.util.Date;

public class DashSettlementDueVO {

	private String currency;
	
	private BigDecimal amount;
	
	private String invoiceCount;
	
	private Date recordDate;
	
	private int decimalPoint;
	
	private String relationship;
	
	private String bandRecordCount;
	
	private Date dueDate;
	
	private String band;
	
	private String buyerOrgId;
	
	private String supplierOrgId;
	
	private String docType;
	
	private String overdueTodayInd;
	
	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getBuyerOrgId() {
		return buyerOrgId;
	}

	public void setBuyerOrgId(String buyerOrgId) {
		this.buyerOrgId = buyerOrgId;
	}

	public String getSupplierOrgId() {
		return supplierOrgId;
	}

	public void setSupplierOrgId(String supplierOrgId) {
		this.supplierOrgId = supplierOrgId;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public String getBandRecordCount() {
		return bandRecordCount;
	}

	public void setBandRecordCount(String bandRecordCount) {
		this.bandRecordCount = bandRecordCount;
	}

	public String getBand() {
		return band;
	}

	public void setBand(String band) {
		this.band = band;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public int getDecimalPoint() {
		return decimalPoint;
	}

	public void setDecimalPoint(int decimalPoint) {
		this.decimalPoint = decimalPoint;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getInvoiceCount() {
		return invoiceCount;
	}

	public void setInvoiceCount(String invoiceCount) {
		this.invoiceCount = invoiceCount;
	}

	
	public String getOverdueTodayInd() {
		return overdueTodayInd;
	}

	public void setOverdueTodayInd(String overdueTodayInd) {
		this.overdueTodayInd = overdueTodayInd;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public Date getRecordDate() {
		return recordDate;
	}

	public void setRecordDate(Date recordDate) {
		this.recordDate = recordDate;
	}

	/**
	 * Getter methods introduced to send the amounts as
	 * String to avoid amount > 16 digits getting truncated
	 * Added as part of defect Fix CSC-7835
	**/
	
	public String getAmountStr() {
		return (amount != null)?amount.toPlainString():"";
	}
	
	
}
