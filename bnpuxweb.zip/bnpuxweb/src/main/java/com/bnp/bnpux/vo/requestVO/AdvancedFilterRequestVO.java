/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   02-Mar-2017
 * 
 * Purpose:      Advanced Filter Request VO
 * 
 * Change History:
 *  
 * Date                       Author                                            Reason
 * 02-Mar-2017				BELANGOV					Base version for Advanced filter Request VO 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.requestVO;

import java.util.Date;
import java.util.List;

import com.bnp.bnpux.common.vo.AdvancedFilterVO;


public class AdvancedFilterRequestVO {
	
	private String userId;
	
	private String userTypeId;
	
	private String screenName;
	
	private String errorFlag;

	private String periodCategory;
	
	private Date sysdate;
	
	private String branchId;
	
	List<AdvancedFilterVO> advancedFilterList;
	
	List<AdvancedFilterVO> periodDateList;
	
	private Date periodFromDate;
	
	private Date periodToDate;
	
	private String filterId;
	
	private String filterName;
	
	private String operatorId;
	
	private String operatorName;
	
	private String filterFromValue;
	
	private String filterToValue;
	
	private String filterElementId;
	
	private String filterElementValue;
	
	
	
	
	private List<AdvancedFilterVO> userFilterObject;
	
	private String getWhat;
	
	
		
	public List<AdvancedFilterVO> getUserFilterObject() {
		return userFilterObject;
	}

	public void setUserFilterObject(List<AdvancedFilterVO> userFilterObject) {
		this.userFilterObject = userFilterObject;
	}

	public String getFilterId() {
		return filterId;
	}

	public void setFilterId(String filterId) {
		this.filterId = filterId;
	}

	public String getFilterName() {
		return filterName;
	}

	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}

	public String getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(String operatorId) {
		this.operatorId = operatorId;
	}

	public String getOperatorName() {
		return operatorName;
	}

	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}

	public String getFilterFromValue() {
		return filterFromValue;
	}

	public void setFilterFromValue(String filterFromValue) {
		this.filterFromValue = filterFromValue;
	}

	public String getFilterToValue() {
		return filterToValue;
	}

	public void setFilterToValue(String filterToValue) {
		this.filterToValue = filterToValue;
	}

	public String getFilterElementId() {
		return filterElementId;
	}

	public void setFilterElementId(String filterElementId) {
		this.filterElementId = filterElementId;
	}

	public String getFilterElementValue() {
		return filterElementValue;
	}

	public void setFilterElementValue(String filterElementValue) {
		this.filterElementValue = filterElementValue;
	}

	
	public String getGetWhat() {
		return getWhat;
	}

	public void setGetWhat(String getWhat) {
		this.getWhat = getWhat;
	}

	public Date getPeriodFromDate() {
		return periodFromDate;
	}

	public void setPeriodFromDate(Date periodFromDate) {
		this.periodFromDate = periodFromDate;
	}

	public Date getPeriodToDate() {
		return periodToDate;
	}

	public void setPeriodToDate(Date periodToDate) {
		this.periodToDate = periodToDate;
	}

	public List<AdvancedFilterVO> getPeriodDateList() {
		return periodDateList;
	}

	public void setPeriodDateList(List<AdvancedFilterVO> periodDateList) {
		this.periodDateList = periodDateList;
	}

	public String getPeriodCategory() {
		return periodCategory;
	}

	public void setPeriodCategory(String periodCategory) {
		this.periodCategory = periodCategory;
	}

	public Date getSysdate() {
		return sysdate;
	}

	public void setSysdate(Date sysdate) {
		this.sysdate = sysdate;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public String getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	public List<AdvancedFilterVO> getAdvancedFilterList() {
		return advancedFilterList;
	}

	public void setAdvancedFilterList(List<AdvancedFilterVO> advancedFilterList) {
		this.advancedFilterList = advancedFilterList;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserTypeId() {
		return userTypeId;
	}

	public void setUserTypeId(String userTypeId) {
		this.userTypeId = userTypeId;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}
	
	
	
	
}
