package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;
import java.util.List;
import com.bnp.scm.services.discounting.vo.LimitUtilReportTreeVO;

public class LimitUtilDetailReportVO {
	
	private String limitType;
	
	private BigDecimal blockedAmountPtg;
	
	private BigDecimal utilizedAmountPtg;
	
	private BigDecimal availableAmountPtg;
	
	private List<String> orgIdWithShortName;
	
	private LimitUtilReportTreeVO limitUtilReportTreeVO;

	public String getLimitType() {
		return limitType;
	}

	public void setLimitType(String limitType) {
		this.limitType = limitType;
	}

	public BigDecimal getBlockedAmountPtg() {
		return blockedAmountPtg;
	}

	public void setBlockedAmountPtg(BigDecimal blockedAmountPtg) {
		this.blockedAmountPtg = blockedAmountPtg;
	}

	public BigDecimal getUtilizedAmountPtg() {
		return utilizedAmountPtg;
	}

	public void setUtilizedAmountPtg(BigDecimal utilizedAmountPtg) {
		this.utilizedAmountPtg = utilizedAmountPtg;
	}

	public BigDecimal getAvailableAmountPtg() {
		return availableAmountPtg;
	}

	public void setAvailableAmountPtg(BigDecimal availableAmountPtg) {
		this.availableAmountPtg = availableAmountPtg;
	}

	public LimitUtilReportTreeVO getLimitUtilReportTreeVO() {
		return limitUtilReportTreeVO;
	}

	public void setLimitUtilReportTreeVO(LimitUtilReportTreeVO limitUtilReportTreeVO) {
		this.limitUtilReportTreeVO = limitUtilReportTreeVO;
	}

	public List<String> getOrgIdWithShortName() {
		return orgIdWithShortName;
	}

	public void setOrgIdWithShortName(List<String> orgIdWithShortName) {
		this.orgIdWithShortName = orgIdWithShortName;
	}
	
}
