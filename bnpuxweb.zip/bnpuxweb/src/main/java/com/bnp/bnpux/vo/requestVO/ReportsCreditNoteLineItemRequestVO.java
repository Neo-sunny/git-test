package com.bnp.bnpux.vo.requestVO;

import java.util.List;

import com.bnp.bnpux.common.vo.ReportsCreditNoteLineItemVO;

public class ReportsCreditNoteLineItemRequestVO {
	private int cnt_id;
	private String error_msg;
	private List<ReportsCreditNoteLineItemVO> reportsCreditNoteLineItemVO;
	public String getError_msg() {
		return error_msg;
	}

	public void setError_msg(String error_msg) {
		this.error_msg = error_msg;
	}

	public int getCnt_id() {
		return cnt_id;
	}

	public void setCnt_id(int cnt_id) {
		this.cnt_id = cnt_id;
	}

	public List<ReportsCreditNoteLineItemVO> getReportsCreditNoteLineItemVO() {
		return reportsCreditNoteLineItemVO;
	}

	public void setReportsCreditNoteLineItemVO(List<ReportsCreditNoteLineItemVO> reportsCreditNoteLineItemVO) {
		this.reportsCreditNoteLineItemVO = reportsCreditNoteLineItemVO;
	}

}
