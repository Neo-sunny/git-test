/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   29 Mar 2017	
 * 
 * Purpose:       Buyer Acceptance screen
 * 
 * Change History: 
 * Date                       Author                                    Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 29 Mar 2017			      kmanimar					                Initial Version - FO 10.0 - S2098
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.responseVO;

import java.util.List;

import com.bnp.bnpux.common.vo.BaAttachmentListVO;
import com.bnp.bnpux.common.vo.BuyerAcceptanceListVO;
import com.bnp.bnpux.common.vo.BuyerAcceptanceSummaryVO;
import com.bnp.bnpux.common.vo.StatusDetailsVO;
import com.bnp.bnpux.vo.errorMessageVO.ErrorMessageVO;

public class BuyerAcceptanceResponseVO {

	private String errorMsg;
	private List<BuyerAcceptanceSummaryVO> buyerAcceptanceSummaryVOList;
	private List<BuyerAcceptanceListVO> buyerAcceptanceListVOList; 
	private List<BaAttachmentListVO> baAttachmentListVO;
	private List<StatusDetailsVO> statusDet;
	private List<ErrorMessageVO> errMessageVO;
	private String fileName;
	private byte[] data;
	
	public String getErrorMsg() {
		return errorMsg;
	}
	public List<BuyerAcceptanceListVO> getBuyerAcceptanceListVOList() {
		return buyerAcceptanceListVOList;
	}
	public void setBuyerAcceptanceListVOList(List<BuyerAcceptanceListVO> buyerAcceptanceListVOList) {
		this.buyerAcceptanceListVOList = buyerAcceptanceListVOList;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public List<BuyerAcceptanceSummaryVO> getBuyerAcceptanceSummaryVOList() {
		return buyerAcceptanceSummaryVOList;
	}
	public void setBuyerAcceptanceSummaryVOList(List<BuyerAcceptanceSummaryVO> buyerAcceptanceSummaryVOList) {
		this.buyerAcceptanceSummaryVOList = buyerAcceptanceSummaryVOList;
	}
	public List<StatusDetailsVO> getStatusDet() {
		return statusDet;
	}
	public void setStatusDet(List<StatusDetailsVO> statusDet) {
		this.statusDet = statusDet;
	}
	public List<BaAttachmentListVO> getBaAttachmentListVO() {
		return baAttachmentListVO;
	}
	public void setBaAttachmentListVO(List<BaAttachmentListVO> baAttachmentListVO) {
		this.baAttachmentListVO = baAttachmentListVO;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public byte[] getData() {
		return data;
	}
	public void setData(byte[] data) {
		this.data = data;
	}
	/**
	 * @return the errMessageVO
	 */
	public List<ErrorMessageVO> getErrMessageVO() {
		return errMessageVO;
	}
	/**
	 * @param errMessageVO the errMessageVO to set
	 */
	public void setErrMessageVO(List<ErrorMessageVO> errMessageVO) {
		this.errMessageVO = errMessageVO;
	}
	
	
}
