/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      User Controller
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.common.vo.CountryFlagVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.service.IUserService;
import com.bnp.bnpux.util.ImageUtil;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private IUserService userService;
	
	private static final Logger log = LoggerFactory.getLogger(UserController.class);
	
		
	/**
	 * This method is for getting User Info
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "cotdtls.rest", method = RequestMethod.GET)
	public List<Map<String,String>> getUserInfo(HttpServletRequest request)
	{
		HttpSession session = request.getSession();
		UserInfoVO user = (UserInfoVO) session.getAttribute("userInfo");
		log.debug("User details "+user);
		List<Map<String,String>> cotMap = null;
		if(user != null)
		{
			cotMap = userService.getCoTRemaniningTime(user.getBranchList(),user.getOrgId());
			log.debug("User details MAP"+cotMap);
		}
		
		
		return cotMap;
	}
	
	/**
	 * This method is for getting Country Flag
	 * 
	 * @param cc
	 * @param request
	 * @param response
	 */
	@RequestMapping("cntryflag.img")
	public void getCountryFlag(@RequestParam("cc") String cc,HttpServletRequest request,HttpServletResponse response)
	{
		byte [] img;
		CountryFlagVO flag = userService.getCountryFlag(cc);
		if(flag != null && flag.getCountryFlg() != null)
		{
			img = flag.getCountryFlg();
		}
		else
		{
			String imgPath = request.getSession().getServletContext().getRealPath("images/hh.png");
			
			img = ImageUtil.getOrgLogo(imgPath);	
		}
		
		
		
		//response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
		response.setContentType("image/png");
		response.setContentLength((img !=null)?img.length:0);
	    try {
			response.getOutputStream().write(img);
			 response.getOutputStream().close();
		} catch (IOException e) {
			log.error(e.getMessage(),e);
		}
	}
}
