/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14-March-2017
 * 
 * Purpose:      File Management Controller
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 14-March-2017			Sree Reshmi						                  Initial Version
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.common.vo.ReleaseFileMgmtResponseVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.constants.FileMgmtConstants;
import com.bnp.bnpux.service.IAuditService;
import com.bnp.bnpux.service.IFileMgmtService;
import com.bnp.bnpux.util.CommonUtil;
import com.bnp.bnpux.util.RequestIdentityValidator;
import com.bnp.bnpux.vo.requestVO.FileMgmtRequestVO;
import com.bnp.bnpux.vo.requestVO.ReleaseFileMgmtRequestVO;
import com.bnp.bnpux.vo.responseVO.FileMgmtResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;


@RestController
@RequestMapping("/fileMgmtCtrl")
public class FileMgmtController {

	/**
	 * Logger for FileMgmtController
	 */
	public static final Logger log = LoggerFactory.getLogger(FileMgmtController.class);

	/**
	 * Autowired Interface IFileMgmtService
	 */
	@Autowired
	private IFileMgmtService fileMgmtService;

	@Autowired
	RequestIdentityValidator validateRequest;
	
	@Autowired
	private IAuditService auditService;
	
	@Autowired 
	private CommonUtil commonUtil;

	/**
	 * This method is for getting the File Management Details
	 * 
	 * @param fileMgmtRequestVO
	 * @return
	 */
	@RequestMapping(value = "getFileManagementDetails.rest", method = RequestMethod.POST)
	public FileMgmtResponseVO getFileManagementDetails(@RequestBody FileMgmtRequestVO fileMgmtRequestVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		FileMgmtResponseVO fileMgmtResponseVO = new FileMgmtResponseVO();
		try {
			boolean requestValidatedFlag = validateRequest.validate(fileMgmtRequestVO.getUserId(), httpServletRequest.getSession());
			if (requestValidatedFlag) {
				fileMgmtResponseVO = fileMgmtService.getFileManagementDetails(fileMgmtRequestVO);
			} else {
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (BNPApplicationException exception) {
			fileMgmtResponseVO.setErrorMsg(exception.getMessage());
			log.error(exception.getMessage(), exception);
		}
		return fileMgmtResponseVO;
	}
	
	/**
	 * This method is for getting the File Management Details
	 * 
	 * @param fileMgmtRequestVO
	 * @return
	 */
	@RequestMapping(value = "getAdvancedFilterIndicatorCount.rest", method = RequestMethod.POST)
	public FileMgmtResponseVO getAdvancedFilterIndicatorCount(@RequestBody FileMgmtRequestVO fileMgmtRequestVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		FileMgmtResponseVO fileMgmtResponseVO = new FileMgmtResponseVO();
		try {
			boolean requestValidatedFlag = validateRequest.validate(fileMgmtRequestVO.getUserId(), httpServletRequest.getSession());
			if (requestValidatedFlag) {
				fileMgmtResponseVO = fileMgmtService.getAdvancedFilterCount(fileMgmtRequestVO);
			} else {
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (BNPApplicationException exception) {
			fileMgmtResponseVO.setErrorMsg(exception.getMessage());
			log.error(exception.getMessage(), exception);
		}
		return fileMgmtResponseVO;
	}


	/**
	 * This method triggers the Undo action for the File Upload  
	 * 
	 * @param ReleaseFileMgmtRequestVO
	 * @return ReleaseFileMgmtResponseVO
	 */
	@RequestMapping(value = "undoFileUploadRequest.rest", method = RequestMethod.POST)
	public ReleaseFileMgmtResponseVO undoFileUploadRequest(@RequestBody ReleaseFileMgmtRequestVO releaseFileMgmtRequestVo, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		log.debug("In filkemanagement Controller - enters");
		ReleaseFileMgmtResponseVO releaseFileResponseVO = new ReleaseFileMgmtResponseVO();		
		UserInfoVO user = commonUtil.getUserVoFromSession(httpServletRequest); 	
		
		try {
				boolean requestValidatedFlag = validateRequest.validate(releaseFileMgmtRequestVo.getUserId(), httpServletRequest.getSession());
				if (requestValidatedFlag) {
				releaseFileResponseVO = fileMgmtService.undoFileUploadRequest(releaseFileMgmtRequestVo , user);			

				auditService.insertAuditLog(commonUtil.constructAuditVo(user , FileMgmtConstants.FILE_UNDO_REQUEST));
				
				}else {
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
				
		} catch (BNPApplicationException exception) {
			
			commonUtil.addReleaseFileMgmtResponseVO(null, exception.getErrorMessage(), true, releaseFileResponseVO);			
			log.error(exception.getMessage(), exception);
		}
		log.debug("In filkemanagement Controller - exits");
		return releaseFileResponseVO;
	}
	

	/**
	 * This method triggers the Release action for the File Upload  
	 * 
	 * @param ReleaseFileMgmtRequestVO
	 * @return ReleaseFileMgmtResponseVO
	 */
	@RequestMapping(value = "releaseFileUploadRequest.rest", method = RequestMethod.POST)
	public ReleaseFileMgmtResponseVO releaseFileUploadRequest(@RequestBody ReleaseFileMgmtRequestVO releaseFileMgmtRequestVo, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		log.debug("In filkemanagement Controller - enters");
		ReleaseFileMgmtResponseVO releaseFileResponseVO = new ReleaseFileMgmtResponseVO();
		UserInfoVO user = commonUtil.getUserVoFromSession(httpServletRequest); 	
		
		try {
				boolean requestValidatedFlag = validateRequest.validate(releaseFileMgmtRequestVo.getUserId(), httpServletRequest.getSession());
				if (requestValidatedFlag) {
					releaseFileResponseVO = fileMgmtService.releaseFileUploadRequest(releaseFileMgmtRequestVo ,user);
					
					auditService.insertAuditLog(commonUtil.constructAuditVo(user , FileMgmtConstants.FILE_RELEASE_REQUEST));
					
				}else {
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
		} catch (BNPApplicationException exception) {

			commonUtil.addReleaseFileMgmtResponseVO(null, exception.getErrorMessage(), true, releaseFileResponseVO);			
			log.error(exception.getMessage(), exception);
		}
		log.debug("In filkemanagement Controller - exits");
		return releaseFileResponseVO;
	}
	
	/**
	 * @param releaseFileMgmtRequestVO
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @return
	 */
	@RequestMapping(value="authorizeRecords.rest", method = RequestMethod.POST)
	public ReleaseFileMgmtResponseVO authorizeRecords(@RequestBody ReleaseFileMgmtRequestVO releaseFileMgmtRequestVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse)
	{
		ReleaseFileMgmtResponseVO releaseFileMgmtResponseVO = new ReleaseFileMgmtResponseVO();
		UserInfoVO user = commonUtil.getUserVoFromSession(httpServletRequest); 
		try
		{
			boolean requestValidatedFlag = validateRequest.validate(releaseFileMgmtRequestVO.getUserId(), httpServletRequest.getSession());
			if (requestValidatedFlag) {
				releaseFileMgmtResponseVO = fileMgmtService.authorizeFileUploadRequest(releaseFileMgmtRequestVO, user);
				auditService.insertAuditLog(commonUtil.constructAuditVo(user , FileMgmtConstants.FILE_AUTHORIZE_REQUEST));
			}
			else{
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		}
		catch(BNPApplicationException e){
			commonUtil.addReleaseFileMgmtResponseVO(null, e.getErrorMessage(), true, releaseFileMgmtResponseVO);			
			log.error(e.getMessage(), e);
		}
		return releaseFileMgmtResponseVO;
	}
	
	@RequestMapping(value="rejectRecords.rest", method=RequestMethod.POST)
	public ReleaseFileMgmtResponseVO rejectRecords(@RequestBody ReleaseFileMgmtRequestVO releaseFileMgmtRequestVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse)
	{
		ReleaseFileMgmtResponseVO releaseFileMgmtResponseVO = new ReleaseFileMgmtResponseVO();
		UserInfoVO user = commonUtil.getUserVoFromSession(httpServletRequest);
		boolean requestValidated;
		try{
			requestValidated = validateRequest.validate(releaseFileMgmtRequestVO.getUserId(), httpServletRequest.getSession());
			if(requestValidated)
			{
				releaseFileMgmtResponseVO = fileMgmtService.rejectFile(releaseFileMgmtRequestVO, user);
				auditService.insertAuditLog(commonUtil.constructAuditVo(user, FileMgmtConstants.FILE_REJECT_REQUEST));
			}
			else
			{
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		}catch(BNPApplicationException e)
		{
			commonUtil.addReleaseFileMgmtResponseVO(null, e.getErrorMessage(), true, releaseFileMgmtResponseVO);
			log.error(e.getErrorMessage());
		}
		return releaseFileMgmtResponseVO;
	}
	/**
	 * This method is for getting the File Management Details
	 * 
	 * @param fileMgmtRequestVO
	 * @return
	 */
	@RequestMapping(value = "getAttachmentList.rest", method = RequestMethod.POST)
	public FileMgmtResponseVO getAttachmentList(@RequestBody FileMgmtRequestVO fileMgmtRequestVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		FileMgmtResponseVO fileMgmtResponseVO = new FileMgmtResponseVO();
		try {
			boolean requestValidatedFlag = validateRequest.validate(fileMgmtRequestVO.getUserId(), httpServletRequest.getSession());
			if (requestValidatedFlag) {
				fileMgmtResponseVO = fileMgmtService.getAttachmentList(fileMgmtRequestVO);
				if(!FileMgmtConstants.FILE_MANAGMENT_ATTACHEMENT_DTL.equals(fileMgmtRequestVO.getGetWhat())){
					httpServletResponse.setHeader("Content-Disposition","attachment;filename=\"" + FileMgmtConstants.SCF_FILE_NAME + "\"");				
					try {
						httpServletResponse.getOutputStream().write(fileMgmtResponseVO.getData());
						httpServletResponse.getOutputStream().close();
					} catch (IOException e) {
						log.error(e.getMessage(),e);
					}
				}
			} else {
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (BNPApplicationException exception) {
			fileMgmtResponseVO.setErrorMsg(exception.getMessage());
			log.error(exception.getMessage(), exception);
		}
		return fileMgmtResponseVO;
	}
	
}