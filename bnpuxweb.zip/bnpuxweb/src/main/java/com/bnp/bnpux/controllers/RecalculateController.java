/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Recalculate Controller
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.common.vo.PaymentOrderListCollectionVO;
import com.bnp.bnpux.common.vo.PaymentOrderListVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.constants.PaymentOrderConstants;
import com.bnp.bnpux.discounting.service.ISearchDiscountRequestsService;
import com.bnp.bnpux.service.IAuditService;
import com.bnp.bnpux.util.RequestIdentityValidator;
import com.bnp.bnpux.vo.requestVO.AuditRequestVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.discounting.vo.DiscountChargesVO;
import com.bnp.scm.services.discounting.vo.DiscountRequestVO;


@RestController
@RequestMapping("/recalculateCtrl")
public class RecalculateController {

	/**
	 * Logger log for TransactionController class
	 */
	public static final Logger log = LoggerFactory.getLogger(RecalculateController.class);

	
	@Autowired
	private ISearchDiscountRequestsService discRecalService;
	
	
	@Autowired
	private IAuditService auditService;
	
	@Autowired
	RequestIdentityValidator validateRequest;
	
	DiscountRequestVO voObj = new DiscountRequestVO (); 

	/**
	 * This method is for getting the Recalculate Details
	 * 
	 * @param paymentOrderListVO
	 * @param request
	 * @param response
	 * @return
	 * @throws BNPApplicationException
	 */
	@RequestMapping(value = "getRecalculate.rest", method = RequestMethod.POST)
	public DiscountRequestVO getRecalculateDetails(@RequestBody PaymentOrderListCollectionVO paymentOrderListCollectionVO,HttpServletRequest request,HttpServletResponse response) throws BNPApplicationException{
		HttpSession session = request.getSession();
		DiscountRequestVO discountVo = new DiscountRequestVO();
		try {
			boolean requestValidatedFlag = validateRequest.validate(paymentOrderListCollectionVO.getUserId(),session);
			if(requestValidatedFlag && paymentOrderListCollectionVO.getPaymentOrderListCollection().size() == 1){
				UserInfoVO user = (UserInfoVO) session.getAttribute("userInfo");
				user.setSessionId((String) session.getAttribute("USER_AUTH_TOKEN"));
				discountVo = discRecalService.getDiscRequestVO(paymentOrderListCollectionVO.getPaymentOrderListCollection().get(0));
				AuditRequestVO auditVo = new AuditRequestVO();
				auditVo.setUserId(user.getUserId());
				auditVo.setSessionId(user.getSessionId());
				auditVo.setFuncId(PaymentOrderConstants.DISCOUNT_RECALCULATE);
				auditVo.setOrgId(user.getOrgId());
				auditService.insertAuditLog(auditVo);
			}
			else{
				discountVo = null;
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (Exception exception) {
			response.setHeader("isError", "true");			
			log.error(exception.getMessage(),exception);
			throw new BNPApplicationException();
		}
		return discountVo;
	}
	
}
