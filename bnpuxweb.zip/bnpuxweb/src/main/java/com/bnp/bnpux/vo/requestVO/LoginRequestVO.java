/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   07 Apr 2016
 * 
 * Purpose:     Login Request VO
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 11 Apr 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 * 14 Dec 2017			  	  		Rameshwar Khedekar							  							  FO 10.0.2- CSC 8692: Existing pin validation, disable certificate logic 
 *****************************************************************************************************************************************************************/

package com.bnp.bnpux.vo.requestVO;

public class LoginRequestVO {
	
	private String userid;
	private String password;
	
	//Added for FO 10.0.2- CSC 8692:
	private String pinSuccess;
	private String pinSuccessMesg;
	
	//Added for FO 10.0.2- CSC 8693:
	private String userCertHashKey;
	
	
	public String getUserCertHashKey() {
		return userCertHashKey;
	}
	public void setUserCertHashKey(String userCertHashKey) {
		this.userCertHashKey = userCertHashKey;
	}
	public String getPinSuccess() {
		return pinSuccess;
	}
	public void setPinSuccess(String pinSuccess) {
		this.pinSuccess = pinSuccess;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPinSuccessMesg() {
		return pinSuccessMesg;
	}
	public void setPinSuccessMesg(String pinSuccessMesg) {
		this.pinSuccessMesg = pinSuccessMesg;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	

}
