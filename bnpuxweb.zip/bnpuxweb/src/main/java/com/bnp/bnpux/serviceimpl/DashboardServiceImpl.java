/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   19-Aug-2017
 * 
 * Purpose:      Dashboard Service Implementation
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 19-Aug-2017				Divyashri S								To hold the service impl methods for Dashboard
************************************************************************************************************************************************************/
package com.bnp.bnpux.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.bnp.bnpux.common.vo.DashbrdPendingActionListVO;
import com.bnp.bnpux.common.vo.DashbrdPendingActionResultVO;
import com.bnp.bnpux.common.vo.DashbrdPendingActionSummaryVO;
import com.bnp.bnpux.dao.IDashboardLimitUtilReportDAO;
import com.bnp.bnpux.service.IDashboardService;
import com.bnp.bnpux.vo.requestVO.DashPendingActRequestVO;
import com.bnp.bnpux.vo.requestVO.LimitUtilReportResponseVO;
import com.bnp.bnpux.vo.requestVO.RequestParamVO;
import com.bnp.scm.services.common.vo.NameValueVO;

@Component
public class DashboardServiceImpl implements IDashboardService{
	
	public static final Logger log = LoggerFactory.getLogger(DashboardServiceImpl.class);
	
	@Autowired
	private IDashboardLimitUtilReportDAO dashboardLimitUtilReportDAO;
	
	@Override
	public LimitUtilReportResponseVO getPendingActionDetails(DashPendingActRequestVO dashPendingActRequestVO){
		LimitUtilReportResponseVO limitUtilReportResponseVO = new LimitUtilReportResponseVO();
		List<DashbrdPendingActionSummaryVO> pendingActionDetailsList = new ArrayList<DashbrdPendingActionSummaryVO>();
		try{
			dashboardLimitUtilReportDAO.getPendingActionDetails(dashPendingActRequestVO);
			List<DashbrdPendingActionResultVO> dashbrdPendingActionResultVOs = dashPendingActRequestVO.getDashPendingActResultVOList();
			for(DashbrdPendingActionResultVO actionResultVO : dashbrdPendingActionResultVOs) {
				DashbrdPendingActionSummaryVO actionSummaryVO = createSummaryVO(actionResultVO);
				int index = pendingActionDetailsList.indexOf(actionSummaryVO);
				if(index != -1){
					List<DashbrdPendingActionListVO> actionListVOs = pendingActionDetailsList.get(index).getDashbrdPendingActionListVOs();
					actionListVOs.add(createDetailListVO(actionResultVO));
				}
				else{
					List<DashbrdPendingActionListVO> actionListVOs = new ArrayList<DashbrdPendingActionListVO>();
					actionListVOs.add(createDetailListVO(actionResultVO));
					actionSummaryVO.setDashbrdPendingActionListVOs(actionListVOs);
					pendingActionDetailsList.add(actionSummaryVO);
				}
			}	
		}
		catch(Exception exception){
			log.error("Exception occured in getPendingActionDetails "+exception.getMessage(), exception);
		}
		limitUtilReportResponseVO.setPendingActionDetailsList(pendingActionDetailsList);
		return limitUtilReportResponseVO;
	}
	
	
	public DashbrdPendingActionSummaryVO createSummaryVO(DashbrdPendingActionResultVO actionResultVO){
		DashbrdPendingActionSummaryVO actionSummaryVO = new DashbrdPendingActionSummaryVO();
		actionSummaryVO.setAction(actionResultVO.getAction());
		actionSummaryVO.setActionDisplay(actionResultVO.getActionDisplay());
		actionSummaryVO.setActionDisplayKey(actionResultVO.getActionDisplayKey());
		return actionSummaryVO;
	}
	
	public DashbrdPendingActionListVO createDetailListVO(DashbrdPendingActionResultVO actionResultVO){
		DashbrdPendingActionListVO actionListVO = new DashbrdPendingActionListVO();
		actionListVO.setCcy(actionResultVO.getCcy());
		actionListVO.setCount(actionResultVO.getCount());
		actionListVO.setAmount(actionResultVO.getAmount());
		actionListVO.setDecimal(actionResultVO.getDecimal());
		actionListVO.setActionDisplayKey(actionResultVO.getActionDisplayKey());
		actionListVO.setCountLabel(actionResultVO.getCountLabel());
		actionListVO.setScreen(populateScreenName(actionResultVO.getActionDisplay()));
		actionListVO.setStatus(actionResultVO.getAction());
		actionListVO.setStatusKey(actionResultVO.getStatusKey());
		actionListVO.setMakeCheckFlg(actionResultVO.getMakeCheckFlg());
		return actionListVO;
	}
	
	public String populateScreenName(String actionDisplay){
		String screenName = null; 
		if(actionDisplay.equalsIgnoreCase("Discounts pending to be raised") || 
				actionDisplay.equalsIgnoreCase("Upload Attachment Pending Approval") || 
				actionDisplay.equalsIgnoreCase("Pending Recall Approval")){
			screenName = "Payment Order";
		}else if(actionDisplay.equalsIgnoreCase("Discounts pending to be approved") ||
				actionDisplay.equalsIgnoreCase("Discount Cancellation pending approval") ||
				actionDisplay.startsWith("Discount pending Buyer Acceptance")){
			screenName = "Transaction";
		}else if(actionDisplay.equalsIgnoreCase("Invoice pending Buyer Acceptance") ||
				actionDisplay.equalsIgnoreCase("Invoice pending Buyer Acceptance - Rejection") ||
				actionDisplay.equalsIgnoreCase("Invoice pending Buyer Acceptance - Acceptance")){
			screenName = "BuyerAcceptance";
		}else if(actionDisplay.equalsIgnoreCase("File Pending Release") ||
				actionDisplay.equalsIgnoreCase("File Pending Authorization")){
			screenName = "File Management";
		}
		return screenName;
	}


	@Override
	public String getRequestedParamMapping(RequestParamVO requestParamVO) {
		String outputValue = null;
		List<NameValueVO> outputValueList = dashboardLimitUtilReportDAO.getRequestedParamMapping(requestParamVO);
		if(!outputValueList.isEmpty() && outputValueList.size() > 0){
			outputValue = outputValueList.get(0).getValue();
		}
		return outputValue;
	}
	
}
