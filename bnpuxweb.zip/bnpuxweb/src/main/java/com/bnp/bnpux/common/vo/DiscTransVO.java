/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  21 June 2017
 * 
 * Purpose:      Credit Note Inquiry Report Summary VO
 * 
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 21 June 2017       Ratna Gokhale, Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/

package com.bnp.bnpux.common.vo;

public class DiscTransVO{
	
	private String buyerOrgId;
	
	private String suppOrgId;
	
	private String buyerOrgName;
	
	private String suppOrgName;
	
	private String currencyCode;
	
	private String bandRecordCnt;
	
	private String recCount;
	
	private String rNo;
	
	private String errorMessage;

	public String getBuyerOrgId() {
		return buyerOrgId;
	}

	public void setBuyerOrgId(String buyerOrgId) {
		this.buyerOrgId = buyerOrgId;
	}

	public String getSuppOrgId() {
		return suppOrgId;
	}

	public void setSuppOrgId(String suppOrgId) {
		this.suppOrgId = suppOrgId;
	}

	public String getBuyerOrgName() {
		return buyerOrgName;
	}

	public void setBuyerOrgName(String buyerOrgName) {
		this.buyerOrgName = buyerOrgName;
	}

	public String getSuppOrgName() {
		return suppOrgName;
	}

	public void setSuppOrgName(String suppOrgName) {
		this.suppOrgName = suppOrgName;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getBandRecordCnt() {
		return bandRecordCnt;
	}

	public void setBandRecordCnt(String bandRecordCnt) {
		this.bandRecordCnt = bandRecordCnt;
	}

	public String getRecCount() {
		return recCount;
	}

	public void setRecCount(String recCount) {
		this.recCount = recCount;
	}

	public String getrNo() {
		return rNo;
	}

	public void setrNo(String rNo) {
		this.rNo = rNo;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	

}
