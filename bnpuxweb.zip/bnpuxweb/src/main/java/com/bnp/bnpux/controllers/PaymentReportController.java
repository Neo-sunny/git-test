/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   13 July 2017
 * 
 * Purpose:      Credit Note Inquiry Report Controller
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 13 July 2017       Jaimal Singh, Oracle Financial Services Software Ltd     Initial Version
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;



import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.constants.ReportsConstant;
import com.bnp.bnpux.service.IPaymentReportService;
import com.bnp.bnpux.util.RequestIdentityValidator;
import com.bnp.bnpux.vo.requestVO.PaymentReportRequestVO;
import com.bnp.bnpux.vo.responseVO.PaymentReportResponseVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@RestController
@RequestMapping("/paymentReportCtrl")
public class PaymentReportController {

	/**
	 * Logger for PaymentReportController
	 */
	public static final Logger log = LoggerFactory.getLogger(PaymentReportController.class);
	
	/**
	 * Autowired Interface IPaymentReportService
	 */
	@Autowired
	private IPaymentReportService reportsService;
	
	@Autowired
	RequestIdentityValidator validateRequest;
	
	/**
	 * This method is for getting the Credit Note Inquiry Reports Details list
	 * 
	 * @param SettlmntDueReminderRptRequestVO
	 * @return
	 */
	@RequestMapping(value = "getPaymentReportList.rest", method = RequestMethod.POST)
	public PaymentReportResponseVO getPaymentReportList(@RequestBody PaymentReportRequestVO paymentReportRequestVO,HttpServletRequest request,HttpServletResponse response) {		
		PaymentReportResponseVO paymentReportResponseVO = new PaymentReportResponseVO();
		try {
			boolean requestValidatedFlag = validateRequest.validate(paymentReportRequestVO.getUserId(),request.getSession());
			if(requestValidatedFlag){
				paymentReportResponseVO = reportsService.getPaymentReportList(paymentReportRequestVO);
			}
			else{
				paymentReportResponseVO = null;
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (BNPApplicationException exception) {
			paymentReportResponseVO.setErrorMessage(exception.getMessage());
			log.error(exception.getMessage(),exception);	
		}
		return paymentReportResponseVO;
	}
	
	/**
	 * This method is for getting the Chart Data
	 * 
	 * @param requestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@RequestMapping(value = ReportsConstant.REPORT_SUMMARY_REST_GET_CHART_DATA, method = RequestMethod.POST,produces= MediaType.APPLICATION_JSON_VALUE,headers = {"content-type=application/json","content-type=application/xml"})
	public List<ReportChartResponseVO> getChartData(@RequestBody PaymentReportRequestVO requestVO,HttpServletRequest request,HttpServletResponse response) throws BNPApplicationException { 
		List<ReportChartResponseVO> reportChartLst =null;
		try {
			if(requestVO !=null){
				boolean requestValidatedFlag = validateRequest.validate(requestVO.getUserId(),request.getSession());
				if(requestValidatedFlag){
					reportChartLst = reportsService.getReportChartAxis(requestVO);
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			}
		} catch (BNPApplicationException exception) {
			log.error(exception.getMessage(),exception);	
		}
		return reportChartLst;
	}
	
}