/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      User Preference Constants
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.constants;

public interface UserPreferenceConstants {
	
	/**
	 * Constant QRY_SAVE_USER_PREF
	 */
	public static final String QRY_SAVE_USER_PREF = "UserPrefNS.saveUserPreference";
	
	/**
	 * Constant QRY_GET_USER_PREF
	 */
	public static final String QRY_GET_USER_PREF = "UserPrefNS.getUserPreferenceInfo";
	
	/**
	 * Constant QRY_GET_TIMEZONE
	 */
	public static final String QRY_GET_TIMEZONE = "UserPrefNS.getTimeZone";
	
	/**
	 * Constant QRY_GET_TIMEZONE
	 */
	public static final String QRY_GET_TIMEZONE_CODE = "UserPrefNS.getCountryTimeZoneCode";
	
	/**
	 * Constant QRY_GET_TIMEZONE_BA
	 */
	public static final String QRY_GET_TIMEZONE_BA = "UserPrefNS.getTimeZoneForBA";
	
	/**
	 * Constant QRY_GET_TIMEZONE_BUYSELL
	 */
	public static final String QRY_GET_TIMEZONE_BUYSELL = "UserPrefNS.getTimeZoneForBuyerSeller";
	
	/**
	 * Constant QRY_GET_LOCALEF
	 */
	public static final String QRY_GET_LOCALEF = "UserPrefNS.getLocale";
	
	/**
	 * Constant GET_DEAL_TYPE
	 */
	public static final String GET_DEAL_TYPE = "UserPrefNS.getDealType";
	
	/**
	 * Constant EXCEPTION_DATA_BASE
	 */
	public static final String EXCEPTION_DATA_BASE = "Unable to process data due to databse exception";

	public static final String USERPREFERENCE_AUDIT = "USERPREFERENCE";


}
