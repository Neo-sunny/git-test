/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     Modal Service Implementation
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 
 *****************************************************************************************************************************************************************/
package com.bnp.bnpux.serviceimpl;

import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;

import com.bnp.bnpux.dao.ICommonDAO;
import com.bnp.bnpux.service.IModalService;

@Component
public class ModalServiceImpl implements IModalService{
	
	@Autowired
	public ICommonDAO commonDAO;
	/**
	 * This method is for getting Perishable Popup TimeOut
	 * @return
	 * @see com.bnp.bnpux.service.IModalService#getPerishablePopupTimeOut()
	 * @Description get TimeOut for PerishablePopup 
	 */
	@Override
	public int getPerishablePopupTimeOut() {
		// TODO Auto-generated method stub
		int timeOutValue = commonDAO.getPerishablePopupTimeOut();
		return timeOutValue;
	}

}
