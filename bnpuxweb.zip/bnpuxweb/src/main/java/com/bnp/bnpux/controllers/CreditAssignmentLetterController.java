/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Credit Assignment Letter Controller
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.constants.CreditAssignmentLetterConstants;
import com.bnp.bnpux.service.ICreditAssignmentLetterService;
import com.bnp.bnpux.vo.responseVO.CreditAssignmentLetterResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.discounting.vo.CreditAssignmentVO;

@RestController
@RequestMapping("/creditAssignmentLetterController")
public class CreditAssignmentLetterController {
	
	public static final Logger log = LoggerFactory.getLogger(CreditAssignmentLetterController.class);
	
	@Autowired
	private ICreditAssignmentLetterService creditAssignmentLetterService;
	  
		
	/**
	 * This method is get the credit assignment letters
	 * 
	 * @param pymtId
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = CreditAssignmentLetterConstants.CREDIT_LETTER_REST_GET_LIST, method = RequestMethod.POST)
	public CreditAssignmentLetterResponseVO getCreditAssgntLetters(@RequestParam long pymtId, HttpServletRequest request,HttpServletResponse response){
		CreditAssignmentLetterResponseVO creditAssignmentLetterResponseVO = new CreditAssignmentLetterResponseVO();
		
		List<CreditAssignmentVO> creditAssignLettersList;
		try {
			creditAssignLettersList = creditAssignmentLetterService.getCreditAssgntLetters(pymtId);
			creditAssignmentLetterResponseVO.setCreditAssignLettersList(creditAssignLettersList);
			creditAssignmentLetterResponseVO.setCount(creditAssignLettersList.size());
		} catch (BNPApplicationException exception) {
			creditAssignmentLetterResponseVO.setErrorMsg(exception.getMessage());
			log.error(exception.getMessage(),exception);	
		} 
		return creditAssignmentLetterResponseVO;
	}
		
	/**
	 * This method is download the credit assignment letters
	 * @param creditAssignmentVO
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = CreditAssignmentLetterConstants.CREDIT_LETTER_REST_DOWNLOAD, method = RequestMethod.POST)
	public void downloadCreditAssgntLetter(@RequestBody CreditAssignmentVO creditAssignmentVO, HttpServletRequest request,HttpServletResponse response){
		response.setHeader("Content-Disposition","attachment;filename=\"" + creditAssignmentVO.getFilename() + "\"");
		try {
			response.getOutputStream().write(creditAssignmentVO.getCreditAssgnLetter());
			response.getOutputStream().close();
		} catch (IOException e) {
			log.error(e.getMessage(),e);
		}		
	}	
}
