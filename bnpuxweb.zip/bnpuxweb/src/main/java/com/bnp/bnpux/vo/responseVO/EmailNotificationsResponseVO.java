package com.bnp.bnpux.vo.responseVO;

import java.util.List;

import com.bnp.bnpux.common.vo.EmailNotificationsVO;

public class EmailNotificationsResponseVO{
	
	private String errorMessage;
	
	private List<EmailNotificationsVO> notificationsList;
	
	private String pollingTime;

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public List<EmailNotificationsVO> getNotificationsList() {
		return notificationsList;
	}

	public void setNotificationsList(List<EmailNotificationsVO> notificationsList) {
		this.notificationsList = notificationsList;
	}

	public String getPollingTime() {
		return pollingTime;
	}

	public void setPollingTime(String pollingTime) {
		this.pollingTime = pollingTime;
	}

	
	
	

}
