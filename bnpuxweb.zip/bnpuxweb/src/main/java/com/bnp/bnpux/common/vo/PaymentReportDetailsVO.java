package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;
import java.util.Date;

public class PaymentReportDetailsVO {

	private String errorMessage;
	private String clientOrgName;
	private String cptyOrgName;
	private String ccyCode;
	private String disRefNo;
	private String pymtRefNo;
	private String euribor;
	private String discStatus;
	private String beneReconRefType;
	private Date  fileProcDate;
	private Date  discDate;
	private Date  confirmedDiscDate;
	private Date  orgMaturityDate;
	private Date  maturityDate;
	private Integer discTenure;
	private int decimalPoint;
	private BigDecimal pymtAmt;
	private BigDecimal confirmedInterestRate;
	private BigDecimal margin;
	private BigDecimal confirmedInterestAmt;
	private BigDecimal confirmedNetAmount;
	private String beneReconRefValue;

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * @return the clientOrgName
	 */
	public String getClientOrgName() {
		return clientOrgName;
	}

	/**
	 * @param clientOrgName the clientOrgName to set
	 */
	public void setClientOrgName(String clientOrgName) {
		this.clientOrgName = clientOrgName;
	}

	/**
	 * @return the cptyOrgName
	 */
	public String getCptyOrgName() {
		return cptyOrgName;
	}

	/**
	 * @param cptyOrgName the cptyOrgName to set
	 */
	public void setCptyOrgName(String cptyOrgName) {
		this.cptyOrgName = cptyOrgName;
	}

	/**
	 * @return the ccyCode
	 */
	public String getCcyCode() {
		return ccyCode;
	}

	/**
	 * @param ccyCode the ccyCode to set
	 */
	public void setCcyCode(String ccyCode) {
		this.ccyCode = ccyCode;
	}

	/**
	 * @return the disRefNo
	 */
	public String getDisRefNo() {
		return disRefNo;
	}

	/**
	 * @param disRefNo the disRefNo to set
	 */
	public void setDisRefNo(String disRefNo) {
		this.disRefNo = disRefNo;
	}

	/**
	 * @return the pymtRefNo
	 */
	public String getPymtRefNo() {
		return pymtRefNo;
	}

	/**
	 * @param pymtRefNo the pymtRefNo to set
	 */
	public void setPymtRefNo(String pymtRefNo) {
		this.pymtRefNo = pymtRefNo;
	}

	/**
	 * @return the euribor
	 */
	public String getEuribor() {
		return euribor;
	}

	/**
	 * @param euribor the euribor to set
	 */
	public void setEuribor(String euribor) {
		this.euribor = euribor;
	}

	/**
	 * @return the discStatus
	 */
	public String getDiscStatus() {
		return discStatus;
	}

	/**
	 * @param discStatus the discStatus to set
	 */
	public void setDiscStatus(String discStatus) {
		this.discStatus = discStatus;
	}

	/**
	 * @return the beneReconRefType
	 */
	public String getBeneReconRefType() {
		return beneReconRefType;
	}

	/**
	 * @param beneReconRefType the beneReconRefType to set
	 */
	public void setBeneReconRefType(String beneReconRefType) {
		this.beneReconRefType = beneReconRefType;
	}

	/**
	 * @return the fileProcDate
	 */
	public Date getFileProcDate() {
		return fileProcDate;
	}

	/**
	 * @param fileProcDate the fileProcDate to set
	 */
	public void setFileProcDate(Date fileProcDate) {
		this.fileProcDate = fileProcDate;
	}

	/**
	 * @return the discDate
	 */
	public Date getDiscDate() {
		return discDate;
	}

	/**
	 * @param discDate the discDate to set
	 */
	public void setDiscDate(Date discDate) {
		this.discDate = discDate;
	}

	/**
	 * @return the confirmedDiscDate
	 */
	public Date getConfirmedDiscDate() {
		return confirmedDiscDate;
	}

	/**
	 * @param confirmedDiscDate the confirmedDiscDate to set
	 */
	public void setConfirmedDiscDate(Date confirmedDiscDate) {
		this.confirmedDiscDate = confirmedDiscDate;
	}

	/**
	 * @return the orgMaturityDate
	 */
	public Date getOrgMaturityDate() {
		return orgMaturityDate;
	}

	/**
	 * @param orgMaturityDate the orgMaturityDate to set
	 */
	public void setOrgMaturityDate(Date orgMaturityDate) {
		this.orgMaturityDate = orgMaturityDate;
	}

	/**
	 * @return the maturityDate
	 */
	public Date getMaturityDate() {
		return maturityDate;
	}

	/**
	 * @param maturityDate the maturityDate to set
	 */
	public void setMaturityDate(Date maturityDate) {
		this.maturityDate = maturityDate;
	}

	/**
	 * @return the discTenure
	 */
	public Integer getDiscTenure() {
		return discTenure;
	}

	/**
	 * @param discTenure the discTenure to set
	 */
	public void setDiscTenure(Integer discTenure) {
		this.discTenure = discTenure;
	}

	/**
	 * @return the pymtAmt
	 */
	public BigDecimal getPymtAmt() {
		return pymtAmt;
	}

	/**
	 * @param pymtAmt the pymtAmt to set
	 */
	public void setPymtAmt(BigDecimal pymtAmt) {
		this.pymtAmt = pymtAmt;
	}

	/**
	 * @return the confirmedInterestRate
	 */
	public BigDecimal getConfirmedInterestRate() {
		return confirmedInterestRate;
	}

	/**
	 * @param confirmedInterestRate the confirmedInterestRate to set
	 */
	public void setConfirmedInterestRate(BigDecimal confirmedInterestRate) {
		this.confirmedInterestRate = confirmedInterestRate;
	}

	/**
	 * @return the margin
	 */
	public BigDecimal getMargin() {
		return margin;
	}

	/**
	 * @param margin the margin to set
	 */
	public void setMargin(BigDecimal margin) {
		this.margin = margin;
	}

	/**
	 * @return the confirmedInterestAmt
	 */
	public BigDecimal getConfirmedInterestAmt() {
		return confirmedInterestAmt;
	}

	/**
	 * @param confirmedInterestAmt the confirmedInterestAmt to set
	 */
	public void setConfirmedInterestAmt(BigDecimal confirmedInterestAmt) {
		this.confirmedInterestAmt = confirmedInterestAmt;
	}

	/**
	 * @return the confirmedNetAmount
	 */
	public BigDecimal getConfirmedNetAmount() {
		return confirmedNetAmount;
	}

	/**
	 * @param confirmedNetAmount the confirmedNetAmount to set
	 */
	public void setConfirmedNetAmount(BigDecimal confirmedNetAmount) {
		this.confirmedNetAmount = confirmedNetAmount;
	}

	/**
	 * @return the beneReconRefValue
	 */
	public String getBeneReconRefValue() {
		return beneReconRefValue;
	}

	/**
	 * @param beneReconRefValue the beneReconRefValue to set
	 */
	public void setBeneReconRefValue(String beneReconRefValue) {
		this.beneReconRefValue = beneReconRefValue;
	}

	/**
	 * @return the decimalPoint
	 */
	public int getDecimalPoint() {
		return decimalPoint;
	}

	/**
	 * @param decimalPoint the decimalPoint to set
	 */
	public void setDecimalPoint(int decimalPoint) {
		this.decimalPoint = decimalPoint;
	}
	
	
	public String getPymtAmtStr() {
		return (pymtAmt != null)? pymtAmt.toPlainString():"";
	}
	
	public String getConfirmedInterestRateStr() {
		return (confirmedInterestRate != null)? confirmedInterestRate.toPlainString():"";
	}
	
	public String getMarginStr() {
		return (margin != null)? margin.toPlainString():"";
	}
	
	public String getConfirmedInterestAmtStr() {
		return (confirmedInterestAmt != null)? confirmedInterestAmt.toPlainString():"";
	}
	
	public String getConfirmedNetAmountStr() {
		return (confirmedNetAmount != null)? confirmedNetAmount.toPlainString():"";
	}
}
