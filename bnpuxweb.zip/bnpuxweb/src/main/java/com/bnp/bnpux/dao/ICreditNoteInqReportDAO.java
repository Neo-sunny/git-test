/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  21 June 2017
 * 
 * Purpose:      Credit Note Inquiry Report Interface for Data Access Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 21 June 2017       Ratna Gokhale, Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.dao;

import java.util.List;
import java.util.Map;

import com.bnp.bnpux.common.vo.CreditNoteUtilizationVO;
import com.bnp.bnpux.vo.requestVO.CreditNoteInqRequestVO;
import com.bnp.bnpux.vo.responseVO.CreditNoteInqResponseVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;
import com.bnp.bnpux.common.vo.ReportsCreditNoteLineItemVO;

public interface ICreditNoteInqReportDAO {
	

	/**
	 * This method is for getting Credit Note Inquiry Report List
	 * 
	 * @param CreditNoteInqRequestVO
	 * @return CreditNoteInqResponseVO List
	 */
	List<CreditNoteInqResponseVO> getReportList(CreditNoteInqRequestVO creditNoteInqRequestVO);
	
	/**
	 * This method is for getting Credit Note Inquiry Report List Details
	 * 
	 * @param CreditNoteInqRequestVO
	 * @return CreditNoteInqResponseVO List
	 */
	List<CreditNoteInqResponseVO> getReportListDetails(CreditNoteInqRequestVO creditNoteInqRequestVO);
	

	/**
	 * This method is for getting Credit Note Inquiry Report List Details
	 * 
	 * @param CreditNoteInqRequestVO
	 * @return CreditNoteInqResponseVO List
	 */
	List<CreditNoteUtilizationVO> getReportUtilization(CreditNoteInqRequestVO creditNoteInqRequestVO);
	

	/**
	 * This method is for getting Chart Axis
	 * 
	 * @param CreditNoteInqRequestVO
	 * @return ReportChartResponseVO List
	 */
	List<ReportChartResponseVO> getChartAxis(CreditNoteInqRequestVO creditNoteInqRequestVO);
	
		/**
	 * This method is for getting Credit Note Line Item details
	 * 
	 * @param paramMap
	 * @return
	 */
	ReportsCreditNoteLineItemVO getReportsCreditNoteLineItemDetails(Map<String, Object> paramMap);

}
