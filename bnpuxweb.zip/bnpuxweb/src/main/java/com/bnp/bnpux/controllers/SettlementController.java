/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Settlement Controller
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.service.ISettlementService;
import com.bnp.bnpux.util.RequestIdentityValidator;
import com.bnp.bnpux.vo.requestVO.InProcessAlreadySettDetailsRequestVO;
import com.bnp.bnpux.vo.requestVO.InProcessAmtDetailsRequestVO;
import com.bnp.bnpux.vo.requestVO.SettlementCreditNoteLineItemRequestVO;
import com.bnp.bnpux.vo.requestVO.SettlementInvoiceDetailsRequestVO;
import com.bnp.bnpux.vo.requestVO.SettlementRequestVO;
import com.bnp.bnpux.vo.responseVO.InProcessAlreadySettDetailsResponseVO;
import com.bnp.bnpux.vo.responseVO.SettlementCreditNoteLineItemResponseVO;
import com.bnp.bnpux.vo.responseVO.SettlementInvoiceLineItemResponseVO;
import com.bnp.bnpux.vo.responseVO.SettlementResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@RestController
@RequestMapping("/settlementCtrl")
public class SettlementController {
	

	/**
	 * Logger for SettlementController
	 */
	public static final Logger log = LoggerFactory.getLogger(SettlementController.class);
	

	/**
	 * Autowired Interface ISettlementService
	 */
	@Autowired
	private ISettlementService settlementService;
	
	@Autowired
	RequestIdentityValidator validateRequest;
	
	/**
	 * This method is for getting Settlement details
	 * 
	 * @param settlementRequestVO
	 * @return
	 */
	@RequestMapping(value = "getSettlementOrderdetails.rest", method = RequestMethod.POST)
	public SettlementResponseVO getSettlementDetails(@RequestBody SettlementRequestVO settlementRequestVO,HttpServletRequest request,HttpServletResponse response) {		
		SettlementResponseVO settlementResponseVO = new SettlementResponseVO();
		try {
			boolean requestValidatedFlag = validateRequest.validate(settlementRequestVO.getUserId(),request.getSession());
			if(requestValidatedFlag){
				settlementResponseVO = settlementService.getSettlementDetails(settlementRequestVO);
			}
			else{
				settlementResponseVO = null;
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (BNPApplicationException exception) {
			settlementResponseVO.setErrorMsg(exception.getMessage());
			log.error(exception.getMessage(),exception);	
		}
		return settlementResponseVO;
	}
	
	/**
	 * This method is for getting Settlement details
	 * 
	 * @param settlementRequestVO
	 * @return
	 */
	@RequestMapping(value = "getAdvancedFilterIndicatorCount.rest", method = RequestMethod.POST)
	public SettlementResponseVO getAdvancedFilterIndicatorCount(@RequestBody SettlementRequestVO settlementRequestVO,HttpServletRequest request,HttpServletResponse response) {		
		SettlementResponseVO settlementResponseVO = new SettlementResponseVO();
		try {
			boolean requestValidatedFlag = validateRequest.validate(settlementRequestVO.getUserId(),request.getSession());
			if(requestValidatedFlag){
				settlementResponseVO = settlementService.getAdvancedFilterCount(settlementRequestVO);
			}
			else{
				settlementResponseVO = null;
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (BNPApplicationException exception) {
			settlementResponseVO.setErrorMsg(exception.getMessage());
			log.error(exception.getMessage(),exception);	
		}
		return settlementResponseVO;
	}

	/**
	 * This method is getting Already Paid Amount details call out
	 * 
	 * @param alreadySettledDetailsRequestVO
	 * @return
	 */
	@RequestMapping(value = "getInProcessAlreadySettDetailsCallout.rest", method = RequestMethod.POST)
	public InProcessAlreadySettDetailsResponseVO getInProcessAlreadySettDetailsCallout(@RequestBody InProcessAlreadySettDetailsRequestVO alreadySettledDetailsRequestVO) {		
		InProcessAlreadySettDetailsResponseVO alreadySettledDetailsResponseVO = new InProcessAlreadySettDetailsResponseVO();
		try {			
			alreadySettledDetailsResponseVO = settlementService.getInProcessAlreadySettDetailsCallout(alreadySettledDetailsRequestVO);				
		} catch (BNPApplicationException exception) {
			log.error(exception.getMessage(),exception);	
		}
		return alreadySettledDetailsResponseVO;		
	}
	
	
	/**
	 * This method is for getting Inprocess amount details call out
	 * 
	 * @param inProcessAmtDetailsRequestVO
	 * @return
	 */
	/*
	 * Commented below method since it is merged with Already Paid amount callout
	 * @RequestMapping(value = "getInProcessAmtDetails.rest", method = RequestMethod.POST)
	public AlreadySettledDetailsResponseVO getInProcessAmtDetailsCallout(@RequestBody InProcessAmtDetailsRequestVO inProcessAmtDetailsRequestVO) {		
		AlreadySettledDetailsResponseVO inProcessAmtDetailsResponseVO = new AlreadySettledDetailsResponseVO();
		try {			
			inProcessAmtDetailsResponseVO = settlementService.getInProcessAmtDetailsCallout(inProcessAmtDetailsRequestVO);				
		} catch (BNPApplicationException exception) {
			log.error(exception.getMessage(),exception);	
		}
		return inProcessAmtDetailsResponseVO;		
	}
*/	
	/**
	 * This method is for getting Credit Note Line item details
	 * 
	 * @param settlementCreditNoteLineItemRequestVO
	 * @return
	 */
	@RequestMapping(value = "getSettlementCreditNoteLineItemdetails.rest", method = RequestMethod.POST)
	public SettlementCreditNoteLineItemResponseVO getSettlementCreditNoteLineItemdetails(@RequestBody SettlementCreditNoteLineItemRequestVO settlementCreditNoteLineItemRequestVO) {		
		SettlementCreditNoteLineItemResponseVO settlementCreditNoteLineItemResponseVO = new SettlementCreditNoteLineItemResponseVO();
		try {
			settlementCreditNoteLineItemResponseVO = settlementService.getSettlementCreditNoteLineItemdetails(settlementCreditNoteLineItemRequestVO);
		} catch (BNPApplicationException exception) {
			log.error(exception.getMessage(),exception);	
		}
		return settlementCreditNoteLineItemResponseVO;		
	}
	
	/**
	 * This method is for getting Invoice details
	 * 
	 * @param settlementInvoiceDetailsRequestVO
	 * @return
	 */
	@RequestMapping(value = "getSettlementInvoiceDetails.rest", method = RequestMethod.POST)
	public SettlementInvoiceLineItemResponseVO getSettlementInvoiceDetails(@RequestBody SettlementInvoiceDetailsRequestVO settlementInvoiceDetailsRequestVO) {		
		SettlementInvoiceLineItemResponseVO settlementInvoiceLineItemResponseVO = new SettlementInvoiceLineItemResponseVO();
		try {			
			settlementInvoiceLineItemResponseVO = settlementService.getSettlementInvoiceDetails(settlementInvoiceDetailsRequestVO);				
		} catch (BNPApplicationException exception) {
			log.error(exception.getMessage(),exception);	
		}
		return settlementInvoiceLineItemResponseVO;		
	}
	
	}