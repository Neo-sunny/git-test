/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     UserService Interface
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 
 *****************************************************************************************************************************************************************/
package com.bnp.bnpux.service;

import java.util.List;
import java.util.Map;

import com.bnp.bnpux.common.vo.CountryFlagVO;
import com.bnp.bnpux.common.vo.UserBranchVO;

public interface IUserService {

	/**
	 * This method is for getting user info
	 * 
	 * @param userId
	 * @param orgId
	 * @return
	 */
	public List<UserBranchVO> getUserInfo(String userId,String orgId);
	
	/**
	 * This method is for getting Cut off time remaining
	 * 
	 * @param branches
	 * @param orgId
	 * @return
	 */
	public List<Map<String,String>> getCoTRemaniningTime(List<UserBranchVO> branches,String orgId);
	
	/**
	 * This method is for getting country code
	 * 
	 * @param countryCd
	 * @return
	 */
	public CountryFlagVO getCountryFlag(String countryCd);
}
