/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     Holiday Request Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                Oracle Financial Services Software Ltd            Initial Version
 * 08 Mar 2017                skbhaska                                    		FO 10.0 - S30 - Holiday Calendar   
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.requestVO;

import java.io.Serializable;
import java.util.List;

public class HolidayRequestVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String userid;

	private String leadOrgId;

	private String ccyCode;

	private String orgId;

	private String branch;

	private String year;

	private String userType;

	private List<String> checkedCurrencyList;

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getLeadOrgId() {
		return leadOrgId;
	}

	public void setLeadOrgId(String leadOrgId) {
		this.leadOrgId = leadOrgId;
	}

	public String getCcyCode() {
		return ccyCode;
	}

	public void setCcyCode(String ccyCode) {
		this.ccyCode = ccyCode;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public List<String> getCheckedCurrencyList() {
		return checkedCurrencyList;
	}

	public void setCheckedCurrencyList(List<String> checkedCurrencyList) {
		this.checkedCurrencyList = checkedCurrencyList;
	}

}
