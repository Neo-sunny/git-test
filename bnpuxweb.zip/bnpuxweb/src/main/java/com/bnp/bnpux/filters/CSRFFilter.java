/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Servlet Request Filters
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.filters;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


@Component("csrfFilter")
public class CSRFFilter implements javax.servlet.Filter{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CSRFFilter.class);
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		
	}

	/* 
	 * This method for filter the HTTPServletRequest
	 * (non-Javadoc)
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		if (request instanceof HttpServletRequest) {
			
			HttpServletResponse httpServletResponse = (HttpServletResponse) response;
			HttpServletRequest httpServletRequest = (HttpServletRequest) request;
			HttpSession existingSession = httpServletRequest.getSession(false);
			if(existingSession!=null){
				if(!("GET").equals(httpServletRequest.getMethod())){
					String sessionCsrfToken = null;
					String requestCsrfToken = null;
					if(existingSession.getAttribute("CSRF_SESSION_TOKEN")!=null){
						sessionCsrfToken = existingSession.getAttribute("CSRF_SESSION_TOKEN").toString();
					}
					if(httpServletRequest.getHeader("USER_CSRF_TOKEN")!=null){
						requestCsrfToken =httpServletRequest.getHeader("USER_CSRF_TOKEN");
					}
					if(sessionCsrfToken!=null && requestCsrfToken!=null && sessionCsrfToken.equals(requestCsrfToken)){
						chain.doFilter(request, response);
					}else{
						LOGGER.warn(" Request "+httpServletRequest.getRequestURI()+" Request Method "+httpServletRequest.getMethod()+" CSRF_SESSION_TOKEN missing.");
						httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
					}
				}else{
					chain.doFilter(request, response);
				}
			}else{
				LOGGER.warn("Session Object is Null");
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
			
			
		}
	}

	@Override
	public void destroy() {
		
	}
	
}
