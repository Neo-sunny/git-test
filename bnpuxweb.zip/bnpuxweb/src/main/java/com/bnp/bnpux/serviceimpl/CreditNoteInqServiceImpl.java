/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   21 June 2017
 * 
 * Purpose:      Credit Note Inquiry Report Service Implementation
 * 
 * Change History:
 *  
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 21 June 2017       Ratna Gokhale, Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.serviceimpl;

import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.constants.CreditNoteInqConstants;
import com.bnp.bnpux.constants.PaymentOrderConstants;
import com.bnp.bnpux.constants.ReportsConstant;
import com.bnp.bnpux.dao.ICreditNoteInqReportDAO;
import com.bnp.bnpux.service.ICreditNoteInqReportService;
import com.bnp.bnpux.vo.requestVO.CreditNoteInqRequestVO;
import com.bnp.bnpux.vo.requestVO.ReportsCreditNoteLineItemRequestVO;
import com.bnp.bnpux.vo.responseVO.CreditNoteInqResponseVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.bnpux.vo.responseVO.ReportsCreditNoteLineItemResponseVO;
import com.bnp.bnpux.common.vo.ReportsCreditNoteLineItemVO;

@Component
public class CreditNoteInqServiceImpl implements ICreditNoteInqReportService{

	@Autowired
	private ICreditNoteInqReportDAO creditNoteInqReportDAO;
	
	/**
	 * Logger log for CreditNoteInqServiceImpl class
	 */
	private static final Logger log = LoggerFactory.getLogger(CreditNoteInqServiceImpl.class);
	
	/**
	 * Constant for Exception message
	 */
	public static final String EXCEPTION_UNABLE_TO_PROCESS = "Unable to process action - Database Exception";
	
	/**
	 * This service implementation method is used to fetch latest Credit Note Inquiry Report list
	 * 
	 * @param CreditNoteInqRequestVO 
	 * @return CreditNoteInqResponseVO
	 */
	@Override
	public CreditNoteInqResponseVO getReportList(CreditNoteInqRequestVO creditNoteInqRequestVO) throws BNPApplicationException {
		CreditNoteInqResponseVO creditNoteInqResponseVO = null; 
		try{
			creditNoteInqResponseVO = new CreditNoteInqResponseVO();
			
			if(CreditNoteInqConstants.CREDIT_NOTE_INQ_LIST.equalsIgnoreCase(creditNoteInqRequestVO.getViewType())) {
				creditNoteInqReportDAO.getReportList(creditNoteInqRequestVO);
				if(creditNoteInqRequestVO.getCreditNoteInqList() != null) {
					creditNoteInqResponseVO.setCreditNoteInqList(creditNoteInqRequestVO.getCreditNoteInqList());
				}
			} else if(CreditNoteInqConstants.CREDIT_NOTE_INQ_LIST_DETAILS.equalsIgnoreCase(creditNoteInqRequestVO.getViewType())) {
				creditNoteInqReportDAO.getReportListDetails(creditNoteInqRequestVO);
				if(creditNoteInqRequestVO.getCreditNoteInqDetails() != null) {
					creditNoteInqResponseVO.setCreditNoteInqDetails(creditNoteInqRequestVO.getCreditNoteInqDetails());
				}
			}  else if(CreditNoteInqConstants.CREDIT_NOTE_INQ_UTILIZATION.equalsIgnoreCase(creditNoteInqRequestVO.getViewType())) {
				creditNoteInqReportDAO.getReportUtilization(creditNoteInqRequestVO);
				if(creditNoteInqRequestVO.getCreditNoteInqUtilization() != null) {
					creditNoteInqResponseVO.setCreditNoteInqUtilization(creditNoteInqRequestVO.getCreditNoteInqUtilization());
				}
			} 
			
			if(creditNoteInqRequestVO.getErrorMsg() != null){				
				log.error(EXCEPTION_UNABLE_TO_PROCESS + creditNoteInqRequestVO.getErrorMsg());
				//throw new BNPApplicationException(EXCEPTION_UNABLE_TO_PROCESS);	
			}
			
			
		} catch(DataAccessException exception) {
			log.error(EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(EXCEPTION_UNABLE_TO_PROCESS);	
		}
		return creditNoteInqResponseVO;
	}


	/**
	 * This method is for getting Credit Note Inquiry Report details
	 * 
	 * @param CreditNoteInqRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public CreditNoteInqResponseVO getReportDetails(CreditNoteInqRequestVO creditNoteInqRequestVO)
			throws BNPApplicationException {
		// TODO Auto-generated method stub
		String errorFlag = null;	
		CreditNoteInqResponseVO creditNoteInqResponseVO = new CreditNoteInqResponseVO();
		try{
			
		}catch(Exception exception){
			log.error(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS);
		}
		return creditNoteInqResponseVO;
	}
	
	/**
	 * This method is for getting report chart axis 
	 * 
	 * @param requestVo
	 * @return
	 * @throws BNPApplicationException
	 */
	public List<ReportChartResponseVO> getReportChartAxis (CreditNoteInqRequestVO creditNoteInqRequestVO)throws BNPApplicationException {
		List<ReportChartResponseVO> reportVOList = new ArrayList<ReportChartResponseVO>();
		try{
			
		creditNoteInqReportDAO.getChartAxis(creditNoteInqRequestVO);
		reportVOList = (List<ReportChartResponseVO>) creditNoteInqRequestVO.getReportChartList();
		
		
		/*if(reportVOList != null){
			settlementResponseVO.setSettlementListVO(settlementVOList);
		}*/	
		}catch(Exception exception){
			log.error(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS);
		}
		return reportVOList;
   }
	



	/**
	 * This method is for getting Credit Note Line Item details
	 * 
	 * @param paymentOrderCreditNoteLineItemRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public ReportsCreditNoteLineItemResponseVO getReportsCreditNoteLineItemDetails(ReportsCreditNoteLineItemRequestVO reportsCreditNoteLineItemRequestVO) throws BNPApplicationException{
		String errorFlag;
		ReportsCreditNoteLineItemResponseVO reportsCreditNoteLineItemResponseVO = new ReportsCreditNoteLineItemResponseVO();
		try {
			List<ReportsCreditNoteLineItemVO> reportsCreditNoteLineItemVOList = new ArrayList<ReportsCreditNoteLineItemVO>();
			Map<String, Object> creditNoteLineItemMap = new HashMap<String, Object>();
			creditNoteLineItemMap.put(PaymentOrderConstants.PAYMENT_ORDER_CREDIT_NOTE_LINE_ITEM_ID,
					reportsCreditNoteLineItemRequestVO.getCnt_id());
			creditNoteInqReportDAO.getReportsCreditNoteLineItemDetails(creditNoteLineItemMap);
			reportsCreditNoteLineItemVOList = (List<ReportsCreditNoteLineItemVO>) creditNoteLineItemMap
					.get(PaymentOrderConstants.PAYMENT_ORDER_CREDIT_NOTE_LINE_ITEM_SUMMARY);
			if (reportsCreditNoteLineItemVOList != null && reportsCreditNoteLineItemVOList.size() > 0) {
				reportsCreditNoteLineItemResponseVO.setReportsCreditNoteLineItemVO(reportsCreditNoteLineItemVOList);
			} else {
				errorFlag = (String) creditNoteLineItemMap
						.get(PaymentOrderConstants.PAYMENT_ORDER_CREDIT_NOTE_LINE_ITEM_EROR_MSG);
				reportsCreditNoteLineItemResponseVO.setError_msg(errorFlag);
			}
			reportsCreditNoteLineItemResponseVO.setReportsCreditNoteLineItemVO(reportsCreditNoteLineItemVOList);
		} catch (DataAccessException exception) {
			log.error(PaymentOrderConstants.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(PaymentOrderConstants.EXCEPTION_UNABLE_TO_PROCESS);
		}
		return reportsCreditNoteLineItemResponseVO;
	}
}