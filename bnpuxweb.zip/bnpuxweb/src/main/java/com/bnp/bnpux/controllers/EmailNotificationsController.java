/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   26-May-2017
 * 
 * Purpose:      NotificationsController
 * 
 * Change History:
 *  
 * Date                       Author                                            Reason
 * 26-May-2017			Bala Murugan Elangovan					Notifications Controller controller 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import java.io.IOException;

import javax.servlet.ServletOutputStream;
//import java.io.BufferedInputStream;
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.IOException;
//import java.io.OutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.common.vo.EmailNotificationsVO;
import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.service.IEmailNotificationsService;
import com.bnp.bnpux.util.RequestIdentityValidator;
//import com.bnp.bnpux.vo.requestVO.EmailInquiryRptRequestVO;
import com.bnp.bnpux.vo.requestVO.EmailNotificationsRequestVO;
import com.bnp.bnpux.vo.responseVO.EmailNotificationsResponseVO;
//import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@RestController
@RequestMapping("/notificationsCtrl")
public class EmailNotificationsController {
	
	/**
	 * Logger log for NotificationsController class
	 */
	public static final Logger log = LoggerFactory.getLogger(EmailNotificationsController.class);

	
	/**
	 * RequestIdentityValidator validateRequest;
	 */
	@Autowired
	private IEmailNotificationsService notificationsService;
	
	
	/**
	 * RequestIdentityValidator validateRequest;
	 */
	@Autowired
	private RequestIdentityValidator validateRequest;	
	
	//@Autowired
	//protected BNPPropertyLoaderConfigurer bnpPropertyLoaderConfigurer;
	
	/**
	 * This method is used to fetch latest email records
	 * 
	 * @param EmailNotificationsRequestVO , httpRequest , httpResponse
	 * @return notificationsResponseVO
	 */
	@RequestMapping(value = "getNotificationsList.rest", method = RequestMethod.POST)
	public EmailNotificationsResponseVO getNotificationsList(@RequestBody EmailNotificationsRequestVO noticationsVO, HttpServletRequest httpRequest, HttpServletResponse httpResponse){
		EmailNotificationsResponseVO notificationsResponseVO = new EmailNotificationsResponseVO();		
		try{
			boolean validateRequestFlag = validateRequest.validate(noticationsVO.getUserId(), httpRequest.getSession());
			if(validateRequestFlag){		
				notificationsResponseVO = notificationsService.getNotificationsList(noticationsVO);
			}
			else{		
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		}catch(BNPApplicationException bnpException){
			notificationsResponseVO.setErrorMessage(bnpException.getMessage());
			log.error(bnpException.getMessage(),bnpException);
		}
		return notificationsResponseVO;
	}
	
	/**
	 * This method is used to fetch latest email records
	 * 
	 * @param EmailNotificationsRequestVO , httpRequest , httpResponse
	 * @return notificationsResponseVO
	 */
	@RequestMapping(value = "getEmailInqRptList.rest", method = RequestMethod.POST)
	public EmailNotificationsResponseVO getEmailInqRptList(@RequestBody EmailNotificationsRequestVO noticationsVO, HttpServletRequest httpRequest, HttpServletResponse httpResponse){
		EmailNotificationsResponseVO notificationsResponseVO = new EmailNotificationsResponseVO();		
		try{
			boolean validateRequestFlag = validateRequest.validate(noticationsVO.getUserId(), httpRequest.getSession());
			if(validateRequestFlag){		
				notificationsResponseVO = notificationsService.getEmailInqRptList(noticationsVO);
			}
			else{		
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		}catch(BNPApplicationException bnpException){
			notificationsResponseVO.setErrorMessage(bnpException.getMessage());
			log.error(bnpException.getMessage(),bnpException);
		}
		return notificationsResponseVO;
	}
	
	/**
	 * This method is used to fetch latest email records
	 * 
	 * @param EmailNotificationsRequestVO , httpRequest , httpResponse
	 * @return notificationsResponseVO
	 */
	@RequestMapping(value = "getEmailInqRptDetails.rest", method = RequestMethod.POST)
	public EmailNotificationsVO getEmailInqRptDetails(@RequestBody EmailNotificationsVO noticationsVO, HttpServletRequest httpRequest, HttpServletResponse httpResponse){
		try{
			boolean validateRequestFlag = validateRequest.validate(noticationsVO.getUserId(), httpRequest.getSession());
			if(validateRequestFlag){		
				 notificationsService.getEmailInqRptDetails(noticationsVO);
			}
			else{		
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		}catch(BNPApplicationException bnpException){
			noticationsVO.setErrorMessage(bnpException.getMessage());
			log.error(bnpException.getMessage(),bnpException);
		}
		return noticationsVO;
	}

	//The below code is for fetching the audio from server and flushing it
	/*@RequestMapping(value = "getAudio.rest", method = RequestMethod.GET)
	public void getAudio(@RequestParam("userId") String userId,HttpServletRequest request,HttpServletResponse response) {		
		OutputStream stream= null;
		BufferedInputStream buf = null;
		FileInputStream inputStream = null;
		try {
			stream = response.getOutputStream();
			response.setContentType("audio/mpeg");
			File file = new File(bnpPropertyLoaderConfigurer.getValue(BNPConstants.AUDIO_FILE_PATH)+bnpPropertyLoaderConfigurer.getValue(BNPConstants.AUDIO_FILE_NAME));
			response.setContentLength((int) file.length());
			inputStream = new FileInputStream(file);
			buf = new BufferedInputStream(inputStream);
			int readBytes = 0;
			while ((readBytes = buf.read()) != -1){
				stream.write(readBytes);
			}
			stream.flush();
		}catch (IOException e) {
			log.error(e.getMessage(),e);	
		}finally{
			try {
				if(stream!=null){
					stream.close();
				}
				if(inputStream != null){
					inputStream.close();
				}
			} catch (IOException e) {
				log.error(e.getMessage(),e);
			}
		}
	}*/
	
	@RequestMapping(value = "getAttachmentData.rest", method = RequestMethod.POST)
	public void getAttachmentData(@RequestBody EmailNotificationsVO emailNotificationVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse)
	{
		EmailNotificationsVO emailNotificationsResponseVO = new EmailNotificationsVO();
		ServletOutputStream outStream;
		String fileName;
		String fileType;
		int len;
		try {
			boolean requestValidatedFlag = validateRequest.validate(emailNotificationVO.getUserId(), httpServletRequest.getSession());
			if (requestValidatedFlag) {
				emailNotificationsResponseVO = notificationsService.getAttachmentData(emailNotificationVO);
				fileName = emailNotificationsResponseVO.getAttachmentName();
				fileType = fileName.substring(fileName.indexOf('.') + 1, fileName.length());
				len = emailNotificationsResponseVO.getAttachmentData().length;
					try {
						httpServletResponse.setContentType("application/"+fileType);
						httpServletResponse.setContentLength(len);
						httpServletResponse.setHeader("Content-Disposition","attachment;filename=\"" + fileName + "\"");
						httpServletResponse.setHeader("allFlag",emailNotificationsResponseVO.isAllFlag()+"");
						outStream = httpServletResponse.getOutputStream();
						outStream.write(emailNotificationsResponseVO.getAttachmentData(), 0, len);
						outStream.flush();
						outStream.close();
					} catch (IOException e) {
						log.error(e.getMessage(),e);
					}
				}
			else {
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (BNPApplicationException exception) {
			emailNotificationsResponseVO.setErrorMessage(exception.getMessage());
			log.error(exception.getMessage(), exception);
		}
	}
}
