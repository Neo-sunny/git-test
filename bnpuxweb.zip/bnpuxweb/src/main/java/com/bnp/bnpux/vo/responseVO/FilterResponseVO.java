/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:      Filter Response Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd      Initial Version
 * 07 Mar 2017                      skbhaska                                    FO 10.0 - S30  
 * 21 Apr 2017						AnubhaJ										FO 10.0 -S2045A
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.responseVO;

import java.util.List;

import com.bnp.bnpux.common.vo.StatusDetailsVO;

public class FilterResponseVO {

	private List<StatusDetailsVO> statusDet;
	private List<StatusDetailsVO> branchDet;
	
	private List<PeriodStatusResponseVO> periodDet;
	private List<PeriodStatusResponseVO> reportBranchDet;
	private List<PeriodStatusResponseVO> quickSearchDet;
	private List<PeriodStatusResponseVO> chartTypeDet;
	private List<PeriodStatusResponseVO> plotParamDet;
	private List<PeriodStatusResponseVO> plotParamPreStlmtDet;
	
	private List<StatusDetailsVO> ccyDet;
	private List<StatusDetailsVO> clientOrgDet;
	private List<StatusDetailsVO> counterPtyDet;
	private List<StatusDetailsVO> fileStatusDet;
	
	private List<PeriodStatusResponseVO> yearDet;
	private List<PeriodStatusResponseVO> orgIdDet;
	private List<PeriodStatusResponseVO> ccyHolDet;
	private List<PeriodStatusResponseVO> counterPartyDet;
	private List<PeriodStatusResponseVO> stlmtReportType;
	private List<PeriodStatusResponseVO> pymtReportType;
	private PeriodStatusResponseVO branchLocaleDateType;

	private List<PeriodStatusResponseVO> senderOrgIdDet;//FO 10.0 S2045A
	private List<StatusDetailsVO> docTypeIdDet;//FO 10.0 S2045A
	
	private List<PeriodStatusResponseVO> emailEventDet;
	private List<PeriodStatusResponseVO> emailDelvStatusDet;
	private List<PeriodStatusResponseVO> emailCategoryDet;
	private List<PeriodStatusResponseVO> emailInqOrgDet;
	private List<PeriodStatusResponseVO> emailInqPeriodDet;
	
	private List<PeriodStatusResponseVO> cntCurrencyDet;
	private List<PeriodStatusResponseVO> cntPeriodDet;
	private List<PeriodStatusResponseVO> cntStatusDet;
	private List<PeriodStatusResponseVO> cntBuyerDet;
	private List<PeriodStatusResponseVO> cntSupplierDet;
	
	private List<PeriodStatusResponseVO> remitRptCurrencyDet;
	private List<PeriodStatusResponseVO> remitRptPeriodDet;
	private List<PeriodStatusResponseVO> remitRptStatusDet;
	private List<PeriodStatusResponseVO> remitRptBuyerDet;
	private List<PeriodStatusResponseVO> remitRptSupplierDet;
	
	private List<PeriodStatusResponseVO> reportTypeDet;
	private List<PeriodStatusResponseVO> reportOrgIdDet;
	private List<PeriodStatusResponseVO> reportPeriodDet;
	private List<PeriodStatusResponseVO> reportFrequenctDet;
	
	private List<PeriodStatusResponseVO> lmtClientOrgDet;
	private List<PeriodStatusResponseVO> lmtCounterOrgDet;
	private List<PeriodStatusResponseVO> lmtLimitTypDet;
	private List<PeriodStatusResponseVO> lmtIncConvLimDet;
	
	private List<PeriodStatusResponseVO> dscCurrencyDet;
	private List<PeriodStatusResponseVO> dscPeriodDet;
	private List<PeriodStatusResponseVO> dscStatusDet;
	private List<PeriodStatusResponseVO> dscBuyerDet;
	private List<PeriodStatusResponseVO> dscSupplierDet;
	
	private List<PeriodStatusResponseVO> agingDiscountType;
	private List<PeriodStatusResponseVO> cntPeriodDet_pre;
	
	public List<PeriodStatusResponseVO> getCntPeriodDet_pre() {
		return cntPeriodDet_pre;
	}

	public void setCntPeriodDet_pre(List<PeriodStatusResponseVO> cntPeriodDet_pre) {
		this.cntPeriodDet_pre = cntPeriodDet_pre;
	}

	public List<PeriodStatusResponseVO> getRemitRptCurrencyDet() {
		return remitRptCurrencyDet;
	}

	public void setRemitRptCurrencyDet(List<PeriodStatusResponseVO> remitRptCurrencyDet) {
		this.remitRptCurrencyDet = remitRptCurrencyDet;
	}

	public List<PeriodStatusResponseVO> getRemitRptPeriodDet() {
		return remitRptPeriodDet;
	}

	public void setRemitRptPeriodDet(List<PeriodStatusResponseVO> remitRptPeriodDet) {
		this.remitRptPeriodDet = remitRptPeriodDet;
	}

	public List<PeriodStatusResponseVO> getRemitRptStatusDet() {
		return remitRptStatusDet;
	}

	public void setRemitRptStatusDet(List<PeriodStatusResponseVO> remitRptStatusDet) {
		this.remitRptStatusDet = remitRptStatusDet;
	}

	public List<PeriodStatusResponseVO> getRemitRptBuyerDet() {
		return remitRptBuyerDet;
	}

	public void setRemitRptBuyerDet(List<PeriodStatusResponseVO> remitRptBuyerDet) {
		this.remitRptBuyerDet = remitRptBuyerDet;
	}

	public List<PeriodStatusResponseVO> getRemitRptSupplierDet() {
		return remitRptSupplierDet;
	}

	public void setRemitRptSupplierDet(List<PeriodStatusResponseVO> remitRptSupplierDet) {
		this.remitRptSupplierDet = remitRptSupplierDet;
	}

	public List<PeriodStatusResponseVO> getCntCurrencyDet() {
		return cntCurrencyDet;
	}

	public void setCntCurrencyDet(List<PeriodStatusResponseVO> cntCurrencyDet) {
		this.cntCurrencyDet = cntCurrencyDet;
	}

	public List<PeriodStatusResponseVO> getCntPeriodDet() {
		return cntPeriodDet;
	}

	public void setCntPeriodDet(List<PeriodStatusResponseVO> cntPeriodDet) {
		this.cntPeriodDet = cntPeriodDet;
	}

	public List<PeriodStatusResponseVO> getCntStatusDet() {
		return cntStatusDet;
	}

	public void setCntStatusDet(List<PeriodStatusResponseVO> cntStatusDet) {
		this.cntStatusDet = cntStatusDet;
	}

	public List<PeriodStatusResponseVO> getCntBuyerDet() {
		return cntBuyerDet;
	}

	public void setCntBuyerDet(List<PeriodStatusResponseVO> cntBuyerDet) {
		this.cntBuyerDet = cntBuyerDet;
	}

	public List<PeriodStatusResponseVO> getCntSupplierDet() {
		return cntSupplierDet;
	}

	public void setCntSupplierDet(List<PeriodStatusResponseVO> cntSupplierDet) {
		this.cntSupplierDet = cntSupplierDet;
	}

	public List<PeriodStatusResponseVO> getLmtClientOrgDet() {
		return lmtClientOrgDet;
	}

	public void setLmtClientOrgDet(List<PeriodStatusResponseVO> lmtClientOrgDet) {
		this.lmtClientOrgDet = lmtClientOrgDet;
	}

	public List<PeriodStatusResponseVO> getLmtCounterOrgDet() {
		return lmtCounterOrgDet;
	}

	public void setLmtCounterOrgDet(List<PeriodStatusResponseVO> lmtCounterOrgDet) {
		this.lmtCounterOrgDet = lmtCounterOrgDet;
	}

	public List<PeriodStatusResponseVO> getLmtLimitTypDet() {
		return lmtLimitTypDet;
	}

	public void setLmtLimitTypDet(List<PeriodStatusResponseVO> lmtLimitTypDet) {
		this.lmtLimitTypDet = lmtLimitTypDet;
	}

	public List<PeriodStatusResponseVO> getLmtIncConvLimDet() {
		return lmtIncConvLimDet;
	}

	public void setLmtIncConvLimDet(List<PeriodStatusResponseVO> lmtIncConvLimDet) {
		this.lmtIncConvLimDet = lmtIncConvLimDet;
	}

	public List<PeriodStatusResponseVO> getSenderOrgIdDet() {
		return senderOrgIdDet;
	}

	public void setSenderOrgIdDet(List<PeriodStatusResponseVO> senderOrgIdDet) {
		this.senderOrgIdDet = senderOrgIdDet;
	}

	public List<StatusDetailsVO> getDocTypeIdDet() {
		return docTypeIdDet;
	}

	public void setDocTypeIdDet(List<StatusDetailsVO> docTypeIdDet) {
		this.docTypeIdDet = docTypeIdDet;
	}

	public List<StatusDetailsVO> getStatusDet() {
		return statusDet;
	}

	public void setStatusDet(List<StatusDetailsVO> statusDet) {
		this.statusDet = statusDet;
	}

	public List<StatusDetailsVO> getBranchDet() {
		return branchDet;
	}

	public void setBranchDet(List<StatusDetailsVO> branchDet) {
		this.branchDet = branchDet;
	}

	public List<PeriodStatusResponseVO> getPeriodDet() {
		return periodDet;
	}

	public void setPeriodDet(List<PeriodStatusResponseVO> periodDet) {
		this.periodDet = periodDet;
	}

	public List<PeriodStatusResponseVO> getQuickSearchDet() {
		return quickSearchDet;
	}

	public void setQuickSearchDet(List<PeriodStatusResponseVO> quickSearchDet) {
		this.quickSearchDet = quickSearchDet;
	}

	public List<StatusDetailsVO> getCcyDet() {
		return ccyDet;
	}

	public void setCcyDet(List<StatusDetailsVO> ccyDet) {
		this.ccyDet = ccyDet;
	}

	public List<StatusDetailsVO> getClientOrgDet() {
		return clientOrgDet;
	}

	public void setClientOrgDet(List<StatusDetailsVO> clientOrgDet) {
		this.clientOrgDet = clientOrgDet;
	}

	public List<StatusDetailsVO> getCounterPtyDet() {
		return counterPtyDet;
	}

	public void setCounterPtyDet(List<StatusDetailsVO> counterPtyDet) {
		this.counterPtyDet = counterPtyDet;
	}

	public List<StatusDetailsVO> getFileStatusDet() {
		return fileStatusDet;
	}

	public void setFileStatusDet(List<StatusDetailsVO> fileStatusDet) {
		this.fileStatusDet = fileStatusDet;
	}

	public List<PeriodStatusResponseVO> getReportBranchDet() {
		return reportBranchDet;
	}

	public void setReportBranchDet(List<PeriodStatusResponseVO> reportBranchDet) {
		this.reportBranchDet = reportBranchDet;
	}

	public List<PeriodStatusResponseVO> getChartTypeDet() {
		return chartTypeDet;
	}

	public void setChartTypeDet(List<PeriodStatusResponseVO> chartTypeDet) {
		this.chartTypeDet = chartTypeDet;
	}

	public List<PeriodStatusResponseVO> getPlotParamDet() {
		return plotParamDet;
	}

	public void setPlotParamDet(List<PeriodStatusResponseVO> plotParamDet) {
		this.plotParamDet = plotParamDet;
	}

	public List<PeriodStatusResponseVO> getYearDet() {
		return yearDet;
	}

	public void setYearDet(List<PeriodStatusResponseVO> yearDet) {
		this.yearDet = yearDet;
	}

	public List<PeriodStatusResponseVO> getOrgIdDet() {
		return orgIdDet;
	}

	public void setOrgIdDet(List<PeriodStatusResponseVO> orgIdDet) {
		this.orgIdDet = orgIdDet;
	}

	public List<PeriodStatusResponseVO> getCcyHolDet() {
		return ccyHolDet;
	}

	public void setCcyHolDet(List<PeriodStatusResponseVO> ccyHolDet) {
		this.ccyHolDet = ccyHolDet;
	}



	public List<PeriodStatusResponseVO> getEmailDelvStatusDet() {
		return emailDelvStatusDet;
	}

	public void setEmailDelvStatusDet(
			List<PeriodStatusResponseVO> emailDelvStatusDet) {
		this.emailDelvStatusDet = emailDelvStatusDet;
	}

	public List<PeriodStatusResponseVO> getEmailCategoryDet() {
		return emailCategoryDet;
	}

	public void setEmailCategoryDet(List<PeriodStatusResponseVO> emailCategoryDet) {
		this.emailCategoryDet = emailCategoryDet;
	}

	public List<PeriodStatusResponseVO> getEmailEventDet() {
		return emailEventDet;
	}

	public void setEmailEventDet(List<PeriodStatusResponseVO> emailEventDet) {
		this.emailEventDet = emailEventDet;
	}

	public List<PeriodStatusResponseVO> getEmailInqOrgDet() {
		return emailInqOrgDet;
	}

	public void setEmailInqOrgDet(List<PeriodStatusResponseVO> emailInqOrgDet) {
		this.emailInqOrgDet = emailInqOrgDet;
	}

	public List<PeriodStatusResponseVO> getEmailInqPeriodDet() {
		return emailInqPeriodDet;
	}

	public void setEmailInqPeriodDet(List<PeriodStatusResponseVO> emailInqPeriodDet) {
		this.emailInqPeriodDet = emailInqPeriodDet;
	}

	public List<PeriodStatusResponseVO> getCounterPartyDet() {
		return counterPartyDet;
	}

	public void setCounterPartyDet(List<PeriodStatusResponseVO> counterPartyDet) {
		this.counterPartyDet = counterPartyDet;
	}

	public List<PeriodStatusResponseVO> getStlmtReportType() {
		return stlmtReportType;
	}

	public void setStlmtReportType(List<PeriodStatusResponseVO> stlmtReportType) {
		this.stlmtReportType = stlmtReportType;
	}

	/**
	 * @return the pymtReportType
	 */
	public List<PeriodStatusResponseVO> getPymtReportType() {
		return pymtReportType;
	}

	/**
	 * @param pymtReportType the pymtReportType to set
	 */
	public void setPymtReportType(List<PeriodStatusResponseVO> pymtReportType) {
		this.pymtReportType = pymtReportType;
	}

	public PeriodStatusResponseVO getBranchLocaleDateType() {
		return branchLocaleDateType;
	}

	public void setBranchLocaleDateType(PeriodStatusResponseVO branchLocaleDateType) {
		this.branchLocaleDateType = branchLocaleDateType;
	}

	/**
	 * @return the reportTypeDet
	 */
	public List<PeriodStatusResponseVO> getReportTypeDet() {
		return reportTypeDet;
	}

	/**
	 * @param reportTypeDet the reportTypeDet to set
	 */
	public void setReportTypeDet(List<PeriodStatusResponseVO> reportTypeDet) {
		this.reportTypeDet = reportTypeDet;
	}

	/**
	 * @return the reportOrgIdDet
	 */
	public List<PeriodStatusResponseVO> getReportOrgIdDet() {
		return reportOrgIdDet;
	}

	/**
	 * @param reportOrgIdDet the reportOrgIdDet to set
	 */
	public void setReportOrgIdDet(List<PeriodStatusResponseVO> reportOrgIdDet) {
		this.reportOrgIdDet = reportOrgIdDet;
	}

	/**
	 * @return the reportPeriodDet
	 */
	public List<PeriodStatusResponseVO> getReportPeriodDet() {
		return reportPeriodDet;
	}

	/**
	 * @param reportPeriodDet the reportPeriodDet to set
	 */
	public void setReportPeriodDet(List<PeriodStatusResponseVO> reportPeriodDet) {
		this.reportPeriodDet = reportPeriodDet;
	}

	/**
	 * @return the reportFrequenctDet
	 */
	public List<PeriodStatusResponseVO> getReportFrequenctDet() {
		return reportFrequenctDet;
	}

	/**
	 * @param reportFrequenctDet the reportFrequenctDet to set
	 */
	public void setReportFrequenctDet(List<PeriodStatusResponseVO> reportFrequenctDet) {
		this.reportFrequenctDet = reportFrequenctDet;
	}

	/**
	 * @return the plotParamPreStlmtDet
	 */
	public List<PeriodStatusResponseVO> getPlotParamPreStlmtDet() {
		return plotParamPreStlmtDet;
	}

	/**
	 * @param plotParamPreStlmtDet the plotParamPreStlmtDet to set
	 */
	public void setPlotParamPreStlmtDet(
			List<PeriodStatusResponseVO> plotParamPreStlmtDet) {
		this.plotParamPreStlmtDet = plotParamPreStlmtDet;
	}

	public List<PeriodStatusResponseVO> getDscCurrencyDet() {
		return dscCurrencyDet;
	}

	public void setDscCurrencyDet(List<PeriodStatusResponseVO> dscCurrencyDet) {
		this.dscCurrencyDet = dscCurrencyDet;
	}

	public List<PeriodStatusResponseVO> getDscPeriodDet() {
		return dscPeriodDet;
	}

	public void setDscPeriodDet(List<PeriodStatusResponseVO> dscPeriodDet) {
		this.dscPeriodDet = dscPeriodDet;
	}

	public List<PeriodStatusResponseVO> getDscStatusDet() {
		return dscStatusDet;
	}

	public void setDscStatusDet(List<PeriodStatusResponseVO> dscStatusDet) {
		this.dscStatusDet = dscStatusDet;
	}

	public List<PeriodStatusResponseVO> getDscBuyerDet() {
		return dscBuyerDet;
	}

	public void setDscBuyerDet(List<PeriodStatusResponseVO> dscBuyerDet) {
		this.dscBuyerDet = dscBuyerDet;
	}

	public List<PeriodStatusResponseVO> getDscSupplierDet() {
		return dscSupplierDet;
	}

	public void setDscSupplierDet(List<PeriodStatusResponseVO> dscSupplierDet) {
		this.dscSupplierDet = dscSupplierDet;
	}

	/**
	 * @return the agingDiscountType
	 */
	public List<PeriodStatusResponseVO> getAgingDiscountType() {
		return agingDiscountType;
	}

	/**
	 * @param agingDiscountType the agingDiscountType to set
	 */
	public void setAgingDiscountType(List<PeriodStatusResponseVO> agingDiscountType) {
		this.agingDiscountType = agingDiscountType;
	}
	
	
}
