/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Payment Order List Details Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 21 Feb 2017				Sathishkumar B										FO 10.0 - S008, S009, S010, S011, S012, S013, S014
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;
import java.util.Date;

public class PaymentOrderListDetailsVO {

	private String userId;
	
	private String buyerRefNumberUnique;
	
	private String invoiceRefNo;
	
	private Date invoiceIssueDate;
	
	private BigDecimal invoiceAmount;
	
	private BigDecimal discInvoiceAmount;
	
	private BigDecimal remInvoiceAmount;
	
	private boolean attachementIconInd;
	
	private String indicatorFlag;
	
	private boolean callOutIndicator;
	
	private boolean lineItemInd;
	
	private String errorMsg;

	private String countUtilId;
	
	private String invoiceRefOrder;
	
	private String pymtId;
	
	/** Invoice and Credit Note Call Out Starts**/
	private String buyerRefNo;
	
	private String sellerRefNo;

	private String cntInvoiceRefNo;
	
	private Date cntEffectDate;
	
	private String cntUtilizedAmt;
	
	private BigDecimal cntOriginalAmt;
	
	private String invoiceCreditNoteID;
	/** Invoice and Credit Note Call Out Ends**/
	
	private String invCrdCcy;
	
	private Date crdUtilDate;
	
	private Date invDueDate;
	
	private String invUniqRefNo;
	
	private String crdNtUniqRefNo;
	
	private int decimalPoint;
	
	/**Discount Popup Details - PO Details - FO 10.0 - S008, S009, S010, S011, S012, S013, S014**/
	private String paymentRefno;
	
	
	public String getInvUniqRefNo() {
		return invUniqRefNo;
	}

	public void setInvUniqRefNo(String invUniqRefNo) {
		this.invUniqRefNo = invUniqRefNo;
	}

	public String getCrdNtUniqRefNo() {
		return crdNtUniqRefNo;
	}

	public void setCrdNtUniqRefNo(String crdNtUniqRefNo) {
		this.crdNtUniqRefNo = crdNtUniqRefNo;
	}
	
	public String getInvCrdCcy() {
		return invCrdCcy;
	}

	public void setInvCrdCcy(String invCrdCcy) {
		this.invCrdCcy = invCrdCcy;
	}

	public Date getCrdUtilDate() {
		return crdUtilDate;
	}

	public void setCrdUtilDate(Date crdUtilDate) {
		this.crdUtilDate = crdUtilDate;
	}

	private String commitmentReleaseDate;
	
	private String paymentDueDate;
	
	private String paymentCCY;
	
	private String paymentAmount;
	
	private String updatedPaymentAmount;
	/**Discount Popup Details - PO Details - FO 10.0 - S008, S009, S010, S011, S012, S013, S014**/
	
	private long invId;
	
	private String ccyCode;
	
	public Date getInvDueDate() {
		return invDueDate;
	}

	public void setInvDueDate(Date invDueDate) {
		this.invDueDate = invDueDate;
	}

	public String getPymtId() {
		return pymtId;
	}

	public void setPymtId(String pymtId) {
		this.pymtId = pymtId;
	}

	public String getCountUtilId() {
		return countUtilId;
	}

	public void setCountUtilId(String countUtilId) {
		this.countUtilId = countUtilId;
	}

	public String getInvoiceRefOrder() {
		return invoiceRefOrder;
	}

	public void setInvoiceRefOrder(String invoiceRefOrder) {
		this.invoiceRefOrder = invoiceRefOrder;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getBuyerRefNumberUnique() {
		return buyerRefNumberUnique;
	}

	public void setBuyerRefNumberUnique(String buyerRefNumberUnique) {
		this.buyerRefNumberUnique = buyerRefNumberUnique;
	}

	public String getInvoiceRefNo() {
		return invoiceRefNo;
	}

	public void setInvoiceRefNo(String invoiceRefNo) {
		this.invoiceRefNo = invoiceRefNo;
	}

	public Date getInvoiceIssueDate() {
		return invoiceIssueDate;
	}

	public void setInvoiceIssueDate(Date invoiceIssueDate) {
		this.invoiceIssueDate = invoiceIssueDate;
	}

	public BigDecimal getInvoiceAmount() {
		return invoiceAmount;
	}

	public void setInvoiceAmount(BigDecimal invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}

	public BigDecimal getDiscInvoiceAmount() {
		return discInvoiceAmount;
	}

	public void setDiscInvoiceAmount(BigDecimal discInvoiceAmount) {
		this.discInvoiceAmount = discInvoiceAmount;
	}

	public BigDecimal getRemInvoiceAmount() {
		return remInvoiceAmount;
	}

	public void setRemInvoiceAmount(BigDecimal remInvoiceAmount) {
		this.remInvoiceAmount = remInvoiceAmount;
	}
	
	public boolean isAttachementIconInd() {
		return attachementIconInd;
	}

	public void setAttachementIconInd(boolean attachementIconInd) {
		this.attachementIconInd = attachementIconInd;
	}

	public String getIndicatorFlag() {
		return indicatorFlag;
	}

	public void setIndicatorFlag(String indicatorFlag) {
		this.indicatorFlag = indicatorFlag;
	}	

	public boolean isCallOutIndicator() {
		return callOutIndicator;
	}

	public void setCallOutIndicator(boolean callOutIndicator) {
		this.callOutIndicator = callOutIndicator;
	}

	public boolean isLineItemInd() {
		return lineItemInd;
	}

	public void setLineItemInd(boolean lineItemInd) {
		this.lineItemInd = lineItemInd;
	}

	/** Invoice and Credit Note Call Out Starts**/
	public String getBuyerRefNo() {
		return buyerRefNo;
	}

	public void setBuyerRefNo(String buyerRefNo) {
		this.buyerRefNo = buyerRefNo;
	}

	public String getSellerRefNo() {
		return sellerRefNo;
	}

	public long getInvId() {
		return invId;
	}

	public void setInvId(long invId) {
		this.invId = invId;
	}

	public void setSellerRefNo(String sellerRefNo) {
		this.sellerRefNo = sellerRefNo;
	}

	public String getCntInvoiceRefNo() {
		return cntInvoiceRefNo;
	}

	public void setCntInvoiceRefNo(String cntInvoiceRefNo) {
		this.cntInvoiceRefNo = cntInvoiceRefNo;
	}

	public Date getCntEffectDate() {
		return cntEffectDate;
	}

	public void setCntEffectDate(Date cntEffectDate) {
		this.cntEffectDate = cntEffectDate;
	}

	public String getCntUtilizedAmt() {
		return cntUtilizedAmt;
	}

	public void setCntUtilizedAmt(String cntUtilizedAmt) {
		this.cntUtilizedAmt = cntUtilizedAmt;
	}

	public String getInvoiceCreditNoteID() {
		return invoiceCreditNoteID;
	}

	public void setInvoiceCreditNoteID(String invoiceCreditNoteID) {
		this.invoiceCreditNoteID = invoiceCreditNoteID;
	}

	public BigDecimal getCntOriginalAmt() {
		return cntOriginalAmt;
	}

	public void setCntOriginalAmt(BigDecimal cntOriginalAmt) {
		this.cntOriginalAmt = cntOriginalAmt;
	}

	/** Invoice and Credit Note Call Out Ends**/
	
	
	/**Discount Popup Details - PO Details - FO 10.0 - S008, S009, S010, S011, S012, S013, S014**/
	public String getPaymentRefno() {
		return paymentRefno;
	}

	public void setPaymentRefno(String paymentRefno) {
		this.paymentRefno = paymentRefno;
	}

	public String getCommitmentReleaseDate() {
		return commitmentReleaseDate;
	}

	public void setCommitmentReleaseDate(String commitmentReleaseDate) {
		this.commitmentReleaseDate = commitmentReleaseDate;
	}

	public String getPaymentDueDate() {
		return paymentDueDate;
	}

	public void setPaymentDueDate(String paymentDueDate) {
		this.paymentDueDate = paymentDueDate;
	}

	public String getPaymentCCY() {
		return paymentCCY;
	}

	public void setPaymentCCY(String paymentCCY) {
		this.paymentCCY = paymentCCY;
	}

	public String getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public String getUpdatedPaymentAmount() {
		return updatedPaymentAmount;
	}

	public void setUpdatedPaymentAmount(String updatedPaymentAmount) {
		this.updatedPaymentAmount = updatedPaymentAmount;
	}
	/**Discount Popup Details - PO Details - FO 10.0 - S008, S009, S010, S011, S012, S013, S014**/

	/**
	 * @return the decimalPoint
	 */
	public int getDecimalPoint() {
		return decimalPoint;
	}

	/**
	 * @param decimalPoint the decimalPoint to set
	 */
	public void setDecimalPoint(int decimalPoint) {
		this.decimalPoint = decimalPoint;
	}
	
	
	/**
	 * Getter methods introduced to send the amounts as
	 * String to avoid amount > 16 digits getting truncated
	 * Added as part of defect Fix CSC-7835
	 */
	
	public String getInvoiceAmountStr()
	{
		return (invoiceAmount!=null)?invoiceAmount.toPlainString():"";
	}
	
	public String getDiscInvoiceAmountStr()
	{
		return (discInvoiceAmount!=null)?discInvoiceAmount.toPlainString():"";
	}
	
	public String getRemInvoiceAmountStr()
	{
		return (remInvoiceAmount!=null)?remInvoiceAmount.toPlainString():"";
	}
	
	public String getCntOriginalAmtStr()
	{
		return (cntOriginalAmt!=null)?cntOriginalAmt.toPlainString():"";
	}

	
}
