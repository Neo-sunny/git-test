/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   23-Feb-2017 by AnubhaJ
 * 
 * Purpose:      Contact Us pop Up object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 23-Feb-2017				AnubhaJ												Created FO 10.0 S015,S016,S017
************************************************************************************************************************************************************/

package com.bnp.bnpux.serviceimpl;


import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.common.vo.ContactUsVO;
import com.bnp.bnpux.common.vo.CountryFlagVO;
import com.bnp.bnpux.constants.ContactUsConstants;
import com.bnp.bnpux.constants.ErrorConstants;
import com.bnp.bnpux.dao.ICommonDAO;
import com.bnp.bnpux.service.IContactUsService;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.mail.BNPEmailSender;

@Component 
@Scope("request")
public class ContactUsServiceImpl implements IContactUsService {
	
	
	/**
	 * Logger log for ContactUsServiceImpl class
	 */
	public static final Logger log = LoggerFactory.getLogger(ContactUsServiceImpl.class);
	
	/**
	 * ICommonDAO ICommonDAO;
	 */
	@Autowired
	private ICommonDAO iCommonDAO;

	/**
	 * BNPPropertyLoaderConfigurer propertyLoader  : load property of mail;
	 */
	@Autowired
	protected BNPPropertyLoaderConfigurer propertyLoader;
	
	/**
	 * BNPEmailSender emailSender  : sending email;
	 */
	@Autowired
	private BNPEmailSender emailSender;
	
	
	@Autowired
	protected ReloadableResourceBundleMessageSource resourceBundle;
	
	
	/**
	 * This method is for getting Location DropDown
	 * 
	 * @param 
	 * @return List<CountryVO>
	 * @throws BNPApplicationException
	 */
	@Override
	public List<CountryFlagVO> fetchLocationDropDwn() throws BNPApplicationException{
		List<CountryFlagVO> countryList = new ArrayList<CountryFlagVO>(); 
		
		
		try{
			countryList = iCommonDAO.fetchCountryList();
		}catch(DataAccessException ex){
			log.error(ContactUsConstants.EXCEPTION_UNABLE_TO_PROCESS, ex);
			throw new BNPApplicationException(ContactUsConstants.EXCEPTION_UNABLE_TO_PROCESS);
		}
		return countryList;
	}
	
	/**
	 * This method is for sending Contact Details
	 * 
	 * @param ContactUsVO
	 * @return ContactUsVO
	 * @throws BNPApplicationException
	 */
	@Override
	public ContactUsVO sendContactUsDetails(ContactUsVO contactUsVO)throws BNPApplicationException {
		try{
		Map<Object,Object> model = new HashMap<Object, Object>();
		String emailId = propertyLoader.getValue("contactus.email.id");
		String template = propertyLoader.getValue("contactus.template.vm");
		model.put("toList", emailId);
		if(contactUsVO !=null){
		model.put("contactUsVO", contactUsVO);
		model.put("subject",contactUsVO.getSubject());
		}
		emailSender.sendMail(model, template);
		contactUsVO.setErrorMsg(Integer.toString(ErrorConstants.EMAIL_SEND_SUCCESS));
		}catch (BNPApplicationException ex) {
			log.error(ContactUsConstants.EXCEPTION_UNABLE_TO_PROCESS, ex);
			throw new BNPApplicationException(ContactUsConstants.EXCEPTION_UNABLE_TO_PROCESS);
		}
		return contactUsVO;
	}

	

	
}
