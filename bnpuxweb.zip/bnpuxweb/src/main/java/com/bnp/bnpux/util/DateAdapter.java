/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   07 Apr 2016
 * 
 * Purpose:     Date Adapter
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 11 Apr 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 
 *****************************************************************************************************************************************************************/

package com.bnp.bnpux.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.xml.bind.annotation.adapters.XmlAdapter;

import com.bnp.bnpux.util.PropertiesReader;

public class DateAdapter extends XmlAdapter<String, Calendar> {

	private static final String PATTERN = PropertiesReader.getProperty("message.date.format");
	private SimpleDateFormat df = new SimpleDateFormat(PATTERN);
	
	/**
	 * @param value
	 * @return Calendar
	 * @throws Exception
	 * @see javax.xml.bind.annotation.adapters.XmlAdapter#unmarshal(java.lang.Object)
	 * @Description Set Value in Calendar Time and Return Calendar
	 */
	public Calendar unmarshal(String value) throws Exception {
		if (value == null || value.trim().length() == 0) {
			return null;
		}
		df.setLenient(false);
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(df.parse(value));
		return calendar;
	}
	
	/**
	 * @param value
	 * @return String
	 * @see javax.xml.bind.annotation.adapters.XmlAdapter#marshal(java.lang.Object)
	 * @Description Get the Calendar Date in Specific Format for passed Value 
	 */
	public String marshal(Calendar value) {
		if (value == null) {
			return null;
		}
		return df.format(value.getTime());
	}
}
