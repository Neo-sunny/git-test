package com.bnp.bnpux.vo.requestVO;

import java.sql.Timestamp;
import java.util.List;

import com.bnp.bnpux.common.vo.ViewScheduledReportListVO;

public class ViewScheduledReportRequestVO {
	private String userId;
	private String userTypeId;
	private String errorFlag;
	private String exportType;
	private String viewType;
	private String  report;
	private String frequency;
	private String reportOrgId;
	private String  reportFileName;
	private String  reportScheduleId;
	private String period;
	private String  dateFrom;
	private String  dateTo;
	private Integer recordFrom;
	private Integer recordTo;
	private String  fetchItem;
	private List<ViewScheduledReportListVO> viewScheduledReportList;
	private byte[] reportData;
	private String reportFormat;
	private String generatedReportId;
	private String lastViewed;
	private String recoredNo;
	private long u_generatedReportId;
	private String lastViewedBy;
	private String branch;
	
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the userTypeId
	 */
	public String getUserTypeId() {
		return userTypeId;
	}

	/**
	 * @param userTypeId the userTypeId to set
	 */
	public void setUserTypeId(String userTypeId) {
		this.userTypeId = userTypeId;
	}

	/**
	 * @return the errorFlag
	 */
	public String getErrorFlag() {
		return errorFlag;
	}

	/**
	 * @param errorFlag the errorFlag to set
	 */
	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	/**
	 * @return the exportType
	 */
	public String getExportType() {
		return exportType;
	}

	/**
	 * @param exportType the exportType to set
	 */
	public void setExportType(String exportType) {
		this.exportType = exportType;
	}

	/**
	 * @return the viewType
	 */
	public String getViewType() {
		return viewType;
	}

	/**
	 * @param viewType the viewType to set
	 */
	public void setViewType(String viewType) {
		this.viewType = viewType;
	}

	/**
	 * @return the report
	 */
	public String getReport() {
		return report;
	}

	/**
	 * @param report the report to set
	 */
	public void setReport(String report) {
		this.report = report;
	}

	/**
	 * @return the frequency
	 */
	public String getFrequency() {
		return frequency;
	}

	/**
	 * @param frequency the frequency to set
	 */
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	/**
	 * @return the reportOrgId
	 */
	public String getReportOrgId() {
		return reportOrgId;
	}

	/**
	 * @param reportOrgId the reportOrgId to set
	 */
	public void setReportOrgId(String reportOrgId) {
		this.reportOrgId = reportOrgId;
	}

	/**
	 * @return the reportFileName
	 */
	public String getReportFileName() {
		return reportFileName;
	}

	/**
	 * @param reportFileName the reportFileName to set
	 */
	public void setReportFileName(String reportFileName) {
		this.reportFileName = reportFileName;
	}

	/**
	 * @return the reportScheduleId
	 */
	public String getReportScheduleId() {
		return reportScheduleId;
	}

	/**
	 * @param reportScheduleId the reportScheduleId to set
	 */
	public void setReportScheduleId(String reportScheduleId) {
		this.reportScheduleId = reportScheduleId;
	}

	/**
	 * @return the period
	 */
	public String getPeriod() {
		return period;
	}

	/**
	 * @param period the period to set
	 */
	public void setPeriod(String period) {
		this.period = period;
	}

	/**
	 * @return the dateFrom
	 */
	public String getDateFrom() {
		return dateFrom;
	}

	/**
	 * @param dateFrom the dateFrom to set
	 */
	public void setDateFrom(String dateFrom) {
		this.dateFrom = dateFrom;
	}

	/**
	 * @return the dateTo
	 */
	public String getDateTo() {
		return dateTo;
	}

	/**
	 * @param dateTo the dateTo to set
	 */
	public void setDateTo(String dateTo) {
		this.dateTo = dateTo;
	}

	/**
	 * @return the recordFrom
	 */
	public Integer getRecordFrom() {
		return recordFrom;
	}

	/**
	 * @param recordFrom the recordFrom to set
	 */
	public void setRecordFrom(Integer recordFrom) {
		this.recordFrom = recordFrom;
	}

	/**
	 * @return the recordTo
	 */
	public Integer getRecordTo() {
		return recordTo;
	}

	/**
	 * @param recordTo the recordTo to set
	 */
	public void setRecordTo(Integer recordTo) {
		this.recordTo = recordTo;
	}

	/**
	 * @return the fetchItem
	 */
	public String getFetchItem() {
		return fetchItem;
	}

	/**
	 * @param fetchItem the fetchItem to set
	 */
	public void setFetchItem(String fetchItem) {
		this.fetchItem = fetchItem;
	}

	/**
	 * @return the viewScheduledReportList
	 */
	public List<ViewScheduledReportListVO> getViewScheduledReportList() {
		return viewScheduledReportList;
	}

	/**
	 * @param viewScheduledReportList the viewScheduledReportList to set
	 */
	public void setViewScheduledReportList(List<ViewScheduledReportListVO> viewScheduledReportList) {
		this.viewScheduledReportList = viewScheduledReportList;
	}

	/**
	 * @return the reportData
	 */
	public byte[] getReportData() {
		return reportData;
	}

	/**
	 * @param reportData the reportData to set
	 */
	public void setReportData(byte[] reportData) {
		this.reportData = reportData;
	}

	/**
	 * @return the reportFormat
	 */
	public String getReportFormat() {
		return reportFormat;
	}

	/**
	 * @param reportFormat the reportFormat to set
	 */
	public void setReportFormat(String reportFormat) {
		this.reportFormat = reportFormat;
	}

	/**
	 * @return the generatedReportId
	 */
	public String getGeneratedReportId() {
		return generatedReportId;
	}

	/**
	 * @param generatedReportId the generatedReportId to set
	 */
	public void setGeneratedReportId(String generatedReportId) {
		this.generatedReportId = generatedReportId;
	}

	/**
	 * @return the recoredNo
	 */
	public String getRecoredNo() {
		return recoredNo;
	}

	/**
	 * @param recoredNo the recoredNo to set
	 */
	public void setRecoredNo(String recoredNo) {
		this.recoredNo = recoredNo;
	}

	/**
	 * @return the u_generatedReportId
	 */
	public long getU_generatedReportId() {
		return u_generatedReportId;
	}

	/**
	 * @param u_generatedReportId the u_generatedReportId to set
	 */
	public void setU_generatedReportId(long u_generatedReportId) {
		this.u_generatedReportId = u_generatedReportId;
	}

	/**
	 * @return the lastViewed
	 */
	public String getLastViewed() {
		return lastViewed;
	}

	/**
	 * @param lastViewed the lastViewed to set
	 */
	public void setLastViewed(String lastViewed) {
		this.lastViewed = lastViewed;
	}

	/**
	 * @return the lastViewedBy
	 */
	public String getLastViewedBy() {
		return lastViewedBy;
	}

	/**
	 * @param lastViewedBy the lastViewedBy to set
	 */
	public void setLastViewedBy(String lastViewedBy) {
		this.lastViewedBy = lastViewedBy;
	}

	/**
	 * @return the branch
	 */
	public String getBranch() {
		return branch;
	}

	/**
	 * @param branch the branch to set
	 */
	public void setBranch(String branch) {
		this.branch = branch;
	}


	
}
