/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     DataSource Connector
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 
 *****************************************************************************************************************************************************************/
package com.bnp.bnpux.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DataSourceConnector {

    private static DataSource dataSource;

    static {
        try {
            dataSource = (DataSource) new InitialContext().lookup("jdbc/GSCSDatasource");
        }
        catch (NamingException e) { 
            throw new ExceptionInInitializerError("'jndifordbconc' not found in JNDI");
        }
    }

    /**
     * @return Connection
     * @throws SQLException
     * @Description get Connection from DataSource 
     */
    public static Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

}