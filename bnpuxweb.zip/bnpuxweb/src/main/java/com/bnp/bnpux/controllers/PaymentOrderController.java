/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Payment Order Controller
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 23-FEB-2017				Divyashri Subramaniam						Added new method getPDFpopupDetails for S001
 * 01-JAN-2018				Bala Murugan Elangovan						Added new method validateDiscDateWithHoliday for S101001 as part of FO10.1 Sprint 2
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.common.bean.RecallInvoicesBean;
import com.bnp.bnpux.common.vo.PaymentOrderAvailableamtCalloutVO;
import com.bnp.bnpux.common.vo.PaymentOrderListCollectionVO;
import com.bnp.bnpux.common.vo.PaymentOrderListVO;
import com.bnp.bnpux.common.vo.RecallResponseVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.constants.PaymentOrderConstants;
import com.bnp.bnpux.service.IAuditService;
import com.bnp.bnpux.service.IDiscountServiceUX;
import com.bnp.bnpux.service.INewAttachmentService;
import com.bnp.bnpux.service.IPaymentOrderService;
import com.bnp.bnpux.util.RequestIdentityValidator;
import com.bnp.bnpux.vo.errorMessageVO.ErrorMessageVO;
import com.bnp.bnpux.vo.requestVO.AttachmentRequestVO;
import com.bnp.bnpux.vo.requestVO.AuditRequestVO;
import com.bnp.bnpux.vo.requestVO.PaymentOrderCreditNoteLineItemRequestVO;
import com.bnp.bnpux.vo.requestVO.PaymentOrderInvoiceDetailsRequestVO;
import com.bnp.bnpux.vo.requestVO.PaymentOrderPopupRequestVO;
import com.bnp.bnpux.vo.requestVO.PaymentOrderRequestVO;
import com.bnp.bnpux.vo.responseVO.AttachmentResponseVO;
import com.bnp.bnpux.vo.responseVO.DiscountResponseVO;
import com.bnp.bnpux.vo.responseVO.PaymentOrderCreditNoteLineItemResponseVO;
import com.bnp.bnpux.vo.responseVO.PaymentOrderInvoiceDetailsResponseVO;
import com.bnp.bnpux.vo.responseVO.PaymentOrderResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.discounting.vo.DiscountRequestVO;
import com.bnp.scm.services.invoice.vo.RecallInvoiceVO;

@RestController
@RequestMapping("/paymentOrderCtrl")
public class PaymentOrderController {


	/**
	 * Logger for PaymentOrderController
	 */
	public static final Logger log = LoggerFactory.getLogger(PaymentOrderController.class);


	/**
	 * Autowired Interface IPaymentOrderService
	 */
	@Autowired
	private IPaymentOrderService paymentOrderService;

	@Autowired
	private INewAttachmentService attachmentService;
    @Autowired
	private IDiscountServiceUX discountRequestService;

    @Autowired
	private IAuditService auditService;

    @Autowired
    private RecallInvoicesBean recallInvoiceBean;

    @Autowired
	RequestIdentityValidator validateRequest;
	/**
	 * This method is for getting the Payment Order Details
	 * 
	 * @param paymentOrderRequestVO
	 * @return
	 */
	@RequestMapping(value = "getPaymentOrderdetails.rest", method = RequestMethod.POST)
	public PaymentOrderResponseVO getPaymentOrderDetails(@RequestBody PaymentOrderRequestVO paymentOrderRequestVO,HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		PaymentOrderResponseVO paymentOrderResponseVO = null;
		try {
			boolean requestValidatedFlag = validateRequest.validate(paymentOrderRequestVO.getUserId(),httpServletRequest.getSession());
			if(requestValidatedFlag){
				paymentOrderResponseVO = new PaymentOrderResponseVO();
				paymentOrderResponseVO = paymentOrderService.getPaymentOrderDetails(paymentOrderRequestVO);
			}
			else{
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (BNPApplicationException exception) {
			paymentOrderResponseVO.setErrorMsg(exception.getMessage());
			log.error(exception.getMessage(),exception);
		}
		return paymentOrderResponseVO;
	}
	
	@RequestMapping(value = "getAdvancedFilterIndicatorCount.rest", method = RequestMethod.POST)
	public PaymentOrderResponseVO getAdvancedFilterIndicatorCount(@RequestBody PaymentOrderRequestVO paymentOrderRequestVO,HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		PaymentOrderResponseVO paymentOrderResponseVO = null;
		try {
			boolean requestValidatedFlag = validateRequest.validate(paymentOrderRequestVO.getUserId(),httpServletRequest.getSession());
			if(requestValidatedFlag){
				paymentOrderResponseVO = new PaymentOrderResponseVO();
				paymentOrderResponseVO = paymentOrderService.getAdvancedFilterCount(paymentOrderRequestVO);
			}
			else{
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (BNPApplicationException exception) {
			paymentOrderResponseVO.setErrorMsg(exception.getMessage());
			log.error(exception.getMessage(),exception);
		}
		return paymentOrderResponseVO;
	}

	@RequestMapping(value = "putDiscRequestdetails.rest", method = RequestMethod.POST)
	public DiscountResponseVO getPaymentOrderDiscReqDetails(@RequestBody PaymentOrderListCollectionVO paymentOrderListVCollection,HttpServletRequest request,HttpServletResponse response) throws BNPApplicationException {
		DiscountResponseVO discountRequVO = new DiscountResponseVO();
		HttpSession session = request.getSession();
		UserInfoVO user = (UserInfoVO) session.getAttribute("userInfo");
		user.setSessionId((String) session.getAttribute("USER_AUTH_TOKEN"));
		List<DiscountRequestVO> disceqVO = new ArrayList<DiscountRequestVO>();
		try {
			boolean requestValidatedFlag = validateRequest.validate(paymentOrderListVCollection.getUserId(),session);
			if(requestValidatedFlag){
				discountRequVO = discountRequestService.getDiscRequestVO(paymentOrderListVCollection.getPaymentOrderListCollection(),user);
				AuditRequestVO auditVo = new AuditRequestVO();
				auditVo.setUserId(user.getUserId());
				auditVo.setSessionId(user.getSessionId());
				auditVo.setFuncId(PaymentOrderConstants.DISCOUNT_REQUEST);
				auditVo.setOrgId(user.getOrgId());
				auditService.insertAuditLog(auditVo);
			}
			else{
				discountRequVO = null;
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (Exception exception) {
			//response.setHeader("isError", "true");			
			log.error(exception.getMessage(),exception);
			throw new BNPApplicationException();
		}
		//return paymentOrderResponseVO;
		return discountRequVO;
	}

	/**
	 * This method is for getting Payment Order Attachment details
	 * 
	 * @param attachmentRequestVO
	 * @return
	 */
	@RequestMapping(value = "getPaymentOrderdAttchdetails.rest", method = RequestMethod.POST)
	public AttachmentResponseVO getPaymentOrderdAttchDetails(@RequestBody AttachmentRequestVO attachmentRequestVO) {
		AttachmentResponseVO attachmentResponseVO = new AttachmentResponseVO();
		try {
			attachmentResponseVO = attachmentService.getSCFAttachmentDetails(attachmentRequestVO);
		} catch (BNPApplicationException exception) {
			attachmentResponseVO.setErrorMsg(exception.getMessage());
			log.error(exception.getMessage(),exception);
		}
		return attachmentResponseVO;
	}

	
		/**
		 * This method is for getting the Payment Order Credit Note Line Item Details
		 * 
		 * @param paymentOrderCreditNoteLineItemRequestVO
		 * @return
		 */
		@RequestMapping(value = "getPaymentOrderCreditNoteLineItemdetails.rest", method = RequestMethod.POST)
		public PaymentOrderCreditNoteLineItemResponseVO getPaymentOrderCreditNoteLineItemdetails(@RequestBody PaymentOrderCreditNoteLineItemRequestVO paymentOrderCreditNoteLineItemRequestVO) {
			PaymentOrderCreditNoteLineItemResponseVO paymentOrderCreditNoteLineItemResponseVO = new PaymentOrderCreditNoteLineItemResponseVO();
			try {
				paymentOrderCreditNoteLineItemResponseVO = paymentOrderService.getPaymentOrderCreditNoteLineItemdetails(paymentOrderCreditNoteLineItemRequestVO);
			} catch (BNPApplicationException exception) {
				log.error(exception.getMessage(),exception);
			}
			return paymentOrderCreditNoteLineItemResponseVO;
		}

		/**
		 * This method is for getting the Payment Order Invoice Details Callout
		 * 
		 * @param paymentOrderInvoiceDetailsRequestVO
		 * @return
		 */
		@RequestMapping(value = "getPaymentOrderInvoiceDetailsCallout.rest", method = RequestMethod.POST)
		public PaymentOrderInvoiceDetailsResponseVO getPaymentOrderInvoiceDetailsCallout(@RequestBody PaymentOrderInvoiceDetailsRequestVO paymentOrderInvoiceDetailsRequestVO) {
			PaymentOrderInvoiceDetailsResponseVO paymentOrderInvoiceDetailsResponseVO = new PaymentOrderInvoiceDetailsResponseVO();
			try {
				paymentOrderInvoiceDetailsResponseVO = paymentOrderService.getPaymentOrderInvoiceDetailsCallout(paymentOrderInvoiceDetailsRequestVO);
			} catch (BNPApplicationException exception) {
				log.error(exception.getMessage(),exception);
			}
			return paymentOrderInvoiceDetailsResponseVO;
		}

		/**
		 * This method is for getting the Payment Order Available Amount Callout Details
		 * 
		 * @param paymentOrderAvailableamtCalloutVO
		 * @return
		 */
		@RequestMapping(value = "getPaymentOrderAvlbleAmtCallOut.rest", method = RequestMethod.POST)
		public PaymentOrderAvailableamtCalloutVO getPaymentOrderAvailableAmtCalloutDetals(@RequestBody PaymentOrderAvailableamtCalloutVO paymentOrderAvailableamtCalloutVO) {
			try {
				paymentOrderAvailableamtCalloutVO = paymentOrderService.getPaymentOrderAvailableAmtCalloutDetals(paymentOrderAvailableamtCalloutVO);
			} catch (BNPApplicationException exception) {
				log.debug("Exception in PaymentOrderController.getPaymentOrderAvailableAmtCalloutDetals");
				log.error(exception.getMessage(),exception);
			}
			return paymentOrderAvailableamtCalloutVO;
		}

		/**
		 * This method is for getting the Recall Invoice
		 * 
		 * @param paymentOrderRecalleDetailsRequestVO
		 * @return
		 * @throws ParseException
		 */
		@RequestMapping(value = "getPaymentOrderRecallInvoice.rest", method = RequestMethod.POST)
		public RecallInvoiceVO getPaymentOrderRecallInvoice(@RequestBody PaymentOrderListVO paymentOrderRecalleDetailsRequestVO) throws ParseException {
		//	PaymentOrderInvoiceDetailsResponseVO paymentOrderInvoiceDetailsResponseVO = new PaymentOrderInvoiceDetailsResponseVO();
			//System.out.println(paymentOrderRecalleDetailsRequestVO.getBuyerRefNoUnique());
			RecallInvoiceVO data =  null;
			data = recallInvoiceBean.viewDetailsFromLink(paymentOrderRecalleDetailsRequestVO);
			return data;
		}

		// Added For User Stories - Recall - Starts

		/**
		 * This method is for getting the Recall Invoice Request Details
		 * 
		 * @param paymentOrderListVO
		 * @param request
		 * @return
		 */
		@RequestMapping(value = "recallInvoiceRequestdetails.rest", method = RequestMethod.POST)
		public RecallResponseVO  recallPaymentOrderReqDetails(@RequestBody PaymentOrderListCollectionVO paymentOrderListCollectionVO,HttpServletRequest request,HttpServletResponse response) throws BNPApplicationException {
			HttpSession session = request.getSession();
			UserInfoVO user = (UserInfoVO) session.getAttribute("userInfo");
			RecallResponseVO recallResponseVO = null;
			try {
				boolean requestValidatedFlag = validateRequest.validate(paymentOrderListCollectionVO.getUserId(),session);
				if(requestValidatedFlag){
					user.setSessionId((String) session.getAttribute("USER_AUTH_TOKEN"));
					recallResponseVO = paymentOrderService.recallPaymentOrderDetails(paymentOrderListCollectionVO.getPaymentOrderListCollection(),user);
					AuditRequestVO auditVo = new AuditRequestVO();
					auditVo.setUserId(user.getUserId());
					auditVo.setSessionId(user.getSessionId());
					auditVo.setFuncId(PaymentOrderConstants.RECALL_REQUEST);
					auditVo.setOrgId(user.getOrgId());
					auditService.insertAuditLog(auditVo);
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException exception) {
				log.error(exception.getMessage(),exception);
				throw new BNPApplicationException();
			}
			return recallResponseVO;
		}

		/**
		 * This method is for Approving Recall Payment Order Request details
		 * 
		 * @param paymentOrderListVO
		 * @param request
		 * @return
		 */
		@RequestMapping(value = "approveRecallInvoiceRequestdetails.rest", method = RequestMethod.POST)
		public RecallResponseVO  approveRecallPaymentOrderReqDetails(@RequestBody PaymentOrderListCollectionVO paymentOrderListCollectionVO,HttpServletRequest request,HttpServletResponse response) throws BNPApplicationException {
			HttpSession session = request.getSession();
			UserInfoVO user = (UserInfoVO) session.getAttribute("userInfo");
			RecallResponseVO recallResponseVO = null;
			try {
				boolean requestValidatedFlag = validateRequest.validate(paymentOrderListCollectionVO.getUserId(),session);
				if(requestValidatedFlag){
					user.setSessionId((String) session.getAttribute("USER_AUTH_TOKEN"));
					recallResponseVO = paymentOrderService.approveRecallPaymentOrderDetails(paymentOrderListCollectionVO.getPaymentOrderListCollection(),user);
					AuditRequestVO auditVo = new AuditRequestVO();
					auditVo.setUserId(user.getUserId());
					auditVo.setSessionId(user.getSessionId());
					auditVo.setFuncId(PaymentOrderConstants.RECALL_APPROVE);
					auditVo.setOrgId(user.getOrgId());
					auditService.insertAuditLog(auditVo);
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException exception) {
				log.error(exception.getMessage(),exception);
				throw new BNPApplicationException();
			}
			return recallResponseVO;
		}

		/**
		 * This method is for Undo Recall Payment Order Request details
		 * 
		 * @param paymentOrderListVO
		 * @param request
		 * @return
		 */
		@RequestMapping(value = "undoRecallInvoiceRequestdetails.rest", method = RequestMethod.POST)
		public RecallResponseVO  undoRecallPaymentOrderReqDetails(@RequestBody PaymentOrderListCollectionVO paymentOrderListCollectionVO,HttpServletRequest request,HttpServletResponse response) throws BNPApplicationException {
			HttpSession session = request.getSession();
			UserInfoVO user = (UserInfoVO) session.getAttribute("userInfo");
			RecallResponseVO recallResponseVO = null;
			try {
				boolean requestValidatedFlag = validateRequest.validate(paymentOrderListCollectionVO.getUserId(),session);
				if(requestValidatedFlag){
					user.setSessionId((String) session.getAttribute("USER_AUTH_TOKEN"));
					recallResponseVO = paymentOrderService.undoRecallPaymentOrderDetails(paymentOrderListCollectionVO.getPaymentOrderListCollection(),user);
					AuditRequestVO auditVo = new AuditRequestVO();
					auditVo.setUserId(user.getUserId());
					auditVo.setSessionId(user.getSessionId());
					auditVo.setFuncId(PaymentOrderConstants.RECALL_UNDO);
					auditVo.setOrgId(user.getOrgId());
					auditService.insertAuditLog(auditVo);
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException exception) {
				log.error(exception.getMessage(),exception);
				throw new BNPApplicationException();
			}
			return recallResponseVO;
		}
		// Added For User Stories - Recall - Ends
		
		/**
		 * This method is for getting request for PO Ref Popup - S001
		 * 
		 * @param PaymentOrderPopupRequestVO
		 * @param request
		 * @return PaymentOrderPopupRequestVO
		 */
		@RequestMapping(value = "getPDFpopupDetails.rest", method = RequestMethod.POST)
		public PaymentOrderPopupRequestVO  getPDFpopupDetails(@RequestBody PaymentOrderPopupRequestVO paymentOrderPopupRequestVO,HttpServletRequest request,HttpServletResponse response) throws BNPApplicationException {
			HttpSession session = request.getSession();
			UserInfoVO user = (UserInfoVO) session.getAttribute("userInfo");
			try {
				boolean requestValidatedFlag = validateRequest.validate(paymentOrderPopupRequestVO.getUserId(),session);
				if(requestValidatedFlag){
					user.setSessionId((String) session.getAttribute("USER_AUTH_TOKEN"));
					paymentOrderService.getPDFpopupDetails(paymentOrderPopupRequestVO);
					AuditRequestVO auditVo = new AuditRequestVO();
					auditVo.setUserId(user.getUserId());
					auditVo.setSessionId(user.getSessionId());
					auditVo.setFuncId(PaymentOrderConstants.PO_REF_POPUP);
					auditVo.setOrgId(user.getOrgId());
					auditService.insertAuditLog(auditVo);
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (Exception exception) {
				log.error(exception.getMessage(),exception);
				throw new BNPApplicationException();
			}
			return paymentOrderPopupRequestVO;
		}
		
		/**
		 * Method is used to validate discount date with corresponding holidays
		 * @param paymentOrderRequestVO
		 * @param httpServletRequest
		 * @param httpServletResponse
		 * @return
		 */
		@RequestMapping(value ="validateDiscDateWithHoliday.rest", method=RequestMethod.POST)
		public boolean validateDiscDateWithHoliday(@RequestBody PaymentOrderRequestVO paymentOrderRequestVO,HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws BNPApplicationException{
			HttpSession httpSession = httpServletRequest.getSession();
			boolean isHoliday = false;
			try{				
				if(validateRequest.validate(paymentOrderRequestVO.getUserId(),httpSession)){
					isHoliday = paymentOrderService.validateDiscDateWithHoliday(paymentOrderRequestVO);
				}else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			}catch(Exception exception){
				log.error(exception.getMessage(),exception);
				throw new BNPApplicationException();
			}
			return isHoliday;
		};
	}