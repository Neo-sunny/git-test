package com.bnp.bnpux.service;

import java.util.List;

import com.bnp.bnpux.vo.requestVO.PaymentReportRequestVO;
import com.bnp.bnpux.vo.responseVO.PaymentReportResponseVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface IPaymentReportService {
	
	/**
	 * This method is for getting Settlement Due Reminder Report list
	 * 
	 * @param SettlmntDueReminderRptRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	PaymentReportResponseVO getPaymentReportList(PaymentReportRequestVO paymentReportRequestVO)	throws BNPApplicationException;
	
	/**
	 * This method is for getting report chart axis 
	 * 
	 * @param requestVo
	 * @return
	 * @throws BNPApplicationException
	 */
	List<ReportChartResponseVO> getReportChartAxis (PaymentReportRequestVO requestVo)throws BNPApplicationException;
	
}
