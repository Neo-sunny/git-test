package com.bnp.bnpux.vo.responseVO;

import java.util.List;

import com.bnp.bnpux.common.vo.ViewScheduledReportListVO;

public class ViewScheduledReportResponseVO {
	
	private String errorMessage;
	private String fileName;
	private byte[] data;
	private List<ViewScheduledReportListVO> viewScheduledResponseList;
	
	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}
	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}
	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	/**
	 * @return the data
	 */
	public byte[] getData() {
		return data;
	}
	/**
	 * @param data the data to set
	 */
	public void setData(byte[] data) {
		this.data = data;
	}
	
	/**
	 * @return the viewScheduledResponseList
	 */
	public List<ViewScheduledReportListVO> getViewScheduledResponseList() {
		return viewScheduledResponseList;
	}
	/**
	 * @param viewScheduledResponseList the viewScheduledResponseList to set
	 */
	public void setViewScheduledResponseList(List<ViewScheduledReportListVO> viewScheduledResponseList) {
		this.viewScheduledResponseList = viewScheduledResponseList;
	}
	
}
