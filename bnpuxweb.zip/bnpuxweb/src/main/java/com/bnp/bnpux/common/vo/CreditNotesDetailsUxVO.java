/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   13-FEB-2017
 * 
 * Purpose:      Credit Notes Details Ux VO
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 13-FEB-2017				  Sathishkumar B									New VO - S271, S273, S274, S275, S276, S277
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

public class CreditNotesDetailsUxVO extends AbstractVO{ 


	/**
	 * 
	 */
	private static final long serialVersionUID = 8346690132169175213L;


	private String cnRefNo;
	
	private String issueDate;
	
	private String effectiveDate;
	
	private String cnType;
	
	private String cnCCY;
	
	private String cnAmount;
	
	private String status;
	
	private String utilRefNo;

	public String getCnRefNo() {
		return cnRefNo;
	}

	public void setCnRefNo(String cnRefNo) {
		this.cnRefNo = cnRefNo;
	}

	public String getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getCnType() {
		return cnType;
	}

	public void setCnType(String cnType) {
		this.cnType = cnType;
	}

	public String getCnCCY() {
		return cnCCY;
	}

	public void setCnCCY(String cnCCY) {
		this.cnCCY = cnCCY;
	}

	public String getCnAmount() {
		return cnAmount;
	}

	public void setCnAmount(String cnAmount) {
		this.cnAmount = cnAmount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUtilRefNo() {
		return utilRefNo;
	}

	public void setUtilRefNo(String utilRefNo) {
		this.utilRefNo = utilRefNo;
	}
	
	
	
}
