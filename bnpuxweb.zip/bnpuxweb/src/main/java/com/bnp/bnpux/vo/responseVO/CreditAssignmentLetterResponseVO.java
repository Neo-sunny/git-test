/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:      CreditAssignmentLetter Response Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.responseVO;

import java.util.List;

import com.bnp.scm.services.discounting.vo.CreditAssignmentVO;

public class CreditAssignmentLetterResponseVO {

	private List<CreditAssignmentVO> creditAssignLettersList;
	
	private long count;
	
	private String errorMsg;

	public List<CreditAssignmentVO> getCreditAssignLettersList() {
		return creditAssignLettersList;
	}

	public void setCreditAssignLettersList(List<CreditAssignmentVO> creditAssignLettersList) {
		this.creditAssignLettersList = creditAssignLettersList;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}
	
	
	
}
