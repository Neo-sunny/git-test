/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  21 June 2017
 * 
 * Purpose:      Discount Transaction Report Request VO
 * 
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 21 June 2017       Ratna Gokhale, Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.requestVO;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.bnp.bnpux.common.vo.DiscTransDetailsVO;
import com.bnp.bnpux.common.vo.DiscTransVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;

public class DiscTransRequestVO{
	
	private String userId;
	
	private String userType;
	
	private String buyerOrgId;
	
	private String suppOrgId;
	
	private String currencyCode;
	
	private Date discountFromDate;
	
	private Date discountToDate;
	
	private Date maturityFromDate;
	
	private Date maturityToDate;
	
	private BigDecimal orgFromAmt;
	
	private BigDecimal orgToAmt;
	
	private String status;
	
	private String period;
	
	private String branch;
	
	private String getWhat;
	
	private String exportType;
	
	private List<DiscTransVO> discTransList;

	private String errorMsg;
	
	private String viewType;
	
	private String recordFrom;
	
	private String recordTo;
	
	private String creditNoteRefNum;
	
	private String utilizationRefNum;
	
	private List<DiscTransDetailsVO> discTransDetails;
	
	private List<ReportChartResponseVO> reportChartList;
	
	private String errorResult;
	
	private String cntId;
	
	
	public List<ReportChartResponseVO> getReportChartList() {
		return reportChartList;
	}

	public void setReportChartList(List<ReportChartResponseVO> reportChartList) {
		this.reportChartList = reportChartList;
	}

	public String getErrorResult() {
		return errorResult;
	}

	public void setErrorResult(String errorResult) {
		this.errorResult = errorResult;
	}

	public String getCntId() {
		return cntId;
	}

	public void setCntId(String cntId) {
		this.cntId = cntId;
	}


	public List<DiscTransDetailsVO> getDiscTransDetails() {
		return discTransDetails;
	}

	public void setDiscTransDetails(List<DiscTransDetailsVO> discTransDetails) {
		this.discTransDetails = discTransDetails;
	}


	public String getViewType() {
		return viewType;
	}

	public void setViewType(String viewType) {
		this.viewType = viewType;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getBuyerOrgId() {
		return buyerOrgId;
	}

	public void setBuyerOrgId(String buyerOrgId) {
		this.buyerOrgId = buyerOrgId;
	}

	public String getSuppOrgId() {
		return suppOrgId;
	}

	public void setSuppOrgId(String suppOrgId) {
		this.suppOrgId = suppOrgId;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	

	public Date getDiscountFromDate() {
		return discountFromDate;
	}

	public void setDiscountFromDate(Date discountFromDate) {
		this.discountFromDate = discountFromDate;
	}

	public Date getDiscountToDate() {
		return discountToDate;
	}

	public void setDiscountToDate(Date discountToDate) {
		this.discountToDate = discountToDate;
	}

	public Date getMaturityFromDate() {
		return maturityFromDate;
	}

	public void setMaturityFromDate(Date maturityFromDate) {
		this.maturityFromDate = maturityFromDate;
	}

	public Date getMaturityToDate() {
		return maturityToDate;
	}

	public void setMaturityToDate(Date maturityToDate) {
		this.maturityToDate = maturityToDate;
	}

	public BigDecimal getOrgFromAmt() {
		return orgFromAmt;
	}

	public void setOrgFromAmt(BigDecimal orgFromAmt) {
		this.orgFromAmt = orgFromAmt;
	}

	public BigDecimal getOrgToAmt() {
		return orgToAmt;
	}

	public void setOrgToAmt(BigDecimal orgToAmt) {
		this.orgToAmt = orgToAmt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getGetWhat() {
		return getWhat;
	}

	public void setGetWhat(String getWhat) {
		this.getWhat = getWhat;
	}

	public String getExportType() {
		return exportType;
	}

	public void setExportType(String exportType) {
		this.exportType = exportType;
	}

	public List<DiscTransVO> getDiscTransList() {
		return discTransList;
	}

	public void setDiscTransList(List<DiscTransVO> discTransList) {
		this.discTransList = discTransList;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public String getRecordFrom() {
		return recordFrom;
	}

	public void setRecordFrom(String recordFrom) {
		this.recordFrom = recordFrom;
	}

	public String getRecordTo() {
		return recordTo;
	}

	public void setRecordTo(String recordTo) {
		this.recordTo = recordTo;
	}

	public String getCreditNoteRefNum() {
		return creditNoteRefNum;
	}

	public void setCreditNoteRefNum(String creditNoteRefNum) {
		this.creditNoteRefNum = creditNoteRefNum;
	}

	public String getUtilizationRefNum() {
		return utilizationRefNum;
	}

	public void setUtilizationRefNum(String utilizationRefNum) {
		this.utilizationRefNum = utilizationRefNum;
	}


	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	
	
}
