/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     PaymentOrder CreditNote LineItem Request Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version  
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.requestVO;

public class PaymentOrderCreditNoteLineItemRequestVO {

	private int cnt_id;

	public int getCnt_id() {
		return cnt_id;
	}

	public void setCnt_id(int cnt_id) {
		this.cnt_id = cnt_id;
	}
}
