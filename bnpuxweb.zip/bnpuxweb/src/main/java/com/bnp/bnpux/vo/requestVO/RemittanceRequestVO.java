package com.bnp.bnpux.vo.requestVO;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.bnp.bnpux.vo.responseVO.RemittanceResponseVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;

public class RemittanceRequestVO {
private String userId;
	
	private String userType;
	
	private String branch;
	
	private String clientOrgId;
	
	private String cptyOrgId;
	
	private String matDisStatus;
	
	private String currencyCode;

	private String getWhat;
	
	private String exportType;

	private String plottingParam;
	
	private String errorMessage;
	
	private String viewType;
	
	private String recordFrom;
	
	private String recordTo;
	
	private String filePeriod;
	
	private Date uploadFromDate;
	
	private Date uploadToDate;
	
	private int decimalPoint;
	
	private String buyerErpId;
	
	private String suppErpId;
	
	private String reportType;
	
	private int bandRecordCnt;
	
	private int recCount;
	
	private String buyerShtNm;
	
	private String suppShrtName;
	
	
	private int rNo;
	
	public int getrNo() {
		return rNo;
	}

	public void setrNo(int rNo) {
		this.rNo = rNo;
	}

	public String getBuyerErpId() {
		return buyerErpId;
	}

	public void setBuyerErpId(String buyerErpId) {
		this.buyerErpId = buyerErpId;
	}

	public String getSuppErpId() {
		return suppErpId;
	}

	public void setSuppErpId(String suppErpId) {
		this.suppErpId = suppErpId;
	}

	public int getBandRecordCnt() {
		return bandRecordCnt;
	}

	public void setBandRecordCnt(int bandRecordCnt) {
		this.bandRecordCnt = bandRecordCnt;
	}

	public int getRecCount() {
		return recCount;
	}

	public void setRecCount(int recCount) {
		this.recCount = recCount;
	}

	public String getBuyerShtNm() {
		return buyerShtNm;
	}

	public void setBuyerShtNm(String buyerShtNm) {
		this.buyerShtNm = buyerShtNm;
	}

	public String getSuppShrtName() {
		return suppShrtName;
	}

	public void setSuppShrtName(String suppShrtName) {
		this.suppShrtName = suppShrtName;
	}

	private String chartName;
	private int recFrom;
	private int recTo;
	private String pmtId;
	private String invId;
	private String errorFlag;
	
	
	public String getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}
	
	public String getInvId() {
		return invId;
	}

	public void setInvId(String invId) {
		this.invId = invId;
	}

	private List<RemittanceRequestVO> remitMainList = new ArrayList<RemittanceRequestVO>();
		
	private List<RemittanceResponseVO> remittDetailList = new ArrayList<RemittanceResponseVO>(); 
		
	private List<ReportChartResponseVO> remittChartData = new ArrayList<ReportChartResponseVO>();
	
	private List<RemittanceResponseVO> remittDiscList = new ArrayList<RemittanceResponseVO>(); 
	private List<RemittanceResponseVO> remittCnList = new ArrayList<RemittanceResponseVO>(); 
	private List<RemittanceResponseVO> remitMatList = new ArrayList<RemittanceResponseVO>(); 
	private List<RemittanceResponseVO> remitInvList = new ArrayList<RemittanceResponseVO>(); 

		
	public List<RemittanceResponseVO> getRemittDiscList() {
		return remittDiscList;
	}

	public List<RemittanceResponseVO> getRemitMatList() {
		return remitMatList;
	}

	public void setRemitMatList(List<RemittanceResponseVO> remitMatList) {
		this.remitMatList = remitMatList;
	}

	public List<RemittanceResponseVO> getRemitInvList() {
		return remitInvList;
	}

	public void setRemitInvList(List<RemittanceResponseVO> remitInvList) {
		this.remitInvList = remitInvList;
	}

	public void setRemittDiscList(List<RemittanceResponseVO> remittDiscList) {
		this.remittDiscList = remittDiscList;
	}

	public List<RemittanceResponseVO> getRemittCnList() {
		return remittCnList;
	}

	public void setRemittCnList(List<RemittanceResponseVO> remittCnList) {
		this.remittCnList = remittCnList;
	}

	

	
	public String getPmtId() {
		return pmtId;
	}

	public void setPmtId(String pmtId) {
		this.pmtId = pmtId;
	}

	public List<ReportChartResponseVO> getRemittChartData() {
		return remittChartData;
	}

	public void setRemittChartData(List<ReportChartResponseVO> remittChartData) {
		this.remittChartData = remittChartData;
	}

	public int getRecFrom() {
		return recFrom;
	}

	public void setRecFrom(int recFrom) {
		this.recFrom = recFrom;
	}

	public int getRecTo() {
		return recTo;
	}

	public void setRecTo(int recTo) {
		this.recTo = recTo;
	}

	public String getChartName() {
		return chartName;
	}

	public void setChartName(String chartName) {
		this.chartName = chartName;
	}

	public String getReportType() {
		return reportType;
	}

	public void setReportType(String reportType) {
		this.reportType = reportType;
	}
	
	public List<RemittanceRequestVO> getRemitMainList() {
		return remitMainList;
	}

	public void setRemitMainList(List<RemittanceRequestVO> remitMainList) {
		this.remitMainList = remitMainList;
	}

	public List<RemittanceResponseVO> getRemittDetailList() {
		return remittDetailList;
	}

	public void setRemittDetailList(List<RemittanceResponseVO> remittDetailList) {
		this.remittDetailList = remittDetailList;
	}

	public int getDecimalPoint() {
		return decimalPoint;
	}

	public void setDecimalPoint(int decimalPoint) {
		this.decimalPoint = decimalPoint;
	}

	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getClientOrgId() {
		return clientOrgId;
	}

	public void setClientOrgId(String clientOrgId) {
		this.clientOrgId = clientOrgId;
	}

	public String getCptyOrgId() {
		return cptyOrgId;
	}

	public void setCptyOrgId(String cptyOrgId) {
		this.cptyOrgId = cptyOrgId;
	}

	public String getMatDisStatus() {
		return matDisStatus;
	}

	public void setMatDisStatus(String matDisStatus) {
		this.matDisStatus = matDisStatus;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getGetWhat() {
		return getWhat;
	}

	public void setGetWhat(String getWhat) {
		this.getWhat = getWhat;
	}

	public String getExportType() {
		return exportType;
	}

	public void setExportType(String exportType) {
		this.exportType = exportType;
	}

	public String getPlottingParam() {
		return plottingParam;
	}

	public void setPlottingParam(String plottingParam) {
		this.plottingParam = plottingParam;
	}

	

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getViewType() {
		return viewType;
	}

	public void setViewType(String viewType) {
		this.viewType = viewType;
	}

	public String getRecordFrom() {
		return recordFrom;
	}

	public void setRecordFrom(String recordFrom) {
		this.recordFrom = recordFrom;
	}

	public String getRecordTo() {
		return recordTo;
	}

	public void setRecordTo(String recordTo) {
		this.recordTo = recordTo;
	}

	public String getFilePeriod() {
		return filePeriod;
	}

	public void setFilePeriod(String filePeriod) {
		this.filePeriod = filePeriod;
	}

	public Date getUploadFromDate() {
		return uploadFromDate;
	}

	public void setUploadFromDate(Date uploadFromDate) {
		this.uploadFromDate = uploadFromDate;
	}

	public Date getUploadToDate() {
		return uploadToDate;
	}

	public void setUploadToDate(Date uploadToDate) {
		this.uploadToDate = uploadToDate;
	}

	
}
