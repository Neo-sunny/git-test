/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     UserService Implementation
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 
 *****************************************************************************************************************************************************************/
package com.bnp.bnpux.serviceimpl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.bnp.bnpux.common.vo.CountryFlagVO;
import com.bnp.bnpux.common.vo.UserBranchVO;
import com.bnp.bnpux.dao.ICommonDAO;
import com.bnp.bnpux.service.IUserService;
import com.bnp.csc.services.common.cache.IUserCacheService;
import com.bnp.csc.services.common.vo.BranchVO;
import com.bnp.scm.services.common.util.BNPCommonUtil;
import com.googlecode.ehcache.annotations.Cacheable;

@Service("userService")
public class UserServiceImpl implements IUserService {

	@Autowired
	private IUserCacheService userCacheService;
	
	@Autowired
	private ICommonDAO commonDao;
	
	private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);
	
	/**
	 * @param userId
	 * @param orgId
	 * @return List<UserBranchVO>
	 * @see com.bnp.bnpux.service.IUserService#getUserInfo(java.lang.String, java.lang.String)
	 * @Description Fetches User Information for Passed User Id and Org Id
	 */
	@Override
	public List<UserBranchVO> getUserInfo(String userId,String orgId) {
		List<BranchVO> branches =  userCacheService.getBranchListForOrgUser(userId);
		List<UserBranchVO> userBranches = getUserBranchFromCommon(branches);
		Map<String,List<Map<String,String>>> cufOffTimes =  new HashMap<String, List<Map<String,String>>>();
		for (UserBranchVO userBranchVO : userBranches) 
		{
			List<Map<String,String>> cufOffTimesLst = commonDao.getBranchesCutOffTime(userBranchVO);
			cufOffTimes.put(userBranchVO.getBranchId(), cufOffTimesLst);
		}
		setBranchCutOffTime(userBranches,cufOffTimes,orgId);
		
		return userBranches;
	}
	
	/**
	 * @param branches
	 * @param orgId
	 * @return List<Map<String,String>>
	 * @see com.bnp.bnpux.service.IUserService#getCoTRemaniningTime(java.util.List, java.lang.String)
	 * @Description get Cut-Off Remaining Time for passed branch List and Org Id
	 */
	@Override
	public List<Map<String,String>> getCoTRemaniningTime(List<UserBranchVO> branches,String orgId)
	{
		List<Map<String,String>> remainingTimeLst = new ArrayList<Map<String,String>>();
		log.debug("entering cut off remainig time");
		for (UserBranchVO userBranchVO : branches) {
			if(userBranchVO.getCutOffTime() != null)
			{
				String branchTimeZone = BNPCommonUtil.getTimeZoneID(userBranchVO.getTimeZone());
				TimeZone timeZone =  branchTimeZone != null ? TimeZone.getTimeZone(branchTimeZone) : TimeZone.getDefault();
				Date cutOffDt = userBranchVO.getCutOffDate();
				String [] cutOffTimes = userBranchVO.getCutOffTime().split(":");
				String hour =cutOffTimes[0];
				String minutes =cutOffTimes[1];
				Date currentDt = BNPCommonUtil.getCurrentDateWithTZ(timeZone);
				log.debug("Branch Details : "+userBranchVO.getBranchId()+" "+userBranchVO.getCountry()+" "+userBranchVO.getCurrency()+" "+userBranchVO.getCutOffDate()+" "+userBranchVO.getCutOffTime()+" "+userBranchVO.getTimeZone());
				log.debug("Current Date : "+currentDt);
				log.debug("Cut Off Date : "+cutOffDt+ " "+userBranchVO.getSrvrCutOffTime());
				int currDt = BNPCommonUtil.getDtValueFromDateTZ(currentDt, timeZone);				
				Calendar cutOffCal = getCutOffTimeCal(cutOffDt, hour, minutes,timeZone);
				log.debug("Cut Off Timestamp : "+cutOffCal.get(Calendar.DATE)+"/"+cutOffCal.get(Calendar.MONTH)+"/"+cutOffCal.get(Calendar.YEAR)+" "+cutOffCal.get(Calendar.HOUR_OF_DAY)+" : "+cutOffCal.get(Calendar.MINUTE));
				log.debug("CT DT : "+cutOffCal.getTime());
				if(currentDt.after(cutOffCal.getTime()))
				{
					Date nxtDt = getNextBusinessDay(userBranchVO, currentDt, orgId);
					log.debug("Next Date : "+nxtDt);
					int nxtCutOffDt = BNPCommonUtil.getDtValueFromDate(nxtDt);					
					cutOffCal = getCutOffTimeCal(nxtCutOffDt,currDt,hour, minutes);					
					log.debug("Next Cut Off Date : "+nxtCutOffDt);
					log.debug("Next Cut Off Timestamp : "+cutOffCal.getTime());
					userBranchVO.setCutOffDate(nxtDt);
				}
				long diffTime = cutOffCal.getTimeInMillis() - currentDt.getTime();
				long diffMinutes = diffTime / (60 * 1000) % 60;
		        long diffHours = diffTime / (60 * 60 * 1000);
		        String rHrs = Long.toString(diffHours)+":"+Long.toString(diffMinutes);
		        log.debug("rHrs : "+rHrs);
				Map<String,String> remainingTime = new HashMap<String, String>();
				remainingTime.put("branchId", userBranchVO.getBranchId());
				remainingTime.put("branchCode", userBranchVO.getBranchCode());
				remainingTime.put("remainingTime", rHrs);
				remainingTime.put("remainingHour", Long.toString(diffHours));
				remainingTime.put("remainingMins", Long.toString(diffMinutes));
				remainingTime.put("branchName", userBranchVO.getBranchName());
				remainingTime.put("flagPath", "");
				remainingTime.put("country", userBranchVO.getCountry());
				remainingTime.put("countryName", getCountryFlag(userBranchVO.getCountry()).getCountryName().toLowerCase());
				log.debug("CountryName"+getCountryFlag(userBranchVO.getCountry()).getCountryName().toLowerCase());
				remainingTimeLst.add(remainingTime);
			}
			
			
		}
		log.debug("entering cut off remainig time");
		return remainingTimeLst;
	}
	
	/**
	 * @param branches
	 * @return List<UserBranchVO>
	 * @Description Maps List of BranchVO to List of UserBranchVO
	 */
	private List<UserBranchVO> getUserBranchFromCommon(List<BranchVO> branches)
	{
		List<UserBranchVO> userBranches = new ArrayList<UserBranchVO>();
		for (BranchVO branchVO : branches) {
			UserBranchVO userBranch = new UserBranchVO();
			  userBranch.setBranchCode(branchVO.getBranchCode());
			  userBranch.setBranchId(branchVO.getBranchId());
			  userBranch.setBranchName(branchVO.getBranchName());
			  userBranch.setCountry(branchVO.getCountry());
			  userBranch.setCurrency(branchVO.getCurrency());
			  userBranch.setTimeZone(branchVO.getTimeZone());
			  userBranches.add(userBranch);
		}
		return userBranches;
	}
	
	/**
	 * @param branches
	 * @param cutOffTimeMap
	 * @param orgId 
	 * @Description set Cut-Off Time for Passed List of Branches and Org Id  
	 */
	private void setBranchCutOffTime(List<UserBranchVO> branches,Map<String,List<Map<String,String>>> cutOffTimeMap,String orgId)
	{
		
		for (UserBranchVO userBranch : branches) {
			
			List<Map<String,String>> cutOffTime = cutOffTimeMap.get(userBranch.getBranchId());
			if((cutOffTime != null) && (!cutOffTime.isEmpty()))
			{
				
				if(cutOffTime.size() == 1)
				{
					userBranch.setCutOffTime(cutOffTime.get(0).get(userBranch.getBranchId()));
					String [] hrmin = cutOffTime.get(0).get("DISC_REQ_EXT_CUTTOFF").split(":");
					if(!("00").equals(hrmin[0]) || !("00").equals(hrmin[1]))
					{
						int hour = Integer.parseInt(hrmin[0]);
						int min = Integer.parseInt(hrmin[1]);
						StringBuilder cutOffTimesb = new StringBuilder();
						cutOffTimesb.append(Integer.toString(hour)).append(":").append(Integer.toString(min));
						userBranch.setCutOffTime(cutOffTimesb.toString());
						getBranchCutOffTime(userBranch,hour,min,orgId);
					}
					
					
				}
				else
				{
					List<Date> timeList = new ArrayList<Date>();
					for(Map<String,String> cts : cutOffTime) {
						String [] hrmin = cts.get("DISC_REQ_EXT_CUTTOFF").split(":");
						if(!("00").equals(hrmin[0]) || !("00").equals(hrmin[1]))
						{
							Calendar cal = Calendar.getInstance();
							cal.set(Calendar.HOUR_OF_DAY,Integer.parseInt(hrmin[0]) );
							cal.set(Calendar.MINUTE,Integer.parseInt(hrmin[1]) );							
							Date d = cal.getTime();
							timeList.add(d);
						}
						
					}
					Collections.sort(timeList);
					Date cutTime = timeList.get(0);
					Calendar cal = Calendar.getInstance();
					cal.setTime(cutTime);
					StringBuilder cutOffTimesb = new StringBuilder();
					cutOffTimesb.append(Integer.toString(cal.get(Calendar.HOUR_OF_DAY))).append(":").append(Integer.toString(cal.get(Calendar.MINUTE)));
					getBranchCutOffTime(userBranch, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), orgId);
					userBranch.setCutOffTime(cutOffTimesb.toString());
				}
			}
			
		}		
		
	}
	
	
	/**
	 * @param userBranch
	 * @param hr
	 * @param min
	 * @param orgId 
	 * @Description get Cut-Off Time for passed userBranch
	 */
	private void getBranchCutOffTime(UserBranchVO userBranch,int hr,int min,String orgId)
	{
		String branchTimeZone = BNPCommonUtil.getTimeZoneID(userBranch.getTimeZone());
		TimeZone timeZone =  branchTimeZone != null ? TimeZone.getTimeZone(branchTimeZone) : TimeZone.getDefault();
		Date cutOffDt = null;
		Date curDt = BNPCommonUtil.getCurrentDateWithTZ(timeZone);
		if(userBranch.getCutOffDate() == null)
		{
			cutOffDt = getHolidayAdjustedDate(userBranch,curDt, orgId);
			userBranch.setCutOffDate(cutOffDt);			
		}
		
		String hour = Integer.toString(hr);
		String minutes = Integer.toString(min);
		
		
		
		Calendar cutOffCal = getCutOffTimeCal(cutOffDt, hour, minutes,timeZone);
		if(curDt.after(cutOffCal.getTime()))
		{
			Date nxtDt = getNextBusinessDay(userBranch, curDt, orgId);
			userBranch.setCutOffDate(nxtDt);
			userBranch.setSrvrCutOffTime(nxtDt);
		}
		
	}
	
	/**
	 * @param cutOffDt
	 * @param currDt
	 * @param hour
	 * @param minutes
	 * @return Calendar
	 * @Description get Cut-Off Time in Calendar
	 */
	private Calendar getCutOffTimeCal(int cutOffDt,int currDt, String hour, String minutes)
	{
		Calendar cutOffCal = Calendar.getInstance();
		cutOffCal.set(Calendar.DATE, cutOffDt);
		if(currDt > cutOffDt)
		{
			cutOffCal.add(Calendar.MONTH, 1);
		}
		cutOffCal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hour));
		cutOffCal.set(Calendar.MINUTE, Integer.parseInt(minutes));
		cutOffCal.set(Calendar.SECOND, 0);
		return cutOffCal;
	}
	
	/*private Calendar getCutOffTimeCal(int cutOffDt, String hour, String minutes)
	{
		Calendar cutOffCal = Calendar.getInstance();
		cutOffCal.add(Calendar.DATE, cutOffDt);
		cutOffCal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hour));
		cutOffCal.set(Calendar.MINUTE, Integer.parseInt(minutes));
		cutOffCal.set(Calendar.SECOND, 0);
		return cutOffCal;
	}*/
	
	/**
	 * @param dt
	 * @param hour
	 * @param minutes
	 * @param tz
	 * @return Calendar
	 * @Description get Cut-Off Time in Calendar
	 */
	private Calendar getCutOffTimeCal(Date dt, String hour, String minutes,TimeZone tz)
	{
		Calendar dtCal = Calendar.getInstance();
		dtCal.setTimeInMillis(dt.getTime());
		int cutOffDt = dtCal.get(Calendar.DATE);
		int cutOffMonth = dtCal.get(Calendar.MONTH);
		int cutOffYr  = dtCal.get(Calendar.YEAR);
		Calendar cutOffCal = Calendar.getInstance();
		log.info("Get Cut Off Calender 2");
		log.info("Cut Off Date : "+cutOffDt);
		log.info("Cut Off Month : "+cutOffMonth);
		log.info("Cut Off Year : "+cutOffYr);
		//cutOffCal.setTimeZone(tz);
	/*	cutOffCal.set(Calendar.MONTH, cutOffMonth);
		cutOffCal.set(Calendar.YEAR, cutOffYr);
		cutOffCal.set(Calendar.DATE, cutOffDt);*/
		cutOffCal.setTime(dt);
		cutOffCal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hour));
		cutOffCal.set(Calendar.MINUTE, Integer.parseInt(minutes));
		cutOffCal.set(Calendar.SECOND, 0);
		return cutOffCal;
	}
	
	/**
	 * @param branch
	 * @param dt
	 * @param orgId
	 * @return Date
	 * @Description get Holiday Adjusted Date for Passed UserBranchVO and orgId 
	 */
	public Date getHolidayAdjustedDate(UserBranchVO branch,Date dt,String orgId)
	{
		Date businessDay = new Date();
		String errorFlag = "";
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("ccyCode", branch.getCurrency());
		params.put("branchId", branch.getBranchId());
		params.put("inputDate", dt);
		params.put("orgId", orgId);
		params.put("businessDay",  businessDay);
		params.put("errorFlag", errorFlag);
		userCacheService.getHolidayAdjustedDate(params);
		return (Date) params.get("businessDay");
	}
	
	
	/**
	 * @param branch
	 * @param dt
	 * @param orgId
	 * @return Date
	 * @Description get Next Business Day for Passed UserBranchVO and orgId
	 */
	public Date getNextBusinessDay(UserBranchVO branch,Date dt,String orgId)
	{
		Date businessDay = new Date();
		String errorFlag = "";
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("ccyCode", branch.getCurrency());
		params.put("branchId", branch.getBranchId());
		params.put("inputDate", dt);
		params.put("leadDays", 1);
		params.put("ignCcyHoliday", "N");
		params.put("orgId", orgId);
		params.put("businessDay",  businessDay);
		params.put("errorFlag", errorFlag);
		userCacheService.getNextBusinessDay(params);
		return (Date) params.get("businessDay");
	}
	
	/**
	 * @param countryCode
	 * @return CountryFlagVO
	 * @see com.bnp.bnpux.service.IUserService#getCountryFlag(java.lang.String)
	 * @Description get Country Flag
	 */
	@Override
	@Cacheable(cacheName="countryCache")
	public CountryFlagVO getCountryFlag(String countryCode) {
		return commonDao.getCountryFlag(countryCode);
	}


}
