/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Settlement List Details Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;
import java.util.Date;

public class SettlementListDetailsVO {

	private String userId;
	
	private String paymntRefNumberUnique;
	
	private String invoiceRefNo;
	
	private Date invoiceIssueDate;
	
	private BigDecimal invoiceAmount;
	
	private BigDecimal alreadySettledAmount;
	
	private BigDecimal discInvoiceAmount;
	
	private BigDecimal dueAmount;
	
	private boolean attachementIconInd;
	
	private String indicatorFlag;
	
	private boolean callOutIndicator;
	
	private boolean lineItemInd;
	
	private String errorMsg;

	private String countUtilId;
	
	private String invoiceRefOrder;
	
	private String pymtId;
	
	/** Invoice and Credit Note Call Out Starts**/
	private String buyerRefNo;
	
	private String sellerRefNo;

	private String cntInvoiceRefNo;
	
	private String cntEffectDate;
	
	private String cntUtilizedAmt;
	
	private String invoiceCreditNoteID;
	/** Invoice and Credit Note Call Out Ends**/
	
	private long invId;
	
	private String currencyCode;
	
	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getPymtId() {
		return pymtId;
	}

	public void setPymtId(String pymtId) {
		this.pymtId = pymtId;
	}

	public String getCountUtilId() {
		return countUtilId;
	}

	public void setCountUtilId(String countUtilId) {
		this.countUtilId = countUtilId;
	}

	public String getInvoiceRefOrder() {
		return invoiceRefOrder;
	}

	public void setInvoiceRefOrder(String invoiceRefOrder) {
		this.invoiceRefOrder = invoiceRefOrder;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}


	public String getInvoiceRefNo() {
		return invoiceRefNo;
	}

	public void setInvoiceRefNo(String invoiceRefNo) {
		this.invoiceRefNo = invoiceRefNo;
	}

	public Date getInvoiceIssueDate() {
		return invoiceIssueDate;
	}

	public void setInvoiceIssueDate(Date invoiceIssueDate) {
		this.invoiceIssueDate = invoiceIssueDate;
	}

	public BigDecimal getInvoiceAmount() {
		return invoiceAmount;
	}

	public void setInvoiceAmount(BigDecimal invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}

	public BigDecimal getDiscInvoiceAmount() {
		return discInvoiceAmount;
	}

	public void setDiscInvoiceAmount(BigDecimal discInvoiceAmount) {
		this.discInvoiceAmount = discInvoiceAmount;
	}


	
	public boolean isAttachementIconInd() {
		return attachementIconInd;
	}

	public void setAttachementIconInd(boolean attachementIconInd) {
		this.attachementIconInd = attachementIconInd;
	}

	public String getIndicatorFlag() {
		return indicatorFlag;
	}

	public void setIndicatorFlag(String indicatorFlag) {
		this.indicatorFlag = indicatorFlag;
	}	

	public boolean isCallOutIndicator() {
		return callOutIndicator;
	}

	public void setCallOutIndicator(boolean callOutIndicator) {
		this.callOutIndicator = callOutIndicator;
	}

	public boolean isLineItemInd() {
		return lineItemInd;
	}

	public void setLineItemInd(boolean lineItemInd) {
		this.lineItemInd = lineItemInd;
	}

	/** Invoice and Credit Note Call Out Starts**/
	public String getBuyerRefNo() {
		return buyerRefNo;
	}

	public void setBuyerRefNo(String buyerRefNo) {
		this.buyerRefNo = buyerRefNo;
	}

	public String getSellerRefNo() {
		return sellerRefNo;
	}

	public long getInvId() {
		return invId;
	}

	public void setInvId(long invId) {
		this.invId = invId;
	}

	public void setSellerRefNo(String sellerRefNo) {
		this.sellerRefNo = sellerRefNo;
	}

	public String getCntInvoiceRefNo() {
		return cntInvoiceRefNo;
	}

	public void setCntInvoiceRefNo(String cntInvoiceRefNo) {
		this.cntInvoiceRefNo = cntInvoiceRefNo;
	}

	public String getCntEffectDate() {
		return cntEffectDate;
	}

	public void setCntEffectDate(String cntEffectDate) {
		this.cntEffectDate = cntEffectDate;
	}

	public String getCntUtilizedAmt() {
		return cntUtilizedAmt;
	}

	public void setCntUtilizedAmt(String cntUtilizedAmt) {
		this.cntUtilizedAmt = cntUtilizedAmt;
	}

	public String getInvoiceCreditNoteID() {
		return invoiceCreditNoteID;
	}

	public void setInvoiceCreditNoteID(String invoiceCreditNoteID) {
		this.invoiceCreditNoteID = invoiceCreditNoteID;
	}

	public String getPaymntRefNumberUnique() {
		return paymntRefNumberUnique;
	}

	public void setPaymntRefNumberUnique(String paymntRefNumberUnique) {
		this.paymntRefNumberUnique = paymntRefNumberUnique;
	}

	public BigDecimal getAlreadySettledAmount() {
		return alreadySettledAmount;
	}

	public void setAlreadySettledAmount(BigDecimal alreadySettledAmount) {
		this.alreadySettledAmount = alreadySettledAmount;
	}

	public BigDecimal getDueAmount() {
		return dueAmount;
	}

	public void setDueAmount(BigDecimal dueAmount) {
		this.dueAmount = dueAmount;
	}
	
	/** Invoice and Credit Note Call Out Ends**/
	
	/**
	 * Getter methods introduced to send the amounts as
	 * String to avoid amount > 16 digits getting truncated
	 * Added as part of defect Fix CSC-7835
	 */
	
	public String getInvoiceAmountStr()
	{
		return(invoiceAmount !=null)?invoiceAmount.toPlainString():"";
	}
	
	public String getAlreadySettledAmountStr()
	{
		return(alreadySettledAmount !=null)?alreadySettledAmount.toPlainString():"";
	}
	
	public String getDiscInvoiceAmountStr()
	{
		return(discInvoiceAmount !=null)?discInvoiceAmount.toPlainString():"";
	}
	
	public String getDueAmountStr()
	{
		return(dueAmount !=null)?dueAmount.toPlainString():"";
	}
	
	//added to handle the common code in UI
	public String getCntUtilizedAmtStr() {
		return cntUtilizedAmt;
	} 
	
	
	
}
