/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   07 Apr 2016
 * 
 * Purpose:     Login Service Intf
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 11 Apr 2016                      Oracle Financial Services Software Ltd                                    Initial Version
 * 02 Mar 2017                      Purjayar                                                     UX10.0 S021 - Display icon only on 2FA authentication- Added method getchk2FAUser 
 * 14 Dec 2017			  	  		Rameshwar Khedekar							  							  FO 10.0.2- CSC 8692: Existing pin validation, disable certificate logic 
 *****************************************************************************************************************************************************************/

package com.bnp.bnpux.service;

import java.util.List;
import java.util.Map;

import com.bnp.bnpux.common.vo.EntitlementVO;
import com.bnp.bnpux.common.vo.OrganizationVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.common.vo.UserVO;
import com.bnp.bnpux.common.vo.WhiteLabelVO;
import com.bnp.bnpux.vo.requestVO.LoginRequestVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;


public interface INewLoginService {

	/**
	 * This method is for getting the User login status
	 * 
	 * @param userId
	 * @param sessionId
	 * @return
	 * @throws BNPApplicationException
	 */
	UserVO getUserLoginStatus(String userId, String sessionId) throws BNPApplicationException;
	
	/**
	 * This method is for getting the user UX info
	 * 
	 * @param userVO
	 * @return
	 * @throws BNPApplicationException
	 */
	List<UserInfoVO> getUserUXInfo(UserVO userVO) throws BNPApplicationException;

	/**
	 * This method is for getting the Org logo
	 * 
	 * @param orgId
	 * @return
	 */
	OrganizationVO getOrgLogo(String orgId);

	/**
	 * This method is for getting the White label details
	 * 
	 * @param userId
	 * @return
	 * @throws BNPApplicationException
	 */
	List<WhiteLabelVO> getWhiteLabelDetails(String userId) throws BNPApplicationException;
	
	/**********Added for New UX 9.0 - User story S18,S19 starts ***********/

	/**
	 * This method is for getting the entitlement details
	 * 
	 * @param userId
	 * @return
	 * @throws BNPApplicationException
	 */
	List<EntitlementVO> getEntitlmntDet(String userId) throws BNPApplicationException; 
	/**********Added for New UX 9.0 - User story S18,S19 ends ***********/
	
	/**********Added for New UX 9.0 - (Session Handling)*****/
	/**
	 * This method is for updaing the new session details
	 * 
	 * @param userVO
	 * @return
	 */
	UserVO updateNewSessionDetails(UserVO userVO);

	/**
	 * This method is for getting the User login status for new ux
	 * 
	 * @param userId
	 * @param sessionId
	 * @param authToken
	 * @return
	 * @throws BNPApplicationException
	 */
	UserVO getUserLoginStatusForNewUX(String userId, String sessionId, String authToken) throws BNPApplicationException;

	/**
	 * This method is for getting the time interval
	 * 
	 * @return
	 * @throws BNPApplicationException
	 */
	String getTimeInterval() throws BNPApplicationException;

	/**
	 * This method is for getting the scroll info list
	 * 
	 * @return
	 * @throws BNPApplicationException
	 */
	List<NameValueVO> getScrollInfoList() throws BNPApplicationException;
	
	/**
	 * This method is for checking user is counter party
	 * 
	 * @param userId
	 * @return
	 */
	String getIsCounterpartyUser(String userId);
	
	
	/**
	 * This method is for checking user is authorized for 2FA login
	 * 
	 * @param userId
	 * @return String
	 */
	String getchk2FAUser(String userId)throws BNPApplicationException;
	
	/**
	 * This method is to get the session inactive time interval from the DB.
	 * For Bank user , query will fetch it from the PARAM_MASTER table and
	 * org user query will fetch it from the M_ORGANIZATION table.
	 * 
	 * @param userId
	 * @return String
	 */
	String getSessionInactiveInterval(String userId) throws BNPApplicationException;
	
	/**
	 * FO 10.0.2- CSC 8692: Existing pin validation, disable certificate logic
	 * @param pinInfo 
	 * @throws BNPApplicationException
	 */
	public String updateCertStatus(Map pinInfo) throws BNPApplicationException;
	
	/**
	 * This method is used to get current serialNo for certificate.
	 * @param userId 
	 * @return String
	 * @throws BNPApplicationException
	 */
	public String getSerialNoByUser(String userId) throws BNPApplicationException;

	/**
	 * This method is used to validate uploaded file hashkey with DB hashkey
	 * @param requestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	boolean isCertificateHashKeyValid(LoginRequestVO requestVO) throws BNPApplicationException;

	/**
	 * This method is used to update newly generated Certificate hash key
	 * @param requestVO
	 * @throws BNPApplicationException
	 */
	void updateCertificateHashKey(LoginRequestVO requestVO) throws BNPApplicationException;
	
	/**
	 * This method is used to get user certificate Hash Key.
	 * @param userId 
	 * @return String
	 * @throws BNPApplicationException
	 */
	public String getUserCertHashkey(String userId) throws BNPApplicationException;
	
}
