package com.bnp.bnpux.vo.requestVO;

import java.util.List;

import com.bnp.bnpux.common.vo.FileUploadStatusVO;

public class FileUploadRequestVO {
	
	private String userId;

	private String userType;
	
	private String supportBranchId;
	
	private String fileId;
	
	private String errorFlag;
	
	private List<FileUploadStatusVO> fileStatusListVO;	

	public String getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	public List<FileUploadStatusVO> getFileStatusListVO() {
		return fileStatusListVO;
	}

	public void setFileStatusListVO(List<FileUploadStatusVO> fileStatusListVO) {
		this.fileStatusListVO = fileStatusListVO;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getSenderOrgId() {
		return senderOrgId;
	}

	public void setSenderOrgId(String senderOrgId) {
		this.senderOrgId = senderOrgId;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	private String senderOrgId;
	
	private String docType;

	/**
	 * @return the supportBranchId
	 */
	public String getSupportBranchId() {
		return supportBranchId;
	}

	/**
	 * @param supportBranchId the supportBranchId to set
	 */
	public void setSupportBranchId(String supportBranchId) {
		this.supportBranchId = supportBranchId;
	}
	
}
