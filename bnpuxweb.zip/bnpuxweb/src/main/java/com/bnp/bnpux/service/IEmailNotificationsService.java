/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   26-May-2017
 * 
 * Purpose:     Notifications Service
 * 
 * Change History:
 *  
 * Date                       Author                                            Reason
 * 26-May-2017			Bala Murugan Elangovan					Base version for Notifications Service 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.service;

import com.bnp.bnpux.common.vo.EmailNotificationsVO;
import com.bnp.bnpux.vo.requestVO.EmailNotificationsRequestVO;
import com.bnp.bnpux.vo.responseVO.EmailNotificationsResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface IEmailNotificationsService {

	/**
	 * Abstract method is used to fetch notifications list
	 * @param noticationsVO
	 * @return
	 * @throws BNPApplicationException
	 */
	EmailNotificationsResponseVO getNotificationsList(EmailNotificationsRequestVO noticationsVO) throws BNPApplicationException;

	/**
	 * Abstract method is used to fetch email Inquiry Report list
	 * @param EmailNotificationsRequestVO
	 * @return EmailNotificationsResponseVO
	 * @throws BNPApplicationException
	 */
	public EmailNotificationsResponseVO getEmailInqRptList(EmailNotificationsRequestVO noticationsVO) throws BNPApplicationException ;
		
	/**
	 * Abstract method is used to fetch email Inquiry Report list
	 * @param EmailNotificationsVO
	 * @return EmailNotificationsVO
	 * @throws BNPApplicationException
	 */
	EmailNotificationsVO getEmailInqRptDetails(EmailNotificationsVO noticationsVO) throws BNPApplicationException ;
	
	/**
	 * This method is for getting attachment information for the file and Download operations
	 * 
	 * @param emailNotificationsVO
	 * @return
	 * @throws BNPApplicationException
	 */
	EmailNotificationsVO getAttachmentData(EmailNotificationsVO emailNotificationsVO) throws BNPApplicationException;
		
	
}
