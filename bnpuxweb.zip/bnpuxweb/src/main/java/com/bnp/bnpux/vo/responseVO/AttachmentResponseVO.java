package com.bnp.bnpux.vo.responseVO;

import java.util.List;

import com.bnp.scm.services.common.vo.AttachmentVO;

public class AttachmentResponseVO {
	
	private String errorMsg;
	
	private String fileName;

	byte[] data;
	
	String attachmentRefNO;
	
	String attachmentType;
	
	private int seqNo;
	
	private List<AttachmentVO> attachmentList;
	
	private boolean isSingleAttachment;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public int getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(int seqNo) {
		this.seqNo = seqNo;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getAttachmentRefNO() {
		return attachmentRefNO;
	}

	public void setAttachmentRefNO(String attachmentRefNO) {
		this.attachmentRefNO = attachmentRefNO;
	}

	public String getAttachmentType() {
		return attachmentType;
	}

	public void setAttachmentType(String attachmentType) {
		this.attachmentType = attachmentType;
	}

	public List<AttachmentVO> getAttachmentList() {
		return attachmentList;
	}

	public void setAttachmentList(List<AttachmentVO> attachmentList) {
		this.attachmentList = attachmentList;
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

	public boolean isSingleAttachment() {
		return isSingleAttachment;
	}

	public void setSingleAttachment(boolean isSingleAttachment) {
		this.isSingleAttachment = isSingleAttachment;
	}
	
	

}
