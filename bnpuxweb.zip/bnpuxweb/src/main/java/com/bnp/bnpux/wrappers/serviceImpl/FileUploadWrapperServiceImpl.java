/******************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   31 Mar 2011
 * 
 * Purpose:      Financial Inquiry Functionality
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 29 Apr 2017          Oracle Financial Services Software Ltd                 Moved FileUploadBean from OldUX
 * 1 MAY 2017            	Bhuvaneswari                                       File Upload  
*************************************************************************************************************************************************************/
package com.bnp.bnpux.wrappers.serviceImpl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.bnp.bnpux.vo.requestVO.FileUploadRequestVO;
import com.bnp.bnpux.wrappers.service.IFileUploadWrapperService;
import com.bnp.eipp.services.filemgmt.IEippFileMgmtService;
import com.bnp.eipp.services.filemgmt.util.InstrumentTypeEnum;
import com.bnp.scm.common.IResourceManager;
import com.bnp.scm.services.admin.EntitlementService;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.IAccessLogService;
import com.bnp.scm.services.common.cache.ICacheService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.CacheConstants;
import com.bnp.scm.services.common.util.ScreenConstants;
import com.bnp.scm.services.common.vo.AbstractVO;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.bnp.scm.services.discounting.IDiscountDefinitionService;
import com.bnp.scm.services.filemgmt.IFileManagementService;
import com.bnp.scm.services.filemgmt.vo.FileUploadVO;
import com.bnp.scm.services.filemgmt.vo.FileVO;
import com.bnp.scm.services.marketing.IPreAprvdSupplierFileMgmtService;

/**
 * The Class FileUploadBean.
 */
@Component
@Scope("request")
public class FileUploadWrapperServiceImpl implements IFileUploadWrapperService{
	
	/** The logger. */
	private static Logger LOGGER = LoggerFactory.getLogger(FileUploadWrapperServiceImpl.class);

	/** The file service. */
	@Autowired
	private IFileManagementService fileService;
	
	/** The eipp file service. */
	@Autowired
	private IEippFileMgmtService eippFileService;

	/** The cache service. */
	@Autowired
	private ICacheService cacheService;
	
	/** The rel file inq bean. */
	@Autowired
	private ReleaseFileInqServiceImpl relFileInqBean;
	
	/** The login bean. *//*
	@Autowired
	private LoginBean loginBean;
*/
	/** The resource manager. */
	@Autowired
	private IResourceManager resourceManager;
	
	/** The property loader. */
	@Autowired
	private BNPPropertyLoaderConfigurer propertyLoader;
	
	/** The disc def service. */
	@Autowired
	private IDiscountDefinitionService discDefService;
	
	/** The access log service. */
	@Autowired
	private IAccessLogService accessLogService;
	
	/** The pre aprvd supplier file mgmt srvc. */
	@Autowired
	private IPreAprvdSupplierFileMgmtService preAprvdSupplierFileMgmtSrvc;

	/** The entitlement service. */
	@Autowired
	private	EntitlementService entitlementService;
	

	/** The file type id sel val list. */
	private static List<String> fileTypeIdSelValList;


	/**
	 * Checks if is valid format types.
	 *
	 * @param formatType the format type
	 * @return true, if is valid format types
	 */
	private boolean isValidFormatTypes(String formatType) {
      return CacheConstants.REFRESH_BASE_RATE_VAL.equals(formatType) || CacheConstants.DISC_CONFIRMATION_VAL.equals(formatType)
	    ||CacheConstants.TP_DISC_CONFIRM_VAL.equals(formatType) ||CacheConstants.UPDATE_SETTLEMENTS_VAL.equals(formatType);	
    }
		
		
	/**
	 * Checks if is invalid type.
	 *
	 * @param formatType the format type
	 * @return true, if is invalid type
	 */
	private boolean isInvalidType(String formatType, String senderOrgId){
	  return isSenderOrgIdNull(senderOrgId)&& !(CacheConstants.EIPP_BILLING_CHARGECOUNT.equals(formatType) || CacheConstants.REFRESH_BASE_RATE_VAL.equals(formatType) || CacheConstants.DISC_CONFIRMATION_VAL.equals(formatType)  ||
	    CacheConstants.TP_DISC_CONFIRM_VAL.equals(formatType)  || CacheConstants.UPDATE_SETTLEMENTS_VAL.equals(formatType));
	}
	
		
	/**
	 * Checks if is sender org id null.
	 *
	 * @return true, if is sender org id null
	 */
	private boolean isSenderOrgIdNull(String senderOrgId) {
	  return (StringUtils.isEmpty(senderOrgId));
	}
				
	/**
	 * Sets the file type on scf disc doc.
	 */
	private void setFileTypeOnScfDiscDoc(FileUploadVO fileUploadVO) throws BNPApplicationException{
	NameValueVO nameValueVO = fileService.getFileTypeForOrg(fileUploadVO.getSenderOrgId(),fileUploadVO.getSupportBranchId());
	String orgLevelFileType = null;
		if (nameValueVO != null) {
			orgLevelFileType = nameValueVO.getName();
		}
	  fileUploadVO.setFileType((BNPConstants.S.equalsIgnoreCase(orgLevelFileType) || BNPConstants.SCF_XML.equalsIgnoreCase(fileUploadVO.getFileVO().getFileType())) ? BNPConstants.STANDARD_FILE_TYPE: BNPConstants.CUSTOM_FILE_TYPE)  ;
	}
					
	/**
	 * Checks if is invoice settlement file.
	 *
	 * @param formatType the format type
	 * @return true, if is invoice settlement file
	 */
	private  boolean isInvoiceSettlementFile(String formatType) {
	  return (formatType != null && BNPConstants.INVOICESETTLEMENTS.equalsIgnoreCase(formatType)) ? true : false;
	}
	
	/**
	 * Checks if is valid file detail format.
	 *
	 * @param formatType the format type
	 * @param senderOrgId the sender org id
	 * @return true, if is valid file detail format
	 * @throws BNPApplicationException the BNP application exception
	 */
	private boolean isValidFileDetailFormat(String formatType,String senderOrgId) throws BNPApplicationException {
	  return  (!formatType.equals(BNPConstants.EIPP) && !formatType.equals(BNPConstants.PRE_APPROVED_SUPPLIER_LIST)&& !CacheConstants.EIPP_DISPUTE.equals(formatType) && !CacheConstants.EIPP_UPDT_PYMT_STATUS.equals(formatType) &&
	    !CacheConstants.EIPP_INVOICE_CANCELLATION.equals(formatType) && !CacheConstants.EIPP_PYMT_PREP_VAL.equals(formatType) && !CacheConstants.EIPP_BILLING_CHARGECOUNT.equals(formatType) &&
		!CacheConstants.EIPP_INV_ATTACHMENT.equals(formatType) && !discDefService.getDiscDefinitions(senderOrgId) && !fileTypeIdSelValList.contains(formatType) && !formatType.equals(BNPConstants.MATCH_EIPP_INVC) && 
		!formatType.equals(BNPConstants.MATCH_EIPP_CN) && !formatType.equals(BNPConstants.MATCH_RECON) && !formatType.equals(BNPConstants.MATCH_EIPP_PMT_RESP) && !CacheConstants.TP_DISC_CONFIRM_VAL.equals(formatType));
	}
	
	/**
	 * Checks if is zip file type.
	 *
	 * @param contentType the content type
	 * @return true, if is zip file type
	 */
	private boolean isZipFileType(String contentType){
	  return (BNPConstants.CONTENT_TYPE_COMPRESSED.equalsIgnoreCase(contentType) || BNPConstants.CONTENT_TYPE_ZIP.equalsIgnoreCase(contentType) || BNPConstants.CONTENT_TYPE_XZIP.equalsIgnoreCase(contentType));
	}
	
	/**
	 * Checks if is standard file type.
	 *
	 * @param contentType the content type
	 * @return true, if is standard file type
	 */
	private boolean isStandardFileType(String contentType){
	  return (BNPConstants.CONTENT_TYPE_TEXT_XML.equalsIgnoreCase(contentType) || BNPConstants.CONTENT_TYPE_APPLICATION_XML.equalsIgnoreCase(contentType) 
	    || BNPConstants.CONTENT_TYPE_ATOM_XML.equalsIgnoreCase(contentType));
	}
	
	/**
	 * Checks if is eipp file.
	 *
	 * @param fileFormatType the file format type
	 * @return true, if is eipp file
	 */
	private boolean isEippFile(String fileFormatType) {
	  return (BNPConstants.EIPP.equals(fileFormatType) || InstrumentTypeEnum.isEippFile(fileFormatType)) ? true : false;
	}
	/**
	 * Checks if is file released by system.
	 *
	 * @return true, if is file released by system
	 */
	private boolean isFileReleasedBySystem(FileUploadVO fileUploadVO){
	  return (fileUploadVO.getDetailsVO() != null && BNPConstants.SYSTEM.equalsIgnoreCase(fileUploadVO.getDetailsVO().getReleasedBy()));
	}
	/**
	 * This API will be invoked from the UI component
	 * 
	 * @param event
	 * @throws Exception
	 */
	public FileVO onUpload(FileUploadRequestVO fileUpldVO,
			MultipartFile file ,String sessionId) throws IOException {
	  long startTime = System.currentTimeMillis();
	  String errorMsg = BNPConstants.EMPTY;
	  LOGGER.warn("Enter : onUpload = {} ",System.currentTimeMillis());	 
	  LOGGER.debug("Sender Organization details "+fileUpldVO.getSenderOrgId());
	  FileVO fileVO = new FileVO();
	  FileUploadVO fileUploadVO = createFileUploadVO(fileUpldVO);
	  
	  String fileFormatType = fileUploadVO.getFileFormatType();
	  if (isInvalidType(fileFormatType , fileUploadVO.getSenderOrgId())) {
		  errorMsg = setErrorMsgForSenderOrgId();
		  setErrorMsg(fileVO, null , errorMsg,false);
	  } else {
	    try {
	       errorMsg = validateFileDetails(file.getContentType() , fileUploadVO);
		  setFileVO(file,fileUpldVO , fileVO ,fileUploadVO,fileUpldVO.getUserId());
		  setAccessLogDetails(fileUploadVO ,sessionId , fileUpldVO.getUserId());
		  
		  if (isEippFile(fileUploadVO.getFileFormatType())) {		    
			fileVO.setReferenceNo(eippFileService.uploadDataFile(fileUploadVO));
		  }else if (BNPConstants.PRE_APPROVED_SUPPLIER_LIST.equals(fileFormatType)) {
		    preAprvdSupplierFileMgmtSrvc.uploadDataFile(fileUploadVO);
			if(isFileReleasedBySystem(fileUploadVO)){
			  relFileInqBean.sendEmailToBank(fileUploadVO.getDetailsVO());
			}
	      } else {
		    long fileId = 0;
			if (isValidFormatTypes(fileFormatType)) {			
			  fileId = fileService.uploadFile(fileUploadVO);
			} else {
			  setFileTypeOnScfDiscDoc(fileUploadVO);
			  fileId = fileService.uploadDataFile(fileUploadVO);
			}
			fileVO.setReferenceNo(fileId);
			LOGGER.debug("The uploaded file identifier from File Upload Bean is "+fileId+ " with file format type "+fileFormatType);
		  }
		  setStatusMsg(fileVO,fileUploadVO);
		} catch (BNPApplicationException exception) {
		  setErrorMsg(fileVO, exception , null,true);
		  LOGGER.error("BNPApplicationException Occured While Executing method onUpload() in FileUploadBean  {} ",exception);
		} catch (RuntimeException exception) {
		  setErrorMsg(fileVO, exception , null,true);
		  LOGGER.error("RuntimeException Occured While Executing method onUpload() in FileUploadBean  {} ",exception);
		} 
	  }
	 long stopTime = System.currentTimeMillis();
	  LOGGER.warn("The Time Taken To Execute the method onUpload from FileUploadBean is :: ",(stopTime - startTime)+" milliseconds");
	return fileVO;
	}
	
	
	
	/**
	 * Sets the error msg.
	 *
	 * @param fileVO the file vo
	 * @param exception the exception
	 */
	private void setErrorMsg(FileVO fileVO, Exception exception , String errorMsg , boolean isException) {
	  fileVO.setStatus(BNPConstants.FAILURE);
	 if(isException){
	  fileVO.setStatusMessage(exception.getMessage());
	  errorMsg = exception.getMessage();
	 }
	  
	  if (errorMsg != null && errorMsg.length() > 0) {
        fileVO.setErroneousData(errorMsg);
	  }
	}
	

	/**
	 * Validate file details.
	 *
	 * @param uploadedItem the uploaded item
	 * @throws BNPApplicationException the BNP application exception
	 */
	private String validateFileDetails(String contentType , FileUploadVO fileUploadVO) throws BNPApplicationException {
	  long startTime = System.currentTimeMillis();
	  NameValueVO orgType = discDefService.getDiscountDoc(fileUploadVO.getSenderOrgId());
	  String productType = orgType.getName();
	  fileUploadVO.setProductType(productType);
	  setFileType(contentType ,fileUploadVO );
	  String errorMsg = null;
	try{	
	    if (!isSenderOrgIdNull(fileUploadVO.getSenderOrgId())) {
		  if(isValidFileDetailFormat(fileUploadVO.getFileFormatType(),fileUploadVO.getSenderOrgId())){
		    errorMsg =resourceManager.getMessage(ErrorConstants.ORG_NOT_ELIG_FOR_DISCOUNT);
		  }else if(isInvoiceSettlementFile(fileUploadVO.getFileFormatType())){		    
			LOGGER.debug("Checking senderOrg is Supplier centric supplier ::");
			if(!BNPConstants.RECEIVABLES.equalsIgnoreCase(productType)){	
				errorMsg = setErrorMessageForNonReceivableOrg(orgType ,fileUploadVO);			
			}else{
			  fileUploadVO.setProductType(BNPConstants.RECEIVABLES);
			}
		  }
		}
	    long stopTime = System.currentTimeMillis();
	    LOGGER.warn("The Time Taken To Execute the method validateFileDetails from FileUploadBean is :: "+(stopTime - startTime));
	  } catch (BNPApplicationException exception) {
		LOGGER.error("BNPApplicationException Occured While Executing method validateFileDetails() in FileUploadBean  {} ",exception);
	    errorMsg = resourceManager.getMessage(exception.getErrorCode());		
		return errorMsg;
	  }
	return errorMsg;
	}

	/**
	 * Sets the status msg.
	 *
	 * @param fileVO the new status msg
	 */
	private void setStatusMsg(FileVO fileVO, FileUploadVO fileUploadVO) {
	  String statusMsg = fileUploadVO.getFileVO().getStatusMessage();
	  fileVO.setStatus(BNPConstants.SUCCESS);
	  fileVO.setStatusMessage(statusMsg != null ? statusMsg : BNPConstants.FILE_SUCCESSFULLY_UPLOADED);
	}

	/**
	 * Sets the file vo.
	 *
	 * @param uploadedItem the uploaded item
	 * @param fileVO the file vo
	 */
	private void setFileVO(MultipartFile file, FileUploadRequestVO fileUpldVO, FileVO fileVO, FileUploadVO fileUploadVO, String userId) throws IOException {	  
	  String fileName = file.getOriginalFilename();
	  String fileType = null;
	  int index = fileName.lastIndexOf("\\"); 
	  if (index > -1) {
	    fileName = fileName.substring((index + 1), fileName.length());
	  }
	  index = fileName.lastIndexOf('.');
	  fileType = fileName.substring((index + 1), fileName.length());
	  fileVO.setUserId(fileUpldVO.getUserId());
	  fileVO.setData(file.getBytes());
	  fileVO.setFileName(fileName);
	  fileVO.setContentType(file.getContentType());
	  fileVO.setFileType(fileType);
	  fileVO.setUserId(userId);
	  fileUploadVO.setFileVO(fileVO);
	  /*fileList.add(fileVO);
	  maxFileCount--;*/
	}
	/**
	 * Sets the error message for non receivable org.
	 *
	 * @param orgType the new error message for non receivable org
	 */
	private String setErrorMessageForNonReceivableOrg(NameValueVO orgType, FileUploadVO fileUploadVO) {
	  fileUploadVO.setProductType(orgType.getName());
	  
	  return resourceManager.getMessage(ErrorConstants.SENDER_NOT_IN_RECEIVABLES);
	}


	/**
	 * Sets the error msg for sender org id.
	 */
	private String setErrorMsgForSenderOrgId() {	 
	  return resourceManager.getMessage(ErrorConstants.MANDATORY_FIELD_ERROR);
	}

	/**
	 * Sets the file type.
	 *
	 * @param uploadedItem the new file type
	 */
	private void setFileType(String contentType, FileUploadVO fileUploadVO) {
	  if(isStandardFileType(contentType)){
	    fileUploadVO.setFileType(BNPConstants.STANDARD_FILE_TYPE);
	  }else if(isZipFileType(contentType)){
		fileUploadVO.setFileType(BNPConstants.ZIP_FILE_TYPE);
	  }else{
	    fileUploadVO.setFileType(BNPConstants.CUSTOM_FILE_TYPE);
	  }
	}
	


	/**
	 * Sets the access log details.
	 *
	 * @throws BNPApplicationException the BNP application exception
	 */
	private void setAccessLogDetails(FileUploadVO fileUploadVO, String sessionId, String userId) throws BNPApplicationException {
	  AbstractVO abstractVO = new AbstractVO();
	  abstractVO.setCurrentUserId(userId);
	  abstractVO.setSessionId(sessionId);
	  abstractVO.setCheckPoint(ScreenConstants.ACCESS_LOG_FILE_UPLOAD);
	  /*String screenId = loginBean.getUserVO().getSelectedLink();*/
	  abstractVO.setScreenId(ScreenConstants.MANUALFILEUPLOAD);
	  abstractVO.setOrgId(fileUploadVO.getSenderOrgId());
	  abstractVO.setAccessLogRefNo(fileUploadVO.getFileVO().getFileName());
	    accessLogService.insertAccessLog(abstractVO);
	
	}
	
	/**
	 * Sets the file type id sel val list.
	 */
	 static  {
	  fileTypeIdSelValList = new ArrayList<String>();
	  fileTypeIdSelValList.add(CacheConstants.EIPP_MATCHING_AND_RECONCILATION_VAL);
	  fileTypeIdSelValList.add(CacheConstants.MATCHING_EIPP_INVOICE_VAL);
	  fileTypeIdSelValList.add(CacheConstants.MATCHING_EIPP_CREDIT_NOTE_VAL);
	  fileTypeIdSelValList.add(CacheConstants.MATCHING_EIPP_PAYMENT_RESPONSE_VAL);
	}
	
	/**
	 * @param fileUpldVO
	 * @return 
	 */
	private FileUploadVO createFileUploadVO(FileUploadRequestVO fileUpldVO) {
		FileUploadVO uploadVO = new FileUploadVO();
		uploadVO.setFileFormatType(fileUpldVO.getDocType());
		uploadVO.setSenderOrgId(fileUpldVO.getSenderOrgId());
		uploadVO.setSupportBranchId(fileUpldVO.getSupportBranchId());
		uploadVO.setLoginUserTypeId(fileUpldVO.getUserType());
		
		return uploadVO;
	}	
}
