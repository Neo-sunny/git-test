/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   02-Mar-2017
 * 
 * Purpose:      Advanced Filter Response VO
 * 
 * Change History:
 *  
 * Date                       Author                                            Reason
 * 02-Mar-2017				BELANGOV					Base version for Advanced filter Response VO 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.responseVO;

import java.util.Date;
import java.util.List;

import com.bnp.bnpux.common.vo.AdvancedFilterVO;

public class AdvancedFilterResponseVO {

		
	private Date periodFromDate;
	
	private Date periodToDate;
	
	private String errorMsg;	
	
	List<AdvancedFilterVO> periodDateList;
	
	List<AdvancedFilterVO> advancedFilterList;
	
			
	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public List<AdvancedFilterVO> getAdvancedFilterList() {
		return advancedFilterList;
	}

	public void setAdvancedFilterList(List<AdvancedFilterVO> advancedFilterList) {
		this.advancedFilterList = advancedFilterList;
	}

	public Date getPeriodFromDate() {
		return periodFromDate;
	}

	public void setPeriodFromDate(Date periodFromDate) {
		this.periodFromDate = periodFromDate;
	}

	public Date getPeriodToDate() {
		return periodToDate;
	}

	public void setPeriodToDate(Date periodToDate) {
		this.periodToDate = periodToDate;
	}

	public List<AdvancedFilterVO> getAdvanceFilterList() {
		return advancedFilterList;
	}

	public void setAdvanceFilterList(List<AdvancedFilterVO> advanceFilterList) {
		this.advancedFilterList = advanceFilterList;
	}
		
	public List<AdvancedFilterVO> getPeriodDateList() {
		return periodDateList;
	}

	public void setPeriodDateList(List<AdvancedFilterVO> periodDateList) {
		this.periodDateList = periodDateList;
	}	
	
}
