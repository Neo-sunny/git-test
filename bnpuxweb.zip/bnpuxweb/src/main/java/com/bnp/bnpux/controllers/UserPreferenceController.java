/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      User Preference Controller
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import java.util.List;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.common.vo.UserPreferenceVO;
import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.constants.UserPreferenceConstants;
import com.bnp.bnpux.service.IAuditService;
import com.bnp.bnpux.service.ICreateUserService;
import com.bnp.bnpux.service.INewUserPrefService;
import com.bnp.bnpux.util.ExportUtil;
import com.bnp.bnpux.util.RequestIdentityValidator;
import com.bnp.bnpux.vo.requestVO.AuditRequestVO;
import com.bnp.bnpux.vo.requestVO.LoginRequestVO;
import com.bnp.scm.services.common.cache.ICacheService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

@RestController
@RequestMapping("/userPreferenceCtrl")
public class UserPreferenceController {
	
	/**
	 * Logger log for UserPreferenceController class
	 */
	public static final Logger log = LoggerFactory.getLogger(UserPreferenceController.class);

	/**
	 * ICacheService cacheService;
	 */
	@Autowired
	private ICacheService cacheService;	
	
	@Autowired
	private RequestIdentityValidator validateRequest;	
	
	/**
	 * IUserPrefService userPrefService;
	 */
	@Autowired
	private INewUserPrefService userPrefService;	
	
	/**
	 * UserPreferenceVO userPrefVO;
	 */
	//private UserPreferenceVO userPrefVO;
	
	/**
	 * ICreateUserService createUserSrv;
	 */
	@Autowired
	private ICreateUserService createUserSrv;		
	
	@Autowired
	private IAuditService auditService;
	
	/** Added the below 4 instance variables to store the data which will used across all HTTP request for validation **/
    /** Date Format List **/
	private List<String> dateFormatList;
	
	/** The amount format list. */
	private List<String> amountFormatList;
	
	/** Language format list.*/
	private List<String>  languageList;
	
	/** TimeZone List */
	private List<String> timeZoneList;
				
	/**
	 * This method is used to get the default user preferences values (Amount Format, Date Format, Time Zone and Language)
	 * 
	 * @param requsetVO
	 * @return
	 */
	@RequestMapping(value = "getUserPreferenceInfo.rest", method = RequestMethod.POST)
	public UserPreferenceVO getUserPreferenceInfo(@RequestBody LoginRequestVO requsetVO, HttpServletRequest request, HttpServletResponse response){
		UserPreferenceVO userPrefVO = null; // Fortify issue Fix 
		try{
			boolean validateRequestFlag = validateRequest.validate(requsetVO.getUserid(), request.getSession());
			if(validateRequestFlag){
				userPrefVO=new UserPreferenceVO();	
				userPrefVO = userPrefService.getUserPreferenceInfo(requsetVO.getUserid(),requsetVO.getUserid());
				userPrefVO.setDateFormatList(cacheService.getDateFormatList());
				if(dateFormatList == null){
				    initDateFormatList(userPrefVO.getDateFormatList());
				}
				userPrefVO.setAmountFormatList(cacheService.getAmountFmtList());
				if(amountFormatList == null){
					initAmountFormatList(userPrefVO.getAmountFormatList());
				}
				userPrefVO.setLanguageList(createUserSrv.populateLanguageList());
				if(languageList == null ){
					initLanguageList(userPrefVO.getLanguageList());
				}
				userPrefVO.setLocaleAmtFrmtList(cacheService.getLocaleAmtFrmtList());
				if(timeZoneList == null){
					initTimeZoneList(userPrefVO.getCountryZoneList());
				}
			}
			else{
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		}catch(BNPApplicationException bnpException){
			log.error(UserPreferenceConstants.EXCEPTION_DATA_BASE,bnpException);
		}
		return userPrefVO;
	}
	
	/**
	 * This method is used to update the user preferences
	 * 
	 * @param userPrefVO
	 * @param request
	 * @return
	 * @throws BNPApplicationException
	 */
	@RequestMapping(value = "updateUserPreference.rest", method = RequestMethod.POST)
	public UserPreferenceVO updateUserPreference(@RequestBody UserPreferenceVO userPrefVO, HttpServletRequest request, HttpServletResponse response) throws BNPApplicationException {
		try{
			HttpSession session = request.getSession();
			boolean validateRequestFlag = validateRequest.validate(userPrefVO.getUserId(), session);
			// This method introduced as part of Pen Test issue - XSS Reflection 
			boolean isRequestParametersValid = validateValues(userPrefVO);
			if(validateRequestFlag && isRequestParametersValid){
				UserInfoVO user = (UserInfoVO) session.getAttribute("userInfo");
				userPrefVO = userPrefService.saveUserPreferenceInfo(userPrefVO);
				user.setSessionId((String) session.getAttribute("USER_AUTH_TOKEN"));
				AuditRequestVO auditVo = new AuditRequestVO();
				auditVo.setUserId(user.getUserId());
				auditVo.setSessionId(user.getSessionId());
				auditVo.setFuncId(UserPreferenceConstants.USERPREFERENCE_AUDIT);
				auditVo.setOrgId(user.getOrgId());
				auditService.insertAuditLog(auditVo);
			}
			else{
				userPrefVO = null;
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		}catch(BNPApplicationException bnpException){
			log.error(UserPreferenceConstants.EXCEPTION_DATA_BASE,bnpException);
		}
		return userPrefVO;
	}
	
	/* This method will process the date format and stores the value alone in the date format list
	 * This will be called only once in the life cycle of this component
	 * 
	 */
	public void initDateFormatList(List<NameValueVO> detailedList){
		if(detailedList != null ){
			dateFormatList = new ArrayList<String>();
			for(NameValueVO nameValue : detailedList){
				dateFormatList.add((String)nameValue.getValue());
			}
		}
	}
	
	/* This method will process the amount format and stores the value alone in the amount format list
	 * This will be called only once in the life cycle of this component
	 * 
	 */
	public void initAmountFormatList(List<NameValueVO> detailedList){
		if(detailedList != null ){
			amountFormatList = new ArrayList<String>();
			for(NameValueVO nameValue : detailedList){
				amountFormatList.add(nameValue.getValue());
			}
		}
		
	}
	
	/* This method will process the language code and stores the value alone in the language format list
	 * This will be called only once in life cycle of this component
	 * 
	 */
	
	public void initLanguageList(List<NameValueVO> detailedList){
		if(detailedList != null ){
			languageList = new ArrayList<String>();
			for(NameValueVO nameValue : detailedList){
				languageList.add(nameValue.getName());
			}
		}
	}
	
	/* This method will process the timezone format and stores the value alone in the timezone format list
	 * This will be called only once in the life cycle of this component
	 * 
	 */
	public void initTimeZoneList(List<NameValueVO> detailedList){
		if(detailedList != null ){
			timeZoneList = new ArrayList<String>();
			for(NameValueVO nameValue : detailedList){
				timeZoneList.add(nameValue.getValue());
			}
		}
	
	}
	/* Validate the incoming request parameters with accepted values.
	 * 
	 */
	public boolean validateValues(UserPreferenceVO userPrefVO){
		boolean valid = false;
		if (languageList.contains(userPrefVO.getLanguage()) && amountFormatList.contains(userPrefVO.getPreferredAmtFmt()) && dateFormatList.contains(userPrefVO.getPreferredDateFmt()) && timeZoneList.contains(userPrefVO.getCountryZone())){
	    	valid = true;
	    }else{
	    	log.warn("Invalid Request Parameters - UPDATE USER PREFERENCE- Details --> UserPreference VO "+userPrefVO.getLanguage()+" Amount "+userPrefVO.getPreferredAmtFmt()+" Date Format "+userPrefVO.getPreferredDateFmt()+" country Zone "+userPrefVO.getCountryZone());
	    }
		return valid;
	}
}
