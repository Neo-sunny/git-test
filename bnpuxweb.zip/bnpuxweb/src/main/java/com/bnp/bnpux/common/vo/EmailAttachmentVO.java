package com.bnp.bnpux.common.vo;

public class EmailAttachmentVO {
	
	private byte[] data;
	
	private String attachmentName;

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

	public String getAttachmentName() {
		return attachmentName;
	}

	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}

}
