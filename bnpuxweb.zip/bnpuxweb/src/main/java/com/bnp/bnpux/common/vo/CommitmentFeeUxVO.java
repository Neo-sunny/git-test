/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   10-FEB-2017
 * 
 * Purpose:      Commitment Fee Ux VO
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 10-FEB-2017				  Sathishkumar B									New VO - S271, S273, S274, S275, S276, S277
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

public class CommitmentFeeUxVO extends AbstractVO{

	/**
	 * 
	 */
	private static final long serialVersionUID = -965056350161587093L;
	
	private String fromDate;
	
	private String toDate;
	
	private String period;
	
	private String commitmentAmount;
	
	private double feePercentage;
	
	private String outstandingAmount;
	
	private String feePayDueDate;
	
	private String paymentStatus;
	
	private String feeCCY;
	
	private String commFeePeriod;
	
	private String unfundedCollFreq;
	
	private String unfundedCollVal;

	private String commFeePaidDate;
	
	private double paidAmount;
	
	private String commFeeDebitNoteRef;
	
	private String fileName;
	
	private byte[] data;

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getCommitmentAmount() {
		return commitmentAmount;
	}

	public void setCommitmentAmount(String commitmentAmount) {
		this.commitmentAmount = commitmentAmount;
	}

	public double getFeePercentage() {
		return feePercentage;
	}

	public void setFeePercentage(double feePercentage) {
		this.feePercentage = feePercentage;
	}

	public String getOutstandingAmount() {
		return outstandingAmount;
	}

	public void setOutstandingAmount(String outstandingAmount) {
		this.outstandingAmount = outstandingAmount;
	}

	public String getFeePayDueDate() {
		return feePayDueDate;
	}

	public void setFeePayDueDate(String feePayDueDate) {
		this.feePayDueDate = feePayDueDate;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getFeeCCY() {
		return feeCCY;
	}

	public void setFeeCCY(String feeCCY) {
		this.feeCCY = feeCCY;
	}
	
	public String getCommFeePeriod() {
		return commFeePeriod;
	}

	public void setCommFeePeriod(String commFeePeriod) {
		this.commFeePeriod = commFeePeriod;
	}

	public String getUnfundedCollFreq() {
		return unfundedCollFreq;
	}

	public void setUnfundedCollFreq(String unfundedCollFreq) {
		this.unfundedCollFreq = unfundedCollFreq;
	}

	public String getUnfundedCollVal() {
		return unfundedCollVal;
	}

	public void setUnfundedCollVal(String unfundedCollVal) {
		this.unfundedCollVal = unfundedCollVal;
	}
	
	public String getCommFeePaidDate() {
		return commFeePaidDate;
	}

	public void setCommFeePaidDate(String commFeePaidDate) {
		this.commFeePaidDate = commFeePaidDate;
	}

	public double getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(double paidAmount) {
		this.paidAmount = paidAmount;
	}

	public String getCommFeeDebitNoteRef() {
		return commFeeDebitNoteRef;
	}

	public void setCommFeeDebitNoteRef(String commFeeDebitNoteRef) {
		this.commFeeDebitNoteRef = commFeeDebitNoteRef;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

}
