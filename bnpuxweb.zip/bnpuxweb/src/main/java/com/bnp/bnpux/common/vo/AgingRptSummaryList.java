/**
 * 
 */
package com.bnp.bnpux.common.vo;

/**
 * @author banandha
 *
 */
public class AgingRptSummaryList {

	
	private String buyerOrgId;
	
	private String suppOrgId;
	
	private String buyerOrgName;
	
	private String suppOrgName;
	
	private String buyerErpId;
	
	private String suppErpId;
	
	private String currencyCode;	
	
	private String errorMessage;
	
	private String timePeriod;
	
	private String bandRecordCnt;
	
	private String deicmalPnt;
	
	

	/**
	 * @return the buyerOrgId
	 */
	public String getBuyerOrgId() {
		return buyerOrgId;
	}

	/**
	 * @param buyerOrgId the buyerOrgId to set
	 */
	public void setBuyerOrgId(String buyerOrgId) {
		this.buyerOrgId = buyerOrgId;
	}

	/**
	 * @return the suppOrgId
	 */
	public String getSuppOrgId() {
		return suppOrgId;
	}

	/**
	 * @param suppOrgId the suppOrgId to set
	 */
	public void setSuppOrgId(String suppOrgId) {
		this.suppOrgId = suppOrgId;
	}

	/**
	 * @return the buyerOrgName
	 */
	public String getBuyerOrgName() {
		return buyerOrgName;
	}

	/**
	 * @param buyerOrgName the buyerOrgName to set
	 */
	public void setBuyerOrgName(String buyerOrgName) {
		this.buyerOrgName = buyerOrgName;
	}

	/**
	 * @return the suppOrgName
	 */
	public String getSuppOrgName() {
		return suppOrgName;
	}

	/**
	 * @param suppOrgName the suppOrgName to set
	 */
	public void setSuppOrgName(String suppOrgName) {
		this.suppOrgName = suppOrgName;
	}

	/**
	 * @return the buyerErpId
	 */
	public String getBuyerErpId() {
		return buyerErpId;
	}

	/**
	 * @param buyerErpId the buyerErpId to set
	 */
	public void setBuyerErpId(String buyerErpId) {
		this.buyerErpId = buyerErpId;
	}

	/**
	 * @return the suppErpId
	 */
	public String getSuppErpId() {
		return suppErpId;
	}

	/**
	 * @param suppErpId the suppErpId to set
	 */
	public void setSuppErpId(String suppErpId) {
		this.suppErpId = suppErpId;
	}

	/**
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * @return the timePeriod
	 */
	public String getTimePeriod() {
		return timePeriod;
	}

	/**
	 * @param timePeriod the timePeriod to set
	 */
	public void setTimePeriod(String timePeriod) {
		this.timePeriod = timePeriod;
	}

	/**
	 * @return the bandRecordCnt
	 */
	public String getBandRecordCnt() {
		return bandRecordCnt;
	}

	/**
	 * @param bandRecordCnt the bandRecordCnt to set
	 */
	public void setBandRecordCnt(String bandRecordCnt) {
		this.bandRecordCnt = bandRecordCnt;
	}

	/**
	 * @return the deicmalPnt
	 */
	public String getDeicmalPnt() {
		return deicmalPnt;
	}

	/**
	 * @param deicmalPnt the deicmalPnt to set
	 */
	public void setDeicmalPnt(String deicmalPnt) {
		this.deicmalPnt = deicmalPnt;
	}

	
	

}
