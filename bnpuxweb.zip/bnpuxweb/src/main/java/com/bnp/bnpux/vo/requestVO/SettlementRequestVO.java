/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:      Settlement Request Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016           Oracle Financial Services Software Ltd              Initial Version 
 * 14-Mar-2017            Divyashri Subramaniam                              FO10.0 Added attributes for Advanced filter options
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.requestVO;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.bnp.bnpux.common.vo.AdvancedFilterVO;
import com.bnp.bnpux.common.vo.SettlementListDetailsVO;
import com.bnp.bnpux.common.vo.SettlementListVO;
import com.bnp.bnpux.common.vo.SettlementSummaryVO;

public class SettlementRequestVO {

	private String userId;

	private String userType;

	private String orgId;
	
	private String leadOrgId;

	private String currencyCode;

	private BigDecimal availableAmt;

	private BigDecimal indicativeNetAmt;

	private BigDecimal supplierBalance;

	private String paymentOrderNo;

	private String paymentOrderStatus;
	
	private Date maturityDate;	
	
	private Long recordFrom;
	
	private Long recordTo;
	
	private Integer recordCount;
	
	private String maturityFilter;
	
	private String errorFlag;
	
	private String advanceFilter;
	
	private String groupIndicator;
	
	private String viewType;
	
	private String supplierOrgId;
	
	private String buyerOrgId;
	
	private String buyerRefNumberUnique;
	
	private String paymentRefNumberUnique;
	
	private String discRefNo;
	
	private String periodFilter;
	
	private String statusFilter;

	private String branchFilter;
	
	private String quickSearchText;
	
	private String dueDate;
	
	/* Added below variables for code review comments(HashMap to RequestVO  in service layer)*/
	
	private List<SettlementSummaryVO> settlementdetails;
	
	private List<SettlementListVO> settlementOrderList;
	
	private List<SettlementListDetailsVO> settlementListDetails;

	private List<AdvancedFilterVO> advancedFilterListVO;

	public String getQuickSearchText() {
		return quickSearchText;
	}

	public void setQuickSearchText(String quickSearchText) {
		this.quickSearchText = quickSearchText;
	}

	public String getPeriodFilter() {
		return periodFilter;
	}

	public void setPeriodFilter(String periodFilter) {
		this.periodFilter = periodFilter;
	}

	public String getStatusFilter() {
		return statusFilter;
	}

	public void setStatusFilter(String statusFilter) {
		this.statusFilter = statusFilter;
	}

	public Date getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(Date maturityDate) {
		this.maturityDate = maturityDate;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public BigDecimal getAvailableAmt() {
		return availableAmt;
	}

	public void setAvailableAmt(BigDecimal availableAmt) {
		this.availableAmt = availableAmt;
	}

	public BigDecimal getIndicativeNetAmt() {
		return indicativeNetAmt;
	}

	public void setIndicativeNetAmt(BigDecimal indicativeNetAmt) {
		this.indicativeNetAmt = indicativeNetAmt;
	}

	public BigDecimal getSupplierBalance() {
		return supplierBalance;
	}

	public void setSupplierBalance(BigDecimal supplierBalance) {
		this.supplierBalance = supplierBalance;
	}

	public String getPaymentOrderNo() {
		return paymentOrderNo;
	}

	public void setPaymentOrderNo(String paymentOrderNo) {
		this.paymentOrderNo = paymentOrderNo;
	}

	public String getPaymentOrderStatus() {
		return paymentOrderStatus;
	}

	public void setPaymentOrderStatus(String paymentOrderStatus) {
		this.paymentOrderStatus = paymentOrderStatus;
	}

	public String getLeadOrgId() {
		return leadOrgId;
	}

	public void setLeadOrgId(String leadOrgId) {
		this.leadOrgId = leadOrgId;
	}

	

	public Integer getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(Integer recordCount) {
		this.recordCount = recordCount;
	}

	public String getMaturityFilter() {
		return maturityFilter;
	}

	public void setMaturityFilter(String maturityFilter) {
		this.maturityFilter = maturityFilter;
	}

	public String getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	public String getAdvanceFilter() {
		return advanceFilter;
	}

	public void setAdvanceFilter(String advanceFilter) {
		this.advanceFilter = advanceFilter;
	}


	public String getViewType() {
		return viewType;
	}

	public void setViewType(String viewType) {
		this.viewType = viewType;
	}

	public String getGroupIndicator() {
		return groupIndicator;
	}

	public void setGroupIndicator(String groupIndicator) {
		this.groupIndicator = groupIndicator;
	}

	public String getSupplierOrgId() {
		return supplierOrgId;
	}

	public void setSupplierOrgId(String supplierOrgId) {
		this.supplierOrgId = supplierOrgId;
	}

	public String getBuyerOrgId() {
		return buyerOrgId;
	}

	public void setBuyerOrgId(String buyerOrgId) {
		this.buyerOrgId = buyerOrgId;
	}

	public String getBuyerRefNumberUnique() {
		return buyerRefNumberUnique;
	}

	public void setBuyerRefNumberUnique(String buyerRefNumberUnique) {
		this.buyerRefNumberUnique = buyerRefNumberUnique;
	}

	public String getDiscRefNo() {
		return discRefNo;
	}

	public void setDiscRefNo(String discRefNo) {
		this.discRefNo = discRefNo;
	}

	public String getBranchFilter() {
		return branchFilter;
	}

	public void setBranchFilter(String branchFilter) {
		this.branchFilter = branchFilter;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public String getPaymentRefNumberUnique() {
		return paymentRefNumberUnique;
	}

	public void setPaymentRefNumberUnique(String paymentRefNumberUnique) {
		this.paymentRefNumberUnique = paymentRefNumberUnique;
	}

	public List<SettlementSummaryVO> getSettlementdetails() {
		return settlementdetails;
	}

	public void setSettlementdetails(List<SettlementSummaryVO> settlementdetails) {
		this.settlementdetails = settlementdetails;
	}

	public List<SettlementListVO> getSettlementOrderList() {
		return settlementOrderList;
	}

	public void setSettlementOrderList(List<SettlementListVO> settlementOrderList) {
		this.settlementOrderList = settlementOrderList;
	}

	public List<SettlementListDetailsVO> getSettlementListDetails() {
		return settlementListDetails;
	}

	public void setSettlementListDetails(List<SettlementListDetailsVO> settlementListDetails) {
		this.settlementListDetails = settlementListDetails;
	}

	public List<AdvancedFilterVO> getAdvancedFilterListVO() {
		return advancedFilterListVO;
	}

	public void setAdvancedFilterListVO(List<AdvancedFilterVO> advancedFilterListVO) {
		this.advancedFilterListVO = advancedFilterListVO;
	}

	public Long getRecordFrom() {
		return recordFrom;
	}

	public void setRecordFrom(Long recordFrom) {
		this.recordFrom = recordFrom;
	}

	public Long getRecordTo() {
		return recordTo;
	}

	public void setRecordTo(Long recordTo) {
		this.recordTo = recordTo;
	}

}
