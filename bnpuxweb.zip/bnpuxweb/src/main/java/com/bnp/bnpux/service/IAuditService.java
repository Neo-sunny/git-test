/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   24 May 2016
 * 
 * Purpose:     Audit Service Intf
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 24 May 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 
 *****************************************************************************************************************************************************************/

package com.bnp.bnpux.service;

import com.bnp.bnpux.vo.requestVO.AuditRequestVO;

public interface IAuditService {

	/**
	 * Insert audit log
	 */
	public void insertAuditLog(AuditRequestVO auditVo);
	
}
