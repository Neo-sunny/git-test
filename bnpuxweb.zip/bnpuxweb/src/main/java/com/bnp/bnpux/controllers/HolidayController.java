/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Holiday Controller
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 08 Mar 2017                skbhaska                                    		FO 10.0 - S30 - Holiday Calendar
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.constants.HolidayConstants;
import com.bnp.bnpux.service.IAuditService;
import com.bnp.bnpux.service.IHolidayService;
import com.bnp.bnpux.util.RequestIdentityValidator;
import com.bnp.bnpux.vo.requestVO.AuditRequestVO;
import com.bnp.bnpux.vo.requestVO.HolidayRequestVO;
import com.bnp.bnpux.vo.responseVO.HolidayResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@RestController
@RequestMapping("/holidayCtrl")
public class HolidayController {
	
	/**
	 * Logger for PaymentOrderController
	 */
	public static final Logger log = LoggerFactory.getLogger(HolidayController.class);
	
	@Autowired
	private IHolidayService holidayService;
	
	@Autowired
	RequestIdentityValidator validateRequest;
	
	@Autowired
	private IAuditService auditService;
	
	/**
	 * Method to get Holiday list
	 * 
	 * @param holReqVo
	 * @return
	 */
	@RequestMapping(value = HolidayConstants.HOLIDAY_REST, method = RequestMethod.POST)
	public HolidayResponseVO getHolidayList(
			@RequestBody HolidayRequestVO holReqVo,HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		
		HolidayResponseVO holidayResponseVO = new HolidayResponseVO();
		HolidayRequestVO holidayRequestVO = new HolidayRequestVO();
		
		try {
			boolean requestValidatedFlag = validateRequest.validate(holReqVo.getUserid(),httpServletRequest.getSession());
			if(requestValidatedFlag){
				log.debug("Holiday controller Start..");
				
				holidayRequestVO.setLeadOrgId(holReqVo.getLeadOrgId());
				holidayRequestVO.setCcyCode(holReqVo.getCcyCode());
				holidayResponseVO.setHolidayList(holidayService.getHolidayList(holidayRequestVO));
			}
			else{
				holidayResponseVO = null;
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		}catch (BNPApplicationException exception) {
			log.error(exception.getMessage() + " - " +exception);
			
		}
		log.debug("Holiday controller end..");
		return holidayResponseVO;
	}
	
	
	/**
	 * This method is invoked from holidayController.js
	 * Used to get the list of holiday based on CYY List, Year, Org ID, Branch (For BA Users) 
	 * @param holReqVo
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @return HolidayResponseVO
	 */
	@RequestMapping(value = "getHolidayListForCalendar.rest", method = RequestMethod.POST)
	public HolidayResponseVO getHolidayListForCalendar(
			@RequestBody HolidayRequestVO holReqVo,HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		
		log.debug("Enter getHolidayListForCalendar");
		
		HttpSession session = httpServletRequest.getSession();
		HolidayResponseVO holidayResponseVO = new HolidayResponseVO();
		
		try {
			boolean requestValidatedFlag = validateRequest.validate(holReqVo.getUserid(),httpServletRequest.getSession());
			if(requestValidatedFlag){
				
				log.debug("getHolidayListForCalendar :: Before Service Call");
				
				holidayResponseVO.setHolidayList(holidayService.getHolidayListForCalendar(holReqVo));
				
				log.debug("getHolidayListForCalendar :: adding Audit entries");
				UserInfoVO user = (UserInfoVO) session.getAttribute("userInfo");
				user.setSessionId((String) session.getAttribute("USER_AUTH_TOKEN"));
				AuditRequestVO auditVo = new AuditRequestVO();
				auditVo.setUserId(user.getUserId());
				auditVo.setSessionId(user.getSessionId());
				auditVo.setOrgId(user.getOrgId());
				auditVo.setFuncId(BNPConstants.FUNCID_HOLIDAYCALENDAR);
				auditService.insertAuditLog(auditVo);
			}
			else{
				holidayResponseVO = null;
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		}catch (BNPApplicationException exception) {
			log.error(exception.getMessage() + " - " +exception);
		}
		
		log.debug("Exit getHolidayListForCalendar");
		
		return holidayResponseVO;
	}


}