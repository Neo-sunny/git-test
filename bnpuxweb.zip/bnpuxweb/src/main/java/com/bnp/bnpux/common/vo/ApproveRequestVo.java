/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Approve Request Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.io.Serializable;
import java.util.List;

import com.bnp.scm.services.discounting.vo.DiscountRequestVO;

public class ApproveRequestVo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	private UserInfoVO transReqVO;
	private transient List<TransactionListVO> transListVO;
	
	private DiscountRequestVO tempDiscReqVO;
	private List<ApproveResponseGridVo> apprvdResGridListVO;
	
	
	public DiscountRequestVO getTempDiscReqVO() {
		return tempDiscReqVO;
	}
	public void setTempDiscReqVO(DiscountRequestVO tempDiscReqVO) {
		this.tempDiscReqVO = tempDiscReqVO;
	}
	public List<ApproveResponseGridVo> getApprvdResGridListVO() {
		return apprvdResGridListVO;
	}
	public void setApprvdResGridListVO(List<ApproveResponseGridVo> apprvdResGridListVO) {
		this.apprvdResGridListVO = apprvdResGridListVO;
	}
	
	public UserInfoVO getTransReqVO() {
		return transReqVO;
	}
	public void setTransReqVO(UserInfoVO transReqVO) {
		this.transReqVO = transReqVO;
	}
	public List<TransactionListVO> getTransListVO() {
		return transListVO;
	}
	public void setTransListVO(List<TransactionListVO> transListVO) {
		this.transListVO = transListVO;
	}
	
	
	
}
