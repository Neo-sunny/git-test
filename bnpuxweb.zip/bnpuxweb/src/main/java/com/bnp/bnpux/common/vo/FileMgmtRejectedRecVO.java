/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14 Mar 2017
 * 
 * Purpose:      File Management Rejected Record VO
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 28-Mar-2018				        Bala Murugan Elangovan					    R11.0 - User Story - S2018X1803 - Rejected Valid Records introduction
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

public class FileMgmtRejectedRecVO {
	
	private String type;
	private String errorData;
	private String errorMsg;
	private Integer bandRecCount;
	private String recordType;
	
	
	public Integer getBandRecCount() {
		return bandRecCount;
	}
	public void setBandRecCount(Integer bandRecCount) {
		this.bandRecCount = bandRecCount;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getErrorData() {
		return errorData;
	}
	public void setErrorData(String errorData) {
		this.errorData = errorData;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public String getRecordType() {
		return recordType;
	}
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}	
	
}
