/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Holiday Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 08 Mar 2017                skbhaska                                    		FO 10.0 - S30 - Holiday Calendar
************************************************************************************************************************************************************/

package com.bnp.bnpux.common.vo;

import java.io.Serializable;
import java.util.Date;

public class HolidayVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Date holDate;
	private Date startDate;
	private Date endDate;

	private String holType;
	private String color;
	private String ccyCodeComma;

	public Date getHolDate() {
		return holDate;
	}

	public void setHolDate(Date holDate) {
		this.holDate = holDate;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getHolType() {
		return holType;
	}

	public void setHolType(String holType) {
		this.holType = holType;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getCcyCodeComma() {
		return ccyCodeComma;
	}

	public void setCcyCodeComma(String ccyCodeComma) {
		this.ccyCodeComma = ccyCodeComma;
	}

}
