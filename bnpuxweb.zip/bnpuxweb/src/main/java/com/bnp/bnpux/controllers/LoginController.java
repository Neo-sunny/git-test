/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Login Controller
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 02 Mar 2017                Purjayar                                        UX10.0 S021 - Display icon only on 2FA authentication- Added is2FAUser Value in User Preference
 * 14 Dec 2017			  	  Rameshwar Khedekar							  FO 10.0.2- CSC 8692: Existing pin validation, disable certificate logic
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.common.vo.EntitlementVO;
import com.bnp.bnpux.common.vo.OrganizationVO;
import com.bnp.bnpux.common.vo.UserBranchVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.common.vo.UserVO;
import com.bnp.bnpux.common.vo.WhiteLabelVO;
import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.service.INewLoginService;
import com.bnp.bnpux.service.IUserService;
import com.bnp.bnpux.util.ImageUtil;
import com.bnp.bnpux.util.RequestIdentityValidator;
import com.bnp.bnpux.vo.requestVO.LoginRequestVO;
import com.bnp.scm.common.IResourceManager;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;


@RestController
@RequestMapping("/loginCtrl")
public class LoginController {
	private static final Logger log = LoggerFactory.getLogger(LoginController.class);
	
	@Autowired
	INewLoginService loginService;
	
	@Autowired
	RequestIdentityValidator validateRequest;
	
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IResourceManager resourceManager;
	
	
	/**
	 * This method is for getting user info
	 * 
	 * @param requsetVO
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "getUserInfo.rest", method = RequestMethod.POST)
	public Map<String,Object> getUserInfo(@RequestBody LoginRequestVO requsetVO,HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) { 
		UserVO userVO = new UserVO();
		userVO.setUserId(requsetVO.getUserid());
		UserInfoVO userInfo = null;
		List<EntitlementVO> entitlDet = null;
		Map<String,Object> resultMap = null;
		try {
			HttpSession session = httpServletRequest.getSession();
			boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserid(),session);
			if(requestValidatedFlag){
				resultMap = new HashMap<String,Object>();
				List<UserInfoVO> userDetails=loginService.getUserUXInfo(userVO);
				if(!userDetails.isEmpty())
				{
					userInfo=userDetails.get(0);
					
					String sOrgType = "";
					
					if(userInfo.getUserTypeId().equals("BA")){
						sOrgType = "";
					}else{
						sOrgType = loginService.getIsCounterpartyUser(requsetVO.getUserid());
					}
					
					userInfo.setOrgType(sOrgType);
					
					List<UserBranchVO> branches = userService.getUserInfo(requsetVO.getUserid(),userInfo.getOrgId());
					userInfo.setBranchList(branches);
					session.setAttribute("userInfo", userInfo);
					List<NameValueVO> scrollInfoList = loginService.getScrollInfoList();
					userInfo.setScrollInfoList(scrollInfoList);	
				}
				resultMap.put("userInfo", userInfo);
				entitlDet=loginService.getEntitlmntDet(requsetVO.getUserid());
				resultMap.put("entitlDet", entitlDet);
				String is2FAUser=loginService.getchk2FAUser(requsetVO.getUserid());
				resultMap.put("is2FAUser", is2FAUser);
			}
			else{
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (BNPApplicationException e) {
			log.error(e.getMessage(),e);
		}		
		return resultMap;
	}
	
	/**
	 * This method is for getting organization logo
	 * 
	 * @param orgId
	 * @param request
	 * @param response
	 */
	@RequestMapping("getorg.img")
	public void getOrganizationLogo(@RequestParam("orgId") String orgId,HttpServletRequest request,HttpServletResponse response)
	{
		OrganizationVO org = loginService.getOrgLogo(orgId);
		byte [] img;
		if(org.getOrgLogo() ==  null)
		{
			String imgPath = request.getSession().getServletContext().getRealPath("images/hh.png");
			
			img = ImageUtil.getOrgLogo(imgPath);	
			response.setContentType("image/png");
		}
		else
		{
			img = org.getOrgLogo();
			
			response.setContentType(org.getLogoFileType());
			
		}
		
		//response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
		response.setContentLength(img.length);
	    try {
			response.getOutputStream().write(img);
			 response.getOutputStream().close();
		} catch (IOException e) {
			log.error(e.getMessage(),e);
		}
	}
	
	/**
	 * This method is for getting white label info
	 * 
	 * @param requsetVO
	 * @return
	 */
	@RequestMapping(value = "getWhiteLabelInfo.rest", method = RequestMethod.POST)
			//headers = {"content-type=application/json","content-type=application/xml"})
			//, consumes=MediaType.APPLICATION_JSON,produces= MediaType.APPLICATION_JSON)
	public  List<WhiteLabelVO> getWhiteLabelInfo(@RequestBody LoginRequestVO requsetVO,HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) { 
		List<WhiteLabelVO> responseVO = null;
		try{
			boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserid(),httpServletRequest.getSession());
			if(requestValidatedFlag){
				responseVO = new ArrayList<WhiteLabelVO>();
				responseVO = loginService.getWhiteLabelDetails(requsetVO.getUserid());	
			}
			else{
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		}catch (BNPApplicationException e) {
			log.error(e.getMessage(),e);
		}		
		return responseVO;		
	}
	@RequestMapping(value ="isLogoAvailable.rest", method = RequestMethod.POST)
	public String isLogoAvailable(@RequestBody String orgId) throws IOException{
		String width = "30px";
		OrganizationVO org = loginService.getOrgLogo(orgId);
		if(org.getOrgLogo() !=  null){
			width = "90px";
		}
		return width;
	}

	/**
	 * This method is for getting entitlements
	 * 
	 * @param reqVo
	 * @return
	 */
	@RequestMapping(value = "getEntitlements.rest", method = RequestMethod.POST)
	public List<EntitlementVO> getEntitlements(@RequestBody LoginRequestVO reqVo,HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		List<EntitlementVO> entitlDet = null;
		try {
			boolean requestValidatedFlag = validateRequest.validate(reqVo.getUserid(),httpServletRequest.getSession());
			if(requestValidatedFlag){
				entitlDet=loginService.getEntitlmntDet(reqVo.getUserid());
			}
			else{
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (BNPApplicationException e) {
			log.error("Exception in getEntitlements",e);
		}		
		return entitlDet;
	}
	
	/**
	 * This method is used to get the message bundle key and values
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "getmessageBundle.rest", method = RequestMethod.GET)
	public @ResponseBody Properties getmessageBundle(HttpServletRequest request) {
		String propertyLocation =  request.getParameter("part");
		String[] locale = request.getParameter("lang").split("_");
		
		String sLanguage = "_"+locale[0]+"_"+locale[1];
		if(locale[0].equals("en"))
		{
			resourceManager.setResourceBundle("");
		}
		else
		{
			resourceManager.setResourceBundle(sLanguage);
		}
		
		Locale lc = new Locale(locale[0], locale[1]);
		ResourceBundle resourceBundle = null;
		Properties properties = new Properties();
		
		InputStreamReader errorPropsReader = null;
		
		try { 
				/**For Label Properties - Start**/
			
				if(propertyLocation == null || propertyLocation.length() == 0 || ("default").equals(propertyLocation)){
					propertyLocation = BNPConstants.LOCALE_PROPERTY_FILE_PATH;
				}
			
				resourceBundle = ResourceBundle.getBundle(propertyLocation, lc);
				properties = convertResourceBundleToProperties(resourceBundle,properties);
				
				/**For Label Properties - End**/
				
				/**For Error Properties - Start**/
				propertyLocation = BNPConstants.LOCALE_ERROR_PROPERTY_FILE_PATH;
				
				String absolutePath = BNPConstants.BACK_SLASH+propertyLocation+sLanguage+BNPConstants.PROPERTIES_FILE_TYPE;
				
				/**Convert to UTF-8 for the below files**/
				if(lc.toString().equals("zh_CN") || lc.toString().equals("zh_TW") || lc.toString().equals("th_TH") || lc.toString().equals("ja_JP") || lc.toString().equals("ko_KR")){
					
					errorPropsReader = new InputStreamReader( getClass().getClassLoader().getResourceAsStream(absolutePath), "UTF-8");
					
					resourceBundle = new PropertyResourceBundle(errorPropsReader);
				}else{
					
					resourceBundle = ResourceBundle.getBundle(propertyLocation, lc);
				}
				
				properties = convertResourceBundleToProperties(resourceBundle,properties);
				
				/**For Error Properties - End**/
				
				log.debug("Properties loaded.."+properties.toString());
				
		} catch (Exception e) {
			log.error(e.getMessage(),e);
		}finally {
			try {
				if(errorPropsReader != null){
					errorPropsReader.close();
				}
			} catch (IOException e) {
				log.error(e.getMessage(),e);
			}
		}
		return properties;
	}

	/**
	 * This method is used to iterate resource bundle and make property object
	 * 
	 * @param resource
	 * @param properties
	 * @return
	 */
	private static Properties convertResourceBundleToProperties(ResourceBundle resource, Properties properties) {
		Enumeration<?> keys = resource.getKeys();
		while (keys.hasMoreElements()) {
			String key = (String) keys.nextElement();
			properties.put(key, resource.getString(key));
		}
		return properties;
	}
	
	/**
	 * Added for FO 10.0.2- CSC 8692: This method is used to update newly generated Certificate hash key
	 * @param requestVO
	 * @param httpServletRequest
	 * @param httpServletResponse
	 */
	@RequestMapping(value="updateCertStatus",method=RequestMethod.POST)
	public LoginRequestVO updateCertStatus(@RequestBody LoginRequestVO requestVO,HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		try{

			String serialNo = loginService.getSerialNoByUser(requestVO.getUserid());
			Map pinInfo = new HashMap();
			
			pinInfo.put("userId", requestVO.getUserid()); 
			pinInfo.put("serialNo", serialNo);
			pinInfo.put("screenFlag", 2);
			pinInfo.put("pinSuccess", Boolean.parseBoolean(requestVO.getPinSuccess()));
			String resultCode = loginService.updateCertStatus(pinInfo);
			
			requestVO.setPinSuccessMesg(resultCode);
		} catch (BNPApplicationException exception) {
			log.error("Exception in Change certificate Pin"+exception);
		}
		return requestVO;
	}
	
	/**
	 * This method is used to validate uploaded file hashkey with DB hashkey
	 * @param requestVO
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @return
	 */
	@RequestMapping(value="isCertificateHashKeyValid",method=RequestMethod.POST)
	public boolean isCertificateHashKeyValid(@RequestBody LoginRequestVO requestVO,HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		boolean isValidCertificate = false;
		try{
			boolean requestValidatedFlag = validateRequest.validate(requestVO.getUserid(),httpServletRequest.getSession());
			if(requestValidatedFlag){
				
				String userCertHashKey = loginService.getUserCertHashkey(requestVO.getUserid());
				if(userCertHashKey != null){
				    isValidCertificate = loginService.isCertificateHashKeyValid(requestVO);
				}else{
					isValidCertificate = true;
				}
			}			
		}catch(BNPApplicationException exception){
			log.error(exception.getMessage(),exception);
		}
		return isValidCertificate;
	}
	
	/**
	 * This method is used to update newly generated Certificate hash key
	 * @param requestVO
	 * @param httpServletRequest
	 * @param httpServletResponse
	 */
	@RequestMapping(value="updateCertificateHashKey",method=RequestMethod.POST)
	public void updateCertificateHashKey(@RequestBody LoginRequestVO requestVO,HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		try{
			boolean requestValidatedFlag = validateRequest.validate(requestVO.getUserid(),httpServletRequest.getSession());
			if(requestValidatedFlag){
				
				String userCertHashKey = loginService.getUserCertHashkey(requestVO.getUserid());
				if(userCertHashKey != null){
				     loginService.updateCertificateHashKey(requestVO);
				}
			}
		}catch(BNPApplicationException exception){
			log.error(exception.getMessage(),exception);
		}
	}

}