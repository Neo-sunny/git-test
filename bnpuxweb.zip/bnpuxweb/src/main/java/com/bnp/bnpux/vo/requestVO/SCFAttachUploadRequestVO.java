/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   15-JUL-2017
 * 
 * Purpose:      SCF Attach Upload Request VO
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 15-JUL-2017				Divyashri Subramaniam						To Handle service calls Request Object related to SCF Attachment Upload
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.requestVO;

import java.util.List;

import com.bnp.scm.services.common.vo.AttachmentVO;
import com.bnp.scm.services.discounting.vo.CreditNoteUtilizationVO;
import com.bnp.scm.services.invoice.vo.InvoiceVO;

public class SCFAttachUploadRequestVO {
	
	private String userId;

	private String userType;
	
	private String orgId;
	
	private String errorFlag;
	
	private String title;
	
	private String pymtRefNo;
	
	private String errMessage;
	
	private Integer errCode;
	
	private String cnRefNo;
	
	private String invRefNo;
	
	private Long pymtID;
	
	private Long invID;
	
	private Long credNoID;

	private String pymtRefUniqNo;
	
	private String invRefUniqNo;
	
	private String cnRefUniqNo;
	
	private List<AttachmentVO> attachmentVOList;	
	
	private List<InvoiceVO> invoiceList;
	
	private List<CreditNoteUtilizationVO> creditNoteList;
	
	private String uploadCode;
	
	private Integer maxFileSize;
	
	private Integer maxFileCount;
	
	private AttachmentVO removeAttachVO;
	
	private String fileName;
	
	private int seqNo;
	
	private String attachPmtId;
	
	private String attchPendAppFlg;
	
	public String getAttachPmtId() {
		return attachPmtId;
	}

	public void setAttachPmtId(String attachPmtId) {
		this.attachPmtId = attachPmtId;
	}

	public String getAttchPendAppFlg() {
		return attchPendAppFlg;
	}

	public void setAttchPendAppFlg(String attchPendAppFlg) {
		this.attchPendAppFlg = attchPendAppFlg;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public int getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(int seqNo) {
		this.seqNo = seqNo;
	}

	public String getErrMessage() {
		return errMessage;
	}

	public void setErrMessage(String errMessage) {
		this.errMessage = errMessage;
	}

	public Integer getErrCode() {
		return errCode;
	}

	public void setErrCode(Integer errCode) {
		this.errCode = errCode;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public AttachmentVO getRemoveAttachVO() {
		return removeAttachVO;
	}

	public void setRemoveAttachVO(AttachmentVO removeAttachVO) {
		this.removeAttachVO = removeAttachVO;
	}

	private String type;
	
	public String getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPymtRefUniqNo() {
		return pymtRefUniqNo;
	}

	public void setPymtRefUniqNo(String pymtRefUniqNo) {
		this.pymtRefUniqNo = pymtRefUniqNo;
	}

	public String getInvRefUniqNo() {
		return invRefUniqNo;
	}

	public void setInvRefUniqNo(String invRefUniqNo) {
		this.invRefUniqNo = invRefUniqNo;
	}

	public String getCnRefUniqNo() {
		return cnRefUniqNo;
	}

	public void setCnRefUniqNo(String cnRefUniqNo) {
		this.cnRefUniqNo = cnRefUniqNo;
	}

	public String getUploadCode() {
		return uploadCode;
	}

	public void setUploadCode(String uploadCode) {
		this.uploadCode = uploadCode;
	}

	public String getPymtRefNo() {
		return pymtRefNo;
	}

	public void setPymtRefNo(String pymtRefNo) {
		this.pymtRefNo = pymtRefNo;
	}

	public String getCnRefNo() {
		return cnRefNo;
	}

	public void setCnRefNo(String cnRefNo) {
		this.cnRefNo = cnRefNo;
	}

	public String getInvRefNo() {
		return invRefNo;
	}

	public void setInvRefNo(String invRefNo) {
		this.invRefNo = invRefNo;
	}

	public Long getPymtID() {
		return pymtID;
	}

	public void setPymtID(Long pymtID) {
		this.pymtID = pymtID;
	}

	public Long getInvID() {
		return invID;
	}

	public void setInvID(Long invID) {
		this.invID = invID;
	}

	public Long getCredNoID() {
		return credNoID;
	}

	public void setCredNoID(Long credNoID) {
		this.credNoID = credNoID;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public List<AttachmentVO> getAttachmentVOList() {
		return attachmentVOList;
	}

	public void setAttachmentVOList(List<AttachmentVO> attachmentVOList) {
		this.attachmentVOList = attachmentVOList;
	}

	public List<InvoiceVO> getInvoiceList() {
		return invoiceList;
	}

	public void setInvoiceList(List<InvoiceVO> invoiceList) {
		this.invoiceList = invoiceList;
	}

	public List<CreditNoteUtilizationVO> getCreditNoteList() {
		return creditNoteList;
	}

	public void setCreditNoteList(List<CreditNoteUtilizationVO> creditNoteList) {
		this.creditNoteList = creditNoteList;
	}

	public Integer getMaxFileSize() {
		return maxFileSize;
	}

	public void setMaxFileSize(Integer maxFileSize) {
		this.maxFileSize = maxFileSize;
	}

	public Integer getMaxFileCount() {
		return maxFileCount;
	}

	public void setMaxFileCount(Integer maxFileCount) {
		this.maxFileCount = maxFileCount;
	}
	
}
