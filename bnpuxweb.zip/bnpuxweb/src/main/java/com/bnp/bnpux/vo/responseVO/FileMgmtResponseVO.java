/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14 Mar 2017
 * 
 * Purpose:      File Management Response Object
 * 
 * Change History: 
 * Date                               Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 14 Mar 2017			             skbhaska					                	    Initial Version - FO 10.0 - S2005, S2007
 * 04 Apr 2017			             Divyashri S					                	FO10.0 - S2020 - Invoice Settlement List Details
 * 28-Mar-2018				        Bala Murugan Elangovan							    R11.0 - User Story - S2018X1803 - Rejected Valid Records introduction
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.responseVO;

import java.util.List;

import com.bnp.bnpux.common.vo.FileMgmtAttachmentListVO;
import com.bnp.bnpux.common.vo.FileMgmtInvSettleListVO;
import com.bnp.bnpux.common.vo.FileMgmtInvoiceListVO;
import com.bnp.bnpux.common.vo.FileMgmtListVO;
import com.bnp.bnpux.common.vo.FileMgmtPOListVO;
import com.bnp.bnpux.common.vo.FileMgmtPreAppSuppListVO;
import com.bnp.bnpux.common.vo.FileMgmtRejectedRecVO;
import com.bnp.bnpux.common.vo.FileMgmtRolloverStlVO;
import com.bnp.bnpux.common.vo.FileMgmtSummaryVO;
import com.bnp.bnpux.common.vo.StatusDetailsVO;

public class FileMgmtResponseVO {

	private String errorMsg;

	private List<FileMgmtSummaryVO> fileMgmtSummaryVOList;
	private List<FileMgmtListVO> fileMgmtListVO;
	private List<StatusDetailsVO> statusDet;
	private List<FileMgmtPOListVO> fileMgmtPOListVO;
	private List<FileMgmtInvoiceListVO> fileMgmtInvoiceListVO;
	private List<FileMgmtPreAppSuppListVO> fileMgmtPreAppSuppListVO;
	private List<FileMgmtAttachmentListVO> fileMgmtAttachmentListVO;
	private List<FileMgmtRejectedRecVO> fileMgmtRejectionListVO;
	private List<FileMgmtRejectedRecVO> fileMgmtValidRejectionListVO;
	private List<FileMgmtInvSettleListVO> fileMgmtInvSettleListVO;
	private List<FileMgmtRolloverStlVO> fileMgmtRolloverStlListVO;
	
	private String fileName;
	private byte[] data;
	
	
	

	public List<FileMgmtRejectedRecVO> getFileMgmtValidRejectionListVO() {
		return fileMgmtValidRejectionListVO;
	}

	public void setFileMgmtValidRejectionListVO(List<FileMgmtRejectedRecVO> fileMgmtValidRejectionListVO) {
		this.fileMgmtValidRejectionListVO = fileMgmtValidRejectionListVO;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

	public List<FileMgmtRolloverStlVO> getFileMgmtRolloverStlListVO() {
		return fileMgmtRolloverStlListVO;
	}

	public void setFileMgmtRolloverStlListVO(List<FileMgmtRolloverStlVO> fileMgmtRolloverStlListVO) {
		this.fileMgmtRolloverStlListVO = fileMgmtRolloverStlListVO;
	}
	
	public List<FileMgmtInvSettleListVO> getFileMgmtInvSettleListVO() {
		return fileMgmtInvSettleListVO;
	}

	public void setFileMgmtInvSettleListVO(List<FileMgmtInvSettleListVO> fileMgmtInvSettleListVO) {
		this.fileMgmtInvSettleListVO = fileMgmtInvSettleListVO;
	}

	public List<FileMgmtRejectedRecVO> getFileMgmtRejectionListVO() {
		return fileMgmtRejectionListVO;
	}

	public void setFileMgmtRejectionListVO(List<FileMgmtRejectedRecVO> fileMgmtRejectionListVO) {
		this.fileMgmtRejectionListVO = fileMgmtRejectionListVO;
	}
	
	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public List<FileMgmtSummaryVO> getFileMgmtSummaryVOList() {
		return fileMgmtSummaryVOList;
	}

	public void setFileMgmtSummaryVOList(List<FileMgmtSummaryVO> fileMgmtSummaryVOList) {
		this.fileMgmtSummaryVOList = fileMgmtSummaryVOList;
	}

	public List<FileMgmtListVO> getFileMgmtListVO() {
		return fileMgmtListVO;
	}

	public void setFileMgmtListVO(List<FileMgmtListVO> fileMgmtListVO) {
		this.fileMgmtListVO = fileMgmtListVO;
	}

	public List<StatusDetailsVO> getStatusDet() {
		return statusDet;
	}

	public void setStatusDet(List<StatusDetailsVO> statusDet) {
		this.statusDet = statusDet;
	}

	public List<FileMgmtPOListVO> getFileMgmtPOListVO() {
		return fileMgmtPOListVO;
	}

	public void setFileMgmtPOListVO(List<FileMgmtPOListVO> fileMgmtPOListVO) {
		this.fileMgmtPOListVO = fileMgmtPOListVO;
	}

	public List<FileMgmtInvoiceListVO> getFileMgmtInvoiceListVO() {
		return fileMgmtInvoiceListVO;
	}

	public void setFileMgmtInvoiceListVO(List<FileMgmtInvoiceListVO> fileMgmtInvoiceListVO) {
		this.fileMgmtInvoiceListVO = fileMgmtInvoiceListVO;
	}

	public List<FileMgmtPreAppSuppListVO> getFileMgmtPreAppSuppListVO() {
		return fileMgmtPreAppSuppListVO;
	}

	public void setFileMgmtPreAppSuppListVO(List<FileMgmtPreAppSuppListVO> fileMgmtPreAppSuppListVO) {
		this.fileMgmtPreAppSuppListVO = fileMgmtPreAppSuppListVO;
	}

	public List<FileMgmtAttachmentListVO> getFileMgmtAttachmentListVO() {
		return fileMgmtAttachmentListVO;
	}

	public void setFileMgmtAttachmentListVO(List<FileMgmtAttachmentListVO> fileMgmtAttachmentListVO) {
		this.fileMgmtAttachmentListVO = fileMgmtAttachmentListVO;
	}


	
	
	
	
}
