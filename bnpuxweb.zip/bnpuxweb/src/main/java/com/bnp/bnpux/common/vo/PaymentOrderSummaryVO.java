/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Payment Order Summary Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;
import java.util.Date;

public class PaymentOrderSummaryVO {
	
	private String buyerOrgId;
    private String buyerOrgName;
    private String sellerOrgId;
    private String sellerOrgName;
    private String currencyCode;
    private BigDecimal supplierBalanceAmt;
    private String recordCount;
    private String recordNo;   
    private String dueMonth;
	private Date maturityDate;
    private String bandRecordCount;
    private String leadOrgId;
    private String discRefNo;
    
    private int decimalPoint;
    
	public int getDecimalPoint() {
		return decimalPoint;
	}
	public void setDecimalPoint(int decimalPoint) {
		this.decimalPoint = decimalPoint;
	}
	public String getBuyerOrgId() {
		return buyerOrgId;
	}
	public void setBuyerOrgId(String buyerOrgId) {
		this.buyerOrgId = buyerOrgId;
	}
	public String getBuyerOrgName() {
		return buyerOrgName;
	}
	public void setBuyerOrgName(String buyerOrgName) {
		this.buyerOrgName = buyerOrgName;
	}
	public String getSellerOrgId() {
		return sellerOrgId;
	}
	public void setSellerOrgId(String sellerOrgId) {
		this.sellerOrgId = sellerOrgId;
	}
	public String getSellerOrgName() {
		return sellerOrgName;
	}
	public void setSellerOrgName(String sellerOrgName) {
		this.sellerOrgName = sellerOrgName;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public BigDecimal getSupplierBalanceAmt() {
		return supplierBalanceAmt;
	}
	public void setSupplierBalanceAmt(BigDecimal supplierBalanceAmt) {
		this.supplierBalanceAmt = supplierBalanceAmt;
	}
	public String getRecordCount() {
		return recordCount;
	}
	public void setRecordCount(String recordCount) {
		this.recordCount = recordCount;
	}
	public String getRecordNo() {
		return recordNo;
	}
	public void setRecordNo(String recordNo) {
		this.recordNo = recordNo;
	}
	public Date getMaturityDate() {
		return maturityDate;
	}
	public void setMaturityDate(Date maturityDate) {
		this.maturityDate = maturityDate;
	}
	public String getBandRecordCount() {
		return bandRecordCount;
	}
	public void setBandRecordCount(String bandRecordCount) {
		this.bandRecordCount = bandRecordCount;
	}
	public String getLeadOrgId() {
		return leadOrgId;
	}
	public void setLeadOrgId(String leadOrgId) {
		this.leadOrgId = leadOrgId;
	}
	public String getDiscRefNo() {
		return discRefNo;
	}
	public void setDiscRefNo(String discRefNo) {
		this.discRefNo = discRefNo;
	}
	public String getDueMonth() {
		return dueMonth;
	}
	public void setDueMonth(String dueMonth) {
		this.dueMonth = dueMonth;
	}
    
	/**
	 * Getter methods introduced to send the amounts as
	 * String to avoid amount > 16 digits getting truncated
	 * Added as part of defect Fix CSC-7835
	 */
	
	public String getSupplierBalanceAmtStr() {
		return (supplierBalanceAmt!=null)?supplierBalanceAmt.toPlainString():"";
	}

}
