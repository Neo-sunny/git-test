/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-JUL-2017
 * 
 * Purpose:      Limit Utilization Service Implementation
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27-JUL-2017				Divyashri Subramaniam						Limit Utilization Service Implementation
 * 09-Aug-2017				Bala Murugan Elangovan						Limit Utilization Service Implementation
************************************************************************************************************************************************************/
package com.bnp.bnpux.wrappers.serviceImpl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import com.bnp.bnpux.common.vo.LimitUtilDetailReportVO;
import com.bnp.bnpux.common.vo.LimitUtilReportBarChartVO;
import com.bnp.bnpux.dao.IDashboardLimitUtilReportDAO;
import com.bnp.bnpux.vo.requestVO.DashSettelmentDueRequestVO;
import com.bnp.bnpux.vo.requestVO.LimitUtilReportRequestVO;
import com.bnp.bnpux.vo.requestVO.LimitUtilReportResponseVO;
import com.bnp.bnpux.vo.responseVO.DashSettelmentDueResponseVO;
import com.bnp.bnpux.wrappers.service.ILimitUtilReportWrapperService;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.cache.ICacheService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.BNPCommonUtil;
import com.bnp.scm.services.common.vo.AbstractVO;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.bnp.scm.services.discounting.ILimitUtilReportService;
import com.bnp.scm.services.discounting.vo.LimitUtilReportTreeVO;
import com.bnp.scm.services.discounting.vo.LimitUtilReportVO;

@Component
@Scope("session")
public class LimitUtilReportWrapperServiceImpl implements ILimitUtilReportWrapperService{

	private static final Logger LOGGER = LoggerFactory.getLogger(LimitUtilReportWrapperServiceImpl.class);
	
	private LimitUtilReportVO selectedData = new LimitUtilReportVO();
	
	private List<NameValueVO> organisationList = null;
	
	private List<NameValueVO> branchList = new ArrayList<NameValueVO>();
	
	protected AbstractVO entitlementVO;
	
	@Autowired 
	private ILimitUtilReportService  limitUtilReportService;
	
	@Autowired 
	private ICacheService cacheService;
	
	@Autowired
	protected BNPCommonUtil bnpUtil;
	
	@Autowired
	private IDashboardLimitUtilReportDAO dashboardLimitUtilReportDAO;
	
	public List<NameValueVO> getBranchList() {
		return branchList;
	}

	public void setBranchList(List<NameValueVO> branchList) {
		this.branchList = branchList;
	}

	public List<NameValueVO> getOrganisationList() {
		return organisationList;
	}
	
	public void setOrganisationList(List<NameValueVO> organisationList) {
        this.organisationList = organisationList;
    }
	
	public void populateSupportBranchDetails(LimitUtilReportRequestVO limitUtilReportRequestVO) throws BNPApplicationException{
			this.branchList = dashboardLimitUtilReportDAO.getBranchDtls(limitUtilReportRequestVO);
	}

	private Map<String,String> getForexParam(String ccy,String flg){
	   	Map<String,String> paramMap = new HashMap<String, String>();
	   	paramMap.put(BNPConstants.ORG_ID,selectedData.getOrganizationId());
	   	paramMap.put(BNPConstants.INDICATIVECCY,ccy);
	   	paramMap.put(BNPConstants.ENTITYFLG,flg);
	   	return paramMap;
	}
	
	private String formatBigDecimal(BigDecimal value,int digits) {
		String str="-";
		if(value!=null){
			int decimalCount = digits;	
			DecimalFormat df = new DecimalFormat("#,###,###,##0.###"); 
			df.setMinimumFractionDigits(decimalCount); 
			df.setMaximumFractionDigits(decimalCount);
			str=df.format(value);
		}
		return str; 
	}
	
	@Override
	public LimitUtilReportResponseVO getDefaultFilerList(LimitUtilReportRequestVO limitUtilReportRequestVO){
		LimitUtilReportResponseVO limitUtilReportResponseVO = new LimitUtilReportResponseVO();
		try{
			populateSupportBranchDetails(limitUtilReportRequestVO);
			if(limitUtilReportRequestVO.getSelectedBranch() != null && limitUtilReportRequestVO.getSelectedBranch() != ""){
				if(limitUtilReportRequestVO.getUserType().equals("BA")){
					this.organisationList = dashboardLimitUtilReportDAO.getOrgDtlsBA(limitUtilReportRequestVO);
				}
				else{
					this.organisationList = dashboardLimitUtilReportDAO.getDashboardLimitOrgList(limitUtilReportRequestVO);
				}
				if(limitUtilReportRequestVO.getSelectedOrgId() != null && limitUtilReportRequestVO.getSelectedOrgId() != ""){
					limitUtilReportResponseVO.setCurrencyList((getCcyFilterList(limitUtilReportRequestVO)).getCurrencyList());
				}
			}
			limitUtilReportResponseVO.setBranchList(branchList);
			limitUtilReportResponseVO.setOrganisationList(organisationList);
		}
		catch(Exception exception){
			LOGGER.error("Error occured in method getDefaultFilerList() ", exception);
		}
		return limitUtilReportResponseVO;
	}
	
	@Override
	public LimitUtilReportResponseVO getOrgFilterList(LimitUtilReportRequestVO limitUtilReportRequestVO){
		LimitUtilReportResponseVO limitUtilReportResponseVO = new LimitUtilReportResponseVO();
		try{
			if(limitUtilReportRequestVO.getSelectedBranch() != null && limitUtilReportRequestVO.getSelectedBranch() != ""){
				if(limitUtilReportRequestVO.getUserType().equals("BA")){
					this.organisationList = dashboardLimitUtilReportDAO.getOrgDtlsBA(limitUtilReportRequestVO);
				}
				else{
					this.organisationList = dashboardLimitUtilReportDAO.getDashboardLimitOrgList(limitUtilReportRequestVO);
				}
			}
			limitUtilReportResponseVO.setOrganisationList(organisationList);
		}
		catch(Exception exception){
			LOGGER.error("Error occured in method getOrgFilterList() ", exception);
		}
		return limitUtilReportResponseVO;
	}
	
	@Override
	public LimitUtilReportResponseVO getCcyFilterList(LimitUtilReportRequestVO limitUtilReportRequestVO){
		LimitUtilReportResponseVO limitUtilReportResponseVO = new LimitUtilReportResponseVO();
		try{
			if(limitUtilReportRequestVO.getSelectedOrgId() != null && limitUtilReportRequestVO.getSelectedOrgId() != ""){
				limitUtilReportResponseVO.setCurrencyList(limitUtilReportService.getCurrencyList(limitUtilReportRequestVO.getSelectedOrgId()));
				if(CollectionUtils.isEmpty(limitUtilReportResponseVO.getCurrencyList())){
        			List<String> defaultList= new ArrayList<String>();
            		defaultList.add(BNPConstants.LIMIT_DEFAULT_CCY);
            		limitUtilReportResponseVO.setCurrencyList(defaultList);
        		}
        		else{
        			limitUtilReportResponseVO.getCurrencyList().add(BNPConstants.LIMIT_DEFAULT_CCY);
        		}
			}
		}
		catch(Exception exception){
			LOGGER.error("Error occured in method getCcyFilterList() ", exception);
		}
		return limitUtilReportResponseVO;
	}
	
	@Override
	public LimitUtilReportResponseVO getSearchedData(LimitUtilReportRequestVO limitUtilReportRequestVO){
		LimitUtilReportResponseVO limitUtilReportResponseVO = new LimitUtilReportResponseVO();
		LimitUtilReportVO dataVO = new LimitUtilReportVO();
		LimitUtilReportBarChartVO limitUtilReportBarChartVO = new LimitUtilReportBarChartVO();
		int errorCode=0;
		String defaultCcy;
		try{
			dataVO.setId(limitUtilReportRequestVO.getUserId());
	    	dataVO.setCurrentUserId(limitUtilReportRequestVO.getUserId());
	       	dataVO.setUserType(limitUtilReportRequestVO.getUserType());
	       	dataVO.setEntityDefaultCcy(BNPConstants.LIMIT_DEFAULT_CCY);
	       	dataVO.setCpDefaultCcy(BNPConstants.LIMIT_DEFAULT_CCY);
	       	dataVO.setOrganizationId(limitUtilReportRequestVO.getSelectedOrgId());
	       	dataVO.setBranchdtl(limitUtilReportRequestVO.getSelectedBranch());
	       	List<LimitUtilReportVO>  tempList= limitUtilReportService.getOrgDetailsForSummary(dataVO);
	       	if(tempList != null && !tempList.isEmpty()){
	       		LimitUtilReportVO tempVO = tempList.get(0);
	       		if(tempVO.getEntityBlokLimit() != null){
	       			tempVO.setEntityAvblLimit(tempVO.getEntityAvblLimit().subtract(tempVO.getEntityBlokLimit()));
	       		}
	       		selectedData = tempVO;
	       		defaultCcy = tempVO.getCcy();
	       		if((defaultCcy == null || defaultCcy.equals("")) || BNPConstants.NO.equals(limitUtilReportService.checkForexRate(getForexParam(defaultCcy,BNPConstants.YES)))){
	            	errorCode = ErrorConstants.CURRENCY_CONVERSION_RATE_VALIDATION;
	    			limitUtilReportResponseVO.setErrCode(errorCode);
	    			limitUtilReportResponseVO.setErrMessage(BNPConstants.FX_RATE_ERROR_CCY);
	    		}
	       		else{
		       		tempVO.setEntityCcy(tempVO.getCcy());
		       		int entityDecimal = cacheService.getCurrencyDecimal(tempVO.getCcy());
		       		tempVO.setEntityDecimals(String.valueOf(entityDecimal));     
		       		tempVO.setEffectiveEntityAvlAmtfmt(formatBigDecimal(tempVO.getEffectiveEntityAvlAmt(),entityDecimal));
		       		tempVO.setEffectiveGroupAvlAmtfmt(formatBigDecimal(tempVO.getEffectiveGroupAvlAmt(),entityDecimal));
		       		tempVO.setEffectiveTPAvlAmtfmt(formatBigDecimal(tempVO.getEffectiveTPAvlAmt(),entityDecimal));
		       		setOrgTPAccessFlag(tempVO);
		       		limitUtilReportBarChartVO.setLimitUtilReportVO(tempVO);
		       		calculatePercentage(limitUtilReportBarChartVO);
		       		limitUtilReportResponseVO.setLimitUtilReportBarChartVO(limitUtilReportBarChartVO);
	       		}
	       	}
		}
		catch(Exception exception){
			LOGGER.error("Error occured in method getSearchedData() ", exception);
		}
		return limitUtilReportResponseVO;
	}
	
	@Override
	public LimitUtilReportResponseVO getSearchedDataOnCcyChange(LimitUtilReportRequestVO limitUtilReportRequestVO){
		LimitUtilReportResponseVO limitUtilReportResponseVO = new LimitUtilReportResponseVO();
		LimitUtilReportVO dataVO = new LimitUtilReportVO();
		LimitUtilReportVO resultVO = new LimitUtilReportVO();
		LimitUtilReportBarChartVO barChartVO = new LimitUtilReportBarChartVO();
        try {
        	int errorCode=0;
        	selectedData.setConverstionMsg(null);
        	String ccySelected = limitUtilReportRequestVO.getSelectedCcy();
            if(BNPConstants.LIMIT_DEFAULT_CCY.equals(ccySelected)){
            	ccySelected = this.selectedData.getCcy();
            	
            }
            if((ccySelected == null || ccySelected.equals("")) || BNPConstants.NO.equals(limitUtilReportService.checkForexRate(getForexParam(ccySelected,BNPConstants.YES)))){
            	errorCode = ErrorConstants.CURRENCY_CONVERSION_RATE_VALIDATION;
    			limitUtilReportResponseVO.setErrCode(errorCode);
    			limitUtilReportResponseVO.setErrMessage(BNPConstants.FX_RATE_ERROR_CCY);
    		}
            else{
            	dataVO.setId(limitUtilReportRequestVO.getUserId());
    	    	dataVO.setCurrentUserId(limitUtilReportRequestVO.getUserId());
    	       	dataVO.setUserType(limitUtilReportRequestVO.getUserType());
    	       	dataVO.setEntityDefaultCcy(limitUtilReportRequestVO.getSelectedCcy());
    	       	dataVO.setOrganizationId(limitUtilReportRequestVO.getSelectedOrgId());
    	       	dataVO.setBranchdtl(limitUtilReportRequestVO.getSelectedBranch());
        		List<LimitUtilReportVO> tempSummaryList = limitUtilReportService.getOrgDetailsForSummary(dataVO);
        		if(tempSummaryList.size()==1){
        			resultVO = tempSummaryList.get(0); 
        			if(resultVO.getEntityBlokLimit() != null){
        				resultVO.setEntityAvblLimit(resultVO.getEntityAvblLimit().subtract(resultVO.getEntityBlokLimit()));
    	       		}
        			resultVO.setEntityCcy(ccySelected);
            		int entityDecimal = cacheService.getCurrencyDecimal(ccySelected);
            		resultVO.setEntityDecimals(String.valueOf(entityDecimal));            		
            		resultVO.setEffectiveEntityAvlAmtfmt(formatBigDecimal(resultVO.getEffectiveEntityAvlAmt(),entityDecimal));
            		resultVO.setEffectiveGroupAvlAmtfmt(formatBigDecimal(resultVO.getEffectiveGroupAvlAmt(),entityDecimal));
            		resultVO.setEffectiveTPAvlAmtfmt(formatBigDecimal(resultVO.getEffectiveTPAvlAmt(),entityDecimal));
            		setOrgTPAccessFlag(resultVO);
            		barChartVO.setLimitUtilReportVO(resultVO);
            		calculatePercentage(barChartVO);
            		limitUtilReportResponseVO.setLimitUtilReportBarChartVO(barChartVO);
        		}
        		else{
        			limitUtilReportResponseVO.setErrCode(ErrorConstants.ACCESSLOG_NORECORDFOUND);
        			limitUtilReportResponseVO.setErrMessage(BNPConstants.NODATA_AVAILABLE);
        		}
            }
    	if(errorCode!=0 && errorCode!=ErrorConstants.CURRENCY_CONVERSION_RATE_VALIDATION ){
    		throw new BNPApplicationException(errorCode);
    	}
        } catch (BNPApplicationException ex) {
        	LOGGER.debug("Exception during ccy change");
        	limitUtilReportResponseVO.setErrCode(ex.getErrorCode());
        }
        return limitUtilReportResponseVO;
    }
	
	@Override
	public LimitUtilReportResponseVO getLimitDetails(LimitUtilReportRequestVO limitUtilReportRequestVO) {
		LimitUtilReportResponseVO limitUtilReportResponseVO = new LimitUtilReportResponseVO();
		List<LimitUtilReportTreeVO> limitUtilReportTreeVOs = null;
		List<LimitUtilDetailReportVO> limitUtilDetailReportVOs = new ArrayList<LimitUtilDetailReportVO>();
		try{
			Map<String, String> paramMap = new HashMap<String, String>();
			String selectedCcy = limitUtilReportRequestVO.getSelectedCcy();
			if(BNPConstants.LIMIT_DEFAULT_CCY.equals(limitUtilReportRequestVO.getSelectedCcy())){
				selectedCcy = this.selectedData.getCcy();
	        }
			paramMap.put(BNPConstants.INDICATIVECCY, selectedCcy);
			paramMap.put(BNPConstants.ENTITY_ORG, limitUtilReportRequestVO.getSelectedOrgId());
			if(limitUtilReportRequestVO.getLimitDetailKey() != null && limitUtilReportRequestVO.getLimitDetailKey().equals("Group")){
				limitUtilReportTreeVOs = dashboardLimitUtilReportDAO.getGroupLimitDetails(paramMap);
			}
			else if(limitUtilReportRequestVO.getLimitDetailKey() != null && limitUtilReportRequestVO.getLimitDetailKey().equals("TP")){
				limitUtilReportTreeVOs = dashboardLimitUtilReportDAO.getTPLimitDetails(paramMap);
			}
			for(LimitUtilReportTreeVO treeVO : limitUtilReportTreeVOs) {
				LimitUtilDetailReportVO reportVO = calculateLimitDtlPtg(treeVO);
				Map<String,String> paramMapForGrp = new HashMap<String, String>();
				paramMapForGrp.put(BNPConstants.USER_ID_KEY, limitUtilReportRequestVO.getUserId());
				paramMapForGrp.put(BNPConstants.USER_TYPE_KEY, limitUtilReportRequestVO.getUserType());
				paramMapForGrp.put(BNPConstants.GROUP_ID, treeVO.getOrgId());
				if(limitUtilReportRequestVO.getLimitDetailKey() != null && limitUtilReportRequestVO.getLimitDetailKey().equals("Group")){
					paramMapForGrp.put(BNPConstants.GROUP_TYPE,"ENTITY");
					reportVO.setOrgIdWithShortName(limitUtilReportService.getGroupDetails(paramMapForGrp));
				}
				else if(treeVO.getType() != null && treeVO.getType().equals("Customers")){
					paramMapForGrp.put(BNPConstants.GROUP_TYPE,"TP");
					reportVO.setOrgIdWithShortName(limitUtilReportService.getGroupDetails(paramMapForGrp));
				}
				limitUtilDetailReportVOs.add(reportVO);
			}
			limitUtilReportResponseVO.setLimitUtilDetailReportVOs(limitUtilDetailReportVOs);
		} catch (BNPApplicationException ex) {
        	LOGGER.debug("Exception in getLimitDetails()" + ex);
        	limitUtilReportResponseVO.setErrMessage(ex.errorMessage);
        }
		return limitUtilReportResponseVO;
	}
	
	public void calculatePercentage(LimitUtilReportBarChartVO chartVO){
		BigDecimal totalAmount;
		BigDecimal entityUtilizedLimit;
		BigDecimal entityBlokLimit;
		BigDecimal effectiveAvlAmt;
		BigDecimal entityAvblLimit;
		BigDecimal entityUtilizedLimitPtg;
		BigDecimal entityBlokLimitPtg;
		BigDecimal effectiveAvlAmtPtg;
		BigDecimal entityAvblLimitPtg;
		if(chartVO != null && chartVO.getLimitUtilReportVO() != null){
			LimitUtilReportVO dataVO = chartVO.getLimitUtilReportVO();
			totalAmount = dataVO.getEntityGrantedLimit();
			if(dataVO.getEntityUtilizedLimit().compareTo(BigDecimal.ZERO) <= 0){
				entityUtilizedLimit = BigDecimal.ZERO;
				chartVO.setShowEntityUtilizedLimitPtg(false);
			}else{
				entityUtilizedLimit = dataVO.getEntityUtilizedLimit();
				chartVO.setShowEntityUtilizedLimitPtg(true);
			}
			if(dataVO.getEntityBlokLimit().compareTo(BigDecimal.ZERO) <= 0){
				entityBlokLimit = BigDecimal.ZERO;
				chartVO.setShowEntityBlokLimitPtg(false);
			}else{
				entityBlokLimit = dataVO.getEntityBlokLimit();
				chartVO.setShowEntityBlokLimitPtg(true);
			}
			if(dataVO.getEffectiveAvlAmt().compareTo(BigDecimal.ZERO) <= 0){
				effectiveAvlAmt = BigDecimal.ZERO;
				chartVO.setShowEffectiveAvlAmtPtg(false);
			}else{
				effectiveAvlAmt = dataVO.getEffectiveAvlAmt();
				chartVO.setShowEffectiveAvlAmtPtg(true);
			}
			if(dataVO.getEntityAvblLimit().compareTo(BigDecimal.ZERO) <= 0){
				entityAvblLimit = BigDecimal.ZERO;
				chartVO.setShowEntityAvblLimitPtg(false);
			}else{
				entityAvblLimit = dataVO.getEntityAvblLimit();
				chartVO.setShowEntityAvblLimitPtg(true);
			}
			if(totalAmount.compareTo(BigDecimal.ZERO) == 0){
				chartVO.setTotalAmount(new BigDecimal(0));
				chartVO.setEntityUtilizedLimitPtg(new BigDecimal(0));
	            chartVO.setEntityBlokLimitPtg(new BigDecimal(0));
	            chartVO.setEntityAvblLimitPtg(new BigDecimal(0));
	            chartVO.setEffectiveAvlAmtPtg(new BigDecimal(0));
			}
			else{
				chartVO.setTotalAmount(totalAmount);
				
				entityUtilizedLimitPtg = entityUtilizedLimit.multiply(new BigDecimal(100)).divide(totalAmount,0,RoundingMode.HALF_EVEN);
				if(entityUtilizedLimitPtg.compareTo(BigDecimal.ONE) <= 0 && chartVO.isShowEntityUtilizedLimitPtg()){
					entityUtilizedLimitPtg = new BigDecimal(2);
				}
				chartVO.setEntityUtilizedLimitPtg(entityUtilizedLimitPtg);
	            
				entityBlokLimitPtg = entityBlokLimit.multiply(new BigDecimal(100)).divide(totalAmount,0,RoundingMode.HALF_EVEN);
				if(entityBlokLimitPtg.compareTo(BigDecimal.ONE) <= 0 && chartVO.isShowEntityBlokLimitPtg()){
					entityBlokLimitPtg = new BigDecimal(2);
				}
				chartVO.setEntityBlokLimitPtg(entityBlokLimitPtg);
				
	            if(chartVO.getEntityUtilizedLimitPtg().add(chartVO.getEntityBlokLimitPtg()).compareTo(new BigDecimal(100)) < 0 ){
	            	chartVO.setEntityAvblLimitPtg(new BigDecimal(100).subtract(chartVO.getEntityUtilizedLimitPtg()).subtract(chartVO.getEntityBlokLimitPtg()));
	            }
	            else if(chartVO.isShowEntityAvblLimitPtg()){
	            	 chartVO.setEntityAvblLimitPtg(new BigDecimal(5));
	            }
	            else{
	            	chartVO.setEntityAvblLimitPtg(BigDecimal.ZERO);
	            }
	            
	            effectiveAvlAmtPtg = effectiveAvlAmt.multiply(new BigDecimal(100)).divide(totalAmount,0,RoundingMode.HALF_EVEN);
	            if(effectiveAvlAmtPtg.compareTo(BigDecimal.ZERO) == 0 && chartVO.isShowEffectiveAvlAmtPtg()){
	            	effectiveAvlAmtPtg = new BigDecimal(2);
				}
	            chartVO.setEffectiveAvlAmtPtg(effectiveAvlAmtPtg);
	            
	            reAssignPtgMaxVal(chartVO);
			}
		}
	}
	
	public LimitUtilDetailReportVO calculateLimitDtlPtg(LimitUtilReportTreeVO treeVO){
		LimitUtilDetailReportVO limitUtilDetailReportVO = new LimitUtilDetailReportVO();
		limitUtilDetailReportVO.setLimitUtilReportTreeVO(treeVO);
		BigDecimal totalAmount;
		BigDecimal availableAmount = treeVO.getAvailableAmount();
		BigDecimal blockedAmount = treeVO.getBlockedAmount();
		BigDecimal utilizedAmount = treeVO.getUtilizedAmount();
		if(availableAmount.compareTo(BigDecimal.ZERO) < 0){
			availableAmount = BigDecimal.ZERO;
		}
		if(blockedAmount.compareTo(BigDecimal.ZERO) < 0){
			blockedAmount = BigDecimal.ZERO;
		}
		if(utilizedAmount.compareTo(BigDecimal.ZERO) < 0){
			utilizedAmount = BigDecimal.ZERO;
		}
		if(treeVO != null){
			totalAmount = availableAmount.add(blockedAmount.add(utilizedAmount));
			if(totalAmount.compareTo(BigDecimal.ZERO) == 0){
				limitUtilDetailReportVO.setBlockedAmountPtg(new BigDecimal(0));
				limitUtilDetailReportVO.setUtilizedAmountPtg(new BigDecimal(0));
				limitUtilDetailReportVO.setAvailableAmountPtg(new BigDecimal(0));
			}
			else{
				limitUtilDetailReportVO.setBlockedAmountPtg(blockedAmount.multiply(new BigDecimal(100)).divide(totalAmount,0,RoundingMode.HALF_EVEN));
				limitUtilDetailReportVO.setUtilizedAmountPtg(utilizedAmount.multiply(new BigDecimal(100)).divide(totalAmount,0,RoundingMode.HALF_EVEN));
				limitUtilDetailReportVO.setAvailableAmountPtg(new BigDecimal(100).subtract(limitUtilDetailReportVO.getBlockedAmountPtg()).subtract(limitUtilDetailReportVO.getUtilizedAmountPtg()));
			}
		}
		return limitUtilDetailReportVO;
	}
	
	public void reAssignPtgMaxVal(LimitUtilReportBarChartVO chartVO){
		BigDecimal totalPtg = chartVO.getEntityUtilizedLimitPtg().add(chartVO.getEntityBlokLimitPtg().add(chartVO.getEntityAvblLimitPtg()));
		if(totalPtg.compareTo(new BigDecimal(100)) > 0){
			BigDecimal ptgDiff = totalPtg.subtract(new BigDecimal(100));
			int isLargeUtil = chartVO.getEntityUtilizedLimitPtg().compareTo(chartVO.getEntityBlokLimitPtg());
			int isLargeAvbl;
			if(isLargeUtil > 0){
				isLargeAvbl = chartVO.getEntityUtilizedLimitPtg().compareTo(chartVO.getEntityAvblLimitPtg());
				if(isLargeAvbl > 0){
					chartVO.setEntityUtilizedLimitPtg(chartVO.getEntityUtilizedLimitPtg().subtract(ptgDiff));
				}
				else{
					chartVO.setEntityAvblLimitPtg(chartVO.getEntityAvblLimitPtg().subtract(ptgDiff));
				}
			}
			else{
				isLargeAvbl = chartVO.getEntityBlokLimitPtg().compareTo(chartVO.getEntityAvblLimitPtg());
				if(isLargeAvbl > 0){
					chartVO.setEntityBlokLimitPtg(chartVO.getEntityBlokLimitPtg().subtract(ptgDiff));
				}
				else{
					chartVO.setEntityAvblLimitPtg(chartVO.getEntityAvblLimitPtg().subtract(ptgDiff));
				}
			}
		}
		if(chartVO.getEffectiveAvlAmtPtg().compareTo(chartVO.getEntityAvblLimitPtg()) > 0){
			chartVO.setEffectiveAvlAmtPtg(chartVO.getEntityAvblLimitPtg());
		}
		if(chartVO.getEffectiveAvlAmtPtg().compareTo(chartVO.getEntityAvblLimitPtg()) == 0 && 
				chartVO.getEffectiveAvlAmtPtg().compareTo(BigDecimal.ONE) > 0 &&
				chartVO.getLimitUtilReportVO().getEffectiveAvlAmt().compareTo(chartVO.getLimitUtilReportVO().getEntityAvblLimit()) < 0){
			if(chartVO.getEffectiveAvlAmtPtg().compareTo(new BigDecimal(5)) >= 0){
				chartVO.setEffectiveAvlAmtPtg(chartVO.getEntityAvblLimitPtg().subtract(new BigDecimal(2)));
			}
			else{
				chartVO.setEffectiveAvlAmtPtg(chartVO.getEntityAvblLimitPtg().divide(new BigDecimal(2),0,RoundingMode.HALF_EVEN));
			}
		}
	}
	
	public void setOrgTPAccessFlag(LimitUtilReportVO tempVO){
		boolean flag = false;
		String showTPdtls = null;
		try{
			showTPdtls = limitUtilReportService.getOrgUserTPAccess(tempVO.getOrganizationId());
			if(showTPdtls!=null && showTPdtls.trim().equalsIgnoreCase(BNPConstants.YES)){
				flag = true;
			}
			tempVO.setOrgUserTPAccess(flag);
		}
		catch (BNPApplicationException ex) {
        	LOGGER.debug("Exception in setOrgTPAccessFlag()" + ex);
        }
	}

	@Override
	public DashSettelmentDueResponseVO getSettlementSearchDetails(DashSettelmentDueRequestVO dashSettelmentDueRequestVO) {
		DashSettelmentDueResponseVO dashSettelmentDueResponseVO = new DashSettelmentDueResponseVO();
		try{
			dashboardLimitUtilReportDAO.getSettlementDueDetails(dashSettelmentDueRequestVO);
			dashSettelmentDueResponseVO.setDashSettlementDueVOList(dashSettelmentDueRequestVO.getDashSettlementDueVOList());
		}
		catch(Exception exception){
			LOGGER.error(exception.getMessage());
			dashSettelmentDueResponseVO.setErrorMessage(exception.getMessage());
		}
		return dashSettelmentDueResponseVO;
	}
}