package com.bnp.bnpux.service;

import java.util.List;

import com.bnp.bnpux.vo.requestVO.CreditNoteInqRequestVO;
import com.bnp.bnpux.vo.requestVO.SettlmntDueReminderRptRequestVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;
import com.bnp.bnpux.vo.responseVO.SettlmntDueReminderRptResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface ISettlmntDueReminderRptService {
	
	/**
	 * This method is for getting Settlement Due Reminder Report list
	 * 
	 * @param SettlmntDueReminderRptRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	SettlmntDueReminderRptResponseVO getSettlmntReportList(SettlmntDueReminderRptRequestVO settlmntDueReminderRptRequestVO)	throws BNPApplicationException;
	
	/**
	 * This method is for getting report chart axis 
	 * 
	 * @param requestVo
	 * @return
	 * @throws BNPApplicationException
	 */
	List<ReportChartResponseVO> getReportChartAxis (SettlmntDueReminderRptRequestVO requestVo)throws BNPApplicationException;
	
}
