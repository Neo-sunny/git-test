/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     Holiday Service Implementation
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                Oracle Financial Services Software Ltd            Initial Version 
 * 08 Mar 2017                skbhaska                                    		FO 10.0 - S30 - Holiday Calendar
 *****************************************************************************************************************************************************************/
package com.bnp.bnpux.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.common.vo.HolidayVO;
import com.bnp.bnpux.dao.IHolidayDAO;
import com.bnp.bnpux.service.IHolidayService;
import com.bnp.bnpux.vo.requestVO.HolidayRequestVO;
import com.bnp.bnpux.vo.responseVO.HolidayResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@Component
public class HolidayServiceImpl implements IHolidayService {

	@Autowired
	private IHolidayDAO holidayDao;
	
	
	/**
	 * This method is for getting the holiday list 
	 * 
	 * @param holidayRequestVO
	 * @return HolidayVO List
	 * @throws BNPApplicationException
	 * @see com.bnp.bnpux.service.IHolidayService#getHolidayList(com.bnp.bnpux.vo.requestVO.HolidayRequestVO)
	 * @Description get Holiday List
	 */
	@Override
	public List<HolidayVO> getHolidayList(HolidayRequestVO holidayRequestVO) throws BNPApplicationException {
		return holidayDao.getHolidayList(holidayRequestVO);
	}
	
	/**
	 * This method is used to get the list of holiday based on CYY List, Year, Org ID, Branch (For BA Users) 
	 * @param holidayRequestVO
	 * @return HolidayResponseVO
	 * @throws BNPApplicationException
	 */
	@Override
	public List<HolidayVO> getHolidayListForCalendar(HolidayRequestVO holidayRequestVO) throws BNPApplicationException {
		return holidayDao.getHolidayListForCalendar(holidayRequestVO);
	}
	
}
