/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14 Feb 2017
 * 
 * Purpose:     PaymentOrderPopupRequestVO - R10.0 S001
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 20 Feb 2017       Oracle Financial Services Software Ltd                  Initial Version Created for S001 - po POP up
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.requestVO;

import java.util.List;

import com.bnp.bnpux.common.vo.AuditDetailsUxVO;
import com.bnp.bnpux.common.vo.CreditNotesDetailsUxVO;
import com.bnp.bnpux.common.vo.InvoiceDetailsUxVO;
import com.bnp.bnpux.common.vo.OrganizationVO;
import com.bnp.bnpux.common.vo.PaymentOrderDetailVO;

public class PaymentOrderPopupRequestVO {
	
	private String userId;
	
	private String pymtId;
	
	private String buyerOrgId;
	
	private String sellerOrgId;
	
	private String exportType;
		
	private OrganizationVO buyerOrgVO;
	
	private OrganizationVO sellerOrgVO;

	private List<PaymentOrderDetailVO> paymentOrderDetailVOs;
	
	private List<InvoiceDetailsUxVO> invoiceDetailsUxVOs;
	
	private List<CreditNotesDetailsUxVO> creditNotesDetailsUxVOs;
	
	private List<AuditDetailsUxVO> auditDetailsUxVOs;
	
	private String errorFlag;
	
	public String getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPymtId() {
		return pymtId;
	}

	public void setPymtId(String pymtId) {
		this.pymtId = pymtId;
	}

	public String getBuyerOrgId() {
		return buyerOrgId;
	}

	public void setBuyerOrgId(String buyerOrgId) {
		this.buyerOrgId = buyerOrgId;
	}

	public String getSellerOrgId() {
		return sellerOrgId;
	}

	public void setSellerOrgId(String sellerOrgId) {
		this.sellerOrgId = sellerOrgId;
	}

	public List<PaymentOrderDetailVO> getPaymentOrderDetailVOs() {
		return paymentOrderDetailVOs;
	}

	public void setPaymentOrderDetailVOs(List<PaymentOrderDetailVO> paymentOrderDetailVOs) {
		this.paymentOrderDetailVOs = paymentOrderDetailVOs;
	}

	public List<InvoiceDetailsUxVO> getInvoiceDetailsUxVOs() {
		return invoiceDetailsUxVOs;
	}

	public void setInvoiceDetailsUxVOs(List<InvoiceDetailsUxVO> invoiceDetailsUxVOs) {
		this.invoiceDetailsUxVOs = invoiceDetailsUxVOs;
	}

	public List<CreditNotesDetailsUxVO> getCreditNotesDetailsUxVOs() {
		return creditNotesDetailsUxVOs;
	}

	public void setCreditNotesDetailsUxVOs(List<CreditNotesDetailsUxVO> creditNotesDetailsUxVOs) {
		this.creditNotesDetailsUxVOs = creditNotesDetailsUxVOs;
	}

	public List<AuditDetailsUxVO> getAuditDetailsUxVOs() {
		return auditDetailsUxVOs;
	}

	public void setAuditDetailsUxVOs(List<AuditDetailsUxVO> auditDetailsUxVOs) {
		this.auditDetailsUxVOs = auditDetailsUxVOs;
	}

	public String getExportType() {
		return exportType;
	}

	public void setExportType(String exportType) {
		this.exportType = exportType;
	}

	public OrganizationVO getBuyerOrgVO() {
		return buyerOrgVO;
	}

	public void setBuyerOrgVO(OrganizationVO buyerOrgVO) {
		this.buyerOrgVO = buyerOrgVO;
	}

	public OrganizationVO getSellerOrgVO() {
		return sellerOrgVO;
	}

	public void setSellerOrgVO(OrganizationVO sellerOrgVO) {
		this.sellerOrgVO = sellerOrgVO;
	}

}
