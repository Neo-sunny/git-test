/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   13 July 2017
 * 
 * Purpose:      Credit Note Inquiry Report Service Implementation
 * 
 * Change History:
 *  
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 13 July 2017       Jaimal Singh, Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.constants;

public interface SettlmntDueReminderConstants {
	
    public static final String VIEW_TYPE = "viewType";
    
    public static final String SETTLEMENT_DUE_RMDR_SUMMARY = "SUMMARY";
	
	public static final String SETTLEMENT_DUE_RMDR_LIST = "settlmntDueReminderList";
	
	public static final String SETTLEMENT_DUE_RMDR_LIST_DETAILS = "settlementDueReminderListDetails";

}
