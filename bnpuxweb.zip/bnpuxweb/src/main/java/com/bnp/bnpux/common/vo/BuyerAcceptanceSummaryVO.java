/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   29 Mar 2017	
 * 
 * Purpose:       Buyer Acceptance screen
 * 
 * Change History: 
 * Date                       Author                                    Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 29 Mar 2017			      kmanimar					                Initial Version - FO 10.0 - S2098
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.util.Date;

public class BuyerAcceptanceSummaryVO {

	private String recordCount;
	private String recordNo;
	private String bandRecordCount;
	private String buyerOrdId;
	private String supplierOrgId;
	private String buyerOrgName;
	private String sellerOrgName;
	private String ccyCode;
	private String docStatus;
	private Date dueDate;
	private String lotNumber;
	private String greenbandLabel1;
	private String greenbandLabel2;
	
	public String getGreenbandLabel1() {
		return greenbandLabel1;
	}
	public void setGreenbandLabel1(String greenbandLabel1) {
		this.greenbandLabel1 = greenbandLabel1;
	}
	public String getGreenbandLabel2() {
		return greenbandLabel2;
	}
	public void setGreenbandLabel2(String greenbandLabel2) {
		this.greenbandLabel2 = greenbandLabel2;
	}
	public String getLotNumber() {
		return lotNumber;
	}
	public void setLotNumber(String lotNumber) {
		this.lotNumber = lotNumber;
	}
	public String getDocStatus() {
		return docStatus;
	}
	public void setDocStatus(String docStatus) {
		this.docStatus = docStatus;
	}
	public String getCcyCode() {
		return ccyCode;
	}
	public void setCcyCode(String ccyCode) {
		this.ccyCode = ccyCode;
	}
	public String getRecordCount() {
		return recordCount;
	}
	public void setRecordCount(String recordCount) {
		this.recordCount = recordCount;
	}
	public String getRecordNo() {
		return recordNo;
	}
	public void setRecordNo(String recordNo) {
		this.recordNo = recordNo;
	}
	public String getBandRecordCount() {
		return bandRecordCount;
	}
	public void setBandRecordCount(String bandRecordCount) {
		this.bandRecordCount = bandRecordCount;
	}
	public String getBuyerOrdId() {
		return buyerOrdId;
	}
	public void setBuyerOrdId(String buyerOrdId) {
		this.buyerOrdId = buyerOrdId;
	}
	public String getSupplierOrgId() {
		return supplierOrgId;
	}
	public void setSupplierOrgId(String supplierOrgId) {
		this.supplierOrgId = supplierOrgId;
	}
	public String getBuyerOrgName() {
		return buyerOrgName;
	}
	public void setBuyerOrgName(String buyerOrgName) {
		this.buyerOrgName = buyerOrgName;
	}
	public String getSellerOrgName() {
		return sellerOrgName;
	}
	public void setSellerOrgName(String sellerOrgName) {
		this.sellerOrgName = sellerOrgName;
	}
	public Date getDueDate() {
		return dueDate;
	}
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}
	
}
