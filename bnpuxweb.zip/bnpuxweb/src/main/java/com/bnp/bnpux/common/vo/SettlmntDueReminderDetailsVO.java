package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.bnp.bnpux.vo.responseVO.SettlmntDueReminderRptResponseVO;

public class SettlmntDueReminderDetailsVO {

	private String errorMessage;

	private String ccyCode;

	private Date discDate;

	private Date dueDate;

	private Date adjDueDate;
	
	private Date pymtDueDate;

	private Date adjExtndDueDate;

	private Integer discTenure;

	private String rateChargeType;

	private String discRefNo;

	private BigDecimal financeAmt;

	private BigDecimal avlbleAmt;

	private BigDecimal rateApplied;

	private Integer revisedTenure;

	private BigDecimal indRevisedRate;

	private BigDecimal revisedDiscAmt;

	private String pymtRefNo;

	private BigDecimal pymtAmt;

	private BigDecimal outstandStlmtAmt;
	
	private int decimalPoint;

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * @return the ccyCode
	 */
	public String getCcyCode() {
		return ccyCode;
	}

	/**
	 * @param ccyCode the ccyCode to set
	 */
	public void setCcyCode(String ccyCode) {
		this.ccyCode = ccyCode;
	}

	/**
	 * @return the pymtDueDate
	 */
	public Date getPymtDueDate() {
		return pymtDueDate;
	}

	/**
	 * @param pymtDueDate the pymtDueDate to set
	 */
	public void setPymtDueDate(Date pymtDueDate) {
		this.pymtDueDate = pymtDueDate;
	}

	/**
	 * @return the adjExtndDueDate
	 */
	public Date getAdjExtndDueDate() {
		return adjExtndDueDate;
	}

	/**
	 * @param adjExtndDueDate the adjExtndDueDate to set
	 */
	public void setAdjExtndDueDate(Date adjExtndDueDate) {
		this.adjExtndDueDate = adjExtndDueDate;
	}

	/**
	 * @return the pymtRefNo
	 */
	public String getPymtRefNo() {
		return pymtRefNo;
	}

	/**
	 * @param pymtRefNo the pymtRefNo to set
	 */
	public void setPymtRefNo(String pymtRefNo) {
		this.pymtRefNo = pymtRefNo;
	}

	/**
	 * @return the pymtAmt
	 */
	public BigDecimal getPymtAmt() {
		return pymtAmt;
	}

	/**
	 * @param pymtAmt the pymtAmt to set
	 */
	public void setPymtAmt(BigDecimal pymtAmt) {
		this.pymtAmt = pymtAmt;
	}

	/**
	 * @return the outstandStlmtAmt
	 */
	public BigDecimal getOutstandStlmtAmt() {
		return outstandStlmtAmt;
	}

	/**
	 * @param outstandStlmtAmt the outstandStlmtAmt to set
	 */
	public void setOutstandStlmtAmt(BigDecimal outstandStlmtAmt) {
		this.outstandStlmtAmt = outstandStlmtAmt;
	}


	/**
	 * @return the discDate
	 */
	public Date getDiscDate() {
		return discDate;
	}

	/**
	 * @param discDate the discDate to set
	 */
	public void setDiscDate(Date discDate) {
		this.discDate = discDate;
	}

	/**
	 * @return the dueDate
	 */
	public Date getDueDate() {
		return dueDate;
	}

	/**
	 * @param dueDate the dueDate to set
	 */
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	/**
	 * @return the adjDueDate
	 */
	public Date getAdjDueDate() {
		return adjDueDate;
	}

	/**
	 * @param adjDueDate the adjDueDate to set
	 */
	public void setAdjDueDate(Date adjDueDate) {
		this.adjDueDate = adjDueDate;
	}

	/**
	 * @return the discTenure
	 */
	public Integer getDiscTenure() {
		return discTenure;
	}

	/**
	 * @param discTenure the discTenure to set
	 */
	public void setDiscTenure(Integer discTenure) {
		this.discTenure = discTenure;
	}

	/**
	 * @return the rateChargeType
	 */
	public String getRateChargeType() {
		return rateChargeType;
	}

	/**
	 * @param rateChargeType the rateChargeType to set
	 */
	public void setRateChargeType(String rateChargeType) {
		this.rateChargeType = rateChargeType;
	}

	/**
	 * @return the discRefNo
	 */
	public String getDiscRefNo() {
		return discRefNo;
	}

	/**
	 * @param discRefNo the discRefNo to set
	 */
	public void setDiscRefNo(String discRefNo) {
		this.discRefNo = discRefNo;
	}

	/**
	 * @return the financeAmt
	 */
	public BigDecimal getFinanceAmt() {
		return financeAmt;
	}

	/**
	 * @param financeAmt the financeAmt to set
	 */
	public void setFinanceAmt(BigDecimal financeAmt) {
		this.financeAmt = financeAmt;
	}

	/**
	 * @return the avlbleAmt
	 */
	public BigDecimal getAvlbleAmt() {
		return avlbleAmt;
	}

	/**
	 * @param avlbleAmt the avlbleAmt to set
	 */
	public void setAvlbleAmt(BigDecimal avlbleAmt) {
		this.avlbleAmt = avlbleAmt;
	}

	/**
	 * @return the rateApplied
	 */
	public BigDecimal getRateApplied() {
		return rateApplied;
	}

	/**
	 * @param rateApplied the rateApplied to set
	 */
	public void setRateApplied(BigDecimal rateApplied) {
		this.rateApplied = rateApplied;
	}

	/**
	 * @return the revisedTenure
	 */
	public Integer getRevisedTenure() {
		return revisedTenure;
	}

	/**
	 * @param revisedTenure the revisedTenure to set
	 */
	public void setRevisedTenure(Integer revisedTenure) {
		this.revisedTenure = revisedTenure;
	}

	/**
	 * @return the indRevisedRate
	 */
	public BigDecimal getIndRevisedRate() {
		return indRevisedRate;
	}

	/**
	 * @param indRevisedRate the indRevisedRate to set
	 */
	public void setIndRevisedRate(BigDecimal indRevisedRate) {
		this.indRevisedRate = indRevisedRate;
	}

	/**
	 * @return the revisedDiscAmt
	 */
	public BigDecimal getRevisedDiscAmt() {
		return revisedDiscAmt;
	}

	/**
	 * @param revisedDiscAmt the revisedDiscAmt to set
	 */
	public void setRevisedDiscAmt(BigDecimal revisedDiscAmt) {
		this.revisedDiscAmt = revisedDiscAmt;
	}

	/**
	 * @return the decimalPoint
	 */
	public int getDecimalPoint() {
		return decimalPoint;
	}

	/**
	 * @param decimalPoint the decimalPoint to set
	 */
	public void setDecimalPoint(int decimalPoint) {
		this.decimalPoint = decimalPoint;
	}
	
	
	
	public String getFinanceAmtStr() {
		return (financeAmt != null)?financeAmt.toPlainString():"";
	}
	
	public String getAvlbleAmtStr() {
		return (avlbleAmt != null)?avlbleAmt.toPlainString():"";
	}
	
	public String getRateAppliedStr() {
		return (rateApplied != null)?rateApplied.toPlainString():"";
	}
	
	public String getIndRevisedRateStr() {
		return (indRevisedRate != null)?indRevisedRate.toPlainString():"";
	}
	
	public String getRevisedDiscAmtStr() {
		return (revisedDiscAmt != null)?revisedDiscAmt.toPlainString():"";
	}
	
	public String getPymtAmtStr() {
		return (pymtAmt != null)?pymtAmt.toPlainString():"";
	}
	
	public String getOutstandStlmtAmtStr() {
		return (outstandStlmtAmt != null)?outstandStlmtAmt.toPlainString():"";
	}
	
}
