/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      User Info Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.bnp.scm.services.common.vo.NameValueVO;

public class UserInfoVO implements Serializable{

private static final long serialVersionUID = 1L;
	
	private String userId;
	private String firstName;
	private String lastName;
	private String emailID;
	private Date lastLogin;
	private String userStatus;	
	private String timeZone;
	private String orgId;
	private String userTypeId;
	private String sessionId;
	private String orgType;
	private String userTypeDesc;
	private String userTypeCode;
	private List<NameValueVO> scrollInfoList; 
	
	private String dbTimeZone; 
	private String primaryBranchId;
	private String isLeadOrg;
	
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	private List<UserBranchVO> branchList;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public Date getLastLogin() {
		return lastLogin;
	}
	public void setLastLogin(Date lastLogin) {
		this.lastLogin = lastLogin;
	}
	public String getUserStatus() {
		return userStatus;
	}
	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}
	public String getTimeZone() {
		return timeZone;
	}
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}
	
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	
	public List<UserBranchVO> getBranchList() {
		return branchList;
	}
	public void setBranchList(List<UserBranchVO> branchList) {
		this.branchList = branchList;
	}
	
	public String getUserTypeId() {
		return userTypeId;
	}
	public void setUserTypeId(String userTypeId) {
		this.userTypeId = userTypeId;
	}
	
	public String getDbTimeZone() {
		return dbTimeZone;
	}
	public void setDbTimeZone(String dbTimeZone) {
		this.dbTimeZone = dbTimeZone;
	}
	
	public String getOrgType() {
		return orgType;
	}
	public void setOrgType(String orgType) {
		this.orgType = orgType;
	}
	
	
	public List<NameValueVO> getScrollInfoList() {
		return scrollInfoList;
	}
	public void setScrollInfoList(List<NameValueVO> scrollInfoList) {
		this.scrollInfoList = scrollInfoList;
	}
	
	public String getPrimaryBranchId() {
		return primaryBranchId;
	}
	public void setPrimaryBranchId(String primaryBranchId) {
		this.primaryBranchId = primaryBranchId;
	}
	public String getUserTypeDesc() {
		return userTypeDesc;
	}
	public void setUserTypeDesc(String userTypeDesc) {
		this.userTypeDesc = userTypeDesc;
	}
	public String getUserTypeCode() {
		return userTypeCode;
	}
	public void setUserTypeCode(String userTypeCode) {
		this.userTypeCode = userTypeCode;
	}
	
	/**
	 * @return the isLeadOrg
	 */
	public String getIsLeadOrg() {
		return isLeadOrg;
	}
	/**
	 * @param isLeadOrg the isLeadOrg to set
	 */
	public void setIsLeadOrg(String isLeadOrg) {
		this.isLeadOrg = isLeadOrg;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UserInfoVO [userId=").append(userId).append(", firstName=").append(firstName)
				.append(", lastName=").append(lastName).append(", emailID=").append(emailID).append(", lastLogin=")
				.append(lastLogin).append(", userStatus=").append(userStatus).append(", timeZone=").append(timeZone)
				.append(", orgId=").append(orgId).append(", primaryBranchId=").append(primaryBranchId).append(", orgType=").append(orgType).append(", isLeadOrg=").append(isLeadOrg).append("]");
		return builder.toString();
	}
	
	
}
