/*****************************************************************************************************************************************************************
 * Author: Oracle Financial Services Software Ltd for BNP Paribas.
 * 
 * Created on:   06 June 2016	
 * 
 * Purpose:      Payment Order Service Interface
 * 
 * Change History: 
 * Date                                    Author                                                                               Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 06 June 2016						    Bala Murugan Elangovan														 	 Service Interface 
 * 23-FEB-2017							Divyashri Subramaniam													Added new method getPDFpopupDetails for S001
 * 01-JAN-2018				            Bala Murugan Elangovan						Added new method validateDiscDateWithHoliday for S101001 as part of FO10.1 Sprint 2
 * *****************************************************************************************************************************************************************/
package com.bnp.bnpux.service;

import java.util.List;

import com.bnp.bnpux.common.vo.PaymentOrderAvailableamtCalloutVO;
import com.bnp.bnpux.common.vo.PaymentOrderListVO;
import com.bnp.bnpux.common.vo.RecallResponseVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.vo.errorMessageVO.ErrorMessageVO;
import com.bnp.bnpux.vo.requestVO.PaymentOrderCreditNoteLineItemRequestVO;
import com.bnp.bnpux.vo.requestVO.PaymentOrderInvoiceDetailsRequestVO;
import com.bnp.bnpux.vo.requestVO.PaymentOrderPopupRequestVO;
import com.bnp.bnpux.vo.requestVO.PaymentOrderRequestVO;
import com.bnp.bnpux.vo.responseVO.PaymentOrderCreditNoteLineItemResponseVO;
import com.bnp.bnpux.vo.responseVO.PaymentOrderInvoiceDetailsResponseVO;
import com.bnp.bnpux.vo.responseVO.PaymentOrderResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.discounting.vo.DiscountRequestVO;

public interface IPaymentOrderService {

	/**
	 * This method is for getting Payment Order Details
	 * 
	 * @param paymentOrderRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	PaymentOrderResponseVO getPaymentOrderDetails(PaymentOrderRequestVO paymentOrderRequestVO) throws BNPApplicationException;	
	
/*	PaymentOrderInvoiceCalloutVO getPaymentOrderInvoiceCalloutdetails(PaymentOrderInvoiceCalloutVO paymentOrderInvoiceCalloutVO)  throws BNPApplicationException;

	PaymentOrderCreditNoteCalloutVO getPaymentOrderCreditNoteCalloutdetails(PaymentOrderCreditNoteCalloutVO paymentOrderCreditNoteCalloutVO) throws BNPApplicationException;*/
	
	/**
	 * This method is for getting Credit Note Line Item details
	 * 
	 * @param paymentOrderCreditNoteLineItemRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	PaymentOrderCreditNoteLineItemResponseVO getPaymentOrderCreditNoteLineItemdetails(PaymentOrderCreditNoteLineItemRequestVO paymentOrderCreditNoteLineItemRequestVO) throws BNPApplicationException;
	
	/**
	 * This method is for getting Invoice Details Callout
	 * 
	 * @param paymentOrderInvoiceDetailsRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	PaymentOrderInvoiceDetailsResponseVO getPaymentOrderInvoiceDetailsCallout(PaymentOrderInvoiceDetailsRequestVO paymentOrderInvoiceDetailsRequestVO) throws BNPApplicationException;
	
	/**
	 * This method is for getting Available Amount Callout Details
	 * 
	 * @param paymentOrderAvailableamtCalloutVO
	 * @return
	 * @throws BNPApplicationException
	 */
	PaymentOrderAvailableamtCalloutVO getPaymentOrderAvailableAmtCalloutDetals(PaymentOrderAvailableamtCalloutVO paymentOrderAvailableamtCalloutVO)  throws BNPApplicationException;

	// Added For User Stories - Recall - Starts
	/**
	 * This method is for recall Payment Order Details 
	 * 
	 * @param paymentOrderListVO
	 * @param user
	 * @return
	 * @throws BNPApplicationException
	 */
	RecallResponseVO recallPaymentOrderDetails(List<PaymentOrderListVO> paymentOrderListVO, UserInfoVO user) throws BNPApplicationException;
	
	/**
	 * This method is for approving Recall Payment Order Details 
	 * 
	 * @param paymentOrderListtVO
	 * @param user
	 * @return
	 * @throws BNPApplicationException
	 */
	RecallResponseVO approveRecallPaymentOrderDetails(List<PaymentOrderListVO> paymentOrderListtVO, UserInfoVO user) throws BNPApplicationException;

	/**
	 * This method is for undo Recall Payment Order Details 
	 * 
	 * @param paymentOrderListtVO
	 * @param user
	 * @return
	 * @throws BNPApplicationException
	 */
	RecallResponseVO undoRecallPaymentOrderDetails(List<PaymentOrderListVO> paymentOrderListtVO, UserInfoVO user) throws BNPApplicationException;
	// Added For User Stories - Recall - Ends

	/**
	 * This method is for Payment Order Popup details - S001
	 * 
	 * @param PaymentOrderPopupRequestVO
	 * @param 
	 * @return void
	 * @throws BNPApplicationException
	 */
	void getPDFpopupDetails(PaymentOrderPopupRequestVO paymentOrderPopupRequestVO) throws BNPApplicationException;

	/**
	 * This method is for Payment Order get pending Approval Count
	 * 
	 * @param String
	 * @param 
	 * @return int
	 * @throws BNPApplicationException
	 */
	 int getPendAppovalCntService(String pmtId) throws BNPApplicationException;
	
	PaymentOrderResponseVO getAdvancedFilterCount(PaymentOrderRequestVO paymentOrderRequestVO) throws BNPApplicationException;

	/**
	 * Method is used to validate discount date with corresponding holiday
	 * @param paymentOrderRequestVO
	 * @throws BNPApplicationException
	 */
	boolean validateDiscDateWithHoliday(PaymentOrderRequestVO paymentOrderRequestVO) throws BNPApplicationException;	

}
