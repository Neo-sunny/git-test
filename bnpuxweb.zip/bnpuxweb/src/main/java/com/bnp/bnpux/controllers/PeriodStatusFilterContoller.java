/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Period Status Filter Controller
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 08 Mar 2017                skbhaska                                    		FO 10.0 - S30 - Holiday Calendar
 * 05 Jun 2017                Bhuvaneswari Anandhan                             FO 10.0 -Email Inquiry Search Filter Data Population
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.common.vo.AdvancedFilterVO;
import com.bnp.bnpux.common.vo.StatusDetailsVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.constants.ReportsConstant;
import com.bnp.bnpux.service.IAuditService;
import com.bnp.bnpux.service.IPeriodStatusFilterService;
import com.bnp.bnpux.util.RequestIdentityValidator;
import com.bnp.bnpux.vo.requestVO.AuditRequestVO;
import com.bnp.bnpux.vo.requestVO.PaymentOrderRequestVO;
import com.bnp.bnpux.vo.requestVO.ReportRequestVO;
import com.bnp.bnpux.vo.responseVO.FilterResponseVO;
import com.bnp.bnpux.vo.responseVO.PaymentOrderResponseVO;
import com.bnp.bnpux.vo.responseVO.PeriodStatusResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.report.util.ReportConstants;

@RestController
@RequestMapping("/periodStatusCtrl")
public class PeriodStatusFilterContoller {
	
		private static final Logger log = LoggerFactory.getLogger(PeriodStatusFilterContoller.class);
		
		private enum Filter {
			BRANCH_FILTER, PO_PERIOD_FILTER, PO_STATUS_FILTER, TO_PERIOD_FILTER, TO_STATUS_FILTER, SETTLE_PERIOD_FILTER, SETTLE_STATUS_FILTER, RPT_UPLD_CCY_FILTER, RPT_UPLD_ORG_ID, RPT_UPLD_CPTY_ORG_ID, 
			RPT_UPLD_PERIOD_FILTER, RPT_UPLD_PLOT, RPT_UPLD_STATUS_FILTER, RPT_UPLD_FILE_STATUS_FILTER, RPT_UPLD_GRAPH_TYPE, PO, TO, SETTLE, RPT_UPLD_FILE, QUICK_SEARCH_FIELDS, PAYMTORDMENU, TRANSMENU, 
			SETTLMNTMENU, SCR_HOL_CALENDER, HOLIDAYCALENDAR, Y, CCY_FILTER, YEAR_FILTER, ORG_FILTER, SCR_HOL_CAL_YEAR, SCR_HOL_ORG_ID, SCR_HOL_CAL_CCY, REPORTSMENU, FILEMGMT, FILEMGMTMENU, FILEMGMT_PERIOD_FILTER, FILEMGMT_STATUS_FILTER, BUYERACCEPT, BUYERACCEPT_STATUS_FILTER, BUYERACCEPT_PERIOD_FILTER,
			FILEUPLD,FILEUPLD_DOC_TYPE,FILEUPLD_ORG_ID,RPT_EMAIL_INQ,RPT_EMAIL_ORG_ID, RPT_EMAIL_CATEGORY, RPT_EMAIL_DELIVERY_STATUS, RPT_EMAIL_EVENT_RPT_NAME, RPT_EMAIL_PERIOD_FILTER,
			RPT_CN_INQ, RPT_CN_CCY_FILTER, RPT_CN_PERIOD_FILTER, RPT_CN_STATUS_FILTER, RPT_CN_BUYER_ORG_ID, RPT_CN_SUPPLIER_ORG_ID, RPT_CN_GRAPH_TYPE, RPT_CN_PLOT, RPT_SETTLE, RPT_SETTLE_CCY_FILTER, RPT_SETTLE_ORG_ID, RPT_SETTLE_CPTY_ORG_ID,
			RPT_SETTLE_PERIOD_FILTER, RPT_SETTLE_REPORT_FILTER, RPT_SETTLE_BRN_DATE, RPT_SETTLE_PLOT, RPT_SETTLE_GRAPH_TYPE, RPT_SETTLE_FORE_PLOT, RPT_VIEW_SCHEDULE, RPT_VIEWSCHD_REPORT_FILTER, RPT_VIEWSCHD_ORG_ID, RPT_VIEWSCHD_PERIOD_FILTER, 
			RPT_LMT_UTILIZATION, RPT_LMT_UT_CLIENT_ORG_ID, RPT_LMT_UT_CPTY_ORG_ID, RPT_LMT_UT_LIMIT_TYPE, RPT_LMT_UT_CCY_FILTER, RPT_LMT_UT_GRAPH_TYPE, RPT_LMT_UT_PLOT,
			RPT_REMITTANCE,RPT_REMIT_GRAPH_TYPE, RPT_REMIT_PLOT,RPT_REMIT_INQ,RPT_REMIT_CCY_FILTER, RPT_REMIT_PERIOD_FILTER, RPT_REMIT_REP_TYPE,RPT_REMIT_BUYER_ORG_ID,RPT_REMIT_SUPPLIER_ORG_ID,
			RPT_DISC_TRN, RPT_DISC_TRN_BUYER_ORG_ID, RPT_DISC_TRN_CCY_FILTER, RPT_DISC_TRN_PERIOD_FILTER, RPT_DISC_TRN_STATUS_FILTER, RPT_DISC_TRN_SUPPLIER_ORG_ID, RPT_DISC_TRN_PLOT, RPT_AGING,RPT_AGN_BUYER_ORG_ID,
			RPT_AGN_SUPP_ORG_ID,RPT_AGN_PERIOD_FILTER,RPT_AGN_CCY_FILTER,RPT_AGN_DISCOUNT_TYPE, RPT_PYMT, RPT_PYMT_ORG_ID, RPT_PYMT_CPTY_ORG_ID, RPT_PYMT_CCY_FILTER, RPT_PYMT_PERIOD_FILTER, RPT_PYMT_REPORT_FILTER, RPT_PYMT_PLOT, RPT_PYMT_GRAPH_TYPE, RPT_AGN_PLOT, RPT_AGN_GRAPH_TYPE, RPT_SETTLE_PRE_PERIOD_FILTER 
		};
		@Autowired
		private IPeriodStatusFilterService filterService;
		@Autowired
		private IAuditService auditService;
		
		@Autowired
		RequestIdentityValidator validateRequest;
		
		/**
		 * This method is for getting Filter data
		 * 
		 * @param requsetVO
		 * @param session
		 * @return
		 */
		@RequestMapping(value = "periodstatus.rest", method = RequestMethod.POST,produces= MediaType.APPLICATION_JSON_VALUE,headers = {"content-type=application/json","content-type=application/xml"})
		public FilterResponseVO getFilterData(@RequestBody PaymentOrderRequestVO requsetVO,HttpServletRequest request,HttpServletResponse response) { 
			HttpSession session = request.getSession();
			log.debug("filter");
			List<PeriodStatusResponseVO> filterVo = new ArrayList<PeriodStatusResponseVO>();
			FilterResponseVO filterVoResult = null;
			try {
				boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserId(),session);
				if(requestValidatedFlag){
					filterVoResult = new FilterResponseVO();
					
					if(requsetVO.getViewType().contains(Filter.SCR_HOL_CALENDER.name())){
						filterVo = filterService.getPeriodStatusFilterHolidayCal(requsetVO);
					}else{
						filterVo = filterService.getPeriodStatusFilter(requsetVO);
						getBranchValues(filterVo, filterVoResult);
						fillQuickSearchData(filterVo, filterVoResult);
					}
					
					UserInfoVO user = (UserInfoVO) session.getAttribute("userInfo");
					user.setSessionId((String) session.getAttribute("USER_AUTH_TOKEN"));
					AuditRequestVO auditVo = new AuditRequestVO();
					auditVo.setUserId(user.getUserId());
					auditVo.setSessionId(user.getSessionId());
					auditVo.setOrgId(user.getOrgId());
	
					 if(requsetVO.getViewType().contains(Filter.PO.name())){
						  addfilterData(filterVo, filterVoResult,Filter.PO_PERIOD_FILTER.name(),Filter.PO_STATUS_FILTER.name());
						auditVo.setFuncId(Filter.PAYMTORDMENU.name());
					 }else if(requsetVO.getViewType().contains(Filter.TO.name())){
						  addfilterData(filterVo, filterVoResult,Filter.TO_PERIOD_FILTER.name(),Filter.TO_STATUS_FILTER.name());
						auditVo.setFuncId(Filter.TRANSMENU.name());
					 }else if(requsetVO.getViewType().contains(Filter.RPT_SETTLE.name())){ /*Settlement Reminder Report - Search Filter Data population*/
						 fillFilterDataForSettlementReminderReport(filterVo, filterVoResult);
						  auditVo.setFuncId(Filter.RPT_SETTLE.name());
					 }else if(requsetVO.getViewType().contains(Filter.RPT_PYMT.name())){ /*Payment Report Product Log - Search Filter Data population*/
						 fillFilterDataForPaymentReport(filterVo, filterVoResult);
						  auditVo.setFuncId(Filter.RPT_PYMT.name());
					 }else if(requsetVO.getViewType().contains(Filter.SETTLE.name())){
						 addfilterData(filterVo, filterVoResult,Filter.SETTLE_PERIOD_FILTER.name(),Filter.SETTLE_STATUS_FILTER.name());
						auditVo.setFuncId(Filter.SETTLMNTMENU.name());
					 }else if(requsetVO.getViewType().contains(Filter.RPT_UPLD_FILE.name())){
						  fillFilterDataforUploadInvoiceReport(filterVo, filterVoResult);
						  auditVo.setFuncId(Filter.REPORTSMENU.name());
					 }else if(requsetVO.getViewType().contains(Filter.SCR_HOL_CALENDER.name())){
						  fillFilterDataforHolidayCalendar(filterVo, filterVoResult);
						  auditVo.setFuncId(Filter.HOLIDAYCALENDAR.name());
					 }else if(requsetVO.getViewType().contains(Filter.FILEMGMT.name())){
						  addfilterData(filterVo, filterVoResult,Filter.FILEMGMT_PERIOD_FILTER.name(),Filter.FILEMGMT_STATUS_FILTER.name());
						  auditVo.setFuncId(Filter.FILEMGMTMENU.name());
					 }/**S2068,S2069 Code change for filter value population**/
					 else if(requsetVO.getViewType().contains(Filter.BUYERACCEPT.name())){
						  addfilterData(filterVo, filterVoResult,Filter.BUYERACCEPT_PERIOD_FILTER.name(),Filter.BUYERACCEPT_STATUS_FILTER.name());
						  auditVo.setFuncId(Filter.BUYERACCEPT.name());
					 }else if(requsetVO.getViewType().contains(Filter.FILEUPLD.name())){
						  fillFilterFileUpldData(filterVo, filterVoResult);
						  auditVo.setFuncId(Filter.FILEMGMTMENU.name());
					 }else if(requsetVO.getViewType().contains(Filter.RPT_EMAIL_INQ.name())){ /*Email Inquiry Report - Search Filter Data population*/
						  fillFilterDataForEmailInqReport(filterVo, filterVoResult);
						  auditVo.setFuncId(Filter.RPT_EMAIL_INQ.name());
					 }else if(requsetVO.getViewType().contains(Filter.RPT_CN_INQ.name())){ /*CreditNote Inquiry Report - Search Filter Data population*/
						  fillFilterDataForCreditNoteInqReport(filterVo, filterVoResult);
						  auditVo.setFuncId(Filter.RPT_CN_INQ.name());
					 } else if(requsetVO.getViewType().contains(Filter.RPT_VIEW_SCHEDULE.name())){ /*View scheduled reports - Search Filter Data population*/
						 fillFilterDataForViewSchdReport(filterVo, filterVoResult);
						  auditVo.setFuncId(Filter.RPT_VIEW_SCHEDULE.name()); 
					 } else if(requsetVO.getViewType().contains(Filter.RPT_LMT_UTILIZATION.name())){ /*CreditNote Inquiry Report - Search Filter Data population*/
						  fillFilterDataForLimitUtilizationReport(filterVo, filterVoResult);
						  auditVo.setFuncId(Filter.RPT_CN_INQ.name());
					 }else if(requsetVO.getViewType().contains(Filter.RPT_REMITTANCE.name())){ /*Remittance Report - Search Filter Data population*/
						 fillFilterDataForRemittanceInqReport(filterVo, filterVoResult);
						  auditVo.setFuncId(Filter.RPT_REMITTANCE.name());
					 } else if(requsetVO.getViewType().contains(Filter.RPT_DISC_TRN.name())){ /*Discount Transaction Report - Search Filter Data population*/
						  fillFilterDataForDiscTransReport(filterVo, filterVoResult);
						  auditVo.setFuncId(Filter.RPT_DISC_TRN.name());
					 }else if(requsetVO.getViewType().contains(Filter.RPT_AGING.name())){ /*Aging Report - Search Filter Data population*/
						 fillFilterDataForAgingReport(filterVo, filterVoResult);
						  auditVo.setFuncId(Filter.RPT_AGING.name());
					 }
					auditService.insertAuditLog(auditVo);
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException e) {
				// TODO Auto-generated catch block
				log.debug(e.getErrorMessage(),e);
			}
			return filterVoResult;
		}
		
		/**
		 * This method is for getting filter data for Email Inquiry Report
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @throws BNPApplicationException
		 */
		private void fillFilterDataForEmailInqReport(
				List<PeriodStatusResponseVO> filterVo,
				FilterResponseVO filterVoResult) throws BNPApplicationException {
			if(filterVo !=null && filterVo.size() >0){
			getReportBranchValues(filterVo, filterVoResult);
			filterVoResult.setEmailDelvStatusDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_EMAIL_DELIVERY_STATUS));
			filterVoResult.setEmailCategoryDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_EMAIL_CATEGORY));
			filterVoResult.setEmailInqOrgDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_EMAIL_ORG_ID));
			filterVoResult.setEmailEventDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_EMAIL_EVENT_RPT_NAME));
			filterVoResult.setEmailInqPeriodDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_EMAIL_PERIOD_FILTER));
			}
		}
		
		/**
		 * This method is for getting filter data for Settlement Reminder Report
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @throws BNPApplicationException
		 */
		private void fillFilterDataForSettlementReminderReport(
				List<PeriodStatusResponseVO> filterVo,
				FilterResponseVO filterVoResult) throws BNPApplicationException {
			if(filterVo !=null && filterVo.size() >0){
			getReportBranchValues(filterVo, filterVoResult);
			filterVoResult.setOrgIdDet(getStlmtDueRmdrReportValues(filterVo, filterVoResult,Filter.RPT_SETTLE_ORG_ID));
			filterVoResult.setCounterPartyDet(getStlmtDueRmdrReportValues(filterVo, filterVoResult, Filter.RPT_SETTLE_CPTY_ORG_ID));
			filterVoResult.setCntCurrencyDet(getStlmtDueRmdrReportValues(filterVo, filterVoResult, Filter.RPT_SETTLE_CCY_FILTER));
			//filterVoResult.setCntPeriodDet(getStlmtDueRmdrReportValues(filterVo, filterVoResult, Filter.RPT_SETTLE_PERIOD_FILTER));
			List<PeriodStatusResponseVO> cntPeriodDet = getStlmtDueRmdrReportValues(filterVo, filterVoResult, Filter.RPT_SETTLE_PERIOD_FILTER);
			List<PeriodStatusResponseVO> cntPeriodDet_pre = getStlmtDueRmdrReportValues(filterVo, filterVoResult, Filter.RPT_SETTLE_PRE_PERIOD_FILTER);
			filterVoResult.setCntPeriodDet(cntPeriodDet);
			filterVoResult.setCntPeriodDet_pre(cntPeriodDet_pre);
			filterVoResult.setStlmtReportType(getStlmtDueRmdrReportValues(filterVo, filterVoResult, Filter.RPT_SETTLE_REPORT_FILTER));
			filterVoResult.setBranchLocaleDateType(getStlmtDueRmdrReportValues(filterVo, filterVoResult, Filter.RPT_SETTLE_BRN_DATE).get(0));
			getPlotParams(filterVo, filterVoResult, Filter.RPT_SETTLE_PLOT .name());
			getPlotParamsPreStlmt(filterVo, filterVoResult, Filter.RPT_SETTLE_FORE_PLOT.name());
			getChartTypes(filterVo, filterVoResult, Filter.RPT_SETTLE_GRAPH_TYPE.name());
			}
		}
		
		/**
		 * This method is for getting filter data for Payment Report Product Log
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @throws BNPApplicationException
		 */
		private void fillFilterDataForPaymentReport(List<PeriodStatusResponseVO> filterVo,FilterResponseVO filterVoResult) throws BNPApplicationException {
			if(filterVo !=null && filterVo.size() >0){
			getReportBranchValues(filterVo, filterVoResult);
			filterVoResult.setOrgIdDet(getPaymentReportValues(filterVo, filterVoResult,Filter.RPT_PYMT_ORG_ID));
			filterVoResult.setCounterPartyDet(getPaymentReportValues(filterVo, filterVoResult, Filter.RPT_PYMT_CPTY_ORG_ID));
			filterVoResult.setCntCurrencyDet(getPaymentReportValues(filterVo, filterVoResult, Filter.RPT_PYMT_CCY_FILTER));
			filterVoResult.setCntPeriodDet(getPaymentReportValues(filterVo, filterVoResult, Filter.RPT_PYMT_PERIOD_FILTER));
			filterVoResult.setPymtReportType(getPaymentReportValues(filterVo, filterVoResult, Filter.RPT_PYMT_REPORT_FILTER));
			getPlotParams(filterVo, filterVoResult, Filter.RPT_PYMT_PLOT.name());
			getChartTypes(filterVo, filterVoResult, Filter.RPT_PYMT_GRAPH_TYPE.name());
			}
		}
		
		/**
		 * This method is for getting filter data for Aging Report
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @throws BNPApplicationException
		 */
		private void fillFilterDataForAgingReport(
				List<PeriodStatusResponseVO> filterVo,
				FilterResponseVO filterVoResult) throws BNPApplicationException {
			if(filterVo !=null && filterVo.size() >0){
			getReportBranchValues(filterVo, filterVoResult);
			filterVoResult.setCntBuyerDet(getAgingReportValues(filterVo, filterVoResult,Filter.RPT_AGN_BUYER_ORG_ID));
			filterVoResult.setCntSupplierDet(getAgingReportValues(filterVo, filterVoResult, Filter.RPT_AGN_SUPP_ORG_ID));
			filterVoResult.setCntCurrencyDet(getAgingReportValues(filterVo, filterVoResult, Filter.RPT_AGN_CCY_FILTER));
			filterVoResult.setCntPeriodDet(getAgingReportValues(filterVo, filterVoResult, Filter.RPT_AGN_PERIOD_FILTER));
			filterVoResult.setAgingDiscountType(getAgingReportValues(filterVo, filterVoResult, Filter.RPT_AGN_DISCOUNT_TYPE));
			getPlotParams(filterVo, filterVoResult, Filter.RPT_AGN_PLOT.name());
			getChartTypes(filterVo, filterVoResult, Filter.RPT_AGN_GRAPH_TYPE.name());
			
			
			}
		}
		/**
		 * This method is for getting filter data for CreditNote Inquiry Report
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @throws BNPApplicationException
		 */
		private void fillFilterDataForCreditNoteInqReport(
				List<PeriodStatusResponseVO> filterVo,
				FilterResponseVO filterVoResult) throws BNPApplicationException {
			if(filterVo !=null && filterVo.size() >0) {
				getReportBranchValues(filterVo, filterVoResult);
				filterVoResult.setCntCurrencyDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_CN_CCY_FILTER));
				filterVoResult.setCntPeriodDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_CN_PERIOD_FILTER));
				filterVoResult.setCntStatusDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_CN_STATUS_FILTER));
				filterVoResult.setCntBuyerDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_CN_BUYER_ORG_ID));
				filterVoResult.setCntSupplierDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_CN_SUPPLIER_ORG_ID));
				getPlotParams(filterVo, filterVoResult, Filter.RPT_CN_PLOT.name());
				getChartTypes(filterVo, filterVoResult, Filter.RPT_CN_GRAPH_TYPE.name());
			}
		}
		
		/**
		 * This method is for getting filter data for CreditNote Inquiry Report
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @throws BNPApplicationException
		 */
		private void fillFilterDataForRemittanceInqReport(
				List<PeriodStatusResponseVO> filterVo,
				FilterResponseVO filterVoResult) throws BNPApplicationException {
			if(filterVo !=null && filterVo.size() >0) {
				getReportBranchValues(filterVo, filterVoResult);
				filterVoResult.setRemitRptCurrencyDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_REMIT_CCY_FILTER));
				filterVoResult.setRemitRptPeriodDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_REMIT_PERIOD_FILTER));
				filterVoResult.setRemitRptStatusDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_REMIT_REP_TYPE));
				filterVoResult.setRemitRptBuyerDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_REMIT_BUYER_ORG_ID));
				filterVoResult.setRemitRptSupplierDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_REMIT_SUPPLIER_ORG_ID));
				getPlotParams(filterVo, filterVoResult, Filter.RPT_REMIT_PLOT.name());
				getChartTypes(filterVo, filterVoResult, Filter.RPT_REMIT_GRAPH_TYPE.name());
			}
		}
		
		/**
		 * This method is for getting filter data for DiscountTransaction Report
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @throws BNPApplicationException
		 */
		private void fillFilterDataForDiscTransReport(
				List<PeriodStatusResponseVO> filterVo,
				FilterResponseVO filterVoResult) throws BNPApplicationException {
			if(filterVo !=null && filterVo.size() > 0) {
				getReportBranchValues(filterVo, filterVoResult);
				filterVoResult.setDscCurrencyDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_DISC_TRN_CCY_FILTER));
				filterVoResult.setDscPeriodDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_DISC_TRN_PERIOD_FILTER));
				filterVoResult.setDscStatusDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_DISC_TRN_STATUS_FILTER));
				filterVoResult.setDscBuyerDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_DISC_TRN_BUYER_ORG_ID));
				filterVoResult.setDscSupplierDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_DISC_TRN_SUPPLIER_ORG_ID));
				getPlotParams(filterVo, filterVoResult, Filter.RPT_DISC_TRN_PLOT.name());
				getChartTypes(filterVo, filterVoResult, Filter.RPT_CN_GRAPH_TYPE.name());
			}
		}
		
		/**
		 * This method is for getting filter data for Limit Utilization Report
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @throws BNPApplicationException
		 */
		private void fillFilterDataForLimitUtilizationReport(
				List<PeriodStatusResponseVO> filterVo,
				FilterResponseVO filterVoResult) throws BNPApplicationException {
			if(filterVo !=null && filterVo.size() >0) {
				getReportBranchValues(filterVo, filterVoResult);
				filterVoResult.setLmtClientOrgDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_LMT_UT_CLIENT_ORG_ID));
				filterVoResult.setLmtCounterOrgDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_LMT_UT_CPTY_ORG_ID));
				filterVoResult.setLmtLimitTypDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_LMT_UT_LIMIT_TYPE));
				filterVoResult.setLmtIncConvLimDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_LMT_UT_CCY_FILTER));
				getPlotParams(filterVo, filterVoResult, Filter.RPT_LMT_UT_PLOT.name());
				getChartTypes(filterVo, filterVoResult, Filter.RPT_LMT_UT_GRAPH_TYPE.name());
			}
		}
		
		/**
		 * This method is for getting filter data for View Scheduled reports
		 * @param filterVo
		 * @param filterVoResult
		 * @throws BNPApplicationException
		 */
		private void fillFilterDataForViewSchdReport(List<PeriodStatusResponseVO> filterVo, FilterResponseVO filterVoResult) throws BNPApplicationException {
			if (filterVo != null && filterVo.size() > 0) {
				getReportBranchValues(filterVo, filterVoResult);
				filterVoResult.setReportTypeDet(getViewScheduleReportValues(filterVo, filterVoResult, Filter.RPT_VIEWSCHD_REPORT_FILTER));
				filterVoResult.setReportOrgIdDet(getViewScheduleReportValues(filterVo, filterVoResult, Filter.RPT_VIEWSCHD_ORG_ID));
				filterVoResult.setReportPeriodDet(getViewScheduleReportValues(filterVo, filterVoResult, Filter.RPT_VIEWSCHD_PERIOD_FILTER));
				filterVoResult.setReportFrequenctDet(setViewScheduleFrequencyList());
			}
		}
		/**
		 * This method is to get View Schedule Report drop down values
		 * @param filterVo
		 * @param filterVoResult
		 * @param rptViewScheduleFilter
		 * @return List<PeriodStatusResponseVO>
		 */
		private List<PeriodStatusResponseVO> getViewScheduleReportValues(List<PeriodStatusResponseVO> filterVo, FilterResponseVO filterVoResult, Filter rptViewScheduleFilter) {
			List<PeriodStatusResponseVO> filterVo1 = new ArrayList<PeriodStatusResponseVO>();
			for (PeriodStatusResponseVO filterVObj : filterVo) {
				if (filterVObj.getKey().equalsIgnoreCase(rptViewScheduleFilter.name())) {
					filterVo1.add(filterVObj);
				}
			}
			return filterVo1;
		}
		/**
		 * This method sets View Schedule Frequency List
		 * @return List<PeriodStatusResponseVO>
		 */
		public List<PeriodStatusResponseVO> setViewScheduleFrequencyList() {
			List<PeriodStatusResponseVO> filterVo1 = new ArrayList<PeriodStatusResponseVO>();
				PeriodStatusResponseVO responseVo1 = new PeriodStatusResponseVO();
				responseVo1.setKey(ReportConstants.VIEW_SCHEDULE_FREQ.ADHOC.getValue());
				responseVo1.setValue(ReportConstants.VIEW_SCHEDULE_FREQ.ADHOC.getValue());
				responseVo1.setName(ReportConstants.VIEW_SCHEDULE_FREQ.ADHOC.getValue());
				responseVo1.setFlag(ReportsConstant.REPORT_FLAG_N);
				filterVo1.add(responseVo1);
				PeriodStatusResponseVO responseVo2 = new PeriodStatusResponseVO();
				responseVo2.setKey(ReportConstants.VIEW_SCHEDULE_FREQ.ONCE.getValue());
				responseVo2.setValue(ReportConstants.VIEW_SCHEDULE_FREQ.ONCE.getValue());
				responseVo2.setName(ReportConstants.VIEW_SCHEDULE_FREQ.ONCE.getValue());
				responseVo2.setFlag(ReportsConstant.REPORT_FLAG_N);
				filterVo1.add(responseVo2);
				PeriodStatusResponseVO responseVo3 = new PeriodStatusResponseVO();
				responseVo3.setKey(ReportConstants.VIEW_SCHEDULE_FREQ.DAILY.getValue());
				responseVo3.setValue(ReportConstants.VIEW_SCHEDULE_FREQ.DAILY.getValue());
				responseVo3.setName(ReportConstants.VIEW_SCHEDULE_FREQ.DAILY.getValue());
				responseVo3.setFlag(ReportsConstant.REPORT_FLAG_N);
				filterVo1.add(responseVo3);
				PeriodStatusResponseVO responseVo4 = new PeriodStatusResponseVO();
				responseVo4.setKey(ReportConstants.VIEW_SCHEDULE_FREQ.WEEKELY.getValue());
				responseVo4.setValue(ReportConstants.VIEW_SCHEDULE_FREQ.WEEKELY.getValue());
				responseVo4.setName(ReportConstants.VIEW_SCHEDULE_FREQ.WEEKELY.getValue());
				responseVo4.setFlag(ReportsConstant.REPORT_FLAG_N);
				filterVo1.add(responseVo4);
				PeriodStatusResponseVO responseVo5 = new PeriodStatusResponseVO();
				responseVo5.setKey(ReportConstants.VIEW_SCHEDULE_FREQ.MONTHLY.getValue());
				responseVo5.setValue(ReportConstants.VIEW_SCHEDULE_FREQ.MONTHLY.getValue());
				responseVo5.setName(ReportConstants.VIEW_SCHEDULE_FREQ.MONTHLY.getValue());
				responseVo5.setFlag(ReportsConstant.REPORT_FLAG_N);
				filterVo1.add(responseVo5);
				return filterVo1;
		}
		/**
		 * This method is for getting Email Inquiry Report data for search Filter
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @throws BNPApplicationException
		 */
		private List<PeriodStatusResponseVO> getEmailInqReportValues(List<PeriodStatusResponseVO> filterVo, FilterResponseVO filterVoResult, Filter rptEmailDeliveryStatus) {
			List<PeriodStatusResponseVO> filterVo1 = new ArrayList<PeriodStatusResponseVO>();
		
		for(PeriodStatusResponseVO filterVObj : filterVo){
			 if(filterVObj.getKey().equalsIgnoreCase(rptEmailDeliveryStatus.name())){
				 filterVo1.add(filterVObj);
			 }
		}
		
		return filterVo1;
		}
		
		/**
		 * This method is for getting Settlement Due Reminder Report data for search Filter
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @throws BNPApplicationException
		 */
		private List<PeriodStatusResponseVO> getStlmtDueRmdrReportValues(List<PeriodStatusResponseVO> filterVo, FilterResponseVO filterVoResult, Filter rptStlmtDueRmdr) {
			List<PeriodStatusResponseVO> filterVo1 = new ArrayList<PeriodStatusResponseVO>();
		
		for(PeriodStatusResponseVO filterVObj : filterVo){
			 if(filterVObj.getKey().equalsIgnoreCase(rptStlmtDueRmdr.name())){
				 filterVo1.add(filterVObj);
			 }
		}
		
		return filterVo1;
		}
		
		/**
		 * This method is for getting Payment Report Product Log data for search Filter
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @throws BNPApplicationException
		 */
		private List<PeriodStatusResponseVO> getPaymentReportValues(List<PeriodStatusResponseVO> filterVo, FilterResponseVO filterVoResult, Filter rptPymtRptFltr) {
			List<PeriodStatusResponseVO> filterVo1 = new ArrayList<PeriodStatusResponseVO>();
		
		for(PeriodStatusResponseVO filterVObj : filterVo){
			 if(rptPymtRptFltr.name().equalsIgnoreCase(filterVObj.getKey())){
				 filterVo1.add(filterVObj);
			 }
		}
		
		return filterVo1;
		}
		
		/**
		 * This method is for getting Aging Report data for search Filter
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @throws BNPApplicationException
		 */
		private List<PeriodStatusResponseVO> getAgingReportValues(List<PeriodStatusResponseVO> filterVo, FilterResponseVO filterVoResult, Filter rptAging) {
			List<PeriodStatusResponseVO> filterVo1 = new ArrayList<PeriodStatusResponseVO>();
		
		for(PeriodStatusResponseVO filterVObj : filterVo){
			 if(filterVObj.getKey().equalsIgnoreCase(rptAging.name())){
				 filterVo1.add(filterVObj);
			 }
		}
		
		return filterVo1;
		}
		
		/**
		 * This method is for getting filter data for file Upload
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @throws BNPApplicationException
		 */
		public void fillFilterFileUpldData(List<PeriodStatusResponseVO> filterVo, FilterResponseVO filterVoResult ) throws BNPApplicationException { 
			getSenderOrgId(filterVo, filterVoResult);
			getDoctypeIdList(filterVo, filterVoResult);
		}
		
		/**
		 * This method is for getting currency codes
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @return
		 * @throws BNPApplicationException
		 */
		private FilterResponseVO getSenderOrgId (List<PeriodStatusResponseVO> filterVo, FilterResponseVO filterVoResult ) throws BNPApplicationException {
			List<PeriodStatusResponseVO> senderOrgIg = new ArrayList<PeriodStatusResponseVO>();
			 for(PeriodStatusResponseVO filterVObj : filterVo){
				 if(filterVObj.getKey()!=null && filterVObj.getKey().equalsIgnoreCase(Filter.FILEUPLD_ORG_ID.name())){
					 PeriodStatusResponseVO st = new PeriodStatusResponseVO();
					 st.setName(filterVObj.getName());
					 st.setValue(filterVObj.getValue());
					 if(filterVObj.getFlag() != null && filterVObj.getFlag().contains("-")){
						 String[] data = filterVObj.getFlag().split("-");
						 st.setKey(data[0]);
						 st.setFlag(data[1]);
						 }else{
						 st.setFlag(filterVObj.getFlag());
						 }
					 senderOrgIg.add(st);
				 }
			 }
			 filterVoResult.setSenderOrgIdDet(senderOrgIg);
			return filterVoResult;

		}
		
		/**
		 * This method is for getting currency codes
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @return
		 * @throws BNPApplicationException
		 */
		private FilterResponseVO getDoctypeIdList (List<PeriodStatusResponseVO> filterVo, FilterResponseVO filterVoResult ) throws BNPApplicationException {
			List<StatusDetailsVO> doctypeLst = new ArrayList<StatusDetailsVO>();
			 for(PeriodStatusResponseVO filterVObj : filterVo){
				 if(filterVObj.getKey()!=null && filterVObj.getKey().equalsIgnoreCase(Filter.FILEUPLD_DOC_TYPE.name())){
					 StatusDetailsVO st = new StatusDetailsVO();
					 st.setStatusCode(filterVObj.getName());
					 st.setStatusValue(filterVObj.getValue());
					 if(filterVObj.getFlag().equalsIgnoreCase("Y")){
						 st.setChecked(true);
						 }else{
						 st.setChecked(false); 
						 }
					 doctypeLst.add(st);
				 }
			 }
			 filterVoResult.setDocTypeIdDet(doctypeLst);
			return filterVoResult;

		}
		
		
		
		/**
		 * This method is for getting filter data for reports
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @throws BNPApplicationException
		 */
		public void fillFilterDataforUploadInvoiceReport(List<PeriodStatusResponseVO> filterVo, FilterResponseVO filterVoResult ) throws BNPApplicationException { 
			 getReportBranchValues(filterVo, filterVoResult);
			 getCurrecyCodes(filterVo, filterVoResult);
			  getClientOrgIds(filterVo, filterVoResult);
			  getCounterParties(filterVo, filterVoResult);
			  getPeriodDetails(filterVo, filterVoResult);
			  getStatusDetails(filterVo, filterVoResult);
			  getFileStatusDetails(filterVo, filterVoResult);
			  getPlotParams(filterVo, filterVoResult, Filter.RPT_UPLD_PLOT.name());
			  getChartTypes(filterVo, filterVoResult, Filter.RPT_UPLD_GRAPH_TYPE.name());
		}
		
		
		/**
		 * This method for getting org for branch
		 * 
		 * @param requsetVO
		 * @param session
		 * @return
		 */
		@RequestMapping(value = "getOrgForBranchReport.rest", method = RequestMethod.POST)
		public FilterResponseVO getOrgForBranchReport(@RequestBody ReportRequestVO requsetVO,HttpServletRequest request,HttpServletResponse response) {
			log.debug("getOrgForBranchReport filter");
			List<PeriodStatusResponseVO> filterVo = new ArrayList<PeriodStatusResponseVO>();
			FilterResponseVO filterVoResult = null;
			try {
				boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserId(),request.getSession());
				if(requestValidatedFlag){
					filterVoResult = new FilterResponseVO();
					 filterVo = filterService.getOrgForBranchReport(requsetVO);
					  getClientOrgIds(filterVo, filterVoResult);
					  getCounterParties(filterVo, filterVoResult);
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException e) {
				// TODO Auto-generated catch block
				log.debug(e.getErrorMessage(),e);
			}
			return filterVoResult;
		}
		
		
		
		/**
		 * This method is for getting the Org filter values for Email Report when the branch changed 
		 * 
		 * @param requsetVO
		 * @return List<PeriodStatusResponseVO>
		 * @throws BNPApplicationException
		 */
		@RequestMapping(value = "getOrgForBranchEmailReport.rest", method = RequestMethod.POST)
		public FilterResponseVO getOrgForBranchEmailReport(@RequestBody ReportRequestVO requsetVO,HttpServletRequest request,HttpServletResponse response) {
			log.debug("getOrgForBranchEmailReport filter");
			List<PeriodStatusResponseVO> filterVo = null;
			FilterResponseVO filterVoResult = null;
			try {
				boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserId(),request.getSession());
				if(requestValidatedFlag){
					filterVoResult = new FilterResponseVO();
					filterVo = new ArrayList<PeriodStatusResponseVO>();
					filterVo = filterService.getOrgForBranchReport(requsetVO);
					filterVoResult.setEmailInqOrgDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_EMAIL_ORG_ID));
					
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException e) {
				// TODO Auto-generated catch block
				log.debug(e.getErrorMessage(),e);
			}
			return filterVoResult;
		}
		/**
		 * This method is for getting the Buyer Org ID and Supplier Org ID filter values on change for Aging Report when the branch changed 
		 * 
		 * @param requsetVO
		 * @return List<PeriodStatusResponseVO>
		 * @throws BNPApplicationException
		 */
		@RequestMapping(value = "getBuyerSupplierOrgIDForBranchAgingReport.rest", method = RequestMethod.POST)
		public FilterResponseVO getBuyerSupplierOrgIDForBranchAgingReport(@RequestBody ReportRequestVO requsetVO,HttpServletRequest request,HttpServletResponse response) {
			log.debug("getBuyerSupplierOrgIDForBranchAgingReport filter");
			List<PeriodStatusResponseVO> filterVo = null;
			FilterResponseVO filterVoResult = null;
			try {
				boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserId(),request.getSession());
				if(requestValidatedFlag){
					filterVoResult = new FilterResponseVO();
					filterVo = new ArrayList<PeriodStatusResponseVO>();
					filterVo = filterService.getBuyerSupplierOrgIDForBranchAgingReport(requsetVO);
					filterVoResult.setCntBuyerDet(getAgingReportValues(filterVo, filterVoResult,Filter.RPT_AGN_BUYER_ORG_ID));
					filterVoResult.setCntSupplierDet(getAgingReportValues(filterVo, filterVoResult, Filter.RPT_AGN_SUPP_ORG_ID));
					
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException e) {
				// TODO Auto-generated catch block
				log.debug(e.getErrorMessage(),e);
			}
			return filterVoResult;
		}
		
		/**
		 * This method is for getting the Org filter values for Settlement Report when the branch changed 
		 * 
		 * @param requsetVO
		 * @return List<PeriodStatusResponseVO>
		 * @throws BNPApplicationException
		 */
		@RequestMapping(value = "getOrgForBranchStlmtReport.rest", method = RequestMethod.POST)
		public FilterResponseVO getOrgForBranchStlmtReport(@RequestBody ReportRequestVO requsetVO,HttpServletRequest request,HttpServletResponse response) {
			log.debug("getOrgForBranchStlmtReport filter");
			List<PeriodStatusResponseVO> filterVo = null;
			FilterResponseVO filterVoResult = null;
			try {
				boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserId(),request.getSession());
				if(requestValidatedFlag){
					filterVoResult = new FilterResponseVO();
					filterVo = new ArrayList<PeriodStatusResponseVO>();
					filterVo = filterService.getOrgForBranchReport(requsetVO);
					filterVoResult.setOrgIdDet(getStlmtDueRmdrReportValues(filterVo, filterVoResult,Filter.RPT_SETTLE_ORG_ID));
					
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException e) {
				// TODO Auto-generated catch block
				log.debug(e.getErrorMessage(),e);
			}
			return filterVoResult;
		}
		
		/**
		 * This method is for getting the Org filter values for Settlement Report when the branch changed 
		 * 
		 * @param requsetVO
		 * @return List<PeriodStatusResponseVO>
		 * @throws BNPApplicationException
		 */
		@RequestMapping(value = "getOrgForBranchPaymentReport.rest", method = RequestMethod.POST)
		public FilterResponseVO getOrgForBranchPaymentReport(@RequestBody ReportRequestVO requsetVO,HttpServletRequest request,HttpServletResponse response) {
			log.debug("getOrgForBranchPaymentReport filter");
			List<PeriodStatusResponseVO> filterVo = null;
			FilterResponseVO filterVoResult = null;
			try {
				boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserId(),request.getSession());
				if(requestValidatedFlag){
					filterVoResult = new FilterResponseVO();
					filterVo = new ArrayList<PeriodStatusResponseVO>();
					filterVo = filterService.getOrgForBranchReport(requsetVO);
					filterVoResult.setOrgIdDet(getPaymentReportValues(filterVo, filterVoResult,Filter.RPT_PYMT_ORG_ID));
					
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException e) {
				// TODO Auto-generated catch block
				log.debug(e.getErrorMessage(),e);
			}
			return filterVoResult;
		}
		
		/**
		 * This method is for getting the Org filter values for Settlement Report when the branch changed 
		 * 
		 * @param requsetVO
		 * @return List<PeriodStatusResponseVO>
		 * @throws BNPApplicationException
		 */
		@RequestMapping(value = "getCptyOrgIdForClientReport.rest", method = RequestMethod.POST)
		public FilterResponseVO getCptyOrgIdForClientReport(@RequestBody ReportRequestVO requsetVO,HttpServletRequest request,HttpServletResponse response) {
			log.debug("getCptyOrgIdForClientReport filter");
			List<PeriodStatusResponseVO> filterVo = null;
			FilterResponseVO filterVoResult = null;
			try {
				boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserId(),request.getSession());
				if(requestValidatedFlag){
					filterVoResult = new FilterResponseVO();
					filterVo = new ArrayList<PeriodStatusResponseVO>();		
					if(requsetVO.getOrgId() != ""){
						filterVo = filterService.getCptyOrgIdForClientReport(requsetVO);
					      if(requsetVO.getViewType().equalsIgnoreCase("RPT_SETTLE")){
						filterVoResult.setCounterPartyDet(getStlmtDueRmdrReportValues(filterVo, filterVoResult, Filter.RPT_SETTLE_CPTY_ORG_ID));
					      }else if(requsetVO.getViewType().equalsIgnoreCase("RPT_PYMT")){
					    	  filterVoResult.setCounterPartyDet(getPaymentReportValues(filterVo, filterVoResult, Filter.RPT_PYMT_CPTY_ORG_ID));
					      }
					}
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException e) {
				log.debug(e.getErrorMessage(),e);
			}
			return filterVoResult;
		}
		
		/**
		 * This method is for getting the Org filter values for CreditNote Report when the branch changed 
		 * 
		 * @param requsetVO
		 * @return List<PeriodStatusResponseVO>
		 * @throws BNPApplicationException
		 */
		@RequestMapping(value = "getOrgForBranchCntReport.rest", method = RequestMethod.POST)
		public FilterResponseVO getOrgForBranchCntReport(@RequestBody ReportRequestVO requsetVO,HttpServletRequest request,HttpServletResponse response) {
			log.debug("getOrgForBranchCntReport filter");
			List<PeriodStatusResponseVO> filterVo = null;
			FilterResponseVO filterVoResult = null;
			try {
				boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserId(),request.getSession());
				if(requestValidatedFlag){
					filterVoResult = new FilterResponseVO();
					filterVo = filterService.getOrgForBranchReport(requsetVO);
					filterVoResult.setCntBuyerDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_CN_BUYER_ORG_ID));
					filterVoResult.setCntSupplierDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_CN_SUPPLIER_ORG_ID));
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException e) {
				// TODO Auto-generated catch block
				log.debug(e.getErrorMessage(),e);
			}
			return filterVoResult;
		}
		
		/**
		 * This method is for getting the Org filter values for View Schedule Report when the branch changed 
		 * 
		 * @param requsetVO
		 * @return List<PeriodStatusResponseVO>
		 * @throws BNPApplicationException
		 */
		@RequestMapping(value = "getOrgForBranchViewSchdReport.rest", method = RequestMethod.POST)
		public FilterResponseVO getOrgForBranchViewSchdReport(@RequestBody ReportRequestVO requsetVO,HttpServletRequest request,HttpServletResponse response) {
			log.debug("getOrgForBranchEmailReport filter");
			List<PeriodStatusResponseVO> filterVo = null;
			FilterResponseVO filterVoResult = null;
			try {
				boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserId(),request.getSession());
				if(requestValidatedFlag){
					filterVoResult = new FilterResponseVO();
					filterVo = filterService.getOrgForBranchReport(requsetVO);
					filterVoResult.setReportOrgIdDet(getViewScheduleReportValues(filterVo, filterVoResult, Filter.RPT_VIEWSCHD_ORG_ID));
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException e) {
				// TODO Auto-generated catch block
				log.debug(e.getErrorMessage(),e);
			}
			return filterVoResult;
		}
		
		/**
		 * This method is for getting the Org filter values for Discount Transaction Report when the branch changed 
		 * 
		 * @param requsetVO
		 * @return List<PeriodStatusResponseVO>
		 * @throws BNPApplicationException
		 */
		@RequestMapping(value = "getOrgForBranchDscReport.rest", method = RequestMethod.POST)
		public FilterResponseVO getOrgForBranchDscReport(@RequestBody ReportRequestVO requsetVO,HttpServletRequest request,HttpServletResponse response) {
			log.debug("getOrgForBranchDscReport filter");
			List<PeriodStatusResponseVO> filterVo = null;
			FilterResponseVO filterVoResult = null;
			try {
				boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserId(),request.getSession());
				if(requestValidatedFlag){
					filterVoResult = new FilterResponseVO();
					filterVo = filterService.getOrgForBranchReport(requsetVO);
					filterVoResult.setDscBuyerDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_DISC_TRN_BUYER_ORG_ID));
					filterVoResult.setDscSupplierDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_DISC_TRN_SUPPLIER_ORG_ID));
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException e) {
				// TODO Auto-generated catch block
				log.debug(e.getErrorMessage(),e);
			}
			return filterVoResult;
		}
		
		/**
		 * This method is for getting the Org filter values for Remittance Report when the branch changed 
		 * 
		 * @param requsetVO
		 * @return List<PeriodStatusResponseVO>
		 * @throws BNPApplicationException
		 */
		@RequestMapping(value = "getOrgForBranchRemitReport.rest", method = RequestMethod.POST)
		public FilterResponseVO getOrgForBranchRemitReport(@RequestBody ReportRequestVO requsetVO,HttpServletRequest request,HttpServletResponse response) {
			log.debug("getOrgForBranchRemitReport filter");
			List<PeriodStatusResponseVO> filterVo = null;
			FilterResponseVO filterVoResult = null;
			try {
				boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserId(),request.getSession());
				if(requestValidatedFlag){
					filterVoResult = new FilterResponseVO();
					filterVo = filterService.getOrgForBranchReport(requsetVO);
					filterVoResult.setRemitRptBuyerDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_REMIT_BUYER_ORG_ID));
					filterVoResult.setRemitRptSupplierDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_REMIT_SUPPLIER_ORG_ID));
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException e) {
				// TODO Auto-generated catch block
				log.debug(e.getErrorMessage(),e);
			}
			return filterVoResult;
		}
	
		
		/**
		 * This method is for getting the Org filter values for Limit Utilization Report when the branch changed 
		 * 
		 * @param requsetVO
		 * @return List<PeriodStatusResponseVO>
		 * @throws BNPApplicationException
		 */
		@RequestMapping(value = "getOrgForBranchLmtUtlReport.rest", method = RequestMethod.POST)
		public FilterResponseVO getOrgForBranchLmtUtlReport(@RequestBody ReportRequestVO requsetVO,HttpServletRequest request,HttpServletResponse response) {
			log.debug("getOrgForBranchCntReport filter");
			List<PeriodStatusResponseVO> filterVo = null;
			FilterResponseVO filterVoResult = null;
			try {
				boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserId(),request.getSession());
				if(requestValidatedFlag){
					filterVoResult = new FilterResponseVO();
					filterVo = filterService.getOrgForBranchReport(requsetVO);
					filterVoResult.setLmtClientOrgDet(getEmailInqReportValues(filterVo, filterVoResult,Filter.RPT_LMT_UT_CLIENT_ORG_ID));
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException e) {
				// TODO Auto-generated catch block
				log.debug(e.getErrorMessage(),e);
			}
			return filterVoResult;
		}
		
		/**
		 * This method is for getting the Org filter values for Limit Utilization Report when the branch changed 
		 * 
		 * @param requsetVO
		 * @return List<PeriodStatusResponseVO>
		 * @throws BNPApplicationException
		 */
		@RequestMapping(value = "getCptyOrgIdForLmtUtlReport.rest", method = RequestMethod.POST)
		public FilterResponseVO getCptyOrgIdForLmtUtlReport(@RequestBody ReportRequestVO requsetVO,HttpServletRequest request,HttpServletResponse response) {
			log.debug("getOrgForBranchStlmtReport filter");
			List<PeriodStatusResponseVO> filterVo = null;
			FilterResponseVO filterVoResult = null;
			try {
				boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserId(),request.getSession());
				if(requestValidatedFlag){
					filterVoResult = new FilterResponseVO();
					filterVo = new ArrayList<PeriodStatusResponseVO>();		
					if(requsetVO.getOrgId() != ""){
						filterVo = filterService.getCptyOrgIdForClientReport(requsetVO);
					
						filterVoResult.setLmtCounterOrgDet(getEmailInqReportValues(filterVo, filterVoResult, Filter.RPT_LMT_UT_CPTY_ORG_ID));
						filterVoResult.setLmtIncConvLimDet(getEmailInqReportValues(filterVo, filterVoResult, Filter.RPT_LMT_UT_CCY_FILTER));
					}
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException e) {
				log.debug(e.getErrorMessage(),e);
			}
			return filterVoResult;
		}

/**
		 * This method is for getting the Plot Parameter values for Limit Utilization Report when the Limit Type is changed 
		 * 
		 * @param requsetVO
		 * @return List<PeriodStatusResponseVO>
		 * @throws BNPApplicationException
		 */
		@RequestMapping(value = "getPlotParamForLmtUtlReport.rest", method = RequestMethod.POST)
		public FilterResponseVO getPlotParamForLmtUtlReport(@RequestBody ReportRequestVO requsetVO,HttpServletRequest request,HttpServletResponse response) {
			log.debug("getPlotParamForLimitTypeLmtUtlReport filter");
			List<PeriodStatusResponseVO> filterVo = null;
			FilterResponseVO filterVoResult = null;
			try {
				boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserId(),request.getSession());
				if(requestValidatedFlag){
					filterVoResult = new FilterResponseVO();
					filterVo = new ArrayList<PeriodStatusResponseVO>();		
						filterVo = filterService.getPlotParamForLmtUtlReport(requsetVO);
						filterVoResult=getPlotParams(filterVo, filterVoResult, Filter.RPT_LMT_UT_PLOT.name());
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException e) {
				log.debug(e.getErrorMessage(),e);
			}
			return filterVoResult;
		}
		
		/**
		 * This method is for getting the Email Event filter values for Email Report when the Organization changed
		 * 
		 * @param requsetVO
		 * @param session
		 * @return
		 */
		@RequestMapping(value = "getEmailEventForBranchReport.rest", method = RequestMethod.POST)
		public FilterResponseVO getEmailEventForBranchReport(@RequestBody ReportRequestVO requsetVO,HttpServletRequest request,HttpServletResponse response) {
			log.debug("getEmailEventForBranchReport filter");
			List<PeriodStatusResponseVO> filterVo = new ArrayList<PeriodStatusResponseVO>();
			FilterResponseVO filterVoResult = null;
			try {
				boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserId(),request.getSession());
				if(requestValidatedFlag){
					filterVoResult = new FilterResponseVO();
					 filterVo = filterService.getEmailEventForBranchReport(requsetVO);					  
					  getEmailEvents(filterVo, filterVoResult);
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException e) {
				// TODO Auto-generated catch block
				log.debug(e.getErrorMessage(),e);
			}
			return filterVoResult;
		}
		
		
		private FilterResponseVO getEmailEvents(List<PeriodStatusResponseVO> filterVo,
				FilterResponseVO filterVoResult) {
			List<PeriodStatusResponseVO> emailEvntlst = new ArrayList<PeriodStatusResponseVO>();
			 for(PeriodStatusResponseVO filterVObj : filterVo){
				 if(filterVObj.getKey()!=null && filterVObj.getKey().equalsIgnoreCase(Filter.RPT_EMAIL_EVENT_RPT_NAME.name())){
					 PeriodStatusResponseVO st = new PeriodStatusResponseVO();
					 st.setName(filterVObj.getName());
					 st.setValue(filterVObj.getValue());
					 if(filterVObj.getFlag() != null && filterVObj.getFlag().contains("-")){
						 String[] data = filterVObj.getFlag().split("-");
						 st.setKey(data[0]);
						 st.setFlag(data[1]);
						 }else{
						 st.setFlag(filterVObj.getFlag());
						 }
					 emailEvntlst.add(st);
				 }
			 }
			 filterVoResult.setEmailEventDet(emailEvntlst);
			return filterVoResult;

		}

		/**
		 * Generic method to add filter data
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @param periodFltr
		 * @param statusFltr
		 * @return
		 * @throws BNPApplicationException
		 */
		private FilterResponseVO addfilterData(List<PeriodStatusResponseVO> filterVo,FilterResponseVO filterVoResult,String periodFltr, String statusFltr ) throws BNPApplicationException { 
			log.debug("filter PO");
			List<PeriodStatusResponseVO> filterVo1 = new ArrayList<PeriodStatusResponseVO>();
			//PeriodStatusResponseVO filterVoResult = null;
			//filterVoResult = new PeriodStatusResponseVO();
			List<StatusDetailsVO> statusList = new ArrayList<StatusDetailsVO>();
			 for(PeriodStatusResponseVO filterVObj : filterVo){
				 if(filterVObj.getKey().equalsIgnoreCase(periodFltr)){
					 filterVo1.add(filterVObj);
				 }
				 if(filterVObj.getKey().equalsIgnoreCase(statusFltr)){
					 StatusDetailsVO st = new StatusDetailsVO();
					 st.setStatusCode(filterVObj.getName());
					 st.setStatusValue(filterVObj.getValue());
					 if(filterVObj.getFlag().equalsIgnoreCase("Y")){
					 st.setChecked(true);
					 }else{
					 st.setChecked(false); 
					 }
					 statusList.add(st);
				 }
			 }
			 filterVoResult.setPeriodDet(filterVo1);
			 filterVoResult.setStatusDet(statusList);
			return filterVoResult;
		}
		
	
		/**
		 * This method is for adding Branch Values
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @return
		 * @throws BNPApplicationException
		 */
		private FilterResponseVO getBranchValues(List<PeriodStatusResponseVO> filterVo, FilterResponseVO filterVoResult ) throws BNPApplicationException {
			//PeriodStatusResponseVO payOrderRespVo = new PeriodStatusResponseVO(); 
			List<StatusDetailsVO> statusList = new ArrayList<StatusDetailsVO>();
			// filterVo = filterService.getPeriodStatusFilter(requsetVO);
			 for(PeriodStatusResponseVO filterVObj : filterVo){
				 if(filterVObj.getKey()!=null && filterVObj.getKey().equalsIgnoreCase(Filter.BRANCH_FILTER.name())){
					 StatusDetailsVO st = new StatusDetailsVO();
					 st.setStatusCode(filterVObj.getName());
					 st.setStatusValue(filterVObj.getValue());
					 if(filterVObj.getFlag().equalsIgnoreCase("Y")){
						 st.setChecked(true);
						 }else{
						 st.setChecked(false); 
						 }
					 statusList.add(st);
				 }
			 }
			 filterVoResult.setBranchDet(statusList);
			return filterVoResult;

		}
		
		/**
		 * This method is for getting currency codes
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @return
		 * @throws BNPApplicationException
		 */
		private FilterResponseVO getCurrecyCodes (List<PeriodStatusResponseVO> filterVo, FilterResponseVO filterVoResult ) throws BNPApplicationException {
			List<StatusDetailsVO> statusList = new ArrayList<StatusDetailsVO>();
			 for(PeriodStatusResponseVO filterVObj : filterVo){
				 if(filterVObj.getKey()!=null && filterVObj.getKey().equalsIgnoreCase(Filter.RPT_UPLD_CCY_FILTER.name())){
					 StatusDetailsVO st = new StatusDetailsVO();
					 st.setStatusCode(filterVObj.getName());
					 st.setStatusValue(filterVObj.getValue());
					 if(filterVObj.getFlag().equalsIgnoreCase("Y")){
						 st.setChecked(true);
						 }else{
						 st.setChecked(false); 
						 }
					 statusList.add(st);
				 }
			 }
			 filterVoResult.setCcyDet(statusList);
			return filterVoResult;

		}
		
		/**
		 * This method is for getting client org ids
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @return
		 * @throws BNPApplicationException
		 */
		private FilterResponseVO getClientOrgIds (List<PeriodStatusResponseVO> filterVo, FilterResponseVO filterVoResult ) throws BNPApplicationException {
			List<StatusDetailsVO> statusList = new ArrayList<StatusDetailsVO>();
			 for(PeriodStatusResponseVO filterVObj : filterVo){
//				 System.out.println(filterVObj.getName()+"**"+filterVObj.getValue()+"**"+filterVObj.getFlag());
				 if(filterVObj.getKey()!=null && filterVObj.getKey().equalsIgnoreCase(Filter.RPT_UPLD_ORG_ID.name())){
					 StatusDetailsVO st = new StatusDetailsVO();
					 st.setStatusCode(filterVObj.getName());
					 st.setStatusValue(filterVObj.getValue());
					 if(filterVObj.getFlag().equalsIgnoreCase("Y")){
						 st.setChecked(true);
						 }else{
						 st.setChecked(false); 
						 }
					 statusList.add(st);
				 }
			 }
			 filterVoResult.setClientOrgDet(statusList);
			return filterVoResult;

		}
		
		/**
		 * This method is for getting counter parties list
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @return
		 * @throws BNPApplicationException
		 */
		private FilterResponseVO getCounterParties (List<PeriodStatusResponseVO> filterVo, FilterResponseVO filterVoResult ) throws BNPApplicationException {
			List<StatusDetailsVO> statusList = new ArrayList<StatusDetailsVO>();
			 for(PeriodStatusResponseVO filterVObj : filterVo){
				 if(filterVObj.getKey()!=null && filterVObj.getKey().equalsIgnoreCase(Filter.RPT_UPLD_CPTY_ORG_ID.name())){
					 StatusDetailsVO st = new StatusDetailsVO();
					 st.setStatusCode(filterVObj.getName());
					 st.setStatusValue(filterVObj.getValue());
					 if(filterVObj.getFlag().equalsIgnoreCase("Y")){
						 st.setChecked(true);
						 }else{
						 st.setChecked(false); 
						 }
					 statusList.add(st);
				 }
			 }
			 filterVoResult.setCounterPtyDet(statusList);
			return filterVoResult;

		}
		
		/**
		 * This method is for getting report branch values
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @return
		 * @throws BNPApplicationException
		 */
		private FilterResponseVO getReportBranchValues (List<PeriodStatusResponseVO> filterVo, FilterResponseVO filterVoResult ) throws BNPApplicationException {
			List<PeriodStatusResponseVO> filterVo1 = new ArrayList<PeriodStatusResponseVO>();
			
			for(PeriodStatusResponseVO filterVObj : filterVo){
				 if(filterVObj.getKey().equalsIgnoreCase(Filter.BRANCH_FILTER.name())){
					 filterVo1.add(filterVObj);
				 }
			}
			filterVoResult.setReportBranchDet(filterVo1);
			return filterVoResult;
		}
		
		/**
		 * This method is for getting plot params for reports
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @return
		 * @throws BNPApplicationException
		 */
		private FilterResponseVO getPlotParams (List<PeriodStatusResponseVO> filterVo, FilterResponseVO filterVoResult, String plotType ) throws BNPApplicationException {
			List<PeriodStatusResponseVO> filterVo1 = new ArrayList<PeriodStatusResponseVO>();
			
			for(PeriodStatusResponseVO filterVObj : filterVo){
				 if(filterVObj.getKey().equalsIgnoreCase(plotType)){
					 filterVo1.add(filterVObj);
				 }
			}
			filterVoResult.setPlotParamDet(filterVo1);
			return filterVoResult;
		}
		
		/**
		 * This method is for getting plot params for Pre-Settlement Reports
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @return
		 * @throws BNPApplicationException
		 */
		private FilterResponseVO getPlotParamsPreStlmt (List<PeriodStatusResponseVO> filterVo, FilterResponseVO filterVoResult, String plotType ) throws BNPApplicationException {
			List<PeriodStatusResponseVO> filterVo1 = new ArrayList<PeriodStatusResponseVO>();
			
			for(PeriodStatusResponseVO filterVObj : filterVo){
				 if(filterVObj.getKey().equalsIgnoreCase(plotType)){
					 filterVo1.add(filterVObj);
				 }
			}
			filterVoResult.setPlotParamPreStlmtDet(filterVo1);
			return filterVoResult;
		}
		
		/**
		 * This method is for getting chart types
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @return
		 * @throws BNPApplicationException
		 */
		private FilterResponseVO getChartTypes (List<PeriodStatusResponseVO> filterVo, FilterResponseVO filterVoResult , String graphType) throws BNPApplicationException {
			List<PeriodStatusResponseVO> filterVo1 = new ArrayList<PeriodStatusResponseVO>();
			
			for(PeriodStatusResponseVO filterVObj : filterVo){
				 if(filterVObj.getKey().equalsIgnoreCase(graphType)){
					 filterVo1.add(filterVObj);
				 }
			}
			filterVoResult.setChartTypeDet(filterVo1);
			return filterVoResult;
		}
		
		/**
		 * This method is for getting Period details
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @return
		 * @throws BNPApplicationException
		 */
		private FilterResponseVO getPeriodDetails (List<PeriodStatusResponseVO> filterVo, FilterResponseVO filterVoResult ) throws BNPApplicationException {
			List<PeriodStatusResponseVO> filterVo1 = new ArrayList<PeriodStatusResponseVO>();
			
			for(PeriodStatusResponseVO filterVObj : filterVo){
				 if(filterVObj.getKey().equalsIgnoreCase(Filter.RPT_UPLD_PERIOD_FILTER.name())){
					 filterVo1.add(filterVObj);
				 }
			}
			filterVoResult.setPeriodDet(filterVo1);
			return filterVoResult;
		}
		
		/**
		 * This method is for getting Status details
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @return
		 * @throws BNPApplicationException
		 */
		private FilterResponseVO getStatusDetails (List<PeriodStatusResponseVO> filterVo, FilterResponseVO filterVoResult ) throws BNPApplicationException {
			List<StatusDetailsVO> statusList = new ArrayList<StatusDetailsVO>();
			 for(PeriodStatusResponseVO filterVObj : filterVo){
				 if(filterVObj.getKey()!=null && filterVObj.getKey().equalsIgnoreCase(Filter.RPT_UPLD_STATUS_FILTER.name())){
					 StatusDetailsVO st = new StatusDetailsVO();
					 st.setStatusCode(filterVObj.getName());
					 st.setStatusValue(filterVObj.getValue());
					 if(filterVObj.getFlag().equalsIgnoreCase("Y")){
						 st.setChecked(true);
						 }else{
						 st.setChecked(false); 
						 }
					 statusList.add(st);
				 }
			 }
			 filterVoResult.setStatusDet(statusList);
			return filterVoResult;

		}
		
		/**
		 * This method is for getting file status details
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @return
		 * @throws BNPApplicationException
		 */
		private FilterResponseVO getFileStatusDetails (List<PeriodStatusResponseVO> filterVo, FilterResponseVO filterVoResult ) throws BNPApplicationException {
			List<StatusDetailsVO> statusList = new ArrayList<StatusDetailsVO>();
			 for(PeriodStatusResponseVO filterVObj : filterVo){
				 if(filterVObj.getKey()!=null && filterVObj.getKey().equalsIgnoreCase(Filter.RPT_UPLD_FILE_STATUS_FILTER.name())){
					 StatusDetailsVO st = new StatusDetailsVO();
					 st.setStatusCode(filterVObj.getName());
					 st.setStatusValue(filterVObj.getValue());
					 if(filterVObj.getFlag().equalsIgnoreCase("Y")){
						 st.setChecked(true);
						 }else{
						 st.setChecked(false); 
						 }
					 statusList.add(st);
				 }
			 }
			 filterVoResult.setFileStatusDet(statusList);
			return filterVoResult;

		}
		
		
		/**
		 * This method is for getting quick search data
		 * 
		 * @param filterVo
		 * @param filterVoResult
		 * @return
		 * @throws BNPApplicationException
		 */
		private FilterResponseVO fillQuickSearchData(List<PeriodStatusResponseVO> filterVo,FilterResponseVO filterVoResult ) throws BNPApplicationException { 
			log.debug("filter PO");
			List<PeriodStatusResponseVO> filterVo1 = new ArrayList<PeriodStatusResponseVO>();
			//PeriodStatusResponseVO filterVoResult = null;
			//filterVoResult = new PeriodStatusResponseVO();
			 for(PeriodStatusResponseVO filterVObj : filterVo){
				 if(filterVObj.getKey().equalsIgnoreCase(Filter.QUICK_SEARCH_FIELDS.name())){
					 filterVo1.add(filterVObj);
				 }
			 }
			 filterVoResult.setQuickSearchDet(filterVo1);
			 //System.out.println("Size is branxch "+filterVoResult.getBranchDet().size()+"Size is period"+filterVoResult.getPeriodDet().size());
			return filterVoResult;
		}
		
		/**
		 * This method is for getting status values
		 * 
		 * @param requsetVO
		 * @param session
		 * @return
		 */
		@RequestMapping(value = "getStatusValues.rest", method = RequestMethod.POST)
		public PaymentOrderResponseVO getStatusValues(@RequestBody PaymentOrderRequestVO requsetVO,HttpServletRequest request,HttpServletResponse response) {
			PaymentOrderResponseVO payOrderRespVo = new PaymentOrderResponseVO(); 
			List<StatusDetailsVO> statusList = new ArrayList<StatusDetailsVO>();
			List<PeriodStatusResponseVO> filterVo = new ArrayList<PeriodStatusResponseVO>();
			try {
				boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserId(),request.getSession());
				if(requestValidatedFlag){
				 filterVo = filterService.getPeriodStatusFilter(requsetVO);
				 for(PeriodStatusResponseVO filterVObj : filterVo){
					 if(filterVObj.getKey().equalsIgnoreCase(Filter.PO_STATUS_FILTER.name())){
						 StatusDetailsVO st = new StatusDetailsVO();
						 st.setStatusCode(filterVObj.getName());
						 st.setStatusValue(filterVObj.getValue());
						 if(filterVObj.getFlag().equalsIgnoreCase("Y")){
						 st.setChecked(true);
						 }else{
						 st.setChecked(false); 
						 }
						 statusList.add(st);
					 }
				 }
				}
				else{
					payOrderRespVo = null;
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException e) {
				// TODO Auto-generated catch block
				log.debug(e.getErrorMessage(),e);
			}
				payOrderRespVo.setStatusDet(statusList);
			return payOrderRespVo;

		}
		
		/**
		 * This method is for getting transaction search fields
		 * 
		 * @param requsetVO
		 * @param session
		 * @return
		 */
		@RequestMapping(value = "searchableFields.rest", method = RequestMethod.POST)
		public List<PeriodStatusResponseVO> getTransactionSearchFields(@RequestBody PaymentOrderRequestVO requsetVO,HttpServletRequest request,HttpServletResponse response) { 
			List<PeriodStatusResponseVO> filterVo = new ArrayList<PeriodStatusResponseVO>();
			List<PeriodStatusResponseVO> filterVoResult = null;
			try {
				boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserId(),request.getSession());
				if(requestValidatedFlag){
					filterVoResult = new ArrayList<PeriodStatusResponseVO>();
					filterVo = filterService.getPeriodStatusFilter(requsetVO);
					for(PeriodStatusResponseVO filterVObj : filterVo){
						if(filterVObj.getKey().equalsIgnoreCase(Filter.QUICK_SEARCH_FIELDS.name())){
							filterVoResult.add(filterVObj);
						}
					}
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}	 
			} catch (BNPApplicationException e) {
				// TODO Auto-generated catch block
				log.debug(e.getErrorMessage(),e);
			}
			return filterVoResult;
		}

		
		/**
		 * This method is for getting transaction filter data
		 * 
		 * @param requsetVO
		 * @param session
		 * @return
		 */
		@RequestMapping(value = "Transactionperiodstatus.rest", method = RequestMethod.POST)
		public List<PeriodStatusResponseVO> getTransactionFilterData(@RequestBody PaymentOrderRequestVO requsetVO,HttpServletRequest request,HttpServletResponse response) { 
			log.debug("filter");
			List<PeriodStatusResponseVO> filterVo = new ArrayList<PeriodStatusResponseVO>();
			List<PeriodStatusResponseVO> filterVoResult = null;
			try {
				boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserId(),request.getSession());
				if(requestValidatedFlag){
					filterVoResult = new ArrayList<PeriodStatusResponseVO>();
					filterVo = filterService.getPeriodStatusFilter(requsetVO);
					for(PeriodStatusResponseVO filterVObj : filterVo){
						if(filterVObj.getKey().equalsIgnoreCase(Filter.TO_PERIOD_FILTER.name())){
							filterVoResult.add(filterVObj);
						}
					}
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException e) {
				// TODO Auto-generated catch block
				log.debug(e.getErrorMessage(),e);
			}
			return filterVoResult;
		}
		
		/**
		 * This method is for getting transaction status values
		 * 
		 * @param requsetVO
		 * @param session
		 * @return
		 */
		@RequestMapping(value = "getTransactionStatusValues.rest", method = RequestMethod.POST)
		public PaymentOrderResponseVO getTransactionStatusValues(@RequestBody PaymentOrderRequestVO requsetVO,HttpServletRequest request,HttpServletResponse response) {
			PaymentOrderResponseVO payOrderRespVo = new PaymentOrderResponseVO(); 
			List<StatusDetailsVO> statusList = new ArrayList<StatusDetailsVO>();
			List<PeriodStatusResponseVO> filterVo = new ArrayList<PeriodStatusResponseVO>();
			try {
				boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserId(),request.getSession());
				if(requestValidatedFlag){
					 filterVo = filterService.getPeriodStatusFilter(requsetVO);
					 for(PeriodStatusResponseVO filterVObj : filterVo){
						 if(filterVObj.getKey().equalsIgnoreCase(Filter.TO_STATUS_FILTER.name())){
							 StatusDetailsVO st = new StatusDetailsVO();
							 st.setStatusCode(filterVObj.getName());
							 st.setStatusValue(filterVObj.getValue().replace("\n", "").replace("\r", ""));
							 if(filterVObj.getFlag().equalsIgnoreCase("Y")){
							 st.setChecked(true);
							 }else{
							 st.setChecked(false); 
							 }
							 statusList.add(st);
						 }
					 }
					payOrderRespVo.setStatusDet(statusList);
				}
				else{
					payOrderRespVo = null;
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException e) {
				// TODO Auto-generated catch block
				log.debug(e.getErrorMessage(),e);
			}
			return payOrderRespVo;

		}
		
		/**
		 * This method is for getting Branch values
		 * 
		 * @param requsetVO
		 * @param session
		 * @return
		 */
		@RequestMapping(value = "getBranchValues.rest", method = RequestMethod.POST)
		public PaymentOrderResponseVO getBranchValues(@RequestBody PaymentOrderRequestVO requsetVO,HttpServletRequest request,HttpServletResponse response) {
			PaymentOrderResponseVO payOrderRespVo = new PaymentOrderResponseVO(); 
			List<StatusDetailsVO> statusList = new ArrayList<StatusDetailsVO>();
			List<PeriodStatusResponseVO> filterVo = new ArrayList<PeriodStatusResponseVO>();
			try {
				boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserId(),request.getSession());
				if(requestValidatedFlag){
					 filterVo = filterService.getPeriodStatusFilter(requsetVO);
					 for(PeriodStatusResponseVO filterVObj : filterVo){
						 if(filterVObj.getKey()!=null && filterVObj.getKey().equalsIgnoreCase(Filter.BRANCH_FILTER.name())){
							 StatusDetailsVO st = new StatusDetailsVO();
							 st.setStatusCode(filterVObj.getName());
							 st.setStatusValue(filterVObj.getValue());
							 if(filterVObj.getFlag().equalsIgnoreCase("Y")){
								 st.setChecked(true);
								 }else{
								 st.setChecked(false); 
								 }
							 statusList.add(st);
						 }
					 }
					 payOrderRespVo.setStatusDet(statusList);
				}
				else{
					payOrderRespVo = null;
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException e) {
				// TODO Auto-generated catch block
				log.debug(e.getErrorMessage(),e);
			}
			return payOrderRespVo;

		}
		
		/**
		 * This method is for getting settlement period values
		 * 
		 * @param requsetVO
		 * @param session
		 * @return
		 */
		@RequestMapping(value = "settlementPeriodstatus.rest", method = RequestMethod.POST)
		public List<PeriodStatusResponseVO> getSettlementFilterData(@RequestBody PaymentOrderRequestVO requsetVO,HttpServletRequest request,HttpServletResponse response) { 
			log.debug("filter");
			List<PeriodStatusResponseVO> filterVo = new ArrayList<PeriodStatusResponseVO>();
			List<PeriodStatusResponseVO> filterVoResult = null;
			try {
				boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserId(),request.getSession());
				if(requestValidatedFlag){
					filterVoResult = new ArrayList<PeriodStatusResponseVO>();
					 filterVo = filterService.getPeriodStatusFilter(requsetVO);
					 for( PeriodStatusResponseVO filterVObj : filterVo){
						 if(filterVObj.getKey()!=null && filterVObj.getKey().equalsIgnoreCase(Filter.SETTLE_PERIOD_FILTER.name())){
							 filterVoResult.add(filterVObj);
						 }
					 }
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException e) {
				// TODO Auto-generated catch block
				log.debug(e.getErrorMessage(),e);
			}
			return filterVoResult;
		}
		
		/**
		 * This method is for getting settlement status values
		 * 
		 * @param requsetVO
		 * @param session
		 * @return
		 */
		@RequestMapping(value = "getSettltmentStatusValues.rest", method = RequestMethod.POST)
		public PaymentOrderResponseVO getSettltmentStatusValues(@RequestBody PaymentOrderRequestVO requsetVO,HttpServletRequest request,HttpServletResponse response) {
			PaymentOrderResponseVO payOrderRespVo = new PaymentOrderResponseVO(); 
			List<StatusDetailsVO> statusList = new ArrayList<StatusDetailsVO>();
			List<PeriodStatusResponseVO> filterVo = new ArrayList<PeriodStatusResponseVO>();
			try {
				boolean requestValidatedFlag = validateRequest.validate(requsetVO.getUserId(),request.getSession());
				if(requestValidatedFlag){
					 filterVo = filterService.getPeriodStatusFilter(requsetVO);
					 for(PeriodStatusResponseVO filterVObj : filterVo){
						 if(filterVObj.getKey()!=null && filterVObj.getKey().equalsIgnoreCase(Filter.SETTLE_STATUS_FILTER.name())){
							 StatusDetailsVO st = new StatusDetailsVO();
							 st.setStatusCode(filterVObj.getName());
							 st.setStatusValue(filterVObj.getValue().replace("\n", "").replace("\r", ""));
							 if(filterVObj.getFlag().equalsIgnoreCase("Y")){
							 st.setChecked(true);
							 }else{
							 st.setChecked(false); 
							 }
							 statusList.add(st);
						 }
					 }
					 payOrderRespVo.setStatusDet(statusList);
				}
				else{
					payOrderRespVo = null;
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} catch (BNPApplicationException e) {
				// TODO Auto-generated catch block
				log.debug(e.getErrorMessage(),e);
			}
			return payOrderRespVo;

		}
		
	/***
	 * This method is for population of Filter data for Holiday Calendar Popup
	 * @param filterVo
	 * @param filterVoResult
	 * @throws BNPApplicationException
	 */
	public FilterResponseVO fillFilterDataforHolidayCalendar(List<PeriodStatusResponseVO> filterVo,
			FilterResponseVO filterVoResult) throws BNPApplicationException {
		
		log.debug("Enter fillFilterDataforHolidayCalendar");
		List<PeriodStatusResponseVO> yearDet = new ArrayList<PeriodStatusResponseVO>();
		List<PeriodStatusResponseVO> orgIdDet = new ArrayList<PeriodStatusResponseVO>();
		List<StatusDetailsVO> ccyDet = new ArrayList<StatusDetailsVO>();
		List<PeriodStatusResponseVO> reportBranchDet = new ArrayList<PeriodStatusResponseVO>();
		StatusDetailsVO st;

		for (PeriodStatusResponseVO filterVObj : filterVo) {

			if (filterVObj.getKey() != null && filterVObj.getKey().equalsIgnoreCase(Filter.BRANCH_FILTER.name())) {
				reportBranchDet.add(filterVObj);
			} else if (filterVObj.getKey() != null
					&& filterVObj.getKey().equalsIgnoreCase(Filter.SCR_HOL_CAL_CCY.name())) {

				 st = new StatusDetailsVO();
				 st.setStatusCode(filterVObj.getName());
				 st.setStatusValue(filterVObj.getValue());
				 if(filterVObj.getFlag().equalsIgnoreCase("Y")){
					 st.setChecked(true);
				 }else{
					 st.setChecked(false); 
				 }
				 ccyDet.add(st);
			 

			} else if (filterVObj.getKey().equalsIgnoreCase(Filter.SCR_HOL_ORG_ID.name())) {
				
				orgIdDet.add(filterVObj);
			 
			} else if (filterVObj.getKey().equalsIgnoreCase(Filter.SCR_HOL_CAL_YEAR.name())) {
				
				yearDet.add(filterVObj);
				
			}
		}
		
		filterVoResult.setReportBranchDet(reportBranchDet);
		filterVoResult.setCcyDet(ccyDet);
		filterVoResult.setOrgIdDet(orgIdDet);
		filterVoResult.setYearDet(yearDet);
		
		log.debug("Exit fillFilterDataforHolidayCalendar");
		return filterVoResult;
	}
		
	/**
	 * This method for getting dates on period filter
	 * 
	 * @param requsetVO
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "getDatesFromPeriod.rest", method = RequestMethod.POST)
	public AdvancedFilterVO getPeriodFilterDate(@RequestBody AdvancedFilterVO advanceFiterRequsetVO,HttpServletRequest httpRequest,HttpServletResponse httpResponse) {
		log.debug("getOrgForBranchReport filter");
		AdvancedFilterVO advanceFilterVO = new AdvancedFilterVO();
		try {
			boolean requestValidatedFlag = validateRequest.validate(advanceFiterRequsetVO.getUserId(),httpRequest.getSession());
			if(requestValidatedFlag){
				advanceFilterVO = filterService.getPeriodFilterDate(advanceFiterRequsetVO);
			}
			else{
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (BNPApplicationException e) {
			log.debug(e.getErrorMessage(),e);
		}
		return advanceFilterVO;
	}
	
	/**
	 * Get period date range for view schedule reports
	 * @param advanceFiterRequsetVO
	 * @param httpRequest
	 * @param httpResponse
	 * @return List<String>
	 */
	@RequestMapping(value = "getSchReportDtRange.rest", method = RequestMethod.POST)
	public List<String> getPeriodFilterDateRange(@RequestBody AdvancedFilterVO advanceFiterRequsetVO,HttpServletRequest httpRequest,HttpServletResponse httpResponse) {
		log.debug("method: getPeriodFilterDateRange, class:PeriodStatusFilterContoller");
		List<String> periodrangeDates = new ArrayList<String>();
		try {
			boolean requestValidatedFlag = validateRequest.validate(advanceFiterRequsetVO.getUserId(),httpRequest.getSession());
			if(requestValidatedFlag){
				AdvancedFilterVO advanceFilterVO = filterService.getPeriodFilterDate(advanceFiterRequsetVO);
				periodrangeDates.add(formateDt(advanceFilterVO.getPeriodFromDate()));
				periodrangeDates.add(formateDt(advanceFilterVO.getPeriodToDate()));
			}
			else{
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (BNPApplicationException e) {
			log.debug(e.getErrorMessage(),e);
		}
		return periodrangeDates;
	}
	
	/**
	 * Format date
	 * @param inputDt
	 * @return String
	 */
	public String formateDt(Date inputDt){
		 SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss aa");
		 return dateFormat.format(inputDt.getTime());
	}
	
}
