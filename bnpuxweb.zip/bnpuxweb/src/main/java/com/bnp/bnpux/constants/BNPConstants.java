/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      BNP Constants
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 28 Feb 2017				  skbhaska									 		FO 10.0 - S011, S012
 * 08 Mar 2017                skbhaska                                    		FO 10.0 - S30 - Holiday Calendar
************************************************************************************************************************************************************/
package com.bnp.bnpux.constants;

public interface BNPConstants {
	String BNP_COMMON_PROPERTIES = "resources/common.properties";
	String EMPTY="";
	String USER_TIME_ZONE="userTimeZone";
	String SYSTEMLOGOUT="SYSTEM LOGOUT";
	
	String LOCALE_PROPERTY_FILE_PATH ="resources/translations/labels";
	
	String i18n_PROPERTY_FILE_PATH = "i18n";
	
	String LOCALE_ERROR_PROPERTY_FILE_PATH ="resources/translations/ErrorMessage";
	
	String PROPERTIES_FILE_TYPE = ".properties";
	
	String BACK_SLASH = "/";
	
	String UNAUTHORIZED_ACCESS = "Requested user ID Mismatch. Unauthorized access.";
	
	/**FO 10.0 - S011, S012**/
	String SQL_EXCEPTION = " SQLException:";
	/**FO 10.0 - S011, S012**/
	
	/**FO 10.0 - S30 - Holiday Calendar**/
	String FUNCID_HOLIDAYCALENDAR = "HOLIDAYCALENDAR";
	/**FO 10.0 - S30 - Holiday Calendar**/
	String NO = "N";
	
	//The below code is commented for fetching file from the server
	
	/*String AUDIO_FILE_NAME = "audio.file.name";
	
	String AUDIO_FILE_PATH = "audio.file.path";*/
	
	String currency = "Currency";
	
	String entity = "Entity";
}
    