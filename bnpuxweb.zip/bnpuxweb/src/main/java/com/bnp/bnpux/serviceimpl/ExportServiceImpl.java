/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     Export Service Implementation
 * 
 * Change History: 
 * Date                  Author   								Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016			Oracle Financial Services Software Ltd		Initial Version 
 * 21 Feb 2017			Sathishkumar B								FO 10.0 - S011, S012, S013, S014
 * 26-Feb-2017			aasriniv									FO 10.0 - S004, S005,S006
 * 28 Feb 2017	 		Sathishkumar B								FO 10.0 - S011, S012
 * 09-Mar-2017			aasriniv									FO 10.0 - Defect 11642 - CSV should handle data with comma.
 * 13-Mar-2017			Bala Murugan Elangovan						FO 10.0 - Advanced Filter Implementation 
 * 14-Mar-2017			Divyashri Subramaniam						FO 10.0 - Advanced Filter Implementation - Settlement screen
 * 16-Mar-2017			aasriniv									FO 10.0 - Advanced Filter Implementation - Transaction screen
 *****************************************************************************************************************************************************************/

package com.bnp.bnpux.serviceimpl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.ResourceBundle;
import java.sql.DriverManager;

import javax.servlet.ServletOutputStream;

import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.common.vo.AdvancedFilterVO;
import com.bnp.bnpux.common.vo.OrganizationVO;
import com.bnp.bnpux.common.vo.UserPreferenceVO;
import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.constants.ErrorConstants;
import com.bnp.bnpux.constants.ExportConstants;
import com.bnp.bnpux.dao.ITransactionDAO;
import com.bnp.bnpux.dao.IUserPrefDAO;
import com.bnp.bnpux.service.IExportService;
import com.bnp.bnpux.service.INewLoginService;
import com.bnp.bnpux.util.DataSourceConnector;
import com.bnp.bnpux.util.ExportUtil;
import com.bnp.bnpux.vo.requestVO.ExportRequestVO;
import com.bnp.scm.services.common.ExportDataUtil;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.report.util.DynamicReportUtil;
import com.bnp.scm.services.report.util.ReportConstants;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRParameter;
import net.sf.jasperreports.engine.JRPrintPage;
import net.sf.jasperreports.engine.JRResultSetDataSource;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRPdfExporterParameter;
import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;

@Component
public class ExportServiceImpl implements IExportService{

	@Autowired
	private ITransactionDAO transactionDAO;

	@Autowired
	private ExportDataUtil exportDataUtil;

	@Autowired
	
	private DynamicReportUtil dynamicReportUtil;

	@Autowired
    private IUserPrefDAO userPrefDAO;
	
	@Autowired
	INewLoginService loginService;


	/*@Autowired
	private DataSourceConnector datasourceconnector; */

	String exportDelimiter;

	String exportType;

	String userId;

	String errorFlag;

	public static final String NO_RECORDS = "There are no records available for export.";

	/** The JASPER_EXTN. */
	private final static String JASPER_EXTN=".jasper";

	/** The BNPLOGO. */
	private final static String BNPLOGO="bnpLogo";
	
	String SUBREPORT_DIR = "SUBREPORT_DIR";


	public static final Logger log = LoggerFactory
			.getLogger(ExportServiceImpl.class);


	public String getExportDelimiter() {
		return exportDelimiter;
	}

	public void setExportDelimiter(String exportDelimiter) {
		this.exportDelimiter = exportDelimiter;
	}


	public String getExportType() {
		return exportType;
	}

	public void setExportType(String exportType) {
		this.exportType = exportType;
	}

	private String replaceNullWithEmpty(Object input) {
		if(input == null){
			input = ExportConstants.EMPTY;
		}
		return input.toString().replaceAll(ExportConstants.NULL_STR, ExportConstants.EMPTY);
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * This method for setting export delimiter value
	 * 
	 * @param exportType 
	 * @Description set Export Delimiter Value
	 */
	private void setExportDelimiterValue(String exportType) {
		this.exportType = exportType;
		if (ExportConstants.CSV_FORMAT.equalsIgnoreCase(exportType)){
			setExportDelimiter(ExportConstants.COMMA_DELIMITER);
		}else {
			setExportDelimiter(ExportConstants.EMPTY);
		}
    }

	/**
	 * This method for getting string value
	 * 
	 * @param input
	 * @return String
	 * @Description get String for Object
	 */
	private String getStringValue(Object input){
		String inputStr = replaceNullWithEmpty(input);
		if (ExportConstants.CSV_FORMAT.equalsIgnoreCase(this.exportType)){
			StringBuilder instance = new StringBuilder();
			//inputStr = inputStr.replace(ExportConstants.COMMA_DELIMITER,ExportConstants.EMPTY);
			if(inputStr.contains(","))
			{
				instance.append("\"" + inputStr + "\"");
			}
			else
			{
				instance.append(inputStr);
			}
			instance.append(ExportConstants.COMMA_DELIMITER);
			inputStr = instance.toString();
		}
		return inputStr;
	}

	/**
	 * This method for getting Transaction resultset
	 * 
	 * @param exportRequestVO
	 * @param outputStream
	 * @throws BNPApplicationException
	 * @throws IOException
	 * @see com.bnp.bnpux.service.IExportService#getTransactionResultSet(com.bnp.bnpux.vo.requestVO.ExportRequestVO, javax.servlet.ServletOutputStream)
	 * @Description get Transaction ResultSet
	 */
	public  void getTransactionResultSet(ExportRequestVO exportRequestVO, ServletOutputStream outputStream)
			throws BNPApplicationException, IOException {
		try {
			setExportDelimiterValue(exportRequestVO.getExportType());
			getTransactionExportData(exportRequestVO,outputStream);
		} catch (BNPApplicationException e) {
			throw new BNPApplicationException(e.getErrorCode(),e.getMessage());
		}
	}


	/**
	 * This method for getting settlement results
	 * 
	 * @param exportRequestVO
	 * @param outputStream
	 * @throws BNPApplicationException
	 * @throws IOException
	 * @see com.bnp.bnpux.service.IExportService#getSettlementResults(com.bnp.bnpux.vo.requestVO.ExportRequestVO, javax.servlet.ServletOutputStream)
	 * @Description Get Settlement Results
	 */
	@Override
	public  void getSettlementResults(ExportRequestVO exportRequestVO, ServletOutputStream outputStream)
			throws BNPApplicationException, IOException {
		try {
			setExportDelimiterValue(exportRequestVO.getExportType());
			getSettlementResultset(exportRequestVO,outputStream);
		} catch (BNPApplicationException e) {
			throw new BNPApplicationException(e.getErrorCode(),e.getMessage());
		}
	}


	/**
	 * This method for getting Payment Order export details
	 * 
	 * @param exportRequestVO
	 * @param outputStream
	 * @throws BNPApplicationException
	 * @throws IOException
	 * @see com.bnp.bnpux.service.IExportService#getPaymentOrderExportDetails(com.bnp.bnpux.vo.requestVO.ExportRequestVO, javax.servlet.ServletOutputStream)
	 * @Description Get PaymentOrder Export Details
	 */
	@Override
	public void getPaymentOrderExportDetails(ExportRequestVO exportRequestVO, ServletOutputStream outputStream) throws BNPApplicationException, IOException {
	try {
		setExportDelimiterValue(exportRequestVO.getExportType());
		getPaymentOrderExportData(exportRequestVO,outputStream);
	} catch (BNPApplicationException e) {
		throw new BNPApplicationException(e.getErrorCode(),e.getMessage());
	}
	}
	
	/**
	 * This method for getting reports export
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException
	 * @see com.bnp.bnpux.service.IExportService#getReportsExport(com.bnp.bnpux.vo.requestVO.ExportRequestVO, javax.servlet.ServletOutputStream, byte[])
	 * @Description Get Reports for Export
	 */
	@Override
	public void getReportsExport(ExportRequestVO exportVO,
			ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException,
			IOException {
		try {
			setExportDelimiterValue(exportVO.getExportType());
			exportReportsData(exportVO,outputStream,buffer);
		} catch (BNPApplicationException e) {
			throw new BNPApplicationException(e.getErrorCode(),e.getMessage());
		}
		
	}
	
	/**
	 * This method for getting reports export
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException
	 * @see com.bnp.bnpux.service.IExportService#getCreditNoteReportsExport(com.bnp.bnpux.vo.requestVO.ExportRequestVO, javax.servlet.ServletOutputStream, byte[])
	 * @Description Get Reports for Export
	 */
	@Override
	public void getCreditNoteReportsExport(ExportRequestVO exportVO,
			ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException,
			IOException {
		try {
			setExportDelimiterValue(exportVO.getExportType());
			exportCreditNoteReportsData(exportVO,outputStream,buffer);
		} catch (BNPApplicationException e) {
			throw new BNPApplicationException(e.getErrorCode(),e.getMessage());
		}
		
	}
	
	/**
	 * This method for getting View Scheduled Reports Export data
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException
	 * @see com.bnp.bnpux.service.IExportService#getExportRemittanceReportsData(com.bnp.bnpux.vo.requestVO.ExportRequestVO, javax.servlet.ServletOutputStream, byte[])
	 * @Description Get Reports for Export
	 */
	@Override
	public void getExportRemittanceReportsData(ExportRequestVO exportVO,
			ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException,
			IOException {
		try {
			setExportDelimiterValue(exportVO.getExportType());
			exportRemittanceReportsData(exportVO,outputStream,buffer);
		} catch (BNPApplicationException e) {
			throw new BNPApplicationException(e.getErrorCode(),e.getMessage());
		}
		
	}
	
	//S39801 :Limit Util Report
	/**
	 * This method for getting reports export
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException
	 * @see com.bnp.bnpux.service.IExportService#getLimitUtilReportsExport(com.bnp.bnpux.vo.requestVO.ExportRequestVO, javax.servlet.ServletOutputStream, byte[])
	 * @Description Get Reports for Export
	 */
	@Override
	public void getLimitUtilReportsExport(ExportRequestVO exportVO,
			ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException,
			IOException {
		try {
			setExportDelimiterValue(exportVO.getExportType());
			exportLimitUtilReportsData(exportVO,outputStream,buffer);
		} catch (BNPApplicationException e) {
			throw new BNPApplicationException(e.getErrorCode(),e.getMessage());
		}
		
	}
	
	/**
	 * This method for getting reports export
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException
	 * @see com.bnp.bnpux.service.IExportService#getDiscTransReportsExport(com.bnp.bnpux.vo.requestVO.ExportRequestVO, javax.servlet.ServletOutputStream, byte[])
	 * @Description Get Reports for Export
	 */
	@Override
	public void getDiscTransReportsExport(ExportRequestVO exportVO,
			ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException,
			IOException {
		try {
			setExportDelimiterValue(exportVO.getExportType());
			exportDiscTransReportsData(exportVO,outputStream,buffer);
		} catch (BNPApplicationException e) {
			throw new BNPApplicationException(e.getErrorCode(),e.getMessage());
		}
		
	}
	
	/**
	 * This method for getting reports export
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException
	 * @see com.bnp.bnpux.service.IExportService#getCreditNoteReportsExport(com.bnp.bnpux.vo.requestVO.ExportRequestVO, javax.servlet.ServletOutputStream, byte[])
	 * @Description Get Reports for Export
	 */
	@Override
	public void getExportSettlementDueReminderReportsData(ExportRequestVO exportVO,
			ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException,
			IOException {
		try {
			setExportDelimiterValue(exportVO.getExportType());
			exportSettlementDueReminderReportsData(exportVO,outputStream,buffer);
		} catch (BNPApplicationException e) {
			throw new BNPApplicationException(e.getErrorCode(),e.getMessage());
		}
		
	}
	//CMA
	/**
	 * This method for getting reports export
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException
	 * @see com.bnp.bnpux.service.IExportService#getCreditNoteReportsExport(com.bnp.bnpux.vo.requestVO.ExportRequestVO, javax.servlet.ServletOutputStream, byte[])
	 * @Description Get Reports for Export
	 */
	
	public void exportSettlementDueReminderReportsData(ExportRequestVO exportRequestVO, ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException, IOException {
		log.debug("For Export Reports Screen ");
		Connection con = null;
		ResultSet rs = null;
		try{
			con = getConnection();
		}catch(Exception bnp){
			log.error(1000010 + "    Could not get Connection");
			throw new BNPApplicationException(1000010,"SQLException: " + "    Could not get Connection");
		}
		CallableStatement callableStatement = null;
		Properties prop = ExportUtil.getProperties(exportRequestVO);
		try {
			long strTime = System.currentTimeMillis();
			callableStatement = con.prepareCall("{call pkg_reports.prc_setlmt_rpt_summary( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?)}"); // Modified for Sonar Fix
			callableStatement.setString(1, exportRequestVO.getUserId());
			callableStatement.setString(2, exportRequestVO.getUserType());
			callableStatement.setString(3, exportRequestVO.getOrgId());
			callableStatement.setString(4, exportRequestVO.getCounterPartyOrgId());
			callableStatement.setString(5, exportRequestVO.getCurrencyCode());
			callableStatement.setString(6, exportRequestVO.getPeriodFilter());
			callableStatement.setString(7, exportRequestVO.getBranchFilter());
			callableStatement.setString(8, exportRequestVO.getReportType());
			if(exportRequestVO.getProjSettleDate() != null){
				callableStatement.setDate(9, new java.sql.Date(exportRequestVO.getProjSettleDate().getTime()));
			}else{
				callableStatement.setDate(9,null);
			}
			callableStatement.setString(10, ExportUtil.EXPORT);
			callableStatement.setString(11, exportRequestVO.getExportType());
			if(exportRequestVO.getRecordFrom() != null) {
				callableStatement.setInt(12, exportRequestVO.getRecordFrom());
			} else {
				callableStatement.setNull(12, java.sql.Types.INTEGER);
			}
			if(exportRequestVO.getRecordTo() != null) {
				callableStatement.setInt(13, exportRequestVO.getRecordTo());
			} else {
				callableStatement.setNull(13, java.sql.Types.INTEGER);
			}
			callableStatement.setString(15, exportRequestVO.getErrorFlag());
			
			callableStatement.registerOutParameter(14, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(15, java.sql.Types.VARCHAR);
			callableStatement.execute();
			String errrorCode = (String) callableStatement.getObject(15);
        	if(errrorCode!=null && (errrorCode.equalsIgnoreCase("93000172"))){
        		log.debug("Threshold limt exceeds for Export - Transaction");
        		throw new BNPApplicationException(93000172 , errrorCode);
        	}
			rs = (ResultSet) callableStatement.getObject(14);
			log.debug("Time taken for Database call -->>" +(System.currentTimeMillis()-strTime));
			ResultSetMetaData rsmd = rs.getMetaData();
	    	exportRecords(rs,rsmd,exportRequestVO, prop,outputStream,buffer);
	    	
		} catch (Exception e) {
			if(e instanceof BNPApplicationException){
				BNPApplicationException bnpError = (BNPApplicationException) e;
				log.error("Exception Occured in Settlemnt Due Reminder exportReportsData"+ bnpError.getErrorCode());
				throw new BNPApplicationException(bnpError.getErrorCode(), bnpError.getMessage());
			}else{
				log.error("Exception Occured in Settlemnt Due Reminder exportReportsData" + e.getMessage());
				throw new BNPApplicationException(9100103, e.getMessage());
			}}
		finally {
			if(rs != null){
        		try {
        			rs.close();
        		} catch (SQLException e) {
        			log.error("Exception Occured in Settlemnt Due Reminder exportReportsData" + e.getMessage());
        		}
        	}
			if (callableStatement != null) {
				try {
					callableStatement.close();
				} catch (SQLException e) {
					log.error("Exception Occured in Settlemnt Due Reminder exportReportsData" + e.getMessage());
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					log.error("Exception Occured in Settlemnt Due Reminder exportReportsData" + e.getMessage());
				}
			}
		}
	}
	/**
	 * This method for getting reports export
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException
	 * @see com.bnp.bnpux.service.getExportPaymentReportsData(com.bnp.bnpux.vo.requestVO.ExportRequestVO, javax.servlet.ServletOutputStream, byte[])
	 * @Description Get Reports for Export
	 */
	@Override
	public void getExportPaymentReportsData(ExportRequestVO exportVO,
			ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException,
			IOException {
		try {
			setExportDelimiterValue(exportVO.getExportType());
			exportPaymentReportsData(exportVO,outputStream,buffer);
		} catch (BNPApplicationException e) {
			throw new BNPApplicationException(e.getErrorCode(),e.getMessage());
		}
		
	}
	//CMA
	/**
	 * This method for getting reports export
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException
	 * @see com.bnp.bnpux.service.IExportService#exportPaymentReportsData(com.bnp.bnpux.vo.requestVO.ExportRequestVO, javax.servlet.ServletOutputStream, byte[])
	 * @Description Get Reports for Export
	 */
	
	public void exportPaymentReportsData(ExportRequestVO exportRequestVO, ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException, IOException {
		log.debug("For Export Reports Screen ");
		Connection con = null;
		ResultSet rs = null;
		try{
			con = getConnection();
		}catch(Exception bnp){
			log.error(1000010 + "    Could not get Connection");
			throw new BNPApplicationException(1000010,"SQLException: " + "    Could not get Connection");
		}
		CallableStatement callableStatement = null;
		Properties prop = ExportUtil.getProperties(exportRequestVO);
		try {long strTime = System.currentTimeMillis();
		callableStatement = con.prepareCall("{call pkg_reports.prc_avlble_pymt_rpt_summary( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?)}"); // Modified for Sonar Fix
		callableStatement.setString(1, exportRequestVO.getUserId());
		callableStatement.setString(2, exportRequestVO.getUserType());
		callableStatement.setString(3, exportRequestVO.getOrgId());
		callableStatement.setString(4, exportRequestVO.getCounterPartyOrgId());
		callableStatement.setString(5, exportRequestVO.getCurrencyCode());
		
		if(exportRequestVO.getFromDate() != null){
			callableStatement.setDate(6, new java.sql.Date(exportRequestVO.getFromDate().getTime()));
		}else{
			callableStatement.setDate(6,null);
		}
		if(exportRequestVO.getToDate() != null){
			callableStatement.setDate(7, new java.sql.Date(exportRequestVO.getToDate().getTime()));
		}else{
			callableStatement.setDate(7,null);
		}
		callableStatement.setString(8, exportRequestVO.getPeriodFilter());
		callableStatement.setString(9, exportRequestVO.getBranchFilter());
		callableStatement.setString(10, exportRequestVO.getReportType());
		
		callableStatement.setString(11, ExportUtil.EXPORT);
		callableStatement.setString(12, exportRequestVO.getExportType());
		if(exportRequestVO.getRecordFrom() != null) {
			callableStatement.setInt(13, exportRequestVO.getRecordFrom());
		} else {
			callableStatement.setNull(13, java.sql.Types.INTEGER);
		}
		if(exportRequestVO.getRecordTo() != null) {
			callableStatement.setInt(14, exportRequestVO.getRecordTo());
		} else {
			callableStatement.setNull(14, java.sql.Types.INTEGER);
		}
		callableStatement.setString(16, exportRequestVO.getErrorFlag());
		
		callableStatement.registerOutParameter(15, OracleTypes.CURSOR);
		callableStatement.registerOutParameter(16, java.sql.Types.VARCHAR);
		callableStatement.execute();
		String errrorCode = (String) callableStatement.getObject(16);
    	if(errrorCode!=null && (errrorCode.equalsIgnoreCase("93000172"))){
    		log.debug("Threshold limt exceeds for Export - Transaction");
    		throw new BNPApplicationException(93000172 , errrorCode);
    	}
		rs = (ResultSet) callableStatement.getObject(15);
		log.debug("Time taken for Database call -->>" +(System.currentTimeMillis()-strTime));
		ResultSetMetaData rsmd = rs.getMetaData();
    	exportRecords(rs,rsmd,exportRequestVO, prop,outputStream,buffer);
    	} catch (Exception e) {
			if(e instanceof BNPApplicationException){
				BNPApplicationException bnpError = (BNPApplicationException) e;
				log.error("Exception Occured in Payment exportReportsData"+ bnpError.getErrorCode());
				throw new BNPApplicationException(bnpError.getErrorCode(), bnpError.getMessage());
			}else{
				log.error("Exception Occured in Payment exportReportsData" + e.getMessage());
				throw new BNPApplicationException(9100103, e.getMessage());
			}}
		finally {
			if(rs != null){
        		try {
        			rs.close();
        		} catch (SQLException e) {
        			log.error("Exception Occured in Payment exportReportsData" + e.getMessage());
        		}
        	}
			if (callableStatement != null) {
				try {
					callableStatement.close();
				} catch (SQLException e) {
					log.error("Exception Occured in Payment exportReportsData" + e.getMessage());
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					log.error("Exception Occured in Payment exportReportsData" + e.getMessage());
				}
			}
		}
	}
	
	/**
	 * This method for exporting reports data
	 * 
	 * @param exportRequestVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException 
	 * @Description Export the Report Data
	 */
	public void exportReportsData(ExportRequestVO exportRequestVO, ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException, IOException {
		log.debug("For Export Reports Screen ");
		Connection con = null;
		ResultSet rs = null;
		try{
		 con = getConnection();
		}catch(Exception bnp){
			log.error(1000010 + "    Could not get Connection");
			throw new BNPApplicationException(1000010,"SQLException: " + "    Could not get Connection");
		}
		CallableStatement callableStatement = null;
		Properties prop = ExportUtil.getProperties(exportRequestVO);
		try {
			long strTime = System.currentTimeMillis();
			callableStatement = con.prepareCall("{call pkg_reports.prc_upld_inv_cn_summary( ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?,? ,?)}"); // Modified for Sonar Fix
			callableStatement.setString(1, exportRequestVO.getUserId());
			callableStatement.setString(2, exportRequestVO.getUserType());
			callableStatement.setString(3, exportRequestVO.getOrgId());
			callableStatement.setString(4, exportRequestVO.getCounterPartyOrgId());
			callableStatement.setString(5, exportRequestVO.getCurrencyCode());
			if(exportRequestVO.getFromDate() != null){
			callableStatement.setDate(6, new java.sql.Date(exportRequestVO.getFromDate().getTime()));
			}else{
				callableStatement.setDate(6, null);
			}
			if(exportRequestVO.getToDate() != null){
				callableStatement.setDate(7, new java.sql.Date(exportRequestVO.getToDate().getTime()));
				}else{
					callableStatement.setDate(7, null);
				}
			callableStatement.setString(8, exportRequestVO.getStatusFilter());
			if(exportRequestVO.getPeriodFilter().equalsIgnoreCase(ExportUtil.DATE_RANGE)){
				callableStatement.setString(9, null);
			}else{
				callableStatement.setString(9, exportRequestVO.getPeriodFilter());
			}
			callableStatement.setString(10, exportRequestVO.getBranchFilter());
			callableStatement.setString(11, exportRequestVO.getFileFilter());
			callableStatement.setString(12, ExportUtil.EXPORT);
			callableStatement.setString(13, exportRequestVO.getExportType());
			callableStatement.registerOutParameter(14, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(15, java.sql.Types.VARCHAR);
			callableStatement.execute();
			String errrorCode = (String) callableStatement.getObject(15);
        	if(errrorCode!=null && (errrorCode.equalsIgnoreCase("93000172"))){
        		log.debug("Threshold limt exceeds for Export - Transaction");
        		throw new BNPApplicationException(93000172 , errrorCode);
        	}
			rs = (ResultSet) callableStatement.getObject(14);
			log.debug("Time taken for Database call -->>" +(System.currentTimeMillis()-strTime));
			ResultSetMetaData rsmd = rs.getMetaData();
	    	exportRecords(rs,rsmd,exportRequestVO, prop,outputStream,buffer);
	    	
		} catch (Exception e) {
			if(e instanceof BNPApplicationException){
				BNPApplicationException bnpError = (BNPApplicationException) e;
				log.error("Exception Occured in exportReportsData"+ bnpError.getErrorCode());
				throw new BNPApplicationException(bnpError.getErrorCode(), bnpError.getMessage());
			}else{
				log.error("Exception Occured in exportReportsData" + e.getMessage());
				throw new BNPApplicationException(9100103, e.getMessage());
			}
		}
		finally {
			if(rs != null){
        		try {
        			rs.close();

        		} catch (SQLException e) {
        			//throw new BNPApplicationException(e.getErrorCode(),"SQLException: " + e.getMessage()); // Modified for Sonar Fix
        			log.error("Exception Occured in exportReportsData" + e.getMessage()); // Modified for Sonar Fix
        		}
        	}
			if (callableStatement != null) {
				try {
					callableStatement.close();

				} catch (SQLException e) {
					//throw new BNPApplicationException(e.getErrorCode(),"SQLException: " + e.getMessage());// Modified for Sonar Fix
					log.error("Exception Occured in exportReportsData" + e.getMessage());// Modified for Sonar Fix
					
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					//throw new BNPApplicationException(e.getErrorCode(),"SQLException: " + e.getMessage());// Modified for Sonar Fix
					log.error("Exception Occured in exportReportsData" + e.getMessage());// Modified for Sonar Fix
				}
			}
		}
	}
	
	/**
	 * This method for exporting reports data
	 * 
	 * @param exportRequestVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException 
	 * @Description Export the Report Data
	 */
	public void exportCreditNoteReportsData(ExportRequestVO exportRequestVO, ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException, IOException {
		log.debug("For Export Reports Screen ");
		Connection con = null;
		ResultSet rs = null;
		try{
			con = getConnection();
		}catch(Exception bnp){
			log.error(1000010 + "    Could not get Connection");
			throw new BNPApplicationException(1000010,"SQLException: " + "    Could not get Connection");
		}
		CallableStatement callableStatement = null;
		Properties prop = ExportUtil.getProperties(exportRequestVO);
		try {
			long strTime = System.currentTimeMillis();
			callableStatement = con.prepareCall("{call pkg_reports.prc_cn_inq_summary( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?)}"); // Modified for Sonar Fix
			callableStatement.setString(1, exportRequestVO.getUserId());
			callableStatement.setString(2, exportRequestVO.getUserType());
			callableStatement.setString(3, exportRequestVO.getBuyerOrgId());
			callableStatement.setString(4, exportRequestVO.getSupplierOrgId());
			callableStatement.setString(5, exportRequestVO.getCurrencyCode());
			if(exportRequestVO.getFromDate() != null){
				callableStatement.setDate(6, new java.sql.Date(exportRequestVO.getFromDate().getTime()));
			}else{
				callableStatement.setDate(6, null);
			}
			if(exportRequestVO.getToDate() != null){
				callableStatement.setDate(7, new java.sql.Date(exportRequestVO.getToDate().getTime()));
			}else{
				callableStatement.setDate(7, null);
			}
			callableStatement.setBigDecimal(8, exportRequestVO.getFromAmount());
			callableStatement.setBigDecimal(9, exportRequestVO.getToAmount());
			callableStatement.setString(10, exportRequestVO.getStatusFilter());
			if(null != exportRequestVO.getPeriodFilter() && exportRequestVO.getPeriodFilter().equalsIgnoreCase(ExportUtil.DATE_RANGE)){
				callableStatement.setString(11, null);
			}else{
				callableStatement.setString(11, exportRequestVO.getPeriodFilter());
			}
			callableStatement.setString(12, exportRequestVO.getBranchFilter());
			callableStatement.setString(13, ExportUtil.EXPORT);
			callableStatement.setString(14, exportRequestVO.getExportType());
			if(exportRequestVO.getRecordFrom() != null) {
				callableStatement.setInt(15, exportRequestVO.getRecordFrom());
			} else {
				callableStatement.setNull(15, java.sql.Types.INTEGER);
			}
			if(exportRequestVO.getRecordTo() != null) {
				callableStatement.setInt(16, exportRequestVO.getRecordTo());
			} else {
				callableStatement.setNull(16, java.sql.Types.INTEGER);
			}
			callableStatement.setString(17, exportRequestVO.getCreditNoteRefNum());
			callableStatement.setString(18, exportRequestVO.getUtilizationRefNum());
			callableStatement.setString(20, exportRequestVO.getErrorFlag());
			
			callableStatement.registerOutParameter(19, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(20, java.sql.Types.VARCHAR);
			callableStatement.execute();
			String errrorCode = (String) callableStatement.getObject(20);
        	if(errrorCode!=null && (errrorCode.equalsIgnoreCase("93000172"))){
        		log.debug("Threshold limt exceeds for Export - Transaction");
        		throw new BNPApplicationException(93000172 , errrorCode);
        	}
			rs = (ResultSet) callableStatement.getObject(19);
			log.debug("Time taken for Database call -->>" +(System.currentTimeMillis()-strTime));
			ResultSetMetaData rsmd = rs.getMetaData();
	    	exportRecords(rs,rsmd,exportRequestVO, prop,outputStream,buffer);
	    	
		} catch (Exception e) {
			if(e instanceof BNPApplicationException){
				BNPApplicationException bnpError = (BNPApplicationException) e;
				log.error("Exception Occured in exportReportsData"+ bnpError.getErrorCode());
				throw new BNPApplicationException(bnpError.getErrorCode(), bnpError.getMessage());
			}else{
				log.error("Exception Occured in exportReportsData" + e.getMessage());
				throw new BNPApplicationException(9100103, e.getMessage());
			}
		}
		finally {
			if(rs != null){
        		try {
        			rs.close();
        		} catch (SQLException e) {
        			log.error("Exception Occured in exportReportsData" + e.getMessage());
        		}
        	}
			if (callableStatement != null) {
				try {
					callableStatement.close();
				} catch (SQLException e) {
					log.error("Exception Occured in exportReportsData" + e.getMessage());
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					log.error("Exception Occured in exportReportsData" + e.getMessage());
				}
			}
		}
	}
	
	/**
	 * This method for getting View Scheduled Reports Export data
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException
	 * @see com.bnp.bnpux.service.IExportService#getRemittanceReportsExport(com.bnp.bnpux.vo.requestVO.ExportRequestVO, javax.servlet.ServletOutputStream, byte[])
	 * @Description Get Reports for Export
	 */
	
	public void exportRemittanceReportsData(ExportRequestVO exportRequestVO, ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException, IOException {
		log.debug("For Export Reports Screen ");
		Connection con = null;
		ResultSet rs = null;
		try{
			con = getConnection();
		}catch(Exception bnp){
			log.error(1000010 + "    Could not get Connection");
			throw new BNPApplicationException(1000010,"SQLException: " + "    Could not get Connection");
		}
		CallableStatement callableStatement = null;
		Properties prop = ExportUtil.getProperties(exportRequestVO);
		try {
			long strTime = System.currentTimeMillis();
			callableStatement = con.prepareCall("{call pkg_reports.prc_remit_report( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}"); // Modified for Sonar Fix
			callableStatement.setString(1, exportRequestVO.getUserId());
			callableStatement.setString(2, exportRequestVO.getUserType());
			callableStatement.setString(3, exportRequestVO.getBranchFilter());
			callableStatement.setString(4, exportRequestVO.getBuyerOrgId());
			callableStatement.setString(5, exportRequestVO.getSupplierOrgId());
			if(null != exportRequestVO.getPeriodFilter() && exportRequestVO.getPeriodFilter().equalsIgnoreCase(ExportUtil.DATE_RANGE)){
				callableStatement.setString(6, null);
			}else{
				callableStatement.setString(6, exportRequestVO.getPeriodFilter());
			}
			if(exportRequestVO.getFromDate() != null){
				callableStatement.setDate(7, new java.sql.Date(exportRequestVO.getFromDate().getTime()));
			}else{
				callableStatement.setDate(7, null);
			}
			if(exportRequestVO.getToDate() != null){
				callableStatement.setDate(8, new java.sql.Date(exportRequestVO.getToDate().getTime()));
			}else{
				callableStatement.setDate(8, null);
			}
			callableStatement.setString(9, exportRequestVO.getCurrencyCode());
			callableStatement.setString(10, exportRequestVO.getReportType());
			callableStatement.setString(11, exportRequestVO.getGetWhat());
			callableStatement.setString(12, exportRequestVO.getExportType());
			callableStatement.setString(13, exportRequestVO.getChartName());
			if(exportRequestVO.getRecordFrom() != null) {
				callableStatement.setInt(14, exportRequestVO.getRecordFrom());
			} else {
				callableStatement.setNull(14, java.sql.Types.INTEGER);
			}
			if(exportRequestVO.getRecordTo() != null) {
				callableStatement.setInt(15, exportRequestVO.getRecordTo());
			} else {
				callableStatement.setNull(15, java.sql.Types.INTEGER);
			}
			callableStatement.setString(16, null);
			callableStatement.setString(17, null);
			
			
			//callableStatement.setString(18, exportRequestVO.getErrorFlag());
			
			callableStatement.registerOutParameter(18, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(19, java.sql.Types.VARCHAR);
			callableStatement.execute();
			String errrorCode = (String) callableStatement.getObject(19);
        	if(errrorCode!=null && (errrorCode.equalsIgnoreCase("93000172"))){
        		log.debug("Threshold limt exceeds for Export - Transaction");
        		throw new BNPApplicationException(93000172 , errrorCode);
        	}
			rs = (ResultSet) callableStatement.getObject(18);
			log.debug("Time taken for Database call -->>" +(System.currentTimeMillis()-strTime));
			ResultSetMetaData rsmd = rs.getMetaData();
	    	exportRecords(rs,rsmd,exportRequestVO, prop,outputStream,buffer);
	    	
		} catch (Exception e) {
			if(e instanceof BNPApplicationException){
				BNPApplicationException bnpError = (BNPApplicationException) e;
				log.error("Exception Occured in exportReportsData"+ bnpError.getErrorCode());
				throw new BNPApplicationException(bnpError.getErrorCode(), bnpError.getMessage());
			}else{
				log.error("Exception Occured in exportReportsData" + e.getMessage());
				throw new BNPApplicationException(9100103, e.getMessage());
			}
		}
		finally {
			if(rs != null){
        		try {
        			rs.close();
        		} catch (SQLException e) {
        			log.error("Exception Occured in exportReportsData" + e.getMessage());
        		}
        	}
			if (callableStatement != null) {
				try {
					callableStatement.close();
				} catch (SQLException e) {
					log.error("Exception Occured in exportReportsData" + e.getMessage());
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					log.error("Exception Occured in exportReportsData" + e.getMessage());
				}
			}
		}
	}

	//S39801 :Limit Util Report
	/**
	 * This method for exporting reports data
	 * 
	 * @param exportRequestVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException 
	 * @Description Export the Limit Utilization Report Data
	 */
	public void exportLimitUtilReportsData(ExportRequestVO exportRequestVO, ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException, IOException {
		log.debug("For Export Reports Screen ");
		Connection con = null;
		ResultSet rs = null;
		try{
			con = getConnection();
		}catch(Exception bnp){
			log.error(1000010 + "    Could not get Connection");
			throw new BNPApplicationException(1000010,"SQLException: " + "    Could not get Connection");
		}
		CallableStatement callableStatement = null;
		Properties prop = ExportUtil.getProperties(exportRequestVO);
		try {
			long strTime = System.currentTimeMillis();
			callableStatement = con.prepareCall("{call pkg_reports.prc_limit_util_rpt_summary( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}"); // Modified for Sonar Fix
			callableStatement.setString(1, exportRequestVO.getUserId());
			callableStatement.setString(2, exportRequestVO.getUserType());
			callableStatement.setString(3, exportRequestVO.getBranchFilter());
			callableStatement.setString(4, exportRequestVO.getOrgId()); 
			callableStatement.setString(5, exportRequestVO.getCounterPartyOrgId());
			callableStatement.setString(6, exportRequestVO.getLimitType());
			callableStatement.setString(7, exportRequestVO.getCurrencyCode());
			callableStatement.setString(8, ExportUtil.EXPORT);
			callableStatement.setString(9, exportRequestVO.getExportType());
			if(exportRequestVO.getRecordFrom() != null) {
				callableStatement.setInt(10, exportRequestVO.getRecordFrom());
			} else {
				callableStatement.setNull(10, java.sql.Types.INTEGER);
			}
			if(exportRequestVO.getRecordTo() != null) {
				callableStatement.setInt(11, exportRequestVO.getRecordTo());
			} else {
				callableStatement.setNull(11, java.sql.Types.INTEGER);
			}
			callableStatement.setNull(12, java.sql.Types.VARCHAR);
			callableStatement.setNull(13, java.sql.Types.VARCHAR);
			callableStatement.setNull(14, java.sql.Types.VARCHAR);
			callableStatement.setNull(15, java.sql.Types.VARCHAR);
			
			callableStatement.setString(17, exportRequestVO.getErrorFlag());
			
			callableStatement.registerOutParameter(16, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(17, java.sql.Types.VARCHAR);
			callableStatement.execute();
			String errrorCode = (String) callableStatement.getObject(17);
        	if(errrorCode!=null && (errrorCode.equalsIgnoreCase("93000172"))){
        		log.debug("Threshold limt exceeds for Export - Transaction");
        		throw new BNPApplicationException(93000172 , errrorCode);
        	}
			rs = (ResultSet) callableStatement.getObject(16);
			log.debug("Time taken for Database call -->>" +(System.currentTimeMillis()-strTime));
			ResultSetMetaData rsmd = rs.getMetaData();
	    	exportRecords(rs,rsmd,exportRequestVO, prop,outputStream,buffer);
	    	
		} catch (Exception e) {
			if(e instanceof BNPApplicationException){
				BNPApplicationException bnpError = (BNPApplicationException) e;
				log.error("Exception Occured in exportReportsData"+ bnpError.getErrorCode());
				throw new BNPApplicationException(bnpError.getErrorCode(), bnpError.getMessage());
			}else{
				log.error("Exception Occured in exportReportsData" + e.getMessage());
				throw new BNPApplicationException(9100103, e.getMessage());
			}
		}
		finally {
			if(rs != null){
        		try {
        			rs.close();
        		} catch (SQLException e) {
        			log.error("Exception Occured in exportReportsData" + e.getMessage());
        		}
        	}
			if (callableStatement != null) {
				try {
					callableStatement.close();
				} catch (SQLException e) {
					log.error("Exception Occured in exportReportsData" + e.getMessage());
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					log.error("Exception Occured in exportReportsData" + e.getMessage());
				}
			}
		}
	}

	/**
	 * This method for exporting reports data
	 * 
	 * @param exportRequestVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException 
	 * @Description Export the Discount Transaction Report Data
	 */
	public void exportDiscTransReportsData(ExportRequestVO exportRequestVO, ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException, IOException {
		log.debug("For Export Reports Screen ");
		Connection con = null;
		ResultSet rs = null;
		try{
			con = getConnection();
		}catch(Exception bnp){
			log.error(1000010 + "    Could not get Connection");
			throw new BNPApplicationException(1000010,"SQLException: " + "    Could not get Connection");
		}
		CallableStatement callableStatement = null;
		Properties prop = ExportUtil.getProperties(exportRequestVO);
		try {
			long strTime = System.currentTimeMillis();
			callableStatement = con.prepareCall("{call pkg_reports.prc_disc_trn_report( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}"); // Modified for Sonar Fix
			callableStatement.setString(1, exportRequestVO.getUserId());
			callableStatement.setString(2, exportRequestVO.getUserType());
			callableStatement.setString(3, exportRequestVO.getBuyerOrgId());
			callableStatement.setString(4, exportRequestVO.getSupplierOrgId()); 
			callableStatement.setString(5, exportRequestVO.getCurrencyCode());
			if(exportRequestVO.getFromDate() != null){
				callableStatement.setDate(6, new java.sql.Date(exportRequestVO.getFromDate().getTime()));
			}else{
				callableStatement.setDate(6, null);
			}
			if(exportRequestVO.getToDate() != null){
				callableStatement.setDate(7, new java.sql.Date(exportRequestVO.getToDate().getTime()));
			}else{
				callableStatement.setDate(7, null);
			}
			if(exportRequestVO.getFromMDate() != null){
				callableStatement.setDate(8, new java.sql.Date(exportRequestVO.getFromMDate().getTime()));
			}else{
				callableStatement.setDate(8, null);
			}
			if(exportRequestVO.getToMDate() != null){
				callableStatement.setDate(9, new java.sql.Date(exportRequestVO.getToMDate().getTime()));
			}else{
				callableStatement.setDate(9, null);
			}
			callableStatement.setBigDecimal(10, exportRequestVO.getFromAmount());
			callableStatement.setBigDecimal(11, exportRequestVO.getToAmount());
			callableStatement.setString(12, exportRequestVO.getStatusFilter());
			if(null != exportRequestVO.getPeriodFilter() && exportRequestVO.getPeriodFilter().equalsIgnoreCase(ExportUtil.DATE_RANGE)){
				callableStatement.setString(13, null);
			}else{
				callableStatement.setString(13, exportRequestVO.getPeriodFilter());
			}
			callableStatement.setString(14, exportRequestVO.getBranchFilter());
			callableStatement.setString(15, ExportUtil.EXPORT);
			callableStatement.setString(16, exportRequestVO.getExportType());
			if(exportRequestVO.getRecordFrom() != null) {
				callableStatement.setInt(17, exportRequestVO.getRecordFrom());
			} else {
				callableStatement.setNull(17, java.sql.Types.INTEGER);
			}
			if(exportRequestVO.getRecordTo() != null) {
				callableStatement.setInt(18, exportRequestVO.getRecordTo());
			} else {
				callableStatement.setNull(18, java.sql.Types.INTEGER);
			}
			
			callableStatement.setString(20, exportRequestVO.getErrorFlag());
			
			callableStatement.registerOutParameter(19, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(20, java.sql.Types.VARCHAR);
			callableStatement.execute();
			String errrorCode = (String) callableStatement.getObject(20);
        	if(errrorCode!=null && (errrorCode.equalsIgnoreCase("93000172"))){
        		log.debug("Threshold limt exceeds for Export - Transaction");
        		throw new BNPApplicationException(93000172 , errrorCode);
        	}
			rs = (ResultSet) callableStatement.getObject(19);
			log.debug("Time taken for Database call -->>" +(System.currentTimeMillis()-strTime));
			ResultSetMetaData rsmd = rs.getMetaData();
	    	exportRecords(rs,rsmd,exportRequestVO, prop,outputStream,buffer);
	    	
		} catch (Exception e) {
			if(e instanceof BNPApplicationException){
				BNPApplicationException bnpError = (BNPApplicationException) e;
				log.error("Exception Occured in exportReportsData"+ bnpError.getErrorCode());
				throw new BNPApplicationException(bnpError.getErrorCode(), bnpError.getMessage());
			}else{
				log.error("Exception Occured in exportReportsData" + e.getMessage());
				throw new BNPApplicationException(9100103, e.getMessage());
			}
		}
		finally {
			if(rs != null){
        		try {
        			rs.close();
        		} catch (SQLException e) {
        			log.error("Exception Occured in exportReportsData" + e.getMessage());
        		}
        	}
			if (callableStatement != null) {
				try {
					callableStatement.close();
				} catch (SQLException e) {
					log.error("Exception Occured in exportReportsData" + e.getMessage());
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					log.error("Exception Occured in exportReportsData" + e.getMessage());
				}
			}
		}
	}	
	
	/**
	 * This method for getting Transaction export data
	 * 
	 * @param exportRequestVO
	 * @param outputStream
	 * @throws IOException
	 * @throws BNPApplicationException 
	 * @Description get Transaction Export Data
	 */
	public void getTransactionExportData(ExportRequestVO exportRequestVO, ServletOutputStream outputStream) throws IOException, BNPApplicationException {
		  Connection con = null;
		  ResultSet rs = null;
			try{
			 con = getConnection();
			}catch(Exception bnp){
				log.error(1000010 + "    Could not get Connection");
				throw new BNPApplicationException(1000010,"SQLException: " + "    Could not get Connection");
			}
	        CallableStatement callableStatement = null;
	        Properties prop = ExportUtil.getProperties(exportRequestVO);
	        try {
	        	callableStatement = con.prepareCall("{call pkg_transaction_dashboard.prc_trans_export( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");// Modified for Sonar Fix
	        	callableStatement.setString(1, exportRequestVO.getUserId());
	        	callableStatement.setString(2, exportRequestVO.getUserType());
	        	callableStatement.setString(3, exportRequestVO.getGroupIndicator());
	        	callableStatement.setString(4, exportRequestVO.getLeadOrgId());
	        	callableStatement.setString(5, exportRequestVO.getBuyerRefNoUniqueValue());
	        	callableStatement.setString(6, exportRequestVO.getPaymentFlagValue());
	        	callableStatement.setString(7, exportRequestVO.getStatusFilter());
	        	callableStatement.setString(8, exportRequestVO.getPeriodFilter());
	        	callableStatement.setString(9, exportRequestVO.getBranchFilter());
	        	callableStatement.setString(10, exportRequestVO.getQuickSearch());
	        	callableStatement.setString(11, exportRequestVO.getExportType());
	        	if(exportRequestVO.getAdvancedFilterListVO() != null && exportRequestVO.getAdvancedFilterListVO().size() > 0)
	            	callableStatement.setObject(12, this.getStructValue(con, exportRequestVO), OracleTypes.ARRAY);
	        	else
	        		callableStatement.setNull(12,OracleTypes.STRUCT, "TB_OBJ_ADV_FLTR");
	        	callableStatement.registerOutParameter(13, OracleTypes.CURSOR);
	        	callableStatement.registerOutParameter(14, java.sql.Types.VARCHAR);
	        	long strTime = System.currentTimeMillis();
	        	callableStatement.execute();
	        	String errrorCode = (String) callableStatement.getObject(14);
	        	if(errrorCode!=null && (errrorCode.equalsIgnoreCase("93000172"))){
	        		log.debug("Threshold limt exceeds for Export - Transaction");
	        		throw new BNPApplicationException(93000172 , errrorCode);
	        	}
	        	log.debug("Time taken for Database call -->>" +(System.currentTimeMillis()-strTime));
	        	rs = (ResultSet) callableStatement.getObject(13);
	        	ResultSetMetaData rsmd = rs.getMetaData();
	        	exportRecords(rs,rsmd,exportRequestVO, prop,outputStream,null);
	        } catch (Exception e) {
	        	if(e instanceof BNPApplicationException){
					BNPApplicationException bnpError = (BNPApplicationException) e;
					log.error("Exception Occured in getTransactionExportData"+ bnpError.getErrorCode());
					throw new BNPApplicationException(bnpError.getErrorCode(), bnpError.getMessage());
				}else{
					log.error("Exception Occured in getTransactionExportData" + e.getMessage());
					throw new BNPApplicationException(9100103, e.getMessage());
				}
	        	
	        }
	        finally {
	        	if(rs != null){
	        		try {
	        			rs.close();

	        		} catch (SQLException e) {
	        			//throw new BNPApplicationException(e.getErrorCode(),"SQLException: " + e.getMessage()); // Modified for Sonar Fix
	        			log.error("Exception Occured in getTransactionExportData" + e.getMessage()); // Modified for Sonar Fix
	        		}
	        	}

				if (callableStatement != null) {
					try {
						callableStatement.close();

					} catch (SQLException e) {
						//throw new BNPApplicationException(e.getErrorCode(),"SQLException: " + e.getMessage());// Modified for Sonar Fix
	        			log.error("Exception Occured in getTransactionExportData" + e.getMessage()); // Modified for Sonar Fix
					}
				}
				if (con != null) {
					try {
						con.close();
					} catch (SQLException e) {
						//throw new BNPApplicationException(e.getErrorCode(),"SQLException: " + e.getMessage());// Modified for Sonar Fix
						log.error("Exception Occured in getTransactionExportData" + e.getMessage()); // Modified for Sonar Fix
					}
				}
			}

		}

			/**
			 * Method used to Create Struct for Advanced Filter object 
			 * @param con
			 * @param exportRequestVO
			 * @return
			 * @throws SQLException 
			 */
			public ARRAY getStructValue(Connection con,ExportRequestVO exportRequestVO) throws SQLException, BNPApplicationException{
				con= DriverManager.getConnection("jdbc:oracle:thin:@10.184.153.184:1521: orcl","rel10_st2","o");		
				//STRUCT mySTRUCT = new STRUCT ()
				 ARRAY oracleArray = null;
				List<AdvancedFilterVO> advancedFilterListParameterVO = (List<AdvancedFilterVO>) exportRequestVO.getAdvancedFilterListVO();
				try{
					  StructDescriptor structDescriptor = StructDescriptor.createDescriptor("OBJ_ADV_FLTR", con);			     
					  STRUCT[] structs = new STRUCT[advancedFilterListParameterVO.size()];			       
					  @SuppressWarnings("unchecked")
					  List<AdvancedFilterVO> advancedFilterListVO = (List<AdvancedFilterVO>) exportRequestVO.getAdvancedFilterListVO();				
					  for(int index = 0; index < advancedFilterListParameterVO.size(); index++) {
				        	AdvancedFilterVO obj = advancedFilterListVO.get(index);
				            Object[] params = new Object[6];
				            params[0] = obj.getAdvanceFilterId();
				            params[1] = obj.getOperatorId();
				            params[2] = null;
				            params[3] = obj.getFilterFromValue();
				            params[4] = obj.getFilterToValue();
				            params[5] = obj.getValueList();
				            STRUCT struct = new STRUCT(structDescriptor, con, params);
				            structs[index] = struct;
					  }
					  ArrayDescriptor desc = ArrayDescriptor.createDescriptor("TB_OBJ_ADV_FLTR",con);
					  oracleArray = new ARRAY(desc, con, structs);
				}catch(Exception e){
					//e.printStackTrace();
					//e.printStackTrace();  Removed for Fortify Findings. FO10.0 
					log.error("Exception Occured in getPaymentOrderExportData" + e.getMessage());
					throw new BNPApplicationException(9100103, e.getMessage());
				}
				return oracleArray;
			}

			/**
			 * This method for getting Payment Order export data
			 * 
			 * @param exportRequestVO
			 * @param outputStream
			 * @throws BNPApplicationException
			 * @throws IOException 
			 * @Description get PaymentOrder Export Data
			 */
			public void getPaymentOrderExportData(ExportRequestVO exportRequestVO, ServletOutputStream outputStream) throws BNPApplicationException, IOException {
				Connection con = null;
				ResultSet rs = null;
				try{
				 con = getConnection();
				}catch(Exception bnp){
					log.error(1000010 + "    Could not get Connection");
					throw new BNPApplicationException(1000010,"SQLException: " + "    Could not get Connection");
				}
				CallableStatement callableStatement = null;
				Properties prop = ExportUtil.getProperties(exportRequestVO);
				
				ARRAY oracleArray = null;
				if(exportRequestVO.getAdvancedFilterListVO() != null){
					try{
						oracleArray = this.getStructValue(con,exportRequestVO);
					}catch(Exception e){
						//e.printStackTrace();  Removed for Fortify Findings. FO10.0 
						log.error("Exception Occured in getPaymentOrderExportData" + e.getMessage());
						throw new BNPApplicationException(9100103, e.getMessage());
					}
				}
				
				try {
					callableStatement = con.prepareCall("{call pkg_pymt_order_dashboard.prc_pymt_order_export( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,? )}"); // Modified for Sonar Fix
					callableStatement.setString(1, exportRequestVO.getUserId());
					callableStatement.setString(2, exportRequestVO.getUserType());
					callableStatement.setString(3, exportRequestVO.getDiscountRefNumber());
					callableStatement.setString(4, exportRequestVO.getGroupIndicator());
					callableStatement.setString(5, exportRequestVO.getStatusFilter());
					callableStatement.setString(6, exportRequestVO.getPeriodFilter());
					callableStatement.setString(7, exportRequestVO.getBranchFilter());
					callableStatement.setString(8, exportRequestVO.getQuickSearch());
					callableStatement.setString(9, exportRequestVO.getExportType());
					if(exportRequestVO.getAdvancedFilterListVO() != null){
						callableStatement.setObject(10, oracleArray,OracleTypes.ARRAY);
					}else{
						callableStatement.setNull(10, OracleTypes.STRUCT,"TB_OBJ_ADV_FLTR");						
					}
					callableStatement.registerOutParameter(11, OracleTypes.CURSOR);
					callableStatement.registerOutParameter(12, java.sql.Types.VARCHAR);
					long strTime = System.currentTimeMillis();
					callableStatement.execute();
					log.debug("Time taken for Database call after -->>" +(System.currentTimeMillis()-strTime));
					String errrorCode = (String) callableStatement.getObject(12);
		        	if(errrorCode!=null && (errrorCode.equalsIgnoreCase("93000172"))){
		        		log.debug("Threshold limt exceeds for Export - payment Order");
		        		throw new BNPApplicationException(93000172 , errrorCode);
		        	}
					rs = (ResultSet) callableStatement.getObject(11);
					ResultSetMetaData rsmd = rs.getMetaData();
        	    	exportRecords(rs,rsmd,exportRequestVO, prop,outputStream,null);
				} catch (Exception e) {
		        	if(e instanceof BNPApplicationException){
						BNPApplicationException bnpError = (BNPApplicationException) e;
						log.error("Exception Occured in getPaymentOrderExportData"+ bnpError.getErrorCode());
						throw new BNPApplicationException(bnpError.getErrorCode(), bnpError.getMessage());
					}else{
						log.error("Exception Occured in getPaymentOrderExportData" + e.getMessage());
						throw new BNPApplicationException(9100103, e.getMessage());
					}
		        	
		        }
				finally {
					if(rs != null){
		        		try {
		        			rs.close();

		        		} catch (SQLException e) {
		        			//throw new BNPApplicationException(e.getErrorCode(),"SQLException: " + e.getMessage()); // Modified for Sonar Fix
		        			log.error("Exception Occured in getPaymentOrderExportData" + e.getMessage()); // Modified for Sonar Fix
		        		}
		        	}
					if (callableStatement != null) {
						try {
							callableStatement.close();

						} catch (SQLException e) {
							//throw new BNPApplicationException(e.getErrorCode(),"SQLException: " + e.getMessage()); // Modified for Sonar Fix
							log.error("Exception Occured in getPaymentOrderExportData" + e.getMessage()); // Modified for Sonar Fix
						}
					}
					if (con != null) {
						try {
							con.close();
						} catch (SQLException e) {
							//throw new BNPApplicationException(e.getErrorCode(),"SQLException: " + e.getMessage()); // Modified for Sonar Fix
							log.error("Exception Occured in getPaymentOrderExportData" + e.getMessage()); // Modified for Sonar Fix
						}
					}
				}
			}


			/**
			 * This method for getting settlement resultset
			 * 
			 * @param exportRequestVO
			 * @param outputStream
			 * @throws BNPApplicationException
			 * @throws IOException 
			 * @Description get Settlement Resultset
			 */
			public void getSettlementResultset(ExportRequestVO exportRequestVO, ServletOutputStream outputStream) throws BNPApplicationException, IOException {
				Connection con = null;
				ResultSet rs = null;
				try{
				 con = getConnection();
				}catch(Exception bnp){
					log.error(1000010 + "    Could not get Connection");
					throw new BNPApplicationException(1000010,"SQLException: " + "    Could not get Connection");
				}
				CallableStatement callableStatement = null;
		        Properties prop = ExportUtil.getProperties(exportRequestVO);
		        ARRAY oracleArray = null;
				if(exportRequestVO.getAdvancedFilterListVO() != null){
					try {
						oracleArray = this.getStructValue(con,exportRequestVO);
					} catch (SQLException e) {						
						//e.printStackTrace(); Removed for Fortify Findings. FO10.0 
						log.error("Exception Occured in getSettlementResultset" + e.getMessage());
						throw new BNPApplicationException(9100103, e.getMessage());
					}
				}
		        try {
		        	callableStatement = con.prepareCall("{call pkg_setlmnt_dashboard.prc_stlmt_export( ?, ?, ?, ?, ?, ?, ?, ?, ?,?,? )}"); // Modified for Sonar Fix
		        	callableStatement.setString(1, exportRequestVO.getUserId());
		        	callableStatement.setString(2, exportRequestVO.getUserType());
		        	callableStatement.setString(3, exportRequestVO.getGroupIndicator());
		        	callableStatement.setString(4, exportRequestVO.getStatusFilter());
		        	callableStatement.setString(5, exportRequestVO.getPeriodFilter());
		        	callableStatement.setString(6, exportRequestVO.getBranchFilter());
		        	callableStatement.setString(7, exportRequestVO.getQuickSearch());
		        	callableStatement.setString(8, exportRequestVO.getExportType());
					callableStatement.setString(11, exportRequestVO.getErrorFlag());
		        	if(exportRequestVO.getAdvancedFilterListVO() != null){
						callableStatement.setObject(9, oracleArray,OracleTypes.ARRAY);
					}else{
						callableStatement.setNull(9, OracleTypes.STRUCT,"TB_OBJ_ADV_FLTR");						
					}
		        	callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
		        	callableStatement.registerOutParameter(11, java.sql.Types.VARCHAR);
		        	long strTime = System.currentTimeMillis();
		        	callableStatement.execute();
		        	log.debug("Time taken for Database call -->>" +(System.currentTimeMillis()-strTime));
		        	String errrorCode = (String) callableStatement.getObject(11);
		        	if(errrorCode!=null && (errrorCode.equalsIgnoreCase("93000172"))){
		        		log.debug("Threshold limt exceeds for Export - Settlement");
		        		throw new BNPApplicationException(93000172 , errrorCode);
		        	}
		        	rs = (ResultSet) callableStatement.getObject(10);
		        	ResultSetMetaData rsmd = rs.getMetaData();
		        	exportRecords(rs,rsmd,exportRequestVO, prop,outputStream,null);
		        } catch (Exception e) {
		        	if(e instanceof BNPApplicationException){
						BNPApplicationException bnpError = (BNPApplicationException) e;
						log.error("Exception Occured in getSettlementResultset"+ bnpError.getErrorCode());
						throw new BNPApplicationException(bnpError.getErrorCode(), bnpError.getMessage());
					}else{
						log.error("Exception Occured in getSettlementResultset" + e.getMessage());
						throw new BNPApplicationException(9100103, e.getMessage());
					}
		        	
		        }
		        finally {

		        	if(rs != null){
		        		try {
		        			rs.close();

		        		} catch (SQLException e) {
		        			//throw new BNPApplicationException(e.getErrorCode(),"SQLException: " + e.getMessage()); // Modified for Sonar Fix
		        			log.error("Exception Occured in getSettlementResultset" + e.getMessage()); // Modified for Sonar Fix
		        		}
		        	}
					if (callableStatement != null) {
						try {
							callableStatement.close();

						} catch (SQLException e) {
							//throw new BNPApplicationException(e.getErrorCode(),"SQLException: " + e.getMessage()); // Modified for Sonar Fix
							log.error("Exception Occured in getSettlementResultset" + e.getMessage()); // Modified for Sonar Fix
						}
					}
					if (con != null) {
						try {
							con.close();
						} catch (SQLException e) {
							//throw new BNPApplicationException(e.getErrorCode(),"SQLException: " + e.getMessage()); // Modified for Sonar Fix
							log.error("Exception Occured in getSettlementResultset" + e.getMessage()); // Modified for Sonar Fix
						}
					}
				}

			}




	/**
	 * This method for exporting records
	 * 
	 * @param rs
	 * @param rsmd
	 * @param exportRequestVO
	 * @param prop
	 * @param outputStream
	 * @param buffer
	 * @throws SQLException
	 * @throws BNPApplicationException
	 * @throws IOException 
	 * @Description Export Records
	 */
	public void exportRecords(ResultSet rs, ResultSetMetaData rsmd, ExportRequestVO exportRequestVO, Properties prop, ServletOutputStream outputStream,byte[] buffer) throws SQLException, BNPApplicationException, IOException {
		try{
			long strTime = System.currentTimeMillis();
			if (exportRequestVO.getExportType().equalsIgnoreCase(ExportUtil.CSV)) {
				
				StringBuilder tempHeader = ExportUtil.getHeaderForCVS(exportRequestVO,prop);
				outputStream.write(tempHeader.toString().getBytes("UTF-8"));
				outputStream.write('\n');
				
				if(!rs.next()){
					throw new BNPApplicationException(30000101, NO_RECORDS);
				}else{
					int columnCnt = rsmd.getColumnCount();
					do{
						for (int i = 1; i <= columnCnt; i++) {
							String sValue = getStringValue(rs.getObject(i));
							
							outputStream.write(sValue.getBytes("UTF-8"));
						}
						outputStream.write('\n');
					}while (rs.next());
				}
				log.debug("Time taken in Service Layer CSV ----> " + (System.currentTimeMillis()-strTime));
				outputStream.flush();
			} else if (exportRequestVO.getExportType().equalsIgnoreCase(ExportUtil.XLS)) {
				setExportType(ExportUtil.XLS);
				SXSSFWorkbook workBook = new SXSSFWorkbook();
				CellStyle cellStyle = workBook.createCellStyle();
				Date dateValue = null;
				int count = 0;
				SXSSFSheet sh = (SXSSFSheet) workBook.createSheet("ExportData");
				Row headerRow = sh.createRow(0);
				ArrayList<String> xlsHeader = ExportUtil.getHeaderForXLS(
						exportRequestVO, prop);
				for (int i = 0; i < xlsHeader.size(); i++) {
					Cell cell = headerRow.createCell(i);
					cell.setCellValue(xlsHeader.get(i));
				}

				if(!rs.next()){
					throw new BNPApplicationException(30000101, NO_RECORDS);
				}else{
					ResultSetMetaData md = rs.getMetaData();					
//					for(int i=1; i<=md.getColumnCount();i++)
//					{
//						log.debug(md.getColumnName(i)+"="+md.getColumnTypeName(i));
//					}
					do{
						count = count + 1;
						Row row = sh.createRow(count);
						for (int cellnum = 0; cellnum < rsmd.getColumnCount(); cellnum++) {
						Cell cell = row.createCell(cellnum);
						// Commented for defect 6396 - Remittance report export xls sheet --- cellStyle = workBook.createCellStyle();
						if(md.getColumnTypeName(cellnum + 1).equals("NUMBER"))
						{
							if(rs.getObject(cellnum + 1) != null)
							{
								cell.setCellType(Cell.CELL_TYPE_NUMERIC);
								cell.setCellValue(Double.valueOf(getStringValue(rs.getObject(cellnum + 1))));
							}
							else
							{
								cell.setCellValue("");
							}
						}else if(md.getColumnTypeName(cellnum + 1).equals("DATE"))
                        {
                            
                            if(rs.getObject(cellnum + 1) != null)
                            {
                                        dateValue = rs.getDate(cellnum+1);
                                        cellStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("m/d/yy"));                                                                                                             
                                        cell.setCellValue(dateValue);
										cell.setCellStyle(cellStyle);
                            }
                            else
                            {
                                        cell.setCellValue("");
                            }
                        }else
						{
							cell.setCellValue(getStringValue(rs.getObject(cellnum + 1)));
						}
						
                        //Apply Style if required
                       /* Commented for defect 6396 - Remittance report export xls sheet 
					   if(cellStyle != null)
                        {
                                    //cell.setCellStyle(cellStyle);
                        }*/
						}
					}while (rs.next());
				}
				log.debug("Time taken in Service Layer XLS ----> " + (System.currentTimeMillis()-strTime));

				try{
				 workBook.write(outputStream);
				 outputStream.flush();
				}finally{
					workBook.dispose();
				}
			}else if (exportRequestVO.getExportType().equalsIgnoreCase(ExportUtil.PDF)) {
				setExportType(ExportUtil.PDF);
				ByteArrayOutputStream pdfOutputStream = null;
				InputStream logoInputStream=null;
				InputStream jasperInputStream = null;
				try {
					 pdfOutputStream = new ByteArrayOutputStream();

					if(exportRequestVO.getPageInfo().equalsIgnoreCase(ExportUtil.PAYMENT_ORDER_PAGE)){
						jasperInputStream = getClass().getClassLoader().getResourceAsStream(ReportConstants.JASPER_PATH+ExportUtil.PaymentReport_PDF+JASPER_EXTN);
					}else if(exportRequestVO.getPageInfo().equalsIgnoreCase(ExportUtil.TRANSACTION_PAGE)){
						jasperInputStream = getClass().getClassLoader().getResourceAsStream(ReportConstants.JASPER_PATH+ExportUtil.TransactionReport_PDF+JASPER_EXTN);
					}else if(exportRequestVO.getPageInfo().equalsIgnoreCase(ExportUtil.SETTLEMENT_PAGE)){
						jasperInputStream = getClass().getClassLoader().getResourceAsStream(ReportConstants.JASPER_PATH+ExportUtil.SettlementReport_PDF+JASPER_EXTN);
					}else if(exportRequestVO.getPageInfo().equalsIgnoreCase(ExportUtil.REPORTS_PAGE)){
						jasperInputStream = getClass().getClassLoader().getResourceAsStream(ReportConstants.JASPER_PATH+ExportUtil.REPORTS_PDF+JASPER_EXTN);
					}else if(exportRequestVO.getPageInfo().equalsIgnoreCase(ExportUtil.CREDIT_NOTE_REPORT)){
						jasperInputStream = getClass().getClassLoader().getResourceAsStream(ReportConstants.JASPER_PATH+ExportUtil.CREDIT_NOTE_REPORT_PDF+JASPER_EXTN);
					}else if(exportRequestVO.getPageInfo().equalsIgnoreCase(ExportUtil.LIMIT_UTIL_REPORT)){
						jasperInputStream = getClass().getClassLoader().getResourceAsStream(ReportConstants.JASPER_PATH+ExportUtil.LIMIT_UTIL_REPORT_PDF+JASPER_EXTN);
					}else if(exportRequestVO.getPageInfo().equalsIgnoreCase(ExportUtil.DISC_TRANS_REPORT)){
						jasperInputStream = getClass().getClassLoader().getResourceAsStream(ReportConstants.JASPER_PATH+ExportUtil.DISC_TRANS_REPORT_PDF+JASPER_EXTN);
					}else if(exportRequestVO.getPageInfo().equalsIgnoreCase(ExportUtil.SETTLEMENT_DUE_REPORT)
							&& exportRequestVO.getReportType().equalsIgnoreCase(ExportUtil.SETTLEMENT_DUE_REPORT_TYPE)){
						if(exportRequestVO.getUserType().equalsIgnoreCase("BA")){
							jasperInputStream = getClass().getClassLoader().getResourceAsStream(ReportConstants.JASPER_PATH+ExportUtil.SETTLEMENT_DUE_REPORT_PDF+JASPER_EXTN);
							}else{
								jasperInputStream = getClass().getClassLoader().getResourceAsStream(ReportConstants.JASPER_PATH+ExportUtil.SETTLEMENT_DUE_REPORT_PDF_FOR_ORG+JASPER_EXTN);}
					}else if(exportRequestVO.getPageInfo().equalsIgnoreCase(ExportUtil.SETTLEMENT_DUE_REPORT) 
							&& exportRequestVO.getReportType().equalsIgnoreCase(ExportUtil.SETTLEMENT_DUE_PRESETTLE_REPORT_TYPE)){
						if(exportRequestVO.getUserType().equalsIgnoreCase("BA")){
							jasperInputStream = getClass().getClassLoader().getResourceAsStream(ReportConstants.JASPER_PATH+ExportUtil.PRE_SETTLEMENT_DUE_REPORT_PDF+JASPER_EXTN);
							}else{
								jasperInputStream = getClass().getClassLoader().getResourceAsStream(ReportConstants.JASPER_PATH+ExportUtil.PRE_SETTLEMENT_DUE_REPORT_PDF_FOR_ORG+JASPER_EXTN);}
					}else if(exportRequestVO.getPageInfo().equalsIgnoreCase(ExportUtil.VIEW_SCHEDULED_REPORT)){
						jasperInputStream = getClass().getClassLoader().getResourceAsStream(ReportConstants.JASPER_PATH+ExportUtil.VIEW_SCHEDULE_REPORT_PDF+JASPER_EXTN);
					}else if(exportRequestVO.getPageInfo().equalsIgnoreCase(ExportUtil.PAYMENT_REPORT)
							&& exportRequestVO.getReportType().equalsIgnoreCase(ExportUtil.AVAILABLE_PAYMENT_REPORT_TYPE)){
						jasperInputStream = getClass().getClassLoader().getResourceAsStream(ReportConstants.JASPER_PATH+ExportUtil.AVAILABLE_PAYMENT_REPORT_PDF+JASPER_EXTN);
					}else if(exportRequestVO.getPageInfo().equalsIgnoreCase(ExportUtil.PAYMENT_REPORT) 
							&& exportRequestVO.getReportType().equalsIgnoreCase(ExportUtil.RECIEVED_PAYMENT_REPORT_TYPE)){
						jasperInputStream = getClass().getClassLoader().getResourceAsStream(ReportConstants.JASPER_PATH+ExportUtil.RECIEVED_PAYMENT_REPORT_PDF+JASPER_EXTN);
					}else if(exportRequestVO.getPageInfo().equalsIgnoreCase(ExportUtil.REMITTANCE_REPORT)){
						jasperInputStream = getClass().getClassLoader().getResourceAsStream(ReportConstants.JASPER_PATH+ExportUtil.REMITTANCE_REPORT_PDF+JASPER_EXTN);
					}else if(exportRequestVO.getPageInfo().equalsIgnoreCase(ExportUtil.AGING_REPORT)){
						jasperInputStream = getClass().getClassLoader().getResourceAsStream(ReportConstants.JASPER_PATH+ExportUtil.AGING_REPORT_PDF+JASPER_EXTN);
					}
					else{
						log.error("Exception in creating inputStream");
						throw new BNPApplicationException(ErrorConstants.REPORT_CREATION_ERROR,"Report Creation Error");
					}

					logoInputStream = getClass().getClassLoader().getResourceAsStream(ReportConstants.IMAGE_PATH);
					HashMap<String, Object> dataMap = new HashMap<String, Object>();
					dataMap.put(BNPLOGO, logoInputStream);
					
					Object result = userPrefDAO.getUserPreferenceInfo(exportRequestVO.getUserId());
					UserPreferenceVO userPrefVO = (UserPreferenceVO) result;
					SimpleDateFormat sdf = new SimpleDateFormat(userPrefVO.getPreferredDateFmt());
					if (null != exportRequestVO.getPageInfo()	&& exportRequestVO.getPageInfo().equals(ExportUtil.REPORTS_PAGE)) {
						InputStream dataInputStream = new ByteArrayInputStream(buffer);
						dataMap.put("chart", dataInputStream);
						
						dataMap.put("clientOrgFilter", exportRequestVO.getOrgId());
						dataMap.put("statusFilter", exportRequestVO.getStatusFilter());
						dataMap.put("ccyFilter", exportRequestVO.getCurrencyCode());
						dataMap.put("branchNameFilter", exportRequestVO.getBranchNameFilter());
						dataMap.put("counterPtyFilter", exportRequestVO.getCounterPartyOrgId());
						dataMap.put("plotParams1", exportRequestVO.getPlotParamValue());
						dataMap.put("fileStatusFilter", exportRequestVO.getFileFilter());
						dataMap.put("selectedPeriodValue", exportRequestVO.getPeriodFilter());
						
						if(exportRequestVO.getFromDate() != null)
						{
							dataMap.put("periodFromDateFilter", sdf.format(exportRequestVO.getFromDate()));
							dataMap.put("periodToDateFilter", sdf.format(exportRequestVO.getToDate()));
						}
						else
						{
							dataMap.put("periodFromDateFilter", "-");
							dataMap.put("periodToDateFilter", "-");
						}
					}
					
					if (null != exportRequestVO.getPageInfo()	&& exportRequestVO.getPageInfo().equals(ExportUtil.CREDIT_NOTE_REPORT)) {
						InputStream dataInputStream = new ByteArrayInputStream(buffer);
						dataMap.put("chart", dataInputStream);
						
						dataMap.put("buyerOrgFilter", exportRequestVO.getBuyerNameFilter());	
						dataMap.put("supplierOrgFilter", exportRequestVO.getSupplierNameFilter()); 
						dataMap.put("statusFilter", exportRequestVO.getStatusNameFilter());
						dataMap.put("ccyFilter", exportRequestVO.getCurrencyCode());
						dataMap.put("branchNameFilter", exportRequestVO.getBranchNameFilter());
						dataMap.put("plotParams1", exportRequestVO.getPlotParamValue());
						dataMap.put("selectedPeriodValue", exportRequestVO.getPeriodNameFilter());
						
						if(exportRequestVO.getFromDate() != null) {
							dataMap.put("periodFromDateFilter", sdf.format(exportRequestVO.getFromDate()));
							dataMap.put("periodToDateFilter", sdf.format(exportRequestVO.getToDate()));
						} else {
							dataMap.put("periodFromDateFilter", "-");
							dataMap.put("periodToDateFilter", "-");
						}
						if(exportRequestVO.getFromAmount() != null) {
							dataMap.put("fromAmountFilter", exportRequestVO.getFromAmountFilter());	
							dataMap.put("toAmountFilter", exportRequestVO.getToAmountFilter()); 
						} else {
							dataMap.put("fromAmountFilter", "-");
							dataMap.put("toAmountFilter", "-");
						}
						
						dataMap.put("creditNoteRefNum", exportRequestVO.getCreditNoteRefNum());
						dataMap.put("utilizationRefNum", exportRequestVO.getUtilizationRefNum());
					}
					

					if (null != exportRequestVO.getPageInfo()	&& exportRequestVO.getPageInfo().equals(ExportUtil.SETTLEMENT_DUE_REPORT)) {
						InputStream dataInputStream = new ByteArrayInputStream(buffer);
						dataMap.put("chart", dataInputStream);
						
						dataMap.put("branchFilter", exportRequestVO.getBranchNameFilter());	
						dataMap.put("currencyCode", exportRequestVO.getCurrencyCode()); 
						dataMap.put("periodFilter", exportRequestVO.getPeriodFilter());
						dataMap.put("reportType", exportRequestVO.getReportTypeName());					
						dataMap.put("orgId", exportRequestVO.getOrgId());
						dataMap.put("counterPartyOrgId", exportRequestVO.getCounterPartyOrgId());
						dataMap.put("plotParams1", exportRequestVO.getPlotParamValue());
						if(exportRequestVO.getProjSettleDate() != null) {
							dataMap.put("projSettleDate", sdf.format(exportRequestVO.getProjSettleDate()));
							
						}
					}
					if (null != exportRequestVO.getPageInfo()	&& exportRequestVO.getPageInfo().equals(ExportUtil.PAYMENT_REPORT)) {
						InputStream dataInputStream = new ByteArrayInputStream(buffer);
						dataMap.put("chart", dataInputStream);
						
						dataMap.put("branchFilter", exportRequestVO.getBranchNameFilter());	
						dataMap.put("currencyCode", exportRequestVO.getCurrencyCode()); 
						dataMap.put("periodFilter", exportRequestVO.getPeriodNameFilter());
						dataMap.put("reportType", exportRequestVO.getReportTypeName());					
						dataMap.put("orgId", exportRequestVO.getOrgId());
						dataMap.put("counterPartyOrgId", exportRequestVO.getCounterPartyOrgId());
						dataMap.put("plotParams1", exportRequestVO.getPlotParamValue());
						if(exportRequestVO.getFromDate() != null) {
							dataMap.put("periodFromDateFilter", sdf.format(exportRequestVO.getFromDate()));
							dataMap.put("periodToDateFilter", sdf.format(exportRequestVO.getToDate()));
						} else {
							dataMap.put("periodFromDateFilter", "-");
							dataMap.put("periodToDateFilter", "-");
						}
					}
					
					if (null != exportRequestVO.getPageInfo()	&& exportRequestVO.getPageInfo().equals(ExportUtil.AGING_REPORT)) {
						dataMap.put("branchNameFilter", exportRequestVO.getBranchFilter());
						dataMap.put("buyerOrgFilter", exportRequestVO.getBuyerOrgId());	
						dataMap.put("supplierOrgFilter", exportRequestVO.getSupplierOrgId()); 
						dataMap.put("ccyFilter", exportRequestVO.getCurrencyCode());
						dataMap.put("duePeriodFilter", exportRequestVO.getDuePeriod());
						dataMap.put("dueInDaysFilter", exportRequestVO.getDueDays());
						dataMap.put("discountType", exportRequestVO.getDiscType());
					}
					

					if (null != exportRequestVO.getPageInfo()	&& exportRequestVO.getPageInfo().equals(ExportUtil.LIMIT_UTIL_REPORT)) {
						InputStream dataInputStream = new ByteArrayInputStream(buffer);
						dataMap.put("chart", dataInputStream);
						dataMap.put("branchNameFilter", exportRequestVO.getBranchNameFilter());
						dataMap.put("clientOrgFilter", exportRequestVO.getOrgIdFilter());	
						dataMap.put("counterPartyOrgFilter", exportRequestVO.getCounterPartyOrgIdFilter()); 
						dataMap.put("limitTypeFilter", exportRequestVO.getLimitTypeFilter());
						dataMap.put("ccyFilter", exportRequestVO.getCurrencyCode());
						dataMap.put("plotParams1", exportRequestVO.getPlotParamValue());
						dataMap.put("chartOrgFilter", exportRequestVO.getLeadOrgIdValue());
					}
					
					if (null != exportRequestVO.getPageInfo()	&& exportRequestVO.getPageInfo().equals(ExportUtil.DISC_TRANS_REPORT)) {
						InputStream dataInputStream = new ByteArrayInputStream(buffer);
						dataMap.put("chart", dataInputStream);
						
						dataMap.put("buyerOrgFilter", exportRequestVO.getBuyerNameFilter());	
						dataMap.put("supplierOrgFilter", exportRequestVO.getSupplierNameFilter()); 
						dataMap.put("statusFilter", exportRequestVO.getStatusNameFilter());
						dataMap.put("ccyFilter", exportRequestVO.getCurrencyCode());
						dataMap.put("branchNameFilter", exportRequestVO.getBranchNameFilter());
						dataMap.put("plotParams1", exportRequestVO.getPlotParamValue());
						dataMap.put("periodFilter", exportRequestVO.getPeriodNameFilter());
						
						if(exportRequestVO.getFromDate() != null) {
							dataMap.put("discountDateFromFilter", sdf.format(exportRequestVO.getFromDate()));
							dataMap.put("discountDateToFilter", sdf.format(exportRequestVO.getToDate()));
						} else {
							dataMap.put("discountDateFromFilter", "-");
							dataMap.put("discountDateToFilter", "-");
						}
						if(exportRequestVO.getFromMDate() != null) {
							dataMap.put("maturityDateFromFilter", sdf.format(exportRequestVO.getFromMDate()));
							dataMap.put("maturityDateToFilter", sdf.format(exportRequestVO.getToMDate()));
						} else {
							dataMap.put("maturityDateFromFilter", "-");
							dataMap.put("maturityDateToFilter", "-");
						}
						if(exportRequestVO.getFromAmount() != null) {
							dataMap.put("fromAmountFilter", exportRequestVO.getFromAmountFilter());	
							dataMap.put("toAmountFilter", exportRequestVO.getToAmountFilter()); 
						} else {
							dataMap.put("fromAmountFilter", "-");
							dataMap.put("toAmountFilter", "-");
						}
					}

					if (null != exportRequestVO.getPageInfo()	&& exportRequestVO.getPageInfo().equals(ExportUtil.REMITTANCE_REPORT)) {
						InputStream dataInputStream = new ByteArrayInputStream(buffer);
						dataMap.put("chart", dataInputStream);
						dataMap.put("buyerOrgFilter", exportRequestVO.getBuyerNameFilter());	
						dataMap.put("supplierOrgFilter", exportRequestVO.getSupplierNameFilter()); 
						dataMap.put("statusFilter", exportRequestVO.getStatusNameFilter());
						dataMap.put("ccyFilter", exportRequestVO.getCurrencyCode());
						dataMap.put("branchNameFilter", exportRequestVO.getBranchNameFilter());
						dataMap.put("plotParams1", exportRequestVO.getPlotParamValue());
						dataMap.put("periodFilter", exportRequestVO.getPeriodNameFilter());
						dataMap.put("reportType", exportRequestVO.getReportTypeName());
						
						if(exportRequestVO.getFromDate() != null) {
							dataMap.put("periodFromDateFilter", sdf.format(exportRequestVO.getFromDate()));
							dataMap.put("periodToDateFilter", sdf.format(exportRequestVO.getToDate()));
						} else {
							dataMap.put("periodFromDateFilter", "-");
							dataMap.put("periodToDateFilter", "-");
						}
					}					
					
					log.debug("Inside PDF");
					dataMap.put("sysDateStr", sdf.format(new java.util.Date()));

					String language = exportRequestVO.getLangPreferance();
					String[] locale = language.split("_");
					Locale lc = new Locale(locale[0], locale[1]);

					dataMap.put(JRParameter.REPORT_RESOURCE_BUNDLE, ResourceBundle.getBundle(BNPConstants.LOCALE_PROPERTY_FILE_PATH, lc));
					dataMap.put("generatedUser", exportRequestVO.getUserId());
					if(jasperInputStream!=null){
						JasperPrint jasperPrint = JasperFillManager.fillReport(jasperInputStream,dataMap,  new JRResultSetDataSource(rs));
						List<JRPrintPage> pages = jasperPrint.getPages();
						if (pages.size()==0){
							log.error("Empty Record" );
							throw new BNPApplicationException(30000101, NO_RECORDS);
						}else{
							JRPdfExporter jrPDFExporter= new JRPdfExporter();
							jrPDFExporter.setParameter(JRPdfExporterParameter.JASPER_PRINT, jasperPrint);
							jrPDFExporter.setParameter(JRPdfExporterParameter.OUTPUT_STREAM, pdfOutputStream);
							jrPDFExporter.exportReport();
						}
						//FO7.0 Fortify Issue Fix
						//_logger.debug("jasper execution time "+(System.currentTimeMillis() - startTime));
						log.debug("Time taken in Service Layer PDF ----> " + (System.currentTimeMillis()-strTime));
					}else{
						log.error("Empty inputStream -- File not found or not available" );
						throw new BNPApplicationException(ErrorConstants.REPORT_CREATION_ERROR,"Empty inputStream -- File not found or not available");
					}
					outputStream.write(pdfOutputStream.toByteArray());
					outputStream.flush();
					//FO7.0 Fortify Issue Fix
					//_logger.debug("report exporting time "+(System.currentTimeMillis() - startTime));
				} catch (JRException exception) {
					log.error(" JRException in creating Billing Pdf" + exception);
					throw new BNPApplicationException(ErrorConstants.REPORT_CREATION_ERROR,"Report Creation Error");
				} finally{
					if(null != pdfOutputStream){
						try{
							pdfOutputStream.close();
						}catch(Exception e){
							log.error(e.getMessage() + Arrays.toString(e.getStackTrace()) + " - "+ e);
							throw new BNPApplicationException(e.getMessage());
						}						
					}
					
					if(null != logoInputStream){
						try{
							logoInputStream.close();
						}catch(Exception e){
							log.error(e.getMessage() + Arrays.toString(e.getStackTrace()) + " - "+ e);
							throw new BNPApplicationException(e.getMessage());
						}
					}
					
					if(null != jasperInputStream ){
						try{
							jasperInputStream.close();
						}catch(Exception e){
							log.error(e.getMessage() + Arrays.toString(e.getStackTrace()) + " - "+ e);
							throw new BNPApplicationException(e.getMessage());
						}
						
					}
				}
				  

			}
		}catch(BNPApplicationException ex){
			log.debug("================================="+ex.getMessage());
			log.error(ex.getMessage(), ex);
			throw new BNPApplicationException(ex.getErrorCode(),ex.getMessage());
		}
	}
	
	/**
	 * This method for getting Payment Order Export PopUp Details
	 * 
	 * @param exportRequestVO
	 * @param outputStream
	 * @throws BNPApplicationException
	 * @throws IOException
	 * @see com.bnp.bnpux.service.IExportService#getPaymentOrderExportPopUpDetails(com.bnp.bnpux.vo.requestVO.ExportRequestVO, javax.servlet.ServletOutputStream)
	 * @Description Get PaymentOrder Export PopUp Details
	 */
	@Override
	public void getPaymentOrderExportPopUpDetails(ExportRequestVO exportRequestVO, ServletOutputStream outputStream) throws BNPApplicationException, IOException {
		try 
		{
			getPaymentOrderPopUpExportData(exportRequestVO,outputStream);
		}
		catch (BNPApplicationException e) 
		{
			throw new BNPApplicationException(e.getErrorCode(),e.getMessage() + " - "+ e);
		}
	}
	
	/**
	 * This method for getting Payment Order PopUp Export Data
	 * 
	 * @param exportRequestVO
	 * @param outputStream
	 * @throws BNPApplicationException
	 * @throws IOException 
	 * @Description get PaymentOrder PopUp ExportData
	 */
	private void getPaymentOrderPopUpExportData(ExportRequestVO exportRequestVO, ServletOutputStream outputStream) throws BNPApplicationException, IOException {
		
		Connection con = null;
		CallableStatement callableStatement = null;
		Properties prop;
		
		ResultSet paymentRS = null;
		ResultSet invoiceRS = null;
		ResultSet creditNoteRS = null;
		ResultSet auditRS = null;
		
		String baseHeaderName= null;
		
		Class exportClass;
		Method headerMethod;
		
		List<String> actualHeaderList = new ArrayList<String>();
		List<ResultSet> outputCursorList = new ArrayList<ResultSet>();
		
		try
		{
		 con = getConnection();
		}
		catch(Exception bnp)
		{
			log.error(1000010 + "    Could not get Connection");
			throw new BNPApplicationException(1000010,"SQLException: " + "    Could not get Connection " + " - " + bnp);
		}

		try 
		{
			log.debug("Export Data for PO Popup starts");
			prop = ExportUtil.getProperties(exportRequestVO);
			baseHeaderName = ExportConstants.poBaseHeaderName;
			
			//Call Package
			log.debug("Executing package - call pkg_pymt_order_dashboard.PRC_PYMT_POP_UP( ?, ?, ?, ?, ?, ?, ?,?)");
			callableStatement = (CallableStatement)con.prepareCall("{call pkg_pymt_order_dashboard.PRC_PYMT_POP_UP( ?, ?, ?, ?, ?, ?, ?,?)}");
			callableStatement.setString(1, exportRequestVO.getUserId());
			callableStatement.setString(2, exportRequestVO.getPaymentId());
			callableStatement.setString(3, exportRequestVO.getExportType());
			callableStatement.registerOutParameter(4, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(5, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(6, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(7, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(8, java.sql.Types.VARCHAR);
			long strTime = System.currentTimeMillis();
			callableStatement.execute();
			log.debug("Time taken for Database call after -->>" +(System.currentTimeMillis()-strTime));
			
			
			//Process output
			String errrorCode = (String) callableStatement.getObject(8);
			if(errrorCode!=null && ("93000172".equalsIgnoreCase(errrorCode))){
				log.debug("Threshold limt exceeds for Export - payment Order POPUP");
				throw new BNPApplicationException(93000172 , errrorCode);	
			}
			
			paymentRS = (ResultSet) callableStatement.getObject(4);
			invoiceRS = (ResultSet) callableStatement.getObject(5);
			creditNoteRS = (ResultSet) callableStatement.getObject(6);
			auditRS = (ResultSet) callableStatement.getObject(7);
			
			setExportDelimiterValue(exportRequestVO.getExportType());
			
			//Export PDF
			if(exportRequestVO.getExportType().equals(ExportUtil.PDF))
			{
				HashMap<String, ResultSet> hmTemp = new HashMap<String, ResultSet>();
				
				hmTemp.put(ExportConstants.RS_PAYMENT,paymentRS);
				hmTemp.put(ExportConstants.RS_INVOICE,invoiceRS);
				hmTemp.put(ExportConstants.RS_CREDITNOTE,creditNoteRS);
				exportPopupPDF(hmTemp,exportRequestVO,outputStream);
			}	
			else
			{
				//Export XLS, CSV Block
				outputCursorList.add(paymentRS);
				outputCursorList.add(invoiceRS);
				outputCursorList.add(creditNoteRS);
				outputCursorList.add(auditRS);
				
				
				//Preparing exportRequestVO
				exportRequestVO.setSectionsList(Arrays.asList(ExportConstants.PO_SECTIONS_LIST.split("~")));
				exportRequestVO.setSectionsData(outputCursorList);
				exportRequestVO.setSectionsHeader(new ArrayList<List<String>>());			
				for(int i=0; i< exportRequestVO.getSectionsList().size();i++)
				{
					exportClass = Class.forName("com.bnp.bnpux.util.ExportUtil");
					headerMethod = exportClass.getMethod("get" + baseHeaderName + (i+1));
					actualHeaderList = (List<String>)headerMethod.invoke(exportClass.newInstance());
					
					exportRequestVO.getSectionsHeader().add(actualHeaderList);
				}
				
				//Actual calls to XLS, CSV Blocks
				if(exportRequestVO.getExportType().equals(ExportUtil.XLS))
				{
					exportDataToXLS(exportRequestVO,prop,outputStream);
				}
				else if(exportRequestVO.getExportType().equals(ExportUtil.CSV))
				{
					exportDataToCSV(exportRequestVO,prop,outputStream);
				}
			}
			
		} catch (BNPApplicationException bnpError) {
				log.error("Exception Occured in getPaymentOrderExportData"+ bnpError.getErrorCode() + Arrays.toString(bnpError.getStackTrace()) + " - " + bnpError);
				throw new BNPApplicationException(bnpError.getErrorCode(), bnpError.getMessage());
		} catch (Exception e) {
			log.error("Exception Occured in getPaymentOrderExportData" + e.getMessage() + Arrays.toString(e.getStackTrace()) + " - " + e);
			throw new BNPApplicationException(9100103, e.getMessage());
		}
		finally {
			if(paymentRS != null){
				try {
					paymentRS.close();

				} catch (SQLException e) {
					log.error(e.getErrorCode() + BNPConstants.SQL_EXCEPTION + e.getMessage() + " - "+ e);
				}
			}
			if(invoiceRS != null){
				try {
					invoiceRS.close();

				} catch (SQLException e) {
					log.error(e.getErrorCode() + BNPConstants.SQL_EXCEPTION + e.getMessage() + " - "+ e);
				}
			}
			if(creditNoteRS != null){
				try {
					creditNoteRS.close();

				} catch (SQLException e) {
					log.error(e.getErrorCode() + BNPConstants.SQL_EXCEPTION + e.getMessage() + " - "+ e);
				}
			}
			
			if(auditRS != null){
				try {
					auditRS.close();

				} catch (SQLException e) {
					log.error(e.getErrorCode() + BNPConstants.SQL_EXCEPTION + e.getMessage() + " - "+ e);
				}
			}
			if (callableStatement != null) {
				try {
					callableStatement.close();

				} catch (SQLException e) {
					log.error(e.getErrorCode() + BNPConstants.SQL_EXCEPTION + e.getMessage() + " - "+ e);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					log.error(e.getErrorCode() + BNPConstants.SQL_EXCEPTION + e.getMessage() + " - "+ e);
				}
			}
		}
	}
	
	
	/**
	 * This method for getting Transaction Export PopUp Details
	 * 
	 * @param exportRequestVO
	 * @param outputStream
	 * @throws BNPApplicationException
	 * @throws IOException
	 * @see com.bnp.bnpux.service.IExportService#getTransactionExportPopUpDetails(com.bnp.bnpux.vo.requestVO.ExportRequestVO, javax.servlet.ServletOutputStream)
	 * @Description Get Transaction Export PopUp Details
	 */
	@Override
	public void getTransactionExportPopUpDetails(ExportRequestVO exportRequestVO, ServletOutputStream outputStream) throws BNPApplicationException, IOException {
		try {
			getTransactionPopUpExportData(exportRequestVO,outputStream);
		} catch (BNPApplicationException e) {
			throw new BNPApplicationException(e.getErrorCode(),e.getMessage() + " - "+ e);
		}
	}
	
	/**
	 * This method for getting Transaction PopUp Export Data
	 * 
	 * @param exportRequestVO
	 * @param outputStream
	 * @throws BNPApplicationException
	 * @throws IOException 
	 * @Description get Transaction PopUp Export Data
	 */
	private void getTransactionPopUpExportData(ExportRequestVO exportRequestVO, ServletOutputStream outputStream) throws BNPApplicationException, IOException {
		
		Connection con = null;
		ResultSet mainRS = null;
		ResultSet discountRS = null;
		ResultSet paymentRS = null;
		ResultSet invoiceRS = null;
		ResultSet creditNoteRS = null;
		ResultSet indChargeRS = null;
		ResultSet commFeeRS = null;
		ResultSet commFeeHdrRS = null;
		
		String baseHeaderName= null;
		
		Class<?> exportClass;
		Method headerMethod;
		
		List<String> actualHeaderList = new ArrayList<String>();
		List<ResultSet> outputCursorList = new ArrayList<ResultSet>();
		
		try{
		 con = getConnection();
		}catch(Exception bnp){
			log.error(1000010 + "    Could not get Connection");
			throw new BNPApplicationException(1000010,"SQLException: " + "    Could not get Connection - "+bnp);
		}
		CallableStatement callableStatement = null;
		Properties prop = ExportUtil.getProperties(exportRequestVO);
		
		baseHeaderName = ExportConstants.TXN_DISCDETAILSPOPOP_EXPORT_BASE_HEADER_NAME;
		
		try {
			callableStatement = (CallableStatement)con.prepareCall("{call pkg_transaction_dashboard.prc_txn_pop_up(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
			
			callableStatement.setString(1, exportRequestVO.getUserId());
			callableStatement.setString(2, exportRequestVO.getUserType());	
			callableStatement.setString(3, exportRequestVO.getDiscRefNo());	
			callableStatement.setString(4, exportRequestVO.getRecFlag());	
			callableStatement.setString(5, exportRequestVO.getBuyerOrgId());
			callableStatement.setString(6, exportRequestVO.getSupplierOrgId());
			callableStatement.setString(7, exportRequestVO.getExportType());
			callableStatement.registerOutParameter(8, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(9, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(10, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(11, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(12, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(13, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(14, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(15, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(16, java.sql.Types.VARCHAR);
			
			
			long strTime = System.currentTimeMillis();
			callableStatement.execute();
			log.debug("Time taken for Database call after -->>" +(System.currentTimeMillis()-strTime));
			String errrorCode = (String) callableStatement.getObject(16);
			if(errrorCode!=null && ("93000172".equalsIgnoreCase(errrorCode))){
				log.debug("Threshold limt exceeds for Export - payment Order POPUP");
				throw new BNPApplicationException(93000172 , errrorCode);
			}
			
			mainRS = (ResultSet) callableStatement.getObject(15);
			discountRS = (ResultSet) callableStatement.getObject(8);		
			
			invoiceRS = (ResultSet) callableStatement.getObject(9);
			creditNoteRS = (ResultSet) callableStatement.getObject(10);
			indChargeRS = (ResultSet) callableStatement.getObject(11);
			commFeeRS = (ResultSet) callableStatement.getObject(12);
			commFeeHdrRS = (ResultSet) callableStatement.getObject(13);
			paymentRS = (ResultSet) callableStatement.getObject(14);
			
			
			if((ExportUtil.PDF).equals(exportRequestVO.getExportType())){
				
				HashMap<String, ResultSet> hmTemp = new HashMap<String, ResultSet>();
				
				hmTemp.put(ExportConstants.RS_MAIN,mainRS);
				hmTemp.put(ExportConstants.RS_DISCOUNT,discountRS);
				hmTemp.put(ExportConstants.RS_PAYMENT,paymentRS);
				hmTemp.put(ExportConstants.RS_INVOICE,invoiceRS);
				hmTemp.put(ExportConstants.RS_CREDITNOTE,creditNoteRS);
				hmTemp.put(ExportConstants.RS_INDCHARGE,indChargeRS);
				hmTemp.put(ExportConstants.RS_COMMFEE,commFeeRS);
				hmTemp.put(ExportConstants.RS_COMMFEE_HDR, commFeeHdrRS);
				
				
				exportPopupPDF(hmTemp,exportRequestVO,outputStream);
				
			}else{
				
				//Export XLS, CSV Block
				outputCursorList.add(discountRS);
				outputCursorList.add(indChargeRS);
				outputCursorList.add(commFeeHdrRS);
				outputCursorList.add(commFeeRS);
				outputCursorList.add(paymentRS);
				outputCursorList.add(invoiceRS);
				outputCursorList.add(creditNoteRS);
				
				
				
				//Preparing exportRequestVO
				exportRequestVO.setSectionsList(Arrays.asList(ExportConstants.TXN_DISCDETAILSPOPOP_EXPORT_SECTIONS_LIST.split("~")));
				exportRequestVO.setSectionsData(outputCursorList);
				exportRequestVO.setSectionsHeader(new ArrayList<List<String>>());			
				for(int i=0; i< exportRequestVO.getSectionsList().size();i++)
				{
					exportClass = Class.forName("com.bnp.bnpux.util.ExportUtil");
					headerMethod = exportClass.getMethod("get" + ExportConstants.TXN_DISCDETAILSPOPOP_EXPORT_BASE_HEADER_NAME + (i+1));
					actualHeaderList = (List<String>)headerMethod.invoke(exportClass.newInstance());
					
					exportRequestVO.getSectionsHeader().add(actualHeaderList);
				}
				
				//Actual calls to XLS, CSV Blocks
				if(exportRequestVO.getExportType().equals(ExportUtil.XLS))
				{
					exportDataToXLS(exportRequestVO,prop,outputStream);
				}
				else if(exportRequestVO.getExportType().equals(ExportUtil.CSV))
				{
					exportDataToCSV(exportRequestVO,prop,outputStream);
				}else{
					log.error("Invalid Export Type: "+ exportRequestVO.getExportType());
					throw new BNPApplicationException(999999999, "Invalid Export Type: " + exportRequestVO.getExportType());
				}
			}
			
			
		} catch (BNPApplicationException bnpError) {
			log.error("Exception Occured in getPaymentOrderExportData"+ bnpError.getErrorCode());
			throw new BNPApplicationException(bnpError.getErrorCode(), bnpError.getMessage()+ " - "+ bnpError);
		}catch (Exception e) {
			log.error("Exception Occured in getPaymentOrderExportData" + e.getMessage() + " - "+ e);
			throw new BNPApplicationException(9100103, e.getMessage());
			
		}
		finally {
			if(mainRS != null){
				try {
					mainRS.close();

				} catch (SQLException e) {
					log.error(e.getErrorCode() + BNPConstants.SQL_EXCEPTION + e.getMessage() + " - "+ e);
				}
			}
			if(discountRS != null){
				try {
					discountRS.close();

				} catch (SQLException e) {
					log.error(e.getErrorCode() + BNPConstants.SQL_EXCEPTION + e.getMessage() + " - "+ e);
				}
			}
			if(paymentRS != null){
				try {
					paymentRS.close();

				} catch (SQLException e) {
					log.error(e.getErrorCode() + BNPConstants.SQL_EXCEPTION + e.getMessage() + " - "+ e);
				}
			}
			if(invoiceRS != null){
				try {
					invoiceRS.close();

				} catch (SQLException e) {
					log.error(e.getErrorCode() + BNPConstants.SQL_EXCEPTION + e.getMessage() + " - "+ e);
				}
			}
			if(creditNoteRS != null){
				try {
					creditNoteRS.close();

				} catch (SQLException e) {
					log.error(e.getErrorCode() + BNPConstants.SQL_EXCEPTION + e.getMessage() + " - "+ e);
				}
			}
			if(indChargeRS != null){
				try {
					indChargeRS.close();

				} catch (SQLException e) {
					log.error(e.getErrorCode() + BNPConstants.SQL_EXCEPTION + e.getMessage() + " - "+ e);
				}
			}
			if(commFeeRS != null){
				try {
					commFeeRS.close();

				} catch (SQLException e) {
					log.error(e.getErrorCode() + BNPConstants.SQL_EXCEPTION + e.getMessage() + " - "+ e);
				}
			}
			if (callableStatement != null) {
				try {
					callableStatement.close();

				} catch (SQLException e) {
					log.error(e.getErrorCode() + BNPConstants.SQL_EXCEPTION + e.getMessage() + " - "+ e);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					log.error(e.getErrorCode() + BNPConstants.SQL_EXCEPTION + e.getMessage() + " - "+ e);
				}
			}
		}
	}
	
	/**
	 * This method for getting View Scheduled Reports Export data
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException
	 * @see com.bnp.bnpux.service.IExportService#getCreditNoteReportsExport(com.bnp.bnpux.vo.requestVO.ExportRequestVO, javax.servlet.ServletOutputStream, byte[])
	 * @Description Get Reports for Export
	 */
	@Override
	public void getExportViewScheduledReportsData(ExportRequestVO exportVO,
			ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException,
			IOException {
		try {
			setExportDelimiterValue(exportVO.getExportType());
			exportViewScheduledReportsData(exportVO,outputStream,buffer);
		} catch (BNPApplicationException e) {
			throw new BNPApplicationException(e.getErrorCode(),e.getMessage());
		}
		
	}

	/**
	 * This method for getting View Scheduled Reports Export data
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException
	 * @see com.bnp.bnpux.service.IExportService#getCreditNoteReportsExport(com.bnp.bnpux.vo.requestVO.ExportRequestVO, javax.servlet.ServletOutputStream, byte[])
	 * @Description Get Reports for Export
	 */
	
	public void exportViewScheduledReportsData(ExportRequestVO exportRequestVO, ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException, IOException {
		log.debug("For Export Reports Screen ");		
		Connection con = null;
		ResultSet rs = null;
		try{
			con = getConnection();
		}catch(Exception bnp){
			log.error(1000010 + "    Could not get Connection");
			throw new BNPApplicationException(1000010,"SQLException: " + "    Could not get Connection");
		}
		CallableStatement callableStatement = null;
		Properties prop = ExportUtil.getProperties(exportRequestVO);
		try {
			long strTime = System.currentTimeMillis();
			callableStatement = con.prepareCall("{call pkg_reports.prc_view_schedule_list( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?)}"); // Modified for Sonar Fix
			callableStatement.setString(1, exportRequestVO.getUserId());
			callableStatement.setString(2, exportRequestVO.getUserType());
			callableStatement.setString(3, exportRequestVO.getReportType());
			callableStatement.setString(4, exportRequestVO.getReportFrequency());
			callableStatement.setString(5, exportRequestVO.getOrgId());
			callableStatement.setString(6, exportRequestVO.getFileFilter());
			callableStatement.setString(7, exportRequestVO.getReportScheduleID());
			callableStatement.setString(8, exportRequestVO.getReportFromDateTime());
			callableStatement.setString(9, exportRequestVO.getReportToDateTime());
			callableStatement.setString(10, exportRequestVO.getPeriodFilter());
			callableStatement.setString(11, exportRequestVO.getBranchFilter());
			callableStatement.setString(12, exportRequestVO.getGetWhat());
			callableStatement.setString(13, exportRequestVO.getExportType());
			if(exportRequestVO.getRecordFrom() != null) {
				callableStatement.setInt(14, exportRequestVO.getRecordFrom());
			} else {
				callableStatement.setNull(14, java.sql.Types.INTEGER);
			}
			if(exportRequestVO.getRecordTo() != null) {
				callableStatement.setInt(15, exportRequestVO.getRecordTo());
			} else {
				callableStatement.setNull(15, java.sql.Types.INTEGER);			}
						
			callableStatement.registerOutParameter(16, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(17, java.sql.Types.VARCHAR);
			callableStatement.execute();
			String errrorCode = (String) callableStatement.getObject(17);
        	if(errrorCode!=null && (errrorCode.equalsIgnoreCase("93000172"))){
        		log.debug("Threshold limt exceeds for Export - View Scheduled report");
        		throw new BNPApplicationException(93000172 , errrorCode);
        	}
			rs = (ResultSet) callableStatement.getObject(16);
			log.debug("Time taken for Database call -->>" +(System.currentTimeMillis()-strTime));
			ResultSetMetaData rsmd = rs.getMetaData();
	    	exportRecords(rs,rsmd,exportRequestVO, prop,outputStream,buffer);
	    	
		} catch (Exception e) {
			if(e instanceof BNPApplicationException){
				BNPApplicationException bnpError = (BNPApplicationException) e;
				log.error("Exception Occured in View Scheduled Report exportReportsData"+ bnpError.getErrorCode());
				throw new BNPApplicationException(bnpError.getErrorCode(), bnpError.getMessage());
			}else{
				log.error("Exception Occured in View Scheduled Report exportReportsData" + e.getMessage());
				throw new BNPApplicationException(9100103, e.getMessage());
			}}
		finally {
			if(rs != null){
        		try {
        			rs.close();
        		} catch (SQLException e) {
        			log.error("Exception Occured in View Scheduled Report exportReportsData" + e.getMessage());
        		}
        	}
			if (callableStatement != null) {
				try {
					callableStatement.close();
				} catch (SQLException e) {
					log.error("Exception Occured in View Scheduled Report exportReportsData" + e.getMessage());
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					log.error("Exception Occured in View Scheduled Report exportReportsData" + e.getMessage());
				}
			}
		}
	}
	
	/**
	 * This method for getting Aging Reports Export data
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException
	 * @see com.bnp.bnpux.service.IExportService#getAgingReportExportData(com.bnp.bnpux.vo.requestVO.ExportRequestVO, javax.servlet.ServletOutputStream, byte[])
	 * @Description Get Reports for Aging Export
	 */
	@Override
	public void getAgingReportExportData(ExportRequestVO exportVO,
			ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException,
			IOException {
		try {
			setExportDelimiterValue(exportVO.getExportType());
			exportAgingReportsData(exportVO,outputStream,buffer);
		} catch (BNPApplicationException e) {
			throw new BNPApplicationException(e.getErrorCode(),e.getMessage());
		}
		
	}

	/**
	 * This method for getting View Scheduled Reports Export data
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException	 * 
	 * @Description Get Aging report data for Export
	 */
	
	public void exportAgingReportsData(ExportRequestVO exportRequestVO, ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException, IOException {
		log.debug("For Export Aging Reports Screen ");
		Connection con = null;
		ResultSet rs = null;
		try{
			con = getConnection();
		}catch(Exception bnp){
			log.error(1000010 + "    Could not get Connection");
			throw new BNPApplicationException(1000010,"SQLException: " + "    Could not get Connection");
		}
		CallableStatement callableStatement = null;
		Properties prop = ExportUtil.getProperties(exportRequestVO);
		try {
			long strTime = System.currentTimeMillis();
			
			callableStatement = con.prepareCall("{call pkg_reports.prc_aging_rpt( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?)}"); // Modified for Sonar Fix
			
			callableStatement.setString(1, exportRequestVO.getUserId());
			callableStatement.setString(2, exportRequestVO.getUserType());
			callableStatement.setString(3, exportRequestVO.getBranchFilter());
			callableStatement.setString(4, exportRequestVO.getBuyerOrgId());
			callableStatement.setString(5, exportRequestVO.getSupplierOrgId());
			callableStatement.setString(6, exportRequestVO.getDuePeriod());
			callableStatement.setString(7, exportRequestVO.getDueDays());
			callableStatement.setString(8, exportRequestVO.getCurrencyCode());
			callableStatement.setString(9, exportRequestVO.getDiscType());
			callableStatement.setNull(10, java.sql.Types.VARCHAR);
			callableStatement.setString(11, exportRequestVO.getGetWhat());
			callableStatement.setString(12, exportRequestVO.getExportType());
			if(exportRequestVO.getRecordFrom() != null) {
				callableStatement.setInt(13, exportRequestVO.getRecordFrom());
			} else {
				callableStatement.setNull(13, java.sql.Types.INTEGER);
			}
			if(exportRequestVO.getRecordTo() != null) {
				callableStatement.setInt(14, exportRequestVO.getRecordTo());
			} else {
				callableStatement.setNull(14, java.sql.Types.INTEGER);			}
						
			callableStatement.registerOutParameter(15, OracleTypes.CURSOR);
			callableStatement.registerOutParameter(16, java.sql.Types.VARCHAR);
			callableStatement.execute();
			String errrorCode = (String) callableStatement.getObject(16);
        	if(errrorCode!=null && (errrorCode.equalsIgnoreCase("93000172"))){
        		log.debug("Threshold limt exceeds for Export - Aging report");
        		throw new BNPApplicationException(93000172 , errrorCode);
        	}
			rs = (ResultSet) callableStatement.getObject(15);
			log.debug("Time taken for Database call -->>" +(System.currentTimeMillis()-strTime));
			ResultSetMetaData rsmd = rs.getMetaData();
	    	exportRecords(rs,rsmd,exportRequestVO, prop,outputStream,buffer);
	    	
		} catch (Exception e) {
			if(e instanceof BNPApplicationException){
				BNPApplicationException bnpError = (BNPApplicationException) e;
				log.error("Exception Occured in Aging exportReportsData"+ bnpError.getErrorCode());
				throw new BNPApplicationException(bnpError.getErrorCode(), bnpError.getMessage());
			}else{
				log.error("Exception Occured in Aging exportReportsData" + e.getMessage());
				throw new BNPApplicationException(9100103, e.getMessage());
			}}
		finally {
			if(rs != null){
        		try {
        			rs.close();
        		} catch (SQLException e) {
        			log.error("Exception Occured in Aging exportReportsData" + e.getMessage());
        		}
        	}
			if (callableStatement != null) {
				try {
					callableStatement.close();
				} catch (SQLException e) {
					log.error("Exception Occured in Aging exportReportsData" + e.getMessage());
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					log.error("Exception Occured in Aging exportReportsData" + e.getMessage());
				}
			}
		}
	}

	
	
	/**
	 * This method for exporting popup
	 * 
	 * @param hmInput
	 * @param exportRequestVO
	 * @param outputStream
	 * @throws SQLException
	 * @throws BNPApplicationException
	 * @throws IOException 
	 * @Description export Popup
	 */
	public void exportPopupPDF(HashMap<String, ResultSet> hmInput, ExportRequestVO exportRequestVO, ServletOutputStream outputStream) throws SQLException, BNPApplicationException, IOException {
		ResultSet rs = null;
		ByteArrayOutputStream pdfOutputStream = null;
		InputStream jasperInputStream = null;
		InputStream logoInputStream=null;
		
		try{
			long strTime = System.currentTimeMillis();
			
				setExportType(ExportUtil.PDF);
				try {
					//FO 8.0 Sonar Fix
					//long startTime = System.currentTimeMillis();
												
					pdfOutputStream = new ByteArrayOutputStream();

					if(exportRequestVO.getPageInfo().equalsIgnoreCase(ExportUtil.PAYMENT_ORDER_PAGE) && ExportUtil.PAYMENT_ORDER_PAGE_POPUP.equals(exportRequestVO.getPagePopUpInfo())){
						jasperInputStream = getClass().getClassLoader().getResourceAsStream(ReportConstants.JASPER_PATH+ExportUtil.PAYMENT_POPUP_PDF+JASPER_EXTN);
					}else if(exportRequestVO.getPageInfo().equalsIgnoreCase(ExportUtil.TRANSACTION_PAGE) && ExportUtil.TRANSACTION_PAGE_POPUP.equals(exportRequestVO.getPagePopUpInfo())){
						jasperInputStream = getClass().getClassLoader().getResourceAsStream(ReportConstants.JASPER_PATH+ExportUtil.TRANSACTION_POPUP_PDF+JASPER_EXTN);
					}else{
						log.error("Exception in creating inputStream");
						throw new BNPApplicationException(ErrorConstants.REPORT_CREATION_ERROR,"Report Creation Error");
					}

					logoInputStream = getClass().getClassLoader().getResourceAsStream(ReportConstants.IMAGE_PATH);
					HashMap<String, Object> dataMap = new HashMap<String, Object>();
					dataMap.put(BNPLOGO, logoInputStream);
					dataMap.put(SUBREPORT_DIR,ReportConstants.JASPER_PATH);
					
					byte [] img;
					
					
					OrganizationVO org = loginService.getOrgLogo(exportRequestVO.getBuyerOrgId());
					
					if(org.getOrgLogo() ==  null)
					{
						InputStream dataInputStream = getClass().getClassLoader().getResourceAsStream(ReportConstants.BUYER_ORG_PATH);
						dataMap.put("buyerLogo", dataInputStream);
						
						
					}
					else
					{
						img = org.getOrgLogo();
						InputStream dataInputStream = new ByteArrayInputStream(img);
						dataMap.put("buyerLogo", dataInputStream);
					}
					
					
					org = loginService.getOrgLogo(exportRequestVO.getSupplierOrgId());
					
					if(org.getOrgLogo() ==  null)
					{
						InputStream dataInputStream = getClass().getClassLoader().getResourceAsStream(ReportConstants.SUPPLIER_ORG_PATH);
						dataMap.put("supplierLogo", dataInputStream);
						
					}
					else
					{
						img = org.getOrgLogo();
						InputStream dataInputStream = new ByteArrayInputStream(img);
						dataMap.put("supplierLogo", dataInputStream);
					}
					
					
					if(exportRequestVO.getPageInfo().equalsIgnoreCase(ExportUtil.PAYMENT_ORDER_PAGE) && ExportUtil.PAYMENT_ORDER_PAGE_POPUP.equals(exportRequestVO.getPagePopUpInfo())){
						
						rs = hmInput.get(ExportConstants.RS_PAYMENT);
						
						dataMap.put("INVOICE_DATE_SOURCE",new JRResultSetDataSource((ResultSet) hmInput.get(ExportConstants.RS_INVOICE)));
						dataMap.put("CNOTE_DATE_SOURCE", new JRResultSetDataSource((ResultSet) hmInput.get(ExportConstants.RS_CREDITNOTE)));
						
					}
					else
					{
						rs = hmInput.get(ExportConstants.RS_DISCOUNT);
						dataMap.put("ORG_DATE_SOURCE",new JRResultSetDataSource((ResultSet) hmInput.get(ExportConstants.RS_MAIN)));
						dataMap.put("PAYMENT_DATE_SOURCE",new JRResultSetDataSource((ResultSet) hmInput.get(ExportConstants.RS_PAYMENT)));
						dataMap.put("INVOICE_DATE_SOURCE",new JRResultSetDataSource((ResultSet) hmInput.get(ExportConstants.RS_INVOICE)));
						dataMap.put("CNOTE_DATE_SOURCE", new JRResultSetDataSource((ResultSet) hmInput.get(ExportConstants.RS_CREDITNOTE)));
						dataMap.put("INDCHARGE_DATE_SOURCE", new JRResultSetDataSource((ResultSet) hmInput.get(ExportConstants.RS_INDCHARGE)));
						dataMap.put("COMMFEE_DATE_SOURCE", new JRResultSetDataSource((ResultSet) hmInput.get(ExportConstants.RS_COMMFEE)));
						dataMap.put("COMMFEE_HDR_DATE_SOURCE", new JRResultSetDataSource((ResultSet) hmInput.get(ExportConstants.RS_COMMFEE_HDR)));
						
					}
					
					
					Object result = userPrefDAO.getUserPreferenceInfo(exportRequestVO.getUserId());

					UserPreferenceVO userPrefVO = new UserPreferenceVO();

					userPrefVO = (UserPreferenceVO) result;
					log.debug("Inside PDF");

					dataMap.put("sysDateStr",((new SimpleDateFormat(userPrefVO.getPreferredDateFmt())).format(new java.util.Date())));

					// StringBuffer localeString = new StringBuffer("i18n").append("_").append(locale);

					String language = exportRequestVO.getLangPreferance();
					String[] locale = language.split("_");
					Locale lc = new Locale(locale[0], locale[1]);

					dataMap.put(JRParameter.REPORT_RESOURCE_BUNDLE, ResourceBundle.getBundle(BNPConstants.LOCALE_PROPERTY_FILE_PATH, lc));
					dataMap.put("generatedUser", exportRequestVO.getUserId());
					if(jasperInputStream!=null){
						JasperPrint jasperPrint = JasperFillManager.fillReport(jasperInputStream,dataMap,  new JRResultSetDataSource(rs));
						List<JRPrintPage> pages = jasperPrint.getPages();
						if(pages.isEmpty()){
							log.error("Empty Record" );
							throw new BNPApplicationException(30000101, NO_RECORDS);
						}else{
							JRPdfExporter jrPDFExporter= new JRPdfExporter();
							jrPDFExporter.setParameter(JRPdfExporterParameter.JASPER_PRINT, jasperPrint);
							jrPDFExporter.setParameter(JRPdfExporterParameter.OUTPUT_STREAM, pdfOutputStream);
							jrPDFExporter.exportReport();
						}
						//FO7.0 Fortify Issue Fix
						//_logger.debug("jasper execution time "+(System.currentTimeMillis() - startTime));
						log.debug("Time taken in Service Layer PDF ----> " + (System.currentTimeMillis()-strTime));
					}else{
						log.error("Empty inputStream -- File not found or not available" );
						throw new BNPApplicationException(ErrorConstants.REPORT_CREATION_ERROR,"Empty inputStream -- File not found or not available");
					}
					//FO7.0 Fortify Issue Fix
					//_logger.debug("report exporting time "+(System.currentTimeMillis() - startTime));
				} catch (JRException exception) {
					
					log.error(" JRException in creating Billing Pdf" + exception);
					throw new BNPApplicationException(ErrorConstants.REPORT_CREATION_ERROR,"Report Creation Error");
				}
				  outputStream.write(pdfOutputStream.toByteArray());
				  outputStream.flush();
				// TO BE WRITTEN

			
		}catch(BNPApplicationException ex){
			log.debug("================================="+ex.getMessage());
			log.error(ex.getMessage(), ex);
			throw new BNPApplicationException(ex.getErrorCode(),ex.getMessage());
		}finally{
			if(null != jasperInputStream){
				try{
					jasperInputStream.close();
				}catch(Exception e){
					log.error(e.getMessage() + Arrays.toString(e.getStackTrace()) + " - "+ e);
					throw new BNPApplicationException(e.getMessage());
				}
			}
			if(null != pdfOutputStream){
				try{
					pdfOutputStream.close();
				}catch(Exception e){
					log.error(e.getMessage() + Arrays.toString(e.getStackTrace()) + " - "+ e);
					throw new BNPApplicationException(e.getMessage());
				}
			}
			
			if(null != logoInputStream){
				try{
					logoInputStream.close();
				}catch(Exception e){
					log.error(e.getMessage() + Arrays.toString(e.getStackTrace()) + " - "+ e);
					throw new BNPApplicationException(e.getMessage());
				}
			}
						
			if(null != rs)
			{
				try
				{
					rs.close();
				}catch(Exception e)
				{
					log.error(e.getMessage() + Arrays.toString(e.getStackTrace()) + " - "+ e);
					throw new BNPApplicationException(e.getMessage());
				}
				
			}
		}
	}
	
	/**
	 * FO 10.0 Changes - Generic Framework to handle writing data to XLS with multiple sections
	   The input exportRequestVO should contain headersList(sectionsHeader), dataList(sectionsData), sectionsList(No of sections in the XL).
	   As of now, the below method can be used for writing data into XL with basic styling(Bordering data).
	 * @param exportRequestVO
	 * @param prop
	 * @param outputStream
	 * @throws SQLException
	 * @throws BNPApplicationException
	 * @throws IOException
	 */
	public void exportDataToXLS(ExportRequestVO exportRequestVO, Properties prop, ServletOutputStream outputStream) throws SQLException, BNPApplicationException, IOException 
	{
		long strTime;
		
		SXSSFWorkbook workBook = null;
		CellStyle cs1;
	
		try
		{
			log.debug("Starting execution of exportDataToXLS method");
			strTime = System.currentTimeMillis();
			setExportType(ExportUtil.XLS);
			
			// XL Settings
			workBook = new SXSSFWorkbook();
		
			cs1 = workBook.createCellStyle();
			cs1.setBorderBottom(CellStyle.BORDER_THIN);
			cs1.setBorderLeft(CellStyle.BORDER_THIN);
			cs1.setBorderRight(CellStyle.BORDER_THIN);
			cs1.setBorderTop(CellStyle.BORDER_THIN);
					
			//Writing data in XL.
			writeDataIntoXL(exportRequestVO, workBook, prop, cs1, cs1, true);	
			
			//Writing in Stream
			workBook.write(outputStream);
			outputStream.flush();
			
			log.debug("Writing XL completed.");
			log.debug("Time taken in Service Layer XLS ----> " + (System.currentTimeMillis() - strTime));
			
		} 
		catch (Exception ex) 
		{
			log.error(ex.getMessage() + Arrays.toString(ex.getStackTrace()), ex);
			throw new BNPApplicationException(ex.getMessage());
		}
		finally
		{
			if(null !=  outputStream)
			{
				outputStream.close();
			}	
			
			if(null !=  workBook)
			{
				workBook.dispose();
			}
		}
	}

	/**
	 * FO 10.0 Changes - Generic Framework to handle writing data to CSV with multiple sections
	 * @param exportRequestVO
	 * @param workBook
	 * @param prop
	 * @param headerStyle
	 * @param dataStyle
	 * @param autoSizeableCols
	 * @throws BNPApplicationException
	 */
	private void writeDataIntoXL(ExportRequestVO exportRequestVO, SXSSFWorkbook workBook, Properties prop, CellStyle headerStyle, CellStyle dataStyle, Boolean autoSizeableCols)
			 throws BNPApplicationException
	{
		
		List<String> currentSectionHeader;
		ResultSet rs = null;
		ResultSetMetaData md;
		
		int columnCount;
		int maxColumnCount = 0;
		int rowCount = 0;
		
		SXSSFSheet sh;
		CellStyle cellStyle;
		Row row;
		Cell cell;
		Date dateValue;
			
		try
		{
			sh = (SXSSFSheet) workBook.createSheet(exportRequestVO.getFileName());
			cellStyle = workBook.createCellStyle();
			
			for(int i =0; i <exportRequestVO.getSectionsList().size();i++)
			{
				currentSectionHeader = exportRequestVO.getSectionsHeader().get(i);
				maxColumnCount = currentSectionHeader.size() > maxColumnCount ? currentSectionHeader.size() : maxColumnCount;
				rs = exportRequestVO.getSectionsData().get(i);
				
				//When there are no rows in the Resultset, Do not write header also
				if(rs.next())
				{
					//Section Header
					log.debug("Writing Header Information");
					row = sh.createRow(rowCount);
					for (int j = 0; j < currentSectionHeader.size(); j++) 
					{
						cell = row.createCell(j);
						cell.setCellValue(prop.getProperty((String)currentSectionHeader.get(j)));
						if(currentSectionHeader != null)
						{
							cell.setCellStyle(headerStyle);
						}
					}
					log.debug("Header Section:" + currentSectionHeader.toString());
					rowCount = rowCount + 1;
					
							
					//Section Data
					log.debug("Writing Data");
					md = rs.getMetaData();
					do 
					{
						columnCount = 0;
						row = sh.createRow(rowCount);
						
						for(int j = 0; j < currentSectionHeader.size(); j++) 
						{								
							cell = row.createCell(columnCount);
							cellStyle = workBook.createCellStyle();
							cellStyle.cloneStyleFrom(dataStyle);
							
							if(null != rs.getObject(columnCount+1) && !"".equals(rs.getObject(columnCount+1)))
							{
								if(md.getColumnTypeName(columnCount+1).equals("NUMBER")) 
								{
									cell.setCellType(Cell.CELL_TYPE_NUMERIC);
									cell.setCellValue(Double.valueOf(getStringValue(rs.getObject(columnCount+1))));
								}
								/*else if(md.getColumnTypeName(columnCount+1).equals("DATE"))  
								{
									dateValue = rs.getDate(columnCount+1);
									cellStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("m/d/yy"));									
									cell.setCellValue(dateValue);
								}*/
								else if(md.getColumnTypeName(columnCount+1).equals("DATE"))  
						        {
						         
							         if(md.getColumnName(columnCount +1).equalsIgnoreCase("released_date") || md.getColumnName(columnCount+1).equalsIgnoreCase("uploaded_date")) {
							        	dateValue = rs.getTimestamp(columnCount+1);
							           	cellStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("m/d/yy h:mm")); // CSC-7881
							         	cell.setCellValue(dateValue);
							              
							         } else {
							        	 dateValue = rs.getDate(columnCount+1);
							        	 cellStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("m/d/yy"));
							        	 cell.setCellValue(dateValue);
							         }     
							        
						         }
								else 
								{
									cell.setCellValue(getStringValue(rs.getObject(columnCount+1)));
								}
							}
							else
							{
								cell.setCellValue("");
							}
							
							
							//Apply Style if required
							if(cellStyle != null)
							{
								cell.setCellStyle(cellStyle);
							}
							
							columnCount = columnCount + 1;
						}
						rowCount = rowCount + 1;
						log.debug("Finished writing data at row: "+rowCount);
					}while(rs.next());
					
					//Section seperators
					for(int k=0;k < Integer.parseInt(ExportConstants.EMPTY_ROWS_BW_SECTIONS);k++)
					{
						sh.createRow(rowCount);
						rowCount++;
					}
					log.debug("Section seperators created.");
				}
			}
			//Apply Auto Resizeable columns if required
			if(autoSizeableCols)
			{
				log.debug("Maximum columns in the Excel sheet:"+maxColumnCount);
				for(int a=0;a<maxColumnCount;a++)
					sh.autoSizeColumn(a);
			}
				
		}
		catch(Exception e)
		{
			log.error(e.getMessage() + Arrays.toString(e.getStackTrace()) + " - "+ e);
			throw new BNPApplicationException(e.getMessage());
		}
		finally
		{
			if(null != rs)
			{
				try
				{
					rs.close();
				}catch(Exception e)
				{
					log.error(e.getMessage() + Arrays.toString(e.getStackTrace()) + " - "+ e);
					throw new BNPApplicationException(e.getMessage());
				}
				
			}
		}
			
		
	}
	
	/**
	 * FO 10.0 Changes - Generic Framework to handle writing data to CSV with multiple sections
	   The input exportRequestVO should contain headersList(sectionsHeader), dataList(sectionsData), sectionsList(No of sections in the CSV).
	 * @param exportRequestVO
	 * @param outputStream
	 * @throws SQLException
	 * @throws BNPApplicationException
	 * @throws IOException 
	 * @Description export Popup
	 */
	public void exportDataToCSV(ExportRequestVO exportRequestVO, Properties prop, ServletOutputStream outputStream) throws SQLException, BNPApplicationException, IOException 
	{
		log.debug("Exporting Data in CSV starts - exportCSVPopup");
		ResultSet rs = null;
		List<String> currentSectionHeader = null;
		setExportType(ExportUtil.CSV);
		StringBuilder data;
		
		try{
			
			long strTime = System.currentTimeMillis();
			for(int i=0;i<exportRequestVO.getSectionsHeader().size();i++)
			{
				rs = exportRequestVO.getSectionsData().get(i);
				
				//When there are no rows in the Resultset, Do not write header also
				if(rs.next())
				{
					//Section Header
					data = new StringBuilder();
					currentSectionHeader = exportRequestVO.getSectionsHeader().get(i);
					for(int j=0;j<currentSectionHeader.size();j++)
					{
						data.append(getStringValue(prop.getProperty((String)currentSectionHeader.get(j))));
					}
					
					String sHeader = data.substring(0, data.length()-1);
					
					outputStream.write(sHeader.getBytes("UTF-8"));
					outputStream.write('\n');
					
					
					//Section Data
					do
					{
						data = new StringBuilder();
						for (int j = 1; j <= currentSectionHeader.size(); j++) {
							data.append(getStringValue((rs.getObject(j) != null && !"".equals(rs.getObject(j))) ? rs.getObject(j).toString() : ""));
						}
						String sValue=data.substring(0, data.length()-1);
						outputStream.write(sValue.getBytes("UTF-8"));
						outputStream.write('\n');
					}while (rs.next());
					
					
					//Section seperators
					for(int k=0;k < Integer.parseInt(ExportConstants.EMPTY_ROWS_BW_SECTIONS);k++)
					{
						outputStream.write('\n');
					}
				}
				
				
			}
			log.debug("Time taken in Service Layer CSV ----> " + (System.currentTimeMillis()-strTime));
			outputStream.flush();
				
		}
		catch(Exception ex)
		{
			log.error(ex.getMessage(), ex);
			throw new BNPApplicationException(ex.getMessage());
		}
		finally
		{
			if(null != outputStream)
			{
				outputStream.close();
			}
			if(null != rs)
			{
				rs.close();
			}
		}
	}



/**
 * This method is for getting DB connection
 * 
 * @return Connection
 * @throws BNPApplicationException 
 * @Description get Connection
 */
public Connection getConnection() throws BNPApplicationException{
		  Connection connection = null;
	try{

		connection= DriverManager.getConnection("jdbc:oracle:thin:@10.184.153.184:1521: orcl","rel10_st2","o");	
		//connection = DriverManager.getConnection("jdbc:oracle:thin:@10.184.153.184:1521:orcl","rel10_st2","o");

		}catch(Exception e){
			log.error(e.getMessage());
			// Added for Sonar Fix - starts
			if(connection != null){
        		try {
        			connection.close();

        		} catch (SQLException ex) {
        			log.error("Exception Occured in exportReportsData" + ex.getMessage());
        		}
			}
			// Added for Sonar Fix - ends
			 throw new BNPApplicationException(e.getMessage());	    
		}
        	
	return connection;
}




}
