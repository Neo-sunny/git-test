/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   29 Mar 2017	
 * 
 * Purpose:       Buyer Acceptance screen
 * 
 * Change History: 
 * Date                       Author                                    Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 29 Mar 2017			      kmanimar					                Initial Version - FO 10.0 - S2098
 * 10 Apr 2017                 srreshmi                                  FO 10.0-S2066-attachment popup
************************************************************************************************************************************************************/
package com.bnp.bnpux.service;

import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.vo.requestVO.BuyerAcceptanceRequestVO;
import com.bnp.bnpux.vo.responseVO.BuyerAcceptanceResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface IBuyerAcceptanceNewUXService {
	
	/**
	 * This method is for getting Buyer Acceptance Service details
	 * 
	 * @param BuyerAcceptanceRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	BuyerAcceptanceResponseVO getBuyerAcceptanceDetails(BuyerAcceptanceRequestVO buyerAcceptanceRequestVO) throws BNPApplicationException;
	
	
	/**
	 * This method is for getting Buyer Acceptance Service count for Advanced filter
	 * 
	 * @param BuyerAcceptanceRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	BuyerAcceptanceResponseVO getAdvancedFilterCount(BuyerAcceptanceRequestVO buyerAcceptanceRequestVO) throws BNPApplicationException;
	/**
	 * This method is for getting Attachment List details
	 * 
	 * @param BuyerAcceptanceRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	BuyerAcceptanceResponseVO getAttachmentList(BuyerAcceptanceRequestVO buyerAcceptanceRequestVO)throws BNPApplicationException;
	
	/**
	 * This method is for performing buyer acceptance actions
	 * @param user 
	 * 
	 * @param BuyerAcceptanceActionsRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */	
	BuyerAcceptanceResponseVO doBuyerAcceptanceAction(BuyerAcceptanceRequestVO actionReqVO, UserInfoVO user) throws BNPApplicationException;

	
}
