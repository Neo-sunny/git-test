/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   21 June 2017
 * 
 * Purpose:     Credit Note Inquiry Report Service Interface
 * 
 * Change History: 
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 21 June 2017       Ratna Gokhale, Oracle Financial Services Software Ltd     Initial Version
 * 
 *****************************************************************************************************************************************************************/
package com.bnp.bnpux.service;

import com.bnp.bnpux.vo.requestVO.AgingRequestVO;
import com.bnp.bnpux.vo.responseVO.AgingResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface IAgingReportService {

	/**
	 * This method is for getting Credit Note Inquiry Report list
	 * 
	 * @param agingReqVO
	 * @return
	 * @throws BNPApplicationException
	 */
	AgingResponseVO getReportList(AgingRequestVO agingReqVO)	throws BNPApplicationException;


}
