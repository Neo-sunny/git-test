/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Abstract Service Implementation
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.discounting.serviceImpl;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.net.InetAddress;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang.StringUtils;
import org.jfree.util.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bnp.bnpux.serviceimpl.ErrorMessageHelper;
import com.bnp.bnpux.vo.errorMessageVO.ErrorMessageVO;
import com.bnp.eipp.services.vo.payment.EippPymtVO;
import com.bnp.scm.common.IResourceManager;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.ExportDataUtil;
import com.bnp.scm.services.common.IAccessLogService;
import com.bnp.scm.services.common.IAttachmentService;
import com.bnp.scm.services.common.IAuthMatrixService;
import com.bnp.scm.services.common.IEventLogService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.BNPCommonUtil;
import com.bnp.scm.services.common.util.CacheConstants;
import com.bnp.scm.services.common.vo.AbstractVO;
import com.bnp.scm.services.common.vo.AttachmentVO;
import com.bnp.scm.services.common.vo.AuthProfileVO;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.bnp.scm.services.edraft.util.EdraftDigitalSign;
import com.bnp.scm.services.report.util.DynamicReportUtil;
public abstract class AbstractServiceImpl<T extends AbstractVO> {

	/* Added for DefectId:1256 STARTS*/
	private static final int DEFAULT_SUMMARYPAGE=1;
	private int summaryDefaultPage=DEFAULT_SUMMARYPAGE;
	/* Added for DefectId:1256 ENDS*/
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractServiceImpl.class);
	/**
	 * List to be used to populate the table grid
	 */
	protected List<T> tableDataList;
	
	/**
	 * List that contains the selected records
	 */
	protected List<T> selectedList;
	
	/**
	 * Index to track the index of the selected record 
	 */
	protected int currentIndex = -1;
	
	/**
	 * Current selected data
	 */
	protected T selectedData;
	
	//914727 CSCDEV-7078 24-DEC-2015 :START
	protected T dataBeforeModification;
	
	public boolean showMasterRecord;
	//914727 CSCDEV-7078 24-DEC-2015 :END

	
	
	/**
	 * Property for check All functionality
	 */
	protected boolean checkAll;
	
	/**
	 * Data model VO that will be passed as a parameter to fetch initial
	 * data and during search
	 */
	protected T dataVO;
	
	/**
	 * Number of records to be displayed
	 */
	private String displayRecordCount="10";
	
	/**
	 * Holds the height of the Data table
	 */
	private String height = "350px";
	
	/**
	 * Abstract VO to hold entitlement related details
	 */
	protected AbstractVO entitlementVO;
	
	/** The access log service. */
	@Autowired
	private IAccessLogService accessLogService;
	
	//914727 CSCDEV-7078 24-DEC-2015 :START
	
	public boolean isShowMasterRecord() {
		return showMasterRecord;
	}

	public void setShowMasterRecord(boolean showMasterRecord) {
		this.showMasterRecord = showMasterRecord;
	}
    
	
	public T getDataBeforeModification() {
		return dataBeforeModification;
	}

	public void setDataBeforeModification(T dataBeforeModification) {
		this.dataBeforeModification = dataBeforeModification;
	}
	//914727 CSCDEV-7078 24-DEC-2015 :END
	
	//added by sonika on 25Apr2012 
	protected AbstractVO userInfoVO;
	
	public AbstractVO getUserInfoVO() {
		return userInfoVO;
	}

	public void setUserInfoVO(AbstractVO userInfoVO) {
		this.userInfoVO = userInfoVO;
	}

	/*public boolean iseWareUser() {
		return eWareUser;
	}

	public void seteWareUser(boolean eWareUser) {
		this.eWareUser = eWareUser;
	}*/
	//private boolean eWareUser;
	protected String selectedTab;
	
	protected boolean openTogglePanel;
	
	public boolean isOpenTogglePanel() {
		return openTogglePanel;
	}
	public void setOpenTogglePanel(boolean openTogglePanel) {
		this.openTogglePanel = openTogglePanel;
	}
	
	public String getSelectedTab() {
		return selectedTab;
	}

	public void setSelectedTab(String selectedTab) {
		this.selectedTab = selectedTab;
	}
	//end of added by sonika on 25Apr2012 
	protected boolean showPreviewPanel=false;
	
	protected boolean showOneRecordPanel=false;
	
	protected boolean showMultipleRecordPanel=false;
	
	private Object tableState;
	
	//Added for Attachment details start 
	
	private AttachmentVO objAttDownloadVO;
	
	public List<AttachmentVO> listAttachmentDetails ;
	
	public List<AttachmentVO> selectedFileList;
	
	boolean checkAllFile;
	
	//Added for Transaction Sign On Starts
	
	/** The self signed cert. */
	private byte[] selfSignedCert;
	
	/** The file name. */
	private String fileName;
	
	/** The cert key. */
	private String certKey;
	
	/** The modal complete. */
	private boolean modalComplete = false;
	
	/** The is summary str. */
	private String isSummaryStr;
	
	/** The show certificate panel. */
	private boolean showCertificatePanel;
	
	/** The signature dtls. */
	private String signatureDtls;
	
	/** The edraft digital sign. */
	@Autowired
	private EdraftDigitalSign edraftDigitalSign;
	
	/** The auth matrix service. */
	@Autowired
	private IAuthMatrixService authMatrixService;
	
/*	@Autowired
	private CacheServiceImpl cacheService;*/
	
	
	@Autowired
	private ExportDataUtil exportDataUtil;
	
	@Autowired
	private DynamicReportUtil dynamicReportUtil;
	
	//Added for Transaction Sign On Ends	

	//Modified for Defect 6862 Starts
	/** The Constant EIPP_FIN_INQ_DET_FILE. */	
	private static final String EIPP_NON_FIN_INQ_DET_FILE = "/facelets/eipp/EippNonFinInquiryDetails.xhtml";
	
	private static final String EIPP_NON_FIN_INQ_BEAN="eippnonfininqbean";
	//Modified for Defect 6862 Ends
	protected String getIdForName(List<NameValueVO> list,String name){
		String id=null;
		if(name!=null && list!=null){
			NameValueVO vo=new NameValueVO();
			vo.setName(name);
			int pos=list.indexOf(vo);
			if(pos>=0){
			id=list.get(pos).getValue();
		}
			
		}
		return id;
	}
	
	//Added for Attachment details end
	
	public boolean isShowOneRecordPanel() {
		return showOneRecordPanel;
	}

	public void setShowOneRecordPanel(boolean showOneRecordPanel) {
		this.showOneRecordPanel = showOneRecordPanel;
	}

	public boolean isShowMultipleRecordPanel() {
		return showMultipleRecordPanel;
	}

	public void setShowMultipleRecordPanel(boolean showMultipleRecordPanel) {
		this.showMultipleRecordPanel = showMultipleRecordPanel;
	}

	public boolean isShowPreviewPanel() {
		return showPreviewPanel;
	}

	public void setShowPreviewPanel(boolean showPreviewPanel) {
		this.showPreviewPanel = showPreviewPanel;
	}
	@Autowired
	protected IResourceManager resourceManager;
	
	@Autowired
	protected ErrorMessageHelper errorMessageHelper;
	
/*	@Autowired
	protected LoginBean loginBean;*/
	
/*	@Autowired
	private	EntitlementService entitlementService;*/
	
	@Autowired
	protected BNPCommonUtil bnpUtil;
	
	@Autowired
	protected IEventLogService eventLogService;
	
	protected Object[] tableData;
	
	@Autowired
	protected BNPPropertyLoaderConfigurer propertyLoader;
	
	@Autowired
	private IAttachmentService objAttServ;
	
	@Autowired
	private IAuthMatrixService authMtxService;
	
	private int selectedRecordsCount;
	
	//Added For Bulk Update Functionality For Eware Start
	protected Map<String,String> editableField;
	
	//protected Map<String,Set<BulkUpdateVO>> editableFieldMap;

	protected String paramName;
	
	protected Object valueObject;
	
	protected Set<Object> masterRecordSet;
	
	protected boolean bulkUpdateComplete = false;
	
	//protected BulkUpdateVO bulkVO;
	//For Tab Switching
	protected boolean tab1Disabled;
	
	protected boolean tab2Disabled;
	
	protected boolean tab3Disabled;
	//For Tab Switching
	//Added For Bulk Update Functionality For Eware End

	//Added For Jquery Calendar Component For Eware Start
	private String jQDateFormat;
	
	public String getjQDateFormat() {
		return jQDateFormat;
	}

	public void setjQDateFormat(String jQDateFormat) {
		this.jQDateFormat = jQDateFormat;
	}
	//Added For Jquery Calendar Component For Eware End
	
	/*public BulkUpdateVO getBulkVO() {
		return bulkVO;
	}

	public void setBulkVO(BulkUpdateVO bulkVO) {
		this.bulkVO = bulkVO;
	}*/
	
	public boolean getTab1Disabled() {
		return tab1Disabled;
	}

	public boolean isBulkUpdateComplete() {
		return bulkUpdateComplete;
	}

	public void setBulkUpdateComplete(boolean bulkUpdateComplete) {
		this.bulkUpdateComplete = bulkUpdateComplete;
	}

	public Map<String, String> getEditableField() {
		return editableField;
	}

	public void setEditableField(Map<String, String> editableField) {
		this.editableField = editableField;
	}

	/*public Map<String, Set<BulkUpdateVO>> getEditableFieldMap() {
		return editableFieldMap;
	}

	public void setEditableFieldMap(Map<String, Set<BulkUpdateVO>> editableFieldMap) {
		this.editableFieldMap = editableFieldMap;
	}*/

	public String getParamName() {
		return paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	public Object getValueObject() {
		return valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	public Set<Object> getMasterRecordSet() {
		return masterRecordSet;
	}

	public void setMasterRecordSet(Set<Object> masterRecordSet) {
		this.masterRecordSet = masterRecordSet;
	}

	public void setTab1Disabled(boolean tab1Disabled) {
		this.tab1Disabled = tab1Disabled;
	}

	public boolean getTab2Disabled() {
		return tab2Disabled;
	}

	public void setTab2Disabled(boolean tab2Disabled) {
		this.tab2Disabled = tab2Disabled;
	}

	public boolean getTab3Disabled() {
		return tab3Disabled;
	}

	public void setTab3Disabled(boolean tab3Disabled) {
		this.tab3Disabled = tab3Disabled;
	}

	/* Added for DefectId:1256 STARTS*/
	public int getSummaryDefaultPage() {
		return summaryDefaultPage;
	}

	public void setSummaryDefaultPage(int summaryDefaultPage) {
		this.summaryDefaultPage = summaryDefaultPage;
	}
	/* Added for DefectId:1256 ENDS*/
	public Object[] getTableData() {
		return tableData;
	}

	public void setTableData(Object[] tableData) {
		this.tableData = copyArray(tableData);
	}

	/**
	 * This API has to be called from the 
	 * @PostConstruct method as well as during search.
	 * This API should forward a call to the service layer
	 * which accepts the dataVO as the parameter and returns
	 * the result based on the condition
	 * 
	 * @throws BNPApplicationException - in case of error
	 */
	public abstract void populateTableData() throws BNPApplicationException;
	
	/**
	 * Returns the relative context path to the view page
	 * @return
	 */
	protected abstract String getViewPage();
	
	/**
	 * Returns the relative context path to the summary page
	 * @return
	 */
	protected abstract String getSummaryPage();
	
	/**
	 * To be used for populating entitlement details
	 * @return
	 */
	protected abstract String getScreenConstant();
	
	/**
	 * Pre-requisite: Populate the screen constant and invoke
	 * this API from the @PostConstruct API in the bean to
	 * enable entitlement. 
	 */
/*	protected void populateEntitlementDetails() {
		
		List<FunctionVO> buttonToBeEnabled = null;
		try {
			buttonToBeEnabled = entitlementService.getFunctionsForUser(getUserId(), 
													getScreenConstant());
		} catch (BNPApplicationException e) {
			displayErrorMessage(e.getErrorCode());
		}
		entitlementVO = bnpUtil.enableButtons(buttonToBeEnabled);
	}*/
	//START - Add by Sonika for Static Eware entitlement	
	/*protected void populateStaticEwareEntitlementDetails(){
		
		LOGGER.debug("inside method populateStaticEwareEntitlementDetails");
		List<FunctionVO> functionsToBeEnabled = null;
		try {
			functionsToBeEnabled = entitlementService.getStaticFunctionsForUser(getUserId(), 
													getScreenConstant());
		} catch (BNPApplicationException e) {
			displayErrorMessage(e.getErrorCode());
		}
		LOGGER.debug("functionsToBeEnabled ::"+functionsToBeEnabled.size());
		userInfoVO = bnpUtil.enableFunctions(functionsToBeEnabled);
		
		
	}*/
	//END - Add by Sonika for Static Eware entitlement	
	/**
	 * To be used for screen access
	 */
/*	protected boolean isScreenEntitledToUser(){
		    boolean isScreenEntitledToUser = false;
		try{
			isScreenEntitledToUser=entitlementService.isScreenEntitledToUser(getUserTypeID(),getScreenConstant());
			
		}catch (BNPApplicationException e) {
			displayErrorMessage(e.getErrorCode());
		}
		return isScreenEntitledToUser;
	}*/
	/**
	 * Set entitlement for creating new record screen
	 */
	protected void setEntitlementForNewRecord() {		
		if (selectedData != null && entitlementVO != null) {
			selectedData.setSaveDisabled(false);
			selectedData.setEditDisabled(false);
			selectedData.setDeleteDisabled(true);
			selectedData.setUndoDisabled(true);
			selectedData.setApproveDisabled(true);
		}		
	}
	
	/**
	 * Restore the entitlement when switch back from create new record screen
	 */
	protected void restoreEntitlement() {		
		if (selectedData != null && entitlementVO != null) {
			selectedData.setSaveDisabled(entitlementVO.isEditDisabled());
			selectedData.setEditDisabled(entitlementVO.isEditDisabled());
			selectedData.setDeleteDisabled(entitlementVO.isDeleteDisabled());
			selectedData.setUndoDisabled(entitlementVO.getUndoDisabled());
			selectedData.setApproveDisabled(entitlementVO.isApproveDisabled());
		}		
	}
	
	/**
	 * Returns the current instance of the faces context
	 * @return
	 */
/*	public FacesContext getFacesContext() {
		return FacesContext.getCurrentInstance();
	}*/
	
	//Start Added by Giriraj 
	public void displayErrorMessage(String errorMsg) {
		/*getFacesContext().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,errorMsg, null));*/
	}
	
	
	public void displayInfoMessage(String statusMsg) {
		/*getFacesContext().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,statusMsg, null));*/
	}
	//End Added by Giriraj 
	/**
	 * Displays the error message
	 * @param errorCode
	 */
	public void displayErrorMessage(int errorCode) {	
/*		getFacesContext().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
								resourceManager.getMessage(errorCode), null));*/
	}
	public void displayErrorMessage(int errorCode,Object ... param) {
/*		getFacesContext().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
								resourceManager.getMessageAfterReplaceArg(errorCode,param), null));*/
	}
	
	/**
	 * Displays the info message
	 * @param statusCode
	 */
	public void displayInfoMessage(int statusCode) {
/*		getFacesContext().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
				resourceManager.getMessage(statusCode), null));*/
	}

	public void displayInfoMessage(int statusCode,String... parameters) {
		MessageFormat formatter = new MessageFormat("");
		String messageString = resourceManager.getMessage(statusCode);
		formatter.applyPattern(messageString);
		String dynamicMsg = formatter.format(parameters);
/*		getFacesContext().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,dynamicMsg, null));*/
	}
	
	public IResourceManager getResourceManager() {
		return resourceManager;
	}

	public void setResourceManager(IResourceManager resourceManager) {
		this.resourceManager = resourceManager;
	}

	public AbstractServiceImpl() {
		selectedList = new ArrayList<T>();
		/*
		 * Added for attachment util start 
		 */
		objAttDownloadVO = new AttachmentVO();
		selectedFileList = new ArrayList<AttachmentVO>();
		listAttachmentDetails = new ArrayList<AttachmentVO>();
		/*
		 * Added for attachment util end 
		 */
		//Added For Bulk Update Start
		masterRecordSet = new TreeSet<Object>();
		//editableFieldMap = DocSetUtil.GetEditableFieldMap();
		//Added For Bulk Update End
	}
	
	/*@PostConstruct
	public void init()throws BNPApplicationException{
		//Added For Jquery Calendar Component For Eware Start
		if(loginBean != null && loginBean.getUserPrefVO() != null) {
			setjQDateFormat(DocSetUtil.getJQDateFormat(loginBean.getUserPrefVO().getPreferredDateFmt()));
		}
		//Added For Jquery Calendar Component For Eware End		
	}*/
	
	public List<T> getSelectedList() {
		return selectedList;
	}

	//public AbstractBean()
	public void setSelectedList(List<T> selectedList) {
		this.selectedList = selectedList;
	}

	public int getCurrentIndex() {
		return currentIndex;
	}

	public void setCurrentIndex(int currentIndex) {
		this.currentIndex = currentIndex;
	}
	
	public T getSelectedData() {
		return selectedData;
	}

	public void setSelectedData(T selectedData) {
		this.selectedData = selectedData;
	}
	
	/**
	 * This property has to be set for the previous button
	 * to disable it when the first record is reached
	 * @return the status of the previous button
	 */
	public boolean getPrevButtonStatus() {
		return !(currentIndex > 0);
	}
	
	/**
	 * This property has to be set for the next button
	 * to disable it when the last record is reached
	 * @return the status of the next button
	 */
	public boolean getNextButtonStatus() {
		return !(currentIndex < (selectedList.size() - 1));
	}
	
	public String getDisplayRecordCount() {
		return displayRecordCount;
	}

	public void setDisplayRecordCount(String displayRecordCount) {
		this.displayRecordCount = displayRecordCount;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}
	
	public T getDataVO() {
		return dataVO;
	}

	public void setDataVO(T dataVO) {
		this.dataVO = dataVO;
	}

/*	public String getUserId() {
		return loginBean.getUserVO().getUserId();
	}*/
	
/*	public String getUserTypeID(){
		return loginBean.getUserVO().getUserTypeId();
	}*/
	
	public String getOrgDealType() {
		/*return loginBean.getUserPrefVO().getPrimaryOrgDealType();*/
		return null;
	}

	public int getSelectedRecordsCount() {
		return selectedRecordsCount;
	}

	public void setSelectedRecordsCount(int selectedRecordsCount) {
		this.selectedRecordsCount = selectedRecordsCount;
	}

	public void addSelectedData() {
		if(selectedData.getRowSelected()){
			selectedList.add(selectedData);
			if(selectedList.size()==tableDataList.size())
				setCheckAll(true);
		}
		else{
			if(checkAll)
				setCheckAll(false);
			selectedList.remove(selectedData);
		}
		final int listSize = selectedList.size();
		if(listSize==1){
			enableSinglePanel();
		}else if (listSize>1){
			enableMultiPanel();
		}else if(listSize<1){
			disablePanels();
		}
	}
	
	public void populatePreviousRecord() {
		setSelectedData(selectedList.get(--currentIndex));
	}
	
	public void populateNextRecord() {
		
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("populateNextRecord starts:"+ new Date());
		
		setSelectedData(selectedList.get(++currentIndex));
		// Added for restoring the entitlement for viewing the record
		restoreEntitlement();
		
		//FO 7.0 Fortify Issue Fix.
		
		//LOGGER.debug("populateNextRecord ends:"+ new Date());
		
	}

	public boolean getCheckAll() {
		return checkAll;
	}

	public void setCheckAll(boolean checkAll) {
		this.checkAll = checkAll;
	}
	public List<T> getTableDataList() {
		return tableDataList;
	}

	public void setTableDataList(List<T> tableDataList) {
		this.tableDataList = tableDataList;
	}

	public AbstractVO getEntitlementVO() {
		return entitlementVO;
	}

	public void setEntitlementVO(AbstractVO entitlementVO) {
		this.entitlementVO = entitlementVO;
	}

	public void selectAllRecords() {
		boolean status = getCheckAll();
		if (status && tableDataList != null) {
			selectedList = new ArrayList<T>(tableDataList);
			if(selectedList.size() ==1){
				enableSinglePanel();
			} else {
				enableMultiPanel();
			}
		} else {
			getSelectedList().clear();
			disablePanels();
		}
		toggleSelection(status);
	}
	
	private void toggleSelection(boolean status) {
		if(tableDataList!=null)
		{
		for ( int i = 0 ; i < tableDataList.size() ; i++){
			tableDataList.get(i).setRowSelected(status);
		}		
	}
	}
	
	public boolean checkRowSelected() {
		
		//if(checkTableDataList()){// Updated for Recall New UX Changes 
		if(selectedList != null && !selectedList.isEmpty()){
			return true;
			/*} else {
			displayErrorMessage(ErrorConstants.SELECT_ROW);
			return false;
		}*/
		}else{
			displayErrorMessage(ErrorConstants.NO_SEARCH_RESULT);
			return false;
		}
	}
	
	public boolean checkTableDataList() {
		
		if(tableDataList != null && !tableDataList.isEmpty()){
			return true;
		} else {
			displayErrorMessage(ErrorConstants.SELECT_ROW);
			return false;
		}
	}
	
	/**
	 * Invoke this API to go the view page
	 * @return
	 */
	public String viewRecordDetails()
	{
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("viewRecordDetails starts:"+ new Date());
		
		String toPage=null;
		
		if(checkRowSelected())
		{
			populateNextRecord();
			toPage = getViewPage();
		}
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("viewRecordDetails ends before return:"+ new Date());
		
		return toPage;
	}
	
	public void clearDataList()
	{
		setSelectedData(null);
		//getSelectedList().clear();
		currentIndex=-1;
		setCheckAll(false);
		disablePanels();	
	}
	
	/**
	 * Reset data for pagination.
	 */
	public void resetDataForPagination(){
	  //Pagination Issues [CSCDEV-7514 , CSCDEV-7513 , CSCDEV-7510]
	  clearDataList();
	  startingRecord=1;
	  endingRecord = 10;
	  setSummaryDefaultPage(DEFAULT_SUMMARYPAGE);
	}
	
	/**
	 * Invoke this API to perform search operation
	 */
	public void searchData() {
		try {
			populateTableData();
			clearDataList();
			startingRecord=1;
			endingRecord = 10;
			//Pagination Issues [CSCDEV-7514 , CSCDEV-7513 , CSCDEV-7510]
			setSummaryDefaultPage(DEFAULT_SUMMARYPAGE);
		} catch (BNPApplicationException e) {
			LOGGER.error("Error in searchData "+e.getMessage() +e.getErrorCode(),e);
			//displayErrorMessage(e.getErrorCode());
		}		
	}
	
	public void clearData() {
		
		try{
			clearDataList();
			clearVO();
			populateTableData();
		}
	  
		catch(BNPApplicationException e)
		{
	       LOGGER.error("ERROR WHILE POPULATING DATA");
	       LOGGER.error("Error in searchData "+e.getMessage() + e.getErrorCode(),e);
	       //displayErrorMessage(e.getErrorCode());
		}
	}
	
	/**
	 * Clear form values. (Added as part of Eware)
	 */
/*	public void clearSearchCriteria(ActionEvent event) {
		UIComponent component = event.getComponent();
		Iterator<UIComponent> children = component.getParent().getParent().getParent().getChildren().iterator();
		while (children.hasNext()) {
			UIComponent child = children.next();
			if(child != component) {
				children.remove();
			}
		}
		clearDataList();
		clearVO();
	}*/
	
	/**
	 * Use this API for cancel button to go to the summary page
	 * @return
	 */
	public String goToSummaryPage()
	{
		clearDataList();
		//clearVO();
		searchData();
		/* Added for DefectId:1256 STARTS*/
		setSummaryDefaultPage(DEFAULT_SUMMARYPAGE);
		/* Added for DefectId:1256 ENDS*/
		return getSummaryPage();
	}
	
	/**
	 * Change row height and number of records to be displayed based on
	 * the availability of the search panel.
	 *  
	 * @param ae
	 */
/*	public void changeRows(ActionEvent ae) {
		HtmlSimpleTogglePanel searchToggle = (HtmlSimpleTogglePanel)ae.getComponent();
		if(searchToggle.isOpened()){
			setDisplayRecordCount("10");
			setHeight("350px");
		} else {
			setDisplayRecordCount("15");
			setHeight("450px");
		}
	}	*/
	public void clearVO()
	{
		try {
			if (dataVO != null) {
				dataVO = (T) dataVO.getClass().newInstance();
			}
		} catch (InstantiationException e) {
			
			LOGGER.error("InstantiationException OCcured in clearData" +e);
		} catch (IllegalAccessException e) {
			
			LOGGER.error("IllegalAccessException OCcured in clearData" +e);
		}
	}
/*	public void clearData(ActionEvent event) {
		
		try{
			UIComponent component = event.getComponent();
			 Iterator<UIComponent> children = component.getParent().getChildren().iterator();
			 while (children.hasNext()) {
				 UIComponent child = children.next();
				 if (child != component) {
					 children.remove();
				 }
			 }
			clearDataList();
			populateTableData();
			clearVO();
		}
	  
		catch(BNPApplicationException e)
		{
	       LOGGER.error("ERROR WHILE POPULATING DATA");
	       displayErrorMessage(e.getErrorCode());
		}
	}*/
	
	private void enableSinglePanel(){
		showPreviewPanel = true;
		showOneRecordPanel = true;
		showMultipleRecordPanel = false;
	}
	
	private void enableMultiPanel(){
		showPreviewPanel = true;
		showOneRecordPanel = false;
		showMultipleRecordPanel = true;
	}
	
	/**
	 * 
	 */
	private void disablePanels(){
		showPreviewPanel = false;
		showOneRecordPanel = false;
		showMultipleRecordPanel = false;
	}
	
	public int getStartingRecord() {		
		return startingRecord;
	}

	public void setStartingRecord(int startingRecord) {
		this.startingRecord = startingRecord;
	}
	public int getEndingRecord() {
		//added for prod defect 2845 starts
		//FO8.0 UAT Defect fix:CSCDEV-7049-Starts
		if(rowCount!=null && tableDataList != null){
          if(tableDataList.size() >= rowCount && endingRecord >= rowCount){
		    endingRecord = rowCount;
		  }else if(endingRecord >= tableDataList.size()){
		    endingRecord = tableDataList.size();
		  }
		}//FO8.0 UAT Defect fix:CSCDEV-7049-Ends
		//added for prod defect 2845 ends
		else if(tableDataList != null){
			if(endingRecord >= tableDataList.size()){
				endingRecord = tableDataList.size();
			}
		}
		return endingRecord;
	}

	public void setEndingRecord(int endingRecord) {
		this.endingRecord = endingRecord;
	}
	private int startingRecord = 1;
	
	private int endingRecord = 10;
	
/*	public void getShowingResults(DataScrollerEvent scrEv){
		int newPage = 0;
		if(scrEv.getNewScrolVal().equalsIgnoreCase("previous")){
			newPage = Integer.parseInt(scrEv.getOldScrolVal())-1;
		}else if(scrEv.getNewScrolVal().equalsIgnoreCase("next")){
			newPage = Integer.parseInt(scrEv.getOldScrolVal())+1;
		}else{
			newPage = Integer.parseInt(scrEv.getNewScrolVal());
		}
 		int recCount = Integer.parseInt(displayRecordCount);
		startingRecord = ((newPage-1)*recCount )+1;
		endingRecord = startingRecord + recCount -1 ;
	}*/
	
	public Object[] copyArray(Object[] source) {
		
		Object[] dest = null;
		 if (source != null) {
			 dest = new Object[source.length];

			 System.arraycopy(source, 0, dest, 0, source.length);
		 }

      return dest;
   }

	public void setTableState(Object tableState) {
		this.tableState = tableState;
	}

	public Object getTableState() {
		return tableState;
	}
	
	/*public List<NameValueVO> fetchAutocompleteData(Object suggestObj) {
    	String prefData = ((String) suggestObj).trim();
        List<NameValueVO> result = new ArrayList<NameValueVO>();

        String attribute = 
        			FacesContext.getCurrentInstance().getExternalContext().
        						getRequestParameterMap().get("componentName");
        
        List<NameValueVO> dataList = getAutoCompleteSearchData(attribute);
        
	    if (dataList == null || dataList.isEmpty()) {
	       	return result;
	    }
       
       String value = null;
       
       if (prefData.isEmpty()) {
    	   return dataList;
       }
       
       for (NameValueVO data : dataList) {
    	   value = data.getName();
    	   
		   if ((value != null && 
				   value.toLowerCase().indexOf(
				prefData.toLowerCase()) == 0)) {
			   result.add(data);
			}
       }
        return result;
    }*/
	
	/**
	 * 
	 * This method has to be overridden in all the subclasses wherever suggestion box is
	 * implemented as part of QAIS changes. This will make sure that all the data fetching
	 * logic is handled in one single method.
	 * @param attribute
	 * @return the List of matched values
	 */
	protected List<NameValueVO> getAutoCompleteSearchData(String attribute) {
		return new ArrayList<NameValueVO>();
	}

	/**
	 * Check null.
	 *
	 * @param userInput the user input
	 * @return true, if successful
	 */
	protected boolean checkNull(String userInput){
		boolean isValid=false;
		if(userInput !=null && userInput.trim().length()>0){
			isValid= true;	
		}
		return isValid;
	}

	/**
	 * Check list null.
	 *
	 * @param inputList the input list
	 * @return true, if successful
	 */
	protected boolean checkListNull(List inputList){
		boolean isValid=false;
		if(inputList !=null && !inputList.isEmpty()){
			isValid= true;	
		}
		return isValid;
	}
	
	/**
	 * Checks if is event value changed.
	 *
	 * @param event the event
	 * @return true, if is event value changed
	 */
/*	protected boolean isEventValueChanged(ValueChangeEvent event){
		boolean isValid=true;
		if((event.getOldValue()==null || event.getOldValue().toString().trim().length()==0) && (event.getNewValue()==null || event.getNewValue().toString().trim().length()==0) ){
			isValid= false;	
		}
		return isValid;
	}*/
	
	/**
	 * Gets the view details from link.
	 *
	 * @return the view details from link
	 */
	public String getViewDetailsFromLink(){
		getSelectedList().clear();
		selectedData.setRowSelected(true);
		addSelectedData();
		return viewRecordDetails();
	}
	
	/**
	 * View PDF.
	 *
	 * @param outputFileName the output file name
	 * @param content the content
	 * @throws BNPApplicationException the bNP application exception
	 */
/*	protected void viewPDF(String outputFileName,byte[] content) throws BNPApplicationException {
		try
		{
			FacesContext context = getFacesContext();
			HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();
			HttpSession session = request.getSession();
			session.setAttribute(BNPConstants.ZIP_FILE_ATTRIBUTE, content);
			session.setAttribute(BNPConstants.FILE_TYPE, BNPConstants.PDF_FORMAT);
			session.setAttribute(BNPConstants.FILE_NAME, outputFileName);
		}
		catch(Exception e)
		{
			LOGGER.error("Error while closing stream : " + e);
			throw new BNPApplicationException(ErrorConstants.ERROR_VIEW_PDF);
		}
	}*/
/*	protected void viewPdf(String outputFileName,byte[] content) throws BNPApplicationException {
		OutputStream outputStream = null;
		try
		{
			FacesContext context = getFacesContext();
			HttpServletResponse response = (HttpServletResponse) context.getExternalContext().getResponse();
			response.setContentType(BNPConstants.CONTENT_TYPE);
			response.setHeader(BNPConstants.CONTENT_DISPOSITION,"attachment; filename=" +outputFileName );
			response.setHeader("Cache-Control", ""); // HTTP 1.1.
			response.setHeader("Pragma", ""); // HTTP 1.0.
			response.setContentLength(content.length);
			outputStream = response.getOutputStream();
			outputStream.write(content);
			outputStream.flush();
			outputStream.close();
			context.responseComplete();
		}
		catch(Exception e)
		{
			LOGGER.error("Error while closing stream : " + e);
			throw new BNPApplicationException(ErrorConstants.ERROR_VIEW_PDF);
		}
	}*/
	
	/**
	 * Method to down load the single/multiple attachment
	 * @throws BNPApplicationException
	 */

/*	public void downLoadAll()throws BNPApplicationException
	{
		try
		{
		LOGGER.debug("Entered downLoadAttachment");
		byte[] readBuff;
			selectedData.setOpenFile(false);
		FacesContext facesContext = FacesContext.getCurrentInstance(); 
		HttpServletRequest request = (HttpServletRequest)facesContext.getExternalContext().getRequest(); 
			readBuff =objAttServ.compressFiles((ArrayList<AttachmentVO>)listAttachmentDetails);
			request.getSession().setAttribute(BNPConstants.ZIP_FILE_ATTRIBUTE, readBuff);
			setSelectedFileList(new ArrayList<AttachmentVO>());
			if(readBuff!=null)
			{
				selectedData.setOpenFile(true);
				toggleSelectionData(false);
				checkAllFile=false;
		}
		}
		catch (Exception e) {
			selectedData.setOpenFile(false);
			LOGGER.error("Exception in download all attachments  " + e.getMessage());
			displayErrorMessage(ErrorConstants.DOWNLOAD_ATT_ERROR);
		}
	}
	public void closeModalPanel() {
		FacesContext facesContext = FacesContext.getCurrentInstance(); 
		HttpServletRequest request = (HttpServletRequest)facesContext.getExternalContext().getRequest(); 
		HttpSession session = request.getSession();
		session.removeAttribute(BNPConstants.ZIP_FILE_ATTRIBUTE);
	}*/
	/**
	 * Method to download a single file
	 * @throws BNPApplicationException: thrown when there is an error in the calling methods
	 */
/*	public void downLoadAttachment()throws BNPApplicationException
	{
		try
		{
			if(checkFileSelected())
			{
		LOGGER.debug("Entered downLoadAttachment");
				selectedData.setOpenFile(false);
		byte[] readBuff;
		FacesContext facesContext = FacesContext.getCurrentInstance(); 
		HttpServletRequest request = (HttpServletRequest)facesContext.getExternalContext().getRequest(); 
			readBuff =objAttServ.compressFiles((ArrayList<AttachmentVO>)selectedFileList);
			request.getSession().setAttribute(BNPConstants.ZIP_FILE_ATTRIBUTE, readBuff);
				setSelectedFileList(new ArrayList<AttachmentVO>());
				if(readBuff!=null)
				{
					selectedData.setOpenFile(true);
					toggleSelectionData(false);
					checkAllFile=false;
				}
			}
			else
			{
				selectedData.setOpenFile(false);
		}
		}
		catch (Exception e) {
			selectedData.setOpenFile(false);
			LOGGER.error("Exception in downLoadAttachment" + e.getMessage());
			displayErrorMessage(ErrorConstants.DOWNLOAD_ATT_ERROR);
		}
	}*/

	/**The following methods are added as a part for Attachment Utility
	 * To set the state of the check box selected and to add the value to the attachment list  
	 * START 
	 */
	public void checkAllFile() {
		boolean status = isCheckAllFile();
		if (status && listAttachmentDetails != null) {
			selectedFileList = new ArrayList<AttachmentVO>(listAttachmentDetails);
		} else {
			getSelectedFileList().clear();
		}
		toggleSelectionData(status);
	}
	private void toggleSelectionData(boolean status) {
		for ( int i = 0 ; i < listAttachmentDetails.size() ; i++){
			listAttachmentDetails.get(i).setRowSelectedOneFile(status);
		}		
	}
	
	public boolean checkFileSelected() {
		if(selectedFileList != null && !selectedFileList.isEmpty()){
			return true;
		} else {
			checkAllFile=false;
			displayErrorMessage(ErrorConstants.SELECT_ROW);
			return false;
		}
	}
	
/*	public void downloadFromLink() {
		objAttDownloadVO.setRowSelectedOneFile(true);
		setSelectedFileList(new ArrayList<AttachmentVO>());
		selectedFileList.add(objAttDownloadVO);
		try {
			downLoadAttachment();
		} catch (BNPApplicationException e) {
			displayErrorMessage(e.getErrorCode());
		}
	}*/
	
	public void addSelectedDataFile() {
		if(objAttDownloadVO.isRowSelectedOneFile()){
				selectedFileList.add(objAttDownloadVO);
			if(selectedFileList.size()==listAttachmentDetails.size())
				setCheckAllFile(true);
		}
		else{
			if(checkAllFile)
			{
				setCheckAllFile(false);
			selectedFileList.remove(objAttDownloadVO);
			}
		}
	}

	public AttachmentVO getObjAttDownloadVO() {
		return objAttDownloadVO;
	}

	public void setObjAttDownloadVO(AttachmentVO objAttDownloadVO) {
		this.objAttDownloadVO = objAttDownloadVO;
	}

	public List<AttachmentVO> getListAttachmentDetails() {
		return listAttachmentDetails;
	}

	public void setListAttachmentDetails(List<AttachmentVO> listAttachmentDetails) {
		this.listAttachmentDetails = listAttachmentDetails;
	}

	public List<AttachmentVO> getSelectedFileList() {
		return selectedFileList;
	}

	public void setSelectedFileList(List<AttachmentVO> selectedFileList) {
		this.selectedFileList = selectedFileList;
	}

	public boolean isCheckAllFile() {
		return checkAllFile;
	}

	public void setCheckAllFile(boolean checkAllFile) {
		this.checkAllFile = checkAllFile;
	}
	/**
	 * Gets the self signed cert.
	 *
	 * @return the self signed cert
	 */
	public byte[] getSelfSignedCert() {
		return selfSignedCert;
	}

	/**
	 * Sets the self signed cert.
	 *
	 * @param selfSignedCert the new self signed cert
	 */
	public void setSelfSignedCert(byte[] selfSignedCert) {
		this.selfSignedCert = copyArray(selfSignedCert);
	}

	/**
	 * Gets the file name.
	 *
	 * @return the file name
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * Sets the file name.
	 *
	 * @param fileName the new file name
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * Gets the cert key.
	 *
	 * @return the cert key
	 */
	public String getCertKey() {
		return certKey;
	}

	/**
	 * Sets the cert key.
	 *
	 * @param certKey the new cert key
	 */
	public void setCertKey(String certKey) {
		this.certKey = certKey;
	}

	/**
	 * Checks if is modal complete.
	 *
	 * @return true, if is modal complete
	 */
	public boolean isModalComplete() {
		return modalComplete;
	}

	/**
	 * Sets the modal complete.
	 *
	 * @param modalComplete the new modal complete
	 */
	public void setModalComplete(boolean modalComplete) {
		this.modalComplete = modalComplete;
	}

	/**
	 * Gets the checks if is summary str.
	 *
	 * @return the checks if is summary str
	 */
	public String getIsSummaryStr() {
		return isSummaryStr;
	}

	/**
	 * Sets the checks if is summary str.
	 *
	 * @param isSummaryStr the new checks if is summary str
	 */
	public void setIsSummaryStr(String isSummaryStr) {
		this.isSummaryStr = isSummaryStr;
	}

	/**
	 * Checks if is show certificate panel.
	 *
	 * @return true, if is show certificate panel
	 */
	public boolean isShowCertificatePanel() {
		return showCertificatePanel;
	}

	/**
	 * Sets the show certificate panel.
	 *
	 * @param showCertificatePanel the new show certificate panel
	 */
	public void setShowCertificatePanel(boolean showCertificatePanel) {
		this.showCertificatePanel = showCertificatePanel;
	}
	
	/**
	 * Gets the signature dtls.
	 *
	 * @return the signature dtls
	 */
	public String getSignatureDtls() {
		return signatureDtls;
	}

	/**
	 * Sets the signature dtls.
	 *
	 * @param signatureDtls the new signature dtls
	 */
	public void setSignatureDtls(String signatureDtls) {
		this.signatureDtls = signatureDtls;
	}		
	/**The following methods are added as a part of EIPP
	 * To set the state of the check box selected and to add the value to the list  
	 * END 
	 */
	 
	 protected boolean isBuyerUser(String userType) {
		if (userType.equals(BNPConstants.SCMBALL) ||
			userType.equals(BNPConstants.SCMB) ||
			userType.equals(BNPConstants.SCMBOA) ||
			userType.equals(BNPConstants.BCMB) ||
			userType.equals(BNPConstants.BCMBOA) ||
			userType.equals(BNPConstants.BCMBALL) ||
			userType.equals(BNPConstants.BCMMPB)||
			userType.equals(BNPConstants.BCMMPBALL) ||
			userType.equals(BNPConstants.BCMMPBOA) 
			) {
				return true;
		}
		return false;
	}
	
	protected boolean isSupplierUser(String userType) {
		if (userType.equals(BNPConstants.SCMSALL) ||
			userType.equals(BNPConstants.SCMS) ||
			userType.equals(BNPConstants.SCMSOA) ||
			userType.equals(BNPConstants.BCMS) ||
			userType.equals(BNPConstants.BCMSOA) ||
			userType.equals(BNPConstants.BCMSALL)||
			userType.equals(BNPConstants.BCMMPS) ||
			userType.equals(BNPConstants.BCMMPSALL) ||
			userType.equals(BNPConstants.BCMMPSOA)
			){
			return true;
		}
		return false;
	}

	public void displayErrorMessage(int errorCode,String...params) {
/*		getFacesContext().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
								bnpUtil.constructMessage(loginBean.getLocale(), resourceManager.getMessage(errorCode), params), null));*/
	}

	public Object[] convertVOPropertiesToObjArray(T ObjectVO,String[] voPropArr) throws BNPApplicationException{
		Object objArg[] = new Object[voPropArr.length];
		try{
			
			for(int i=0;i<voPropArr.length;i++){
				objArg[i]=PropertyUtils.getProperty(ObjectVO, voPropArr[i]);
			}
			
			
		}catch(IllegalAccessException e1){
			Log.error(e1.getMessage(),e1);
			throw new BNPApplicationException(e1.getMessage());
		}catch(InvocationTargetException e2){
			Log.error(e2.getMessage(),e2);
			throw new BNPApplicationException(e2.getMessage());
		}catch(NoSuchMethodException e3){
			Log.error(e3.getMessage(),e3);
			throw new BNPApplicationException(e3.getMessage());
		}		return objArg;
		                             
	}
	//Added By Ram For Eware Bulk Update Functionality Start
	/*public void saveNewValue(){
		
		if(!selectedData.getRowSelected()){
			
			selectedData.setRowSelected(true);
			addSelectedData();
		}
		if(bulkUpdateComplete){
			clearEditableFieldMap();
			bulkUpdateComplete = false;
		}
		
		
		if(masterRecordSet == null ){
			masterRecordSet = new TreeSet<Object>();
			masterRecordSet.add(selectedData.getBulkUpdateId());
		}
		else{
			masterRecordSet.add(selectedData.getBulkUpdateId());
		}
		if(valueObject==null || valueObject.toString().trim().length()<=0){
			valueObject =null;
		}
		BulkUpdateVO bulkUpdateVO = new BulkUpdateVO(selectedData.getBulkUpdateId()+"", paramName, valueObject);
		Set<BulkUpdateVO> bulkUpdateSet = editableFieldMap.get(paramName);
		if(bulkUpdateSet.contains(bulkUpdateVO)){
			for (BulkUpdateVO bulkUpdate : bulkUpdateSet) {
				if(bulkUpdate.equals(bulkUpdateVO)){
					bulkUpdate.setParamName(paramName);
					bulkUpdate.setNewValueObject(valueObject);
					break;
				}
			}
		}else{
			bulkUpdateSet.add(bulkUpdateVO);
		}
		//selectedData.setStyleCss(EwareConstants.EXT_TXT_FONT_COLOR_CSS);
	}
	
	public void bulkUpdate(){
		if(checkRowSelectedForBulkUpdate() && validateBulkUpdate()){
			Set<String> kySet = editableField.keySet();
			for (Iterator<T> iterator = selectedList.iterator(); iterator.hasNext();) {
				T objT = iterator.next();
				Method[] arrMethod = objT.getClass().getMethods();	
				for (Iterator<String> itrKey = kySet.iterator(); itrKey.hasNext();) {
					String key = itrKey.next();
					String methodName = editableField.get(key);
					Set<BulkUpdateVO> setterValue =  editableFieldMap.get(key);
					if(setterValue!=null && setterValue.size()==1){
						for (int i = 0; i < arrMethod.length; i++) {
							Method method = arrMethod[i];
							if(method.getName().equals(methodName)){
								try {
									BulkUpdateVO bulkUpdateVO = setterValue.iterator().next();
									if(!(bulkUpdateVO.isSkipRecord() && objT.isSkipRecord())){
										method.invoke(objT,bulkUpdateVO.getNewValueObject());
									}
								} catch (IllegalArgumentException e) {
									 LOGGER.error("ERROR WHILE PERFORMING BULK UPDATE "+e.getMessage());
									displayErrorMessage(EwareErrorConstants.BULK_UPDATE_ERROR);
								} catch (IllegalAccessException e) {
									LOGGER.error("ERROR WHILE PERFORMING BULK UPDATE"+e.getMessage());
									displayErrorMessage(EwareErrorConstants.BULK_UPDATE_ERROR);
								} catch (InvocationTargetException e) {
									LOGGER.error("ERROR WHILE PERFORMING BULK UPDATE"+e.getMessage());
									displayErrorMessage(EwareErrorConstants.BULK_UPDATE_ERROR);
								}
								break;	
							}
						}				
					}
				}
			}	
			bulkUpdateComplete = true;
//			if(selectedList!=null && selectedList.size()>0){
//				for (T objT : selectedList) {
//					objT.setRowSelected(Boolean.FALSE);
//				}
//			}
			clearBulkUpdateStyleSheet();
			//clearDataList();
		}
		
	}
	
	public void clearEditableFieldMap(){
		masterRecordSet = new TreeSet<Object>();
		editableFieldMap = DocSetUtil.GetEditableFieldMap();
		clearBulkUpdateStyleSheet();
	}
	
	public void clearBulkUpdateStyleSheet(){
		if(selectedList!=null && selectedList.size()>0){
			for (T objT : selectedList) {
				objT.setStyleCss("");
			}
		}
	}
	public boolean validateBulkUpdate(){
		boolean isValidated = true;
		if(masterRecordSet!=null && masterRecordSet.size()>1){
			isValidated = false;
			displayErrorMessage(EwareErrorConstants.MULTIPLE_EDITED_RECORD,masterRecordSet);
		}else{
			Set<String> editableColumnkeySet = editableField.keySet();
			for (Iterator<String> itrEditColumn = editableColumnkeySet.iterator(); itrEditColumn.hasNext();) {
				String keyEditColumn = itrEditColumn.next();
				Set<BulkUpdateVO> bulkUpdateColumnSet = editableFieldMap.get(keyEditColumn);
				if(bulkUpdateColumnSet!=null && bulkUpdateColumnSet.size()>1){
					isValidated = false;
					displayErrorMessage(EwareErrorConstants.BULK_UPDATE_VALIDATION_ERROR);
					break;
				}
			}	
		}

		return isValidated;
	}
	

	public void selectData(){
		if(!selectedData.getRowSelected()){
			bulkVO = new BulkUpdateVO(selectedData.getBulkUpdateId());
			Set<String> editableColumnkeySet = editableField.keySet();
			for (Iterator<String> itrEditColumn = editableColumnkeySet.iterator(); itrEditColumn.hasNext();) {
				String keyEditColumn = itrEditColumn.next();
				Set<BulkUpdateVO> bulkUpdateColumnSet = editableFieldMap.get(keyEditColumn);
				if(bulkUpdateColumnSet!=null){
					bulkUpdateColumnSet.remove(bulkVO);
					selectedData.setStyleCss("");
				}
			}	
			masterRecordSet.remove(bulkVO.getId());
		}
		addSelectedData();
	}
	
	public void selectAllData(){
		boolean status = getCheckAll();
		if (!status && tableDataList != null) {
			clearEditableFieldMap();
			for (T objT : tableDataList) {
				objT.setStyleCss("");
			}
		}
		selectAllRecords();
	}
	
	public boolean checkRowSelectedForBulkUpdate() {
		
		if(checkTableDataList()){
			if(selectedList != null && selectedList.size() > 1){
				return true;
			} else {
				displayErrorMessage(EwareErrorConstants.SELECT_ROW_ERROR_BULK_UPDATE);
				return false;
			}
		}else{
			displayErrorMessage(ErrorConstants.NO_SEARCH_RESULT);
			return false;
		}
	}*/
	//Added By Ram For Eware Bulk Update Functionality End
	
	//Added By Ram For Tab Switching Start
	public void initializeTab(){
		tab1Disabled = Boolean.FALSE;
		tab2Disabled = Boolean.TRUE;
		tab3Disabled = Boolean.TRUE;
	}
	
	public void modifyTab(){
		tab2Disabled = Boolean.FALSE;
		tab3Disabled = Boolean.FALSE;
	}
	//Added By Ram For Tab Switching End

	
	// Horizontal Scroll Bar Remove - Start
	
	private boolean showHiddenColumns = false;
	
	private String tableHeight;

	/**
	 * @return the showHiddenColumns
	 */
	public boolean isShowHiddenColumns() {
		return showHiddenColumns;
	}

	/**
	 * @param showHiddenColumns the showHiddenColumns to set
	 */
	public void setShowHiddenColumns(boolean showHiddenColumns) {
		this.showHiddenColumns = showHiddenColumns;
	}
		
	public void toggleHiddenColumns() {
		setShowHiddenColumns(!showHiddenColumns);
	}
	
	public String getTableHeight() {
		if(tableDataList != null) {
			if(tableDataList.size() == 0 || tableDataList.size() == 1) {
				tableHeight = "120";
			}
			else if(tableDataList.size() >= 10) {
				tableHeight = "340";
			}
			else {
				tableHeight = String.valueOf((120 + (tableDataList.size() * 23)));
			}
		}
		else {
			tableHeight = "120";
		}
		return tableHeight;
	}
	// Horizontal Scroll Bar Remove - End	
	
	/**
	 * Displays the info message
	 * @param componentName
	 * @param statusCode
	 */
	public void displayInfoMessage(String componentName, int statusCode) {
/*		getFacesContext().addMessage(componentName, new FacesMessage(FacesMessage.SEVERITY_INFO,
				resourceManager.getMessage(statusCode), null));*/
	}
	
	/**
	 * Displays the error message
	 * @param componentName
	 * @param errorCode
	 * @param params
	 */
	public void displayErrorMessage(String componentName, int errorCode,String...params) {
/*		getFacesContext().addMessage(componentName, new FacesMessage(FacesMessage.SEVERITY_ERROR,
								bnpUtil.constructMessage(loginBean.getLocale(), resourceManager.getMessage(errorCode), params), null));*/
	}
	
	/**
	 * Gets the profile for function.
	 *
	 * @param profileVO the profile vo
	 * @return the profile for function
	 * @throws BNPApplicationException the bNP application exception
	 */
	protected AuthProfileVO getProfileForFunction(AuthProfileVO profileVO) throws BNPApplicationException{
		AuthProfileVO vo =  authMtxService.getAuthProfile(profileVO);
		return vo;
	}
	
	/**
	 * Convert forex rates.
	 *
	 * @param profileVO the profile vo
	 * @throws BNPApplicationException the bNP application exception
	 */
/*	protected void convertForexRates(AuthProfileVO profileVO) throws BNPApplicationException{
		profileVO.setSupportBranchCode(loginBean.getUserVO().getSupportBranchId());
		authMtxService.convertForexRates(profileVO);		
	}*/

	
	/**
	 * Gets the delimited string.
	 *
	 * @param userIDList the user id list
	 * @return the delimited string (delimited with ',')
	 */
	protected String getDelimitedString(List<String> userIDList){
		return StringUtils.join(userIDList, ",");
	}

	/**
	 * Checks if is market place user type.
	 *
	 * @param strUserId the str user id
	 * @return the string
	 */
	protected String isMarketPlaceUserType(String strUserTypeId) {
		String userType = null;
		if(	strUserTypeId.equalsIgnoreCase(BNPConstants.BCMMPU)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.SCMMPU)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.BCMMPOA)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.SCMMPOA)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.BCMMPALL)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.SCMMPALL)
			){
			userType= "MPUser";
		}else if(strUserTypeId.equalsIgnoreCase(BNPConstants.BCMBOA)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.SCMBOA)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.BCMSOA)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.SCMSOA)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.BCMB)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.BCMS)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.SCMB)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.SCMS)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.BCMBALL)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.BCMSALL)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.SCMBALL)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.SCMSALL)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.BCMMPBOA)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.BCMMPSOA)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.SCMMPSOA)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.SCMMPBOA)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.BCMMPBALL)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.BCMMPSALL)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.SCMMPSALL)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.SCMMPBALL)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.SCMMPS)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.SCMMPB)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.BCMMPB)||
				strUserTypeId.equalsIgnoreCase(BNPConstants.BCMMPS)){
			userType= "NonMPUser";
		}else if(strUserTypeId.equalsIgnoreCase(BNPConstants.BANKADMIN)){
			userType= "BA";
		}
		return userType;
		
	}

	/**
	 * Gets the auth mtx service.
	 *
	 * @return the auth mtx service
	 */
	public IAuthMatrixService getAuthMtxService() {
		return authMtxService;
	}
	//Added for Transaction Sign On Starts
	/**
	 * On upload.
	 *
	 * @param event the event
	 * @throws Exception the exception
	 */
/*	public void onUpload(UploadEvent event) throws Exception {
		LOGGER.debug("START UploadEvent() ");
		UploadItem uploadedItem = event.getUploadItem();
		//FO 8.0 Sonar Fix
		//String ContentType=uploadedItem.getContentType();
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("ContentType : "+ContentType);
		
		setFileName(uploadedItem.getFileName());
		byte[] uploadedKeystore = uploadedItem.getData();
		//FO 7.0 Fortify Issue Fix
		//if(LOGGER.isDebugEnabled())LOGGER.debug("inside onUpload, keystore size: "+uploadedKeystore.length);
		setSelfSignedCert(uploadedKeystore);
		
		LOGGER.debug("END UploadEvent() ");
	} */
	
	/**
	 * Validate cert with pin.
	 *
	 * @return the string
	 */
	/*@SuppressWarnings("deprecation")
	public String validateCertWithPin() {
	
		String userId = loginBean.getUserVO().getUserId();  
		LOGGER.debug("START validateCertificate() ");
		T vo = (T)selectedData;

		Certificate[] certChain = null;
		ArrayList<Certificate> certList = new ArrayList<Certificate>();
		X509Certificate storecert = null;
		CertStore certs = null;
	//	PublicKey pub = null;
		PrivateKey priv = null;
		FileInputStream fis = null;
		String propFileName= null;
		
		try {
			byte[] keyStoreArray=getSelfSignedCert();
			
			propFileName = getPropertyFile(vo);
			
			
			KeyStore keyStore = KeyStore.getInstance("PKCS12"); 
			keyStore.load(new ByteArrayInputStream(keyStoreArray), getCertKey().toCharArray());
			//FO 7.0 Fortify Issue Fix
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("VO_propFileName::"+propFileName);
			storecert = (X509Certificate)keyStore.getCertificate(userId);
		   if (storecert == null) {
			   throw new BNPApplicationException(ErrorConstants.CERT_INVALID);
		   }
		   priv = (PrivateKey)(keyStore.getKey(userId, getCertKey().toCharArray()));
	//	   pub = keyStore.getCertificate(userId).getPublicKey();
			certChain = keyStore.getCertificateChain(userId);
			for ( int i = 0; i < certChain.length;i++)
				certList.add(certChain[i]);

		   certs = CertStore.getInstance("Collection", new CollectionCertStoreParameters(certList), "BC");
		   
			  
		   CMSSignedDataGenerator signGen = new CMSSignedDataGenerator();
		   signGen.addSigner(priv, storecert, CMSSignedDataGenerator.DIGEST_SHA1);
		   signGen.addCertificatesAndCRLs(certs);
		 //FO 7.0 Fortify Issue Fix
		   if(LOGGER.isDebugEnabled())
				LOGGER.debug("Total records::"+getSelectedList().size());
			
			for(T currentVO : getSelectedList()){
				try{
					T dataVO = (T) currentVO;

					if(isSignOnEnabled(dataVO) && getFinalApprovalStatus(dataVO)){
						if(dataVO.getAuthMatxErrorCode() == 0){
							//FO 7.0 Fortify Issue Fix
							if(LOGGER.isDebugEnabled())
								LOGGER.debug("validateCertWithPin==>SupplierOrgId :"+dataVO.getSupplierOrgId());
								
							String digSign=edraftDigitalSign.generateSignature(propFileName,dataVO);
							CMSProcessable content = new CMSProcessableByteArray(digSign.getBytes());
								  
							CMSSignedData signedData = signGen.generate(content,"BC");
	
							byte[] signeddata = signedData.getEncoded();			
							byte[] encodedBytes = Base64.encode(signeddata);
	
							String sigBytes1 = new String(encodedBytes);
							//FO 7.0 Fortify Issue Fix
							if(LOGGER.isDebugEnabled())
							   LOGGER.debug("validateCertWithPin:: sigBytes::"+sigBytes1);
						   
							dataVO.setElecSign(sigBytes1);
							dataVO.setSignData(digSign);
						}
					}
				}catch(Exception e){
					LOGGER.error("Error in generating digital Signature:",e);
				}
			}
		}catch(Exception e)
		{
			LOGGER.error("Error in validateCertWithPin:",e);
			displayErrorMessage(ErrorConstants.CERT_INVALID);
			return  BNPConstants.EDRAFT_NOT_SUCCESS;
		}
		finally {
			if (fis != null) {
				try {
					fis.close();
				}catch (IOException e) {
					LOGGER.error("Error in closing the stream - validateCertWithPin :", e);
				}
			}
		}
		return BNPConstants.EDRAFT_SUCCESS;
	}
*/
	/**
	 * Gets the property file.
	 *
	 * @param vo the vo
	 * @return the property file
	 */
	protected String getPropertyFile(T vo) {
		String propFileName=null;
		if(vo instanceof EippPymtVO)
		{
			propFileName=BNPConstants.EIPP_PMT_AUTH_ENTRIES;
		}
		return propFileName;
	}

	/**
	 * Validate fields.
	 *
	 * @return true, if successful
	 */
	public boolean validateFields() {
		LOGGER.debug("START validateFields() ");
		boolean isValid = true;
		if(getFileName()== null){
			displayErrorMessage(ErrorConstants.CERT_FILE_NOT_EMPTY);
			isValid = false;
		}
		if (getCertKey().trim().length() == 0) {
			displayErrorMessage(ErrorConstants.CERT_PIN_NOT_EMPTY);
			isValid = false;
		}
		LOGGER.debug("END validateFields() ");
		return isValid ;
	}
	
	/**
	 * Gets the final approval status.
	 *
	 * @param abstractVO the abstract vo
	 * @return the final approval status
	 */
	public boolean getFinalApprovalStatus(T abstractVO){
		return  authMatrixService.isFinalLevel(abstractVO);
	}
	
	/**
	 * Close cert modal panel.
	 */
	public void closeCertModalPanel(){
		setShowCertificatePanel(false);
	}
	
	/**
	 * Check cert panel display.
	 *
	 * @return true, if successful
	 */
	protected boolean checkCertPanelDisplay(){
		T abstractVO = null;
		boolean lastApproval = false;
		if(BNPConstants.EDRAFT_FALSE.equalsIgnoreCase(getIsSummaryStr()) && selectedData != null){
			abstractVO = (T)selectedData;
			lastApproval = (isSignOnEnabled(abstractVO)&& (abstractVO.getAuthMatxErrorCode() ==0) && 
					getFinalApprovalStatus(abstractVO));
		}else{
			if(selectedList != null && selectedList.size() > 0){
				for(T objectVO : selectedList){
						lastApproval = (isSignOnEnabled(objectVO) && (objectVO.getAuthMatxErrorCode()==0) &&
								getFinalApprovalStatus(objectVO));
						if(lastApproval){
							break;
					}
				}
			}
		}	
		return lastApproval;
	}
	
	/**
	 * Fetch property file.
	 *
	 * @return the string
	 */
	public String fetchPropertyFile()
	{
		String propFileEntry=null;
		if(selectedData!=null)
		{
			T vo = (T)selectedData;
			propFileEntry=getPropertyFile(vo);
		}
		return propFileEntry;
	}
	
	/**
	 * Digital generated values from view.
	 *
	 * @param propFileEntry the prop file entry
	 * @return the string
	 */
	public String digitalGeneratedValuesFromView(String propFileEntry)
	{
		StringBuffer digSignDetails=new StringBuffer();
		String signToShow=edraftDigitalSign.generateSignature(propFileEntry, (T) selectedData);
		if(signToShow!=null)
		{
				digSignDetails.append(signToShow);
				digSignDetails.append(BNPConstants.LINE_DELIMITER);
				for(int i=0;i<50;i++)
				{
					digSignDetails.append(BNPConstants.LINE_SEPARATOR);
				}
				//FO 7.0 Fortify Issue Fix
				//LOGGER.debug("The digital Signature to show ----------"+digSignDetails);

		}
		return digSignDetails.toString();
	}
	
	/**
	 * Digital generated values from summary.
	 *
	 * @param propFileEntry the prop file entry
	 * @return the string
	 */
	public String digitalGeneratedValuesFromSummary(String propFileEntry)
	{
		StringBuffer digSignDetails=new StringBuffer();
		for(T selectedData:selectedList)
		{
			String signToShow=edraftDigitalSign.generateSignature(propFileEntry, (T) selectedData);
			if(signToShow!=null)
			{
				digSignDetails.append(signToShow);
				digSignDetails.append(BNPConstants.LINE_DELIMITER);
			for(int i=0;i<50;i++)
			{
				digSignDetails.append(BNPConstants.LINE_SEPARATOR);
			}
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("The digital Signature to show ----------"+digSignDetails);
			}
		}
		
		return digSignDetails.toString();
		
	}
	/**
	 * Copy array.
	 *
	 * @param source the source
	 * @return the byte[]
	 */
	public byte[] copyArray(byte[] source) {
		 byte[] dest = null;
		 if (source != null) {
			 dest = new byte[source.length];
			 System.arraycopy(source, 0, dest, 0, source.length);
		 }
	   return dest;
	}
	//Added for Transaction Sign On Ends
	//Modified for Defect 6862
	/**
	 * @return EippNonFinancial Inquiry screen
	 */
/*	public String getEippNonFinInqDetails(){
		FacesContext fc = FacesContext.getCurrentInstance();
		fc.getExternalContext().getRequestMap().remove(EIPP_NON_FIN_INQ_BEAN);
		return EIPP_NON_FIN_INQ_DET_FILE;
	}*/
	
	/**
	 * Checks if is sign on enabled.
	 *
	 * @param vo the vo
	 * @return true, if is sign on enabled
	 * This is a default implementation which always returns true. if this functionality is needed, child classes should override specific implementations.
	 */
	protected boolean isSignOnEnabled(T vo){
		return true;
	}
	
	/**
	 * To create the CSV file
	 * to the user.
	 *
	 * @param outputStream the output stream
	 * @throws BNPApplicationException the bNP application exception
	 */
	/*protected void exportToFile(List<String> reportLst, String filename) throws BNPApplicationException{
		LOGGER.info("Writing content to the output stream");
		BufferedWriter bw = null;
		FacesContext context = getFacesContext();
		try {
			HttpServletResponse response = (HttpServletResponse) context.getExternalContext().getResponse(); 
			response.setCharacterEncoding("UTF-8");
			response.setContentType("application/x-download; charset=UTF-8");   
			response.addHeader("Content-Type", "application/x-download; charset=UTF-8");   
			response.addHeader("content-disposition", "attachment; filename=\"" + filename + "\"");
			response.setHeader("Cache-Control", ""); // HTTP 1.1.
			response.setHeader("Pragma", ""); // HTTP 1.0.
			bw = new BufferedWriter(new OutputStreamWriter(response.getOutputStream()));
			for(String row : reportLst){
				bw.write(row);
				bw.newLine();
			}			
			//bw.close();
			context.responseComplete();
		}
		catch(Exception ex){
			LOGGER.error("createCSVFile - Exception :" + ex);
			throw new BNPApplicationException(ex.getMessage());
		}finally{
			if(bw != null){
				try{
					bw.close();
				}catch(Exception e){
					LOGGER.error("Exception while closing stream:" + e);
				}
			}
		}
	}*/
	// Pagination Changes - Start
	
	private Integer currentPk;

	private boolean sortClicked = false;
	
/*	private Map<String, Ordering> sortMap = new HashMap<String, Ordering>();*/

	private Map<Integer, T> wrappedData = new HashMap<Integer, T>();
	
	private List<Integer> wrappedKeys = null;

	private Integer firstRow = -1;
	
	protected Integer rowCount = null;
	
	/**
     * Serialization Version
     */
    private static final long serialVersionUID = 1L;
    
    /**
     * initialize method
     */
    public void initialize() {
    	currentPk = null;
    	rowCount = null;
    	firstRow = -1;
    	wrappedData = new HashMap<Integer, T>();
    	/*sortMap = new HashMap<String, Ordering>();*/
    	sortClicked = false;
    	wrappedKeys = null;
    	startingRecord=1;
		endingRecord = 10;		
    }
    
   /* private String getSortingColumns() {
    	StringBuilder sortColumnsStr = new StringBuilder("");
    	if(sortMap != null && !sortMap.isEmpty()) {
    		for(Map.Entry<String, Ordering> sortItem : sortMap.entrySet()) {
    			if(Ordering.DESCENDING.equals(sortItem.getValue())) {
    				sortColumnsStr.append(sortItem.getKey()).append(" DESC, ");
    			}
    			else {
    				sortColumnsStr.append(sortItem.getKey()).append(", ");
    			}
    		}
    	}
    	String sortColumns = sortColumnsStr.toString();
    	int index = sortColumns.lastIndexOf(",");
    	if(index != -1) {
    		sortColumns = sortColumns.substring(0, sortColumns.indexOf(","));
    	}
    	sortColumns = (sortColumns.trim().length() != 0) ? sortColumns : "1 ASC";
    	index = sortColumns.lastIndexOf(" ");
    	if(index != -1) {
    		dataVO.setSortCol(sortColumns.substring(0, index).trim());
    		dataVO.setSortOrder(sortColumns.substring(index + 1));
    	}
    	else {
    		dataVO.setSortCol(sortColumns);
    		dataVO.setSortOrder("ASC");
    	}
    	sortMap = new HashMap<String, Ordering>();
    	return sortColumns;
    }
*/
	//@Override
	public int getRowIndex() {
		throw new UnsupportedOperationException();
	}

	//@Override
	public void setRowIndex(int rowIndex) {
		throw new UnsupportedOperationException();
	}

	//@Override
	public void setWrappedData(Object data) {
		throw new UnsupportedOperationException();
	}

	//@Override
	public Object getWrappedData() {
		throw new UnsupportedOperationException();
	}

	//@Override
	public Object getRowKey() {
		return currentPk;
	}

	//@Override
	public void setRowKey(Object key) {
		this.currentPk = (Integer) key;
	}

	//@Override
/*	public SerializableDataModel getSerializableModel(Range range) {
		if (wrappedKeys != null) {
			return this;
		} 
		else {
			return null;
		}
	}*/

	//@Override
	public boolean isRowAvailable() {
		if (currentPk == null) {
			return false;
		} 
		else if (wrappedKeys.contains(currentPk)) {
			return true;
		} 
	/*	commented for R7.0 sonar fix
	 * else if (wrappedData.entrySet().contains(currentPk)) {
			return true;
		}*/
		return false;
	}

	//@Override
	public T getRowData() {
		if (currentPk == null) {
			return null;
		} 
		else {
			return wrappedData.get(currentPk);
		}
	}

	//@Override
/*	public void modify(List<FilterField> filterFields, List<SortField2> sortFields) {
		String sortField = null;
		Ordering order = null;
		if(sortFields != null && !sortFields.isEmpty()) {
			for(SortField2 sortField2 : sortFields) {
				sortField = sortField2.getExpression().getExpressionString();
				if(sortField != null) {
					sortField = sortField.substring(sortField.indexOf('{') + 1, sortField.indexOf('}'));
					order = sortMap.get(sortField);
					if(!sortClicked && order != null && sortField2.getOrdering().equals(order)) {
						sortClicked = false;
					}
					else {
						sortClicked = true;
						sortMap.put(sortField, sortField2.getOrdering());
					}
				}
			}
		}
	}*/
	
	/*//@Override
	public void walk(FacesContext context, DataVisitor visitor, Range range, Object argument) throws IOException {
		Integer startRow = ((SequenceRange) range).getFirstRow();
		Integer numberOfRows = ((SequenceRange) range).getRows();
		
		if(sortClicked || !firstRow.equals(startRow)) {
			setSelectedData(null);
			getSelectedList().clear();
			currentIndex=-1;
			setCheckAll(false);
			disablePanels();
			wrappedKeys = new ArrayList<Integer>();
			wrappedData = new HashMap<Integer, T>();
			try {
				dataVO.setStartRow(startRow);
				dataVO.setEndRow(startRow + numberOfRows);
				dataVO.setSortBy(getSortingColumns());
				populateTableData();		
				validateSearchThreshold(); // Added for CSCDEV-4210 
			} catch (Exception ex) {
				LOGGER.error(ex.getMessage());
			}
			if (tableDataList != null) {
				for (T item : tableDataList) {
					wrappedKeys.add(item.getRowno());
					wrappedData.put(item.getRowno(), item);
					visitor.process(context, item.getRowno(), argument);
				}
			}
			sortClicked = false;
			firstRow = startRow;
		}
		else {
			if(wrappedKeys != null) {
				for(Integer key : wrappedKeys) {
					visitor.process(context, key, argument);
				}
			}
		}
	}*/
	
	
	
	//@Override
	public void update() { }
	
	//@Override
    public int getRowCount() { 
		return (rowCount == null)? 0 : rowCount.intValue(); 
	}
	    
	// Pagination Changes - End
	
	/* Method newly added - FO R5.0 - Rollover Implementation - All screens */
	public void addRolloverType(List<NameValueVO> searchTypeList){
		if(searchTypeList != null){
			NameValueVO rollover = new NameValueVO();
			rollover.setName(propertyLoader.getValue(CacheConstants.TYPE_ROLLOVER));
			rollover.setValue(CacheConstants.TYPE_ROLLOVER);
			searchTypeList.add(rollover);
		}
	}

	
	// Added for CSCDEV-4210 - Starts
	protected boolean validateSearchThreshold(){		
		boolean searchThresholdExceeded = false;
		if(getClientSidePaginationThreshold() > 0  && getRowCount() > getClientSidePaginationThreshold()){
			displayInfoMessage(ErrorConstants.BLANK_SEARCH_EXCEED_THRESHOLD, String.valueOf(getClientSidePaginationThreshold()));
			searchThresholdExceeded = true;
		}
		return searchThresholdExceeded;
	}
	
	// Added for CSCDEV-4210 - Ends
	
		/** CSCDEV-4649 Captcha Implementation on 17-05-2015 - Start **/
	/**
	 * Method is used to generate image and write down in view page
	 * @param  stream
	 * @param  object
	 * @throws Exception
	 */
	/*public void paint(OutputStream stream, Object object)
			throws Exception {
		try {
			String randomCaptchaNo;
			int width = 70, height = 30, x, y;
			
			// Uses a secure Random not a simple Random
			SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
			randomCaptchaNo = String.valueOf(random.nextLong()).substring(1, 5);
			loginBean.setCaptchaText(randomCaptchaNo);
			
			x = random.nextInt(15 - 1 + 1) + 5;
			y = random.nextInt(15 - 1 + 1) + 5;

			BufferedImage img = new BufferedImage(width, height,
					BufferedImage.TYPE_INT_RGB);

			Graphics2D g2d = img.createGraphics();

			Font font = new Font("Mistral", Font.BOLD+Font.ITALIC, 16);
			
			g2d.setFont(font);
			g2d.setColor(Color.LIGHT_GRAY);
			g2d.fillRect(0, 0, width, height);

			g2d.setColor(Color.black);
			
			g2d.drawArc (x, y, x+80, y+180,x+50,y+55);
			g2d.drawArc (x, y, x+80, x+80,x+26,y+90);
			g2d.drawLine(x, y, x+80, y+80);
			g2d.drawLine(x+20, y, x+80, y+80);
			g2d.drawString(randomCaptchaNo, 17, 20);

			g2d.dispose();

			ImageIO.write(img, "jpeg", stream);
			getFacesContext().responseComplete();
		} catch (Exception e) {
			e.getMessage();
		}
	}*/
	
	/**
	 * Method is used to generate new date
	 * @return new Date()
	 */
	public Date getDate() {
		return new Date();
	}
	/** CSCDEV-4649 Captcha Implementation on 17-05-2015 - End **/

	// Added for FO 8.0 Client Pagination changes - Start
	protected int pagThresholdValue = 0;

	protected boolean validatePaginationThreshold(){		
		boolean returnVaue = false;
		if(getClientSidePaginationThreshold() > 0  && getRowCount() > getClientSidePaginationThreshold()){
			returnVaue = true;
			if(null != tableDataList){
				tableDataList.clear();
			}
			displayInfoMessage(ErrorConstants.BLANK_SEARCH_EXCEED_THRESHOLD, String.valueOf(getClientSidePaginationThreshold()));
		}
		return returnVaue;
	}
	
	protected int getSearchOrExportThresold(Map<String, String> thresholdData,String input){
		String values[]=thresholdData.get(getScreenConstant()).split(BNPConstants.PIPE_SEPARATOR);
		//Threshold Format: Searchthreshold || Exportthreshold - will be splited 
		//values[0] will be stored for searchThreshold and values[0] will be stored for exportThreshold  
		if(BNPConstants.SEARCH.equals(input)){
			if(null!=values[0] && !values[0].isEmpty()){
				return (Integer.parseInt(values[0])> 0 ? Integer.parseInt(values[0]): 0);
			}
		}else if(values.length!=1 && BNPConstants.EXPORT.equals(input)){
			if(null!=values[1] && !values[1].isEmpty()){
				return (Integer.parseInt(values[1])> 0 ? Integer.parseInt(values[1]): 0);
			}
		}
		return 0;
	}
	
	public int getClientSidePaginationThreshold() {
		return pagThresholdValue;
	}	
	// Added for FO 8.0 Client Pagination changes - Ends

	//FO 8.0 export changes starts
	protected int exportThreshold = 0;
	protected List<T> exportList;
	protected boolean showExportThresholdPopup;
	protected String exportButtonValue;
	private String exportDelimiter;
	private List<Integer> dateList = new ArrayList<Integer>();
	private List<Integer> amountList = new ArrayList<Integer>();

	public List<Integer> getAmountList() {
		return amountList;
	}

	public void setAmountList(List<Integer> amountList) {
		this.amountList = amountList;
	}

	public int getExportThreshold() {
		return exportThreshold;
	}

	public void setExportThreshold(int exportThreshold) {
		this.exportThreshold = exportThreshold;
	}

	public List<T> getExportList() {
		return exportList;
	}

	public void setExportList(List<T> exportList) {
		this.exportList = exportList;
	}
	
	public boolean isShowExportThresholdPopup() {
		return showExportThresholdPopup;
	}

	public void setShowExportThresholdPopup(boolean showExportThresholdPopup) {
		this.showExportThresholdPopup = showExportThresholdPopup;
	}

	public String getExportButtonValue() {
		return exportButtonValue;
	}

	public void setExportButtonValue(String exportButtonValue) {
		this.exportButtonValue = exportButtonValue;
	}
	
	public String getExportDelimiter() {
		return exportDelimiter;
	}

	public void setExportDelimiter(String exportDelimiter) {
		this.exportDelimiter = exportDelimiter;
	}

	public void getSummarySearchData(){
	}
	public List<String> getListToExport(){
		return new ArrayList<String>();
	}
	public int getSearchDataCount(){
		return 0;
	}
	
	/**
	 * Gets the export search data.
	 *
	 * @return the export search data
	 */
/*	public void getExportSearchData(){
	  initializeExportVariables();
	  if(dataVO == null){
		  dataVO = (T) new AbstractVO();
	  }
	  dataVO.setOpenFile(false);
	  Integer countOfRecords = getSearchDataCount();
	  if(countOfRecords != null){
	   if(countOfRecords == 0){
  	     displayErrorMessage(ErrorConstants.NO_RECORDS_FOUND_EXPORT);
 	   }else if(countOfRecords > exportThreshold){
	     showExportThresholdPopup = true;
	   }else{
		 exportSummaryData();
	   }
	  }
	 }*/
		
	private void initializeExportVariables() {
      showExportThresholdPopup =false;
	  setExportDelimiter(null);
	  dateList = new ArrayList<Integer>();
	  amountList = new ArrayList<Integer>();
	}
	//FO 8.0 CSCDEV - 5908 defect fix
	/**
	 * Creates the list of strings.
	 *
	 * @param originalList the original list
	 * @param partitionSize the partition size
	 * @return the list
	 */
	private List<List<String>> createPartitionList(List<String> originalList,int partitionSize){
	  List<List<String>> partitions = new LinkedList<List<String>>();
	  for (int index = 0; index < originalList.size(); index += partitionSize) {
	    partitions.add(originalList.subList(index,Math.min(index + partitionSize, originalList.size())));
	  }
	  return partitions;
	}

	/**
	 * Gets the string value.
	 *
	 * @param input the input
	 * @return the string value
	 */
/*	protected String getStringValue(Object input){
	  String instance = BNPConstants.EMPTY + getExportDelimiter();
	  SimpleDateFormat dateFormat =new SimpleDateFormat(loginBean.getUserPrefVO().getPreferredDateFmt());
	  if(input!= null){
		if(input instanceof String){
		  input = replaceNullWithEmpty(input);
		  if (BNPConstants.CSV_FORMAT.equalsIgnoreCase(getExportButtonValue())){
			input = String.valueOf(input).replace(BNPConstants.COMMA_DELIMITER,BNPConstants.EMPTY);
		  }
		  instance =  String.valueOf(input) + getExportDelimiter(); 
		}else if(input instanceof Integer){
		  instance =  String.valueOf(input) + getExportDelimiter();  
		}else if(input instanceof Date){
			instance =  dateFormat.format((Date)input) + getExportDelimiter();
	    }else if(input instanceof Long){
	    	instance =  String.valueOf(input) + getExportDelimiter();
		}else if(input instanceof BigDecimal){
	    	instance =  String.valueOf(((BigDecimal)input).doubleValue()) + getExportDelimiter();
		}else if(input instanceof Boolean){
			if((Boolean) input){
				instance =  String.valueOf(BNPConstants.Yes) + getExportDelimiter();
			}else{
				instance =  String.valueOf(BNPConstants.No) + getExportDelimiter();
			}
		}
	  }
	  return instance;
	}*/
	
	
/*	private List<String> applyUserPrefAmountFormat(List<String> listToExport) {
		List<String> resultList = new ArrayList<String>();
		resultList.add(listToExport.get(0));
		NumberFormat numberFormatter;
		Locale locale;
		String pattern;
		String amountFormat = loginBean.getUserPrefVO().getPreferredAmtFmt();
		if(amountFormat.matches("ROOT(.*)")){
        	locale=Locale.ROOT;
        }else{
        	locale = getAmtFmtLocale(amountFormat);
        }
		if(locale==Locale.ROOT){
      		String custom = amountFormat.substring(4);
      		ResourceBundle rb = ResourceBundle.getBundle("messages");
      		pattern=rb.getString("bnp.common.userpref.currencypattern"+custom);
      	}else{
      		pattern = resourceManager.getMessageValue("bnp.common.userpref.currencypattern");
      	}
		
		DecimalFormatSymbols symbols = new DecimalFormatSymbols(locale);
		numberFormatter = (new DecimalFormat(pattern, symbols));
		numberFormatter.setMaximumFractionDigits(2);
		numberFormatter.setMinimumFractionDigits(2);
		for(int i=1; i<listToExport.size();i++){
			String[] record = listToExport.get(i).split(getExportDelimiter());
			 for(int j = 0; j< record.length ; j ++){
				 for(int amountIndex : amountList){
					 if(j == amountIndex && record[j]!= null && ! "".equalsIgnoreCase(record[j])){
						 if (BNPConstants.CSV_FORMAT.equalsIgnoreCase(getExportButtonValue())){
							 record[j] = "\"" + String.valueOf(numberFormatter.format(new BigDecimal(record[j]))) + "\"";
						 }else{
							 record[j] = String.valueOf(numberFormatter.format(new BigDecimal(record[j])));
						 }
					 }
				 }
			 }
			 resultList.add(getRecordWithExportDelimiter(record));
		}
		return resultList;
	}*/
	private String getRecordWithExportDelimiter(String[] record) {
		 StringBuilder builder = new StringBuilder();
		 for(String data : record){
			 builder.append(data + getExportDelimiter());
		 }
		return builder.toString();
	}

/*	private Locale getAmtFmtLocale(String localeFormat){    	
		Locale locale=null;
		switch(LocaleFormat.valueOf(localeFormat)){
		case US:
        	   locale=Locale.US;
        	   break;
		 case ITALY:
        	   locale=Locale.ITALY;
        	   break;
        case CANADA:
     	   locale=Locale.CANADA;
     	   break;
        case CANADA_FRENCH:
      	   locale=Locale.CANADA_FRENCH;
      	   break;
        case CHINA:
      	   locale=Locale.CHINA;
      	   break;
        case CHINESE:
      	   locale=Locale.CHINESE;
      	   break;
        case ENGLISH:
      	   locale=Locale.ENGLISH;
      	   break;
        case FRANCE:
      	   locale=Locale.FRANCE;
      	   break;
        case FRENCH:
      	   locale=Locale.FRENCH;
      	   break;
        case GERMAN:
      	   locale=Locale.GERMAN;
      	   break;
        case GERMANY:
      	   locale=Locale.GERMANY;
      	   break;
        case ITALIAN:
      	   locale=Locale.ITALIAN;
      	   break;           
        case JAPAN:
      	   locale=Locale.JAPAN;
      	   break;
        case JAPANESE:
      	   locale=Locale.JAPANESE;
      	   break;
        case KOREA:
       	   locale=Locale.KOREA;
       	   break;
         case KOREAN:
       	   locale=Locale.KOREAN;
       	   break;
         case PRC:
       	   locale=Locale.PRC;
       	   break;
         case ROOT:
       	   locale=Locale.ROOT;
       	   break;
         case SIMPLIFIED_CHINESE:
       	   locale=Locale.SIMPLIFIED_CHINESE;
       	   break;
         case TAIWAN:
       	   locale=Locale.TAIWAN;
       	   break;
         case TRADITIONAL_CHINESE:
       	   locale=Locale.TRADITIONAL_CHINESE;
       	   break;
         case UK:
       	   locale=Locale.UK;
       	   break;
      	   
        }	
		return locale;
	}*/
	
	private String replaceNullWithEmpty(Object input) {
		return input.toString().replaceAll(BNPConstants.NULL_STR, BNPConstants.EMPTY);
	}
	
	/**
	 * Gets the date time value as string with time zone.
	 *
	 * @param input the input
	 * @return the date time value as string with time zone
	 */
/*	protected String getDateTimeValueAsStringWithTimeZone(Object input){
      String instance = BNPConstants.EMPTY + getExportDelimiter();
	  SimpleDateFormat dateFormat =new SimpleDateFormat(loginBean.getUserPrefVO().getPreferredDateFmt() + BNPConstants.TIME_COMPONENTS);
	  FacesContext context = getFacesContext().getCurrentInstance();
	  HttpServletRequest request = (HttpServletRequest)context.getExternalContext().getRequest();
	  HttpSession session = request.getSession(false);
	  TimeZone timeZone = TimeZone.getTimeZone((String)session.getAttribute("USER_TIME_ZONE_ID"));
	  if(input!= null && input instanceof Date){
	    dateFormat.setTimeZone(timeZone); 
		instance =  dateFormat.format((Date)input) + getExportDelimiter();
	  }
	  return instance;
	}
	
	protected String getDateValueAsStringWithTimeZone(Object input){
	      String instance = BNPConstants.EMPTY + getExportDelimiter();
		  SimpleDateFormat dateFormat =new SimpleDateFormat(loginBean.getUserPrefVO().getPreferredDateFmt());
		  FacesContext context = getFacesContext().getCurrentInstance();
		  HttpServletRequest request = (HttpServletRequest)context.getExternalContext().getRequest();
		  HttpSession session = request.getSession(false);
		  TimeZone timeZone = TimeZone.getTimeZone((String)session.getAttribute("USER_TIME_ZONE_ID"));
		  if(input!= null && input instanceof Date){
		    dateFormat.setTimeZone(timeZone); 
			instance =  dateFormat.format((Date)input) + getExportDelimiter();
		  }
		  return instance;
		}

	protected String getDateTimeValueAsString(Object input){
		  String instance = BNPConstants.EMPTY + getExportDelimiter();
		  SimpleDateFormat dateFormat =new SimpleDateFormat(loginBean.getUserPrefVO().getPreferredDateFmt() + BNPConstants.TIME_COMPONENTS);
		  if(input!= null && input instanceof Date){
			instance =  dateFormat.format((Date)input) + getExportDelimiter();
		  }
		  return instance;
		}*/
		
	/**
	 * Export summary data.
	 */
/*	public void exportSummaryData(){
	  showExportThresholdPopup = false;	
	  List<String> listToExport=null;
	  try{
		_logAccessDetails("EXPORT_BUTTON",getExportButtonValue());
		//FO8.0 UAT Defect fix: CSCDEV-5544
		dataVO.setStartRow(0);
		dataVO.setEndRow(exportThreshold);
		getSummarySearchData();
		setExportDelimiter();
		listToExport = getListToExport();
		if(BNPConstants.XLS_FORMAT.equalsIgnoreCase(getExportButtonValue())){
			exportSummaryDataToXLS(listToExport);
		}else if (BNPConstants.CSV_FORMAT.equalsIgnoreCase(getExportButtonValue())){
			exportSummaryDataToCSV(listToExport);
		}else if(BNPConstants.PDF_FORMAT.equalsIgnoreCase(getExportButtonValue())){
			listToExport = applyUserPrefAmountFormat(listToExport);
			exportSummaryDataToPDF(listToExport);
		}
		dataVO.setOpenFile(true);
	  }catch (BNPApplicationException exception) {
	    LOGGER.error("Exception Occured while executing exportSummaryData() Method in AbstractBean :: {} ",exception);
		displayErrorMessage(ErrorConstants.EXPORT_EXCEPTOPN_OCCURED);
	  }
	  finally{
		  listToExport=null;
	  }
	}*/
	
	private void setExportDelimiter() {
		if (BNPConstants.CSV_FORMAT.equalsIgnoreCase(getExportButtonValue())){
			setExportDelimiter(BNPConstants.COMMA_DELIMITER);
		}else {
			setExportDelimiter(BNPConstants.SEMI_COLON);
		}
    }

	/**
	 * Download summary search data.
	 *
	 * @param fileContent the file content
	 */
/*	public void downloadSummarySearchData(byte[] fileContent){
	  FacesContext context = getFacesContext().getCurrentInstance();
	  HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();
	  HttpSession session = request.getSession();
	  session.setAttribute(BNPConstants.ZIP_FILE_ATTRIBUTE, fileContent);
	  session.setAttribute(BNPConstants.FILE_TYPE, exportButtonValue);
	  session.setAttribute(BNPConstants.FILE_NAME, getExportFileName());
	  session.setAttribute(BNPConstants.DOWNLOAD_STREAM, BNPConstants.ATTACHMENT);
	}
	
	//	FO R8.0 UAT CSCDEV-5729 fix starts
	public void downloadSummarySearchDataCSV(String fileContent){
		  FacesContext context = getFacesContext().getCurrentInstance();
		  HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();
		  HttpSession session = request.getSession();
		  session.setAttribute(BNPConstants.CSV_FORMAT, fileContent);
		  session.setAttribute(BNPConstants.FILE_TYPE, exportButtonValue);
		  session.setAttribute(BNPConstants.FILE_NAME, getExportFileName());
		  session.setAttribute(BNPConstants.DOWNLOAD_STREAM, BNPConstants.ATTACHMENT);
	}*/
	//	FO R8.0 UAT CSCDEV-5729 fix ends
	
	/**
	 * Export summary data to pdf.
	 *
	 * @param listToExport the list to export
	 * @throws BNPApplicationException the BNP application exception
	 */
/*	public void exportSummaryDataToPDF(List<String> listToExport) throws BNPApplicationException{
		String docHeader=  resourceManager.getMessageValue(getScreenConstant().toLowerCase());
		Map<String, Object> exportData = exportDataUtil.getExportData(listToExport, docHeader, getUserId());
		exportData.put("isExport", "YES");//FO 8.0-Defect Fix:CSCDEV-5729
		downloadSummarySearchData(dynamicReportUtil.getPDFReport(exportData));
	}
	
	*//**
	 * Export summary data to csv.
	 *
	 * @param listToExport the list to export
	 *//*
	public void exportSummaryDataToCSV(List<String> listToExport) throws BNPApplicationException{
		downloadSummarySearchDataCSV(BNPDiscountUtil.write(listToExport));		//	FO R8.0 UAT CSCDEV-5729 fix
	}
	
	*//**
	 * Exports data to XLS
	 * 
	 * @param listToExport
	 * @throws BNPApplicationException
	 *//*
	public void exportSummaryDataToXLS(List<String> listToExport) throws BNPApplicationException{
	  HSSFWorkbook dataToFile = createXLData(listToExport);
	  ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
	  try {
	    dataToFile.write(outputStream);
	  }catch (IOException ioxception) {
	    throw new BNPApplicationException(ioxception.getMessage());
	  }finally{
	    try{
	      outputStream.close();
	    }catch (Exception exception) {
          throw new BNPApplicationException(exception.getMessage());
        }
	  }
	  downloadSummarySearchData(outputStream.toByteArray());
	}	
	*/
	/**
	 * Gets the export file name.
	 *
	 * @return the export file name
	 */
/*	public String getExportFileName() {
	  String screenName = resourceManager.getMessageValue(getScreenConstant().toLowerCase()).replaceAll(BNPConstants.SPACE,BNPConstants.EMPTY);
	  StringBuilder builder = new StringBuilder(screenName);
	  builder.append(BNPConstants.VALUE_SEPARATOR);
	  builder.append(cacheService.getExportDateTimestamp(getUserId()));
	  if(BNPConstants.XLS_FORMAT.equalsIgnoreCase(getExportButtonValue())){
	    builder.append(BNPConstants.FILE_XLS);
	  }else if (BNPConstants.CSV_FORMAT.equalsIgnoreCase(getExportButtonValue())){
	    builder.append(BNPConstants.FILE_CSV);
	  }else if(BNPConstants.PDF_FORMAT.equalsIgnoreCase(getExportButtonValue())){
	    builder.append(BNPConstants.FILE_PDF);
	  }
	  return builder.toString();
	}*/

	/**
	 * Creates the xl data.
	 *
	 * @param listToExport the list to export
	 * @return the HSSF workbook
	 */
	/*private HSSFWorkbook createXLData(List<String> listToExport) {
	  String[] columnHeader = new String[]{};
	  if(listToExport != null && listToExport.size() > 0){
	    columnHeader = (listToExport.get(0)).split(BNPConstants.COMMA_DELIMITER);  
	  }
	  SimpleDateFormat sdf =  new SimpleDateFormat(loginBean.getUserPrefVO().getPreferredDateFmt());
	  SimpleDateFormat sdtf =  new SimpleDateFormat(loginBean.getUserPrefVO().getPreferredDateFmt() + BNPConstants.TIME_COMPONENTS);
	  HSSFWorkbook workbook = new HSSFWorkbook();
	  HSSFFont font = workbook.createFont();//FO 8.0-Defect Fix:CSCDEV-5729
	  font.setFontName("Arial Unicode MS");//FO 8.0-Defect Fix:CSCDEV-5729
	  //FO 8.0 CSCDEV - 5908 defect fix
	  List<List<String>> listToExportedRecords = new LinkedList<List<String>>();
	  int excelThreshold = BNPConstants.EXCEL_THRESHOLD;
	  if(listToExport!= null && (listToExport.size() > excelThreshold)){
		listToExportedRecords =  createPartitionList(listToExport,excelThreshold);
	  }else{
	    listToExportedRecords.add(listToExport); 
	  }
	  int count = 0;
	  for(List<String> instance : listToExportedRecords){
	  int columnIndex = 0;
	  HSSFSheet worksheet = workbook.createSheet("ExportData"+count);
	  HSSFRow headerrow = worksheet.createRow(0);
	  List<CellStyle> columnStyle = new ArrayList<CellStyle>();
	  CellStyle stringStyle = workbook.createCellStyle();
	  stringStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat(BNPConstants.POI_TEXT_FORMAT));
	  stringStyle.setAlignment(CellStyle.ALIGN_LEFT);
	  stringStyle.setFont(font); //FO 8.0-Defect Fix:CSCDEV-5729
	  CellStyle dateStyle = workbook.createCellStyle();
	  dateStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat(BNPConstants.POI_INTERNAL_DT_FORMAT));
	    
	  CellStyle intStyle = workbook.createCellStyle();
	  intStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat(BNPConstants.INT_FORMAT));
	  
	  for(int i=0; i<columnHeader.length; i++) {
		String header = columnHeader[i];  
	    HSSFCell cell = headerrow.createCell(columnIndex++);
		RichTextString _hString = new HSSFRichTextString(header.replace(BNPConstants.AMOUNT_DUMMY, BNPConstants.EMPTY));
		cell.setCellValue(_hString);
	//To find the index position of date and amount columns
		if(header.endsWith(BNPConstants.DATE) || BNPConstants.SENT_ON_STR.equals(header) 
				|| BNPConstants.LAST_GENERATED_STR.equals(header)){
			columnStyle.add(dateStyle);
		}else if(header.endsWith(BNPConstants.AMOUNT) || header.endsWith(BNPConstants.AMOUNT_SHORT_NAME)){
			columnStyle.add(intStyle);
		} else{
			columnStyle.add(stringStyle);
		}
	  }
	  Calendar cal = new GregorianCalendar();
	  //FO 8.0 CSCDEV - 5908 defect fix
	  for (int i=1; i<instance.size() ; i++) {   
	    String[] record = instance.get(i).split(getExportDelimiter());
		HSSFRow row = worksheet.createRow(worksheet.getLastRowNum() + 1);
        for(int j = 0; j< record.length ; j ++){
          boolean formatFlg = true;
          HSSFCell cell = row.createCell(j);
		 //To set excel object for date and amount column
          for(int iter : dateList){
           if(j==iter){
        	  try{
        	   if(record[j] != null){ 
        		 if(record[j].contains(BNPConstants.TIME_SEPARATOR)){
        			 cal.setTime(sdtf.parse(record[j]));
        		 }else{
        			 cal.setTime(sdf.parse(record[j]));
        		 }
        	     cell.setCellValue(cal);
        	   }else{
        		   cell.setCellValue(record[j]);  
        	   }
        	   formatFlg =false; 
        	   break;
        	  }catch (ParseException e) {
        		  cell.setCellValue(record[j]); 
			  }
		    }
          }
          if(formatFlg){
          for(int iter : amountList){
            if(j==iter){
              if(record[j] != null && ! record[j].equals(BNPConstants.EMPTY)){ 	
            	  cell.setCellValue(new Double(record[j]));
              }else{
            	  cell.setCellValue(record[j]);
              }
              formatFlg =false; 
              break;
            }
          }
          if(formatFlg){
		  cell.setCellValue(record[j]);
          }
          }
		 if(j < columnStyle.size()){ 
			 cell.setCellStyle(columnStyle.get(j));
		 }
		}
	  }
	  count++;//FO 8.0 CSCDEV - 5908 defect fix
	  }
	  return workbook;
	}*/
	
	/**
	 * Gets the table header.
	 *
	 * @param extndTableId the extnd table id
	 * @return the table header
	 */
/*	public String getTableHeader(String extndTableId){
	  StringBuffer fileHeader = new StringBuffer();
	  StringBuffer fileHeaderId = new StringBuffer(); 
	  UIExtendedDataTable extendedDataTable = (UIExtendedDataTable)findComponent(extndTableId);
	  if(extendedDataTable != null){
	  for (Iterator<UIColumn> columns = extendedDataTable.getChildColumns(); columns.hasNext();) {
	    UIColumn column = columns.next();	
		if(column.isRendered()){
		  UIComponent outputLabel = column.getHeader();
		  String outputLabelID = column.getId();
		  System.out.println("Header ID:"+outputLabelID);
		      if(outputLabel instanceof HtmlOutputLabel){
		    	if(fileHeader.length() > 0){
				      fileHeader.append(BNPConstants.COMMA_DELIMITER);
				      fileHeaderId.append(BNPConstants.COMMA_DELIMITER);
			    }
		    	fileHeader.append(((HtmlOutputLabel) outputLabel).getValue());
		    	fileHeaderId.append(outputLabelID);
		    }else if(outputLabel instanceof HtmlOutputText){
		    	if(fileHeader.length() > 0){
				      fileHeader.append(BNPConstants.COMMA_DELIMITER);
				      fileHeaderId.append(BNPConstants.COMMA_DELIMITER);
			    }
		    	fileHeader.append(((HtmlOutputText) outputLabel).getValue());
		    	fileHeaderId.append(outputLabelID);
		    } 
		  }
		}
	  }
	  String[] fileHeaderArray = fileHeader.toString().split(BNPConstants.COMMA_DELIMITER);
	  String[] fileHeaderIDArray = fileHeaderId.toString().split(BNPConstants.COMMA_DELIMITER);
	  for(int i=0; i<fileHeaderArray.length; i++) {
		String header = fileHeaderArray[i];  
		String headerId = fileHeaderIDArray[i];
		
		String last4 =  headerId == null || headerId.length() < 4 ? 
				headerId : headerId.substring(headerId.length() - 4);
		
		if(last4.equalsIgnoreCase("Amnt"))
		{
			amountList.add(i);
		}
		else if(last4.equalsIgnoreCase("Date")){
			dateList.add(i);
		}
	  }
	  return fileHeader.toString();
	}
	*/
	/**
	 * Find component.
	 *
	 * @param id the id
	 * @return the UI component
	 */
	/*public UIComponent findComponent(final String id) {		//	FO R8.0 UAT CSCDEV-6402 fix
	  FacesContext context = FacesContext.getCurrentInstance();
	  UIViewRoot root = context.getViewRoot();
	  final UIComponent[] found = new UIComponent[1];
	  root.visitTree(new FullVisitContext(context), new VisitCallback() {     
	  @Override
	  public VisitResult visit(VisitContext context, UIComponent component) {
	    if(component.getId().equals(id)){
	      found[0] = component;
	      return VisitResult.COMPLETE;
	    }
	    return VisitResult.ACCEPT;              
	  }
	  });
	  return found[0];
	}*/
	//FO 8.0 export changes ends
	
	/**
     * Gets the declared fields.
     *
     * @param declaredClass the declared class
     * @return the declared fields
     */
    private static List<String> getDeclaredFields(Class<?> declaredClass) {
	  List<String> listOfFields = new ArrayList<String>();
	  Field[] avaialbleFields = declaredClass.getDeclaredFields();
	  for(Field instance : avaialbleFields){
	    listOfFields.add(instance.getName());
	  }
	  return listOfFields;
	}
	
	/**
	 * Gets the object as string.
	 * 
	 * @param indinaSamples
	 *            the indina samples
	 * @return the object as string
	 */
    private static String getObjectAsString(String indinaSamples) {
      StringBuilder toStringObjects = new StringBuilder();
      try{
        List<String> listOfDeclaredFields = getDeclaredFields(new AbstractVO().getClass());
	    String classReference = indinaSamples.substring(0,indinaSamples.indexOf("[") + 1);
	    indinaSamples = indinaSamples.substring(indinaSamples.indexOf("[") + 1);
	    indinaSamples = indinaSamples.substring(0, indinaSamples.indexOf("]"));
	    List<String> individualObjects = Arrays.asList(indinaSamples.split(","));
	    toStringObjects.append(classReference);
	    for(String object:individualObjects){
	      if(object != null && !object.contains("<null>") && object.contains("=") && !listOfDeclaredFields.contains(object.substring(0,object.indexOf("=")))){
		    toStringObjects.append(object); 
		    toStringObjects.append(",");
		  }
	      toStringObjects.append("]");
	    }
      }catch(Exception exception){
    	LOGGER.error("Exception Occured while executing getObjectAsString() Method in AbstractBean :: {} ",exception);
      }
	  return toStringObjects.toString();
	}
    
    /**
     * Extract system level information.
     *
     * @param request the request
     * @return the string
     */
    public String extractSystemLevelInformation(HttpServletRequest request) {
      StringBuilder _userInformation = new StringBuilder();
      try{
        _userInformation.append("Remote IP Address :: "+request.getRemoteAddr()+" ");
        InetAddress inetAddress = InetAddress.getByName(request.getRemoteAddr());
        if(inetAddress != null) _userInformation.append("Host Name :: "+inetAddress.getHostName()+" ");
        if(inetAddress != null) _userInformation.append("Computer Name :: "+java.net.InetAddress.getLocalHost().getHostName()+" ");
      }catch(Exception exception){
        LOGGER.error("Exception Occured while Getting Inet Address",exception);
      }
      return _userInformation.toString();
    }
	
	/**
     * Sets the access log details.
     *
     * @param actionName the action name
     * @param referenceKey the reference key
     * @throws BNPApplicationException the BNP application exception
     */
/*    private void _logAccessDetails(String actionName,String referenceKey) throws BNPApplicationException {
	  HttpServletRequest request= (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
	  HttpSession session=request.getSession(false);
	  AbstractVO abstractInstance = new AbstractVO();
	  abstractInstance.setCurrentUserId(getUserId());
	  abstractInstance.setSessionId(session.getId());
	  abstractInstance.setModifiedData(extractSystemLevelInformation(request) + " " + getObjectAsString(ToStringBuilder.reflectionToString(dataVO)));
	  abstractInstance.setCheckPoint(actionName);
	  abstractInstance.setScreenId(getScreenConstant());
	  abstractInstance.setAccessLogRefNo(referenceKey);
	  try {
		insertAccessLog(abstractInstance);
	  } catch (BNPApplicationException applicationException) {
		throw applicationException;
	  }
	}*/
	
	/**
	 * Insert access log details.
	 *
	 * @param abstractVO the abstract vo
	 * @throws BNPApplicationException the BNP application exception
	 */
	private void insertAccessLog(AbstractVO abstractVO)throws BNPApplicationException {
	  accessLogService.insertAccessLog(abstractVO);
	}
	
	// Added for UX9.09 S144 - Starts 
	
	
	protected String userId="";
	protected String userTypeID="";
	protected String orgId="";
	
	
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId=userId;
	}
	
	public String getUserTypeID() {
		return userTypeID;
	}
	
	public void setUserTypeID(String userTypeID) {
		this.userTypeID=userTypeID;
	}
	
	public String getOrgId() {
		return orgId;
	}
	
	public void setOrgId(String orgId) {
		this.orgId=orgId;
	}
	
	protected void addActionPopupMessages(String uniqueID, String message, boolean error){
		 ErrorMessageVO objErrorMessageVO  = new ErrorMessageVO();
	     objErrorMessageVO.setUniqueID(uniqueID);
	     objErrorMessageVO.setMessage(message +BNPConstants.LINE_SEPARATOR +uniqueID);
	     objErrorMessageVO.setError(error);
	     errorMessageHelper.getErrorMessageVOList().add(objErrorMessageVO);
		
	}
	
	// Added for UX9.09 S144 - Ends
	
}
