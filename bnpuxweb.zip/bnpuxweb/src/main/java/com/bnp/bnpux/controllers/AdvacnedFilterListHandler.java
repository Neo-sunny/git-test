
/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   06-Mar-2017
 * 
 * Purpose:      Advanced Filter List Handler
 * 
 * Change History:
 *  
 * Date                       Author                                            Reason
 * 06-Mar-2017			Bala Murugan Elangovan					Base version for Advanced Filter List Handler 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import java.sql.Array;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.TypeHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnp.bnpux.common.vo.AdvancedFilterVO;
import com.bnp.bnpux.util.DataSourceConnector;

import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;

@SuppressWarnings("rawtypes")
public class AdvacnedFilterListHandler implements TypeHandler{
	
	public static final Logger log = LoggerFactory.getLogger(AdvacnedFilterListHandler.class);
	
	

	@Override
	public void setParameter(PreparedStatement ps, int i, Object parameter, JdbcType jdbcType) throws SQLException {
		
		  
		  Connection connection = null;
		  try{
			  connection= DriverManager.getConnection("jdbc:oracle:thin:@10.180.35.200:1521: orcl11g","rel10_st2","rel10_st2");	
			  
			  @SuppressWarnings("unchecked")
			  List<AdvancedFilterVO> advancedFilterListParameterVO = (List<AdvancedFilterVO>) parameter;
	
			  StructDescriptor structDescriptor = StructDescriptor.createDescriptor("OBJ_ADV_FLTR", connection);
		     
			  STRUCT[] structs = new STRUCT[advancedFilterListParameterVO.size()];
		       
			  @SuppressWarnings("unchecked")
			  List<AdvancedFilterVO> advancedFilterListVO = (List<AdvancedFilterVO>) parameter;
			
			  for(int index = 0; index < advancedFilterListParameterVO.size(); index++) {
		        	AdvancedFilterVO obj = advancedFilterListVO.get(index);
		            Object[] params = new Object[6];
		            params[0] = obj.getAdvanceFilterId();
		            params[1] = obj.getOperatorId();
		            params[2] = null;
		            params[3] = obj.getFilterFromValue();
		            params[4] = obj.getFilterToValue();
		            params[5] = obj.getValueList();
		            STRUCT struct = new STRUCT(structDescriptor, connection, params);
		            structs[index] = struct;
			  }
	
			  ArrayDescriptor desc = ArrayDescriptor.createDescriptor("TB_OBJ_ADV_FLTR",connection);
			  ARRAY oracleArray = new ARRAY(desc, connection, structs);
			  ps.setArray(i, oracleArray);
		  }catch(SQLException e){
			  /** Added Exception class to debug */
			  log.debug("Exception occured in AdvacnedFilterListHandler-->"+e.getMessage());
			  
		  }finally{
			  if(connection != null){
				  connection.close();	 			  
			  }
		  }
	}
		  
		  

	@Override
	public Object getResult(ResultSet rs, String columnName) throws SQLException {
		Array autoFill =   rs.getArray(columnName);
		if(autoFill!=null){
		Object[] autoFillArr = (Object[]) autoFill.getArray();
		return autoFillArr;
		}
		return null;
	}

	@Override
	public Object getResult(ResultSet rs, int columnIndex) throws SQLException {
		return null;
	}

	@Override
	public Object getResult(CallableStatement cs, int columnIndex) throws SQLException {
		return null;
	}
	
	
}
