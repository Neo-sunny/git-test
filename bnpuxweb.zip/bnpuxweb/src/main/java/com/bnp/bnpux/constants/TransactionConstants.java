/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Transaction Constants
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 21 Feb 2017				Sathishkumar B										FO 10.0 - S008, S009, S010
************************************************************************************************************************************************************/
package com.bnp.bnpux.constants;

public interface TransactionConstants {
	
	public static final String VIEW_TYPE_TRANSACTION_SUMMARY = "TRANSACTION_SUMMARY";
	
	public static final String VIEW_TYPE_TRANSACTION_LIST = "TRANSACTION_LIST";
	
	public static final String PARAM_USER_ID = "userId";
	
	public static final String PARAM_USER_TYPE_ID = "userTypeId";
	
	public static final String PARAM_RECORD_FROM = "recordFrom";
	
	public static final String PARAM_RECORD_TO = "recordTo";
	
	public static final String PARAM_GROUP_INDICATOR = "groupIndicator";
	
	public static final String PARAM_PAYMENT_DATE = "paymentDate";	
	
	public static final String PARAM_TRANSACTION_SUMMARY = "transactionSummary";
	
	public static final String PARAM_TRANSACTION_LIST = "transactionListDetails";

	public static final String PARAM_ERROR_MESSAGE = "errorMsg";

	public static final String EXCEPTION_TRANSACTION_INFORMATION = "Unable to fetch Transaction Information - Database Exception";

	public static final String PARAM_BUYER_ORG_ID = "buyerOrgId";

	public static final String PARAM_SUPPLIER_ORG_ID = "supplierOrgId";

	public static final String PARAM_LEAD_ORG_ID = "leadOrgId";

	public static final String PARAM_CURRENCY_CODE = "currencyCode";
	
	public static final String PARAM_BUYER_REF_NO_UNIQUE="buyerRefNoUniqueValue";
	
	public static final String PARAM_PAYMENT_FLAG = "paymentFlagValue";
	
	public static final String PARAM_LEAD_ORG_VALUE = "leadOrgIdValue";
	
	public static final String FILTER_STATUS = "filterStatus";
	public static final String FILTER_PERIOD = "filterPeriod";

	public static final String FILTER_BRANCH = "filterBranch";
	public static final String CANCEL_DISCOUNT = "CANCELDISCOUNT";
	public static final String APPROVE_DISCOUNT = "APPROVE";
	public static final String UNDO_DISCOUNT = "UNDO";
	public static final String ACCEPT_DISCOUNT = "ACCEPT";
	public static final String REJECT_DISCOUNT = "REJECT";
	
	public static final String QUICK_SEARCH = "quickSearchText";
	
	// Added for Callout 
	public static final String PARAM_TRANSACTION_CHARGE_AMOUNT = "transactionChargeAmount";
	
	public static final String PARAM_TRANSACTION_CONFIRMED_PYMNT_AMOUNT = "transactionCnfrmdPymtAmt";
	
	public static final String VIEW_TYPE_TRANSACTION_CHARGE_AMT = "TRANS_CHARGE_AMT_CALLOUT";
	
	public static final String VIEW_TYPE_TRANSACTION_CONFIRMED_PYMNT_AMT = "TRANS_CONFIRMED_AMT_CALLOUT";

	public static final String PARAM_PAYMENT_REF_NO = "paymentRefNo";
	
	public static final String PARAM_REC_TYPE = "recType";
	
	public static final String TXN_UNABLE_TO_GET_DETAILS = "Unable to get the requested details";
	
	public static final String FUNCID_TXN_DISCDETAILS_POPUP = "TXN_DISCDETAILS_POPUP";
	
	
}
