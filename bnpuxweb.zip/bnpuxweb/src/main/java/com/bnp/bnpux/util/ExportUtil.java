/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     Export Util
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 * 28 Feb 2017				 		Sathishkumar B										 					  FO 10.0 - S011, S012
 * 28 Jul 2017                      Anand                                                                     Sprint 7 - S1411004
 *****************************************************************************************************************************************************************/
package com.bnp.bnpux.util;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.ResourceBundle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.constants.ExportConstants;
import com.bnp.bnpux.controllers.ExportController;
import com.bnp.bnpux.vo.requestVO.ExportRequestVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public class ExportUtil {

	public static final Logger log = LoggerFactory
			.getLogger(ExportController.class);

	public static final String CSV = "CSV";
	public static final String XLS = "XLS";
	public static final String PDF = "PDF";
	public static final String ccyStr = "{{ccy}}";
	// For Transaction
	protected static List<String> transactionheaders = null;
	protected static List<String> paymentHeaders = null;
	protected static List<String> settlementHeaders = null;
	protected static List<String> reportHeaders = null;
	protected static List<String> paymentPopupHeaders1 = null;
	protected static List<String> paymentPopupHeaders2 = null;
	protected static List<String> paymentPopupHeaders3 = null;
	protected static List<String> paymentPopupHeaders4 = null;
	// For Credit Note Inquiry
	protected static List<String> creditNoteHeaders = null;
	protected static List<String> settlementDueHeaders = null;
	protected static List<String> preSettlementForCastHeaders = null;
	protected static List<String> availablePaymentHeaders = null;
	protected static List<String> recievedPaymentHeaders = null;
	protected static List<String> viewScheduledReportHeaders = null;
	protected static List<String> agingReportHeaders = null;
	
	protected static List<String> limitUtilRptHeaders =null;//S39801
	
	protected static List<String> remittanceReportHeader = null;
	
	//Disc Trans Report Export
	protected static List<String> discTransRptHeaders =null; 

	protected static List<String> txnDiscDetailsPopupExportHeaders1 = null;
	protected static List<String> txnDiscDetailsPopupExportHeaders2 = null;
	protected static List<String> txnDiscDetailsPopupExportHeaders3 = null;
	protected static List<String> txnDiscDetailsPopupExportHeaders4 = null;
	protected static List<String> txnDiscDetailsPopupExportHeaders5 = null;
	protected static List<String> txnDiscDetailsPopupExportHeaders6 = null;
	protected static List<String> txnDiscDetailsPopupExportHeaders7 = null;
	/**FO 10.0 - S011, S012**/
	
	public static final String EN = "en";
	public static final String US = "US";
	public static final String PaymentReport_PDF = "PaymentReport_PDF";
	public static final String TransactionReport_PDF = "TransactionReport_PDF";
	public static final String SettlementReport_PDF = "SettlementReport_PDF";
	public static final String REPORTS_PDF = "UploadedInvoiceReport_PDF";
	public static final String CREDIT_NOTE_REPORT_PDF = "CreditNoteReport_PDF";
	public static final String LIMIT_UTIL_REPORT_PDF = "LimitUtilizationReport_PDF";//S39801
	public static final String DISC_TRANS_REPORT_PDF = "DiscountTransactionReport_PDF";
	public static final String PAYMENT_POPUP_PDF = "PO_Popup_Detail_PDF";
	public static final String TRANSACTION_POPUP_PDF = "Trans_Popup_Detail_PDF";
	public static final String PAYMENT_ORDER_PAGE = "PAYMENT_ORDER_PAGE";
	public static final String SETTLEMENT_PAGE = "SETTLEMENT_PAGE";
	public static final String TRANSACTION_PAGE = "TRANSACTION_PAGE";
	public static final String REPORTS_PAGE = "REPORTS_PAGE";
	public static final String CREDIT_NOTE_REPORT = "CREDIT_NOTE_REPORT";
	public static final String LIMIT_UTIL_REPORT = "LIMIT_UTILIZATION_REPORT";//S39801
	public static final String DISC_TRANS_REPORT = "DISCOUNT_TRANSACTION_REPORT"; //S312701
	public static final String AUDIT_CONCATENATE = "-";
	public static final String EXPORT = "EXPORT";
	public static final String DATE_RANGE = "Date Range";
	//CMA
	public static final String SETTLEMENT_DUE_REPORT_PDF = "SettlementDueReminderReport_PDF";
	public static final String PRE_SETTLEMENT_DUE_REPORT_PDF = "PreSettlementDueReminderReport_PDF";
	public static final String SETTLEMENT_DUE_REPORT_PDF_FOR_ORG = "SettlementDueReminderReport_Org_PDF";
	public static final String PRE_SETTLEMENT_DUE_REPORT_PDF_FOR_ORG = "PreSettlementDueReminderReport_Org_PDF";
	public static final String SETTLEMENT_DUE_REPORT = "SETTLEMENT_DUE_REPORT";
	public static final String SETTLEMENT_DUE_REPORT_TYPE = "RPT_SETTLE_STLMT_DUE";
	public static final String SETTLEMENT_DUE_PRESETTLE_REPORT_TYPE="RPT_SETTLE_PRE_STLMT";
	
	public static final String PAYMENT_REPORT = "PAYMENT_REPORT";
	public static final String AVAILABLE_PAYMENT_REPORT_PDF = "Available_Payment_Report_PDF";
	public static final String RECIEVED_PAYMENT_REPORT_PDF = "Recieved_Payment_Report_PDF";
	public static final String AVAILABLE_PAYMENT_REPORT_TYPE = "RPT_AVLBLE_PYMT_OPEN_INV";
	public static final String RECIEVED_PAYMENT_REPORT_TYPE="RPT_AVLBLE_PYMT_PAID_INV";
	
	//Settlement Due Reminder Report-XLS Headers
	
	public static final String CLIENT_ORG_NAME = "bnp.settlementDue.export.clientorgname";
	public static final String COUNTERPARTY_ORG_NAME = "bnp.settlementDue.export.cptyorgname";
	public static final String BUYER_ERP_ID = "bnp.settlementDue.export.buyerErpId";
	public static final String SUPPLIER_ERP_ID = "bnp.settlementDue.export.supplierErpId";
	public static final String INVOICE_REF_NUMBER = "bnp.settlmntDueReminder.details.InvoiceRefNum.label";
	public static final String ORIGINAL_DUE_DATE = "bnp.settlmntDueReminder.details.OrgnlDueDate.label";
	public static final String ADJ_DUE_DATE = "bnp.settlmntDueReminder.details.AdjstDueDate.label";
	public static final String CCY_CODE = "bnp.creditNoteInq.fltrLabel.ccy";
	public static final String INVOICE_AMT = "bnp.settlmntDueReminder.details.InvoiceAmt.label";
	public static final String ORIGINAL_SETTLE_DUE_AMT = "bnp.settlmntDueReminder.details.OutStndingAmt.label";
	
	//View Scheduled Report definitions
	public static final String VIEW_SCHEDULED_REPORT = "VIEW_SCHEDULED_REPORT";
	public static final String VIEW_SCHEDULE_REPORT_PDF = "View_Scheduled_Report_PDF";
	
	//Remittance Report definitions
	public static final String REMITTANCE_REPORT = "REMITTANCE_REPORT";
	public static final String REMITTANCE_REPORT_PDF = "RemittanceReport_PDF";
	
	//Aging Report
	public static final String AGING_REPORT = "AGING_REPORT";
	public static final String AGING_REPORT_PDF = "AgingReport_PDF";
	
	
	public static final String DISC_DATE = "bnp.settlmntDueReminder.details.DiscountDate.label";
	public static final String DIS_REF_NO = "bnp.settlmntDueReminder.details.DiscountRef.label";
	public static final String DISC_TENURE ="bnp.basket.lable.grid.header.tenor";
	public static final String FINANCE_AMT=			"bnp.settlmntDueReminder.details.FinancingAmt.label";
	public static final String AVLBLE_AMT	=       "bnp.settlmntDueReminder.details.OriginalDiscountAmount.label";
	public static final String RATE_CHARGE_TYPE	=   "bnp.reports.panelheader.ratechargetype";
	public static final String RATE_APPLIED	=       "bnp.settlmntDueReminder.details.RateApplied.label";
	public static final String REVISED_TENURE	=   "bnp.settlmntDueReminder.details.RevisedTenor.label";
	public static final String IND_REVISED_RATE	=   "bnp.settlmntDueReminder.details.IndicativeRevisedRate.label";
	public static final String REVISED_DISC_AMT=    "bnp.settlmntDueReminder.details.RevisedDiscountAmount.label";
	
	
	public static final String bnp_headerTab_pmntOrders = "bnp.headerTab.pmntOrders";
	public static final String bnp_paymentord_stats_label = "bnp.paymentord.stats.label";
	public static final String bnp_paymentord_discdate_label = "bnp.paymentord.discdate.label";
	public static final String bnp_paymentord_matDate_label = "bnp.paymentord.matDate.label";
	public static final String INVOICE_REF = "bnp.discount.creditnote.invoice.refno";
	public static final String bnp_paymentord_totalorg_label = "bnp.paymentord.totalorg.label";
	public static final String bnp_paymentord_availableamt_label = "bnp.paymentord.availableamt.label";
	public static final String bnp_paymentord_indnetamount_label = "bnp.paymentord.indnetamount.label";
	public static final String bnp_paymentord_alreadypaid_label = "bnp.paymentord.alreadypaid.label";
	public static final String bnp_paymentord_inprocess_label = "bnp.paymentord.inprocess.label";
	public static final String bnp_paymentord_supplierbalance_label = "bnp.paymentord.supplierbalance.label";
	public static final String INVOICE_ISSUE_DATE = "bnp.export.invoiceIssueDate.label";
	public static final String bnp_paymentOrder_cnCalloutCallout_buyerRef_label = "bnp.paymentOrder.cnCalloutCallout.buyerRef.label";
	public static final String bnp_paymentOrder_cnCalloutCallout_supplierRef_label = "bnp.paymentOrder.cnCalloutCallout.supplierRef.label";
	public static final String Credit_Note_Effective_Date = "bnp.paymentOrder.cnCalloutCallout.creditNoteEffectiveDate.label";
	public static final String Credit_Note_Amount_Utilized = "bnp.paymentOrder.cnCalloutCallout.creditNoteAmtUtilized.label";
	public static final String bnp_headerTab_settlements = "bnp.headerTab.settlements";
	public static final String DUE_DATE = "bnp.export.dueDate.label";
	public static final String bnp_paymentOrder_avlAmtCallout_totalOrginalAmt_label = "bnp.paymentOrder.avlAmtCallout.totalOrginalAmt.label";
	public static final String bnp_label_Due_Amount = "bnp.export.Due.Amount";
	public static final String Invoice_issue_date = "bnp.export.invoiceIssueDate.label";
	public static final String BUYER_REF = "bnp.paymentOrder.invCalloutCallout.buyerRef.label";
	public static final String SUPPLIER_REF = "bnp.paymentOrder.invCalloutCallout.sellerRef.label";
	public static final String Buyer = "bnp.export.buyer.label";
	public static final String Supplier = "bnp.export.supplier.label";
	public static final String bnp_trans_paymtamnt_label = "bnp.trans.paymtamnt.label";
	public static final String bnp_paymentOrder_netIndCalloutCallout_indicativeChargeAmt_label = "bnp.paymentOrder.netIndCalloutCallout.indicativeChargeAmt.label";
	public static final String bnp_trans_inddiscamt_label = "bnp.trans.inddiscamt.label";
	public static final String bnp_trans_netindpymtamt_label = "bnp.trans.netindpymtamt.label";
	public static final String bnp_trans_confpaymentamt_label = "bnp.trans.confpaymentamt.label";
	public static final String INVOICE_REFERANCE = "bnp.export.Invoice.Credit.Note";
	public static final String Discount_Reference = "bnp.transaction.transChargeAmtCallout.discRefNo.label";
	public static final String CCY = "bnp.disc.ccy.label";
	public static final String PAYMENT_DATE = "bnp.trans.paymtdate.label";
	
	public static final String ALREADY_SETTLED = "bnp.settlement.alreadysettled.label";
	
	
	public static final String Batch_Reference = "bnp.export.BatchRef";
	public static final String PO_Refereance = "bnp.export.PoRefer";
	public static final String RATE = "bnp.export.rate";
	public static final String creditFundingReport_indicativeDiscountRate = "creditFundingReport.indicativeDiscountRate";
	public static final String mbDiscTransReport_tenorDays = "bnp.export.tenorDays";
	public static final String DiscountInitiatedEmail_appliedMinDiscFee = "bnp.export.appliedMinDiscFee";
	public static final String RemittanceReport_cnrefno = "bnp.export.creditNoteRef";
	
	//Credit Note Inquiry Headers For XLS
	public static final String Credit_Note_Inquiry_Header = "com.report.export.cnt.reportname";
	public static final String Credit_Note_Inquiry_Branch = "com.report.export.cnt.header.branch";
	public static final String Credit_Note_Inquiry_Buyer = "com.report.export.cnt.header.buyer";
	public static final String Credit_Note_Inquiry_Supplier = "com.report.export.cnt.header.supplier";
	public static final String Credit_Note_Inquiry_Currency = "bnp.reports.creditNoteInqReport.ccy.label";
	public static final String Credit_Note_Inquiry_IssueDate = "bnp.reports.creditNoteInqReport.issueDate.label";
	public static final String Credit_Note_Inquiry_EffectiveDate = "bnp.reports.creditNoteInqReport.effectiveDate.label";
	public static final String Credit_Note_Inquiry_Status = "com.report.export.cnt.header.status";
	public static final String Credit_Note_Inquiry_Reference = "bnp.reports.creditNoteInqReport.creditNoteRefNo.label";
	public static final String Credit_Note_Inquiry_OriginalAmount = "bnp.reports.creditNoteInqReport.originalAmt.label";
	public static final String Credit_Note_Inquiry_OutstandingAmount = "bnp.reports.creditNoteInqReport.outstandingAmt.label";
	public static final String Credit_Note_Inquiry_UtilizedAmount = "bnp.reports.creditNoteInqReport.utilizedAmt.label";
	public static final String Credit_Note_Inquiry_BlockedAmount = "bnp.reports.creditNoteInqReport.blockedAmt.label";
							
	//S39801
	public static final String Limit_Util_Report_clientOrgID = "bnp.reports.filter.clientOrgID";
	public static final String Limit_Util_Report_custname = "bnp.limitUtilRpt.header.custname";
	public static final String Limit_Util_Report_convertedCcy = "bnp.limitUtilRpt.header.convertedCcy";
	public static final String Limit_Util_Report_limitType = "bnp.limitUtilRpt.fltrLabel.limitType";
	public static final String Limit_Util_Report_groupId = "bnp.reports.limitUtilization.groupEntityLimit.groupId.label";
	public static final String Limit_Util_Report_TPBankID = "bnp.reports.limitUtilization.groupThirdPartyLimit.TPBankID.label";
	public static final String Limit_Util_Report_TPBankName = "bnp.reports.limitUtilization.groupThirdPartyLimit.TPBankName.label";
	public static final String Limit_Util_Report_counterPartyOrgID = "bnp.reports.limitUtilization.counterpartyLimit.counterPartyOrgID.label";
	public static final String Limit_Util_Report_counterPartyERPID = "bnp.reports.limitUtilization.counterpartyLimit.counterPartyERPID.label";
	public static final String Limit_Util_Report_counterPartyName = "bnp.reports.limitUtilization.counterpartyLimit.counterPartyName.label";
	public static final String Limit_Util_Report_customerLimitCcy = "bnp.reports.limitUtilization.thirdPartyLimit.customerLimitCcy.label";
	public static final String Limit_Util_Report_grantedLimit = "bnp.limitUtilRpt.header.grantedLimit";
	public static final String Limit_Util_Report_utilLimit = "bnp.limitUtilRpt.header.utilLimit";
	public static final String Limit_Util_Report_availLimit = "bnp.limitUtilRpt.header.availLimit";
	public static final String Limit_Util_Report_indicativeLimit ="bnp.limitUtilRpt.header.indicativeLimit";
	public static final String Limit_Util_Report_indicativeConversionRate = "bnp.reports.limitUtilization.entityLimit.indicativeConversionRate.label";
	public static final String Limit_Util_Report_grantedLimitEurEqu = "bnp.limitUtilRpt.header.grantedLimitEurEqu";
	public static final String Limit_Util_Report_utilLimitEurEqu = "bnp.limitUtilRpt.header.utilLimitEurEqu";
	public static final String Limit_Util_Report_availLimitEurEqu = "bnp.limitUtilRpt.header.availLimitEurEqu";
	public static final String Limit_Util_Report_indEffeAvailLimitEurEqu = "bnp.limitUtilRpt.header.indEffeAvailLimitEurEqu";
	
	
	//Disc Trans Report Export
	public static final String Discount_Transaction_Report_BranchId = "com.report.export.discount.transreport.discount.Branch.id";
	public static final String Discount_Transaction_Report_BuyerId = "com.report.export.discount.transreport.discount.Buyer.id";
	public static final String Discount_Transaction_Report_SupplierId = "com.report.export.discount.transreport.discount.Supplier.id";
	public static final String Discount_Transaction_Report_Reference_No = "bnp.reports.discTransReport.discRefNo.label";
	public static final String Discount_Transaction_Report_Discount_Date = "bnp.reports.discTransReport.discountDate.label";
	public static final String Discount_Transaction_Report_Discount_MaturityDate = "bnp.reports.discTransReport.maturityDate.label";
	public static final String Discount_Transaction_Report_Discount_Status = "bnp.reports.discTransReport.status.label";
	public static final String Discount_Transaction_Report_Tenor = "bnp.reports.discTransReport.tenor.label";
	public static final String Discount_Transaction_Report_ConvertedCcy = "com.report.export.discount.transreport.ccy";
	public static final String Discount_Transaction_Report_OriginalAmt = "bnp.reports.discTransReport.originalAmt.label";
	public static final String Discount_Transaction_Report_FinancedAmt = "bnp.reports.discTransReport.financedAmount.label";
	public static final String Discount_Transaction_Report_DscountAmt = "bnp.reports.discTransReport.discountAmount.label";
	public static final String Discount_Transaction_Report_Indicative_NetAmt = "bnp.reports.discTransReport.indicativeNetAmount.label";
	public static final String Discount_Transaction_Report_Customer_ReferenceNo = "bnp.reports.discTransReport.custRefNo.label";
	public static final String Discount_Transaction_Report_Indicative_DiscountRate = "bnp.reports.discTransReport.indicativeDiscountRate.label";
	public static final String Discount_Transaction_Report_Indicative_ChargeAmt = "bnp.reports.discTransReport.indicativeChargeAmount.label";
	public static final String Discount_Transaction_Report_Original_MaturityDate ="bnp.reports.discTransReport.originalMaturityDate.label";
	public static final String Discount_Transaction_Report_AdjustmentDays = "bnp.reports.discTransReport.adjustmentDays.label";
	
	//View Scheduled report  Headers For XLS
	public static final String View_Scheduled_Report_SchRepID = "bnp.reports.summary.reportScheduleId";
	public static final String View_Scheduled_Report_RepName = "bnp.reports.summary.report";
	public static final String View_Scheduled_Report_RepFileName = "bnp.reports.summary.reportFileName";
	public static final String View_Scheduled_Report_OrgID = "bnp.reports.summary.reportOrgId";
	public static final String View_Scheduled_Report_Frequency = "bnp.reports.summary.frequency";
	public static final String View_Scheduled_Report_LastGenerated = "bnp.reports.summary.lastGenDateTime";
	public static final String View_Scheduled_Report_LastViewed = "bnp.reports.summary.lastViewed";

	
	//Aging report  Headers For XLS
	public static final String Aging_Report_BuyerOrgID = "com.report.export.aging.report.buyer.org.id";
	public static final String Aging_Report_SupplierOrgID = "com.report.export.aging.report.supplier.org.id";
	public static final String Aging_Report_BuyerERPID = "com.report.export.aging.report.buyer.erp.id";
	public static final String Aging_Report_SupplierERPID = "com.report.export.aging.report.supplier.erp.id";	
	public static final String Aging_Report_TimePeriod = "com.report.export.aging.report.time.period";
	public static final String Aging_Report_Ccy = "com.report.export.aging.report.ccy";
	public static final String Aging_Report_PoReference = "com.report.export.aging.report.poreference";
	public static final String Aging_Report_DocWithStatus = "com.report.export.aging.report.document.status";
	public static final String Aging_Report_MaturityDate = "com.report.export.aging.report.maturity.date";
	public static final String Aging_Report_FinancingBank = "com.report.export.aging.report.financing.bank";
	public static final String Aging_Report_PayableAmount = "com.report.export.aging.report.payable.amount";
	public static final String Aging_Report_OutstandingAmount = "com.report.export.aging.report.outstanding.amount";
	public static final String Aging_Report_InvoiceRefNum = "com.report.export.aging.report.invoice.reference.number";
	public static final String Aging_Report_IssueDate = "com.report.export.aging.report.issue.date";
	public static final String Aging_Report_AdditionalRef = "com.report.export.aging.report.additional.reference.number";
	public static final String Aging_Report_InvoiceAmt = "com.report.export.aging.report.invoice.amount";
	public static final String Aging_Report_CreditNoteRefNum = "com.report.export.aging.report.cnote.reference.no";
	public static final String Aging_Report_UtilizedDate = "com.report.export.aging.report.cnote.utilized.date";
	public static final String Aging_Report_CreditNoteOriginalAmt = "com.report.export.aging.report.cnote.original.amount";
	public static final String Aging_Report_UtilizedType = "com.report.export.aging.report.utilized.type";
	public static final String Aging_Report_UtilizedAmt = "com.report.export.aging.report.utilized.amount";

	
	// Remittance Report Headers for XLS
	public static final String Remittance_Report_Header = "bnp.reports.remittanceReport.export.reportname"; 
	public static final String Remittance_Report_BranchOrgId = "bnp.remittanceReportInq.fltrLabel.buyerOrgId";
	public static final String Remittance_Report_SupplierOrgId = "bnp.remittanceReportInq.fltrLabel.supplierOrgId";
	public static final String Remittance_Report_ccyCode = "bnp.remittanceReportInq.fltrLabel.ccy";
	public static final String Remittance_Report_byrERPId = "bnp.reports.remittanceReport.export.byrERPId";
	public static final String Remittance_Report_splrERPId = "bnp.reports.remittanceReport.export.splrERPId";
	public static final String Remittance_Report_poRef = "bnp.reports.remittanceReport.export.poRef";	
	public static final String Remittance_Report_dueDate = "bnp.reports.remittanceReport.due.date";
	public static final String Remittance_Report_pmtStatus = "bnp.reports.remittanceReport.payment.status";
	public static final String Remittance_Report_documentType = "bnp.reports.remittanceReport.document.type";
	public static final String Remittance_Report_orglAmt = "bnp.reports.remittanceReport.original.amount";
	public static final String Remittance_Report_avlAmt = "bnp.reports.remittanceReport.available.amount";
	public static final String Remittance_Report_invcRef = "bnp.reports.remittanceReport.export.invcRef";
	public static final String Remittance_Report_issueDate = "bnp.reports.remittanceReport.issue.date";
	public static final String Remittance_Report_dueDate1 = "bnp.reports.remittanceReport.due.date";
	public static final String Remittance_Report_invcAmt = "bnp.reports.remittanceReport.export.invcAmt";
	public static final String Remittance_Report_addtnlRef = "bnp.reports.remittanceReport.additional.ref";
	public static final String Remittance_Report_itemNum = "bnp.reports.remittanceReport.lineItmDtls.itmNo";
	public static final String Remittance_Report_partNum = "bnp.reports.remittanceReport.lineItmDtls.prtNo";
	public static final String Remittance_Report_itemDscrp = "bnp.reports.remittanceReport.lineItmDtls.itmDscrpt";
	public static final String Remittance_Report_itemQunt = "bnp.reports.remittanceReport.export.itemQunt";
	public static final String Remittance_Report_unitPrc = "bnp.reports.remittanceReport.lineItmDtls.untPrce";
	public static final String Remittance_Report_subtotal = "bnp.reports.remittanceReport.lineItmDtls.sbTotal";
	public static final String Remittance_Report_crtNoteRefNum = "bnp.reports.remittanceReport.crtNoteUtlzDtls.crtRfrnceNo";
	public static final String Remittance_Report_utldDate = "bnp.reports.remittanceReport.export.utldDate";
	public static final String Remittance_Report_dscntRefNum = "bnp.reports.remittanceReport.export.dscntRefNum";
	public static final String Remittance_Report_utldType = "bnp.reports.remittanceReport.crtNoteUtlzDtls.utlzdType";
	public static final String Remittance_Report_utldAmt = "bnp.reports.remittanceReport.crtNoteUtlzDtls.utlzdAmt";
	public static final String Remittance_Report_dscntRefNum1 = "bnp.reports.remittanceReport.export.dscntRefNum";
	public static final String Remittance_Report_dscntPymtRefNo = "bnp.reports.remittanceReport.dcntDtls.dcntPymntRefNo";
	public static final String Remittance_Report_dscntPymtSts = "bnp.reports.remittanceReport.dcntDtls.dcntPymntSts";
	public static final String Remittance_Report_dscntPymtDate = "bnp.reports.remittanceReport.dcntDtls.dcntPymntDt";
	public static final String Remittance_Report_dscntDate = "bnp.reports.remittanceReport.dcntDtls.dcntDt";
	public static final String Remittance_Report_splrAcc = "bnp.reports.remittanceReport.dcntDtls.splrAcc";
	public static final String Remittance_Report_amtToBeDscnt = "bnp.reports.remittanceReport.dcntDtls.amtDcntd";
	public static final String Remittance_Report_dscntAmt = "bnp.reports.remittanceReport.dcntDtls.dcntAmt";
	public static final String Remittance_Report_totalIndctvRate = "bnp.reports.remittanceReport.export.totalIndctvRate";
	public static final String Remittance_Report_netInctvAmt = "bnp.reports.remittanceReport.export.netInctvAmt";
	public static final String Remittance_Report_tenor = "bnp.reports.remittanceReport.export.tenor";
	public static final String Remittance_Report_dscntPymtAmt = "bnp.reports.remittanceReport.export.dscntPymtAmt";
	public static final String Remittance_Report_paidAmt = "bnp.reports.remittanceReport.export.paidAmt";
	public static final String Remittance_Report_maturityPymtRef = "bnp.reports.remittanceReport.export.maturityPymtRef";
	public static final String Remittance_Report_maturityPymtSts = "bnp.reports.remittanceReport.export.maturityPymtSts";
	public static final String Remittance_Report_splrAccNo = "bnp.reports.remittanceReport.export.splrAccNo";
	public static final String Remittance_Report_maturityPymtDt = "bnp.reports.remittanceReport.export.maturityPymtDt";
	public static final String Remittance_Report_maturityPymtAmt = "bnp.reports.remittanceReport.export.maturityPymtAmt";
	public static final String Remittance_Report_paidAmt1 = "bnp.reports.remittanceReport.export.paidAmt";



	
	public static final String File_Name_From_Client = "bnp.reports.summary.fileName";   //File Name From Client	File
	
	public static final String File_Received_Date_Time = "bnp.reports.summary.fileRecievedDateTime";   //File Received Date Time
	
	public static final String File_Name_Extension = "bnp.reports.summary.fileNameExtension";   //File Name Extension
	
	public static final String File_Status  = "bnp.reports.summary.fileStatus"; //File Status
	
	public static final String Error_Message = "bnp.reports.summary.errorMessage"; //Error Message

	public static final String PAYMENT_REF_NUMBER = "bnp.reports.report.paymentRefNo.label"; 
	
	public static final String Organization_ID = "bnp.reports.report.orgId.label"; //Organization ID
	
	public static final String Counterparty_Org_ID = "bnp.reports.report.leadOrgId.label"; //Counterparty Org ID
	
	public static final String Payment_Due_Date = "bnp.reports.report.paymentDueDate.label"; //Payment Due Date
	
	public static final String PAYMENT_STATUS = "bnp.reports.report.paymentInvStatus.label"; //PAYMENT_STATUS
	
	public static final String PAYMENT_AMOUNT = "bnp.reports.report.paymentAmount.label"; //PAYMENT AMOUNT
	
	public static final String PAYMENT_AMOUNT_BALANCE = "bnp.reports.report.paymentAmountBalance.label"; //Payemtn Amount balance
	
	public static final String Settlement_Amount = "bnp.reports.report.settlementAmount.label"; //Settlement Amount
	
	public static final String Invoice_Settlement_Status = "com.report.export.invoice.settle.status"; //Invoice Settlement Status
	
	public static final String Adj_Due_Date = "bnp.reports.report.adjustedDueDate.label"; //Adj. Due Date
	
	public static final String Extended_Due_Date = "bnp.reports.report.extendDueDate.label"; //Extended Due Date
	
	public static final String Adj_Extnd_Due_Date = "bnp.reports.report.adjustExtDueDate.label"; //Adj. Extnd. Due Date
	
	public static final String Type = "bnp.reports.report.invCnType.label"; //Type
	
	public static final String Ref_No = "bnp.reports.report.invRefCreditNoteRef.label"; //Ref. No.
	
	public static final String Currecy_CCY = "bnp.reports.report.invCurryCreditNoteCury.label";
	
	public static final String AMOUNT = "bnp.reports.report.invAmountCreditNoteAmt.label"; //Amount
	
	public static final String Issue_Date = "bnp.reports.report.invIssDateCreditNoteIssDate.label"; //Issue Date
	
	public static final String Due_Date_Original = "com.report.export.due.date.original"; //Due Date - Original
	
	public static final String Effective_Date = "bnp.reports.report.creditNoteEffDate.label"; //Effective Date
	
	public static final String STATUS = "bnp.reports.report.invStatCreditNoteStat.label"; //Status
	
	public static final String PAYMENT_ORDER_PAGE_POPUP = "PAYMENT_ORDER_PAGE_POPUP";
	
	public static final String TRANSACTION_PAGE_POPUP = "TRANSACTION_PAGE_POPUP";
	
	public static final String bnp_trans_confirmeddiscamt_label ="TransactionReport.confirmedDiscountAmount";
	
	public static final String popupExpLabel_pymtRef = "bnp.paymentorder.refNumberDetailsPopup.mainDetails.refNo";
	public static final String popupExpLabel_processingBranch = "bnp.paymentorder.refNumberDetailsPopup.mainDetails.processingBranch";
	public static final String popupExpLabel_Buyer = "bnp.paymentorder.refNumberDetailsPopup.mainDetails.buyer";
	public static final String popupExpLabel_Supplier = "bnp.paymentorder.refNumberDetailsPopup.mainDetails.supplier";
	public static final String popupExpLabel_dueDate = "bnp.paymentorder.refNumberDetailsPopup.mainDetails.payment.due.date";
	public static final String popupExpLabel_pymtAmt = "bnp.paymentorder.refNumberDetailsPopup.mainDetails.payment.amount";
	public static final String popupExpLabel_pymtAmtBal = "bnp.paymentorder.refNumberDetailsPopup.mainDetails.payment.amount.balance";
	public static final String popupExpLabel_consolidatedDiscDate = "bnp.paymentorder.refNumberDetailsPopup.mainDetails.consolidated.discount.date";
	public static final String popupExpLabel_countOfInv = "bnp.paymentorder.refNumberDetailsPopup.mainDetails.count.of.invoices";
	public static final String popupExpLabel_updatedPymtAmt = "bnp.paymentorder.refNumberDetailsPopup.mainDetails.updated.payment.amount";
	public static final String popupExpLabel_autoColDate = "bnp.paymentorder.refNumberDetailsPopup.mainDetails.auto.collection.date";
	public static final String popupExpLabel_outstandingSetAmt = "bnp.paymentorder.refNumberDetailsPopup.mainDetails.outstanding.settlement.amount";
	public static final String popupExpLabel_additionalRef = "bnp.paymentorder.refNumberDetailsPopup.mainDetails.additional.reference.no";
	public static final String popupExpLabel_autoCollStatus = "bnp.paymentorder.refNumberDetailsPopup.mainDetails.auto.collection.status";
	public static final String popupExpLabel_autoCollMsgRef = "bnp.paymentorder.refNumberDetailsPopup.mainDetails.auto.collection.message.reference";
	public static final String popupExpLabel_pymtCcy="bnp.paymentorder.refNumberDetailsPopup.mainDetails.payment.currency" ;//S066
	
	public static final String popupExpLabel_inv_invRef = "bnp.paymentorder.refNumberDetailsPopup.invoiceDetails.invoice.no";
	public static final String popupExpLabel_inv_invIssueDate = "bnp.paymentorder.refNumberDetailsPopup.invoiceDetails.issue.date";
	public static final String popupExpLabel_inv_invDueDate = "bnp.paymentorder.refNumberDetailsPopup.invoiceDetails.due.date";
	public static final String popupExpLabel_inv_originalAmount = "bnp.paymentorder.refNumberDetailsPopup.invoiceDetails.original.amount";
	public static final String popupExpLabel_inv_cnUtilAmt = "bnp.paymentorder.refNumberDetailsPopup.invoiceDetails.credit.note.utilized.amount";
	public static final String popupExpLabel_inv_BuyerRef = "bnp.paymentorder.refNumberDetailsPopup.invoiceDetails.buyer.ref";
	public static final String popupExpLabel_inv_SellerRef = "bnp.paymentorder.refNumberDetailsPopup.invoiceDetails.seller.ref";
	public static final String popupExpLabel_inv_updatedinvAmt = "bnp.paymentorder.refNumberDetailsPopup.invoiceDetails.updated.amount";
	public static final String popupExpLabel_inv_invCcy="bnp.paymentorder.refNumberDetailsPopup.invoiceDetails.invoiceCcy";//S066
	public static final String popupExpLabel_inv_cnCcy="bnp.paymentorder.refNumberDetailsPopup.invoiceDetails_invoiceCnCcy";//S066
	
	
	public static final String popupExpLabel_cn_cnRef = "bnp.paymentorder.refNumberDetailsPopup.creditNoteDetails.credit.note.ref.no";
	public static final String popupExpLabel_cn_issueDate = "bnp.paymentorder.refNumberDetailsPopup.creditNoteDetails.crissue.date";
	public static final String popupExpLabel_cn_effectiveDate = "bnp.paymentorder.refNumberDetailsPopup.creditNoteDetails.effective.date";
	public static final String popupExpLabel_cn_type = "bnp.paymentorder.refNumberDetailsPopup.creditNoteDetails.type";
	public static final String popupExpLabel_origAmt = "bnp.paymentorder.refNumberDetailsPopup.creditNoteDetails.croriginal.amount";
	public static final String popupExpLabel_status = "bnp.paymentorder.refNumberDetailsPopup.creditNoteDetails.status";
	public static final String popupExpLabel_utilRef = "bnp.paymentorder.refNumberDetailsPopup.creditNoteDetails.util.ref.no";
	public static final String popupExpLabel_cn_ccy="bnp.paymentorder.refNumberDetailsPopup.creditNoteDetails.ccy";//S066
	public static final String popupExpLabel_audit_uploadId = "bnp.paymentorder.refNumberDetailsPopup.mainDetails.upload.id";
	public static final String popupExpLabel_uploadBy = "bnp.paymentorder.refNumberDetailsPopup.mainDetails.uploaded.by";
	public static final String popupExpLabel_uploadOn = "bnp.paymentorder.refNumberDetailsExport.auditDetails.uploaded.on";
	public static final String popupExpLabel_releaseBy = "bnp.paymentorder.refNumberDetailsPopup.mainDetails.released.by";
	public static final String popupExpLabel_ReleaseOn = "bnp.paymentorder.refNumberDetailsExport.auditDetails.released.on";
	public static final String popupExpLabel_fileName = "bnp.paymentorder.refNumberDetailsPopup.mainDetails.file.name";
	public static final String popupExpLabel_fileStatus = "bnp.paymentorder.refNumberDetailsPopup.mainDetails.file.status";
	
	/**FO 10.0 - S011, S012**/
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_DISREFNO = "bnp.transaction.DiscountDetailsPopup.mainDetails.referenceDetails.disRefNo";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_DISCSTATUS = "bnp.transaction.DiscountDetailsPopup.mainDetails.discStatus";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_BUYER = "bnp.transaction.DiscountDetailsPopup.mainDetails.buyer";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_SUPPLIER = "bnp.transaction.DiscountDetailsPopup.mainDetails.Supplier";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_PYMTREFNO = "bnp.transaction.DiscountDetailsPopup.mainDetails.referenceDetails.pymtRefNo";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_BATCHREFNO = "bnp.transaction.DiscountDetailsPopup.mainDetails.referenceDetails.batchRefNo";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_ADDREFNO = "bnp.transaction.DiscountDetailsPopup.mainDetails.referenceDetails.addRefNo";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_CUSTREFNO = "bnp.transaction.DiscountDetailsPopup.mainDetails.referenceDetails.custRefNo";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_BENERECONREFVALUE = "bnp.transaction.DiscountDetailsPopup.mainDetails.referenceDetails.beneReconRefValue";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_PRIORDISREFNO = "bnp.transaction.DiscountDetailsPopup.mainDetails.referenceDetails.priorDisRefNo";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_ORGAMT = "bnp.transaction.DiscountDetailsPopup.mainDetails.amountDetails.orgAmt";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_SUPPLIERACCTNO = "bnp.transaction.DiscountDetailsPopup.mainDetails.amountDetails.supplierAcctNo";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_CREDITNOTEAMOUNT = "bnp.transaction.DiscountDetailsPopup.mainDetails.amountDetails.creditNoteAmount";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_PYMTAMT = "bnp.transaction.DiscountDetailsPopup.mainDetails.amountDetails.pymtAmt";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_CONFIRMEDINTERESTRATE = "bnp.transaction.DiscountDetailsPopup.mainDetails.discountDetails.confirmedInterestrate";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_CONFCHARGEAMT = "bnp.transaction.DiscountDetailsPopup.mainDetails.amountDetails.confChargeAmt";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_CONFIRMEDINTERESTAMT = "bnp.transaction.DiscountDetailsPopup.mainDetails.discountDetails.confirmedInterestAmt";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_CONFIRMEDNETAMOUNT = "bnp.transaction.DiscountDetailsPopup.mainDetails.amountDetails.confirmedNetAmount";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_DOCTYPE = "bnp.transaction.DiscountDetailsPopup.mainDetails.discountDetails.docType";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_PYMTDUEDATE = "bnp.transaction.DiscountDetailsPopup.mainDetails.discountDetails.pymtDueDate";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_OVERDUEDISCRATE = "bnp.transaction.DiscountDetailsPopup.mainDetails.discountDetails.overdueDiscRate";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_DISCAVLBLEAMT = "bnp.transaction.DiscountDetailsPopup.mainDetails.discountDetails.discAvlbleAmt";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_ISROLOVRCRTD = "bnp.transaction.DiscountDetailsPopup.mainDetails.discountDetails.isRolovrCrtd";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_ISMINDISCFEEAPPLIED = "bnp.transaction.DiscountDetailsPopup.mainDetails.discountDetails.isMinDiscFeeApplied";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_CREATEDDATE = "bnp.transaction.DiscountDetailsPopup.mainDetails.discountDetails.createdDate";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_DISCPYMTSTATUS = "bnp.transaction.DiscountDetailsPopup.mainDetails.discountDetails.discPymtStatus";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_INDDISCRATE = "bnp.transaction.DiscountDetailsPopup.mainDetails.indicativeAmtDetails.indDiscRate";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_INDCHARGEAMT = "bnp.transaction.DiscountDetailsPopup.mainDetails.indicativeAmtDetails.indChargeAmt";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_INDDISCAMT = "bnp.transaction.DiscountDetailsPopup.mainDetails.indicativeAmtDetails.indDiscAmt";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_INDNETAMT = "bnp.transaction.DiscountDetailsPopup.mainDetails.indicativeAmtDetails.indNetAmt";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_MINFINANCIALAMT = "bnp.transaction.DiscountDetailsPopup.mainDetails.otherDetails.minFinancialAmt";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_BUYERMARGINACC = "bnp.transaction.DiscountDetailsPopup.mainDetails.otherDetails.buyerMarginAcc";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_BANKMARGINACCOUNT = "bnp.transaction.DiscountDetailsPopup.mainDetails.otherDetails.bankMarginAccount";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_DUEDATE = "bnp.transaction.DiscountDetailsPopup.mainDetails.otherDetails.dueDate";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_ISROLOVRREQ = "bnp.transaction.DiscountDetailsPopup.mainDetails.otherDetails.isRolovrReq";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_DISCTENURE = "bnp.transaction.DiscountDetailsPopup.mainDetails.otherDetails.discTenure";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_RATECHARGETYPE = "bnp.transaction.DiscountDetailsPopup.mainDetails.otherDetails.rateChargeType";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_BILLTYPE = "bnp.transaction.DiscountDetailsPopup.mainDetails.otherDetails.billType";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_REMARKS = "bnp.transaction.DiscountDetailsPopup.mainDetails.otherDetails.remarks";
	//Sprint 7 - S1411004 start
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_CONFIRMEDBASERATEFLOORED = "bnp.transaction.DiscountDetailsPopup.mainDetails.discountDetails.confirmedBaseRateFloored";
	public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_INDBASERATEFLOORED = "bnp.transaction.DiscountDetailsPopup.mainDetails.indicativeAmtDetails.indBaserateFloored";
	//Sprint 7 - S1411004 end


	public static final String TXN_DISCOUNTDETAILSPOPUP_INDCHARGES_CHARGECODE = "bnp.transaction.DiscountDetailsPopup.indCharges.chargeCode";
	public static final String TXN_DISCOUNTDETAILSPOPUP_INDCHARGES_DESCRIPTION = "bnp.transaction.DiscountDetailsPopup.indCharges.description";
	public static final String TXN_DISCOUNTDETAILSPOPUP_INDCHARGES_CHARGECCY = "bnp.transaction.DiscountDetailsPopup.indCharges.chargeCCY";
	public static final String TXN_DISCOUNTDETAILSPOPUP_INDCHARGES_CHARGEAMOUNT = "bnp.transaction.DiscountDetailsPopup.indCharges.chargeAmount";
	public static final String TXN_DISCOUNTDETAILSPOPUP_INDCHARGES_CODEIDENTIFIER = "bnp.transaction.DiscountDetailsPopup.indCharges.codeIdentifier";
	public static final String TXN_DISCOUNTDETAILSPOPUP_INDCHARGES_AMOUNTTOBEDISCOUNTED = "bnp.transaction.DiscountDetailsPopup.indCharges.amountToBeDiscounted";
	public static final String TXN_DISCOUNTDETAILSPOPUP_INDCHARGES_CHARGEPERCENTAGE = "bnp.transaction.DiscountDetailsPopup.indCharges.chargePercentage";
	public static final String TXN_DISCOUNTDETAILSPOPUP_INDCHARGES_CONFIRMEDCHARGEAMOUNT = "bnp.transaction.DiscountDetailsPopup.indCharges.confirmedChargeAmount";
	
	
	public static final String TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_COMMSTARTDT = "bnp.transaction.DiscountDetailsPopup.commitmentFee.commStartDate";
	public static final String TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_COMMFEEFREQ = "bnp.transaction.DiscountDetailsPopup.commitmentFee.commFeeFrequency";
	public static final String TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_COMMENDDATE = "bnp.transaction.DiscountDetailsPopup.commitmentFee.commEndDate";
	public static final String TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_TOTCOMMFEEAMT = "bnp.transaction.DiscountDetailsPopup.commitmentFee.totCommFeeAmount";
	public static final String TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_COMMFEEPERIOD = "bnp.transaction.DiscountDetailsPopup.commitmentFee.commFeePeriod";
		
	
	public static final String TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_FROMDATE = "bnp.transaction.DiscountDetailsPopup.commitmentFee.commfromDate"; 
	public static final String TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_TODATE = "bnp.transaction.DiscountDetailsPopup.commitmentFee.commtoDate";
	public static final String TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_PERIOD = "bnp.transaction.DiscountDetailsPopup.commitmentFee.period";
	public static final String TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_AMOUNT = "bnp.transaction.DiscountDetailsPopup.commitmentFee.amount";
	public static final String TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_FEEPERCENTAGE = "bnp.transaction.DiscountDetailsPopup.commitmentFee.feePercentage";
	public static final String TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_OUTSTANDINGAMOUNT = "bnp.transaction.DiscountDetailsPopup.commitmentFee.outstandingAmount";
	public static final String TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_FEEPAYDUEDATE = "bnp.transaction.DiscountDetailsPopup.commitmentFee.feePayDueDate";
	public static final String TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_PAYMENTSTATUS = "bnp.transaction.DiscountDetailsPopup.commitmentFee.paymentStatus";
	public static final String TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_COMMFEEPAIDDT = "bnp.transaction.DiscountDetailsPopup.commitmentFee.commFeePaidDate";
	public static final String TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_PAIDAMT = "bnp.transaction.DiscountDetailsPopup.commitmentFee.paidAmount";
	public static final String TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_COMMFEEDEBTREF = "bnp.transaction.DiscountDetailsPopup.commitmentFee.commFeeDebitNoteRef";

	
	public static final String TXN_DISCOUNTDETAILSPOPUP_PODETAILS_REFERENCENO = "bnp.transaction.DiscountDetailsPopup.poDetails.referenceNo";
	public static final String TXN_DISCOUNTDETAILSPOPUP_PODETAILS_COMMITMENTRELEASEDATE = "bnp.transaction.DiscountDetailsPopup.poDetails.commitmentReleaseDate";
	public static final String TXN_DISCOUNTDETAILSPOPUP_PODETAILS_PAYMENTDUEDATE = "bnp.transaction.DiscountDetailsPopup.poDetails.paymentDueDate";
	public static final String TXN_DISCOUNTDETAILSPOPUP_PODETAILS_PAYMENTAMOUNT = "bnp.transaction.DiscountDetailsPopup.poDetails.paymentAmount";
	public static final String TXN_DISCOUNTDETAILSPOPUP_PODETAILS_UPDATEDPAYMENTAMOUNT = "bnp.transaction.DiscountDetailsPopup.poDetails.updatedPaymentAmount";
	
	public static final String TXN_DISCOUNTDETAILSPOPUP_INVOICEDETAILS_INVOICENO = "bnp.transaction.DiscountDetailsPopup.invoiceDetails.invoiceNo";
	public static final String TXN_DISCOUNTDETAILSPOPUP_INVOICEDETAILS_ISSUEDATE = "bnp.transaction.DiscountDetailsPopup.invoiceDetails.issueDate";
	public static final String TXN_DISCOUNTDETAILSPOPUP_INVOICEDETAILS_DUEDATE = "bnp.transaction.DiscountDetailsPopup.invoiceDetails.dueDate";
	public static final String TXN_DISCOUNTDETAILSPOPUP_INVOICEDETAILS_ORIGINALAMOUNT = "bnp.transaction.DiscountDetailsPopup.invoiceDetails.originalAmount";
	public static final String TXN_DISCOUNTDETAILSPOPUP_INVOICEDETAILS_CNUTILIZEDAMOUNT = "bnp.transaction.DiscountDetailsPopup.invoiceDetails.cnUtilizedAmount";
	public static final String TXN_DISCOUNTDETAILSPOPUP_INVOICEDETAILS_BUYERREF = "bnp.transaction.DiscountDetailsPopup.invoiceDetails.buyerRef";
	public static final String TXN_DISCOUNTDETAILSPOPUP_INVOICEDETAILS_SELLERREF = "bnp.transaction.DiscountDetailsPopup.invoiceDetails.SellerRef";
	public static final String TXN_DISCOUNTDETAILSPOPUP_INVOICEDETAILS_UPDATEDAMOUNT = "bnp.transaction.DiscountDetailsPopup.invoiceDetails.updatedAmount";
	
	public static final String TXN_DISCOUNTDETAILSPOPUP_CREDITNOTESDETAILS_CNREFNO = "bnp.transaction.DiscountDetailsPopup.creditNotesDetails.cnRefNo";
	public static final String TXN_DISCOUNTDETAILSPOPUP_CREDITNOTESDETAILS_ISSUEDATE = "bnp.transaction.DiscountDetailsPopup.creditNotesDetails.issueDate";
	public static final String TXN_DISCOUNTDETAILSPOPUP_CREDITNOTESDETAILS_EFFECTIVEDATE = "bnp.transaction.DiscountDetailsPopup.creditNotesDetails.effectiveDate";
	public static final String TXN_DISCOUNTDETAILSPOPUP_CREDITNOTESDETAILS_TYPE = "bnp.transaction.DiscountDetailsPopup.creditNotesDetails.type";
	public static final String TXN_DISCOUNTDETAILSPOPUP_CREDITNOTESDETAILS_AMOUNT = "bnp.transaction.DiscountDetailsPopup.creditNotesDetails.amount";
	public static final String TXN_DISCOUNTDETAILSPOPUP_CREDITNOTESDETAILS_STATUS = "bnp.transaction.DiscountDetailsPopup.creditNotesDetails.status";
	public static final String TXN_DISCOUNTDETAILSPOPUP_CREDITNOTESDETAILS_UTILREFNO = "bnp.transaction.DiscountDetailsPopup.creditNotesDetails.utilRefNo";
	/**FO 10.0 - S011, S012**/
	/**FO 10.0 - S067**/
	public static final String TXN_DISCOUNTDETAILSPOPUP_INDCHARGES_CHARGESCCY="bnp.transaction.DiscountDetailsPopup.creditNotesDetails.ChargeCcy";
	//public static final String TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_MINFEE_CCY="bnp.transaction.DiscountDetailsPopup.creditNotesDetails.minFeeCcy";
	public static final String TXN_DISCOUNTDETAILSPOPUP_INDCHARGES_DISCCCY="bnp.transaction.DiscountDetailsPopup.creditNotesDetails.DiscountCcy";
	public static final String TXN_DISCOUNTDETAILSPOPUP_FEE_CCY="bnp.transaction.DiscountDetailsPopup.creditNotesDetails.feeCcy";
	public static final String TXN_DISCOUNTDETAILSPOPUP_CNOTE_CCY="bnp.transaction.DiscountDetailsPopup.creditNotesDetails.creditNoteCcy";
	
	public static final String DISCOUNT_REF_NO       =	"com.report.export.payment.report.discount.refno";				
	public static final String INVOICE_NUMBER        =	"com.report.export.payment.report.invoice.number";				
	public static final String PYMT_INVOICE_ISSUE_DATE    =	"com.report.export.payment.report.invoice.issuedate";			       
	public static final String UPLOAD_DATE    	=		"com.report.export.payment.report.upload.date";				
	public static final String DISCOUNT_DATE         =	"com.report.export.payment.report.discount.date";			 
	public static final String CONFIRMED_DATE      	=	"com.report.export.payment.report.confirmed.date";				
	public static final String ORIGINAL_MATURITY_DATE=	"com.report.export.payment.report.original.maturity.date";		        
	public static final String MATURITY_DATE		  = "com.report.export.payment.report.maturity.date";			
	public static final String TENOR_DAYS		=		"com.report.export.payment.report.tenor.days";					
	public static final String ORIGINAL_INVOICE_AMOUNT=	"com.report.export.payment.report.original.invoice.amount";	
	public static final String INTEREST_RATE		=	"com.report.export.payment.report.interest.rate";				
	public static final String EURIBOR				=	"com.report.export.payment.report.euribor";					
	public static final String MARGIN				=	"com.report.export.payment.report.margin";						
	public static final String INTEREST_AMOUNT		=	"com.report.export.payment.report.interest.amount";			
	public static final String NET_DISCOUNT_AMOUNT	=	"com.report.export.payment.report.net.discountamount";			
	public static final String PYMT_STATUS			=	"com.report.export.payment.report.status";						
	public static final String BENEFICIARY_TYPE		=	"com.report.export.payment.report.beneficiary.type";			
	public static final String BENEFICIARY_VALUE	=   "com.report.export.payment.report.beneficiary.value";		
	
	public static List<String> getPaymentHeaders() {
		return paymentHeaders;
	}


	public static void setPaymentHeaders(List<String> paymentHeaders) {
		ExportUtil.paymentHeaders = paymentHeaders;
	}


	public static List<String> getPaymentPopupHeaders1() {
		return paymentPopupHeaders1;
	}


	public static void setPaymentPopupHeaders1(List<String> paymentPopupHeaders1) {
		ExportUtil.paymentPopupHeaders1 = paymentPopupHeaders1;
	}


	public static List<String> getPaymentPopupHeaders2() {
		return paymentPopupHeaders2;
	}


	public static void setPaymentPopupHeaders2(List<String> paymentPopupHeaders2) {
		ExportUtil.paymentPopupHeaders2 = paymentPopupHeaders2;
	}


	public static List<String> getPaymentPopupHeaders3() {
		return paymentPopupHeaders3;
	}


	public static void setPaymentPopupHeaders3(List<String> paymentPopupHeaders3) {
		ExportUtil.paymentPopupHeaders3 = paymentPopupHeaders3;
	}


	public static List<String> getPaymentPopupHeaders4() {
		return paymentPopupHeaders4;
	}


	public static void setPaymentPopupHeaders4(List<String> paymentPopupHeaders4) {
		ExportUtil.paymentPopupHeaders4 = paymentPopupHeaders4;
	}
	
	/**FO 10.0 - S011, S012**/

	public static List<String> getTxnDiscDetailsPopupExportHeaders1() {
		return txnDiscDetailsPopupExportHeaders1;
	}


	public static void setTxnDiscDetailsPopupExportHeaders1(List<String> txnDiscDetailsPopupExportHeaders1) {
		ExportUtil.txnDiscDetailsPopupExportHeaders1 = txnDiscDetailsPopupExportHeaders1;
	}


	public static List<String> getTxnDiscDetailsPopupExportHeaders2() {
		return txnDiscDetailsPopupExportHeaders2;
	}


	public static void setTxnDiscDetailsPopupExportHeaders2(List<String> txnDiscDetailsPopupExportHeaders2) {
		ExportUtil.txnDiscDetailsPopupExportHeaders2 = txnDiscDetailsPopupExportHeaders2;
	}


	public static List<String> getTxnDiscDetailsPopupExportHeaders3() {
		return txnDiscDetailsPopupExportHeaders3;
	}


	public static void setTxnDiscDetailsPopupExportHeaders3(List<String> txnDiscDetailsPopupExportHeaders3) {
		ExportUtil.txnDiscDetailsPopupExportHeaders3 = txnDiscDetailsPopupExportHeaders3;
	}


	public static List<String> getTxnDiscDetailsPopupExportHeaders4() {
		return txnDiscDetailsPopupExportHeaders4;
	}


	public static void setTxnDiscDetailsPopupExportHeaders4(List<String> txnDiscDetailsPopupExportHeaders4) {
		ExportUtil.txnDiscDetailsPopupExportHeaders4 = txnDiscDetailsPopupExportHeaders4;
	}


	public static List<String> getTxnDiscDetailsPopupExportHeaders5() {
		return txnDiscDetailsPopupExportHeaders5;
	}


	public static void setTxnDiscDetailsPopupExportHeaders5(List<String> txnDiscDetailsPopupExportHeaders5) {
		ExportUtil.txnDiscDetailsPopupExportHeaders5 = txnDiscDetailsPopupExportHeaders5;
	}


	public static List<String> getTxnDiscDetailsPopupExportHeaders6() {
		return txnDiscDetailsPopupExportHeaders6;
	}


	public static void setTxnDiscDetailsPopupExportHeaders6(List<String> txnDiscDetailsPopupExportHeaders6) {
		ExportUtil.txnDiscDetailsPopupExportHeaders6 = txnDiscDetailsPopupExportHeaders6;
	}

	public static List<String> getTxnDiscDetailsPopupExportHeaders7() {
		return txnDiscDetailsPopupExportHeaders7;
	}


	public static void setTxnDiscDetailsPopupExportHeaders7(List<String> txnDiscDetailsPopupExportHeaders7) {
		ExportUtil.txnDiscDetailsPopupExportHeaders7 = txnDiscDetailsPopupExportHeaders7;
	}
	
	/**
	 * @return the availblePaymentHeaders
	 */
	public static List<String> getAvailablePaymentHeaders() {
		return availablePaymentHeaders;
	}


	public static void setAvailablePaymentHeaders(List<String> availablePaymentHeaders) {
		ExportUtil.availablePaymentHeaders = availablePaymentHeaders;
	}


	/**
	 * @return the recievedPaymentHeaders
	 */
	public static List<String> getRecievedPaymentHeaders() {
		return recievedPaymentHeaders;
	}


	public static void setRecievedPaymentHeaders(List<String> recievedPaymentHeaders) {
		ExportUtil.recievedPaymentHeaders = recievedPaymentHeaders;
	}

	/**FO 10.0 - S011, S012**/

	static {

		paymentHeaders = new ArrayList<String>();
		paymentHeaders.add(bnp_headerTab_pmntOrders);
		paymentHeaders.add(Buyer);
		paymentHeaders.add(Supplier);
		paymentHeaders.add(bnp_paymentord_stats_label);
		paymentHeaders.add(bnp_paymentord_discdate_label);
		paymentHeaders.add(bnp_paymentord_matDate_label);
		paymentHeaders.add(INVOICE_REF);
		paymentHeaders.add(RemittanceReport_cnrefno);
		paymentHeaders.add(bnp_paymentord_totalorg_label);
		paymentHeaders.add(bnp_paymentord_availableamt_label);
		paymentHeaders.add(bnp_paymentord_indnetamount_label);
		paymentHeaders.add(bnp_paymentord_alreadypaid_label);
		paymentHeaders.add(bnp_paymentord_inprocess_label);
		paymentHeaders.add(bnp_paymentord_supplierbalance_label);
		paymentHeaders.add(INVOICE_ISSUE_DATE);
		paymentHeaders.add(bnp_paymentOrder_cnCalloutCallout_buyerRef_label);
		paymentHeaders.add(bnp_paymentOrder_cnCalloutCallout_supplierRef_label);
		paymentHeaders.add(Credit_Note_Effective_Date);
		paymentHeaders.add(Credit_Note_Amount_Utilized);
		
		paymentPopupHeaders1 = new ArrayList<String>();
		paymentPopupHeaders1.add(popupExpLabel_pymtRef);
		paymentPopupHeaders1.add(popupExpLabel_processingBranch);
		paymentPopupHeaders1.add(popupExpLabel_Buyer);
		paymentPopupHeaders1.add(popupExpLabel_Supplier);
		paymentPopupHeaders1.add(popupExpLabel_dueDate);
		paymentPopupHeaders1.add(popupExpLabel_pymtCcy);//S066
		paymentPopupHeaders1.add(popupExpLabel_pymtAmt);
		paymentPopupHeaders1.add(popupExpLabel_pymtAmtBal);
		paymentPopupHeaders1.add(popupExpLabel_consolidatedDiscDate);
		paymentPopupHeaders1.add(popupExpLabel_countOfInv);
		paymentPopupHeaders1.add(popupExpLabel_updatedPymtAmt);
		paymentPopupHeaders1.add(popupExpLabel_autoColDate);
		paymentPopupHeaders1.add(popupExpLabel_outstandingSetAmt);
		paymentPopupHeaders1.add(popupExpLabel_additionalRef);
		paymentPopupHeaders1.add(popupExpLabel_autoCollStatus);
		paymentPopupHeaders1.add(popupExpLabel_autoCollMsgRef);
		
		paymentPopupHeaders2 = new ArrayList<String>();
		paymentPopupHeaders2.add(popupExpLabel_inv_invRef);
		paymentPopupHeaders2.add(popupExpLabel_inv_invIssueDate);
		paymentPopupHeaders2.add(popupExpLabel_inv_invDueDate);
		paymentPopupHeaders2.add(popupExpLabel_inv_invCcy);//S066
		paymentPopupHeaders2.add(popupExpLabel_inv_originalAmount);
		paymentPopupHeaders2.add(popupExpLabel_inv_cnCcy);//S066
		paymentPopupHeaders2.add(popupExpLabel_inv_cnUtilAmt);
		paymentPopupHeaders2.add(popupExpLabel_inv_BuyerRef);
		paymentPopupHeaders2.add(popupExpLabel_inv_SellerRef);
		paymentPopupHeaders2.add(popupExpLabel_inv_updatedinvAmt);
		
		paymentPopupHeaders3 = new ArrayList<String>();
		paymentPopupHeaders3.add(popupExpLabel_cn_cnRef);
		paymentPopupHeaders3.add(popupExpLabel_cn_issueDate);
		paymentPopupHeaders3.add(popupExpLabel_cn_effectiveDate);
		paymentPopupHeaders3.add(popupExpLabel_cn_type);
		paymentPopupHeaders3.add(popupExpLabel_cn_ccy);//S066
		paymentPopupHeaders3.add(popupExpLabel_origAmt);
		paymentPopupHeaders3.add(popupExpLabel_status);
		paymentPopupHeaders3.add(popupExpLabel_utilRef);
		
		paymentPopupHeaders4 = new ArrayList<String>();
		paymentPopupHeaders4.add(popupExpLabel_audit_uploadId);
		paymentPopupHeaders4.add(popupExpLabel_uploadBy);
		paymentPopupHeaders4.add(popupExpLabel_uploadOn);
		paymentPopupHeaders4.add(popupExpLabel_releaseBy);
		paymentPopupHeaders4.add(popupExpLabel_ReleaseOn);
		paymentPopupHeaders4.add(popupExpLabel_fileName);
		paymentPopupHeaders4.add(popupExpLabel_fileStatus);

		settlementHeaders = new ArrayList<String>();
		settlementHeaders.add(bnp_headerTab_settlements);
		settlementHeaders.add(Buyer);
		settlementHeaders.add(Supplier);
		settlementHeaders.add(bnp_paymentord_stats_label);
		settlementHeaders.add(DUE_DATE);
		settlementHeaders.add(INVOICE_REFERANCE);
		settlementHeaders.add(CCY);
		settlementHeaders.add(bnp_paymentOrder_avlAmtCallout_totalOrginalAmt_label);
		settlementHeaders.add(bnp_paymentord_inprocess_label);
		settlementHeaders.add(ALREADY_SETTLED);
		settlementHeaders.add(bnp_label_Due_Amount);
		settlementHeaders.add(Invoice_issue_date);
		settlementHeaders.add(BUYER_REF);
		settlementHeaders.add(SUPPLIER_REF);
		settlementHeaders.add(Credit_Note_Effective_Date);
		settlementHeaders.add(Credit_Note_Amount_Utilized);

		transactionheaders = new ArrayList<String>();
		transactionheaders.add(Discount_Reference);
		transactionheaders.add(Batch_Reference);
		transactionheaders.add(PO_Refereance);
		transactionheaders.add(Buyer);
		transactionheaders.add(Supplier);
		transactionheaders.add(bnp_paymentord_stats_label);
		transactionheaders.add(PAYMENT_DATE);
		transactionheaders.add(bnp_paymentord_matDate_label);
		transactionheaders.add(CCY);
		transactionheaders.add(bnp_trans_paymtamnt_label);
		transactionheaders.add(bnp_paymentOrder_netIndCalloutCallout_indicativeChargeAmt_label);
		transactionheaders.add(RATE);
		transactionheaders.add(mbDiscTransReport_tenorDays);
		transactionheaders.add(DiscountInitiatedEmail_appliedMinDiscFee);
		transactionheaders.add(bnp_trans_inddiscamt_label);
		transactionheaders.add(bnp_trans_netindpymtamt_label);
		transactionheaders.add(bnp_trans_confirmeddiscamt_label);
		transactionheaders.add(bnp_trans_confpaymentamt_label);
		
		reportHeaders = new ArrayList<String>();
		reportHeaders.add(File_Name_From_Client);
		reportHeaders.add(File_Received_Date_Time);
		reportHeaders.add(File_Name_Extension);
		reportHeaders.add(File_Status);
		reportHeaders.add(Error_Message);
		reportHeaders.add(PAYMENT_REF_NUMBER);
		reportHeaders.add(Organization_ID);
		reportHeaders.add(Counterparty_Org_ID);
		reportHeaders.add(Payment_Due_Date);
		reportHeaders.add(PAYMENT_STATUS);
		reportHeaders.add(PAYMENT_AMOUNT);
		reportHeaders.add(PAYMENT_AMOUNT_BALANCE);
		reportHeaders.add(Settlement_Amount);
		//reportHeaders.add(Invoice_Settlement_Status);
		reportHeaders.add(Adj_Due_Date);
		reportHeaders.add(Extended_Due_Date);
		reportHeaders.add(Adj_Extnd_Due_Date);
		reportHeaders.add(Type);
		reportHeaders.add(Ref_No);
		reportHeaders.add(Currecy_CCY);
		reportHeaders.add(AMOUNT);
		reportHeaders.add(Issue_Date);
		reportHeaders.add(Due_Date_Original);
		reportHeaders.add(Effective_Date);
		reportHeaders.add(STATUS);
		
		creditNoteHeaders = new ArrayList<String>();
		creditNoteHeaders.add(Credit_Note_Inquiry_Branch);
		creditNoteHeaders.add(Credit_Note_Inquiry_Buyer);
		creditNoteHeaders.add(Credit_Note_Inquiry_Supplier);
		creditNoteHeaders.add(Credit_Note_Inquiry_Currency);
		creditNoteHeaders.add(Credit_Note_Inquiry_Reference);
		creditNoteHeaders.add(Credit_Note_Inquiry_IssueDate);
		creditNoteHeaders.add(Credit_Note_Inquiry_EffectiveDate);
		creditNoteHeaders.add(Credit_Note_Inquiry_Status);
		creditNoteHeaders.add(Credit_Note_Inquiry_OriginalAmount);
		creditNoteHeaders.add(Credit_Note_Inquiry_OutstandingAmount);
		creditNoteHeaders.add(Credit_Note_Inquiry_UtilizedAmount);
		creditNoteHeaders.add(Credit_Note_Inquiry_BlockedAmount);
		
		limitUtilRptHeaders =new ArrayList<String>();//S39801
		limitUtilRptHeaders.add(Credit_Note_Inquiry_Branch);
		limitUtilRptHeaders.add(Limit_Util_Report_clientOrgID);
		limitUtilRptHeaders.add(Limit_Util_Report_custname);
		limitUtilRptHeaders.add(Limit_Util_Report_convertedCcy);
		limitUtilRptHeaders.add(Limit_Util_Report_limitType);
		limitUtilRptHeaders.add(Limit_Util_Report_groupId);
		limitUtilRptHeaders.add(Limit_Util_Report_TPBankID);
		limitUtilRptHeaders.add(Limit_Util_Report_TPBankName);
		limitUtilRptHeaders.add(Limit_Util_Report_counterPartyOrgID);
		limitUtilRptHeaders.add(Limit_Util_Report_counterPartyERPID);
		limitUtilRptHeaders.add(Limit_Util_Report_counterPartyName);
		limitUtilRptHeaders.add(Limit_Util_Report_customerLimitCcy);
		limitUtilRptHeaders.add(Limit_Util_Report_grantedLimit);
		limitUtilRptHeaders.add(Limit_Util_Report_utilLimit);
		limitUtilRptHeaders.add(Limit_Util_Report_availLimit);
		limitUtilRptHeaders.add(Limit_Util_Report_indicativeLimit);
		limitUtilRptHeaders.add(Limit_Util_Report_indicativeConversionRate);
		limitUtilRptHeaders.add(Limit_Util_Report_grantedLimitEurEqu);
		limitUtilRptHeaders.add(Limit_Util_Report_utilLimitEurEqu);
		limitUtilRptHeaders.add(Limit_Util_Report_availLimitEurEqu);
		limitUtilRptHeaders.add(Limit_Util_Report_indEffeAvailLimitEurEqu);
		
		remittanceReportHeader = new ArrayList<String>();
		remittanceReportHeader.add(Credit_Note_Inquiry_Branch);
		remittanceReportHeader.add(Remittance_Report_BranchOrgId);
		remittanceReportHeader.add(Remittance_Report_SupplierOrgId);
		remittanceReportHeader.add(Remittance_Report_ccyCode);
		remittanceReportHeader.add(Remittance_Report_byrERPId);
		remittanceReportHeader.add(Remittance_Report_splrERPId);		
		remittanceReportHeader.add(Remittance_Report_poRef);
		remittanceReportHeader.add(Remittance_Report_dueDate);
		remittanceReportHeader.add(Remittance_Report_pmtStatus);
		remittanceReportHeader.add(Remittance_Report_documentType);
		remittanceReportHeader.add(Remittance_Report_orglAmt);
		remittanceReportHeader.add(Remittance_Report_avlAmt);
		remittanceReportHeader.add(Remittance_Report_invcRef);
		remittanceReportHeader.add(Remittance_Report_issueDate);
		remittanceReportHeader.add(Remittance_Report_dueDate1);
		remittanceReportHeader.add(Remittance_Report_invcAmt);
		remittanceReportHeader.add(Remittance_Report_addtnlRef);
		remittanceReportHeader.add(Remittance_Report_itemNum);
		remittanceReportHeader.add(Remittance_Report_partNum);
		remittanceReportHeader.add(Remittance_Report_itemDscrp);
		remittanceReportHeader.add(Remittance_Report_itemQunt);
		remittanceReportHeader.add(Remittance_Report_unitPrc);
		remittanceReportHeader.add(Remittance_Report_subtotal);
		remittanceReportHeader.add(Remittance_Report_crtNoteRefNum);
		remittanceReportHeader.add(Remittance_Report_utldDate);
		remittanceReportHeader.add(Remittance_Report_dscntRefNum);
		remittanceReportHeader.add(Remittance_Report_utldType);
		remittanceReportHeader.add(Remittance_Report_utldAmt);
		remittanceReportHeader.add(Remittance_Report_dscntRefNum1);
		remittanceReportHeader.add(Remittance_Report_dscntPymtRefNo);
		remittanceReportHeader.add(Remittance_Report_dscntPymtSts);
		remittanceReportHeader.add(Remittance_Report_dscntPymtDate);
		remittanceReportHeader.add(Remittance_Report_dscntDate);
		remittanceReportHeader.add(Remittance_Report_splrAcc);
		remittanceReportHeader.add(Remittance_Report_amtToBeDscnt);
		remittanceReportHeader.add(Remittance_Report_dscntAmt);
		remittanceReportHeader.add(Remittance_Report_totalIndctvRate);
		remittanceReportHeader.add(Remittance_Report_netInctvAmt);
		remittanceReportHeader.add(Remittance_Report_tenor);
		remittanceReportHeader.add(Remittance_Report_dscntPymtAmt);
		remittanceReportHeader.add(Remittance_Report_paidAmt);
		remittanceReportHeader.add(Remittance_Report_maturityPymtRef);
		remittanceReportHeader.add(Remittance_Report_maturityPymtSts);
		remittanceReportHeader.add(Remittance_Report_splrAccNo);
		remittanceReportHeader.add(Remittance_Report_maturityPymtDt);
		remittanceReportHeader.add(Remittance_Report_maturityPymtAmt);
		remittanceReportHeader.add(Remittance_Report_paidAmt1);
		
		//Discount Transaction Report Export		
		discTransRptHeaders =new ArrayList<String>(); 
		discTransRptHeaders.add(Discount_Transaction_Report_BranchId);
		discTransRptHeaders.add(Discount_Transaction_Report_BuyerId);
		discTransRptHeaders.add(Discount_Transaction_Report_SupplierId);
		discTransRptHeaders.add(Discount_Transaction_Report_ConvertedCcy);
		discTransRptHeaders.add(Discount_Transaction_Report_Reference_No);
		discTransRptHeaders.add(Discount_Transaction_Report_Discount_Date);
		discTransRptHeaders.add(Discount_Transaction_Report_Discount_MaturityDate);
		discTransRptHeaders.add(Discount_Transaction_Report_Discount_Status);
		discTransRptHeaders.add(Discount_Transaction_Report_Tenor);
		discTransRptHeaders.add(Discount_Transaction_Report_OriginalAmt);
		discTransRptHeaders.add(Discount_Transaction_Report_FinancedAmt);
		discTransRptHeaders.add(Discount_Transaction_Report_DscountAmt);
		discTransRptHeaders.add(Discount_Transaction_Report_Indicative_NetAmt);
		discTransRptHeaders.add(Discount_Transaction_Report_Customer_ReferenceNo);
		discTransRptHeaders.add(Discount_Transaction_Report_Indicative_DiscountRate);
		discTransRptHeaders.add(Discount_Transaction_Report_Indicative_ChargeAmt);
		discTransRptHeaders.add(Discount_Transaction_Report_Original_MaturityDate);
		discTransRptHeaders.add(Discount_Transaction_Report_AdjustmentDays);
		
		settlementDueHeaders = new ArrayList<String>();
		settlementDueHeaders.add(CLIENT_ORG_NAME);
		settlementDueHeaders.add(COUNTERPARTY_ORG_NAME);
		settlementDueHeaders.add(BUYER_ERP_ID);
		settlementDueHeaders.add(SUPPLIER_ERP_ID);
		settlementDueHeaders.add(INVOICE_REF_NUMBER);
		settlementDueHeaders.add(ORIGINAL_DUE_DATE);
		settlementDueHeaders.add(ADJ_DUE_DATE);
		settlementDueHeaders.add(CCY_CODE);
		settlementDueHeaders.add(INVOICE_AMT);
		settlementDueHeaders.add(ORIGINAL_SETTLE_DUE_AMT);
		
		preSettlementForCastHeaders = new ArrayList<String>();
		preSettlementForCastHeaders.add(CLIENT_ORG_NAME);
		preSettlementForCastHeaders.add(COUNTERPARTY_ORG_NAME);
		preSettlementForCastHeaders.add(DIS_REF_NO);
		preSettlementForCastHeaders.add(DISC_DATE);
		preSettlementForCastHeaders.add(ORIGINAL_DUE_DATE);	
		preSettlementForCastHeaders.add(ADJ_DUE_DATE);	
		preSettlementForCastHeaders.add(DISC_TENURE);	
		preSettlementForCastHeaders.add(CCY_CODE);	
		preSettlementForCastHeaders.add(FINANCE_AMT);
		preSettlementForCastHeaders.add(AVLBLE_AMT);	
		preSettlementForCastHeaders.add(RATE_CHARGE_TYPE);	
		preSettlementForCastHeaders.add(RATE_APPLIED);	
		preSettlementForCastHeaders.add(REVISED_TENURE);	
		preSettlementForCastHeaders.add(IND_REVISED_RATE);
		preSettlementForCastHeaders.add(REVISED_DISC_AMT);
		
		viewScheduledReportHeaders = new ArrayList<String>();		
		viewScheduledReportHeaders.add(View_Scheduled_Report_SchRepID);	
		viewScheduledReportHeaders.add(View_Scheduled_Report_RepName);
		viewScheduledReportHeaders.add(View_Scheduled_Report_RepFileName);	
		viewScheduledReportHeaders.add(View_Scheduled_Report_OrgID);
		viewScheduledReportHeaders.add(View_Scheduled_Report_Frequency);
		viewScheduledReportHeaders.add(View_Scheduled_Report_LastGenerated);
		viewScheduledReportHeaders.add(View_Scheduled_Report_LastViewed);
		
		agingReportHeaders = new ArrayList<String>();
		
		agingReportHeaders.add(Aging_Report_BuyerOrgID);
		agingReportHeaders.add(Aging_Report_SupplierOrgID);	
		agingReportHeaders.add(Aging_Report_BuyerERPID);
		agingReportHeaders.add(Aging_Report_SupplierERPID);
		agingReportHeaders.add(Aging_Report_TimePeriod);			
		agingReportHeaders.add(Aging_Report_Ccy);
		agingReportHeaders.add(Aging_Report_PoReference);
		agingReportHeaders.add(Aging_Report_DocWithStatus);
		agingReportHeaders.add(Aging_Report_MaturityDate);
		agingReportHeaders.add(Aging_Report_FinancingBank);
		agingReportHeaders.add(Aging_Report_PayableAmount);
		agingReportHeaders.add(Aging_Report_OutstandingAmount);
		agingReportHeaders.add(Aging_Report_InvoiceRefNum);
		agingReportHeaders.add(Aging_Report_IssueDate);
		agingReportHeaders.add(Aging_Report_AdditionalRef);
		agingReportHeaders.add(Aging_Report_InvoiceAmt);
		agingReportHeaders.add(Aging_Report_CreditNoteRefNum);
		agingReportHeaders.add(Aging_Report_UtilizedDate);
		agingReportHeaders.add(Aging_Report_CreditNoteOriginalAmt);
		agingReportHeaders.add(Aging_Report_UtilizedType);
		agingReportHeaders.add(Aging_Report_UtilizedAmt);
		
		
		
		
		
			 				
		txnDiscDetailsPopupExportHeaders1 = new ArrayList<String>();
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_DISREFNO);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_DISCSTATUS);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_BUYER);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_SUPPLIER);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_PYMTREFNO);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_BATCHREFNO);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_ADDREFNO);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_CUSTREFNO);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_BENERECONREFVALUE);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_PRIORDISREFNO);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_FEE_CCY);//S067
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_ORGAMT);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_SUPPLIERACCTNO);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_CREDITNOTEAMOUNT);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_PYMTAMT);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_CONFIRMEDINTERESTRATE);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_INDCHARGES_CHARGESCCY);//S067
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_CONFCHARGEAMT);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_CONFIRMEDINTERESTAMT);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_CONFIRMEDNETAMOUNT);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_DOCTYPE);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_PYMTDUEDATE);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_OVERDUEDISCRATE);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_DISCAVLBLEAMT);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_ISROLOVRCRTD);
		//txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_MINFEE_CCY);//S067
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_ISMINDISCFEEAPPLIED);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_CREATEDDATE);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_DISCPYMTSTATUS);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_INDDISCRATE);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_INDCHARGEAMT);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_INDDISCAMT);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_INDNETAMT);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_MINFINANCIALAMT);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_BUYERMARGINACC);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_BANKMARGINACCOUNT);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_DUEDATE);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_ISROLOVRREQ);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_DISCTENURE);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_RATECHARGETYPE);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_BILLTYPE);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_REMARKS);
		//Sprint 7 - S1411004  Static header interchange start
		
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_INDBASERATEFLOORED);
		txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_MAINDETAILS_CONFIRMEDBASERATEFLOORED);
		//Sprint 7 - S1411004  Static header interchange end
		
		txnDiscDetailsPopupExportHeaders2 = new ArrayList<String>();
		txnDiscDetailsPopupExportHeaders2.add(TXN_DISCOUNTDETAILSPOPUP_INDCHARGES_CHARGECODE);
		txnDiscDetailsPopupExportHeaders2.add(TXN_DISCOUNTDETAILSPOPUP_INDCHARGES_DESCRIPTION);
		txnDiscDetailsPopupExportHeaders2.add(TXN_DISCOUNTDETAILSPOPUP_INDCHARGES_CHARGECCY);
		//txnDiscDetailsPopupExportHeaders1.add(TXN_DISCOUNTDETAILSPOPUP_INDCHARGES_CHARGESCCY);//S067
		txnDiscDetailsPopupExportHeaders2.add(TXN_DISCOUNTDETAILSPOPUP_INDCHARGES_CHARGEAMOUNT);
		txnDiscDetailsPopupExportHeaders2.add(TXN_DISCOUNTDETAILSPOPUP_INDCHARGES_CODEIDENTIFIER);
		//txnDiscDetailsPopupExportHeaders2.add(TXN_DISCOUNTDETAILSPOPUP_INDCHARGES_DISCCCY);//S067
		txnDiscDetailsPopupExportHeaders2.add(TXN_DISCOUNTDETAILSPOPUP_INDCHARGES_AMOUNTTOBEDISCOUNTED);
		txnDiscDetailsPopupExportHeaders2.add(TXN_DISCOUNTDETAILSPOPUP_INDCHARGES_CHARGEPERCENTAGE);
		txnDiscDetailsPopupExportHeaders2.add(TXN_DISCOUNTDETAILSPOPUP_INDCHARGES_CONFIRMEDCHARGEAMOUNT);
		
		txnDiscDetailsPopupExportHeaders3 = new ArrayList<String>();
		txnDiscDetailsPopupExportHeaders3.add(TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_COMMSTARTDT);
		txnDiscDetailsPopupExportHeaders3.add(TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_COMMENDDATE);
		txnDiscDetailsPopupExportHeaders3.add(TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_COMMFEEFREQ);
		txnDiscDetailsPopupExportHeaders3.add(TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_COMMFEEPERIOD);
		txnDiscDetailsPopupExportHeaders3.add(TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_TOTCOMMFEEAMT);
		

		txnDiscDetailsPopupExportHeaders4 = new ArrayList<String>();
		txnDiscDetailsPopupExportHeaders4.add(TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_FROMDATE);
		txnDiscDetailsPopupExportHeaders4.add(TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_TODATE);
		txnDiscDetailsPopupExportHeaders4.add(TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_PERIOD);
		txnDiscDetailsPopupExportHeaders4.add(TXN_DISCOUNTDETAILSPOPUP_FEE_CCY);//S067
		txnDiscDetailsPopupExportHeaders4.add(TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_AMOUNT);
		txnDiscDetailsPopupExportHeaders4.add(TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_FEEPERCENTAGE);
		txnDiscDetailsPopupExportHeaders4.add(TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_OUTSTANDINGAMOUNT);
		txnDiscDetailsPopupExportHeaders4.add(TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_FEEPAYDUEDATE);
		txnDiscDetailsPopupExportHeaders4.add(TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_PAYMENTSTATUS);
		txnDiscDetailsPopupExportHeaders4.add(TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_COMMFEEPAIDDT);
		txnDiscDetailsPopupExportHeaders4.add(TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_PAIDAMT);
		txnDiscDetailsPopupExportHeaders4.add(TXN_DISCOUNTDETAILSPOPUP_COMMITMENTFEE_COMMFEEDEBTREF);

		txnDiscDetailsPopupExportHeaders5 = new ArrayList<String>();
		txnDiscDetailsPopupExportHeaders5.add(TXN_DISCOUNTDETAILSPOPUP_PODETAILS_REFERENCENO);
		txnDiscDetailsPopupExportHeaders5.add(TXN_DISCOUNTDETAILSPOPUP_PODETAILS_COMMITMENTRELEASEDATE);
		txnDiscDetailsPopupExportHeaders5.add(TXN_DISCOUNTDETAILSPOPUP_PODETAILS_PAYMENTDUEDATE);
		txnDiscDetailsPopupExportHeaders5.add(TXN_DISCOUNTDETAILSPOPUP_FEE_CCY);//S067
		txnDiscDetailsPopupExportHeaders5.add(TXN_DISCOUNTDETAILSPOPUP_PODETAILS_PAYMENTAMOUNT);
		txnDiscDetailsPopupExportHeaders5.add(TXN_DISCOUNTDETAILSPOPUP_PODETAILS_UPDATEDPAYMENTAMOUNT);

		txnDiscDetailsPopupExportHeaders6 = new ArrayList<String>();
		txnDiscDetailsPopupExportHeaders6.add(TXN_DISCOUNTDETAILSPOPUP_INVOICEDETAILS_INVOICENO);
		txnDiscDetailsPopupExportHeaders6.add(TXN_DISCOUNTDETAILSPOPUP_INVOICEDETAILS_ISSUEDATE);
		txnDiscDetailsPopupExportHeaders6.add(TXN_DISCOUNTDETAILSPOPUP_INVOICEDETAILS_DUEDATE);
		txnDiscDetailsPopupExportHeaders6.add(TXN_DISCOUNTDETAILSPOPUP_FEE_CCY);//S067
		txnDiscDetailsPopupExportHeaders6.add(TXN_DISCOUNTDETAILSPOPUP_INVOICEDETAILS_ORIGINALAMOUNT);
		txnDiscDetailsPopupExportHeaders6.add(TXN_DISCOUNTDETAILSPOPUP_CNOTE_CCY);//S067
		txnDiscDetailsPopupExportHeaders6.add(TXN_DISCOUNTDETAILSPOPUP_INVOICEDETAILS_CNUTILIZEDAMOUNT);
		txnDiscDetailsPopupExportHeaders6.add(TXN_DISCOUNTDETAILSPOPUP_INVOICEDETAILS_BUYERREF);
		txnDiscDetailsPopupExportHeaders6.add(TXN_DISCOUNTDETAILSPOPUP_INVOICEDETAILS_SELLERREF);
		txnDiscDetailsPopupExportHeaders6.add(TXN_DISCOUNTDETAILSPOPUP_INVOICEDETAILS_UPDATEDAMOUNT);

		txnDiscDetailsPopupExportHeaders7 = new ArrayList<String>();
		txnDiscDetailsPopupExportHeaders7.add(TXN_DISCOUNTDETAILSPOPUP_CREDITNOTESDETAILS_CNREFNO);
		txnDiscDetailsPopupExportHeaders7.add(TXN_DISCOUNTDETAILSPOPUP_CREDITNOTESDETAILS_ISSUEDATE);
		txnDiscDetailsPopupExportHeaders7.add(TXN_DISCOUNTDETAILSPOPUP_CREDITNOTESDETAILS_EFFECTIVEDATE);
		txnDiscDetailsPopupExportHeaders7.add(TXN_DISCOUNTDETAILSPOPUP_CREDITNOTESDETAILS_TYPE);
		txnDiscDetailsPopupExportHeaders7.add(TXN_DISCOUNTDETAILSPOPUP_FEE_CCY);//S067
		txnDiscDetailsPopupExportHeaders7.add(TXN_DISCOUNTDETAILSPOPUP_CREDITNOTESDETAILS_AMOUNT);
		txnDiscDetailsPopupExportHeaders7.add(TXN_DISCOUNTDETAILSPOPUP_CREDITNOTESDETAILS_STATUS);
		txnDiscDetailsPopupExportHeaders7.add(TXN_DISCOUNTDETAILSPOPUP_CREDITNOTESDETAILS_UTILREFNO);
		
		availablePaymentHeaders = new ArrayList<String>();
		availablePaymentHeaders.add(CLIENT_ORG_NAME);	
		availablePaymentHeaders.add(COUNTERPARTY_ORG_NAME);	
		availablePaymentHeaders.add(CCY_CODE);	
		availablePaymentHeaders.add(BUYER_ERP_ID);
		availablePaymentHeaders.add(SUPPLIER_ERP_ID);
		availablePaymentHeaders.add(DISCOUNT_REF_NO);	
		availablePaymentHeaders.add(INVOICE_NUMBER);
		//availablePaymentHeaders.add(PYMT_INVOICE_ISSUE_DATE);
		availablePaymentHeaders.add(UPLOAD_DATE);
		availablePaymentHeaders.add(DISCOUNT_DATE);
		availablePaymentHeaders.add(CONFIRMED_DATE);
		availablePaymentHeaders.add(ORIGINAL_MATURITY_DATE);
		availablePaymentHeaders.add(MATURITY_DATE);
		availablePaymentHeaders.add(TENOR_DAYS);
		availablePaymentHeaders.add(ORIGINAL_INVOICE_AMOUNT);
		availablePaymentHeaders.add(INTEREST_RATE);
		availablePaymentHeaders.add(EURIBOR);
		availablePaymentHeaders.add(MARGIN);
		availablePaymentHeaders.add(INTEREST_AMOUNT);
		availablePaymentHeaders.add(NET_DISCOUNT_AMOUNT);
		availablePaymentHeaders.add(PYMT_STATUS);


		recievedPaymentHeaders = new ArrayList<String>();
		recievedPaymentHeaders.add(CLIENT_ORG_NAME);	
		recievedPaymentHeaders.add(COUNTERPARTY_ORG_NAME);	
		recievedPaymentHeaders.add(CCY_CODE);	
		recievedPaymentHeaders.add(BUYER_ERP_ID);
		recievedPaymentHeaders.add(SUPPLIER_ERP_ID);
		recievedPaymentHeaders.add(DISCOUNT_REF_NO);	
		recievedPaymentHeaders.add(INVOICE_NUMBER);
		//recievedPaymentHeaders.add(PYMT_INVOICE_ISSUE_DATE);
		recievedPaymentHeaders.add(UPLOAD_DATE);
		recievedPaymentHeaders.add(DISCOUNT_DATE);
		recievedPaymentHeaders.add(CONFIRMED_DATE);
		recievedPaymentHeaders.add(ORIGINAL_MATURITY_DATE);
		recievedPaymentHeaders.add(MATURITY_DATE);
		recievedPaymentHeaders.add(TENOR_DAYS);
		recievedPaymentHeaders.add(ORIGINAL_INVOICE_AMOUNT);
		recievedPaymentHeaders.add(INTEREST_RATE);
		recievedPaymentHeaders.add(EURIBOR);
		recievedPaymentHeaders.add(MARGIN);
		recievedPaymentHeaders.add(INTEREST_AMOUNT);
		recievedPaymentHeaders.add(NET_DISCOUNT_AMOUNT);
		recievedPaymentHeaders.add(PYMT_STATUS);
		recievedPaymentHeaders.add(BENEFICIARY_TYPE);
		recievedPaymentHeaders.add(BENEFICIARY_VALUE);


	}
	
	/**
	 * @param exportVO
	 * @param prop
	 * @return StringBuilder
	 * @Description get Header Content for CVS, XLS and PDF
	 */
	public static StringBuilder getHeaderForCVS(ExportRequestVO exportVO, Properties prop) {
		StringBuilder headerBuilder = new StringBuilder();
		
		if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(PAYMENT_ORDER_PAGE)){
			for(String str: paymentHeaders){
				headerBuilder.append(getStringValue(prop.getProperty(str), exportVO));	
			}
		}
		
		
		if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(TRANSACTION_PAGE)){
			for(String str: transactionheaders){
				headerBuilder.append(getStringValue(prop.getProperty(str), exportVO));	
			}
		}
		
		
		if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(SETTLEMENT_PAGE)){
			for(String str: settlementHeaders){
				headerBuilder.append(getStringValue(prop.getProperty(str), exportVO));
			}
		}
		
		if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(REPORTS_PAGE)){
			for(String str: reportHeaders){
				headerBuilder.append(getStringValue(prop.getProperty(str), exportVO));
			}
		}
		
		if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(CREDIT_NOTE_REPORT)){
			for(String str: creditNoteHeaders){
				headerBuilder.append(getStringValue(prop.getProperty(str), exportVO));
			}
		}
		
		if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(LIMIT_UTIL_REPORT)){
			for(String str: limitUtilRptHeaders){
				if(prop.getProperty(str).contains(ccyStr) && !"NOT REQUIRED".equalsIgnoreCase(exportVO.getCurrencyCode())){
					str = prop.getProperty(str).replace(ccyStr, exportVO.getCurrencyCode());
				headerBuilder.append(getStringValue(str, exportVO));
				}else if(!prop.getProperty(str).contains(ccyStr)){
					headerBuilder.append(getStringValue(prop.getProperty(str), exportVO));
				}
				
			}
		}
		if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(DISC_TRANS_REPORT)){
			for(String str: discTransRptHeaders){
				headerBuilder.append(getStringValue(prop.getProperty(str), exportVO));
			}
		}
		 if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(SETTLEMENT_DUE_REPORT) && exportVO.getReportType().equalsIgnoreCase(SETTLEMENT_DUE_REPORT_TYPE)){
			for(String str: settlementDueHeaders){
				headerBuilder.append(getStringValue(prop.getProperty(str), exportVO));
			}
		} if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(SETTLEMENT_DUE_REPORT) &&  exportVO.getReportType().equalsIgnoreCase(SETTLEMENT_DUE_PRESETTLE_REPORT_TYPE)){
			for(String str: preSettlementForCastHeaders){
				headerBuilder.append(getStringValue(prop.getProperty(str), exportVO));
			}
		}
			if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(PAYMENT_REPORT) && exportVO.getReportType().equalsIgnoreCase(AVAILABLE_PAYMENT_REPORT_TYPE)){
				for(String str: availablePaymentHeaders){
					headerBuilder.append(getStringValue(prop.getProperty(str), exportVO));
				}
			}if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(PAYMENT_REPORT) &&  exportVO.getReportType().equalsIgnoreCase(RECIEVED_PAYMENT_REPORT_TYPE)){
				for(String str: recievedPaymentHeaders){
					headerBuilder.append(getStringValue(prop.getProperty(str), exportVO));
				}
			
			}	
		if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(VIEW_SCHEDULED_REPORT)){
			for(String str: viewScheduledReportHeaders){
				headerBuilder.append(getStringValue(prop.getProperty(str), exportVO));
			}
		}

		if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(AGING_REPORT)){
			for(String str: agingReportHeaders){
				headerBuilder.append(getStringValue(prop.getProperty(str), exportVO));
			}
		}
	
		
		if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(REMITTANCE_REPORT)){
			for(String str: remittanceReportHeader){
				headerBuilder.append(getStringValue(prop.getProperty(str), exportVO));
			}
		}

	

		return headerBuilder;
	}
	
	
	/**
	 * @param input
	 * @param exportVO
	 * @return String
	 * @Description Get the Value with corresponding Delimiter
	 */
	private static String getStringValue(String input,ExportRequestVO exportVO ){
		  StringBuilder instance = new StringBuilder();
		  input = replaceNullWithEmpty(input);
		  if(input!= null){
			  if (ExportConstants.CSV_FORMAT.equalsIgnoreCase(exportVO.getExportType())){
				input =input.replace(ExportConstants.COMMA_DELIMITER,ExportConstants.EMPTY);
			  }
			  instance.append(input + getExportDelimiterValue(exportVO.getExportType())); 
		  }
		return instance.toString();
	}
	
	/**
	 * @param input
	 * @return String
	 * @Description Replace Null with Empty
	 */
	private static String replaceNullWithEmpty(Object input) {
		if(input == null){
			input = "";
		}
		return input.toString().replaceAll(ExportConstants.NULL_STR, ExportConstants.EMPTY);
	}
	
/**
 * @param exportVO
 * @return Properties
 * @throws BNPApplicationException 
 * @Description get property file of Preferred Language 
 */
public static Properties getProperties(ExportRequestVO exportVO) throws BNPApplicationException {
		
		String propertyLocation = "";
		String language = exportVO.getLangPreferance();
		String[] locale = language.split("_");
		Locale lc = new Locale(locale[0], locale[1]);
		ResourceBundle resourceBundle = null;
		Properties properties = new Properties();
		try {
			if (propertyLocation.length() == 0
					|| ("default").equals(propertyLocation)) {
				propertyLocation = BNPConstants.LOCALE_PROPERTY_FILE_PATH;
			}
			resourceBundle = ResourceBundle.getBundle(propertyLocation, lc);
			properties = convertResourceBundleToProperties(resourceBundle,
					properties);

			log.debug("Properties loaded.." + properties.toString());
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new BNPApplicationException(e.getMessage());
		}
		
		return properties;
		
		}




/**
 * @Name : convertResourceBundleToProperties
 * @Description : This method is used to iterate resource bundle and make
 *              property object
 * @param resource
 * @return Properties contains key,value pair
 */
private static Properties convertResourceBundleToProperties(
		ResourceBundle resource, Properties properties) {
	Enumeration<?> keys = resource.getKeys();
	while (keys.hasMoreElements()) {
		String key = (String) keys.nextElement();
		properties.put(key, resource.getString(key));
	}
	return properties;
}


/**
 * @param exportType
 * @return String
 * @Description Get Delimiter for Corresponding File
 */
private static String getExportDelimiterValue(String exportType) {
	if (ExportConstants.CSV_FORMAT.equalsIgnoreCase(exportType)){
		return ExportConstants.COMMA_DELIMITER;
	}else {
		 return ExportConstants.EMPTY;
	}
}




/**
 * @param exportVO
 * @param prop
 * @return ArrayList<String>
 * @Description get Header for String
 */
public static ArrayList<String> getHeaderForXLS(ExportRequestVO exportVO, Properties prop) {
	ArrayList<String> header = new ArrayList<String>();
	if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(PAYMENT_ORDER_PAGE)){
		for(String str: paymentHeaders){
			header.add(getStringValue(prop.getProperty(str), exportVO));	
		}
	}else if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(TRANSACTION_PAGE)){
		for(String str: transactionheaders){
			header.add(getStringValue(prop.getProperty(str), exportVO));		
		}
	}else if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(SETTLEMENT_PAGE)){
		for(String str: settlementHeaders){
			header.add(getStringValue(prop.getProperty(str), exportVO));	
		}
	}else if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(REPORTS_PAGE)){
		for(String str: reportHeaders){
			header.add(getStringValue(prop.getProperty(str), exportVO));	
		}
	}else if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(CREDIT_NOTE_REPORT)){
		for(String str: creditNoteHeaders){
			header.add(getStringValue(prop.getProperty(str), exportVO));	
		}
	}else if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(LIMIT_UTIL_REPORT)){//S39801 : limit util report
		for(String str: limitUtilRptHeaders){
			if(prop.getProperty(str).contains(ccyStr) && !"NOT REQUIRED".equalsIgnoreCase(exportVO.getCurrencyCode())){
				str = prop.getProperty(str).replace(ccyStr, exportVO.getCurrencyCode());
			header.add(getStringValue(str, exportVO));	
			}else if(!prop.getProperty(str).contains(ccyStr)){
				header.add(getStringValue(prop.getProperty(str), exportVO));
			}
		}
	}else if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(DISC_TRANS_REPORT)){
			for(String str: discTransRptHeaders){
				header.add(getStringValue(prop.getProperty(str), exportVO));	
			}	
	}else if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(SETTLEMENT_DUE_REPORT) && exportVO.getReportType().equalsIgnoreCase(SETTLEMENT_DUE_REPORT_TYPE)){
		for(String str: settlementDueHeaders){
			header.add(getStringValue(prop.getProperty(str), exportVO));
		}
	}else if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(SETTLEMENT_DUE_REPORT) &&  exportVO.getReportType().equalsIgnoreCase(SETTLEMENT_DUE_PRESETTLE_REPORT_TYPE)){
		for(String str: preSettlementForCastHeaders){
			header.add(getStringValue(prop.getProperty(str), exportVO));
		}
	}else if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(VIEW_SCHEDULED_REPORT)){
		for(String str: viewScheduledReportHeaders){
			header.add(getStringValue(prop.getProperty(str), exportVO));	
		}
	}else if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(PAYMENT_REPORT) && exportVO.getReportType().equalsIgnoreCase(AVAILABLE_PAYMENT_REPORT_TYPE)){
		for(String str: availablePaymentHeaders){
			header.add(getStringValue(prop.getProperty(str), exportVO));
		}
	}else if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(PAYMENT_REPORT) &&  exportVO.getReportType().equalsIgnoreCase(RECIEVED_PAYMENT_REPORT_TYPE)){
		for(String str: recievedPaymentHeaders){
			header.add(getStringValue(prop.getProperty(str), exportVO));
		}

	}else if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(AGING_REPORT)){
		for(String str: agingReportHeaders){
			header.add(getStringValue(prop.getProperty(str), exportVO));	
		}	
	}else if(null != exportVO && exportVO.getPageInfo().equalsIgnoreCase(REMITTANCE_REPORT)){
		for(String str: remittanceReportHeader){
			header.add(getStringValue(prop.getProperty(str), exportVO));
		}
	}
	
	
	return header;


}
	
}
