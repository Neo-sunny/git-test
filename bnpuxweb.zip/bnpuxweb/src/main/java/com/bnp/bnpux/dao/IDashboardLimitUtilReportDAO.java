/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   15-JUL-2017
 * 
 * Purpose:      SCF Attach Upload DAO
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 15-JUL-2017				Divyashri Subramaniam						To call Mybatis Query for Attach SCF Upload Functionality
************************************************************************************************************************************************************/
package com.bnp.bnpux.dao;

import java.util.List;
import java.util.Map;

import com.bnp.bnpux.common.vo.DashSettlementDueVO;
import com.bnp.bnpux.common.vo.DashbrdPendingActionResultVO;
import com.bnp.bnpux.vo.requestVO.DashPendingActRequestVO;
import com.bnp.bnpux.vo.requestVO.DashSettelmentDueRequestVO;
import com.bnp.bnpux.vo.requestVO.LimitUtilReportRequestVO;
import com.bnp.bnpux.vo.requestVO.RequestParamVO;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.bnp.scm.services.discounting.vo.LimitUtilReportTreeVO;

public interface IDashboardLimitUtilReportDAO {

	List<NameValueVO> getDashboardLimitOrgList(LimitUtilReportRequestVO limitUtilReportRequestVO);
	
	List<NameValueVO> getOrgDtlsBA(LimitUtilReportRequestVO limitUtilReportRequestVO);
	
	List<NameValueVO> getBranchDtls(LimitUtilReportRequestVO limitUtilReportRequestVO);
	
	List<DashSettlementDueVO> getSettlementDueDetails(DashSettelmentDueRequestVO dashSettelmentDueRequestVO);
	
	List<LimitUtilReportTreeVO> getGroupLimitDetails(Map<String, String> param);
	
	List<LimitUtilReportTreeVO> getTPLimitDetails(Map<String, String> param);
	
	List<DashbrdPendingActionResultVO> getPendingActionDetails(DashPendingActRequestVO dashPendingActRequestVO);
	
	List<NameValueVO> getRequestedParamMapping(RequestParamVO requestParamVO);
}
