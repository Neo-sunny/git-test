/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  21 June 2017
 * 
 * Purpose:      Credit Note Inquiry Report Summary VO
 * 
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 21 June 2017       Ratna Gokhale, Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/

package com.bnp.bnpux.vo.requestVO;

import java.util.List;

import com.bnp.bnpux.common.vo.AgingRptDetails;
import com.bnp.bnpux.common.vo.AgingRptSummaryList;

public class AgingRequestVO{	
    
	private String userId;
	
	private String userType;
	
	private String buyerOrgId;
	
	private String branch;
	
	private String suppOrgId;
	
	private String currencyCd;
	
	private String viewType;
	
	private String errorMsg;
	
	private String duePeriod;
	
	private String dueDays;
	
	private String discType;
	
	private int recFrom;
	
	private int recTo;
	
	private String exportType;
	
	private String poRefNo;
	
	private List<AgingRptSummaryList> agingRptSummaryList;
	
	private List<AgingRptSummaryList> agingRptList;	
	
	private List<AgingRptDetails> agingRptDetailsList;
	
	private List<AgingRptDetails> agingRptPODetailsList;
	
	private List<AgingRptDetails> agingRptInvDetailsList;
	
	private List<AgingRptDetails> agingRptCNDetailsList;
	
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the userType
	 */
	public String getUserType() {
		return userType;
	}

	/**
	 * @param userType the userType to set
	 */
	public void setUserType(String userType) {
		this.userType = userType;
	}

	/**
	 * @return the buyerOrgId
	 */
	public String getBuyerOrgId() {
		return buyerOrgId;
	}

	/**
	 * @param buyerOrgId the buyerOrgId to set
	 */
	public void setBuyerOrgId(String buyerOrgId) {
		this.buyerOrgId = buyerOrgId;
	}

	/**
	 * @return the suppOrgId
	 */
	public String getSuppOrgId() {
		return suppOrgId;
	}

	/**
	 * @param suppOrgId the suppOrgId to set
	 */
	public void setSuppOrgId(String suppOrgId) {
		this.suppOrgId = suppOrgId;
	}
	
	/**
	 * @return the viewType
	 */
	public String getViewType() {
		return viewType;
	}

	/**
	 * @param viewType the viewType to set
	 */
	public void setViewType(String viewType) {
		this.viewType = viewType;
	}

	/**
	 * @return the errorMsg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}

	/**
	 * @param errorMsg the errorMsg to set
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	/**
	 * @return the agingRptSummaryList
	 */
	public List<AgingRptSummaryList> getAgingRptSummaryList() {
		return agingRptSummaryList;
	}

	/**
	 * @param agingRptSummaryList the agingRptSummaryList to set
	 */
	public void setAgingRptSummaryList(List<AgingRptSummaryList> agingRptSummaryList) {
		this.agingRptSummaryList = agingRptSummaryList;
	}

	/**
	 * @return the agingRptDetailsList
	 */
	public List<AgingRptDetails> getAgingRptDetailsList() {
		return agingRptDetailsList;
	}

	/**
	 * @param agingRptDetailsList the agingRptDetailsList to set
	 */
	public void setAgingRptDetailsList(List<AgingRptDetails> agingRptDetailsList) {
		this.agingRptDetailsList = agingRptDetailsList;
	}

	/**
	 * @return the agingRptPODetailsList
	 */
	public List<AgingRptDetails> getAgingRptPODetailsList() {
		return agingRptPODetailsList;
	}

	/**
	 * @param agingRptPODetailsList the agingRptPODetailsList to set
	 */
	public void setAgingRptPODetailsList(List<AgingRptDetails> agingRptPODetailsList) {
		this.agingRptPODetailsList = agingRptPODetailsList;
	}

	/**
	 * @return the agingRptInvDetailsList
	 */
	public List<AgingRptDetails> getAgingRptInvDetailsList() {
		return agingRptInvDetailsList;
	}

	/**
	 * @param agingRptInvDetailsList the agingRptInvDetailsList to set
	 */
	public void setAgingRptInvDetailsList(
			List<AgingRptDetails> agingRptInvDetailsList) {
		this.agingRptInvDetailsList = agingRptInvDetailsList;
	}

	/**
	 * @return the agingRptCNDetailsList
	 */
	public List<AgingRptDetails> getAgingRptCNDetailsList() {
		return agingRptCNDetailsList;
	}

	/**
	 * @param agingRptCNDetailsList the agingRptCNDetailsList to set
	 */
	public void setAgingRptCNDetailsList(List<AgingRptDetails> agingRptCNDetailsList) {
		this.agingRptCNDetailsList = agingRptCNDetailsList;
	}

	/**
	 * @return the agingRptList
	 */
	public List<AgingRptSummaryList> getAgingRptList() {
		return agingRptList;
	}

	/**
	 * @param agingRptList the agingRptList to set
	 */
	public void setAgingRptList(List<AgingRptSummaryList> agingRptList) {
		this.agingRptList = agingRptList;
	}

	/**
	 * @return the branch
	 */
	public String getBranch() {
		return branch;
	}

	/**
	 * @param branch the branch to set
	 */
	public void setBranch(String branch) {
		this.branch = branch;
	}

	/**
	 * @return the currencyCd
	 */
	public String getCurrencyCd() {
		return currencyCd;
	}

	/**
	 * @param currencyCd the currencyCd to set
	 */
	public void setCurrencyCd(String currencyCd) {
		this.currencyCd = currencyCd;
	}

	/**
	 * @return the duePeriod
	 */
	public String getDuePeriod() {
		return duePeriod;
	}

	/**
	 * @param duePeriod the duePeriod to set
	 */
	public void setDuePeriod(String duePeriod) {
		this.duePeriod = duePeriod;
	}

	/**
	 * @return the dueDays
	 */
	public String getDueDays() {
		return dueDays;
	}

	/**
	 * @param dueDays the dueDays to set
	 */
	public void setDueDays(String dueDays) {
		this.dueDays = dueDays;
	}

	/**
	 * @return the discType
	 */
	public String getDiscType() {
		return discType;
	}

	/**
	 * @param discType the discType to set
	 */
	public void setDiscType(String discType) {
		this.discType = discType;
	}

	/**
	 * @return the recFrom
	 */
	public int getRecFrom() {
		return recFrom;
	}

	/**
	 * @param recFrom the recFrom to set
	 */
	public void setRecFrom(int recFrom) {
		this.recFrom = recFrom;
	}

	/**
	 * @return the recTo
	 */
	public int getRecTo() {
		return recTo;
	}

	/**
	 * @param recTo the recTo to set
	 */
	public void setRecTo(int recTo) {
		this.recTo = recTo;
	}

	/**
	 * @return the exportType
	 */
	public String getExportType() {
		return exportType;
	}

	/**
	 * @param exportType the exportType to set
	 */
	public void setExportType(String exportType) {
		this.exportType = exportType;
	}

	/**
	 * @return the poRefNo
	 */
	public String getPoRefNo() {
		return poRefNo;
	}

	/**
	 * @param poRefNo the poRefNo to set
	 */
	public void setPoRefNo(String poRefNo) {
		this.poRefNo = poRefNo;
	}

	

}

