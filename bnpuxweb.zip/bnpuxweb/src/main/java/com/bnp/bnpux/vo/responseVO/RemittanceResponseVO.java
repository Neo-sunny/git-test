package com.bnp.bnpux.vo.responseVO;

import java.math.BigDecimal;
import java.util.Date;

public class RemittanceResponseVO {
	
	private String customerRef;
	private String additionalRef;
	private Date dueDate;
	private Date issueDate;
	private String paymentType;
	private String docType;
	private BigDecimal origAmt;
	private BigDecimal availAmt;
	private String disRefNo;
	private String disPaymentRefNo;
	private String disPaymentStatus;
	private Date disPaymentDate;
	private Date disDate;
	private String supplierAcct;
	private BigDecimal amtToBeDiscnd;
	private BigDecimal disAmt;
	private String crdRefNo;
	private Date utilizedDate;
	private String docRefNo;
	private String utilizedType;
	private BigDecimal utilAmt;
	private String itemNo;
	private String partNo;
	private String itemDesc;
	private String itemQty;
	private String unitPrice;
	private String subTotal;
	private String matPayRef;
	private String matPayStatus;
	private String supAccNo;
	private Date matPayDate;
	

	private BigDecimal matPayAmt;
	private BigDecimal matPaidAmt;
	private BigDecimal paidAmt;
	private String totIndiRate;
	private BigDecimal netIndAmt;
	private int tenor;
	private BigDecimal discPayAmt;
	private String isExpandFlg;
	private String isMatIniFlg;
	private String pmtId;
	private String gridName;
	private String invId;
	private String invRefNo;
	private Date invIssueDate;
	private Date invDueDate;
	private String statusKey;
	private String statusVal;
	private int decimalPoint;
	
	
	public int getDecimalPoint() {
		return decimalPoint;
	}

	public void setDecimalPoint(int decimalPoint) {
		this.decimalPoint = decimalPoint;
	}
	
	public String getStatusKey() {
		return statusKey;
	}

	public void setStatusKey(String statusKey) {
		this.statusKey = statusKey;
	}
	
	public String getStatusVal() {
		return statusVal;
	}

	public void setStatusVal(String statusVal) {
		this.statusVal = statusVal;
	}
	
	public BigDecimal getMatPaidAmt() {
		return matPaidAmt;
	}

	public void setMatPaidAmt(BigDecimal matPaidAmt) {
		this.matPaidAmt = matPaidAmt;
	}

	public String getInvId() {
		return invId;
	}

	public void setInvId(String invId) {
		this.invId = invId;
	}

	public String getInvRefNo() {
		return invRefNo;
	}

	public void setInvRefNo(String invRefNo) {
		this.invRefNo = invRefNo;
	}

	public Date getInvIssueDate() {
		return invIssueDate;
	}

	public void setInvIssueDate(Date invIssueDate) {
		this.invIssueDate = invIssueDate;
	}

	public Date getInvDueDate() {
		return invDueDate;
	}

	public void setInvDueDate(Date invDueDate) {
		this.invDueDate = invDueDate;
	}

	public BigDecimal getInvAmt() {
		return invAmt;
	}

	public void setInvAmt(BigDecimal invAmt) {
		this.invAmt = invAmt;
	}

	public String getInvAddRefNo() {
		return invAddRefNo;
	}

	public void setInvAddRefNo(String invAddRefNo) {
		this.invAddRefNo = invAddRefNo;
	}

	public String getInvLinEGetFlag() {
		return invLinEGetFlag;
	}

	public void setInvLinEGetFlag(String invLinEGetFlag) {
		this.invLinEGetFlag = invLinEGetFlag;
	}

	private BigDecimal invAmt;
	private String invAddRefNo;
	private String invLinEGetFlag;
	
	
	public String getGridName() {
		return gridName;
	}

	public void setGridName(String gridName) {
		this.gridName = gridName;
	}

	public String getIsExpandFlg() {
		return isExpandFlg;
	}

	public void setIsExpandFlg(String isExpandFlg) {
		this.isExpandFlg = isExpandFlg;
	}

	public String getIsMatIniFlg() {
		return isMatIniFlg;
	}

	public void setIsMatIniFlg(String isMatIniFlg) {
		this.isMatIniFlg = isMatIniFlg;
	}

	public String getPmtId() {
		return pmtId;
	}

	public void setPmtId(String pmtId) {
		this.pmtId = pmtId;
	}
	
	public String getMatPayRef() {
		return matPayRef;
	}

	public void setMatPayRef(String matPayRef) {
		this.matPayRef = matPayRef;
	}

	public String getMatPayStatus() {
		return matPayStatus;
	}

	public void setMatPayStatus(String matPayStatus) {
		this.matPayStatus = matPayStatus;
	}

	public String getSupAccNo() {
		return supAccNo;
	}

	public void setSupAccNo(String supAccNo) {
		this.supAccNo = supAccNo;
	}

	public Date getMatPayDate() {
		return matPayDate;
	}

	public void setMatPayDate(Date matPayDate) {
		this.matPayDate = matPayDate;
	}

	public BigDecimal getMatPayAmt() {
		return matPayAmt;
	}

	public void setMatPayAmt(BigDecimal matPayAmt) {
		this.matPayAmt = matPayAmt;
	}

	public BigDecimal getPaidAmt() {
		return paidAmt;
	}

	public void setPaidAmt(BigDecimal paidAmt) {
		this.paidAmt = paidAmt;
	}

	public String getTotIndiRate() {
		return totIndiRate;
	}

	public void setTotIndiRate(String totIndiRate) {
		this.totIndiRate = totIndiRate;
	}

	public BigDecimal getNetIndAmt() {
		return netIndAmt;
	}

	public void setNetIndAmt(BigDecimal netIndAmt) {
		this.netIndAmt = netIndAmt;
	}

	public int getTenor() {
		return tenor;
	}

	public void setTenor(int tenor) {
		this.tenor = tenor;
	}

	public BigDecimal getDiscPayAmt() {
		return discPayAmt;
	}

	public void setDiscPayAmt(BigDecimal discPayAmt) {
		this.discPayAmt = discPayAmt;
	}

	public String getCustomerRef() {
		return customerRef;
	}

	public void setCustomerRef(String customerRef) {
		this.customerRef = customerRef;
	}

	public String getAdditionalRef() {
		return additionalRef;
	}

	public void setAdditionalRef(String additionalRef) {
		this.additionalRef = additionalRef;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public Date getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public BigDecimal getOrigAmt() {
		return origAmt;
	}

	public void setOrigAmt(BigDecimal origAmt) {
		this.origAmt = origAmt;
	}

	public BigDecimal getAvailAmt() {
		return availAmt;
	}

	public void setAvailAmt(BigDecimal availAmt) {
		this.availAmt = availAmt;
	}

	public String getDisRefNo() {
		return disRefNo;
	}

	public void setDisRefNo(String disRefNo) {
		this.disRefNo = disRefNo;
	}

	public String getDisPaymentRefNo() {
		return disPaymentRefNo;
	}

	public void setDisPaymentRefNo(String disPaymentRefNo) {
		this.disPaymentRefNo = disPaymentRefNo;
	}

	public String getDisPaymentStatus() {
		return disPaymentStatus;
	}

	public void setDisPaymentStatus(String disPaymentStatus) {
		this.disPaymentStatus = disPaymentStatus;
	}

	public Date getDisPaymentDate() {
		return disPaymentDate;
	}

	public void setDisPaymentDate(Date disPaymentDate) {
		this.disPaymentDate = disPaymentDate;
	}

	public Date getDisDate() {
		return disDate;
	}

	public void setDisDate(Date disDate) {
		this.disDate = disDate;
	}

	public String getSupplierAcct() {
		return supplierAcct;
	}

	public void setSupplierAcct(String supplierAcct) {
		this.supplierAcct = supplierAcct;
	}

	public BigDecimal getAmtToBeDiscnd() {
		return amtToBeDiscnd;
	}

	public void setAmtToBeDiscnd(BigDecimal amtToBeDiscnd) {
		this.amtToBeDiscnd = amtToBeDiscnd;
	}

	public BigDecimal getDisAmt() {
		return disAmt;
	}

	public void setDisAmt(BigDecimal disAmt) {
		this.disAmt = disAmt;
	}

	public String getCrdRefNo() {
		return crdRefNo;
	}

	public void setCrdRefNo(String crdRefNo) {
		this.crdRefNo = crdRefNo;
	}

	public Date getUtilizedDate() {
		return utilizedDate;
	}

	public void setUtilizedDate(Date utilizedDate) {
		this.utilizedDate = utilizedDate;
	}

	public String getDocRefNo() {
		return docRefNo;
	}

	public void setDocRefNo(String docRefNo) {
		this.docRefNo = docRefNo;
	}

	public String getUtilizedType() {
		return utilizedType;
	}

	public void setUtilizedType(String utilizedType) {
		this.utilizedType = utilizedType;
	}

	public BigDecimal getUtilAmt() {
		return utilAmt;
	}

	public void setUtilAmt(BigDecimal utilAmt) {
		this.utilAmt = utilAmt;
	}

	public String getItemNo() {
		return itemNo;
	}

	public void setItemNo(String itemNo) {
		this.itemNo = itemNo;
	}

	public String getPartNo() {
		return partNo;
	}

	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}

	public String getItemDesc() {
		return itemDesc;
	}

	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	public String getItemQty() {
		return itemQty;
	}

	public void setItemQty(String itemQty) {
		this.itemQty = itemQty;
	}

	public String getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(String subTotal) {
		this.subTotal = subTotal;
	}

	private String errorMessage;

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	
	public String getOrigAmtStr(){
		return (origAmt != null)?origAmt.toPlainString():"";
	}
	
	public String getAvailAmtStr()
	{
		return (availAmt != null)?availAmt.toPlainString():"";
	}
	
	public String getAmtToBeDiscndStr()
	{
		return (amtToBeDiscnd != null)?amtToBeDiscnd.toPlainString():"";
	}
	
	public String getDisAmtStr()
	{
		return (disAmt != null)?disAmt.toPlainString():"";
	}
	
	public String getUtilAmtStr()
	{
		return (utilAmt != null)?utilAmt.toPlainString():"";
	}
	
	public String getMatPayAmtStr()
	{
		return (matPayAmt != null)?matPayAmt.toPlainString():"";
	}
	
	public String getMatPaidAmtStr()
	{
		return (matPaidAmt != null)?matPaidAmt.toPlainString():"";
	}
	
	public String getPaidAmtStr()
	{
		return (paidAmt != null)?paidAmt.toPlainString():"";
	}
	
	public String getNetIndAmtStr()
	{
		return (netIndAmt != null)?netIndAmt.toPlainString():"";
	}
	
	public String getDiscPayAmtStr()
	{
		return (discPayAmt != null)?discPayAmt.toPlainString():"";
	}
	
	public String getInvAmtStr() {
		return (invAmt != null)?invAmt.toPlainString():"";
	}
}
