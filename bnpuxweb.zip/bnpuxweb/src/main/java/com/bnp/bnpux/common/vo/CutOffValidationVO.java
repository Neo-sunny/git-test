/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
* 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
* 
 * Created on:   27-OCT-2016
* 
 * Purpose:      Cut Off Validation Value Object
* 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/


package com.bnp.bnpux.common.vo;

import java.io.Serializable;

public class CutOffValidationVO implements Serializable{
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String discBuyerAcceptReqd;
	
	private String discountRefNo;
	
	public String getDiscBuyerAcceptReqd() {
		return discBuyerAcceptReqd;
	}

	public void setDiscBuyerAcceptReqd(String discBuyerAcceptReqd) {
		this.discBuyerAcceptReqd = discBuyerAcceptReqd;
	}

	/**
	 * @return the discountRefNo
	 */
	public String getDiscountRefNo() {
		return discountRefNo;
	}

	/**
	 * @param discountRefNo the discountRefNo to set
	 */
	public void setDiscountRefNo(String discountRefNo) {
		this.discountRefNo = discountRefNo;
	}

}
