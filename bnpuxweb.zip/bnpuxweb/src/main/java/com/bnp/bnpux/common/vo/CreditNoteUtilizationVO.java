/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  21 June 2017
 * 
 * Purpose:      Credit Note Inquiry UtilizationVO VO
 * 
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 21 June 2017       Ratna Gokhale, Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/

package com.bnp.bnpux.common.vo;


import java.math.BigDecimal;
import java.util.Date;

public class CreditNoteUtilizationVO{
	
	private String documentRef;
	
	private BigDecimal utilizedAmount;
	
	private Date utilizationDateTime;
	
	private String utilizedStatus;
	
	private String currencyCode;
	
	private String errorMessage;

	private String utilizationDateTimeView;
	

	public String getUtilizationDateTimeView() {
		return utilizationDateTimeView;
	}

	public void setUtilizationDateTimeView(String utilizationDateTimeView) {
		this.utilizationDateTimeView = utilizationDateTimeView;
	}

	public String getDocumentRef() {
		return documentRef;
	}

	public void setDocumentRef(String documentRef) {
		this.documentRef = documentRef;
	}

	public BigDecimal getUtilizedAmount() {
		return utilizedAmount;
	}

	public void setUtilizedAmount(BigDecimal utilizedAmount) {
		this.utilizedAmount = utilizedAmount;
	}

	public Date getUtilizationDateTime() {
		return utilizationDateTime;
	}

	public void setUtilizationDateTime(Date utilizationDateTime) {
		this.utilizationDateTime = utilizationDateTime;
	}

	public String getUtilizedStatus() {
		return utilizedStatus;
	}

	public void setUtilizedStatus(String utilizedStatus) {
		this.utilizedStatus = utilizedStatus;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	
	
	public String getUtilizedAmountStr() {
		return (utilizedAmount != null)? utilizedAmount.toPlainString():"";
	}
	

}
