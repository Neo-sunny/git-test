/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Interface for Discount Request cancel
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.discounting.service;

import java.util.List;

import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.discounting.vo.DiscountRequestVO;

public interface IDiscountCancelSummaryService {
	
	/**
	 * This method is for cancelling the discount request
	 * 
	 * @param discVOList
	 * @param userId
	 * @return
	 * @throws BNPApplicationException
	 */
	public String cancel(List<DiscountRequestVO> discVOList, String userId) throws BNPApplicationException;

}
