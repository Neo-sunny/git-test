/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      White Label Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.io.Serializable;

public class SSMAuthServiceVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String modulus;
	private String publicExponent;
	private String sessionID;
	
	/**
	 * @return the modulus
	 */
	public String getModulus() {
		return modulus;
	}
	
	/**
	 * @param modulus the modulus to set
	 */
	public void setModulus(String modulus) {
		this.modulus = modulus;
	}


	/**
	 * @return the publicExponent
	 */
	public String getPublicExponent() {
		return publicExponent;
	}

	/**
	 * @param publicExponent the publicExponent to set
	 */
	public void setPublicExponent(String publicExponent) {
		this.publicExponent = publicExponent;
	}

	/**
	 * @return the sessionID
	 */
	public String getSessionID() {
		return sessionID;
	}

	/**
	 * @param sessionID the sessionID to set
	 */
	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}
	
}
