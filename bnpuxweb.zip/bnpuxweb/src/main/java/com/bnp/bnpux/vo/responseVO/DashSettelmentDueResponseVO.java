package com.bnp.bnpux.vo.responseVO;

import java.util.List;

import com.bnp.bnpux.common.vo.DashSettlementDueVO;

public class DashSettelmentDueResponseVO {
	
	private List<DashSettlementDueVO> dashSettlementDueVOList;

	private String errorMessage;
	
	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public List<DashSettlementDueVO> getDashSettlementDueVOList() {
		return dashSettlementDueVOList;
	}

	public void setDashSettlementDueVOList(List<DashSettlementDueVO> dashSettlementDueVOList) {
		this.dashSettlementDueVOList = dashSettlementDueVOList;
	}

}
