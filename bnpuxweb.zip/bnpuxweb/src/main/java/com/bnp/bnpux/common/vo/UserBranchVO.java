/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      User Branch Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.io.Serializable;
import java.util.Date;

public class UserBranchVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String branchId;
	private String branchName;
	private String branchCode;
	private String shortName;
	private String country;
	private String timeZone;
	private String currency;
	private String cutOffTime;
	private Date cutOffDate;
	private Date srvrCutOffTime;
	
	public String getBranchId() {
		return branchId;
	}
	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getTimeZone() {
		return timeZone;
	}
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getCutOffTime() {
		return cutOffTime;
	}
	public void setCutOffTime(String cutOffTime) {
		this.cutOffTime = cutOffTime;
	}
	public Date getSrvrCutOffTime() {
		return srvrCutOffTime;
	}
	public void setSrvrCutOffTime(Date srvrCutOffTime) {
		this.srvrCutOffTime = srvrCutOffTime;
	}
	public Date getCutOffDate() {
		return cutOffDate;
	}
	public void setCutOffDate(Date cutOffDate) {
		this.cutOffDate = cutOffDate;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UserBranchVO [branchId=").append(branchId).append(", branchName=").append(branchName)
				.append(", branchCode=").append(branchCode).append(", shortName=").append(shortName)
				.append(", country=").append(country).append(", timeZone=").append(timeZone).append(", currency=")
				.append(currency).append(", cutOffTime=").append(cutOffTime).append(", srvrCutOffTime=")
				.append(srvrCutOffTime).append("]");
		return builder.toString();
	}
	
	
}
