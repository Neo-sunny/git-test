package com.bnp.scm.scheduler.job.handler;

/**************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  03 Feb 2016  
 * 
 * Purpose:    Archival and Purging
 * 
 * Change History: 
 * Date                                  Author                         Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 03 Feb 2016                       Vignesh & Jayadivya S          8.0 New Archival and Purging Implementation
 * *******************************************************************************************************************************
 * */

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.service.JobHandlerService;
import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.scheduler.events.ArchivalandPurgingEmailEvent;

@Component
public class OLTPPurgeJob extends AbstractJob{
	private static final Logger LOGGER = LoggerFactory.getLogger(OLTPPurgeJob.class);

	/** The job handler service. */
	@Autowired
	JobHandlerService jobHandlerService;
	
	/**
	 * Gets the logger.
	 *
	 * @return the logger
	 */
	public Logger getLogger(){
	  return LOGGER;
	}
	
	@Override
	public void run(Map<String, String> inputParam) throws SchedulerException {
	  getLogger().debug("Entering method run from OLTPPurgeJob  with input Parameters :: "+inputParam);
	  long startTime = System.currentTimeMillis();
	  ArchivalandPurgingEmailEvent purgEmailEventInstance = null;
	  try{
		getLogger().debug("Entering to Execute the Purging procedure from OLTPPurgeJob");
	    Map<String, Object> OLTPResultMap = jobHandlerService.processArchivalPurgeData(inputParam,false);
	    getLogger().debug("Exit from Execute the Archival procedure from OLTPPurgeJob");
		purgEmailEventInstance = (ArchivalandPurgingEmailEvent)ApplicationBeanContextFactory.getBean(ArchivalandPurgingEmailEvent.class);
		getLogger().debug("Entering to Send Email from OLAPArchivalandPurgeJob for Success / failure Cases");
		purgEmailEventInstance.processPurgedResults(OLTPResultMap);
		getLogger().debug("Exit from Send Email from OLAPArchivalandPurgeJob for Success / failure Cases");
	  }catch(BNPApplicationException applicationException){
		getLogger().error("BNPApplicationException while OLTPPurgeJob-->" + applicationException.errorMessage);
		throw new SchedulerException(applicationException.errorCode,applicationException.getMessage());
	  }
	  long stopTime = System.currentTimeMillis();
	  getLogger().debug("The Time Taken to Execute Purging Job for the Job History Identifier :: "+inputParam.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID)+" is :: "+(stopTime - startTime)+" milli Seconds");
	  System.out.println("The Time Taken to Execute Purging Job for the Job History Identifier :: "+inputParam.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID)+" is :: "+(stopTime - startTime)+" milli Seconds");
	  getLogger().debug("Exit of method run from OLAPArchivalandPurgeJob ");
	}

}
