package com.bnp.scm.scheduler.job;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.service.ISchedulerService;

@Component
public class ScheduleJob extends AbstractJob{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ScheduleJob.class);
	
	private @Autowired ISchedulerService schedulerService;
	
	
	public ISchedulerService getSchedulerService() {
		return schedulerService;
	}


	public void setSchedulerService(ISchedulerService schedulerService) {
		this.schedulerService = schedulerService;
	}


	@Override
	public void run(Map<String,String> arg0){
		LOGGER.debug("start run ScheduleJob");
		try{
			schedulerService.scheduleJobs();
		}catch(SchedulerException e){
			LOGGER.error(e.getMessage());
			LOGGER.error("error run ScheduleJob "+e);
		}
		LOGGER.debug("end run ScheduleJob");
	}
}
