/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   06 Mar 2011
 * 
 * Purpose:      Create User Screen 
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 24 Feb 2011                      Oracle Financial Services Software Ltd                                    Initial Version 
 *****************************************************************************************************************************************************************/

package com.bnp.scm.scheduler.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnp.scm.scheduler.service.SchedulerService;
import com.bnp.scm.scheduler.util.SchedulerConstants.DAYS;
import com.bnp.scm.scheduler.util.SchedulerConstants.SCH_TYPE;
import com.bnp.scm.scheduler.vo.JobInputVO;

public class SchedulerUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(SchedulerUtil.class);

	public static Map<String,String> buildInput(List<JobInputVO> inputs, Map<String, String> mapToAdd){
		Map<String,String> inputParam = mapToAdd;
		if( inputParam == null){
			inputParam = new HashMap<String, String>();
		}
		if(inputs != null){
			for(JobInputVO param : inputs){
				inputParam.put(param.getParamName(), param.getParamValue());
			}
		}
		return inputParam;
	}
	
	public static DAYS getDay(String day){
		DAYS enumDay;
		if(DAYS.MONDAY.getValue().equalsIgnoreCase(day) || "2".equals(day)){
			enumDay = DAYS.MONDAY;
		}else if(DAYS.TUESDAY.getValue().equalsIgnoreCase(day) || "3".equals(day)){
			enumDay = DAYS.TUESDAY;
		}else if(DAYS.WEDNESDAY.getValue().equalsIgnoreCase(day) || "4".equals(day)){
			enumDay = DAYS.WEDNESDAY;
		}else if(DAYS.THURSDAY.getValue().equalsIgnoreCase(day) || "5".equals(day)){
			enumDay = DAYS.THURSDAY;
		}else if(DAYS.FRIDAY.getValue().equalsIgnoreCase(day) || "6".equals(day)){
			enumDay = DAYS.FRIDAY;
		}else if(DAYS.SATURDAY.getValue().equalsIgnoreCase(day) || "7".equals(day)){
			enumDay = DAYS.SATURDAY;
		}else if(DAYS.SUNDAY.getValue().equalsIgnoreCase(day) || "1".equals(day)){
			enumDay = DAYS.SUNDAY;
		}else{
			enumDay = DAYS.ALL;
		}
		return enumDay;
	}
	public static SCH_TYPE getScheduleType(String schTypeStr){
		SCH_TYPE schType = SCH_TYPE.SCHEDULED;
		if(SCH_TYPE.ADHOC.getValue().equals(schTypeStr)){
			schType = SCH_TYPE.ADHOC;
		}
		return schType;
	}
	
	static public boolean compareToCurrentDate(TimeZone timeZoneIn,Date date, String hour,String min) {
		
		Date newDate = null;
		boolean valid = false;
		
		try{
			SimpleDateFormat formatForDate = new SimpleDateFormat("dd-MM-yyyy");
			String formattedDate = formatForDate.format(date);
			
			SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy HH mm");
			format.setTimeZone(timeZoneIn);
			
			newDate = format.parse(formattedDate+" "+hour+" "+min);//Server timezone time for the given timezone's date info
			
			//976332 CSCDEV-2683 27-NOV-2014:START
			//System.out.println("new Date="+newDate);
			//976332 CSCDEV-2683 27-NOV-2014:END
			
			Date currentDate = new Date();
			formatForDate = new SimpleDateFormat("dd-MM-yyyy HH mm");
			formattedDate = formatForDate.format(currentDate);
			
			format = new SimpleDateFormat("dd-MM-yyyy HH mm");
			currentDate = format.parse(formattedDate);
			
			//976332 CSCDEV-2683 27-NOV-2014:START
			//System.out.println("currentDate="+currentDate);
			
			//System.out.println("compare result"+(newDate.compareTo(currentDate)));
			//976332 CSCDEV-2683 27-NOV-2014:END
			
			if(newDate.compareTo(currentDate) > 0){
				valid = true;
			}
		}catch (ParseException e) {
		}
		
		return valid;
	}

	public static Date getCurrentDateforSelectedTimeZone(Date inputDate,TimeZone fromTimeZone,TimeZone toTimeZone){
		Date returnDate = null;
		try{
			if(inputDate == null){
				returnDate = null;
			}
			if(fromTimeZone == null){
				fromTimeZone = TimeZone.getDefault();
			}
			if(toTimeZone == null){
				toTimeZone = TimeZone.getDefault();
			}
			if(fromTimeZone.equals(toTimeZone)){
				returnDate = inputDate;
			}
			SimpleDateFormat formatForDate = new SimpleDateFormat("dd-MM-yyyy HH mm ss");
			String formattedDate = formatForDate.format(inputDate);
			formatForDate.setTimeZone(fromTimeZone);
			Date convertedStartTimetoServerTZ = formatForDate.parse(formattedDate);
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("convertedStartTimetoServerTZ -->" + convertedStartTimetoServerTZ);
	
			SimpleDateFormat dateFormatterWithTZ = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss Z");
			dateFormatterWithTZ.setTimeZone(toTimeZone);
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("Formatted Date-->" + dateFormatterWithTZ.format(convertedStartTimetoServerTZ));
			
			SimpleDateFormat convertedDateFormatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			returnDate = convertedDateFormatter.parse(dateFormatterWithTZ.format(convertedStartTimetoServerTZ));
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("newDate-->" + returnDate);
		}catch(Exception e){
			returnDate = null;
		}
		return returnDate;
	}
	
}
