package com.bnp.scm.scheduler.dao;

/**************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  03 Feb 2016  
 * 
 * Purpose:    Archival and Purging
 * 
 * Change History: 
 * Date                                  Author                         Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 03 Feb 2016                      Vignesh & Jayadivya S                 					8.0 New Archival and Purging Implementation 
 * *******************************************************************************************************************************
 * */

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("rawtypes")
public class OLAPArchivalResultSetMap {
	/** Map Object In order To handle The Objects from the Result Set call Back handler Class*/
	private List<String> result = new ArrayList<String>();

	/**
	 * Method intended to Get the Result Set Map.
	 * 
	 * @return Map<String, List> - Map Of List Of Objects
	 */
	public List<String> getResult() {
		return result;
	}
	
	/**
	 * Method intended to Set the Result Set Map.
	 * 
	 * @return Map<String, List> - Map Of List Of Objects
	 */
	public void setResult(List<String> result) {
		this.result = result;
	}

	@Override
	public String toString() {
	  return result != null ? result.toString() : new ArrayList<String>().toString();
	}
}
