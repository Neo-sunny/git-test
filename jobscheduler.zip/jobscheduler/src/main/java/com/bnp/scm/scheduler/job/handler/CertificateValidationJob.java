/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Apr 2012
 * 
 * Purpose: Certificate validation Job Handler
 * 
 * Change History: 
 * Date                             Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 25 Apr 2012                      Ramesh A                              Initial Version
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.job.handler;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;
import com.bnp.scm.services.cert.constants.CertificateConstants;
import com.bnp.scm.services.cert.delegate.CertificateDelegate;
import com.bnp.scm.services.common.util.StatusConstants;


@Component
public class CertificateValidationJob extends AbstractJob {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(CertificateValidationJob.class);
	@Override
	public void run(Map<String, String> arg0) throws SchedulerException {
		LOGGER.debug("CertificateValidationJob--Beg");
		//ApplicationContext context = new ClassPathXmlApplicationContext("application-context.xml");
		//CertificateDelegate delegate = context.getBean("certificateDelegate", CertificateDelegate.class);
		CertificateDelegate delegate = (CertificateDelegate)ApplicationBeanContextFactory.getBean(CertificateDelegate.class);

		setProperties();
		LOGGER.info("Starting the Certificate Validation Utility");
		delegate.validateCertificates();
		delegate.validateUserCertificates();
		LOGGER.info("End");
		LOGGER.debug("CertificateValidationJob--End");
	}
	
	public static void setProperties() {
		FileReader fileReader = null;
		try {
			LOGGER.debug("setProperties--Beg");
			Properties properties = new Properties();
			fileReader = new FileReader("certificate.properties");
			properties.load(fileReader);
			CertificateConstants.MAIL_TEMPLATE = properties.getProperty("mail.msg.template", StatusConstants.EMPTY_STRING);
			CertificateConstants.MAIL_FROM_ID = properties.getProperty("mail.msg.from", StatusConstants.EMPTY_STRING);
			CertificateConstants.MAIL_TO_ID = properties.getProperty("mail.msg.to", StatusConstants.EMPTY_STRING);
			CertificateConstants.MAIL_CC_ID = properties.getProperty("mail.msg.cc", StatusConstants.EMPTY_STRING);
			CertificateConstants.MAIL_SUBJECT = properties.getProperty("mail.msg.subject", StatusConstants.EMPTY_STRING);

			CertificateConstants.CERTIFICATE_KEY_SIZE = Integer.valueOf(properties.getProperty("certificate.keysize", StatusConstants.EMPTY_STRING));
			CertificateConstants.CERTIFICATE_ALGORITHM = properties.getProperty("certificate.algorithm", StatusConstants.EMPTY_STRING);
			CertificateConstants.SYMMETRIC_KEY_ALGORITHM = properties.getProperty("certificate.symmetric.algorithm", StatusConstants.EMPTY_STRING);
			CertificateConstants.KEY_PAIR_ALGORITHM = properties.getProperty("certificate.keypair.algorithm", StatusConstants.EMPTY_STRING);
			CertificateConstants.PASS_PHRASE_ALGORITHM = properties.getProperty("certificate.passphrase.algorithm", StatusConstants.EMPTY_STRING);

			CertificateConstants.ROOT_CERTIFICATE_CN = properties.getProperty("certificate.root.commmonname", StatusConstants.EMPTY_STRING);
			CertificateConstants.APPLICATION_CERTIFICATE_CN = properties.getProperty("certificate.application.commmonname", StatusConstants.EMPTY_STRING);
			CertificateConstants.PASSWORD_CERTIFICATE_CN = properties.getProperty("certificate.password.commmonname", StatusConstants.EMPTY_STRING);
			CertificateConstants.ROOT_CERTIFICATE_VALIDITY = Integer.valueOf(properties.getProperty("certificate.root.validity", StatusConstants.EMPTY_STRING));
			CertificateConstants.APPLICATION_CERTIFICATE_VALIDITY = Integer.valueOf(properties.getProperty("certificate.application.validity", StatusConstants.EMPTY_STRING));
			CertificateConstants.PASSWORD_CERTIFICATE_VALIDITY = Integer.valueOf(properties.getProperty("certificate.password.validity", StatusConstants.EMPTY_STRING));
			CertificateConstants.ORGANIZATION_NAME = properties.getProperty("certificate.org.name", StatusConstants.EMPTY_STRING);
			CertificateConstants.ORGANIZATION_UNIT = properties.getProperty("certificate.org.unit", StatusConstants.EMPTY_STRING);
			CertificateConstants.ORGANIZATION_LOCATION = properties.getProperty("certificate.org.location", StatusConstants.EMPTY_STRING);
			CertificateConstants.ORGANIZATION_LOCATION_CODE = properties.getProperty("certificate.org.loccode", StatusConstants.EMPTY_STRING);
			CertificateConstants.EMAIL_ID = properties.getProperty("certificate.org.emailid", StatusConstants.EMPTY_STRING);		
			LOGGER.debug("setProperties--End");
		}
		catch (FileNotFoundException e) {
			LOGGER.error("FileNotFoundException : " + e);
		} 
		catch (IOException e) {
			LOGGER.error("FileNotFoundException : " + e);
		}finally{
			try{
				if(fileReader != null){
					fileReader.close();
				}
			}catch(Exception e){
				LOGGER.error("Exception while closing Filereader : " + e);
			}
		}
	}
	
}
