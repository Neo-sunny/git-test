package com.bnp.scm.scheduler.vo;

public class ScheduledHoursVO {
    private String eventRef;

    private String hours;

    public String getEventRef() {
		return eventRef;
	}

	public void setEventRef(String eventRef) {
		this.eventRef = eventRef;
	}

	public String getHours() {
        return hours;
    }

    public void setHours(String hours) {
        this.hours = hours;
    }
}