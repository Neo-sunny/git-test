/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   02 Apr 12 
 * 
 * Purpose: Scheduler Thread Manager Interface 
 * 
 * Change History: 
 * Date                             Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 25 Apr 2012                      Ramesh A                              Initial Version
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.util;

import com.bnp.scm.scheduler.dao.ISchedulerDAO;
import com.bnp.scm.scheduler.vo.ScheduleVO;

public interface SchedulerThreadManager {
	void scheduleJob(ScheduleVO scheduleVo, boolean isRescheduleRequest,JobBuilder jobBuilder,ISchedulerDAO schedulerDAO);
	void unscheduleJob(String eventRefNo,String jobType,ISchedulerDAO schedulerDAO);
}
