package com.bnp.scm.scheduler.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobListener;

import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;
import com.bnp.scm.scheduler.util.SchedulerConstants;

public class JobListenerImpl implements JobListener{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(JobListenerImpl.class);

	private String name;
	public String getName() {
        return name;
    }

	public void setName(String name) {
        this.name=name;
    }
	//FO 8.0 Sonar Fix -Starts
	private void loggerMsg(String msg){
		LOGGER.debug(msg);
	}
	//FO 8.0 Sonar Fix -Ends

    public void jobToBeExecuted(JobExecutionContext inContext) {
		JobDataMap data = inContext.getMergedJobDataMap();
		String eventName = data.getString(SchedulerConstants.PARAM_NAME_EVENT_NAME);
		String eventRef = data.getString(SchedulerConstants.PARAM_NAME_EVENT_REF);
		//FO 7.0 Fortify Issue Fix
		//FO 8.0 Sonar Fix
		loggerMsg("JobListener says: Job Is about to be executed for event "+eventName+" and ref ="+eventRef);

        JobStatusNotificationService jobStatusService = (JobStatusNotificationService)ApplicationBeanContextFactory.getBean("jobStatusNotificationService");
        jobStatusService.jobStarted(inContext);
        
    }

    public void jobExecutionVetoed(JobExecutionContext inContext) {
		JobDataMap data = inContext.getMergedJobDataMap();
		String eventName = data.getString(SchedulerConstants.PARAM_NAME_EVENT_NAME);
		String eventRef = data.getString(SchedulerConstants.PARAM_NAME_EVENT_REF);
		//FO 7.0 Fortify Issue Fix
		//FO 8.0 Sonar Fix
		loggerMsg("JobListener says: Job was skipped for event "+eventName+" and ref ="+eventRef);
    	
        JobStatusNotificationService jobStatusService = (JobStatusNotificationService)ApplicationBeanContextFactory.getBean("jobStatusNotificationService");
        jobStatusService.jobSkipped(inContext);

    }

    public void jobWasExecuted(JobExecutionContext inContext,JobExecutionException inException) {
		JobDataMap data = inContext.getMergedJobDataMap();
		String eventName = data.getString(SchedulerConstants.PARAM_NAME_EVENT_NAME);
		String eventRef = data.getString(SchedulerConstants.PARAM_NAME_EVENT_REF);
		//FO 7.0 Fortify Issue Fix
		//FO 8.0 Sonar Fix
		loggerMsg("JobListener says: Job was executed for event "+eventName+" and ref ="+eventRef);
    	
        JobStatusNotificationService jobStatusService = (JobStatusNotificationService)ApplicationBeanContextFactory.getBean("jobStatusNotificationService");
        jobStatusService.jobEnded(inContext);
    }
    
}
