/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Sep 2011
 * 
 * Purpose:      Auto Discounting services
 * 
 * Change History: 
 * Date                                   Author                                Version                                 Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 02 Mar 2012                      Oracle Financial Services Software Ltd                                    Initial Version
 ***************************************************************************/

package com.bnp.scm.scheduler.server;

import java.io.InputStream;
import java.rmi.ConnectException;
import java.rmi.NotBoundException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.quartz.Scheduler;
import com.bnp.scm.scheduler.service.ISchedulerService;
import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;
import com.bnp.scm.scheduler.util.QuartzSchedulerFactoryNew;
import com.bnp.scm.scheduler.util.SpringJobFactory;

/**
 * The Class QuartzRemoteServer.
 */
public class QuartzRemoteServer {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(QuartzRemoteServer.class);
	
	 /**
 	 * Run.
 	 *
 	 * @throws Exception the exception
 	 */
 	public void run() throws Exception {
	   if(checkRMIRegistry()){
	     Scheduler scheduler = QuartzSchedulerFactoryNew.getSchedulerFactory().getScheduler(null);
	     scheduler.setJobFactory(new SpringJobFactory());
	     ISchedulerService schedulerService = (ISchedulerService)ApplicationBeanContextFactory.getBean(ISchedulerService.class);
	     schedulerService.removeJobsConfig();
	     schedulerService.loadJobsConfig();
	     schedulerService.scheduleJobs();
	     scheduler.start();
	     System.out.println("instance Id "+scheduler.getSchedulerInstanceId());
	     System.out.println("Name is "+scheduler.getSchedulerName());
	     System.out.println("Scheduler Status :" + scheduler.isStarted());
	   }    
     }
	 
	 
    /**
     * The main method.
     *
     * @param args the arguments
     */
    public static void main(String[] args){
      LOGGER.debug("before starting the remote server");
      QuartzRemoteServer server = new QuartzRemoteServer();
      try{
        server.run();
      }catch(Exception exception){
    	System.out.println("Exception occured while Executing main in QuartzRemoteServer");
        LOGGER.error("Exception Occured whil execution of Main in QuartzRemoteServer: {} ",exception);
        System.exit(0);
      }
    }

    /**
     * Check rmi registry.
     *
     * @return true, if successful
     */
    public static boolean checkRMIRegistry(){
	  boolean returnFlg = true;
	  InputStream inputStream = null;
      try{
	    String propFileName = System.getProperty("quartzpropfilename");
		inputStream = QuartzRemoteServer.class.getClassLoader().getResourceAsStream(propFileName);
		Properties config = new Properties();
		config.load(inputStream);
		String instanceName = config.getProperty("org.quartz.scheduler.instanceName");
		String instanceId = config.getProperty("org.quartz.scheduler.instanceId");
		String rmiRegistryHost = config.getProperty("org.quartz.scheduler.rmi.registryHost");
		String rmiRegistryPort = config.getProperty("org.quartz.scheduler.rmi.registryPort");
		System.out.println("InstanceName =>" + instanceName + ", Instance Id =>" + instanceId + ", RMI Registry Host =>" + rmiRegistryHost + ", RMI Registry Port =>" + rmiRegistryPort);
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("InstanceName =>" + instanceName + ", Instance Id =>" + instanceId + ", RMI Registry Host =>" + rmiRegistryHost + ", RMI Registry Port =>" + rmiRegistryPort);
		if(instanceName == null || "".equals(instanceName)){
	      returnFlg = false;
	      System.out.println("Instance Name is mandatory");
		}
		if(instanceId == null || "".equals(instanceId)){
	      returnFlg = false;
	      System.out.println("Instance Id is mandatory");
		}
		Registry registry = LocateRegistry.getRegistry(rmiRegistryHost, Integer.valueOf(rmiRegistryPort));
	    String instancetobeLookup = instanceName + "_$_" + instanceId;
	    Object obj = registry.lookup(instancetobeLookup);
	    if(obj != null){
	      returnFlg = false;
	      System.out.println("Instance already availble for the given configuration");
	    }
      }catch(ConnectException connectException){
        System.out.println("RMI Registry is not available");
        LOGGER.error("ConnectException occured while executing checkRMIRegistry Method : {} ",connectException);
      }catch(NotBoundException notBoundException){
        System.out.println("NotBoundException occured while executing checkRMIRegistry Method");
        LOGGER.error("NotBoundException occured while executing checkRMIRegistry Method : {} ",notBoundException);
      }catch(Exception exception){
    	System.out.println("Exception occured while executing checkRMIRegistry Method");
	    LOGGER.error("Exception Occured whil execution checkRMIRegistry : {} ",exception);
	  }finally {//Fortify fix : Unreleased Resource: Streams
	    try {
		  if(inputStream != null) {
		    inputStream.close();
		  }
		}catch (Exception exception) {
		  System.out.println("Exception occured while Closing the Quartz connection");
		  LOGGER.error("Exception Occured whil execution checkRMIRegistry while closing connection : {} ",exception);
		}
	  }
      return returnFlg;
    }
}
