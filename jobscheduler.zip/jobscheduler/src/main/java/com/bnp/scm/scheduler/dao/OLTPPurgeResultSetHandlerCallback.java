package com.bnp.scm.scheduler.dao;

/**************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  03 Feb 2016  
 * 
 * Purpose:    Archival and Purging
 * 
 * Change History: 
 * Date                                  Author                         Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 03 Feb 2016                      Vignesh & Jayadivya S                 					8.0 New Archival and Purging Implementation 
 * *******************************************************************************************************************************
 * */

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ibatis.sqlmap.client.extensions.ParameterSetter;
import com.ibatis.sqlmap.client.extensions.ResultGetter;
import com.ibatis.sqlmap.client.extensions.TypeHandlerCallback;

public class OLTPPurgeResultSetHandlerCallback implements TypeHandlerCallback{
	
	/** The LOGGER. */
	public final Logger LOGGER = LoggerFactory.getLogger(OLAPArchivalResultSetHandlerCallback.class);
	
	private String getHeaderColumns(){
	  StringBuilder _headerColumns = new StringBuilder();
	  _headerColumns.append("Organization Id");
	  _headerColumns.append(",");
	  _headerColumns.append("Table Name");
	  _headerColumns.append(",");
	  _headerColumns.append("Processed Record Count");
	  _headerColumns.append(",");
	  _headerColumns.append("Error Description");
	  _headerColumns.append("\n");
	  return _headerColumns.toString();
	}

	public Object getResult(ResultGetter getter) throws SQLException {
	  ResultSet resultSet = getter.getResultSet();  
	  List<String> _resultInstance = new ArrayList<String>();
	  _resultInstance.add(getHeaderColumns());
	  try{
	    while (resultSet.next()) {
		  StringBuilder builderResultInstance = new StringBuilder();
		  builderResultInstance.append("\n");
		  builderResultInstance.append(resultSet.getString("ORG_ID"));
		  builderResultInstance.append(",");
		  builderResultInstance.append(resultSet.getString("TABLE_NAME"));
		  builderResultInstance.append(",");
		  builderResultInstance.append(resultSet.getString("PROCESSED_RECORD_CNT"));
		  builderResultInstance.append(",");
		  builderResultInstance.append(resultSet.getString("ERROR_DESC"));
		  _resultInstance.add(builderResultInstance.toString());
	    }
	  }catch(SQLException exception){
	    LOGGER.error("SQLException Occured while Executing the method OLTPPurgeResultSetHandlerCallback with exception : {} ",exception);
		throw exception;
      }
	  LOGGER.debug("The result Set from the OLTPPurgeResultSetHandlerCallback is :: \n"+_resultInstance);
	  return _resultInstance;
	}

	@Override
	public void setParameter(ParameterSetter arg0, Object arg1)
			throws SQLException {
		
	}

	@Override
	public Object valueOf(String arg0) {
		return null;
	}

}
