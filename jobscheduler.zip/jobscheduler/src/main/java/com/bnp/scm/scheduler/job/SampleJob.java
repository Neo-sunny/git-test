package com.bnp.scm.scheduler.job;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;

@Component
public class SampleJob extends AbstractJob{

	static int count = 0;
	
	@Override
	public void run(Map<String, String> arg0) throws SchedulerException {
	//976332 CSCDEV-2683 27-NOV-2014:START
		//System.out.println("input is"+arg0);
		//976332 CSCDEV-2683 27-NOV-2014:END

		//count++;   Commented for R7.0 Sonar Fix
	/*	if(count%2==0){
			throw new NullPointerException("test exception");
		}*/
	}

}
