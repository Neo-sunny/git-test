package com.bnp.scm.scheduler.vo;

public class ScheduledDaysVO {
    private String eventRef;
    private String day;

    public String getEventRef() {
		return eventRef;
	}

	public void setEventRef(String eventRef) {
		this.eventRef = eventRef;
	}

	public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day == null ? null : day.trim();
    }
}