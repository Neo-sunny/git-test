package com.bnp.scm.scheduler.dao;

import java.util.List;

import com.bnp.scm.scheduler.vo.ScheduleInfoVO;
import com.bnp.scm.services.common.exception.DBException;

public interface ScheduleInfoDAO {
	
    String insert(ScheduleInfoVO record) throws DBException;
    void updateActionFlag(ScheduleInfoVO record) throws DBException;
    void updateScheduleStatus(ScheduleInfoVO record) throws DBException;
    void delete(String eventRef) throws DBException;
    ScheduleInfoVO getScheduleInfo(String eventRef) throws DBException;
    List<ScheduleInfoVO> getUnScheduledInfoByActionFlag(String actionFlag) throws DBException;
    void update(ScheduleInfoVO record) throws DBException;
    void updateJobCompletionStatus(String eventRef) throws DBException;
    String getJobCompletionStatus(String eventRef) throws DBException;
    String getEventRefForStaticJob(String jobName,String groupName)throws DBException;
    void updateScheduleError(ScheduleInfoVO record) throws DBException;
    String getUserBranchTimeZone(String eventRef) throws DBException;
}