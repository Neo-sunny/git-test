package com.bnp.scm.scheduler.util;
import java.util.Map;

import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.vo.JobInfoVO;

@Component
public class JobBuilder {

		
	public JobDetail buildJob(JobInfoVO jobInfoVO) throws SchedulerException{
		
		String groupName = jobInfoVO.getGroupName();
		String jobClassName=jobInfoVO.getJobClassName();
		String jobName = jobInfoVO.getJobName();//take it from table
		
		try{
			Class job = Class.forName(jobClassName);
			JobDetail jobDetail = org.quartz.JobBuilder.newJob(job).withIdentity(jobName, groupName).storeDurably(jobInfoVO.isDurablity()).build();
			return jobDetail;
		}catch(ClassNotFoundException e){
			throw new SchedulerException(e.getMessage(), e);
		}
	}

	public JobDetail buildAdhocJob(String jobName, Class<? extends Job> jobClassName,Map<String,String> input) throws SchedulerException{
		JobDataMap map = new JobDataMap();
		map.putAll(input);
		JobDetail jobDetail = org.quartz.JobBuilder.newJob(jobClassName).withIdentity(jobName).storeDurably(false).usingJobData(map).build();
		return jobDetail;
	}

}
