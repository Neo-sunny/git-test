package com.bnp.scm.scheduler.dao;

import java.util.List;

import com.bnp.scm.scheduler.vo.ScheduledHoursVO;
import com.bnp.scm.services.common.exception.DBException;

public interface ScheduledHoursDAO {
	
    void insert(List<ScheduledHoursVO> record) throws DBException;
    void deleteByEventRef(String eventRef) throws DBException;
    List<String> getScheduledHoursByEventRef(String eventRef) throws DBException;
    
}