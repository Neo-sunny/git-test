/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Apr 2012
 * 
 * Purpose: Branch Holiday validator for Jobs 
 * 
 * Change History: 
 * Date                             Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 25 Apr 2012                      Ramesh A                              Initial Version
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.job.validator;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.service.JobValidatorService;
import com.bnp.scm.scheduler.util.IExcludeFireCheckService;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

@Component("branchHolidayValidator")
public class BranchHolidayValidator implements IExcludeFireCheckService {

	private static final Logger LOGGER = LoggerFactory.getLogger(BranchHolidayValidator.class);
	
	@Autowired
	private JobValidatorService jobValidatorService;
	
	@Override
	public boolean checkExcludeCurrentFire(Map<String, String> inputParameter) throws SchedulerException {
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("BranchHolidayValidator--inputParameter" + inputParameter);
		boolean returnFlg = true;
		String branchId = inputParameter.get(SchedulerConstants.PARAM_NAME_BRANCH_ID);
		if(branchId != null && branchId.length() > 0){
			try{
				NameValueVO branchDetail = jobValidatorService.getBranchDetails(branchId);
				//FO 7.0 Fortify Issue Fix
				//LOGGER.debug("branchDetail-->" + branchDetail);
				if(branchDetail != null){
					String datePattern="dd/MM/yyyy HH:mm:ss";
					String datewithTZPattern="dd/MM/yyyy HH:mm:ss Z";
					String today = jobValidatorService.getSystemDate();
					//FO 7.0 Fortify Issue Fix
					//LOGGER.debug("today->" + today);
					String branchTimezone = branchDetail.getValue();
					//FO 7.0 Fortify Issue Fix
					//LOGGER.debug("branchDetail-branchTimezone->" + branchTimezone);
					SimpleDateFormat serverDateFormatter = new SimpleDateFormat(datePattern);
					serverDateFormatter.setTimeZone(TimeZone.getDefault());
					//FO 7.0 Fortify Issue Fix
					//LOGGER.debug("Server TimeZone->" + serverDateFormatter.getTimeZone());
					Date convertedServerTime = serverDateFormatter.parse(today);
					//FO 7.0 Fortify Issue Fix
					//LOGGER.debug("convertedServerTime-->" + convertedServerTime);
			
					SimpleDateFormat branchDateFormatterWithTZ = new SimpleDateFormat(datewithTZPattern);
					branchDateFormatterWithTZ.setTimeZone(TimeZone.getTimeZone(branchTimezone));
					//FO 7.0 Fortify Issue Fix
					//LOGGER.debug("Formatted Date-->" + branchDateFormatterWithTZ.format(convertedServerTime));
					
					SimpleDateFormat branchDateFormatter = new SimpleDateFormat(datePattern);
			        Timestamp branchDate = new Timestamp((branchDateFormatter.parse(branchDateFormatterWithTZ.format(convertedServerTime))).getTime());
	
			        //FO 7.0 Fortify Issue Fix
					//LOGGER.debug("BranchTimeZne-->" + branchDate);
					int branchHolidayCount = jobValidatorService.getBranchHolidayCount(branchId, branchDate);
					//FO 7.0 Fortify Issue Fix
					//LOGGER.debug("branchHolidayCount-->" + branchHolidayCount);
					if(branchHolidayCount == 0){
						returnFlg = false;
					}else{
						returnFlg = true;
					}
				}	
			}catch(ParseException e){
				LOGGER.error("Error while parsing Date");
			}catch(BNPApplicationException be){
				LOGGER.error(be.getErrorMessage());
			}
		}else{
			returnFlg = false;
		}
		return returnFlg;
	}

}
