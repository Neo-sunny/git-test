package com.bnp.scm.scheduler.vo;

public class ScheduledMinisVO {
    private String eventRef;

    private String minis;


    public String getEventRef() {
		return eventRef;
	}

	public void setEventRef(String eventRef) {
		this.eventRef = eventRef;
	}

	public String getMinis() {
        return minis;
    }

    public void setMinis(String minis) {
        this.minis = minis;
    }
}