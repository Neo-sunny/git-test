/* ************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   22 Dec 2014
 * 
 * Purpose:     Discount Rejected by Buyer ERP Job
 * 
 * Change History: 
 * Date                                                  Author                                                    Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 22 Dec 2014                      Oracle Financial Services Software Ltd                           	R7.0 ERP Message Changes for Brazil Payable
 * 
 ***************************************************************************/

package com.bnp.scm.scheduler.job.handler;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.scheduler.events.DiscRejectedByBuyerErpEvent;


@Component
public class DiscRejectedByBuyerErpJob extends AbstractJob {

	public static final Logger LOGGER = LoggerFactory.getLogger(DiscRejectedByBuyerErpJob.class);
	@Override
	public void run(Map<String, String> inputMap) throws SchedulerException {
		LOGGER.debug("DiscRejectedByBuyerErpJob--Beg");
		String args[] = getArgs(inputMap);
		processEvent(DiscRejectedByBuyerErpEvent.class, args);
		LOGGER.debug("DiscRejectedByBuyerErpJob--End");
	}
	
	private String[] getArgs(Map<String, String> inputMap) {
		String[] args = new String[9];
		args[0] = "";
		args[1] = inputMap.get(SchedulerConstants.PARAM_NAME_BRANCH_ID);
		args[2] = inputMap.get(SchedulerConstants.PARAM_NAME_ORG_ID);
		args[3] = inputMap.get(SchedulerConstants.PARAM_NAME_CCY);
		args[4] = inputMap.get(SchedulerConstants.PARAM_NAME_PYMT_METHOD);
		args[5] = inputMap.get(SchedulerConstants.PARAM_NAME_CUSTOM_PARAM);
		args[6] = BNPConstants.DISC_REJECTED_BY_BUYER_STATUS;
		args[7] = inputMap.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID);
		args[8] = inputMap.get(SchedulerConstants.PARAM_NAME_EVENT_NAME);
		
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("DiscRejectedByBuyerErpJob--arg-0->" + args[0] + "<arg-1->" + args[1] + "<arg-2->" + args[2] + "<arg-3->" + args[3] + 
		//			"<arg-4->" + args[4] + "<arg-5->" + args[5] + "<arg-6->" + args[6] + "<arg-7->" + args[7]+"<arg-8->"+args[8]);
		
		return args;
	}
}
