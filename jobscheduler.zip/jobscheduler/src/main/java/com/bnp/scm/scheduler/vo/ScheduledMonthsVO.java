package com.bnp.scm.scheduler.vo;

public class ScheduledMonthsVO {
    private String eventRef;
    private String month;

    public String getEventRef() {
		return eventRef;
	}
	public void setEventRef(String eventRef) {
		this.eventRef = eventRef;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
}
