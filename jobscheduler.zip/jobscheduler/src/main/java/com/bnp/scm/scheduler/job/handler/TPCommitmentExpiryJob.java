package com.bnp.scm.scheduler.job.handler;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.discounting.CommitmentFeeCalcService;

@Component
public class TPCommitmentExpiryJob extends AbstractJob{


		public static final Logger LOGGER = LoggerFactory.getLogger(TPCommitmentExpiryJob.class);
		
		@Autowired
		private CommitmentFeeCalcService commitmentFeeCalcService;
		
		@Override
		public void run(Map<String, String> inputMap) {

			LOGGER.debug("TPCommitmentExpiryJob--Begins");
			try {
				String branchId = inputMap.get(SchedulerConstants.PARAM_NAME_BRANCH_ID);
				
				//FO 7.0 Fortify Issue Fix
				//LOGGER.debug("TPCommitmentExpiryJob--arg->" + branchId);
				commitmentFeeCalcService.insertBankEventLogForTPCommtExpiry(branchId);
				
			}catch(BNPApplicationException be){
	    		LOGGER.error("BNPApplicationException in TPCommitmentExpiryJob--->",be);
	    	}	
			LOGGER.debug("TPCommitmentExpiryJob--End");
		
		}

	}



