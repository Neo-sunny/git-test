/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   06 Mar 2011
 * 
 * Purpose:      Bank code  DAO Impl 
 * 
 * Change History: 
 * Date                                                  Author                                                 Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 06 Mar 2012                      Oracle Financial Services Software Ltd                                    Initial Version 
 *                                  										
 *****************************************************************************************************************************************************************/

package com.bnp.scm.scheduler.listener;


import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;

import com.bnp.scm.scheduler.dao.ISchedulerDAO;
import com.bnp.scm.scheduler.dao.ScheduleInfoDAO;
import com.bnp.scm.scheduler.service.JobStatusMailService;
import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;
import com.bnp.scm.scheduler.util.IEventStatusNotificationService;
import com.bnp.scm.scheduler.util.JobResult;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.scheduler.util.SchedulerConstants.JOB_RESULT;
import com.bnp.scm.scheduler.util.SchedulerConstants.JOB_STATUS;
import com.bnp.scm.scheduler.vo.JobExecHistVO;
import com.bnp.scm.scheduler.vo.ScheduleInfoVO;
import com.bnp.scm.services.common.exception.DBException;

public class JobStatusNotificationService {
	
    private static Logger LOGGER = LoggerFactory.getLogger(JobStatusNotificationService.class);
    
    //On each method based on the corresponding eventName, find the status notification handler
	private Map<String,String> eventNotificationMap;
	
	@Autowired
	private ISchedulerDAO schedulerDAO;

	@Autowired
	private JobStatusMailService jobStatusMailService;
	
	@Autowired
	private ScheduleInfoDAO scheduleInfoDAO;
	
	//FO 8.0 Sonar Fix -Starts
	private void loggerMsg(String msg){
		LOGGER.debug(msg);
	}
	//FO 8.0 Sonar Fix -Ends
	
	public Map<String, String> getEventNotificationMap() {
		return eventNotificationMap;
	}
	
	public void setEventNotificationMap(Map<String, String> eventNotificationMap) {
		this.eventNotificationMap = eventNotificationMap;
	}
	
	public ISchedulerDAO getSchedulerDAO() {
		return schedulerDAO;
	}
	
	public void setSchedulerDAO(ISchedulerDAO schedulerDAO) {
		this.schedulerDAO = schedulerDAO;
	}
	
	public void jobSkipped(JobExecutionContext context){
		long histId = insertJobStatus(context, SchedulerConstants.JOB_STATUS.SKIPPED);
		context.put(SchedulerConstants.PARAM_NAME_JOB_HIST_ID, histId);
	}
	
	public void jobStarted(JobExecutionContext context){
		long histId = insertJobStatus(context, SchedulerConstants.JOB_STATUS.STARTED);
		context.put(SchedulerConstants.PARAM_NAME_JOB_HIST_ID, histId);

	}
	
	public void jobEnded(JobExecutionContext context){
    	//put entry in the audit log for a event_ref, which is coming as parameter
    	//end time, status as Completed
    	
    	//2.update the scheduler info table, if this the last trigger
		String triggerName = context.getTrigger().getKey().getName();
		//FO 7.0 Fortify Issue Fix
		//FO 8.0 Sonar Fix
		loggerMsg("triggerName ="+triggerName);
		Long histId = (Long)context.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID);
		JobDataMap input = context.getMergedJobDataMap();
		JobResult result = (JobResult)context.getResult();
		if(result != null){
			String eventRef = input.getString(SchedulerConstants.PARAM_NAME_EVENT_REF);
			JOB_RESULT jobResult = result.getResult();
			//FO 7.0 Fortify Issue Fix
			//FO 8.0 Sonar Fix
			loggerMsg("job execution status for event_ref ="+eventRef+" with hisId ="+histId+" is="+jobResult.getValue());
			Throwable exception = result.getException();
			SchedulerConstants.JOB_STATUS jobStatus = SchedulerConstants.JOB_STATUS.COMPLETED;
			if(jobResult.equals(JOB_RESULT.FAIL)){
				jobStatus = SchedulerConstants.JOB_STATUS.FAILED;
			}
			updateEndStatus(context, exception, jobStatus);
		}
	}
	
	private long insertJobStatus(JobExecutionContext context, SchedulerConstants.JOB_STATUS jobStatus){
		long histId = 0;
		JobDataMap input  = context.getMergedJobDataMap();
		String eventName = input.getString(SchedulerConstants.PARAM_NAME_EVENT_NAME);
		String eventRef = input.getString(SchedulerConstants.PARAM_NAME_EVENT_REF);
		String timeZoneID = input.getString(SchedulerConstants.PARAM_NAME_TIME_ZONE);
		try{
			JobDetail jobDetail = context.getJobDetail();
			JobExecHistVO histVO = new JobExecHistVO();
			histVO.setEventRef(eventRef);
			histVO.setJobStatus(jobStatus.getValue());
			histVO.setGroupName(jobDetail.getKey().getGroup());
			histVO.setJobName(jobDetail.getKey().getName());
			histVO.setJobHandlerClassName(jobDetail.getJobClass().getName());
			histVO.setScheduleTimeZoneId(timeZoneID);
			Timestamp time = new Timestamp(new Date().getTime());
			histVO.setStartTime(time);
			if(jobStatus.equals(SchedulerConstants.JOB_STATUS.SKIPPED)){
				histVO.setEndTime(time);
			}
			try{
				ScheduleInfoVO scheduleInfoVO = schedulerDAO.getScheduleInfo(eventRef);
				histVO.setJobType(scheduleInfoVO.getJobType());
				histVO.setScheduleType(scheduleInfoVO.getScheduleType());
				histVO.setOriginalEventRef(scheduleInfoVO.getOriginalEventRef());
			}catch(Exception e){
				LOGGER.error("Error while fetching ScheduleInfo" + e);
			}
			histId = schedulerDAO.insertAuditLog(histVO);
		}catch(DBException e){
			LOGGER.error("Error while inserting JobAuditLog "+e);
		}
		String serviceHandler = eventNotificationMap.get(eventName);
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("jobstatusnotification serviceHandler for eventName ="+eventName+" is ="+serviceHandler);
    	if(serviceHandler!=null && !"".equals(serviceHandler)){
    		IEventStatusNotificationService statusService = (IEventStatusNotificationService)ApplicationBeanContextFactory.getBean(serviceHandler);
    		statusService.started(eventRef);
    		if(jobStatus.equals(SchedulerConstants.JOB_STATUS.SKIPPED)){
    			updateEndStatus(context, null, SchedulerConstants.JOB_STATUS.SKIPPED);    		
    		}
    	}
    	return histId;
	}
	private void updateEndStatus(JobExecutionContext context, Throwable exception, SchedulerConstants.JOB_STATUS jobStatus){
		
		String triggerName = context.getTrigger().getKey().getName();
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("triggerName ="+triggerName);
		
		JobDataMap input  = context.getMergedJobDataMap();
		String eventName = input.getString(SchedulerConstants.PARAM_NAME_EVENT_NAME);
		String eventRef = input.getString(SchedulerConstants.PARAM_NAME_EVENT_REF);
		String serviceHandler = eventNotificationMap.get(eventName);
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("jobstatusnotification serviceHandler for eventName ="+eventName+" is ="+serviceHandler);
    	boolean isResubmissionFire = true;
    	if(triggerName.equals(""+eventRef)){
    		//Its not resubmission
    		isResubmissionFire = false;
    	}
		Date nextFire = context.getNextFireTime();
		boolean hasNextFire = false;
		if(nextFire != null){
			hasNextFire = true;
		}
		Long histId = (Long)context.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID);
		JobExecHistVO histVO = new JobExecHistVO();
		
		try{
			histVO.setJobHistId(new BigDecimal(histId));
			histVO.setJobStatus(jobStatus.getValue());
			Timestamp time = new Timestamp(new Date().getTime());
			histVO.setEndTime(time);
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("jobstatusnotification exception =" + exception + "<message->" + (exception == null ? "" : exception.getMessage()));
			if(exception != null && exception.getMessage() != null){
				String errorDesc = exception.getMessage();
				if(errorDesc.length()>2000){
					errorDesc = errorDesc.substring(0,2000);
				}
				histVO.setErrorDesc(errorDesc);
			}else if(exception != null){
				String errorDesc = exception.toString();
				if(errorDesc.length()>2000){
					errorDesc = errorDesc.substring(0,2000);
				}
				histVO.setErrorDesc(errorDesc);
			}
				
			schedulerDAO.updateAuditLogStatus(histVO);
			
			if(JOB_STATUS.FAILED.getValue().equals(jobStatus.getValue())){
				try{
					jobStatusMailService.sendJobStatusMail(histVO);
				}catch(Exception e){
					LOGGER.error("Exception while sending Job Status notification");
				}
			}	
			
			if(!isResubmissionFire && !hasNextFire){
				ScheduleInfoVO scheduleInfoVO = scheduleInfoDAO.getScheduleInfo(""+eventRef);
				//FO 7.0 Fortify Issue Fix
				//LOGGER.debug("scheduleInfoVO.getStartDate()-->" + scheduleInfoVO.getStartDate());
				//LOGGER.debug("Current Date-->" + new Date());
				if((SchedulerConstants.JOB_TYPE_ADHOC.equals(scheduleInfoVO.getJobType()) && scheduleInfoVO.getStartDate().before(new Date())) || (!SchedulerConstants.JOB_TYPE_ADHOC.equals(scheduleInfoVO.getJobType()))){
				schedulerDAO.updateJobCompletionStatus(eventRef);
			}
			}
			if(isResubmissionFire){//resubmit adhoc for event, then nextfire will there.
				String jobCompStatus = schedulerDAO.getJobCompletionStatus(""+eventRef);
				if(!SchedulerConstants.JOB_COMPLETION_STATUS.equalsIgnoreCase(jobCompStatus)){
					hasNextFire = true;
				}
			}
		}catch(DBException e){
			LOGGER.error("update auditlog failed for histId="+histId);
		}

		if(serviceHandler!=null && !"".equals(serviceHandler)){
			IEventStatusNotificationService statusService = (IEventStatusNotificationService)ApplicationBeanContextFactory.getBean(serviceHandler);
			statusService.endStatus(eventRef, jobStatus.getValue(), exception, hasNextFire);
		}
	}
}
