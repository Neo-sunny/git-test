/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14 Feb 2012
 * 
 * Purpose: Job Monitoring Service Implementation  
 * 
 * Change History: 
 * Date                             Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 25 Apr 2012                      Ramesh A                              Initial Version
 * 22 Jun 2015						Anupriya P																	FO 8.0 export changes
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.service;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.dao.JobMonitoringDAO;
import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.scheduler.vo.JobHistoryVO;
import com.bnp.scm.scheduler.vo.ScheduleVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

@Component
public class JobMonitoringServiceImpl implements JobMonitoringService {

	private static final Logger LOGGER = LoggerFactory.getLogger(JobMonitoringServiceImpl.class);
	
	@Autowired
	private JobMonitoringDAO jobMonitoringDAO;
	@Autowired
	private JobValidatorService jobService;

	@Autowired
	private AbstractSchedulerService schedulerService;
	
	@Override
	public List<JobHistoryVO> getJobExecutionHist(JobHistoryVO jobHistoryVO) throws BNPApplicationException {
		return jobMonitoringDAO.getJobExecutionHist(jobHistoryVO);
	}

	@Override
	public List<NameValueVO> getJobNames() throws BNPApplicationException {
		return jobMonitoringDAO.getJobNames();
	}

	@Override
	public List<NameValueVO> getJobTypes() throws BNPApplicationException {
		return jobMonitoringDAO.getJobTypes();
	}

	@Override
	public List<NameValueVO> getJobStatusList() throws BNPApplicationException {
		return jobMonitoringDAO.getJobStatusList();
	}

	public Timestamp getCurrentSystemDate() throws BNPApplicationException {
		return jobMonitoringDAO.getCurrentSystemDate();
	}

	@Override
	public List<NameValueVO> getJobInput(String jobRefId) throws BNPApplicationException {
		return jobMonitoringDAO.getJobInput(jobRefId);
	}

	@Override
	public void resubmitJob(JobHistoryVO jobHistoryVO) throws BNPApplicationException{
		ScheduleVO scheduleVO = new ScheduleVO();
		Timestamp ts = jobMonitoringDAO.getCurrentSystemDate();
		Map<String,String> input = parseJobInput(jobHistoryVO.getJobInput());
		scheduleVO.setInput(input);
		scheduleVO.setJobType(SchedulerConstants.JOB_TYPE_ADHOC);
		scheduleVO.setEventName(jobHistoryVO.getJobName());
		scheduleVO.setOriginalEventRef(jobHistoryVO.getJobRefId());
		//scheduleVO.setScheduleTimeZoneId(jobHistoryVO.getTimeZone());
		
		scheduleVO.setStartDate(ts);
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("ts"+ ts);
		//LOGGER.debug(	"ts11111111"+new Date(ts.getTime()+(60000)));
		scheduleVO.setEndDate(new Date(ts.getTime()+(60000)));
		schedulerService.scheduleAdhocJobs(scheduleVO);
	}
	
	public Map<String,String> parseJobInput(String jobInput){
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("parseJobInput - jobInput :" + jobInput);
		Map<String,String> jobInputMap = new HashMap<String, String>();
		StringTokenizer inputToken = new StringTokenizer(jobInput,"\n");
		while(inputToken.hasMoreElements()){
			String inputVaule = ((String)inputToken.nextElement()).replace("\r", "");
			StringTokenizer input = new StringTokenizer(inputVaule,":");
			if(input.hasMoreElements()){
				String key = (String)input.nextElement();
				String value = input.hasMoreElements() ? (String)input.nextElement() : null;
				jobInputMap.put(key,value);
			}
		}
		//976332 CSCDEV-2683 20-NOV-2014:START
		//LOGGER.debug("parseJobInput - jobInputMap :" + jobInputMap);
		LOGGER.debug("parseJobInput - jobInputMap :");
		//976332 CSCDEV-2683 20-NOV-2014:END
		return jobInputMap;
	}

	@Override
	public String getUserPrefTimeZone(String userId)
			throws BNPApplicationException {
		String strTZ=null;
	try
	{
		
		strTZ =jobMonitoringDAO.getUserPrefTimeZone(userId);
		
	}catch (BNPApplicationException e) {
		throw e;
	}
	return strTZ;
	}
	
	public int getSearchDataCount(JobHistoryVO jobHistoryVO) throws BNPApplicationException{
		return jobMonitoringDAO.getSearchDataCount(jobHistoryVO);
	}
}
