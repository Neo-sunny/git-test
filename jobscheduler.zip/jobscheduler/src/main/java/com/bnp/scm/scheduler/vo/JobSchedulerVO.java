/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Apr 2012
 * 
 * Purpose: Job Scheduler Value Object
 * 
 * Change History: 
 * Date                             Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 25 Apr 2012                      Ramesh A                              Initial Version
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.vo;

import java.util.Date;
import java.util.List;

import com.bnp.scm.services.common.vo.AbstractVO;

public class JobSchedulerVO extends AbstractVO{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4876977840154119857L;

	private String jobRef;
	private String jobType;
	private String schBranch;
	private String schOrgId;
	private String jobName;
	private String jobDesc;
	private boolean activeStatusFlag;
	private String activeStatus;
	private String timeZone;
	private Date schEffectiveDate;
	private Date schExpiryDate;
	private List<String> selectedMonth;
	private List<String> selectedDayofMonth;
	private List<String> selectedWeekDay;
	private List<String> selectedHours;
	private List<String> selectedMins;
	private String ccy;
	private String pymtMethod;
	private String customparam;
	private String schStatus;
	private String schError;
	private String schMonth;
	private String schDayofMonth;
	private String schWeekDay;
	private String schHours;
	private String schMins;
	private boolean branchRequired;
	private boolean orgIdRequired;
	private boolean ccyRequired;
	private boolean pymtMethodRequired;
	private boolean custParamRequired;
	private String timeZoneId;
	private String statusDescription;
	private String branchDesc;
	private String timeZoneParam;
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public JobSchedulerVO(){
		this.schBranch = "";
		this.schOrgId = "";
		this.ccy = "";
		this.pymtMethod = "";
	}
	
	public String getJobRef() {
		return jobRef;
	}

	public void setJobRef(String jobRef) {
		this.jobRef = jobRef;
	}

	public String getJobType() {
		return jobType;
	}

	public void setJobType(String jobType) {
		this.jobType = jobType;
	}

	public String getSchBranch() {
		return schBranch;
	}

	public void setSchBranch(String schBranch) {
		this.schBranch = schBranch;
	}

	public String getSchOrgId() {
		return schOrgId;
	}

	public void setSchOrgId(String schOrgId) {
		this.schOrgId = schOrgId;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getJobDesc() {
		return jobDesc;
	}

	public void setJobDesc(String jobDesc) {
		this.jobDesc = jobDesc;
	}

	public boolean isActiveStatusFlag() {
		return activeStatusFlag;
	}

	public void setActiveStatusFlag(boolean activeStatusFlag) {
		this.activeStatusFlag = activeStatusFlag;
	}

	public String getActiveStatus() {
		return activeStatus;
	}

	public void setActiveStatus(String activeStatus) {
		this.activeStatus = activeStatus;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public Date getSchEffectiveDate() {
		return schEffectiveDate;
	}

	public void setSchEffectiveDate(Date schEffectiveDate) {
		this.schEffectiveDate = schEffectiveDate;
	}

	public Date getSchExpiryDate() {
		return schExpiryDate;
	}

	public void setSchExpiryDate(Date schExpiryDate) {
		this.schExpiryDate = schExpiryDate;
	}

	public List<String> getSelectedMonth() {
		return selectedMonth;
	}

	public void setSelectedMonth(List<String> selectedMonth) {
		this.selectedMonth = selectedMonth;
	}

	public List<String> getSelectedDayofMonth() {
		return selectedDayofMonth;
	}

	public void setSelectedDayofMonth(List<String> selectedDayofMonth) {
		this.selectedDayofMonth = selectedDayofMonth;
	}

	public List<String> getSelectedWeekDay() {
		return selectedWeekDay;
	}

	public void setSelectedWeekDay(List<String> selectedWeekDay) {
		this.selectedWeekDay = selectedWeekDay;
	}

	public List<String> getSelectedHours() {
		return selectedHours;
	}

	public void setSelectedHours(List<String> selectedHours) {
		this.selectedHours = selectedHours;
	}

	public List<String> getSelectedMins() {
		return selectedMins;
	}

	public void setSelectedMins(List<String> selectedMins) {
		this.selectedMins = selectedMins;
	}

	public String getCcy() {
		return ccy;
	}

	public void setCcy(String ccy) {
		this.ccy = ccy;
	}

	public String getPymtMethod() {
		return pymtMethod;
	}

	public void setPymtMethod(String pymtMethod) {
		this.pymtMethod = pymtMethod;
	}

	public String getCustomparam() {
		return customparam;
	}

	public void setCustomparam(String customparam) {
		this.customparam = customparam;
	}

	public String getSchStatus() {
		return schStatus;
	}

	public void setSchStatus(String schStatus) {
		this.schStatus = schStatus;
	}

	public String getSchError() {
		return schError;
	}

	public void setSchError(String schError) {
		this.schError = schError;
	}

	public String getSchMonth() {
		return schMonth;
	}

	public void setSchMonth(String schMonth) {
		this.schMonth = schMonth;
	}

	public String getSchDayofMonth() {
		return schDayofMonth;
	}

	public void setSchDayofMonth(String schDayofMonth) {
		this.schDayofMonth = schDayofMonth;
	}

	public String getSchWeekDay() {
		return schWeekDay;
	}

	public void setSchWeekDay(String schWeekDay) {
		this.schWeekDay = schWeekDay;
	}

	public String getSchHours() {
		return schHours;
	}

	public void setSchHours(String schHours) {
		this.schHours = schHours;
	}

	public String getSchMins() {
		return schMins;
	}

	public void setSchMins(String schMins) {
		this.schMins = schMins;
	}

	public String getStatusDescription() {
		return statusDescription;
	}

	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}

	public boolean isBranchRequired() {
		return branchRequired;
	}

	public void setBranchRequired(boolean branchRequired) {
		this.branchRequired = branchRequired;
	}

	public boolean isOrgIdRequired() {
		return orgIdRequired;
	}

	public void setOrgIdRequired(boolean orgIdRequired) {
		this.orgIdRequired = orgIdRequired;
	}

	public boolean isCcyRequired() {
		return ccyRequired;
	}

	public void setCcyRequired(boolean ccyRequired) {
		this.ccyRequired = ccyRequired;
	}

	public boolean isPymtMethodRequired() {
		return pymtMethodRequired;
	}

	public void setPymtMethodRequired(boolean pymtMethodRequired) {
		this.pymtMethodRequired = pymtMethodRequired;
	}

	public boolean isCustParamRequired() {
		return custParamRequired;
	}

	public void setCustParamRequired(boolean custParamRequired) {
		this.custParamRequired = custParamRequired;
	}

	public String getTimeZoneId() {
		return timeZoneId;
	}

	public void setTimeZoneId(String timeZoneId) {
		this.timeZoneId = timeZoneId;
	}

	public String getBranchDesc() {
		return branchDesc;
	}

	public void setBranchDesc(String branchDesc) {
		this.branchDesc = branchDesc;
	}

	public String getTimeZoneParam() {
		return timeZoneParam;
	}

	public void setTimeZoneParam(String timeZoneParam) {
		this.timeZoneParam = timeZoneParam;
	}
}
