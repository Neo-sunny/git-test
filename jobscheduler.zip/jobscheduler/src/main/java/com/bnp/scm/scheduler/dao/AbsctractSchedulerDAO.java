package com.bnp.scm.scheduler.dao;

import java.util.Map;

import com.bnp.scm.services.common.exception.DBException;

public interface AbsctractSchedulerDAO {
	Map<String,String> getInput(String eventRef) throws DBException;
}
