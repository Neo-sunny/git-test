package com.bnp.scm.scheduler.dao;

import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.vo.JobConfigVO;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.ibatis.sqlmap.client.SqlMapClient;

@Component

public class JobConfigDAOImpl extends SqlMapClientWrapper implements JobConfigDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(JobConfigDAOImpl.class);
	
	private static final String SELECT_JOBCONFIG_BY_EVENT_NAME ="JobConfigNS.selectJobConfigByEventName";
	private static final String SELECT_JOBCONFIG_BY_ACTIONFLAG ="JobConfigNS.selectJobConfigByActionFlag";
	private static final String UPDATE_JOBCONFIG_ACTIONFLAG ="JobConfigNS.updateActionFlagAsEmpty";
	private static final String DELETE_JOBCONFIG ="JobConfigNS.deleteJobConfig";
	
    public JobConfigVO getJobConfiguration(String eventName) throws DBException{
    	JobConfigVO jobConfigVO;
    	try{
    		jobConfigVO = (JobConfigVO)getSqlMapClientTemplate().queryForObject(SELECT_JOBCONFIG_BY_EVENT_NAME,eventName);
    	}
    	catch(DataAccessException exp){
    		LOGGER.error("method:getJobConfiguration"+exp.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_FETCH);
    	}
    	return jobConfigVO;
    }
    public List<JobConfigVO> getJobConfigByActionFlag(String actionFlag)throws DBException{
    	List<JobConfigVO> jobConfigList;
    	try{
    		jobConfigList = getSqlMapClientTemplate().queryForList(SELECT_JOBCONFIG_BY_ACTIONFLAG,actionFlag);
    	}
    	catch(DataAccessException exp){
    		//976332 CSCDEV-2683 17-NOV-2014:START
    		//exp.printStackTrace();
    		//976332 CSCDEV-2683 17-NOV-2014:END
    		LOGGER.error("method:getJobConfigByActionFlag"+exp.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_FETCH);
    	}
    	return jobConfigList;
    	
    }
    public void updateActionFlagAsEmpty(long jobId)throws DBException{
    	try{
    		getSqlMapClientTemplate().update(UPDATE_JOBCONFIG_ACTIONFLAG,jobId);
    	}
    	catch(DataAccessException exp){
    		LOGGER.error("method:updateActionFlagAsEmpty"+exp.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_UPDATE);
    	}
    	
    }
    public void deleteJob(List<Long> jobIdList)throws DBException{
    	try{
    		SqlMapClient sqlMapClient = getSqlMapClient();
    		sqlMapClient.startBatch();
    		for(Long jobId:jobIdList){
    			getSqlMapClientTemplate().delete(DELETE_JOBCONFIG,jobId);
    		}
    		sqlMapClient.executeBatch();
    	}
    	catch(DataAccessException exp){
    		LOGGER.error("method:deleteJob"+exp.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_DELETE);
    	}catch(SQLException e){
    		LOGGER.error("method:deleteJob"+e.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_DELETE);
    	}
    }

}
