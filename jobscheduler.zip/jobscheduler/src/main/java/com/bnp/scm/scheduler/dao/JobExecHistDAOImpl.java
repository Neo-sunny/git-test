package com.bnp.scm.scheduler.dao;


import java.math.BigDecimal;

import com.bnp.scm.scheduler.vo.JobExecHistVO;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

@Component
public class JobExecHistDAOImpl extends SqlMapClientWrapper implements JobExecHistDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(JobExecHistDAOImpl.class);
	
	private static final String INSERT = "JobExecHistNS.insert";
	private static final String UPDATE_STATUS = "JobExecHistNS.updateStatus";
	private static final String GET_JOB_HISTORY_DETAIL = "JobExecHistNS.getJobHistoryDetail";
	
	@Override
	public BigDecimal insert(JobExecHistVO record) throws DBException{
		BigDecimal pkValue = null;
    	try{
    		pkValue = (BigDecimal) getSqlMapClientTemplate().insert(INSERT, record);
    	}catch(DataAccessException e){
    		LOGGER.error("error in inserting data::"+e.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_INSERT);
    	}
    	return pkValue;
	}
	
	@Override
    public void updateStatus(JobExecHistVO record) throws DBException{
    	try{
    		  getSqlMapClientTemplate().update(UPDATE_STATUS, record);
    	}catch(DataAccessException e){
    		LOGGER.error("error in updateStatus data::"+e.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_UPDATE);
    	}
    }

	@Override
    public JobExecHistVO getJobHistoryDetail(JobExecHistVO jobExecHistVO) throws DBException{
    	try{
    		return (JobExecHistVO)getSqlMapClientTemplate().queryForObject(GET_JOB_HISTORY_DETAIL, jobExecHistVO.getJobHistId());
    	}catch(DataAccessException e){
    		LOGGER.error("error in updateStatus data::"+e.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_UPDATE);
    	}
    }
}
