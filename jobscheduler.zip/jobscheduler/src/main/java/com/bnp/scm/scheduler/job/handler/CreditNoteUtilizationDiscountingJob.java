package com.bnp.scm.scheduler.job.handler;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;

@Component
public class CreditNoteUtilizationDiscountingJob extends AbstractJob {

	@Override
	public void run(Map<String, String> arg0) throws SchedulerException {
		
	}
}
