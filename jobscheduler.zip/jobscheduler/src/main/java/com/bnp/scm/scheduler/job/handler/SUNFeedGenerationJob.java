/********************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   11 May 2017
 * 
 * Purpose: JIRA CSC 6786 Sun Screening Requirements
 * 
 * Change History: 
 * Date                             Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 11 May 2017                     OFSS                              Sun Feed Generation
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.job.handler;

import java.util.Map;
import java.util.StringTokenizer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.service.JobHandlerService;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;
import com.bnp.scm.services.scheduler.events.IEvent;
import com.bnp.scm.services.scheduler.exception.BNPSchedulerException;
import com.bnp.scm.services.scheduler.events.SunFeedGenerationEvent;

@Component
public class SUNFeedGenerationJob extends AbstractJob {

	public static final Logger LOGGER = LoggerFactory.getLogger(SUNFeedGenerationJob.class);
	
	@Autowired
	JobHandlerService jobHandlerService;
	
	private void loggerMsg(String msg){
		LOGGER.debug(msg);
	}
	
	@Override
	public void run(Map<String, String> inputMap) throws SchedulerException {
		
		//System.out.println("SUNFeedGenerationJob run Method Begins");
		LOGGER.debug("SUNFeedGenerationJob run Method Begins");
		
		//System.out.println("inputMap : " + inputMap.toString());
		LOGGER.debug("inputMap : " + inputMap.toString());
		
		String branchId = inputMap.get(SchedulerConstants.PARAM_NAME_BRANCH_ID);
		LOGGER.debug("branchId : " + branchId);
		//System.out.println("branchId : " + branchId);
		
		String eventName = inputMap.get(SchedulerConstants.PARAM_NAME_EVENT_NAME);
		LOGGER.debug("eventName : " + eventName);
		//System.out.println("eventName : " + eventName);

		String eventRef = inputMap.get(SchedulerConstants.PARAM_NAME_EVENT_REF);
		LOGGER.debug("eventRef : " + eventRef);
		//System.out.println("eventRef : " + eventRef);

		String regionCode = inputMap.get(SchedulerConstants.PARAM_NAME_CUSTOM_PARAM);
		LOGGER.debug("regionCode : " + regionCode);
		//System.out.println("regionCode : " + regionCode);
		StringTokenizer st = new StringTokenizer(regionCode, ",");
		
		String strRegionCode = null; 
		
        if(st.hasMoreElements()){
        	strRegionCode = st.nextToken();
            LOGGER.debug("RegionCode = " + strRegionCode);
        }
		
		String jobHistID = inputMap.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID);
		LOGGER.debug("jobHistID  : " + jobHistID);
		//System.out.println("jobHistID : " + jobHistID);
		
		IEvent iEvent = (IEvent)ApplicationBeanContextFactory.getBean(SunFeedGenerationEvent.class); 
		try {
			
			LOGGER.debug("SUNFeedGenerationJob run Method before processEvent Call");
			//System.out.println("SUNFeedGenerationJob run Method before processEvent Call");
			
			if(strRegionCode != null && jobHistID != null){

				String[] arg = new String[2];
				
				arg[0] = strRegionCode;
				arg[1] = jobHistID;
			
				iEvent.processEvent(arg);
				
			}else{
				
				throw new BNPSchedulerException(" | SUNFeedGenerationJob run Method Exception processEvent cannot be executed - Either Region Code (or) Job History ID is NULL | ");
			}
				
			LOGGER.debug("SUNFeedGenerationJob run Method after processEvent Call");
			//System.out.println("SUNFeedGenerationJob run Method after processEvent Call");
			
		}catch (BNPSchedulerException e) {
			
			//System.out.println("SUNFeedGenerationJob run Method Exception after processEvent Call");
			LOGGER.debug("SUNFeedGenerationJob run Method Exception after processEvent Call");
			LOGGER.error(e.getMessage(), e);
			throw new SchedulerException(" | SUNFeedGenerationJob run Method Exception after processEvent Call | " + e.getMessage());
			
		}finally {
			iEvent = null;
		}
		
		//System.out.println("SUNFeedGenerationJob run Method Ends");
		LOGGER.debug("SUNFeedGenerationJob run Method Ends");
	}
}
