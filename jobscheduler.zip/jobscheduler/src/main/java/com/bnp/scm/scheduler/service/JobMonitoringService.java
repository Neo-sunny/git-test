/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14 Feb 2012
 * 
 * Purpose: Job Monitoring Service  
 * 
 * Change History: 
 * Date                             Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 25 Apr 2012                      Ramesh A                              Initial Version
 * 22 Jun 2015						Anupriya P																	FO 8.0 export changes
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.service;

import java.sql.Timestamp;
import java.util.List;

import com.bnp.scm.scheduler.vo.JobHistoryVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

public interface JobMonitoringService{
	List<JobHistoryVO> getJobExecutionHist(JobHistoryVO jobHistoryVO)throws BNPApplicationException;
	List<NameValueVO> getJobNames()throws BNPApplicationException;
	List<NameValueVO> getJobTypes() throws BNPApplicationException;
	List<NameValueVO> getJobStatusList()throws BNPApplicationException;
	Timestamp getCurrentSystemDate() throws BNPApplicationException;
	List<NameValueVO> getJobInput(String jobRefId) throws BNPApplicationException;
	void resubmitJob(JobHistoryVO jobHistoryVO) throws BNPApplicationException;
	String getUserPrefTimeZone(String userId)throws BNPApplicationException;
	int getSearchDataCount(JobHistoryVO jobHistoryVO) throws BNPApplicationException;
}
