package com.bnp.scm.scheduler.job.handler;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.report.IScheduleReportService;

public class PurgeReportsJob extends AbstractJob{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PurgeReportsJob.class);

	private @Autowired IScheduleReportService scheduleReportService;
	
	public void run(Map<String,String> input) throws SchedulerException{
		LOGGER.debug("enter run");
		try{
			scheduleReportService.purgeGeneratedReports();
		}catch(BNPApplicationException e){
			LOGGER.error("exception in processing="+e);
		}
		LOGGER.debug("exit run");
	}
	
}
