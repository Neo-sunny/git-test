/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   06 Mar 2011
 * 
 * Purpose:      Bank code  DAO Impl 
 * 
 * Change History: 
 * Date                                                  Author                                                 Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 06 Mar 2012                      Oracle Financial Services Software Ltd                                    Initial Version 
 *                                  										
 *****************************************************************************************************************************************************************/
package com.bnp.scm.scheduler;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.quartz.CronScheduleBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.scheduler.util.SchedulerConstants.DAYS;
import com.bnp.scm.scheduler.vo.ScheduleVO;
import com.bnp.scm.services.common.BNPMonth;

public class SchedulerExpressionBuilder {

	private static final Logger LOGGER = LoggerFactory.getLogger(SchedulerExpressionBuilder.class);
	
	private static final String MONTH_LIST_29 = "FEB";//only Feb
	private static final String MONTH_LIST_29_COM = "JAN,MAR,APR,MAY,JUN,JUL,AUG,SEP,OCT,NOV,DEC";//only Feb
	private static final String MONTH_LIST_30 = "FEB,APR,JUN,SEP,NOV";//only 30
	private static final String MONTH_LIST_30_COMP = "JAN,MAR,MAY,JUL,AUG,OCT,DEC";//only 30 months
	
	private SchedulerExpressionBuilder(List<Trigger> triggerList){
		this.triggerList=triggerList;
	}
	
	private List<Trigger> triggerList;
	
	public List<Trigger> getTrigger() {
		return triggerList;
	}

	
	static public  SchedulerExpressionBuilder build(ScheduleVO scheduleVO, String triggerName, String triggerGroup, JobDetail jobDetail, JobDataMap jobDataMap) throws SchedulerException{
		List<Trigger> triggerList = new ArrayList<Trigger>();
		Trigger trigger = null;
		try{
			String[] minis = scheduleVO.getMinis();
			String[] hours = scheduleVO.getHours();
			DAYS[] days = scheduleVO.getDays();
			String[] monthOfDay = scheduleVO.getMonthOfDay();
			String[] months = scheduleVO.getMonths();
			
			String timeZoneId = scheduleVO.getScheduleTimeZoneId();
			TimeZone timeZoneIn = null;
			if(timeZoneId == null){
				timeZoneIn = TimeZone.getDefault();
			}else{
				timeZoneIn = TimeZone.getTimeZone(timeZoneId);
			}

			boolean isFebExists = false;
			StringBuilder monthList = new StringBuilder("");
			if(months != null){
				for(String month : months){
					if(monthList.length() != 0){
						monthList.append(",");
					}
					monthList.append(month);
					if(MONTH_LIST_29.equals(month)){
						isFebExists = true;
					}
				}
			}	
			
			Date startDate = convertedDate(timeZoneIn, scheduleVO.getStartDate(), true);
			Date endDate = convertedDate(timeZoneIn, scheduleVO.getEndDate(), false);
			boolean needCronExp = false;
			boolean needFireOnce = false;
			if((days!=null && days.length>0) && (monthOfDay!=null && monthOfDay.length>0)){//Both cant be set
				throw new SchedulerException(SchedulerConstants.ERROR_DAY_MONTH_OF_DAY_ENTERED,"ERROR_DAY_MONTH_OF_DAY_ENTERED");
			}else if(minis !=null && minis.length > 0 && hours!=null && hours.length > 0 && ((days!=null && days.length>0) || (monthOfDay!=null && monthOfDay.length>0))){
				needCronExp = true;
				//all have been entered
			}else if((minis ==null || minis.length == 0) && (hours==null || hours.length == 0) && (days==null || days.length==0) && (monthOfDay==null || monthOfDay.length==0)){
				//Nothing entered, so fire once
				needFireOnce = true;
			}else{
				//Any one of the array is not null. And its not allowed
				throw new SchedulerException(SchedulerConstants.ERROR_CODE_INPUT_MISSING,"ERROR_CODE_INPUT_MISSING");
			}
			if(needCronExp){
				StringBuilder sb = new StringBuilder();
				StringBuilder sbNew =null;
				sb.append("0 ");//appending seconds;
				String comma = "";
				//start of minis
				for(String k:minis){
					sb.append(comma);
					sb.append(k);
					comma=",";
				}
				sb.append(" ");
				//end of minis
				
				//start of hours
				comma="";
				for(String k:hours){
					sb.append(comma);
					sb.append(k);
					comma=",";
				}
				sb.append(" ");
				//end of hours
				comma="";
				if(monthOfDay != null && monthOfDay.length>0){
					/*for(String k:monthOfDay){
						sb.append(comma);
						sb.append(k);
						comma=",";
					}
					sb.append(" * ?");*/
					if(monthOfDay.length ==1 && !"*".equals(monthOfDay[0])){//only one month of day, we have to handle 29,30 issue
						int dayMonth = Integer.parseInt(monthOfDay[0]);
						if(months == null || (months.length == 1 && BNPMonth.ALLMONTH.getValue().equals(months[0]))){
							if(dayMonth == 29){
								sbNew = new StringBuilder();
								sbNew.append(sb.toString());
								sbNew.append("L ").append(MONTH_LIST_29).append(" ?");
								sb.append("29 ").append(MONTH_LIST_29_COM).append(" ?");
							}else if(dayMonth == 30){
								sbNew = new StringBuilder();
								sbNew.append(sb.toString());
								sbNew.append("L ").append(MONTH_LIST_30).append(" ?");
								sb.append("30 ").append(MONTH_LIST_30_COMP).append(" ?");
							}else if(dayMonth == 31){
								sb.append("L * ?");
							}else{
								for(String k:monthOfDay){
									sb.append(comma);
									sb.append(k);
									comma=",";
								}
								sb.append(" * ?");
							}
						}else{
							if(dayMonth == 29){
								if(isFebExists){
									sbNew = new StringBuilder();
									sbNew.append(sb.toString());
									sbNew.append("L ").append(MONTH_LIST_29).append(" ?");
								}	
								sb.append("29 ");
								sb.append(monthList.toString());
								sb.append(" ?");
							}else if(dayMonth == 30){
								sb.append("30 ");
								sb.append(monthList.toString());
								sb.append(" ?");
							}else if(dayMonth == 31){
								sb.append("L ");
								sb.append(monthList.toString());
								sb.append(" ?");
							}else{
								for(String k:monthOfDay){
									sb.append(comma);
									sb.append(k);
									comma=",";
								}
								sb.append(" ");
								sb.append(monthList.toString());
								sb.append(" ?");
							}
						}
					}else{
						if(months == null || (months.length == 1 && BNPMonth.ALLMONTH.getValue().equals(months[0]))){
							for(String k:monthOfDay){
								sb.append(comma);
								sb.append(k);
								comma=",";
							}
							sb.append(" * ?");
						}else{
							for(String k:monthOfDay){
								sb.append(comma);
								sb.append(k);
								comma=",";
							}
							sb.append(" ");
							sb.append(monthList.toString());
							sb.append(" ?");
						}
					}
				}else{
					if(months == null || (months.length == 1 && BNPMonth.ALLMONTH.getValue().equals(months[0]))){
						sb.append("? * ");
						comma="";
						for(DAYS day:days){
							sb.append(comma);
							sb.append(day.getValue());
							comma=",";
						}
					}else{
						sb.append("? ");
						sb.append(monthList.toString());
						sb.append(" ");
						comma="";
						for(DAYS day:days){
							sb.append(comma);
							sb.append(day.getValue());
							comma=",";
						}
					}
				}
				//sb.append(" *"); Year. Its optional
				
				//FO 7.0 Fortify Issue Fix
				//LOGGER.debug("expre ="+sb.toString());
				
						
				/*CronScheduleBuilder cronbuild = CronScheduleBuilder.cronSchedule(sb.toString()).inTimeZone(timeZoneIn);
				if(scheduleVO.getMisfireInst() == 1){
					cronbuild = cronbuild.withMisfireHandlingInstructionFireAndProceed();
				}else{
					cronbuild = cronbuild.withMisfireHandlingInstructionIgnoreMisfires();
				}
				
				TriggerBuilder<Trigger> triggerBuilder = buildTriggerBuilder(triggerName, triggerGroup, startDate, endDate, jobDetail, jobDataMap, scheduleVO.getJobPirority());
				trigger = triggerBuilder.withSchedule(cronbuild).build();*/
				trigger = buildTrigger(sb.toString(),timeZoneIn,triggerName,triggerGroup,startDate,endDate,jobDetail,jobDataMap,scheduleVO);
				triggerList.add(trigger);
				if(sbNew != null){
					//FO 7.0 Fortify Issue Fix
					//LOGGER.debug("expreNew ="+sbNew.toString());
					trigger = buildTrigger(sbNew.toString(),timeZoneIn,triggerName,triggerName,startDate,endDate,jobDetail,jobDataMap,scheduleVO);
					triggerList.add(trigger);
				}
				
			}else if(needFireOnce){
				TriggerBuilder<Trigger> triggerBuilder = buildTriggerBuilder(triggerName, triggerGroup, startDate, endDate, jobDetail, jobDataMap, scheduleVO.getJobPirority());
				
				SimpleScheduleBuilder simpleScheduleBuilder = SimpleScheduleBuilder.simpleSchedule().withRepeatCount(0).withIntervalInSeconds(1);
				if(scheduleVO.getJobPirority() == 1){
					simpleScheduleBuilder.withMisfireHandlingInstructionFireNow();
				}else{
					simpleScheduleBuilder.withMisfireHandlingInstructionNextWithExistingCount();
				}
				
				trigger = triggerBuilder.withSchedule(simpleScheduleBuilder).build();
				triggerList.add(trigger);
			}
		}catch(ParseException e){
			throw new SchedulerException(e.getMessage(), e);
		}
		return new SchedulerExpressionBuilder(triggerList);
	}
	
	private static TriggerBuilder<Trigger> buildTriggerBuilder(String triggerName, String triggerGroup,Date startDate,Date endDate, JobDetail jobDetail, JobDataMap jobDataMap, int jobPriority){
		TriggerBuilder<Trigger> triggerBuilder = TriggerBuilder.newTrigger().withIdentity(triggerName, triggerGroup).usingJobData(jobDataMap).withPriority(jobPriority);
		if(jobDetail != null){
			triggerBuilder = triggerBuilder.forJob(jobDetail);
		}
		if(startDate != null){
			triggerBuilder = triggerBuilder.startAt(startDate);
		}else{
			triggerBuilder = triggerBuilder.startNow();
		}
		if(endDate != null){
			triggerBuilder = triggerBuilder.endAt(endDate);
		}
		return triggerBuilder;
	}
	
	static public Date convertedDate(TimeZone timeZoneIn,Date date, boolean isForStartDate) throws ParseException{
		if(date == null){
			return null;
		}
		Date newDate = null;
		if(timeZoneIn == null){
			timeZoneIn = TimeZone.getDefault();
		}
		
		SimpleDateFormat formatForDate = null;
		if(isForStartDate){
			formatForDate = new SimpleDateFormat("dd-MM-yyyy HH mm ss");
		}else{
			formatForDate = new SimpleDateFormat("dd-MM-yyyy");
		}
		String formattedDate = formatForDate.format(date);
		
		SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy HH mm ss");
		format.setTimeZone(timeZoneIn);
		if(isForStartDate){
			newDate = format.parse(formattedDate+" 00 00 00");
		}else{
			newDate = format.parse(formattedDate+" 23 59 59");	
		}
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("newDate =" + newDate);
		return newDate;
	}
	
	static Trigger buildTrigger(String cronExp, TimeZone timeZoneIn,String triggerName,String triggerGroup, Date startDate, Date endDate, JobDetail jobDetail, JobDataMap jobDataMap, ScheduleVO scheduleVO ) throws ParseException{
		CronScheduleBuilder cronbuild = CronScheduleBuilder.cronSchedule(cronExp).inTimeZone(timeZoneIn);
		if(scheduleVO.getMisfireInst() == 1){
			cronbuild = cronbuild.withMisfireHandlingInstructionFireAndProceed();
		}else{
			cronbuild = cronbuild.withMisfireHandlingInstructionDoNothing();
		}
		
		TriggerBuilder<Trigger> triggerBuilder = buildTriggerBuilder(triggerName, triggerGroup, startDate, endDate, jobDetail, jobDataMap, scheduleVO.getJobPirority());
		Trigger trigger = triggerBuilder.withSchedule(cronbuild).build();
		return trigger;
	}
}
