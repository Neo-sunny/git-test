package com.bnp.scm.scheduler.job.handler;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.bnp.scm.services.common.vo.ThresholdLimitReminderVO;
import com.bnp.scm.services.discounting.ILimitUtilReportService;
import com.bnp.scm.services.scheduler.events.CPThresholdLimitEvent;
import com.bnp.scm.services.scheduler.events.EntityThresholdLimitEvent;
import com.bnp.scm.services.scheduler.events.GroupThresholdLimitEvent;
import com.bnp.scm.services.scheduler.events.IEvent;
import com.bnp.scm.services.scheduler.events.TPThresholdLimitEvent;
import com.bnp.scm.services.scheduler.exception.BNPSchedulerException;

@Component
public class ThresholdLimitcheckJob  extends AbstractJob {
	
	@Autowired
	private ILimitUtilReportService limitUtilReportService;
	
	public static final Logger LOGGER = LoggerFactory.getLogger(ThresholdLimitcheckJob.class);
	@Override
	public void run(Map<String, String> inputMap) throws SchedulerException {
	try{
		/*String  wasLocked= limitUtilReportService.checkLmtConcurrency(inputMap.get(SchedulerConstants.PARAM_NAME_BRANCH_ID));
		if(StringUtils.isEmpty(wasLocked) || !BNPConstants.YES.equals(wasLocked)){*/
		
		logMsg("ThresholdLimitcheckJob--Beg");
		try {
			String[] arg = new String[5];
			arg[0] = "";
			arg[1] = inputMap.get(SchedulerConstants.PARAM_NAME_BRANCH_ID);
			logMsg("ThresholdLimitcheckJob Parameter Brn Id" +inputMap.get(SchedulerConstants.PARAM_NAME_BRANCH_ID));
			arg[2] = inputMap.get(SchedulerConstants.PARAM_NAME_ORG_ID);
			logMsg(" ThresholdLimitcheckJob Parameter Org Id" +inputMap.get(SchedulerConstants.PARAM_NAME_ORG_ID));
			arg[3] = inputMap.get(SchedulerConstants.PARAM_NAME_CCY);
			logMsg(" ThresholdLimitcheckJob Parameter Job hist Id" +inputMap.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID));
			arg[4] = inputMap.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID);
			List<ThresholdLimitReminderVO> orgEventConf = limitUtilReportService.getEventConfigForOrgGroup(new NameValueVO());
			boolean entityEventFlg=false;
			boolean tpEventFlg=false;
			boolean cpEventFlg=false;
			boolean gpEventFlg=false;
			for(ThresholdLimitReminderVO thresholdVo : orgEventConf)
			{
				if(SchedulerConstants.THRESHOLD_ENTITY_BUYER_EVENT_NAME.equals(thresholdVo.getEventNameId()) || SchedulerConstants.THRESHOLD_ENTITY_SUPPLIER_EVENT_NAME.equals(thresholdVo.getEventNameId()) || SchedulerConstants.THRESHOLD_ENTITY_BRANCH_EVENT_NAME.equals(thresholdVo.getEventNameId())){
					entityEventFlg = true;	
				}
				if(SchedulerConstants.THRESHOLD_TP_BUYER_EVENT_NAME.equals(thresholdVo.getEventNameId()) || SchedulerConstants.THRESHOLD_TP_SUPPLIER_EVENT_NAME.equals(thresholdVo.getEventNameId()) || SchedulerConstants.THRESHOLD_TP_BRANCH_EVENT_NAME.equals(thresholdVo.getEventNameId())){
					tpEventFlg = true;	
				}
				if(SchedulerConstants.THRESHOLD_CP_BUYER_EVENT_NAME.equals(thresholdVo.getEventNameId()) || SchedulerConstants.THRESHOLD_CP_SUPPLIER_EVENT_NAME.equals(thresholdVo.getEventNameId()) || SchedulerConstants.THRESHOLD_CP_BRANCH_EVENT_NAME.equals(thresholdVo.getEventNameId())){
					cpEventFlg = true;	
				}
				if(SchedulerConstants.THRESHOLD_GP_BUYER_EVENT_NAME.equals(thresholdVo.getEventNameId()) || SchedulerConstants.THRESHOLD_GP_SUPPLIER_EVENT_NAME.equals(thresholdVo.getEventNameId()) || SchedulerConstants.THRESHOLD_GP_BRANCH_EVENT_NAME.equals(thresholdVo.getEventNameId())){
					gpEventFlg = true;	
				}
			}
			if(entityEventFlg) {((IEvent)ApplicationBeanContextFactory.getBean(EntityThresholdLimitEvent.class)).processEvent(arg);}
		 	if(tpEventFlg){((IEvent)ApplicationBeanContextFactory.getBean(TPThresholdLimitEvent.class)).processEvent(arg);}
		 	if(cpEventFlg){((IEvent)ApplicationBeanContextFactory.getBean(CPThresholdLimitEvent.class)).processEvent(arg);}
		 	if(gpEventFlg){((IEvent)ApplicationBeanContextFactory.getBean(GroupThresholdLimitEvent.class)).processEvent(arg);}
		}
		catch (BNPSchedulerException e) {
			throw new SchedulerException(e.errorCode,e.getMessage());
		}
		/*}else{
			try{
			String jobid =  discPymtService.getAutoDiscJobRef(SchedulerConstants.PARAM_NAME_JOB_HIST_ID);
			FileDetailsVO detailsVO = new FileDetailsVO();
			detailsVO.setBranchId(inputMap.get(SchedulerConstants.PARAM_NAME_BRANCH_ID));
			detailsVO.setSenderOrgId(inputMap.get(SchedulerConstants.PARAM_NAME_SENDER_ORG_ID));
			detailsVO.setFileId(Long.valueOf(inputMap.get(SchedulerConstants.PARAM_NAME_FILE_ID)));
			rescheduleAutoDisc(detailsVO,inputMap.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID));}
			catch (BNPApplicationException e) {
				LOGGER.error(e.getMessage(), e);
				throw new SchedulerException(e.errorCode,e.getMessage());
			}
		}*/
	}
		catch (BNPApplicationException e) {
			throw new SchedulerException(e.errorCode,e.getMessage());
		}
	}
	
	/*private void rescheduleAutoDisc(FileDetailsVO detailsVO,String jobHistId) throws BNPApplicationException{
		//String autoDiscReschInterval = bnpPropertyLoader.getValue("autodisc.reschesuling.interval");
		String autoDiscJobRef = discPymtService.getAutoDiscJobRef(jobHistId);
		if(autoDiscJobRef != null && !autoDiscJobRef.equals("")){
			String autoDiscReschInterval = limitUtilReportService.getRescheduleIntvl();
			ScheduleVO scheduleVO = new ScheduleVO();
			scheduleVO.setEventRef(autoDiscJobRef);
			Timestamp startDate = invoiceUploadDAO.getCurrentSystemDate();
			Calendar cal = Calendar.getInstance();
	        cal.setTimeInMillis(startDate.getTime());
	        cal.add(Calendar.MINUTE, Integer.valueOf(autoDiscReschInterval));
	        startDate = new Timestamp(cal.getTime().getTime());
			Map<String,String> input = getAutoDiscountingJobInput(detailsVO);
			scheduleVO.setInput(input);
			scheduleVO.setJobType(SchedulerConstants.JOB_TYPE_BRANCH);
			scheduleVO.setEventName("ThresholdLimitcheckJob");
			scheduleVO.setStartDate(startDate);
			scheduleVO.setEndDate(new Date(startDate.getTime()+(60000)));
			scheduleVO.setScheduleType(SCH_TYPE.SCHEDULED);
			schedulerService.rescheduleJob(scheduleVO);
		}
	}
	
	private Map<String,String> getAutoDiscountingJobInput(FileDetailsVO detailsVO){
		Map<String,String> jobInput = new HashMap<String, String>();
		jobInput.put(SchedulerConstants.PARAM_NAME_SENDER_ORG_ID, detailsVO.getSenderOrgId());
		jobInput.put(SchedulerConstants.PARAM_NAME_BRANCH_ID, detailsVO.getBranchId());
		jobInput.put(SchedulerConstants.PARAM_NAME_FILE_ID, String.valueOf(detailsVO.getFileId()));
		return jobInput;
	}*/
	
	private void logMsg(String msg){
		LOGGER.debug(msg);
	}

}
