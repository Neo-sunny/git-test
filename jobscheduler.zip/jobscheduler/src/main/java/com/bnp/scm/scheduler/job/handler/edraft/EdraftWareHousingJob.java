package com.bnp.scm.scheduler.job.handler.edraft;
/***********************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   12 aUG 2013	
 * 
 * Purpose:      EdraftWareHousingJob
 * 
 * Change History: 
 * Date                              Author                                  Reason 
 * --------------------------------------------------------------------------------------------------------- 
 02 Aug 2013						Merdith Silvester						CSC 663
 ***********************************************************************************************************/
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;
import com.bnp.scm.services.scheduler.edraft.EdraftWareHousingEvent;
import com.bnp.scm.services.scheduler.events.IEvent;
import com.bnp.scm.services.scheduler.exception.BNPSchedulerException;

@Component
public class EdraftWareHousingJob extends AbstractJob{
	public static final Logger LOGGER = LoggerFactory.getLogger(EdraftWareHousingJob.class);
	
	@Override
	public void run(Map<String, String> arg0) throws SchedulerException {
		IEvent iEvent = null;
		try
		{
			LOGGER.debug("Entered run of EdraftWareHousingJob" );
			iEvent = (IEvent)ApplicationBeanContextFactory.getBean(EdraftWareHousingEvent.class);
			String[] arg = new String[1];
			arg[0] = "";
			iEvent.processEvent(arg);
		}catch (BNPSchedulerException e) {
			LOGGER.error("Error occured in constructring message " + e.getMessage(), e);
			throw new SchedulerException(e.errorCode,e.getMessage());
		}
		
	}

}
