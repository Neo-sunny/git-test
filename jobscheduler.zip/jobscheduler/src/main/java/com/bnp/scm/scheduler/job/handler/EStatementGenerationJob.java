package com.bnp.scm.scheduler.job.handler;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.scheduler.events.EStatementGenerationEvent;
import com.bnp.scm.services.scheduler.events.IEvent;
import com.bnp.scm.services.scheduler.exception.BNPSchedulerException;

@Component
public class EStatementGenerationJob extends AbstractJob{

	public static final Logger LOGGER = LoggerFactory.getLogger(EStatementGenerationJob.class);
	
	@Override
	public void run(Map<String, String> inputMap) throws SchedulerException {
		
		IEvent iEvent = (IEvent)ApplicationBeanContextFactory.getBean(EStatementGenerationEvent.class);
		try{
			String[] args = new String[3];
			args[0] = inputMap.get("");
			args[1] = inputMap.get(SchedulerConstants.PARAM_NAME_BRANCH_ID);
			args[2] = inputMap.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID);
			
			iEvent.processEvent(args);
		}catch (BNPSchedulerException e) {
			LOGGER.error("Error Occured in EStatementGenerationJob "+ e.getMessage());
		}finally{
			iEvent = null;
		}
	}
}
