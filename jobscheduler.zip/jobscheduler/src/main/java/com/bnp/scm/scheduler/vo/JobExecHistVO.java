package com.bnp.scm.scheduler.vo;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class JobExecHistVO {
	
    private BigDecimal jobHistId;
    private String eventRef;
    private Timestamp startTime;
    private Timestamp endTime;
    private String jobStatus;
    private String jobName;
    private String groupName;
    private String jobHandlerClassName;
    private String errorDesc;
    private String scheduleTimeZoneId;

    private String jobType;
    private String scheduleType;
	private String originalEventRef;

    public BigDecimal getJobHistId() {
        return jobHistId;
    }

    public void setJobHistId(BigDecimal jobHistId) {
        this.jobHistId = jobHistId;
    }

    public String getEventRef() {
		return eventRef;
	}

	public void setEventRef(String eventRef) {
		this.eventRef = eventRef;
	}

	public Timestamp getStartTime() {
        return startTime;
    }

    public void setStartTime(Timestamp startTime) {
        this.startTime = startTime;
    }

    public Timestamp getEndTime() {
        return endTime;
    }

    public void setEndTime(Timestamp endTime) {
        this.endTime = endTime;
    }

    public String getJobStatus() {
        return jobStatus;
    }

    public void setJobStatus(String jobStatus) {
        this.jobStatus = jobStatus == null ? null : jobStatus.trim();
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName == null ? null : jobName.trim();
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName == null ? null : groupName.trim();
    }

    public String getJobHandlerClassName() {
        return jobHandlerClassName;
    }

    public void setJobHandlerClassName(String jobHandlerClassName) {
        this.jobHandlerClassName = jobHandlerClassName == null ? null : jobHandlerClassName.trim();
    }

    public String getErrorDesc() {
        return errorDesc;
    }

    public void setErrorDesc(String errorDesc) {
        this.errorDesc = errorDesc == null ? null : errorDesc.trim();
    }
	public String getScheduleTimeZoneId() {
		return scheduleTimeZoneId;
	}

	public void setScheduleTimeZoneId(String scheduleTimeZoneId) {
		this.scheduleTimeZoneId = scheduleTimeZoneId;
	}

	public String getJobType() {
		return jobType;
	}

	public void setJobType(String jobType) {
		this.jobType = jobType;
	}

	public String getScheduleType() {
		return scheduleType;
	}

	public void setScheduleType(String scheduleType) {
		this.scheduleType = scheduleType;
	}

	public String getOriginalEventRef() {
		return originalEventRef;
	}

	public void setOriginalEventRef(String originalEventRef) {
		this.originalEventRef = originalEventRef;
	}
	
}