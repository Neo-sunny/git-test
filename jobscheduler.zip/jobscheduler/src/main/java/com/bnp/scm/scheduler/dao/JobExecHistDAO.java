package com.bnp.scm.scheduler.dao;

import java.math.BigDecimal;

import com.bnp.scm.scheduler.vo.JobExecHistVO;
import com.bnp.scm.services.common.exception.DBException;

public interface JobExecHistDAO {
	
	BigDecimal insert(JobExecHistVO record) throws DBException;
    void updateStatus(JobExecHistVO record) throws DBException;
    JobExecHistVO getJobHistoryDetail(JobExecHistVO jobExecHistVO) throws DBException;
}