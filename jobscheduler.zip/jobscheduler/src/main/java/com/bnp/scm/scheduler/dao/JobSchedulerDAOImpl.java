/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Apr 2012
 * 
 * Purpose: Job Scheduler DAO Implementation
 * 
 * Change History: 
 * Date                             Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 25 Apr 2012                      Ramesh A                              Initial Version
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.vo.JobSchedulerVO;
import com.bnp.scm.services.common.dao.AbstractCommonDaoImpl;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.vo.AbstractVO;
import com.bnp.scm.services.common.vo.NameValueVO;

@Component
public class JobSchedulerDAOImpl extends AbstractCommonDaoImpl implements JobSchedulerDAO {

	private static final Logger LOGGER =LoggerFactory.getLogger(JobSchedulerDAOImpl.class);
	
	private static final String NAME_SPACE = "JobSchedulerNS";
	private static final String NAME_SPACE_SEPERATOR = ".";
	private static final String SEARCH_JOB_SCHEDULER_RECORD = "searchJobScheduler";
	private static final String SELECT_SUP_BRANCH_LIST = "selectUserSupBranches";
	private static final String SELECT_JOB_NAME_SPECTO_TYPE = "selectJobNameSpectoType";
	private static final String SELECT_PAYMENT_METHOD = "getPaymentMethodList";
	private static final String SELECT_ERP_JOB_FOR_ORGID = "selectERPJobsforOrgId";
	private static final String UPDATE_SCHEDULE_STATUS = "updateScheduleStatus";
	private static final String SELECT_USER_BRANCH_SPEC_ORG_IDS = "selectUserandBranchSpecOrgIds";
	private static final String CONCURRENT_ACCESS_CHECK_TRANS = "concurrentAccessCheckTrans";
	private static final String CONCURRENT_ACCESS_TRANS = "concurrentAccessTrans";
	private static final String CONCURRENT_ACCESS_MASTER = "concurrentAccessMaster";
	private static final String GET_TIME_ZONE_LIST="getTimeZone";
	private static final String GET_USER_BRANCH_TIMEZONE="getBranchTimeZoneForUser";
	
	@Override
	public String getNameSpace() {
		return NAME_SPACE + NAME_SPACE_SEPERATOR;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<JobSchedulerVO> getJobSchedulerDetail(JobSchedulerVO jobSchedulerVO) throws BNPApplicationException {
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("Search criteria:" + jobSchedulerVO);
		try{
			return getSqlMapClientTemplate().queryForList(getNameSpace() + SEARCH_JOB_SCHEDULER_RECORD, jobSchedulerVO);
		}catch (DataAccessException exception){
			LOGGER.error("DataAccessException in getJobSchedulerDetail:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}catch (RuntimeException exception){
			LOGGER.error("RuntimeException in getJobSchedulerDetail:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<NameValueVO> getSupportBranchList(String userId) throws BNPApplicationException {
		try{
			return getSqlMapClientTemplate().queryForList(getNameSpace() + SELECT_SUP_BRANCH_LIST,userId);
		}catch (DataAccessException exception){
			LOGGER.error("DataAccessException in getSupportBranchList:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}catch (RuntimeException exception){
			LOGGER.error("RuntimeException in getSupportBranchList:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	} 

	@SuppressWarnings("unchecked")
	@Override
	public List<NameValueVO> getERPJobNamesforOrgId(String orgId) throws BNPApplicationException{
		try{
			return getSqlMapClientTemplate().queryForList(getNameSpace() + SELECT_ERP_JOB_FOR_ORGID,orgId);
		}catch (DataAccessException exception){
			LOGGER.error("DataAccessException in getJobNameSpectoType:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}catch (RuntimeException exception){
			LOGGER.error("RuntimeException in getJobNameSpectoType:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	} 

	@SuppressWarnings("unchecked")
	@Override
	public List<NameValueVO> getJobNameSpectoType(String jobType) throws BNPApplicationException {
		try{
			return getSqlMapClientTemplate().queryForList(getNameSpace() + SELECT_JOB_NAME_SPECTO_TYPE,jobType);
		}catch (DataAccessException exception){
			LOGGER.error("DataAccessException in getJobNameSpectoType:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}catch (RuntimeException exception){
			LOGGER.error("RuntimeException in getJobNameSpectoType:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	} 
	
	@SuppressWarnings("unchecked")
	@Override
	public List<NameValueVO> getPaymentMethods() throws BNPApplicationException {
		try{
			return getSqlMapClientTemplate().queryForList(getNameSpace() + SELECT_PAYMENT_METHOD);
		}catch (DataAccessException exception){
			LOGGER.error("DataAccessException in getPaymentMethods:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}catch (RuntimeException exception){
			LOGGER.error("RuntimeException in getPaymentMethods:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public boolean concurrentAccess(AbstractVO concurrentVO) throws BNPApplicationException {
		boolean concurrentAccess = true;
		int recordCount = 0;
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("Concurrent access - dao :" + concurrentVO);
		if(concurrentVO != null){
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("Data :" + concurrentVO.getMakerId()+"#"+concurrentVO.getMakerDate()+"#"+concurrentVO.getCheckerId()+"#"+concurrentVO.getRecordStatus());
			if(concurrentVO instanceof JobSchedulerVO){
				JobSchedulerVO jobSchedulerVO = (JobSchedulerVO)concurrentVO;
				Map<String, Object> params = new HashMap<String, Object>();
				params.put("makerId", jobSchedulerVO.getMakerId());
				params.put("jobRef", jobSchedulerVO.getJobRef());
				params.put("lastUpdatedTimestamp", jobSchedulerVO.getLastUpdatedTimestamp());
				Object transCount = getSqlMapClientTemplate().queryForObject(getNameSpace() + CONCURRENT_ACCESS_CHECK_TRANS, jobSchedulerVO.getJobRef());
				transCount = transCount == null ? Integer.valueOf(0) : transCount; 
				Object countObject = null;
				if((Integer)transCount > 0){
					countObject = getSqlMapClientTemplate().queryForObject(getNameSpace() + CONCURRENT_ACCESS_TRANS, params);
				}else{
					countObject = getSqlMapClientTemplate().queryForObject(getNameSpace() + CONCURRENT_ACCESS_MASTER, params);
				}
				if(countObject != null){
					recordCount = (Integer) countObject;
				}else{
					recordCount = 0;
				}
				//FO 7.0 Fortify Issue Fix
				//LOGGER.debug("Record count :" + recordCount);
			}	
		}
		if(recordCount > 0){
			concurrentAccess = false;
		}
		return concurrentAccess;
	}
	
    @Override
	public void updateScheduleStatus(JobSchedulerVO jobSchedulerVO) throws DBException{
    	try{
    		getSqlMapClientTemplate().update(getNameSpace() + UPDATE_SCHEDULE_STATUS, jobSchedulerVO);
    	}catch(DataAccessException e){
    		//976332 CSCDEV-2683 17-NOV-2014:START
    		//e.printStackTrace();
    		//976332 CSCDEV-2683 17-NOV-2014:ENd
    		LOGGER.error("error in updateStatus data::"+e.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_UPDATE);
    	}
    }
    
	@SuppressWarnings("unchecked")
	@Override
	public List<NameValueVO> getUserandBranchSpecOrgIdList(String userId,String branchId) throws BNPApplicationException {
		try{
			Map<String,String> inputMap = new HashMap<String, String>();
			inputMap.put("USERID", userId);
			inputMap.put("BRANCHID",branchId);
			return getSqlMapClientTemplate().queryForList(getNameSpace() + SELECT_USER_BRANCH_SPEC_ORG_IDS,inputMap);
		}catch (DataAccessException exception){
			LOGGER.error("DataAccessException in getUserandBranchSpecOrgIdList:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}catch (RuntimeException exception){
			LOGGER.error("RuntimeException in getUserandBranchSpecOrgIdList:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}

	
	@SuppressWarnings("unchecked")
	@Override
	public List<NameValueVO> getTimeZoneDetailList()
			throws BNPApplicationException {
		List<NameValueVO> timeZoneList = null;
		try{
			timeZoneList = getSqlMapClientTemplate().queryForList(getNameSpace()+GET_TIME_ZONE_LIST);
		}catch (DataAccessException e) {
			LOGGER.error("Error while fetching Time Zone Details for Job scheduler Screen"+e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR,e);
		}
		return timeZoneList;
	}

	@Override
	public NameValueVO getUserBranchTimeZone(String userId)
			throws BNPApplicationException {
		NameValueVO nameValueVO = null;
		try{
			nameValueVO =(NameValueVO)getSqlMapClientTemplate().queryForObject(getNameSpace()+GET_USER_BRANCH_TIMEZONE,userId);
		}catch (DataAccessException e) {
			LOGGER.error("Error while fetching Time Zone Details for User"+userId+""+e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR,e);
		}
		return nameValueVO;
	} 
    
}
