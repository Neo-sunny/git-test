package com.bnp.scm.scheduler.util;

public interface IEventStatusNotificationService {
	
	//STARTED,COMPLETED,FAILED,SKIPPED
	//Based on the particular eventName
	void started(String eventRef);
	//COMPLETED,FAILED,SKIPPED
	//The boolean will tell whether any next fire will happen for this event ref or not
	void endStatus(String eventRef, String status, Throwable exception, boolean hasNextFire);
}
