package com.bnp.scm.scheduler.job;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;

@Component
public class SampleAdhocJob1 extends AbstractJob{
	
	@Override
	public void run(Map<String, String> arg0) throws SchedulerException {
		System.out.println("SampleAdhocJob1 input is"+arg0);
		try{
			Thread.sleep(10000);
		}catch(Exception e){
			//976332 CSCDEV-2683 17-NOV-2014:START
			//e.printStackTrace();
			//976332 CSCDEV-2683 17-NOV-2014:END
		}
		System.out.println("End SampleAdhocJob1 input is"+arg0);
	}

}
