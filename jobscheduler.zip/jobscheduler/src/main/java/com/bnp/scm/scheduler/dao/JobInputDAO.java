package com.bnp.scm.scheduler.dao;

import java.util.List;

import com.bnp.scm.scheduler.vo.JobInputVO;
import com.bnp.scm.services.common.exception.DBException;

public interface JobInputDAO {
	
    void insert(List<JobInputVO> inputList) throws DBException;
    void deleteByEventRef(String eventRef) throws DBException;
    List<JobInputVO> getInputByEventRef(String eventRef) throws DBException;
    
}