/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Apr 2012
 * 
 * Purpose: Common Job Validator DAO Implementaion
 * 
 * Change History: 
 * Date                             Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 25 Apr 2012                      Ramesh A                              Initial Version
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.dao;

import java.sql.Timestamp;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.vo.NameValueVO;

@Component
public class JobValidatorDAOImpl extends SqlMapClientWrapper implements JobValidatorDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(JobValidatorDAOImpl.class);
	
	private static final String NAME_SPACE = "JobValidatorNS.";
	private static final String SELECT_BRANCH_DETAIL = "selectBranchDetail";
	private static final String SELECT_BRANCH_HOLIDAY_COUNT = "getBranchHolidayCount";
	private static final String GET_SYSTEM_DATE = "getSyatemDate";
	private static final String SELECT_ORG_DETAIL = "getOrgLevelDetails";

	private static final String SELECT_ORGANIZATION_DETAIL = "getOrganizationDetails";

	private static final String SELECT_ORGANIZATION_HOLIDAY_COUNT = "getOrganizationHolidayCount";

	@Override
	public NameValueVO getBranchDetails(String branchId)throws BNPApplicationException{
		try {
			return (NameValueVO)getSqlMapClientTemplate().queryForObject(NAME_SPACE + SELECT_BRANCH_DETAIL,branchId);
		}catch (DataAccessException e) {
			LOGGER.error("Error while retrieving getBranchDetails ->" + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public String getSystemDate() throws BNPApplicationException{
		try {
			return (String)getSqlMapClientTemplate().queryForObject(NAME_SPACE + GET_SYSTEM_DATE);
		}catch (DataAccessException e) {
			LOGGER.error("Error while retrieving System Date ->" + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public int getBranchHolidayCount(String branchId,Timestamp currentDate) throws BNPApplicationException {
		Properties params = new Properties();
		int i=0;
		try{
			params.put("branchId", branchId);
			params.put("currentDate", currentDate);
			i= (Integer) getSqlMapClientTemplate().queryForObject(NAME_SPACE + SELECT_BRANCH_HOLIDAY_COUNT, params);
		}catch (DataAccessException e) {
			LOGGER.error(e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return i;
	}

	@Override
	public NameValueVO getOrganizationDetails(String orgId)
			throws BNPApplicationException {
		try {
			return (NameValueVO)getSqlMapClientTemplate().queryForObject(NAME_SPACE + SELECT_ORGANIZATION_DETAIL,orgId);
		}catch (DataAccessException e) {
			LOGGER.error("Error while retrieving getBranchDetails ->" + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public int getOrganizationHolidayCount(String orgId,
			Timestamp currentDate) throws BNPApplicationException {
		Properties params = new Properties();
		int i=0;
		try{
			params.put("orgId", orgId);
			params.put("currentDate", currentDate);
			i= (Integer) getSqlMapClientTemplate().queryForObject(NAME_SPACE + SELECT_ORGANIZATION_HOLIDAY_COUNT, params);
		}catch (DataAccessException e) {
			LOGGER.error(e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return i;
	}

	
}
