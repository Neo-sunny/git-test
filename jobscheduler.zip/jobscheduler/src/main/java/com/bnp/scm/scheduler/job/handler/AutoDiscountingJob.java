package com.bnp.scm.scheduler.job.handler;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.scheduler.events.AutoDiscountingEvent;
import com.bnp.scm.services.scheduler.events.IEvent;
import com.bnp.scm.services.scheduler.exception.BNPSchedulerException;

@Component
public class AutoDiscountingJob extends AbstractJob{

	public static final Logger LOGGER = LoggerFactory.getLogger(AutoDiscountingJob.class);
	
	@Override
	public void run(Map<String, String> inputMap) throws SchedulerException {
		long start = System.currentTimeMillis();
		LOGGER.warn("Adding loggers in Auto Disounting flow start time of run : "+start);
		LOGGER.debug("AutoDiscountingJob--Beg");
		IEvent iEvent = (IEvent)ApplicationBeanContextFactory.getBean(AutoDiscountingEvent.class);
		try {
			String[] arg = new String[4];
			arg[0] = "";
			arg[1] = inputMap.get(SchedulerConstants.PARAM_NAME_SENDER_ORG_ID);
			arg[2] = inputMap.get(SchedulerConstants.PARAM_NAME_FILE_ID);
			arg[3] = inputMap.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID);
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("AutoDiscountingJob--arg-0->" + arg[0] + "<arg-1->" + arg[1] + "<arg-2->" + arg[2] + "<arg-3->" + arg[3]);
			iEvent.processEvent(arg);
			long end = System.currentTimeMillis();
			LOGGER.warn("Adding loggers in Auto Disounting flow end time of run : "+end);
			LOGGER.warn("Adding loggers in Auto Disounting flow difference time of run : "+(end-start));
		}catch (BNPSchedulerException e) {
			LOGGER.error(e.getMessage(), e);
			throw new SchedulerException(e.errorCode,e.getMessage());
		}finally {
			iEvent = null;
		}	
		LOGGER.debug("AutoDiscountingJob--End");
	}

}
