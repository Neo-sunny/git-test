/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   03 Jan 2015
 * 
 * Purpose:     DailyTransactionJob
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 03 Jan 2015                      Oracle Financial Services Software Ltd                                    Initial Version 
 *                                  
 *****************************************************************************************************************************************************************/
package com.bnp.scm.scheduler.job.handler.dailytxndetail;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.scheduler.events.DailyTransactionJobEvent;

@Component
public class DailyTransactionJob extends AbstractJob{
	
	public static final Logger LOGGER = LoggerFactory.getLogger(DailyTransactionJob.class);
	@Override
	public void run(Map<String, String> inputMap) throws SchedulerException {
		LOGGER.debug("DailyTransactionJob--Beg");
		String[] arg = getArgs(inputMap);		
		processEvent(DailyTransactionJobEvent.class,arg);
		LOGGER.debug("DailyTransactionJob--End");
	}
	private String[] getArgs(Map<String, String> inputMap) {		
			String[] arg = new String[4];
			arg[0] = "";
			arg[1] = inputMap.get(SchedulerConstants.PARAM_NAME_BRANCH_ID);
			arg[2] = inputMap.get(SchedulerConstants.PARAM_NAME_EVENT_NAME);
			arg[3] = inputMap.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID);
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("DailyTransactionJob--<arg-1->" + arg[1] + "<arg-2->" + arg[2] + "<arg-3->" + arg[3]);
			return arg;	
	}
}
