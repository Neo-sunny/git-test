package com.bnp.scm.scheduler.dao;

import java.util.List;

import com.bnp.scm.scheduler.vo.ScheduledMonthOfDayVO;
import com.bnp.scm.services.common.exception.DBException;

public interface ScheduledMonthOfDayDAO {
	
    void insert(List<ScheduledMonthOfDayVO> record) throws DBException;
    void deleteByEventRef(String eventRef) throws DBException;
    List<String> getScheduledMonthOfDayByEventRef(String eventRef) throws DBException;
    
}