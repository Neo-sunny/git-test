/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Sep 2011
 * 
 * Purpose: Scheduler Framework Service Implementation
 * 
 * Change History: 
 * Date                             Author                                Version                     Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 02 Mar 2012                      Oracle Financial Services Software Ltd                                  Initial Version
 * 25 Apr 2012						Ramesh A																For Job Scheduler Changes
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.quartz.CronTrigger;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.JobPersistenceException;
import org.quartz.Scheduler;
import org.quartz.Trigger;
import org.quartz.TriggerKey;
import org.quartz.impl.matchers.GroupMatcher;
import org.quartz.impl.matchers.StringMatcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnp.scm.scheduler.SchedulerExpressionBuilder;
import com.bnp.scm.scheduler.dao.ISchedulerDAO;
import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.exception.SchedulerValidationException;
import com.bnp.scm.scheduler.util.ISchedulerValidatorService;
import com.bnp.scm.scheduler.util.JobBuilder;
import com.bnp.scm.scheduler.util.QuartzSchedulerFactoryNew;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.scheduler.util.SchedulerUtil;
import com.bnp.scm.scheduler.util.SchedulerConstants.SCH_TYPE;
import com.bnp.scm.scheduler.util.SchedulerConstants.SCHEDULE_ACTION_FLAG;
import com.bnp.scm.scheduler.util.SchedulerThreadManager;
import com.bnp.scm.scheduler.vo.JobConfigVO;
import com.bnp.scm.scheduler.vo.JobInfoVO;
import com.bnp.scm.scheduler.vo.ScheduleInfoVO;
import com.bnp.scm.scheduler.vo.ScheduleVO;
import com.bnp.scm.services.common.ApplicationBeanContextFactory;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;

@Component
@Transactional
public class SchedulerService implements ISchedulerService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SchedulerService.class);
	
	private @Autowired JobBuilder jobBuilder;
	private @Autowired ISchedulerDAO schedulerDAO;
	private @Autowired ISchedulerValidatorService validator;
	
	private @Autowired BNPPropertyLoaderConfigurer propertyLoader;

	
	public JobBuilder getJobBuilder() {
		return jobBuilder;
	}

	public void setJobBuilder(JobBuilder jobBuilder) {
		this.jobBuilder = jobBuilder;
	}

	public ISchedulerDAO getSchedulerDAO() {
		return schedulerDAO;
	}

	public void setSchedulerDAO(ISchedulerDAO schedulerDAO) {
		this.schedulerDAO = schedulerDAO;
	}

	
	public ISchedulerValidatorService getValidator() {
		return validator;
	}

	public void setValidator(ISchedulerValidatorService validator) {
		this.validator = validator;
	}

	/*private org.quartz.Scheduler getScheduler() throws SchedulerException, org.quartz.SchedulerException{
		Scheduler scheduler = QuartzSchedulerFactory.getSchedulerFactory().getScheduler();
		return scheduler;
	}*/
	
	private org.quartz.Scheduler getScheduler(String groupName) throws SchedulerException, org.quartz.SchedulerException{
		/*Map<String,String> map = new HashMap<String, String>();
		map.put("Test", "TestGroup");
		String schedulerName = map.get(groupName);
		if(schedulerName == null){
			schedulerName = "DefaultTestGroup";
		}*/
		String schedulerName = "DefaultGroup";
		Scheduler scheduler = QuartzSchedulerFactoryNew.getSchedulerFactory().getScheduler(schedulerName);
		return scheduler;
	}
	
	public Set<TriggerKey> getTrigger(String groupName)throws SchedulerException, org.quartz.SchedulerException{
		
		Scheduler scheduler = getScheduler(groupName);
		GroupMatcher<TriggerKey> grouMa = GroupMatcher.groupEquals(groupName);
		return scheduler.getTriggerKeys(grouMa);
		
	}
	//return jobRef
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor=SchedulerException.class)
	public String scheduleJob(ScheduleVO scheduleVo) throws SchedulerException{
		long start = System.currentTimeMillis();
		LOGGER.warn("Adding loggers in Auto Disounting flow start time of scheduleJob : "+start);
		String eventRef = "";
		try{
	        Map<String,String> inputParams = scheduleVo.getInput();
	        if(inputParams == null){
	        	inputParams = new HashMap<String, String>();
	        	scheduleVo.setInput(inputParams);
	        }
	        if(scheduleVo.getOrgId() != null){//
	        	inputParams.put(SchedulerConstants.PARAM_NAME_ORG_ID, scheduleVo.getOrgId());
	        }
	        if(scheduleVo.getBranchId() != null){
	        	inputParams.put(SchedulerConstants.PARAM_NAME_BRANCH_ID, scheduleVo.getBranchId());
	        }
	        scheduleVo.setScheduleType(scheduleVo.getScheduleType());
	        scheduleVo.setScheduleActionFlag(SCHEDULE_ACTION_FLAG.NEW);
	        /**/
	        long jobInfoVOStart = System.currentTimeMillis();
	        LOGGER.warn("Adding loggers in Auto Disounting flow start time of jobInfoVOStart : "+jobInfoVOStart);
	        JobInfoVO jobInfoVO = schedulerDAO.getJobInfo(scheduleVo.getEventName());
	        long jobInfoVOend = System.currentTimeMillis();
	        LOGGER.warn("Adding loggers in Auto Disounting flow start time of jobInfoVOend : "+jobInfoVOend);
	        if(jobInfoVO != null){
		        scheduleVo.setJobInfoVO(jobInfoVO);
		        if(SCH_TYPE.ADHOC.equals(scheduleVo.getScheduleType())){
		        	scheduleVo.setJobPirority(1);
		        }else{
		        	scheduleVo.setJobPirority(jobInfoVO.getPriority());
		        }	
		        scheduleVo.setMisfireInst(jobInfoVO.getMisfireInst());
	        }    
	        /**/
	        long insertScheduleInfoStart = System.currentTimeMillis();
	        LOGGER.warn("Adding loggers in Auto Disounting flow start time of insertScheduleInfoStart : "+insertScheduleInfoStart);
			eventRef = schedulerDAO.insertScheduleInfo(scheduleVo);
			long insertScheduleInfoEnd = System.currentTimeMillis();
	        LOGGER.warn("Adding loggers in Auto Disounting flow start time of insertScheduleInfoEnd : "+insertScheduleInfoEnd);
			scheduleVo.setEventRef(eventRef);
    		String schedulerThreadEnable = propertyLoader.getValue("scheduler.enable.thread.processing");
    		//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("schedulerThreadEnable-->" + schedulerThreadEnable);
    		if(SchedulerConstants.SCHEDULED_STATUS.YES.getValue().equals(schedulerThreadEnable)){
    			try {
    				SchedulerThreadManager schedulerThreadManager = (SchedulerThreadManager)com.bnp.scm.services.common.ApplicationBeanContextFactory.getBean("schedulerThreadManager");
    				schedulerThreadManager.scheduleJob(scheduleVo, false, jobBuilder, schedulerDAO);
    			} catch (Exception e) {
    				LOGGER.error("Exception while Scheduling Job" + e);
    				updateJobScheduleStatus(scheduleVo,eventRef,SchedulerConstants.JOB_SCH_STATUS_ERROR,e.getMessage());
    			}
        	}else{
        		scheduleJob(scheduleVo, false);
        	}	
		}catch(DBException e){
			LOGGER.error("Exception ---"+e);
			//976332 CSCDEV-2683 17-NOV-2014:START
			//e.printStackTrace();
			//976332 CSCDEV-2683 17-NOV-2014:END
			updateJobScheduleStatus(scheduleVo,eventRef,SchedulerConstants.JOB_SCH_STATUS_ERROR,e.getMessage());
			throw new SchedulerException(ErrorConstants.DATABASE_ERROR,e);
		}catch(JobPersistenceException e){
			LOGGER.error("Exception ---"+e);
			//976332 CSCDEV-2683 17-NOV-2014:START
			//e.printStackTrace();
			//976332 CSCDEV-2683 17-NOV-2014:END
			updateJobScheduleStatus(scheduleVo,eventRef,SchedulerConstants.JOB_SCH_STATUS_ERROR,e.getMessage());
			throw new SchedulerException(e.getMessage(),e);
		}catch(org.quartz.SchedulerException e){
			LOGGER.error("Exception ---"+e);
			updateJobScheduleStatus(scheduleVo,eventRef,SchedulerConstants.JOB_SCH_STATUS_ERROR,e.getMessage());
			//If not scheduled
			//throw new SchedulerException(e.getMessage(),e);
		}
		long end = System.currentTimeMillis();
		LOGGER.warn("Adding loggers in Auto Disounting flow end time of scheduleJob : "+end);
		LOGGER.warn("Adding loggers in Auto Disounting flow difference time of scheduleJob : "+(end-start));
        return eventRef;
	}

	public void updateJobScheduleStatus(ScheduleVO scheduleVo,String eventRef,String schStatus,String errorMsg){
        try{
	        if(SchedulerConstants.JOB_TYPE_ERP.equals(scheduleVo.getJobType()) || SchedulerConstants.JOB_TYPE_BRANCH.equals(scheduleVo.getJobType()) || SchedulerConstants.JOB_TYPE_SYSTEM.equals(scheduleVo.getJobType())){
	        	schedulerDAO.updateJobSchedulerStatus(eventRef,schStatus,errorMsg);
	        }
        }catch(Exception ne){
        	LOGGER.error("Exception While Updating the Schedule Status");
        }
	}
	
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor={SchedulerException.class})
	public void rescheduleJob(ScheduleVO scheduleVo) throws SchedulerException{
        Map<String,String> inputParams = scheduleVo.getInput();
        if(inputParams == null){
        	inputParams = new HashMap<String, String>();
        	scheduleVo.setInput(inputParams);
        }
        if(scheduleVo.getOrgId() != null){//
        	inputParams.put(SchedulerConstants.PARAM_NAME_ORG_ID, scheduleVo.getOrgId());
        }
        if(scheduleVo.getBranchId() != null){
        	inputParams.put(SchedulerConstants.PARAM_NAME_BRANCH_ID, scheduleVo.getBranchId());
        }
        try{
	        /**/
	        JobInfoVO jobInfoVO = schedulerDAO.getJobInfo(scheduleVo.getEventName());
	        if(jobInfoVO != null){
	        	scheduleVo.setJobInfoVO(jobInfoVO);
	        	scheduleVo.setJobPirority(jobInfoVO.getPriority());
	        	scheduleVo.setMisfireInst(jobInfoVO.getMisfireInst());
	        }
	        if(scheduleVo.getStartDate() != null && scheduleVo.getStartDate().before(new Date())){
	        	scheduleVo.setStartDate(SchedulerUtil.getCurrentDateforSelectedTimeZone(new Date(), TimeZone.getDefault(), TimeZone.getTimeZone(scheduleVo.getScheduleTimeZoneId())));
	        }
	        /**/
        	schedulerDAO.updateScheduleInfo(scheduleVo);//update all framework table
    		String schedulerThreadEnable = propertyLoader.getValue("scheduler.enable.thread.processing");
    		//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("schedulerThreadEnable-->" + schedulerThreadEnable);
    		if(SchedulerConstants.SCHEDULED_STATUS.YES.getValue().equals(schedulerThreadEnable)){
    			try {
    				SchedulerThreadManager schedulerThreadManager = (SchedulerThreadManager)com.bnp.scm.services.common.ApplicationBeanContextFactory.getBean("schedulerThreadManager");
    				schedulerThreadManager.scheduleJob(scheduleVo, true, jobBuilder, schedulerDAO);
    			} catch (Exception e) {
    				LOGGER.error("Exception while Scheduling Job" + e);
    				updateJobScheduleStatus(scheduleVo,scheduleVo.getEventRef(),SchedulerConstants.JOB_SCH_STATUS_ERROR,e.getMessage());
    			}
        	}else{
        		scheduleJob(scheduleVo, true);
        	}	
        }catch(DBException e){
			LOGGER.error("Execption in unscheduleJob="+e);
			throw new SchedulerException(e.getMessage(),e);
        }catch(org.quartz.SchedulerException e){
			LOGGER.error("rescheduleJob in unscheduleJob="+e);
		}
	}
	
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor={SchedulerException.class})
    public void pauseTrigger(String eventRef)throws SchedulerException{
		try{
	    	String groupName = getGroupName(eventRef);
			schedulerDAO.updateScheduleStatus(eventRef, SchedulerConstants.SCHEDULED_STATUS.NO.getValue(), SchedulerConstants.SCHEDULE_ACTION_FLAG.PAUSE.getValue());
	    	TriggerKey triggerKey = new TriggerKey(""+eventRef, groupName);
	    	
	    	Scheduler scheduler = getScheduler(groupName);
	    	boolean isScheduledAlready = scheduler.checkExists(triggerKey);
	    	if(!isScheduledAlready){
	    		ScheduleInfoVO infoVO = schedulerDAO.getScheduleInfo(eventRef);
	    		scheduleJob(infoVO);
	    	}
	    	scheduler.pauseTrigger(triggerKey);
	    	schedulerDAO.updateScheduleStatus(eventRef, SchedulerConstants.SCHEDULED_STATUS.YES.getValue(), "");
	    	
		}catch(DBException e){
			LOGGER.error("Execption in pauseTrigger="+e);
			throw new SchedulerException(e.getMessage(),e);
        }catch(org.quartz.SchedulerException e){
			LOGGER.error("Exception in pauseTrigger="+e);
		}
    }
	
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor={SchedulerException.class,org.quartz.SchedulerException.class})
    public void resumeTrigger(String eventRef)throws DBException, org.quartz.SchedulerException, SchedulerException{
		try{
	    	String groupName = getGroupName(eventRef);
			schedulerDAO.updateScheduleStatus(eventRef, SchedulerConstants.SCHEDULED_STATUS.NO.getValue(), SchedulerConstants.SCHEDULE_ACTION_FLAG.RESUME.getValue());
	    	TriggerKey triggerKey = new TriggerKey(""+eventRef, groupName);
	    	Scheduler scheduler = getScheduler(groupName);
	    	boolean isScheduledAlready = scheduler.checkExists(triggerKey);
	    	if(!isScheduledAlready){
	    		ScheduleInfoVO infoVO = schedulerDAO.getScheduleInfo(eventRef);
	    		scheduleJob(infoVO);
	    	}
	    	scheduler.resumeTrigger(triggerKey);
	    	schedulerDAO.updateScheduleStatus(eventRef, SchedulerConstants.SCHEDULED_STATUS.YES.getValue(), "");
		}catch(DBException e){
			LOGGER.error("Execption in pauseTrigger="+e);
			throw new SchedulerException(e.getMessage(),e);
        }catch(org.quartz.SchedulerException e){
			LOGGER.error("Exception in pauseTrigger="+e);
		}
    }


	//TriggerName, Trigger Group can take from table
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor={SchedulerException.class})
	public void unscheduleJob(String eventRef,String jobType) throws SchedulerException{
		ScheduleVO scheduleVo = new ScheduleVO();
		scheduleVo.setJobType(jobType);
		try{
			String groupName = getGroupName(eventRef);
			TriggerKey triggerKey = new TriggerKey(""+eventRef, groupName);
			schedulerDAO.updateScheduleStatus(eventRef, SchedulerConstants.SCHEDULED_STATUS.NO.getValue(), SchedulerConstants.SCHEDULE_ACTION_FLAG.DELETE.getValue());
			//getScheduler().unscheduleJob(triggerKey);
    		String schedulerThreadEnable = propertyLoader.getValue("scheduler.enable.thread.processing");
    		//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("schedulerThreadEnable-->" + schedulerThreadEnable);
    		if(SchedulerConstants.SCHEDULED_STATUS.YES.getValue().equals(schedulerThreadEnable)){
    			try {
    				SchedulerThreadManager schedulerThreadManager = (SchedulerThreadManager)ApplicationBeanContextFactory.getBean("schedulerThreadManager");
    				schedulerThreadManager.unscheduleJob(eventRef,jobType, schedulerDAO);
    			} catch (Exception e) {
    				LOGGER.error("Exception while Scheduling Job" + e);
    				updateJobScheduleStatus(scheduleVo,jobType,SchedulerConstants.JOB_SCH_STATUS_ERROR,e.getMessage());
    			}
        	}else{
				boolean unschStatus1 = getScheduler(groupName).unscheduleJob(triggerKey);
				triggerKey = new TriggerKey(""+eventRef, ""+eventRef);
				boolean unschStatus2 = getScheduler(groupName).unscheduleJob(triggerKey);
				if(unschStatus1 || unschStatus2){
					schedulerDAO.deleteScheduleInfo(eventRef);
			        if(SchedulerConstants.JOB_TYPE_ERP.equals(jobType) || SchedulerConstants.JOB_TYPE_BRANCH.equals(jobType) || SchedulerConstants.JOB_TYPE_SYSTEM.equals(jobType)){
			        	schedulerDAO.updateJobSchedulerStatus(eventRef,SchedulerConstants.JOB_SCH_STATUS_UNSCHEDULED,"");
			        }
				}
        	}	
		}catch(DBException e){
			LOGGER.error("Execption in unscheduleJob="+e);
			throw new SchedulerException(e.getMessage(),e);
		}catch(org.quartz.SchedulerException e){
			LOGGER.error("Execption in unscheduleJob="+e);
			updateJobScheduleStatus(scheduleVo,eventRef,SchedulerConstants.JOB_SCH_STATUS_ERROR,e.getMessage());
		}
	}
	

	
	//In the scheduleVO, have to populate minis,hours,inputs,jobname, jobhandlerclassname
	public void scheduleStaticJobs(List<ScheduleVO> jobList) throws SchedulerException{
		ISchedulerService schedulerService = (ISchedulerService)com.bnp.scm.scheduler.util.ApplicationBeanContextFactory.getBean(ISchedulerService.class);
		if(jobList != null && !jobList.isEmpty()){
    		for(ScheduleVO job:jobList){
    			job.setGroupName(SchedulerConstants.STATIC_JOB_GROUP);
    			try{
    				validator.checkDuplicateStaticJobNameExists(job.getJobName(), SchedulerConstants.STATIC_JOB_GROUP);
    				job.setJobPirority(5);
    				job.setMisfireInst(1);
    				schedulerService.scheduleJob(job);
    			}catch(SchedulerValidationException e){
    				//FO 7.0 Fortify Issue Fix
    				LOGGER.error("Job Couldn't schedule for reason="+e.getErrorCode());
    			}
    		}
		}
	}
	
	//In the scheduleVO, have to populate minis,hours,inputs,jobname, jobhandlerclassname
	public void rescheduleStaticJobs(List<ScheduleVO> jobList) throws SchedulerException{
		ISchedulerService schedulerService = (ISchedulerService)com.bnp.scm.scheduler.util.ApplicationBeanContextFactory.getBean(ISchedulerService.class);
    	if(jobList != null && !jobList.isEmpty()){
    		for(ScheduleVO job:jobList){
    			try{
    				job.setGroupName(SchedulerConstants.STATIC_JOB_GROUP);
	    			String eventRef = schedulerDAO.getEventRefForStaticJob(job.getJobName(), job.getGroupName());
	    			if(eventRef != null){
	    				job.setEventRef(eventRef);
	    				job.setJobPirority(5);
	    				job.setMisfireInst(1);
	    				schedulerService.rescheduleJob(job);
	    			}else{
						//FO 7.0 Fortify Issue Fix
	    				//LOGGER.error("Couldn't reschedule job="+job.getJobName()+" as it doesn't exists/completed in the scheduler");
	    				LOGGER.error("Couldn't reschedule job  as it doesn't exists/completed in the scheduler");
	    			}
    			}catch(DBException e){
    				LOGGER.error(e.getMessage());
    			}
    		}
    	}

	}
	
    public void unscheduleStaticJobs(List<ScheduleVO> jobList) throws SchedulerException{
    	ISchedulerService schedulerService = (ISchedulerService)com.bnp.scm.scheduler.util.ApplicationBeanContextFactory.getBean(ISchedulerService.class);
    	if(jobList != null && !jobList.isEmpty()){
    		for(ScheduleVO job:jobList){
    			try{
	    			String eventRef = schedulerDAO.getEventRefForStaticJob(job.getJobName(), SchedulerConstants.STATIC_JOB_GROUP);
	    			if(eventRef != null){
	    				schedulerService.unscheduleJob(eventRef,"");
	    			}else{
						//FO 7.0 Fortify Issue Fix
	    				//LOGGER.error("Couldn't unschedule job="+job.getJobName()+" as it doesn't exists or completed in the scheduler");
	    				LOGGER.error("Couldn't unschedule job  as it doesn't exists or completed in the scheduler");
	    			}
    			}catch(DBException e){
    				LOGGER.error(e.getMessage());
    			}
    		}
    	}
    }
    @Transactional(propagation=Propagation.REQUIRES_NEW, rollbackFor={SchedulerException.class})
    public void removeJobsConfig() throws SchedulerException{
    	try{
    		//Scheduler scheduler = getScheduler();
	    	List<JobConfigVO> jobList = schedulerDAO.getDeleteJobList();
	    	if(jobList != null && !jobList.isEmpty()){
	    		List<JobKey> jobKeyList = new ArrayList<JobKey>();
	    		List<Long> jobIdList = new ArrayList<Long>();
	    		for(JobConfigVO jobConfig:jobList){
	    			JobKey jobKey = new JobKey(jobConfig.getJobName(), jobConfig.getGroupName());
	    			jobKeyList.add(jobKey);
	    			jobIdList.add(Long.valueOf(jobConfig.getJobId()));
	    			getScheduler(jobConfig.getGroupName()).deleteJob(jobKey);
	    		}
	    		//scheduler.deleteJobs(jobKeyList);
	    		schedulerDAO.removeDeleteJobList(jobIdList);
	    	}
    	}catch(DBException e){
    		LOGGER.error("Exception in removeJobsConfig ="+e);
			throw new SchedulerException(e.getMessage(),e);
    	}catch(org.quartz.SchedulerException e){
			LOGGER.error("Exception in removeJobsConfig ="+e);
			throw new SchedulerException(e.getMessage(),e);
		}
    }
    
    @Transactional(propagation=Propagation.REQUIRES_NEW, rollbackFor={SchedulerException.class})
    public void loadJobsConfig() throws SchedulerException{
    	try{
    		List<JobConfigVO> jobList = schedulerDAO.getJobListToAdd();
    		if(jobList != null && !jobList.isEmpty()){
    			ISchedulerService schedulerService = (ISchedulerService)com.bnp.scm.scheduler.util.ApplicationBeanContextFactory.getBean(ISchedulerService.class);
    			for(JobConfigVO jobConfig:jobList){
    				schedulerService.addJob(jobConfig);
    			}
    		}
    	}catch(DBException e){
    		LOGGER.error("Exception in loadJobsConfig ="+e);
			throw new SchedulerException(e.getMessage(),e);
    	}
    }
    
    @Transactional(propagation=Propagation.REQUIRES_NEW, rollbackFor=SchedulerException.class)
    public void addJob(JobConfigVO jobConfig)throws SchedulerException{
    	try{
			JobInfoVO jobInfoVO = new JobInfoVO();
			jobInfoVO.setGroupName(jobConfig.getGroupName());
			jobInfoVO.setJobName(jobConfig.getJobName());
			jobInfoVO.setJobClassName(jobConfig.getJobHandlerClassName());
			jobInfoVO.setPriority(jobConfig.getJobPrority());
			JobDetail jobDetail = jobBuilder.buildJob(jobInfoVO);
			jobInfoVO.setDurablity(true);
			//getScheduler().addJob(jobDetail, true);
			getScheduler(jobConfig.getGroupName()).addJob(jobDetail, true);
			schedulerDAO.updateActionFlag(Long.valueOf(jobConfig.getJobId()));
    	}catch(DBException e){
    		LOGGER.error("Exception in addJob ="+e);
			throw new SchedulerException(e.getMessage(),e);
    	}catch(org.quartz.SchedulerException e){
			LOGGER.error("Exception in addJob ="+e);
			throw new SchedulerException(e.getMessage(),e);
		}

    }

    //before the server start up, it will be called
	@Override
	@Transactional(propagation=Propagation.REQUIRES_NEW, rollbackFor={SchedulerException.class})
	public void scheduleJobs() throws SchedulerException {
		try{
			/*start of Pending Unschedule request*/
			ISchedulerService schedulerService = (ISchedulerService)com.bnp.scm.scheduler.util.ApplicationBeanContextFactory.getBean(ISchedulerService.class);
			List<ScheduleInfoVO> jobListToRemove = schedulerDAO.getScheduledJobListToRemove();
			if(jobListToRemove != null && !jobListToRemove.isEmpty()){
				for(ScheduleInfoVO vo:jobListToRemove){
					schedulerService.unScheduleJob(vo);
				}
			}
			/*end of Pending Unschedule request*/
			List<ScheduleInfoVO> jobListToSchedule = schedulerDAO.getJobListToSchedule();
			if(jobListToSchedule != null && !jobListToSchedule.isEmpty()){
				for(ScheduleInfoVO vo:jobListToSchedule){
					schedulerService.scheduleJob(vo);
				}
			}
			/*resuming jobslist*/
			List<ScheduleInfoVO> jobListToResume = schedulerDAO.getJobListToResume();
			for(ScheduleInfoVO vo:jobListToResume){
				schedulerService.resumeTrigger(vo.getEventRef());
			}
			/*End of resuming joblist*/
			/*pausing jobslist*/
			List<ScheduleInfoVO> jobListToPause = schedulerDAO.getJobListToPause();
			for(ScheduleInfoVO vo:jobListToPause){
				schedulerService.pauseTrigger(vo.getEventRef());
			}
			/*End of pausing joblist*/

		}catch(DBException e){
			LOGGER.error("Exception in scheduleJobs ="+e);
			throw new SchedulerException(e.getMessage(),e);
		}catch(org.quartz.SchedulerException e){
			LOGGER.error("Exception in scheduleJobs ="+e);
			throw new SchedulerException(e.getMessage(),e);
		}
	}
	
	/*This method is internal use. Not used for outside*/
	@Transactional(propagation=Propagation.REQUIRES_NEW, rollbackFor={DBException.class,SchedulerException.class})
	public void unScheduleJob(ScheduleInfoVO vo) throws DBException, org.quartz.SchedulerException,SchedulerException{
		
		String groupName = vo.getGroupName();
		if(groupName == null || "".equals(groupName)){
			String eventName = vo.getEventName();
			JobInfoVO jobInfoVO = schedulerDAO.getJobInfo(eventName);
			groupName = jobInfoVO.getGroupName();
		}

		TriggerKey triggerKey = new TriggerKey(vo.getEventRef().toString(), groupName);
		try{
			//getScheduler().unscheduleJob(triggerKey);
			Scheduler scheduler = getScheduler(groupName);
			scheduler.unscheduleJob(triggerKey);
			triggerKey = new TriggerKey(vo.getEventRef().toString(), vo.getEventRef().toString());
			scheduler.unscheduleJob(triggerKey);
			schedulerDAO.deleteScheduleInfo(vo.getEventRef());
		}catch(org.quartz.SchedulerException e){//This exception can't be rectified next time as well, that is the reason we have just update the schedule info table
			LOGGER.error("Error in scheduler "+e);
			ScheduleInfoVO infoVO = new ScheduleInfoVO();
			infoVO.setEventRef(vo.getEventRef());
			infoVO.setSchedulerError(e.getMessage());
			schedulerDAO.updateSchedulerError(infoVO);
		}
	}
	
	/*This method is internal use. Not used for outside*/
	@Transactional(propagation=Propagation.REQUIRES_NEW, rollbackFor={DBException.class,SchedulerException.class})
	public void scheduleJob(ScheduleInfoVO vo) throws DBException, org.quartz.SchedulerException, SchedulerException{
		/*Taking scheduleinfo*/
		ScheduleVO scheduleVO = schedulerDAO.getScheduleInfoDetail(vo.getEventRef());
		String actionFlag = vo.getActionFlag();
		
		boolean isRescheduleRequest = false;
		if(actionFlag != null && actionFlag.equals(SchedulerConstants.SCHEDULE_ACTION_FLAG.MODIFY.getValue())){
			isRescheduleRequest = true;
		}
		
		try{
			scheduleJob(scheduleVO, isRescheduleRequest);
		}catch(org.quartz.SchedulerException e){//This exception can't be rectified next time as well, that is the reason we have just update the schedule info table
			LOGGER.error("Modified Error in scheduler "+e.getMessage());
			ScheduleInfoVO infoVO = new ScheduleInfoVO();
			infoVO.setEventRef(vo.getEventRef());
			infoVO.setSchedulerError(e.getMessage());
			schedulerDAO.updateSchedulerError(infoVO);
		}catch(SchedulerException e){
			LOGGER.error("Modified Error in scheduler "+e.getErrorMessage());
			ScheduleInfoVO infoVO = new ScheduleInfoVO();
			infoVO.setEventRef(vo.getEventRef());
			infoVO.setSchedulerError(e.getErrorMessage());
			schedulerDAO.updateSchedulerError(infoVO);
		}
	}
	
	public void submitJob(String eventRef)throws DBException, org.quartz.SchedulerException, SchedulerException{
		
		ScheduleInfoVO scheduleVo = schedulerDAO.getScheduleInfo(eventRef);
		JobInfoVO jobInfoVO = schedulerDAO.getJobInfo(scheduleVo.getEventName());
		
        JobDataMap dataMap = new JobDataMap();
        
		dataMap.put(SchedulerConstants.PARAM_NAME_EVENT_NAME, scheduleVo.getEventName());
		dataMap.put(SchedulerConstants.PARAM_NAME_EVENT_REF, ""+eventRef);
		dataMap.put(SchedulerConstants.PARAM_NAME_TIME_ZONE, scheduleVo.getScheduleTimeZoneId());
		
		JobDetail jobDetail = jobBuilder.buildJob(jobInfoVO);
        //Scheduler scheduler = getScheduler();
		Scheduler scheduler = getScheduler(jobInfoVO.getGroupName());
        JobKey key = jobDetail.getKey();
        boolean isJobExists = scheduler.checkExists(key);
        if(!isJobExists){
        	scheduler.addJob(jobDetail, true);
        }
        scheduler.triggerJob(key, dataMap);

	}
	
	/*In the vo, it needs only eventRef,eventName, minis,days, hours, start date, end date*/
	private void scheduleJob(ScheduleVO scheduleVo, boolean isRescheduleRequest) throws org.quartz.SchedulerException, SchedulerException, DBException{
		String eventRef = scheduleVo.getEventRef();
        JobDataMap dataMap = new JobDataMap();
        
		dataMap.put(SchedulerConstants.PARAM_NAME_EVENT_NAME, scheduleVo.getEventName());
		dataMap.put(SchedulerConstants.PARAM_NAME_EVENT_REF, ""+eventRef);
		dataMap.put(SchedulerConstants.PARAM_NAME_TIME_ZONE, scheduleVo.getScheduleTimeZoneId());
		
		JobInfoVO jobInfoVO = scheduleVo.getJobInfoVO();// This will be set from schedule and reschedule job
		if(scheduleVo.getJobHandlerClassName() != null && !"".equals(scheduleVo.getJobHandlerClassName())){// This block is for static and adhoc jobs
			LOGGER.debug("Scheduling Static Job...");
			jobInfoVO = new JobInfoVO();
			jobInfoVO.setPriority(scheduleVo.getJobPirority());
			jobInfoVO.setJobClassName(scheduleVo.getJobHandlerClassName());
			jobInfoVO.setJobName(scheduleVo.getJobName());
			jobInfoVO.setGroupName(scheduleVo.getGroupName());
			jobInfoVO.setDurablity(false);
			//scheduleVo.setJobPirority(jobInfoVO.getPriority());
			//scheduleVo.setMisfireInst(jobInfoVO.getMisfireInst());
		}else if(jobInfoVO == null){
			jobInfoVO = schedulerDAO.getJobInfo(scheduleVo.getEventName());
			//scheduleVo.setJobPirority(jobInfoVO.getPriority());
			//scheduleVo.setMisfireInst(jobInfoVO.getMisfireInst());
		}
		//scheduleVo.setJobPirority(jobInfoVO.getPriority());
		//scheduleVo.setMisfireInst(jobInfoVO.getMisfireInst());
		
		JobDetail jobDetail = jobBuilder.buildJob(jobInfoVO);
        //boolean isJobExists = getScheduler().checkExists(jobDetail.getKey());
		Scheduler scheduler = getScheduler(jobInfoVO.getGroupName());
		boolean isJobExists = scheduler.checkExists(jobDetail.getKey());
        if(!isJobExists){
        	scheduler.addJob(jobDetail, true);//Just Load the Job.
        }
        
        SchedulerExpressionBuilder expre = SchedulerExpressionBuilder.build(scheduleVo, ""+eventRef, jobInfoVO.getGroupName(),jobDetail,dataMap);
        List<Trigger> triggerList = expre.getTrigger();
        if(isRescheduleRequest){
        	TriggerKey trigger = new TriggerKey(""+eventRef, jobInfoVO.getGroupName());
        	scheduler.unscheduleJob(trigger);
        	trigger = new TriggerKey(""+eventRef, ""+eventRef);
        	scheduler.unscheduleJob(trigger);
        }
    	for(Trigger trigger: triggerList){
    		scheduler.scheduleJob(trigger);
    	}
        //after successfully scheduling
        schedulerDAO.updateScheduleStatus(eventRef, SchedulerConstants.SCHEDULED_STATUS.YES.getValue(), "");
        String schStatus = (isRescheduleRequest ? SchedulerConstants.JOB_SCH_STATUS_RESCHEDULED : SchedulerConstants.JOB_SCH_STATUS_SCHEDULED); 
        if(SchedulerConstants.JOB_TYPE_ERP.equals(scheduleVo.getJobType()) || SchedulerConstants.JOB_TYPE_BRANCH.equals(scheduleVo.getJobType()) || SchedulerConstants.JOB_TYPE_SYSTEM.equals(scheduleVo.getJobType())){
        	schedulerDAO.updateJobSchedulerStatus(eventRef,schStatus,"");
        }
	}
	private String getGroupName(String eventRef) throws DBException{
		ScheduleInfoVO scheduleVo = schedulerDAO.getScheduleInfo(eventRef);
		String groupName = scheduleVo.getGroupName();
		if(groupName == null || "".equals(groupName)){
			String eventName = scheduleVo.getEventName();
			JobInfoVO jobInfoVO = schedulerDAO.getJobInfo(eventName);
			groupName = jobInfoVO.getGroupName();
		}
		return groupName;
	}

	@Override
	public void scheduleAdhocJobs(ScheduleVO scheduleVO) throws SchedulerException{
		long start = System.currentTimeMillis();
		LOGGER.warn("Adding loggers in Auto Disounting flow start time of scheduleAdhocJobs : "+start);
		scheduleVO.setJobPirority(1);
		scheduleVO.setMisfireInst(1);
		scheduleVO.setScheduleType(SCH_TYPE.ADHOC);
		scheduleJob(scheduleVO);
		long end = System.currentTimeMillis();
		LOGGER.warn("Adding loggers in Auto Disounting flow end time of scheduleAdhocJobs : "+end);
		LOGGER.warn("Adding loggers in Auto Disounting flow difference time of scheduleAdhocJobs : "+(end-start));
	}

}
