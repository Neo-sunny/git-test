package com.bnp.scm.scheduler.util;

import org.quartz.Scheduler;
import org.quartz.SchedulerException;

public class QuartzSchedulerServerFactory extends QuartzSchedulerFactoryNew{
	
	protected QuartzSchedulerServerFactory(){
		scheduler =(Scheduler)ApplicationBeanContextFactory.getBean("quartzSchedulerFactory");
	}
	
	public Scheduler getScheduler(String schedulerName) throws SchedulerException{
		if(scheduler == null){
			scheduler =(Scheduler)ApplicationBeanContextFactory.getBean("quartzSchedulerFactory");
		}
		return scheduler;
	}
}
