package com.bnp.scm.scheduler.util;

import java.io.Serializable;

import com.bnp.scm.scheduler.util.SchedulerConstants.JOB_RESULT;

public class JobResult implements Serializable{

	
	private JOB_RESULT result;
	
	private Throwable exception;

	public JOB_RESULT getResult() {
		return result;
	}

	public void setResult(JOB_RESULT result) {
		this.result = result;
	}

	public Throwable getException() {
		return exception;
	}

	public void setException(Throwable exception) {
		this.exception = exception;
	}
	
	
	
}
