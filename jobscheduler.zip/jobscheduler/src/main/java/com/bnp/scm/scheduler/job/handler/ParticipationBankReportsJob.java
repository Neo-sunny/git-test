/******************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 *
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 *
 * Created on:   13 Jun 2014
 *
 * Purpose: Participation Bank Report Job
 *
 * Change History:
 * Date                             Author                                Reason
 * ------------------------------------------------------------------------------------------------------------------------------
 * 13 Jun 2014                   Gnanalakshmi N                       Initial Version
 * 12 July 2014                  Balaji Sivaraman                     R6.0 Manual Workaround Addendum Changes
 * 24 Jun 2015					 Rajesh Velpuri						  R8.0 Email Inquiry Automatic Tracking Events changes
 * 17 Oct 2016					 Manoj Kushwaha						  R8.2 CSC-5903 UAT
 ********************************************************************************************************************************/
package com.bnp.scm.scheduler.job.handler;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.BNPReloadableResourceBundleMessageSource;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.mail.BNPEmailSender;
import com.bnp.scm.services.report.IScheduleReportService;
import com.bnp.scm.services.report.util.ReportConstants;
import com.bnp.scm.services.report.vo.ReportVO;

@Component
public class ParticipationBankReportsJob extends AbstractJob {

	private static final Logger LOGGER = LoggerFactory.getLogger(ParticipationBankReportsJob.class);

	@Autowired
	private IScheduleReportService schedulerService;
	
	@Autowired
	protected BNPPropertyLoaderConfigurer bnpPropertyLoader;

	@Autowired
	protected BNPReloadableResourceBundleMessageSource resourceBundle;
	
	@Autowired
	private BNPEmailSender emailSender;

	protected Locale locale = Locale.getDefault();
	
	private static Logger getLogger(){
		return LoggerFactory.getLogger(ParticipationBankReportsJob.class);
	}

	@Override
	public void run(Map<String, String> inputMap) throws SchedulerException {
      getLogger().debug("Entering ParticipationBankReportsJob");
        long reportId = Long.valueOf(inputMap.get(SchedulerConstants.PARAM_NAME_SCHEDULE_REPORT_ID).trim());
        long reportTypeId = Long.valueOf(inputMap.get(SchedulerConstants.PARAM_NAME_SCHEDULE_REPORT_TYPE_ID).trim());
      //FO 7.0 Fortify Issue Fix
		//LOGGER.debug("Report Id = " + reportId + " && Report Type Id = " + reportTypeId);
        try {
            Map<String, String> reportParams = getReportSpecificParams(reportTypeId);
            //int reportId = Integer.parseInt(reportParams.get("REPORT_ID"));
            getLogger().debug("Report Id " + reportId);
            String reportName = reportParams.get("REPORT_NAME");
            boolean isPayable = Boolean.valueOf(reportParams.get("IS_PAYABLE"));
            getLogger().debug("isPayable " + isPayable);
            //String eventNameForReport = reportParams.get("EVENT_NAME");
            Map<String, byte[]> attachReportMap = new HashMap<String, byte[]>();
            ReportVO reportVO = getReportVO(reportId, reportTypeId);
            //Set attachment File Name
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
            String fileName = reportVO.getTpBankIDShortName() + "." + reportParams.get("Report ID") + "." + reportVO.getCountryCodeValue() + ".";
            if ("C".equals(reportVO.getReportOption())) {
                List<String> ccyList = schedulerService.getCurrencyList(reportVO);
              //976332 CSCDEV-2683 18-NOV-2014:START
                //getLogger().debug("The List Of Currencies are as follows :: " + ccyList);
              //976332 CSCDEV-2683 18-NOV-2014:END
                if (isPayable) {
                    if (ccyList != null && ccyList.size() > 0) {
                        reportVO.setReportOption(ReportConstants.SUMMARY);
                            attachReportMap.put(fileName + "Summary" + "." + dateFormat.format(new Date()) + ".csv", generateReport(reportVO));
                            schedulerService.insertFileContent(reportVO);
                        reportVO.setReportOption(ReportConstants.DETAILED);
                        for (String ccy : ccyList) {
                            reportVO.setCurrency(ccy);
                            byte[] detailedCurrencyReport = generateReport(reportVO);
                                attachReportMap.put(fileName + ccy + "." + "Detail" + "." + dateFormat.format(new Date()) + ".csv", detailedCurrencyReport);
                                schedulerService.insertFileContent(reportVO);
                            getLogger().debug("GENERATED REPORT FOR INDIVIDUAL CURRENCIES with name ::" + reportName + "_" + ccy + "_Detailed");
                        }
                    }
                    else {
                    	 reportVO.setReportOption(ReportConstants.SUMMARY);
                             attachReportMap.put(fileName + "Summary" + "." + dateFormat.format(new Date()) + ".csv", generateReport(reportVO));
                             schedulerService.insertFileContent(reportVO);
                         reportVO.setReportOption(ReportConstants.DETAILED);
                         String ccy = "CCYNULL";
                         byte[] detailedCurrencyReport = generateReport(reportVO);
                             attachReportMap.put(fileName + ccy + "." + "Detail" + "." + dateFormat.format(new Date()) + ".csv", detailedCurrencyReport);
                             schedulerService.insertFileContent(reportVO);
                         getLogger().debug("GENERATED REPORT FOR INDIVIDUAL CURRENCIES with name ::" + reportName + "_" + ccy + "_Detailed");
                    }
                } else {
                    if (ccyList != null && ccyList.size() > 0) {
                        for (String ccy : ccyList) {
                            reportVO.setCurrency(ccy);
                            reportVO.setReportOption(ReportConstants.SUMMARY);
                            byte[] summary = generateReport(reportVO);
                            reportVO.setReportOption(ReportConstants.DETAILED);
                            byte[] detail = generateReport(reportVO);
                            byte[] mergedReport = mergeReceivableSummaryAndDetailReports(summary, detail);
                                attachReportMap.put(fileName + ccy + "." + dateFormat.format(new Date()) + ".csv", mergedReport);
                                reportVO.setFileContent(mergedReport);
                                schedulerService.insertFileContent(reportVO);
                            getLogger().debug("GENERATED REPORT FOR INDIVIDUAL CURRENCIES BOTH SUMMARY AND DETAIL ::" + reportId);
                        }
                    }
                    else {
                    	String ccy = "CCYNULL";
                    	reportVO.setReportOption(ReportConstants.SUMMARY);
                        byte[] summary = generateReport(reportVO);
                        reportVO.setReportOption(ReportConstants.DETAILED);
                        byte[] detail = generateReport(reportVO);
                        byte[] mergedReport = mergeReceivableSummaryAndDetailReports(summary, detail);
                            attachReportMap.put(fileName + ccy + "." + dateFormat.format(new Date()) + ".csv", mergedReport);
                            reportVO.setFileContent(mergedReport);
                            schedulerService.insertFileContent(reportVO);
                        getLogger().debug("GENERATED REPORT FOR INDIVIDUAL CURRENCIES BOTH SUMMARY AND DETAIL ::" + reportId);
                    }
                  
                }
            } else {
                if (isPayable) {
                    reportVO.setReportOption(ReportConstants.SUMMARY);
                        attachReportMap.put(fileName + "Summary" + "." + dateFormat.format(new Date()) + ".csv", generateReport(reportVO));
                        schedulerService.insertFileContent(reportVO);
                    reportVO.setReportOption(ReportConstants.DETAILED);
                        attachReportMap.put(fileName + "Detail" + "." + dateFormat.format(new Date()) + ".csv", generateReport(reportVO));
                        schedulerService.insertFileContent(reportVO);
                    getLogger().debug("PAYANBLE DETAIL ::" + reportId);
                } else {
                	if(reportTypeId == ReportConstants.OBLIGOR_LIST_REPORT_ID) {
                             attachReportMap.put(fileName + "." + dateFormat.format(new Date()) + ".csv", generateReport(reportVO));
                             schedulerService.insertFileContent(reportVO);
                             getLogger().debug("OBLIGOR LIST REPORT ::" + reportId);
                	}
                	else {
                    reportVO.setReportOption(ReportConstants.SUMMARY);
                    byte[] summary = generateReport(reportVO);
                    reportVO.setReportOption(ReportConstants.DETAILED);
                    byte[] detail = generateReport(reportVO);
                    byte[] mergedReport = mergeReceivableSummaryAndDetailReports(summary, detail);
                        attachReportMap.put(fileName + dateFormat.format(new Date()) + ".csv", mergedReport);
                        reportVO.setFileContent(mergedReport);
                        schedulerService.insertFileContent(reportVO);
                    getLogger().debug("GENERATED REPORT FOR INDIVIDUAL CURRENCIES BOTH SUMMARY AND DETAIL :: NOT PAYABLE" + reportId);
                	}
                }
            }
            if (reportTypeId == ReportConstants.IND_FUND_REQ_PAY && reportVO.isAttachPartCert()) {
            	reportVO.setReportId(Integer.parseInt(ReportConstants.PARTICIPATION_CERT_REPORT_ID));
                reportVO.setReportFormat(ReportConstants.PDF_FORMAT);
                if(reportVO.getCurrency() != null) {
                	reportVO.setCurrency(null);
                }
                byte[] participationReport = (byte[]) schedulerService.generateParticipationBankReport(reportVO).get("fileContent");
	                attachReportMap.put(fileName + dateFormat.format(new Date()) + ".pdf", participationReport);
	                reportVO.setFileContent(participationReport);
	                schedulerService.insertFileContent(reportVO);
	                getLogger().debug("PARTICIPATION BANK REPORT :: " + reportId);
            }
            reportVO.setCustomReportName(reportParams.get("REPORT_NAME"));
            reportVO.setTemplateName(fileName);
            reportVO.setGroupAttachmentMap(attachReportMap);
            reportVO.setNoteName(reportParams.get("NOTE_NAME"));


            if ((attachReportMap.size() > 0 && reportVO.getReportDelivery().contains(ReportConstants.EMAIL) && !reportVO.isNoRecords()) || reportVO.isBlankReportDelivery()) {
                emailReport(reportVO);
                getLogger().debug("Sending mail");
            } else {
                getLogger().debug("The email is blank ,not having any attachements or The attachment is having empty records");
            }
            getLogger().debug("Exiting ParticipationBankReportsJob");
        } catch (BNPApplicationException exception) {
            LOGGER.error("Exception Occured while Executing the ParticipationBankReportsJob" + exception.getMessage(), exception);
            throw new SchedulerException(exception.errorCode, exception.getMessage());
        }
    }


	/**
     * This method was added for R6.0 Manual Workaround changes.
     * It sets the report specific parameters based on the eventName.
     * @param reportTypeId the report type ID
     * @return the map populated with report specific parameters
     */
    private Map<String, String> getReportSpecificParams(long reportTypeId) {
        Map<String, String> reportParamsMap = new HashMap<String, String>();
        switch ((int)reportTypeId) {
            case 55:
                reportParamsMap.put("REPORT_NAME", "Indicative Funding Request Report Receivables");
                reportParamsMap.put("Report ID","IFR");
                reportParamsMap.put("NOTE_NAME", "Attached the details of the funding requests sent today.");
                reportParamsMap.put("IS_PAYABLE", "false");
                break;
            case 56:
                reportParamsMap.put("REPORT_NAME", "Confirmed Funding Request Report Receivables");
                reportParamsMap.put("Report ID","CFR");
                reportParamsMap.put("NOTE_NAME", "Attached the details of the funding requests confirmed today.");
                reportParamsMap.put("IS_PAYABLE", "false");
                break;
            case 57:
                reportParamsMap.put("REPORT_NAME", "Settlement Status Report Receivables");
                reportParamsMap.put("Report ID","SSR");
                reportParamsMap.put("NOTE_NAME","Attached the details of the transactions insettled today.");
                reportParamsMap.put("IS_PAYABLE", "false");
                break;
            case 58:
                reportParamsMap.put("REPORT_NAME", "Indicative Funding Request Report Payables");
                reportParamsMap.put("Report ID","IFR");
                reportParamsMap.put("NOTE_NAME","Attached the details of the funding requests sent today.");
                reportParamsMap.put("IS_PAYABLE", "true");
                break;
            case 59:
                reportParamsMap.put("REPORT_NAME", "Confirmed Funding Request Report Payables");
                reportParamsMap.put("Report ID","CFR");
                reportParamsMap.put("NOTE_NAME","Attached the details of the funding requests sent today.");
                reportParamsMap.put("IS_PAYABLE", "true");
                break;
            case 61:
                reportParamsMap.put("REPORT_NAME", "Indicative Risk Notification Report");
                reportParamsMap.put("Report ID","IRN");
                reportParamsMap.put("NOTE_NAME","Attached the details of the commitment participation requests sent today.");
                reportParamsMap.put("IS_PAYABLE", "false");
                break;
            case 62:
                reportParamsMap.put("REPORT_NAME", "Confirmed Risk Notification Report");
                reportParamsMap.put("Report ID","CRN");
                reportParamsMap.put("NOTE_NAME","Attached the details of the commitment participation requests confirmed today.");
                reportParamsMap.put("IS_PAYABLE", "false");
                break;
            case 63:
                reportParamsMap.put("REPORT_NAME", "Settlement Status Notification Report");
                reportParamsMap.put("Report ID","SSN");
                reportParamsMap.put("NOTE_NAME","Attached the details of the transactions settled today.");
                reportParamsMap.put("IS_PAYABLE", "false");
                break;
            case 64:
                reportParamsMap.put("REPORT_NAME", "Obligor List Report");
                reportParamsMap.put("Report ID","OLR");
                reportParamsMap.put("NOTE_NAME","Attached the Obligor list.");
                reportParamsMap.put("IS_PAYABLE", "false");
                break;
            case 65:
                reportParamsMap.put("REPORT_NAME", "Settlement Status Report Payables");
                reportParamsMap.put("Report ID","SSR");
                reportParamsMap.put("NOTE_NAME","Attached the details of the funding requests sent today.");
                reportParamsMap.put("IS_PAYABLE", "true");
                break;
        }
        return reportParamsMap;
    }
    
	public void emailReport(ReportVO reportVO) throws BNPApplicationException{
		Map<Object,Object> model = new HashMap<Object, Object>();
		model.put("toList", reportVO.getToemail());
		model.put("ccList",reportVO.getCcemail()); // CSCDEV - 2748 STARTS
		model.put("bccList",reportVO.getBccemail()); // CSCDEV - 2748 ENDS
		model.put("subject", reportVO.getCustomReportName());
		model.put("multiAttach", "Y");
		model.put("multiAttachMap", reportVO.getGroupAttachmentMap());
		model.put("compressAttachment", "N");
		model.put("ReportName", reportVO.getTemplateName());
		model.put("attachedSubject", reportVO.getCustomReportName());
		model.put("attachedPleaseNote", reportVO.getNoteName());
		// Added for R8.0 Email Inquiry Changes  Starts
		//A33348 CSC-5903 17-Oct-2016 - Starts
		//model.put(BNPConstants.EVENT_NAME, BNPConstants.EMAIL_STANDARD_REPORT_EVENTNAME);
		model.put(BNPConstants.EVENT_NAME, BNPConstants.STANDARD_REPORT_NAME_PRIFIX + BNPConstants.SPACE 
					+ BNPConstants.LINE_SEPARATOR + BNPConstants.SPACE + reportVO.getCustomReportName());
		model.put(BNPConstants.REF_KEY_ID, reportVO.getSchReportID());
		//A33348 CSC-5903 17-Oct-2016 - End
		model.put(BNPConstants.EVENT_ID, BNPConstants.EMAIL_STANDARD_REPORT_ID);
		model.put(BNPConstants.EMAIL_CATEGORY, BNPConstants.THIRD_PARTY);
		//A33348 CSC-5903 17-Oct-2016 - Starts
		//model.put(BNPConstants.EVENT_ORG_ID, reportVO.getOrgId());
		model.put(BNPConstants.EVENT_ORG_ID, reportVO.getReportOrgId());
		//A33348 CSC-5903 17-Oct-2016 - End
		// Added for R8.0 Email Inquiry Changes Ends
		String template = bnpPropertyLoader.getValue("participationJob.template.mail");
		emailSender.sendMail(model, template, "Y".equals(reportVO.getSecureFlag()) ? true : false);
	}

    /**
     * This method was added for R6.0 Manual Workaround changes.
     * Based on the eventName, it generates payable and receivable reports accordingly.
     * @param reportVO
     * @return the attachment file content byte array
     * @throws SchedulerException
     */
	private byte[] generateReport(ReportVO reportVO) throws SchedulerException {
		Map<String, Object> reportData;
        byte[] fileContent;
        try {
            reportData = schedulerService.generateParticipationBankReport(reportVO);
            fileContent = (byte[]) reportData.get("fileContent");
        } catch (BNPApplicationException e) {
			LOGGER.error("Error occured while getting the generateReport data"+e.getMessage(), e);
			throw new SchedulerException(e.errorCode,e.getMessage());
		}
        return fileContent;
	}

    /**
     * This method was added for R6.0 Manual Workaround changes.
     * It takes as input parameters the byte array for summary and detail reports
     * and merges them into a single byte array. It als adds an extra line in between both.
     * @param summary
     * @param detail
     * @return the byte array containing the merged content
     */
    private byte[] mergeReceivableSummaryAndDetailReports(byte[] summary, byte[] detail) {
        byte[] extraLine = ReportConstants.CSV_BLANK_LINE.getBytes();
        byte[] mergedReport = new byte[summary.length + extraLine.length + detail.length];
        System.arraycopy(summary, 0, mergedReport, 0, summary.length);
        System.arraycopy(extraLine, 0, mergedReport, summary.length, extraLine.length);
        System.arraycopy(detail, 0, mergedReport, summary.length + extraLine.length, detail.length);
        return mergedReport;
    }

    private ReportVO getReportVO(long reportId, long reportTypeId) throws BNPApplicationException {
        return schedulerService.getManualWorkaroundRepParams(reportId, reportTypeId);
    }
}
