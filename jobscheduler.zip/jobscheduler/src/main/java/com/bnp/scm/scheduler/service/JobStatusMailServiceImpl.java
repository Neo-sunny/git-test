package com.bnp.scm.scheduler.service;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.dao.JobExecHistDAO;
import com.bnp.scm.scheduler.vo.JobExecHistVO;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.mail.BNPEmailSender;

@Component
public class JobStatusMailServiceImpl implements JobStatusMailService{

    private static Logger LOGGER = LoggerFactory.getLogger(JobStatusMailServiceImpl.class);

	@Autowired
	private BNPEmailSender emailSender;

	@Autowired
	BNPPropertyLoaderConfigurer bnpPropertyLoader;

	@Autowired
	JobExecHistDAO jobExecHistDAO;
	
	@Override
	public void sendJobStatusMail(JobExecHistVO jobExecHistVO){
		try{
			Map<Object,Object> model = new HashMap<Object, Object>();
			JobExecHistVO jobHistVO = jobExecHistDAO.getJobHistoryDetail(jobExecHistVO);
			String template = bnpPropertyLoader.getValue("jobstatus.template.vm");
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("Job Status Mail Template--->" + template);
			String mailIds = bnpPropertyLoader.getValue("mail.email.jobstatus.tolist");
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("Job Status Mail toList--->" + mailIds);
			String subject = bnpPropertyLoader.getValue("mail.email.jobstatus.subject");
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("Job Status Mail subject--->" + subject);
			MessageFormat formatter = new MessageFormat("");
			formatter.applyPattern(subject);
			String dynamicMailSubject = formatter.format(new String[]{jobHistVO.getJobName(),jobHistVO.getStartTime().toString()});
			//976332 CSCDEV-2683 19-NOV-2014:START
			//LOGGER.debug("Job Status Mail subject--->" + dynamicMailSubject);
			//976332 CSCDEV-2683 19-NOV-2014:END
			model.put("subject", dynamicMailSubject);
			model.put("toList", mailIds);
			model.put("jobHistVO",jobHistVO);
			model.put("locale", Locale.ENGLISH);
			model.put("bnpPropertyLoader", bnpPropertyLoader);
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("gscm.url--->" + bnpPropertyLoader.getValue("gscm.url"));
			//976332 CSCDEV-2683 19-NOV-2014:START
			//LOGGER.debug("Job Status model-->" + model);
			//976332 CSCDEV-2683 19-NOV-2014:END
			
			emailSender.sendMail(model, template, false);
		}catch(Exception e){
			LOGGER.error("Exception while sending the Job status-->" + e.getMessage());
		}
	}
}
