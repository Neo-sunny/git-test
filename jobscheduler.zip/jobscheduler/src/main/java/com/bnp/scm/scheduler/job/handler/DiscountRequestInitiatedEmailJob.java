/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * 
 * 
 * Created on: 03 December 2013
 * 
 * Purpose: Discount Request Initiated Email Job Handler
 * 
 * Change History: 
 * Date                             Author                                		Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 03 December 2013                 Nasreen Shaikh                             For CSCDEV-93
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.job.handler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.scheduler.events.DisRequestInitiatedEmailEvent;
import com.bnp.scm.services.scheduler.events.IEvent;
import com.bnp.scm.services.scheduler.exception.BNPSchedulerException;


@Component
public class DiscountRequestInitiatedEmailJob extends AbstractJob {

	public static final Logger LOGGER = LoggerFactory.getLogger(DiscountRequestInitiatedEmailJob.class);
	@Override
	public void run(Map<String, String> inputMap) throws SchedulerException {
		LOGGER.debug("DiscountRequestInitiatedEmailJob--Beg");

		String[] arg = getArgs(inputMap);
		// Processing Funded Transactions
		processEvent(arg);
		List<String> tempList =  new ArrayList<String>(Arrays.asList(arg));		
		tempList.add("Y");
		String[] unfundedArgs = new String[tempList.size()];
		tempList.toArray(unfundedArgs);
		//Processing unfunded Transactions
		processEvent(unfundedArgs);
		LOGGER.debug("DiscountRequestInitiatedEmailJob--End");
	}
	
	private void processEvent(String[] args) throws SchedulerException
	{
		IEvent iEvent = (IEvent)ApplicationBeanContextFactory.getBean(DisRequestInitiatedEmailEvent.class);
		LOGGER.debug("after application bean context factory ");
		try	{
			iEvent.processEvent(args);
		}catch (BNPSchedulerException e) {
			LOGGER.error(e.getMessage(), e);
			throw new SchedulerException(e.errorCode,e.getMessage());
		}finally {
			iEvent = null;
		}	
	}
	
	private String[] getArgs(Map<String, String> inputMap) {
		
			String[] arg = new String[8];
			arg[0] = "";
			arg[1] = inputMap.get(SchedulerConstants.PARAM_NAME_BRANCH_ID);
			arg[2] = inputMap.get(SchedulerConstants.PARAM_NAME_ORG_ID);
			arg[3] = inputMap.get(SchedulerConstants.PARAM_NAME_CCY);
			arg[4] = inputMap.get(SchedulerConstants.PARAM_NAME_PYMT_METHOD);
			arg[5] = inputMap.get(SchedulerConstants.PARAM_NAME_CUSTOM_PARAM);
			arg[6] = BNPConstants.DISCOUNT_INITIATED_STATUS;//"DiscountInitiatedStatus";
			arg[7] = inputMap.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID);
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("DiscountRequestInitiatedEmailJob--arg-0->" + arg[0] + "<arg-1->" + arg[1] + "<arg-2->" + arg[2] + "<arg-3->" + arg[3] + "<arg-4->" + arg[4] + "<arg-5->" + arg[5] + "<arg-6->" + arg[6] + "<arg-7->" + arg[7]);
			return arg;
			
	}
}
