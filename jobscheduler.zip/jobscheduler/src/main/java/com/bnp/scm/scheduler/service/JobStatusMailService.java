package com.bnp.scm.scheduler.service;

import com.bnp.scm.scheduler.vo.JobExecHistVO;

public interface JobStatusMailService {
	void sendJobStatusMail(JobExecHistVO jobExecHistVO);
}
