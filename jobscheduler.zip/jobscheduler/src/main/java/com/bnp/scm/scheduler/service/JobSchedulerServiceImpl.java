/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Apr 2012
 * 
 * Purpose: Job Scheduler Service Implementation
 * 
 * Change History: 
 * Date                             Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 25 Apr 2012                      Ramesh A                              Initial Version
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnp.scm.scheduler.dao.ISchedulerDAO;
import com.bnp.scm.scheduler.dao.JobConfigDAO;
import com.bnp.scm.scheduler.dao.JobSchedulerDAO;
import com.bnp.scm.scheduler.dao.ScheduleInfoDAO;
import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.services.common.ApplicationBeanContextFactory;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.scheduler.util.SchedulerThreadManager;
import com.bnp.scm.scheduler.util.SchedulerConstants.HOURS;
import com.bnp.scm.scheduler.util.SchedulerConstants.SCH_TYPE;
import com.bnp.scm.scheduler.util.SchedulerUtil;
import com.bnp.scm.scheduler.util.SchedulerConstants.DAYS;
import com.bnp.scm.scheduler.vo.JobConfigVO;
import com.bnp.scm.scheduler.vo.JobSchedulerVO;
import com.bnp.scm.scheduler.vo.ScheduleInfoVO;
import com.bnp.scm.scheduler.vo.ScheduleVO;
import com.bnp.scm.services.common.AbstractServiceImpl;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.BNPMonth;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.dao.IAbstractDAO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.util.BNPCommonUtil;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.common.vo.AbstractVO;
import com.bnp.scm.services.common.vo.NameValueVO;

@Component
public class JobSchedulerServiceImpl extends AbstractServiceImpl implements JobSchedulerService{

	private static final Logger LOGGER = LoggerFactory.getLogger(JobSchedulerServiceImpl.class);

	@Autowired
	private JobSchedulerDAO jobSchedulerDAO;
	
	@Autowired
	private ScheduleInfoDAO scheduleInfoDAO;
	
	@Autowired
	private JobConfigDAO jobConfigDAO;

	@Autowired
	private ISchedulerService schedulerService;

	@Autowired
	private ISchedulerDAO schedulerDAO;
	
	@Autowired
	private BNPPropertyLoaderConfigurer propertyLoader;
	
	@Override
	public IAbstractDAO getDAO() {
		return jobSchedulerDAO;
	}

	@Override
	public List<JobSchedulerVO> getJobSchedulerDetail(JobSchedulerVO jobSchedulerVO) throws BNPApplicationException {
		LOGGER.debug("JobSchedulerServiceImpl-getAllJobNames-start");
		return jobSchedulerDAO.getJobSchedulerDetail(jobSchedulerVO);
	}
	
	@Override
	public List<NameValueVO> getSupportBranchList(String userId) throws BNPApplicationException {
		LOGGER.debug("JobSchedulerServiceImpl-getAllJobNames-start");
		return jobSchedulerDAO.getSupportBranchList(userId);
	}

	@Override
	public List<NameValueVO> getJobNameSpectoType(String jobType) throws BNPApplicationException{
		LOGGER.debug("JobSchedulerServiceImpl-getAllJobNames-Beg");
		return jobSchedulerDAO.getJobNameSpectoType(jobType);
	}

	@Override
	public List<NameValueVO> getERPJobNamesforOrgId(String orgId) throws BNPApplicationException{
		LOGGER.debug("JobSchedulerServiceImpl-getERPJobNamesforOrgId-Beg");
		return jobSchedulerDAO.getERPJobNamesforOrgId(orgId);
	}

	@Override
	public JobConfigVO getJobConfigDetail(String jobName) throws BNPApplicationException{
		LOGGER.debug("JobSchedulerServiceImpl-getJobConfigDetail-Beg");
		return jobConfigDAO.getJobConfiguration(jobName);
	}
	
	@Override
	public List<NameValueVO> getPaymentMethods() throws BNPApplicationException {
		LOGGER.debug("JobSchedulerServiceImpl-getPaymentMethods-start");
		return jobSchedulerDAO.getPaymentMethods();
	}

	public List<NameValueVO> getUserandBranchSpecOrgIdList(String userId,String branchId) throws BNPApplicationException{
		LOGGER.debug("JobSchedulerServiceImpl-getUserandBranchSpecOrgIdList-start");
		return jobSchedulerDAO.getUserandBranchSpecOrgIdList(userId,branchId);
	}
	
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public void approveRecord(AbstractVO abstractJobSchedulerVO) throws BNPApplicationException {
		super.approveRecord(abstractJobSchedulerVO);
		if(abstractJobSchedulerVO instanceof JobSchedulerVO){
			JobSchedulerVO jobSchedulerVO = (JobSchedulerVO)abstractJobSchedulerVO;
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("JobSchedulerServiceImpl - ActiveStatus-->" + jobSchedulerVO.getActiveStatus() + "< RecordStatus--->" + jobSchedulerVO.getRecordStatus() + "<");
			if(!(BNPConstants.YES.equals(jobSchedulerVO.getActiveStatus())) || StatusConstants.DELETE_RECORD.equals(jobSchedulerVO.getAuditRecordStatus())){
				if(checkScheduleStatus(jobSchedulerVO)){
					LOGGER.debug("JobSchedulerServiceImpl - approveRecord - Unscheduling part");
		    		String schedulerThreadEnable = propertyLoader.getValue("scheduler.enable.thread.processing");
		    		//FO 7.0 Fortify Issue Fix
					//LOGGER.debug("schedulerThreadEnable-->" + schedulerThreadEnable);
		    		if(SchedulerConstants.SCHEDULED_STATUS.YES.getValue().equals(schedulerThreadEnable)){
		    			try {
		    				SchedulerThreadManager schedulerThreadManager = (SchedulerThreadManager)ApplicationBeanContextFactory.getBean("schedulerThreadManager");
		    				schedulerThreadManager.unscheduleJob(jobSchedulerVO.getJobRef(),jobSchedulerVO.getJobType(), schedulerDAO);
		    			} catch (Exception e) {
		    				LOGGER.error("Exception while Scheduling Job" + e);
		    			}
		        	}else{
		        		schedulerService.unscheduleJob(((JobSchedulerVO)jobSchedulerVO).getJobRef(),((JobSchedulerVO)jobSchedulerVO).getJobType());
		        	}
				}	
			}else{
				LOGGER.debug("JobSchedulerServiceImpl - approveRecord - Scheduling part");
				scheduleJob(jobSchedulerVO);
			}
		}	
	}
	
	private void scheduleJob(JobSchedulerVO jobSchedulerVO) throws BNPApplicationException{
		LOGGER.debug("JobSchedulerServiceImpl - start of buildScheduleVO");
		ScheduleVO scheduleVO = new ScheduleVO();
		scheduleVO.setEventRef(jobSchedulerVO.getJobRef());
		scheduleVO.setJobType(jobSchedulerVO.getJobType());
		scheduleVO.setEventName(jobSchedulerVO.getJobName());
		//String timeZone = scheduleInfoDAO.getUserBranchTimeZone(scheduleVO.getEventRef());
		//timeZone = (timeZone == null) ? jobSchedulerVO.getTimeZone():BNPCommonUtil.getTimeZoneID(timeZone);
		if(jobSchedulerVO.getTimeZone() != null){
			//914725 CSCDEV-2531 26-AUG-2014 Starts
			//Retrieving TimeZoneID from Enum class for the timezone
			scheduleVO.setScheduleTimeZoneId(BNPCommonUtil.getTimeZoneID(jobSchedulerVO.getTimeZoneId()));
			//914725 CSCDEV-2531 26-AUG-2014 Ends
		}
		scheduleVO.setStartDate(jobSchedulerVO.getSchEffectiveDate());
		scheduleVO.setEndDate(jobSchedulerVO.getSchExpiryDate());
		if(jobSchedulerVO.getSelectedMonth() != null && jobSchedulerVO.getSelectedMonth().size() > 0){
			scheduleVO.setMonths(jobSchedulerVO.getSelectedMonth().toArray(new String[jobSchedulerVO.getSelectedMonth().size()]));
		}else{
			scheduleVO.setMonths(new String[]{BNPMonth.ALLMONTH.getValue()});
		}
		if(jobSchedulerVO.getSelectedDayofMonth() != null && jobSchedulerVO.getSelectedDayofMonth().size() > 0){
			scheduleVO.setMonthOfDay(jobSchedulerVO.getSelectedDayofMonth().toArray(new String[jobSchedulerVO.getSelectedDayofMonth().size()]));
		}else{
			scheduleVO.setMonthOfDay(null);
		}
		if(jobSchedulerVO.getSelectedHours() != null && jobSchedulerVO.getSelectedHours().size() > 0){
			scheduleVO.setHours(jobSchedulerVO.getSelectedHours().toArray(new String[jobSchedulerVO.getSelectedHours().size()]));
		}else{
			scheduleVO.setHours(new String[]{HOURS.ALL.getValue()});
		}
		if(jobSchedulerVO.getSelectedMins() != null && jobSchedulerVO.getSelectedMins().size() > 0){
			scheduleVO.setMinis(jobSchedulerVO.getSelectedMins().toArray(new String[jobSchedulerVO.getSelectedMins().size()]));
		}else{
			scheduleVO.setMinis(null);
		}
		scheduleVO.setDays(getDaysArrayFromList(jobSchedulerVO.getSelectedWeekDay()));
		if(scheduleVO.getMonthOfDay() == null && scheduleVO.getDays() == null){
			scheduleVO.setDays(new DAYS[]{DAYS.ALL});
		}
		Map<String,String> input = new HashMap<String, String>();
		input.put(SchedulerConstants.PARAM_NAME_BRANCH_ID, jobSchedulerVO.getSchBranch());
		input.put(SchedulerConstants.PARAM_NAME_ORG_ID, jobSchedulerVO.getSchOrgId());
		input.put(SchedulerConstants.PARAM_NAME_CCY, jobSchedulerVO.getCcy());
		input.put(SchedulerConstants.PARAM_NAME_PYMT_METHOD, jobSchedulerVO.getPymtMethod());
		input.put(SchedulerConstants.PARAM_NAME_CUSTOM_PARAM, jobSchedulerVO.getCustomparam());
		//914725 Changes for CSCDEV-3245 Start
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("CSCDEV-3245 Job Type="+jobSchedulerVO.getJobType());
		input.put(SchedulerConstants.PARAM_NAME_ORIG_JOB_TYPE, jobSchedulerVO.getJobType());
		//914725 Changes for CSCDEV-3245 End
		scheduleVO.setInput(input);
		scheduleVO.setScheduleType(SCH_TYPE.SCHEDULED);
		try{
			LOGGER.debug("JobSchedulerServiceImpl - before scheduling the request");
			if(checkScheduleStatus(jobSchedulerVO)){
				schedulerService.rescheduleJob(scheduleVO);
			}else{
				schedulerService.scheduleJob(scheduleVO);
			}
			LOGGER.debug("JobSchedulerServiceImpl - after scheduling the request");
		}catch(SchedulerException e){
			LOGGER.error("JobSchedulerServiceImpl - Exception in scheduling"+e);
			throw new BNPApplicationException(e.errorCode,e.getMessage());
		}
		LOGGER.debug("JobSchedulerServiceImpl - end of buildScheduleVO");
	}

	private boolean checkScheduleStatus(JobSchedulerVO jobSchedulerVO) throws BNPApplicationException{
		boolean rescheduleFlg = false;
		ScheduleInfoVO infoVO = scheduleInfoDAO.getScheduleInfo(jobSchedulerVO.getJobRef());
		if(infoVO != null){
			rescheduleFlg = true;
		}
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("JobSchedulerServiceImpl - checkScheduleStatus-->" + rescheduleFlg);
		return rescheduleFlg;
	}
	
	private DAYS[] getDaysArrayFromList(List<String> inputList){
		DAYS[] returnDays = null;
		if(inputList != null && inputList.size() > 0){
			returnDays = new DAYS[inputList.size()];
			int i = 0;
			for(String day : inputList){
				returnDays[i++] = SchedulerUtil.getDay(day);
			}
		}
		return returnDays;
	}

	

	@Override
	public List<NameValueVO> getTimeZoneList() throws BNPApplicationException {
		
		return jobSchedulerDAO.getTimeZoneDetailList();
	}
	@Override
	public NameValueVO getUserBranchTimeZone(String userId)
			throws BNPApplicationException {
		
		return jobSchedulerDAO.getUserBranchTimeZone(userId);
	}
}
