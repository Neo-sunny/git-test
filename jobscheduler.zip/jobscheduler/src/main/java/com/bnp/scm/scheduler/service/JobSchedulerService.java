/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Apr 2012
 * 
 * Purpose: Interface for Job Scheduler Service
 * 
 * Change History: 
 * Date                             Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 25 Apr 2012                      Ramesh A                              Initial Version
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.service;

import java.util.List;

import com.bnp.scm.scheduler.vo.JobConfigVO;
import com.bnp.scm.scheduler.vo.JobSchedulerVO;
import com.bnp.scm.services.common.IAbstractService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

public interface JobSchedulerService extends IAbstractService{
	List<JobSchedulerVO> getJobSchedulerDetail(JobSchedulerVO jobSchedulerVO)throws BNPApplicationException;
	List<NameValueVO> getSupportBranchList(String userId) throws BNPApplicationException;
	List<NameValueVO> getJobNameSpectoType(String userId) throws BNPApplicationException;
	List<NameValueVO> getPaymentMethods() throws BNPApplicationException;
	List<NameValueVO> getERPJobNamesforOrgId(String orgId) throws BNPApplicationException;
	JobConfigVO getJobConfigDetail(String jobName) throws BNPApplicationException;
	List<NameValueVO> getUserandBranchSpecOrgIdList(String userId,String branchId) throws BNPApplicationException;
	List<NameValueVO> getTimeZoneList() throws BNPApplicationException;
	NameValueVO getUserBranchTimeZone(String userId) throws BNPApplicationException;
}
