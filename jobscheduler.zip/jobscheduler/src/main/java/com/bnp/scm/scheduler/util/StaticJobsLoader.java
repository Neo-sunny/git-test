package com.bnp.scm.scheduler.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.service.ISchedulerService;
import com.bnp.scm.scheduler.util.SchedulerConstants.DAYS;
import com.bnp.scm.scheduler.util.SchedulerConstants.SCHEDULE_ACTION_FLAG;
import com.bnp.scm.scheduler.vo.ScheduleVO;

public class StaticJobsLoader {

	/*Run as client mode*/
	//static final SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy");
	static String HANDLER = "handler";
	static String PARAM   = "param";
	static String PARAM_NAME   = "name"; 
	static String PARAM_VALUE   = "value";
	static String ACTION_FLAG = "action";
	static String HOURS = "hours";
	static String MINS = "mins";
	static String DAYS = "days";
	static String START_DT = "startDate";
	static String END_DT = "endDate";
	
	public static void main(String... s) throws SchedulerException,IOException, FileNotFoundException, ParseException {
	    String fileName = "staticjobs.prop";
		if(fileName == null || "".equals(fileName)){
		  throw new SchedulerException("File Name with Full Path is not set as System property");
		}
		
		InputStream input = StaticJobsLoader.class.getClassLoader().getResourceAsStream(fileName);
		Properties prop = new Properties();
		prop.load(input);
		Set keySet = prop.keySet();
		debug("jobs map "+keySet);
		List<String> jobList = new ArrayList<String>();
		for(Object key:keySet){
			String sKey = (String)key;
			if(sKey.startsWith("job.")){
				jobList.add(sKey);
			}
		}
		debug("JobList ="+jobList);
		List<ScheduleVO> newJobList = new ArrayList<ScheduleVO>();
		List<ScheduleVO> modifyJobList = new ArrayList<ScheduleVO>();
		List<ScheduleVO> deleteJobList = new ArrayList<ScheduleVO>();
		
		for(String jobId:jobList){
			String jobName = prop.getProperty(jobId);
			String actionFlag = prop.getProperty((jobName+"."+ACTION_FLAG));
			debug("Action Falg for "+jobName+" is ="+actionFlag);
			if(SchedulerConstants.SCHEDULE_ACTION_FLAG.NEW.getValue().equalsIgnoreCase(actionFlag)){
				ScheduleVO vo = buildVO(prop, jobName);
				vo.setScheduleActionFlag(SCHEDULE_ACTION_FLAG.NEW);
				newJobList.add(vo);
			}else if(SchedulerConstants.SCHEDULE_ACTION_FLAG.MODIFY.getValue().equalsIgnoreCase(actionFlag)){
				ScheduleVO vo = buildVO(prop, jobName);
				vo.setScheduleActionFlag(SCHEDULE_ACTION_FLAG.MODIFY);
				modifyJobList.add(vo);
			}else if(SchedulerConstants.SCHEDULE_ACTION_FLAG.DELETE.getValue().equalsIgnoreCase(actionFlag)){
				ScheduleVO vo = new ScheduleVO();
				vo.setJobName(jobName);
				deleteJobList.add(vo);
			}
		}
		System.setProperty(SchedulerConstants.SCHED_COMP_MODE_PROP_NAME,SchedulerConstants.SCHED_COMP_MODE_CLIENT);
		debug("newJobList ="+newJobList);
		debug("modifyJobList ="+modifyJobList);
		debug("deleteJobList ="+deleteJobList);
		ISchedulerService schedulerService  = (ISchedulerService)ApplicationBeanContextFactory.getBean(ISchedulerService.class);
		schedulerService.scheduleStaticJobs(newJobList);
		schedulerService.rescheduleStaticJobs(modifyJobList);
		schedulerService.unscheduleStaticJobs(deleteJobList);
		if(input != null) {
		  input.close();
		}
	}
	
	private static ScheduleVO buildVO(Properties prop, String jobName) throws ParseException{
		ScheduleVO vo = new ScheduleVO();
		vo.setJobName(jobName);
		vo.setEventName(jobName);
		
		String jobHandlerName = prop.getProperty(jobName+"."+HANDLER);
		vo.setJobHandlerClassName(jobHandlerName);
		/*Parameter Retrival*/
		int k = 1;
		String paramName = prop.getProperty(jobName+"."+PARAM+"."+k+"."+PARAM_NAME);
		if(paramName != null && !"".equals(paramName)){
			Map<String, String> input = new HashMap<String, String>();
			do{
				String paramVal = prop.getProperty(jobName+"."+PARAM+"."+k+"."+PARAM_VALUE);
				input.put(paramName, paramVal);
				k++;
				paramName = prop.getProperty(jobName+"."+PARAM+"."+k+"."+PARAM_NAME);
			}while(paramName != null && !"".equals(paramName));
			//976332 CSCDEV-2683 28-NOV-2014:START
			//System.out.println("input param="+input);
			//976332 CSCDEV-2683 28-NOV-2014:ENd
			vo.setInput(input);
		}
		/*End of Parameter Retrival*/
		/*Start of Hours*/
		String hours = prop.getProperty(jobName+"."+HOURS);
		vo.setHours(convertToArray(hours));
		/*End of Hours*/
		/*Start of Minis*/
		String minis = prop.getProperty(jobName+"."+MINS);
		vo.setMinis(convertToArray(minis));
		/*End of Minis*/
		/*Start of Days*/
		String days = prop.getProperty(jobName+"."+DAYS);
		vo.setDays(convertDays(days));
		/*End of Days*/
		/*Start of startDate*/
		//String startDate = prop.getProperty(jobName+"."+START_DT);
		//vo.setStartDate(formatDate(startDate));
		/*End of startDate*/
		/*Start of endtDate*/
		//String endDate = prop.getProperty(jobName+"."+END_DT);
		//vo.setEndDate(formatDate(endDate));
		/*End of endDate*/
		return vo;
	}
	
/*	private static Date formatDate(String date) throws ParseException{
		Date result = null;
		if(date != null && !"".equals(date)){
			result = dateFormatter.parse(date);
		}
		return result;
	}*/
	private static String[] convertToArray(String input){
		String[] result = null;
		if(input != null && !"".equals(input)){
			StringTokenizer util = new StringTokenizer(input,",");
			result = new String[util.countTokens()];
			int k=0;
			while(util.hasMoreTokens()){
				result[k] = util.nextToken();
				k++;
			}
		}
		return result;
	}
	
	private static DAYS[] convertDays(String days){
		DAYS[] result = null;
		String[] dayArr = convertToArray(days);
		if(dayArr != null && dayArr.length>0){
			result = new DAYS[dayArr.length];
			int k=0;
			for(String day:dayArr){
				result[k] = SchedulerUtil.getDay(day);
				k++;
			}
		}
		return result;
	}
	
	private static void debug(String val){
		System.out.println(val);
	}
}
