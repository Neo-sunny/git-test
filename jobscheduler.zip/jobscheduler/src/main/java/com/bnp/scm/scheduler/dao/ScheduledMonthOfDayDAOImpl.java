package com.bnp.scm.scheduler.dao;

import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;
import com.bnp.scm.scheduler.vo.ScheduledMonthOfDayVO;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.ibatis.sqlmap.client.SqlMapClient;

@Component
public class ScheduledMonthOfDayDAOImpl extends SqlMapClientWrapper implements ScheduledMonthOfDayDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(ScheduledMonthOfDayDAOImpl.class);
	
	private static final String NAMESPACE = "ScheduledMonthOfDayNS.";
	private static final String INSERT = NAMESPACE+"insert";
	private static final String DELETE_BY_EVENT_REF = NAMESPACE+"deleteScheduledMonthOfDayByEventRef";
	private static final String SELECT_SCHEDULEDMONTHOFDAY_BY_EVENT_REF = NAMESPACE+"selectScheduledMonthOfDayByEventRef";


    public void insert(List<ScheduledMonthOfDayVO> record) throws DBException{
    	try{
    		SqlMapClient sqlMapClient = getSqlMapClientTemplate().getSqlMapClient();
    		sqlMapClient.startBatch();
    		for(ScheduledMonthOfDayVO vo:record){
    			sqlMapClient.insert(INSERT, vo);
    		}
    		sqlMapClient.executeBatch();
    	}catch(DataAccessException e){
    		LOGGER.error("error in inserting data::"+e.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_INSERT);

    	}catch(SQLException e){
    		LOGGER.error("error in inserting data::"+e.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_INSERT, e);
    	}
    }

    public void deleteByEventRef(String eventRef) throws DBException{
    	try{
    		getSqlMapClientTemplate().insert(DELETE_BY_EVENT_REF, eventRef);
    	}catch(DataAccessException e){
    		LOGGER.error("error in deleting::"+e.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_DELETE);

    	}
    }
    
    public List<String> getScheduledMonthOfDayByEventRef(String eventRef) throws DBException{
    	List<String> daysList;
    	try{
    		daysList = getSqlMapClientTemplate().queryForList(SELECT_SCHEDULEDMONTHOFDAY_BY_EVENT_REF,eventRef);
    	}
    	catch(DataAccessException exp){
    		LOGGER.error("getScheduledMonthOfDayByEventRef"+exp.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_FETCH);
    	}
    	return daysList;

    }
    }
