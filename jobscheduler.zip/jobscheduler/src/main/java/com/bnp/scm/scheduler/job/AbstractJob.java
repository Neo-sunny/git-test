/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Sep 2011
 * 
 * Purpose:      Auto Discounting services
 * 
 * Change History: 
 * Date                                   Author                                Version                                 Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 02 Mar 2012                      Oracle Financial Services Software Ltd                                    Initial Version
 * 01 Jul 2014                      Vigneshwaran R                                                             R6.0 TP Bank Report Changes
 * 15 Dec 2014						Himachalam D R															FO R7.0 Brazil Basic Payable Model Email Alert
 ***********************************************************************************************************************************/

package com.bnp.scm.scheduler.job;

import java.util.HashMap;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;

import com.bnp.scm.scheduler.dao.AbsctractSchedulerDAO;
import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;
import com.bnp.scm.scheduler.util.JobResult;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.scheduler.util.SchedulerConstants.JOB_RESULT;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.scheduler.events.IEvent;
import com.bnp.scm.services.scheduler.exception.BNPSchedulerException;


public abstract class AbstractJob implements Job{

	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractJob.class);
	
	private @Autowired AbsctractSchedulerDAO schedulerDAO;
	
	public AbsctractSchedulerDAO getSchedulerDAO() {
		return schedulerDAO;
	}

	public void setSchedulerDAO(AbsctractSchedulerDAO schedulerDAO) {
		this.schedulerDAO = schedulerDAO;
	}

	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		JobDataMap data = arg0.getMergedJobDataMap();
		Long histId = (Long)arg0.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID);
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("dataMap ="+data);
		/*String[] keys = data.getKeys();
		Map<String,String> input = new HashMap<String, String>();
		for(String key:keys){
			input.put(key, data.getString(key));
		}*/
		Map<String,String> input = new HashMap<String, String>();
		String eventRef = data.getString(SchedulerConstants.PARAM_NAME_EVENT_REF);
	   // R6.0 Manual Workaround TP Change
		String eventName = data.getString(SchedulerConstants.PARAM_NAME_EVENT_NAME);
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("eventRef = "+eventRef);
		input.put(SchedulerConstants.PARAM_NAME_EVENT_REF, eventRef);
		input.put(SchedulerConstants.PARAM_NAME_JOB_HIST_ID, String.valueOf(histId));
		//R6.0 Added for TP Bank Reports Changes
		input.put(SchedulerConstants.PARAM_NAME_EVENT_NAME, eventName);
		JobResult jobResult = new JobResult();
		jobResult.setResult(JOB_RESULT.SUCCESS);
		try{
			if(eventRef != null && !"".equals(eventRef)){
				Map<String,String> params = schedulerDAO.getInput(eventRef);
				input.putAll(params);
			}
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("Input for the job execution = "+input);
			run(input);
		}catch(SchedulerException e){
			LOGGER.error("SchException in processing job ="+e);
			jobResult.setException(e);
			jobResult.setResult(JOB_RESULT.FAIL);
		}catch(DBException e){
			LOGGER.error("DBException in processing job ="+e);
			jobResult.setException(e);
			jobResult.setResult(JOB_RESULT.FAIL);
		}catch(RuntimeException e){
			LOGGER.error("RuntimeException in processing job ="+e);
			jobResult.setException(e);
			jobResult.setResult(JOB_RESULT.FAIL);
			//976332 CSCDEV-2683 14-NOV-2014:START
			//e.printStackTrace();
			//976332 CSCDEV-2683 14-NOV-2014:END
		}
		arg0.setResult(jobResult);
	}
	
	/**
	 * Process event.
	 *
	 * @param className the class name
	 * @param args the args
	 * @throws SchedulerException the scheduler exception
	 */
	protected void processEvent(Class<?> classArg ,String[] args) throws SchedulerException
	{
		IEvent iEvent = (IEvent)ApplicationBeanContextFactory.getBean(classArg);
		LOGGER.debug("after application bean context factory ");
		try	{
			iEvent.processEvent(args);
		}catch (BNPSchedulerException e) {
			LOGGER.error(e.getMessage(), e);
			throw new SchedulerException(e.getErrorCode(),e.getMessage());
		}finally {
			iEvent = null;
		}	
	}
	//If there is any exception thrown from program, then recorded as Failed
	public abstract void run(Map<String,String> arg0) throws SchedulerException;
}
