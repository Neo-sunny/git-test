package com.bnp.scm.scheduler.dao;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.scheduler.vo.ScheduleInfoVO;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;

@Component
public class ScheduleInfoDAOImpl extends SqlMapClientWrapper implements ScheduleInfoDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(ScheduleInfoDAOImpl.class);
	
	private static final String INSERT = "ScheduleInfoNS.insert";
	private static final String UPDATE = "ScheduleInfoNS.update";
	private static final String UPDATE_SCHEDULE_ERROR = "ScheduleInfoNS.updateScheduleError";
	private static final String DELETE = "ScheduleInfoNS.delete";
	private static final String UPDATE_ACTION_FLAG = "ScheduleInfoNS.updateActionFlag";
	private static final String UPDATE_SCHEDULE_STATUS = "ScheduleInfoNS.updateScheduleStatus";
	private static final String SELECT_SCHEDULEINFO_BY_EVENT_REF = "ScheduleInfoNS.selectScheduleInfo";
	private static final String SELECT_SCHEDULEINFO_BY_ACTION_FLAG = "ScheduleInfoNS.selectUnScheduledInfoByActionFlag";
	private static final String SELECT_JOB_COMPLETION_FLAG = "ScheduleInfoNS.getJobCompletionStatus";
	private static final String SELECT_EVENTREF_FORSTATICJOB = "ScheduleInfoNS.getEventRefByJobNameAndGroupName";
	
	private static final String UPDATE_JOB_COMPLETED_STATUS = "ScheduleInfoNS.updateJobCompletedStatus";
	private static final String SELECT_USER_BRANCH_TIMEZONE = "ScheduleInfoNS.getUserBranchTimeZone";
	
	public String insert(ScheduleInfoVO record) throws DBException{
		String pkValue = null;
    	try{
    		pkValue = (String) getSqlMapClientTemplate().insert(INSERT, record);
    	}catch(DataAccessException e){
    		LOGGER.error("error in inserting data::"+e.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_INSERT);
    	}
    	return pkValue;
	}
	
	
    public void updateActionFlag(ScheduleInfoVO record) throws DBException{
    	try{
    		  getSqlMapClientTemplate().update(UPDATE_ACTION_FLAG, record);
    	}catch(DataAccessException e){
    		LOGGER.error("error in updateStatus data::"+e.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_UPDATE);
    	}
    }
    
    public void updateScheduleStatus(ScheduleInfoVO record) throws DBException{
    	try{
    		  getSqlMapClientTemplate().update(UPDATE_SCHEDULE_STATUS, record);
    	}catch(DataAccessException e){
    		//976332 CSCDEV-2683 17-NOV-2014:START
    		//e.printStackTrace();
    		//976332 CSCDEV-2683 17-NOV-2014:END
    		LOGGER.error("error in updateStatus data::"+e.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_UPDATE);
    	}
    }
    
    public void update(ScheduleInfoVO record) throws DBException{
    	try{
    		  getSqlMapClientTemplate().update(UPDATE, record);
    	}catch(DataAccessException e){
    		LOGGER.error("error in updating data::"+e.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_UPDATE);
    	}
    }
    
	public void delete(String eventRef) throws DBException{
    	try{
    		getSqlMapClientTemplate().delete(DELETE, eventRef);
    	}catch(DataAccessException e){
    		//976332 CSCDEV-2683 17-NOV-2014:START
    		//e.printStackTrace();
    		//976332 CSCDEV-2683 17-NOV-2014:END
    		LOGGER.error("error in delete data::"+e.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_DELETE);
    	}
	}

	public ScheduleInfoVO getScheduleInfo(String eventRef) throws DBException{
		ScheduleInfoVO vo = null;
    	try{
    		vo = (ScheduleInfoVO)getSqlMapClientTemplate().queryForObject(SELECT_SCHEDULEINFO_BY_EVENT_REF,eventRef);
    	}
    	catch(DataAccessException exp){
    		LOGGER.error("method:getScheduleInfo"+exp.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_FETCH);
    	}
    	return vo;

	}
	public List<ScheduleInfoVO> getUnScheduledInfoByActionFlag(String actionFlag) throws DBException{
		List<ScheduleInfoVO> voList;
    	try{
    		voList = getSqlMapClientTemplate().queryForList(SELECT_SCHEDULEINFO_BY_ACTION_FLAG,actionFlag);
    	}
    	catch(DataAccessException exp){
    		LOGGER.error("method:getUnScheduledInfoByActionFlag"+exp.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_FETCH);
    	}
    	return voList;
		
	}
	public void updateJobCompletionStatus(String eventRef) throws DBException{
		try{
    		ScheduleInfoVO record = new ScheduleInfoVO();
    		record.setEventRef(eventRef);
    		record.setJobCompletionStatus(SchedulerConstants.JOB_COMPLETION_STATUS);
  		  	getSqlMapClientTemplate().update(UPDATE_JOB_COMPLETED_STATUS, record);
	  	}catch(DataAccessException e){
	  		LOGGER.error("error in updating data::"+e.getMessage());
	  		throw new DBException(ErrorConstants.ERROR_CONDITION_UPDATE);
	  	}
	}
	
	public void updateScheduleError(ScheduleInfoVO record) throws DBException{
		try{
  		  	getSqlMapClientTemplate().update(UPDATE_SCHEDULE_ERROR, record);
	  	}catch(DataAccessException e){
	  		LOGGER.error("error in updating data::"+e.getMessage());
	  		throw new DBException(ErrorConstants.ERROR_CONDITION_UPDATE);
	  	}
	}
	public String getUserBranchTimeZone(String eventRef) throws DBException {
		String timeZone = null;
    	try{
    		timeZone = (String)getSqlMapClientTemplate().queryForObject(SELECT_USER_BRANCH_TIMEZONE,eventRef);
    	}
    	catch(DataAccessException exp){
    		LOGGER.error("method:getUserBranchTimeZone"+exp.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_FETCH);
    	}
    	return timeZone;
	}

	public String getJobCompletionStatus(String eventRef) throws DBException{
		String jobCompStatus = null;
    	try{
    		jobCompStatus = (String)getSqlMapClientTemplate().queryForObject(SELECT_JOB_COMPLETION_FLAG,eventRef);
    	}
    	catch(DataAccessException exp){
    		LOGGER.error("method:getJobCompletionStatus"+exp.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_FETCH);
    	}
    	return jobCompStatus;
	}
	public String getEventRefForStaticJob(String jobName,String groupName)throws DBException{
		String eventRef = null;
    	try{
    		ScheduleInfoVO record = new ScheduleInfoVO();
    		record.setJobName(jobName);
    		record.setGroupName(groupName);
    		eventRef = (String)getSqlMapClientTemplate().queryForObject(SELECT_EVENTREF_FORSTATICJOB,record);
    	}
    	catch(DataAccessException exp){
    		LOGGER.error("method:getJobCompletionStatus"+exp.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_FETCH);
    	}
    	return eventRef;
	}
}
