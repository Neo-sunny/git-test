/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Apr 2012
 * 
 * Purpose: Interface for Common Job Handler
 * 
 * Change History: 
 * Date                             Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 25 Apr 2012                      Ramesh A                              Initial Version
 * 05 FEB 2014          			Ravishankar V						  Rel5.0     Funding Loan Changes
 * 03 Jun 2014						Yashmika								Changes done for FO 6.0
 * 03 May 2016                      Vigneshwaran.R         				  Pre-Archival and Post-Archival Job Implementation
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.dao;

import java.util.List;
import java.util.Map;

import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.discounting.vo.DiscountRequestVO;

public interface JobHandlerDAO {
	void validateUsers() throws BNPApplicationException;
	Map<String, String> processSettlement(Map<String, String> inputMap) throws BNPApplicationException;
	void validateJobs() throws BNPApplicationException;
	void eDraftMaturedDraftProcess() throws BNPApplicationException;
	Map<String, Object> processOLAPArchivalandPurging(Map<String, String> inputMap,boolean isArchivalProcess) throws BNPApplicationException;
	void refreshOADRecords(Map<String, String> inputMap) throws BNPApplicationException;
	//Changes done for FO 6.0
	void updateDiscountDate(String branchId,DiscountRequestVO discountRequestVO) throws BNPApplicationException;
	/**
	 * @param inputMap
	 * @return The Map of Settlement Reqeust
	 * @throws DBException
	 * The method invokes the settlement proc for fund requests
	 */
	Map<String, String> processFundSettlement(Map<String, String> inputMap)
			throws DBException;
	//Changes Done for FO 6.0
	/**
	 * Gets the oad records.
	 *
	 * @param branchId the branch id
	 * @return the oad records
	 * @throws DBException the dB exception
	 */
	List<DiscountRequestVO> getOadRecords(String branchId)throws DBException;
	
	/**
	 * Update error message.
	 *
	 * @param errorMessage the error message
	 * @param discountRequestVO the discount request vo
	 */
	void updateErrorMessage(int errorMessage,DiscountRequestVO discountRequestVO);
	
	/**
	 * Generate pre archival or purge reports.
	 *
	 * @param inputMap the input map
	 * @param isArchivalProcess the is archival process
	 * @return the map
	 * @throws BNPApplicationException the BNP application exception
	 */
	Map<String, Object> generatePreArchivalOrPurgeReports(Map<String, String> inputMap, boolean isArchivalProcess) throws BNPApplicationException;
}
