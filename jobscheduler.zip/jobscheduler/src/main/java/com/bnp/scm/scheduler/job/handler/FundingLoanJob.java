/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Apr 2012
 * 
 * Purpose: Funding Loan Request Handler
 * 
 * Change History: 
 * Date                             Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 09 Dec 2013                      Ravishankar V                         Initial Version
 * 30 Jan 2014          			Ravishankar V						  Rel5.0     Funding Loan Changes
 ********************************************************************************************************************************/
package com.bnp.scm.scheduler.job.handler;

import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.service.JobHandlerService;
import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.scheduler.events.FundingLoanEvent;
import com.bnp.scm.services.scheduler.events.IEvent;
import com.bnp.scm.services.scheduler.events.SettlementJobEvent;
import com.bnp.scm.services.scheduler.events.SettlementMessageEvent;
import com.bnp.scm.services.scheduler.exception.BNPSchedulerException;


@Component
public class FundingLoanJob extends AbstractJob {
	/**
	 * Logger class
	 */
	public static final Logger LOGGER = LoggerFactory.getLogger(FundingLoanJob.class);
	
	/**
	 * Job Handl Service to call settlement job
	 */
	@Autowired
	JobHandlerService jobHandlerService;
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.scheduler.job.AbstractJob#run(java.util.Map)
	 */
	@Override
	public void run(Map<String, String> inputMap) throws SchedulerException {
		LOGGER.debug("Funding Loan Job Starts--Beg");
		IEvent iEvent = null;
		try {
			iEvent = (IEvent)ApplicationBeanContextFactory.getBean(FundingLoanEvent.class);
			String[] arg = new String[7];
			arg[0] = "";
			arg[1] = inputMap.get(SchedulerConstants.PARAM_NAME_BRANCH_ID);
			arg[2] = inputMap.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID);
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("FundingLoanJob--arg-0->" + arg[0] + "<arg-1->" + arg[1] + "<arg-2->" + arg[2] + "<arg-3->" + arg[3] + "<arg-4->" + arg[4] + "<arg-5->" + arg[5] + "<arg-6->" + arg[6]);
			iEvent.processEvent(arg);
			LOGGER.debug("Funding Loan Job--Afer Completing Funding Loan Request");
			/*inputMap.put(SchedulerConstants.IS_FUND_REQ, BNPConstants.FUNDSET);
			Map<String, String> resultMap = jobHandlerService.processSettlement(inputMap);
			LOGGER.debug("After executing Settlement EOD Proc Funding, resultMap :"+resultMap);*/
//			iEvent = (IEvent)ApplicationBeanContextFactory.getBean(SettlementJobEvent.class);
//			arg = new String[7];
//			arg[0] = "";
//			arg[1] = inputMap.get(SchedulerConstants.PARAM_NAME_BRANCH_ID);
//			arg[2] = inputMap.get(SchedulerConstants.PARAM_NAME_ORG_ID);
//			arg[3] = inputMap.get(SchedulerConstants.PARAM_NAME_CCY);
//			arg[4] = inputMap.get(SchedulerConstants.PARAM_NAME_PYMT_METHOD);
//			arg[5] = inputMap.get(SchedulerConstants.PARAM_NAME_CUSTOM_PARAM);
//			arg[6] = inputMap.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID);
//			LOGGER.debug("SettlementRequestJob--arg-0->" + arg[0] + "<arg-1->" + arg[1] + "<arg-2->" + arg[2] + "<arg-3->" + arg[3] + "<arg-4->" + arg[4] + "<arg-5->" + arg[5] + "<arg-6->" + arg[6]);
//			iEvent.processEvent(arg);
			LOGGER.debug("SettlementRequestJob--Afer Completing Settlement Request For Funding");
			/*iEvent = (IEvent)ApplicationBeanContextFactory.getBean(SettlementMessageEvent.class);
			iEvent.processEvent(arg);
			LOGGER.debug("SettlementRequestJob--Afer Completing Settlement Message Event For Funding");*/
		}catch (BNPSchedulerException e) {
			LOGGER.error(e.getMessage(), e);
			throw new SchedulerException(e.errorCode,e.getMessage());
		}
		finally {
			iEvent = null;
		}	
		LOGGER.debug("Funding Loan Job--end");
	}
		
	
}
