package com.bnp.scm.scheduler.server;

import java.io.InputStream;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Properties;

import org.quartz.core.RemotableQuartzScheduler;

public class ShutdownScheduler {

    public static void main(String[] args){
    	/*if(args.length != 2){
    		System.out.println("Instance Name and Instance Id is must to stop");
    		System.exit(0);
    	}
    	String instanceNameArg = args[0];
    	String instanceIdArg = args[1];*/
    	InputStream input = null;
    	try{
    		/*if (System.getSecurityManager() == null) {
            	System.setSecurityManager(new java.rmi.RMISecurityManager());
           	}*/
	        String propFileName = System.getProperty("quartzpropfilename");
			input = QuartzRemoteServer.class.getClassLoader().getResourceAsStream(propFileName);
			Properties config = new Properties();
			config.load(input);
			String instanceName = config.getProperty("org.quartz.scheduler.instanceName");
			String instanceId = config.getProperty("org.quartz.scheduler.instanceId");
			String rmiRegistryHost = config.getProperty("org.quartz.scheduler.rmi.registryHost");
			String rmiRegistryPort = config.getProperty("org.quartz.scheduler.rmi.registryPort");

			System.out.println("InstanceName =>" + instanceName + ", Instance Id =>" + instanceId + ", RMI Registry Host =>" + rmiRegistryHost + ", RMI Registry Port =>" + rmiRegistryPort);

			/*if(!instanceNameArg.equals(instanceName)){
	        	System.out.println("Invalid Instance Name");
	        	throw new Exception();
			}
			if(!instanceIdArg.equals(instanceId)){
	        	System.out.println("Invalid Instance Id");
	        	throw new Exception();
			}*/
			Registry registry = LocateRegistry.getRegistry(rmiRegistryHost,Integer.valueOf(rmiRegistryPort));
    		RemotableQuartzScheduler scheduler = (RemotableQuartzScheduler)registry.lookup(instanceName+"_$_"+instanceId);
    		scheduler.shutdown(true);
    	}catch(RemoteException e){
    		//976332 CSCDEV-2683 17-NOV-2014:START
    		//e.printStackTrace();
    		//976332 CSCDEV-2683 17-NOV-2014:END
    		System.out.println(" Remote Connection refused");
    		System.exit(0);
    	}catch(NotBoundException e){
    		//976332 CSCDEV-2683 17-NOV-2014:START
    		//e.printStackTrace();
    		//976332 CSCDEV-2683 17-NOV-2014:END
    		System.out.println(" Instance Not found ");
    		System.exit(0);
    	}catch(Exception e){
    		//976332 CSCDEV-2683 17-NOV-2014:START
    		//e.printStackTrace();
    		//976332 CSCDEV-2683 17-NOV-2014:END
    		System.out.println(" File Not found ");
    		System.exit(0);
    	}finally {//Fortify fix : Unreleased Resource: Streams
  		  try {
  		    if(input != null) {
  		    	input.close();
  			}
  	      }catch (Exception exception) {
  	    	System.out.println("Could Not Close COnnection");
    		System.exit(0);
  		  }
  		}
    	
    }
    
}