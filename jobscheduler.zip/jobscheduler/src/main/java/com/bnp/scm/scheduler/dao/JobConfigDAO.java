package com.bnp.scm.scheduler.dao;

import java.util.List;

import com.bnp.scm.scheduler.vo.JobConfigVO;
import com.bnp.scm.services.common.exception.DBException;

public interface JobConfigDAO {
	
    JobConfigVO getJobConfiguration(String eventName) throws DBException;
    List<JobConfigVO> getJobConfigByActionFlag(String actionFlag)throws DBException;
    void updateActionFlagAsEmpty(long jobId)throws DBException;
    void deleteJob(List<Long> jobIdList)throws DBException;
}