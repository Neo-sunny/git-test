/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * 
 * 
 * Created on: 15 December 2014
 * 
 * Purpose: Discount Rejected by buyer job handler class
 * 
 * Change History: 
 * Date                             Author                                		Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 15 December 2014		  		  Oracle Financial Services Software Ltd 				     Initial Version
 ********************************************************************************************************************************/
package com.bnp.scm.scheduler.job.handler.discounting.payable;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.scheduler.events.DiscRejectedByBuyerJobEmailEvent;

@Component
public class DiscRejectedByBuyerJob extends AbstractJob{
	
	public static final Logger LOGGER = LoggerFactory.getLogger(DiscRejectedByBuyerJob.class);
	public void run(Map<String, String> inputMap) throws SchedulerException {
		LOGGER.debug("DiscPendingBuyerAccptOrRejApprovalJob--Beg");
		String[] arg = getArgs(inputMap);		
		processEvent(DiscRejectedByBuyerJobEmailEvent.class,arg);
		LOGGER.debug("DiscPendingBuyerAccptOrRejApprovalJob--End");
	}
	private String[] getArgs(Map<String, String> inputMap) {
		
			String[] arg = new String[4];
			arg[0] = "";
			arg[1] = inputMap.get(SchedulerConstants.PARAM_NAME_ORG_ID);
			arg[2] = inputMap.get(SchedulerConstants.PARAM_NAME_EVENT_NAME);
			arg[3] = inputMap.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID);
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("DiscPendingBuyerJobs--arg-0->" + arg[0] + "<arg-1->" + arg[1] + "<arg-2->" + arg[2] + "<arg-3->" + arg[3]);
			return arg;		
	}
}
