/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Apr 2012
 * 
 * Purpose: Job Refresh Event Handler
 * 
 * Change History: 
 * Date                             Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 25 Apr 2012                      Ramesh A                              Initial Version
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.job.handler;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.service.ISchedulerService;

@Component
public class JobRefreshEvent extends AbstractJob {

	public static final Logger LOGGER = LoggerFactory.getLogger(JobRefreshEvent.class);
	
	@Autowired
	ISchedulerService schedulerService;
	
	@Override
	public void run(Map<String, String> arg0) throws SchedulerException {
		LOGGER.debug("JobRefreshEvent--Beg");
		schedulerService.removeJobsConfig();
        schedulerService.loadJobsConfig();
        schedulerService.scheduleJobs();
        LOGGER.debug("JobRefreshEvent--End");
	}
}
