/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14 Feb 2012
 * 
 * Purpose: Job Monitoring DAO Implementation
 * 
 * Change History: 
 * Date                             Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 25 Apr 2012                      Ramesh A                              Initial Version
 * 22 Jun 2015						Anupriya P																	FO 8.0 export changes
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.dao;

import java.sql.Timestamp;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.vo.JobHistoryVO;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.vo.NameValueVO;

@Component
public class JobMonitoringDAOImpl extends SqlMapClientWrapper implements JobMonitoringDAO {

	private static final Logger LOGGER =LoggerFactory.getLogger(JobMonitoringDAOImpl.class);
	
	private static final String NAMESPACE="JobMonitoringNS.";
	private static final String SEARCH_IN_HIST ="searchJobExecHist";
	private static final String JOB_NAME_LIST ="getJobNameList";
	private static final String JOB_TYPE_LIST ="getJobTypeList";
	private static final String JOB_STATUS_LIST ="getTriggerStatusList";
	private static final String SYSTEM_DATE = "getSystemDate";

	private static final String SELECT_JOB_INPUT = "getJobInput";
	private static final String GET_USER_FORMAT = "getUserPref";
	private static final String GET_SEARCH_DATA_COUNT = "getSearchDataCount";
	
	@SuppressWarnings("unchecked")
	@Override
	public List<JobHistoryVO> getJobExecutionHist(JobHistoryVO jobHistoryVO)
			throws BNPApplicationException {
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("Search criteria:"+jobHistoryVO);
		try{
			return getSqlMapClientTemplate().queryForList(NAMESPACE+SEARCH_IN_HIST, jobHistoryVO);
		}catch (DataAccessException exception){
			LOGGER.error("DataAccessException in getJobExecutionHist:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}catch (RuntimeException exception){
			LOGGER.error("RuntimeException in getJobExecutionHist:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<NameValueVO> getJobTypes() throws BNPApplicationException {
		try{
			return getSqlMapClientTemplate().queryForList(NAMESPACE+JOB_TYPE_LIST);
		}catch (DataAccessException exception){
			LOGGER.error("DataAccessException in getJobNames:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}catch (RuntimeException exception){
			LOGGER.error("RuntimeException in getJobNames:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<NameValueVO> getJobNames() throws BNPApplicationException {
		try{
			return getSqlMapClientTemplate().queryForList(NAMESPACE+JOB_NAME_LIST);
		}catch (DataAccessException exception){
			LOGGER.error("DataAccessException in getJobNames:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}catch (RuntimeException exception){
			LOGGER.error("RuntimeException in getJobNames:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<NameValueVO> getJobStatusList() throws BNPApplicationException {
		try{
			return getSqlMapClientTemplate().queryForList(NAMESPACE+JOB_STATUS_LIST);
		}catch (DataAccessException exception){
			LOGGER.error("DataAccessException in getJobStatusList:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}catch (RuntimeException exception){
			LOGGER.error("RuntimeException in getJobStatusList:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public Timestamp getCurrentSystemDate() throws BNPApplicationException {
		try{
			return (Timestamp)getSqlMapClientTemplate().queryForObject(NAMESPACE+SYSTEM_DATE);
		}catch (DataAccessException exception){
			LOGGER.error("DataAccessException in getCurrentSystemDate:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}catch (RuntimeException exception){
			LOGGER.error("RuntimeException in getCurrentSystemDate:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<NameValueVO> getJobInput(String jobRefId) throws BNPApplicationException {
		try{
			return getSqlMapClientTemplate().queryForList(NAMESPACE+SELECT_JOB_INPUT,jobRefId);
		}catch (DataAccessException exception){
			LOGGER.error("DataAccessException in getJobImput:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}catch (RuntimeException exception){
			LOGGER.error("RuntimeException in getJobImput:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public String getUserPrefTimeZone(String userId)
			throws BNPApplicationException {
		try{
			return (String)getSqlMapClientTemplate().queryForObject(NAMESPACE+GET_USER_FORMAT,userId);
		}catch (DataAccessException exception){
			LOGGER.error("DataAccessException in getUserPrefTimeZone:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}catch (RuntimeException exception){
			LOGGER.error("RuntimeException in getUserPrefTimeZone:",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}

	public int getSearchDataCount(JobHistoryVO jobHistoryVO) throws DBException{
		try{
			return (Integer)getSqlMapClientTemplate().queryForObject(NAMESPACE+GET_SEARCH_DATA_COUNT,jobHistoryVO);
		}catch (DataAccessException exception){
			LOGGER.error("DataAccessException in getSearchDataCount:",exception);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
}
