/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   06 Mar 2011
 * 
 * Purpose:      Bank code  DAO Impl 
 * 
 * Change History: 
 * Date                                                  Author                                                 Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 06 Mar 2011                      Oracle Financial Services Software Ltd                                    Initial Version 
 *                                  										
 *****************************************************************************************************************************************************************/

package com.bnp.scm.scheduler.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TimeZone;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.scheduler.util.SchedulerConstants.DAYS;
import com.bnp.scm.scheduler.util.SchedulerUtil;
import com.bnp.scm.scheduler.vo.JobConfigVO;
import com.bnp.scm.scheduler.vo.JobExecHistVO;
import com.bnp.scm.scheduler.vo.JobInfoVO;
import com.bnp.scm.scheduler.vo.JobInputVO;
import com.bnp.scm.scheduler.vo.JobSchedulerVO;
import com.bnp.scm.scheduler.vo.ScheduleInfoVO;
import com.bnp.scm.scheduler.vo.ScheduleVO;
import com.bnp.scm.scheduler.vo.ScheduledDaysVO;
import com.bnp.scm.scheduler.vo.ScheduledHoursVO;
import com.bnp.scm.scheduler.vo.ScheduledMinisVO;
import com.bnp.scm.scheduler.vo.ScheduledMonthOfDayVO;
import com.bnp.scm.scheduler.vo.ScheduledMonthsVO;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.util.BNPCommonUtil;

@Component
public class SchedulerDAO implements ISchedulerDAO{
	
	private @Autowired JobExecHistDAO jobExecHistDAO;
	private @Autowired ScheduleInfoDAO scheduleInfoDAO;
	private @Autowired JobInputDAO jobInputDAO;
	private @Autowired ScheduledHoursDAO scheduledHoursDAO;
	private @Autowired ScheduledMinisDAO scheduledMinisDAO;
	private @Autowired ScheduledDaysDAO scheduledDaysDAO;
	private @Autowired ScheduledMonthOfDayDAO scheduledMonthOfDayDAO;
	private @Autowired JobConfigDAO jobConfigDAO;
	private @Autowired ScheduledMonthsDAO scheduledMonthsDAO;
	private @Autowired JobSchedulerDAO jobSchedulerDAO;
	
	public JobExecHistDAO getJobExecHistDAO() {
		return jobExecHistDAO;
	}
	public void setJobExecHistDAO(JobExecHistDAO jobExecHistDAO) {
		this.jobExecHistDAO = jobExecHistDAO;
	}
	public ScheduleInfoDAO getScheduleInfoDAO() {
		return scheduleInfoDAO;
	}
	public void setScheduleInfoDAO(ScheduleInfoDAO scheduleInfoDAO) {
		this.scheduleInfoDAO = scheduleInfoDAO;
	}
	
	public JobInputDAO getJobInputDAO() {
		return jobInputDAO;
	}
	public void setJobInputDAO(JobInputDAO jobInputDAO) {
		this.jobInputDAO = jobInputDAO;
	}
	public ScheduledHoursDAO getScheduledHoursDAO() {
		return scheduledHoursDAO;
	}
	public void setScheduledHoursDAO(ScheduledHoursDAO scheduledHoursDAO) {
		this.scheduledHoursDAO = scheduledHoursDAO;
	}
	public ScheduledMinisDAO getScheduledMinisDAO() {
		return scheduledMinisDAO;
	}
	public void setScheduledMinisDAO(ScheduledMinisDAO scheduledMinisDAO) {
		this.scheduledMinisDAO = scheduledMinisDAO;
	}
	public ScheduledDaysDAO getScheduledDaysDAO() {
		return scheduledDaysDAO;
	}
	public void setScheduledDaysDAO(ScheduledDaysDAO scheduledDaysDAO) {
		this.scheduledDaysDAO = scheduledDaysDAO;
	}
	
	public JobConfigDAO getJobConfigDAO() {
		return jobConfigDAO;
	}
	public void setJobConfigDAO(JobConfigDAO jobConfigDAO) {
		this.jobConfigDAO = jobConfigDAO;
	}
	
	
	public ScheduledMonthOfDayDAO getScheduledMonthOfDayDAO() {
		return scheduledMonthOfDayDAO;
	}
	public void setScheduledMonthOfDayDAO(
			ScheduledMonthOfDayDAO scheduledMonthOfDayDAO) {
		this.scheduledMonthOfDayDAO = scheduledMonthOfDayDAO;
	}
	public long insertAuditLog(JobExecHistVO histVO) throws DBException{
		BigDecimal histId = jobExecHistDAO.insert(histVO);
		return histId.longValue();
	}
	
	public void updateAuditLogStatus(JobExecHistVO histVO) throws DBException{
		jobExecHistDAO.updateStatus(histVO);
	}
	//will return eventRef. It should insert groupname, classname, jobName, input as well
	public String insertScheduleInfo(ScheduleVO scheduleVO) throws DBException{
		String eventRef = "";
		ScheduleInfoVO infoVO = new ScheduleInfoVO();
		infoVO.setEventRef(scheduleVO.getEventRef());
		infoVO.setActionFlag(scheduleVO.getScheduleActionFlag().getValue());
		infoVO.setScheduledStatus(SchedulerConstants.SCHEDULED_STATUS.NO.getValue());
		infoVO.setEventName(scheduleVO.getEventName());
		infoVO.setJobType(scheduleVO.getJobType());
		infoVO.setStartDate(scheduleVO.getStartDate());
		infoVO.setEndDate(scheduleVO.getEndDate());
		/*This part will be only for addho/static job*/
		infoVO.setJobName(scheduleVO.getJobName());
		infoVO.setGroupName(scheduleVO.getGroupName());
		infoVO.setJobHandlerClassName(scheduleVO.getJobHandlerClassName());
		infoVO.setJobPirority(scheduleVO.getJobPirority());
		String timeZoneId = scheduleVO.getScheduleTimeZoneId();
		if(timeZoneId == null){
			scheduleVO.setScheduleTimeZoneId(TimeZone.getDefault().getID());
		}
		infoVO.setScheduleTimeZoneId(scheduleVO.getScheduleTimeZoneId());
		infoVO.setMisfireInst(scheduleVO.getMisfireInst());
		infoVO.setScheduleType(scheduleVO.getScheduleType().getValue());
		infoVO.setOriginalEventRef(scheduleVO.getOriginalEventRef());
		/**/
		eventRef = scheduleInfoDAO.insert(infoVO);
		
		//insert input params
		insertInputParameters(eventRef, scheduleVO.getInput());
		//end of input params
		insertHours(scheduleVO.getHours(), eventRef);
		//start of minis
		insertMinis(scheduleVO.getMinis(), eventRef);
		//end of minis
		//start of days
		insertDays(scheduleVO.getDays(), eventRef);
		insertMonthOfDay(scheduleVO.getMonthOfDay(),eventRef);
		//end of days
		insertMonths(scheduleVO.getMonths(),eventRef);
		return eventRef;
	}
	
	public void updateScheduleStatus(String eventRef, String scheduleStatus, String actionFlag) throws DBException{
		ScheduleInfoVO infoVO = new ScheduleInfoVO();
		infoVO.setEventRef(eventRef);
		infoVO.setActionFlag(actionFlag);
		infoVO.setScheduledStatus(scheduleStatus);
		scheduleInfoDAO.updateScheduleStatus(infoVO);
	}

	@Override
	public void updateJobSchedulerStatus(String jobRef, String scheduleStatus,String errorMessage) throws DBException{
		JobSchedulerVO jobSchedulerVO = new JobSchedulerVO();
		jobSchedulerVO.setJobRef(jobRef);
		jobSchedulerVO.setSchStatus(scheduleStatus);
		jobSchedulerVO.setSchError(errorMessage);
		jobSchedulerDAO.updateScheduleStatus(jobSchedulerVO);
	}
	
	public void deleteScheduleInfo(String eventRef) throws DBException{
		jobInputDAO.deleteByEventRef(eventRef);
		scheduledDaysDAO.deleteByEventRef(eventRef);
		scheduledMonthOfDayDAO.deleteByEventRef(eventRef);
		scheduledHoursDAO.deleteByEventRef(eventRef);
		scheduledMinisDAO.deleteByEventRef(eventRef);
		scheduleInfoDAO.delete(eventRef);
		scheduledMonthsDAO.deleteByEventRef(eventRef);
	}
	
	public void insertInputParameters(String eventRef, Map<String, String> inputParam) throws DBException{
		if(inputParam !=null && !inputParam.isEmpty()){
			List<JobInputVO> inputList = new ArrayList<JobInputVO>();
			for(Entry<String, String> param:inputParam.entrySet()){
				JobInputVO input = new JobInputVO();
				input.setEventRef(eventRef);
				input.setParamName(param.getKey());
				input.setParamValue(param.getValue());
				inputList.add(input);
			}
			jobInputDAO.insert(inputList);
		}

	}
	
	
	public JobInfoVO getJobInfo(String eventName) throws DBException{
		JobInfoVO infoVO = null;
		JobConfigVO configVO = jobConfigDAO.getJobConfiguration(eventName);
		if(configVO != null){
			infoVO = new JobInfoVO();
			infoVO.setGroupName(configVO.getGroupName());
			infoVO.setJobClassName(configVO.getJobHandlerClassName());
			infoVO.setJobName(configVO.getJobName());
			infoVO.setPriority(configVO.getJobPrority());
			infoVO.setMisfireInst(configVO.getMisfireInst());
			infoVO.setDurablity(true);
		}
		return infoVO;
	}
	
	public Map<String,String> getInput(String eventRef) throws DBException{
		Map<String,String> input = new HashMap<String, String>();
		List<JobInputVO> params = jobInputDAO.getInputByEventRef(eventRef);//SONAR Fix
		SchedulerUtil.buildInput(params, input);
		return input;
	}
	
	public void deleteInputParameters(String eventRef) throws DBException{
		jobInputDAO.deleteByEventRef(eventRef);
	}
	
	public List<JobConfigVO> getDeleteJobList() throws DBException{
		return jobConfigDAO.getJobConfigByActionFlag(SchedulerConstants.JOB_CONFIG_ACTION_FLAG.DELETE.getValue());
	}
	public void removeDeleteJobList(List<Long> jobReferences) throws DBException{
		jobConfigDAO.deleteJob(jobReferences);
	}
	public List<JobConfigVO> getJobListToAdd() throws DBException{
		return jobConfigDAO.getJobConfigByActionFlag(SchedulerConstants.JOB_CONFIG_ACTION_FLAG.LOAD.getValue());
	}
	public void updateActionFlag(Long jobId) throws DBException{
		jobConfigDAO.updateActionFlagAsEmpty(jobId);
	}
	//Based on scheduleStatus and actionFlag
	public List<ScheduleInfoVO> getScheduledJobListToRemove() throws DBException{
		return scheduleInfoDAO.getUnScheduledInfoByActionFlag(SchedulerConstants.SCHEDULE_ACTION_FLAG.DELETE.getValue());
	}
	public List<ScheduleInfoVO> getJobListToSchedule() throws DBException{
		List<ScheduleInfoVO> scheduleList = new ArrayList<ScheduleInfoVO>();
		List<ScheduleInfoVO> scheduleNewJobList =  scheduleInfoDAO.getUnScheduledInfoByActionFlag(SchedulerConstants.SCHEDULE_ACTION_FLAG.NEW.getValue());
		List<ScheduleInfoVO> scheduleModifyJobList =  scheduleInfoDAO.getUnScheduledInfoByActionFlag(SchedulerConstants.SCHEDULE_ACTION_FLAG.MODIFY.getValue());
		if(scheduleNewJobList!= null && !scheduleNewJobList.isEmpty()){
			scheduleList.addAll(scheduleNewJobList);
		}
		if(scheduleModifyJobList != null && !scheduleModifyJobList.isEmpty()){
			scheduleList.addAll(scheduleModifyJobList);
		}
		return scheduleList;
	}
	
	public List<ScheduleInfoVO> getJobListToResume() throws DBException{
		return scheduleInfoDAO.getUnScheduledInfoByActionFlag(SchedulerConstants.SCHEDULE_ACTION_FLAG.RESUME.getValue());
	}
	public List<ScheduleInfoVO> getJobListToPause() throws DBException{
		return scheduleInfoDAO.getUnScheduledInfoByActionFlag(SchedulerConstants.SCHEDULE_ACTION_FLAG.PAUSE.getValue());
	}

	public ScheduleInfoVO getScheduleInfo(String eventRef) throws DBException{
		return scheduleInfoDAO.getScheduleInfo(eventRef);
	}
	public ScheduleVO getScheduleInfoDetail(String eventRef)throws DBException{
		ScheduleVO vo = new ScheduleVO();
		ScheduleInfoVO infoVO = scheduleInfoDAO.getScheduleInfo(eventRef);
		String timeZone = scheduleInfoDAO.getUserBranchTimeZone(eventRef);
		timeZone = timeZone == null ? infoVO.getScheduleTimeZoneId():BNPCommonUtil.getTimeZoneID(timeZone);
		vo.setStartDate(infoVO.getStartDate());
		vo.setEndDate(infoVO.getEndDate());
		vo.setEventName(infoVO.getEventName());
		vo.setJobType(infoVO.getJobType());
		vo.setEventRef(eventRef);
		vo.setScheduleTimeZoneId(timeZone);
		vo.setMisfireInst(infoVO.getMisfireInst());
		/*static and adhoc jobs, this info will be there*/
		vo.setJobName(infoVO.getJobName());
		vo.setGroupName(infoVO.getGroupName());
		vo.setJobHandlerClassName(infoVO.getJobHandlerClassName());
		vo.setJobPirority(infoVO.getJobPirority());
		vo.setMisfireInst(infoVO.getMisfireInst());
		vo.setScheduleType(SchedulerUtil.getScheduleType(infoVO.getScheduleType()));
		/*end of static and adhoc jobs*/
		List<String> dayList = scheduledDaysDAO.getScheduledDaysByEventRef(eventRef);
		if(dayList != null && !dayList.isEmpty()){
			DAYS[] days = new DAYS[dayList.size()];
			int k = 0;
			for(String day:dayList){
				days[k++] = SchedulerUtil.getDay(day);
			}
			vo.setDays(days);
		}
		List<String> listHours = scheduledHoursDAO.getScheduledHoursByEventRef(eventRef);
		if(listHours != null && !listHours.isEmpty()){
			String[] hours = new String[listHours.size()];
			int k=0;
			for(String hour:listHours){
				hours[k++] = hour;
			}
			vo.setHours(hours);
		}
		List<String> listMinis = scheduledMinisDAO.getScheduledMinisByEventRef(eventRef);
		if(listMinis != null && !listMinis.isEmpty()){
			String[] minis = new String[listMinis.size()];
			int k=0;
			for(String mini:listMinis){
				minis[k++] = mini;
			}
			vo.setMinis(minis);
		}
		List<String> monthOfDayList = scheduledMonthOfDayDAO.getScheduledMonthOfDayByEventRef(eventRef);
		if(monthOfDayList != null && !monthOfDayList.isEmpty()){
			String[] monthOfDay = new String[monthOfDayList.size()];
			int k=0;
			for(String day:monthOfDayList){
				monthOfDay[k++] = day;
			}
			vo.setMonthOfDay(monthOfDay);
		}
		return vo;
	}
	
	//This method will be called at Reschedule
	public void updateScheduleInfo(ScheduleVO scheduleVo)throws DBException{
		ScheduleInfoVO scheduleInfoVO = new ScheduleInfoVO();
		scheduleInfoVO.setEventRef(scheduleVo.getEventRef());
		scheduleInfoVO.setActionFlag(SchedulerConstants.SCHEDULE_ACTION_FLAG.MODIFY.getValue());
		scheduleInfoVO.setScheduledStatus(SchedulerConstants.SCHEDULED_STATUS.NO.getValue());
		String timeZoneId = scheduleVo.getScheduleTimeZoneId();
		if(timeZoneId == null){
			scheduleVo.setScheduleTimeZoneId(TimeZone.getDefault().getID());
		}
		scheduleInfoVO.setStartDate(scheduleVo.getStartDate());
		scheduleInfoVO.setEndDate(scheduleVo.getEndDate());
		scheduleInfoVO.setScheduleTimeZoneId(scheduleVo.getScheduleTimeZoneId());
		scheduleInfoVO.setJobPirority(scheduleVo.getJobPirority());
		scheduleInfoVO.setMisfireInst(scheduleVo.getMisfireInst());
		
		scheduleInfoDAO.update(scheduleInfoVO);
		String eventRef = scheduleVo.getEventRef();
		jobInputDAO.deleteByEventRef(eventRef);
		scheduledDaysDAO.deleteByEventRef(eventRef);
		scheduledMonthOfDayDAO.deleteByEventRef(eventRef);
		scheduledHoursDAO.deleteByEventRef(eventRef);
		scheduledMinisDAO.deleteByEventRef(eventRef);
		scheduledMonthsDAO.deleteByEventRef(eventRef);
		insertInputParameters(eventRef, scheduleVo.getInput());
		insertHours(scheduleVo.getHours(), eventRef);
		//start of minis
		insertMinis(scheduleVo.getMinis(), eventRef);
		//end of minis
		//start of days
		insertDays(scheduleVo.getDays(), eventRef);
		insertMonthOfDay(scheduleVo.getMonthOfDay(),eventRef);
		//end of days
		insertMonths(scheduleVo.getMonths(),eventRef);
	}
	
	public void updateSchedulerError(ScheduleInfoVO scheduleInfoVO) throws DBException{
		String error = scheduleInfoVO.getSchedulerError();
		if(error.length()>2000){
			error = error.substring(0, 2000);
		}
		scheduleInfoVO.setSchedulerError(error);
		scheduleInfoDAO.updateScheduleError(scheduleInfoVO);
	}
    public void updateJobCompletionStatus(String eventRef) throws DBException{
    	scheduleInfoDAO.updateJobCompletionStatus(eventRef);
    }
    public String getJobCompletionStatus(String eventRef) throws DBException{
    	return scheduleInfoDAO.getJobCompletionStatus(eventRef);
    }
    public String getEventRefForStaticJob(String jobName,String groupName)throws DBException{
    	return scheduleInfoDAO.getEventRefForStaticJob(jobName, groupName);
    }
	private void insertHours(String[] hours, String eventRef) throws DBException{
		if(hours != null && hours.length > 0){
			List<ScheduledHoursVO> listHours = new ArrayList<ScheduledHoursVO>();
			for(String hour:hours){
				ScheduledHoursVO vo = new ScheduledHoursVO();
				vo.setEventRef(eventRef);
				vo.setHours(hour);
				listHours.add(vo);
			}
			scheduledHoursDAO.insert(listHours);
		}
	}
	private void insertMinis(String[] minis, String eventRef) throws DBException{
		if(minis != null && minis.length > 0){
			List<ScheduledMinisVO> listMinis = new ArrayList<ScheduledMinisVO>();
			for(String mini:minis){
				ScheduledMinisVO vo = new ScheduledMinisVO();
				vo.setEventRef(eventRef);
				vo.setMinis(mini);
				listMinis.add(vo);
			}
			scheduledMinisDAO.insert(listMinis);
		}
	}
	private void insertDays(DAYS[] days, String eventRef) throws DBException{
		if(days != null && days.length > 0){
			List<ScheduledDaysVO> listDays = new ArrayList<ScheduledDaysVO>();
			for(DAYS day:days){
				ScheduledDaysVO vo = new ScheduledDaysVO();
				vo.setEventRef(eventRef);
				vo.setDay(day.getValue());
				listDays.add(vo);
			}
			scheduledDaysDAO.insert(listDays);
		}
	}
	
	private void insertMonthOfDay(String[] monthOfDay, String eventRef) throws DBException{
		if(monthOfDay != null && monthOfDay.length > 0){
			List<ScheduledMonthOfDayVO> listDays = new ArrayList<ScheduledMonthOfDayVO>();
			for(String day:monthOfDay){
				ScheduledMonthOfDayVO vo = new ScheduledMonthOfDayVO();
				vo.setEventRef(eventRef);
				vo.setMonthOfDay(day);
				listDays.add(vo);
			}
			scheduledMonthOfDayDAO.insert(listDays);
		}
	}

	private void insertMonths(String[] months, String eventRef) throws DBException{
		if(months != null && months.length > 0){
			List<ScheduledMonthsVO> monthList = new ArrayList<ScheduledMonthsVO>();
			for(String month : months){
				ScheduledMonthsVO vo = new ScheduledMonthsVO();
				vo.setEventRef(eventRef);
				vo.setMonth(month);
				monthList.add(vo);
			}
			scheduledMonthsDAO.insert(monthList);
		}
	}
}
