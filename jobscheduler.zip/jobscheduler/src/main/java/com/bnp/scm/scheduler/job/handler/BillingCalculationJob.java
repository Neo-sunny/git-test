package com.bnp.scm.scheduler.job.handler;
/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   19 Mar 2011
 * 
 * Purpose:     Schedule events
 * 
 * Change History: 
 * Date                             Author                                      Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 20 SEP 2012                      Merdith                                     Initial Version- Billing Scheduler
 *10 Oct 2012                      	Merdith                                    	Event Name changed
 * ********************************************************************************************************************************/
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.scheduler.eipp.billing.CustomerBillingEvent;
import com.bnp.scm.services.scheduler.events.IEvent;
import com.bnp.scm.services.scheduler.exception.BNPSchedulerException;
@Component
public class BillingCalculationJob extends AbstractJob {

	public static final Logger LOGGER = LoggerFactory.getLogger(BillingCalculationJob.class);
	
	@Override
	public void run(Map<String, String> inputMap) throws SchedulerException {
		LOGGER.debug("BillingCalculationJob--Start");
		IEvent iEvent = null;
		try {
			iEvent = (IEvent)ApplicationBeanContextFactory.getBean(CustomerBillingEvent.class);
			String[] arg = new String[2];
			arg[0] = "";
			arg[1] = inputMap.get(SchedulerConstants.PARAM_NAME_BRANCH_ID);
			iEvent.processEvent(arg);
			LOGGER.debug("BillingCalculationJob--Afer Completion");
		}catch (BNPSchedulerException e) {
			LOGGER.error(e.getMessage(), e);
			throw new SchedulerException(e.errorCode,e.getMessage());
		}
		finally {
			iEvent = null;
		}	
		LOGGER.debug("BillingCalculationJob--End");
	}

}
