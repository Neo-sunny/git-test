/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Sep 2011
 * 
 * Purpose:      Auto Discounting services
 * 
 * Change History: 
 * Date                                   Author                                Version                                 Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 02 Mar 2012                      Oracle Financial Services Software Ltd                                    Initial Version
 ***************************************************************************/
package com.bnp.scm.scheduler.util;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.impl.StdSchedulerFactory;

public class QuartzSchedulerClientFactory extends QuartzSchedulerFactoryNew{
	
	/** The scheduler map. */
	private Map<String, Scheduler> schedulerMap = new HashMap<String, Scheduler>();
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(QuartzSchedulerClientFactory.class);
	
	public Scheduler getScheduler(String schedulerName) throws SchedulerException {
	  Scheduler scheduler = schedulerMap.get(schedulerName);
	  InputStream input = null;
	  if(scheduler == null){
	    try{
		  String quartzPropertyFile = schedulerName+".properties";
	      input = this.getClass().getClassLoader().getResourceAsStream(quartzPropertyFile);
		  if(input == null){
		    throw new SchedulerException("scheduler client property file "+quartzPropertyFile+"not found for scheduler "+schedulerName);
		  }
		//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("property file name for "+schedulerName+" is="+quartzPropertyFile);
		  System.setProperty(SchedulerConstants.QUARTZ_SYS_PROPERTY_NAME_FOR_FILE, quartzPropertyFile);
		  scheduler = StdSchedulerFactory.getDefaultScheduler();
		}catch(RuntimeException runtimeException){
		  LOGGER.error("Runtime Exception in schedler factory : {} ",runtimeException);
		  throw new SchedulerException(runtimeException);
		}catch(Exception exception){
		  LOGGER.error("Exception in schedler factory : {} ",exception);
		  throw new SchedulerException(exception);
		}finally {//Fortify fix : Unreleased Resource: Streams
		  try {
		    if(input != null) {
		    	input.close();
			}
		  }catch (Exception exception) {
		    LOGGER.error("Exception occured while Closing connection : {} ",exception);
		    throw new SchedulerException(exception);
		  }
		}
	  }
	  return scheduler;
	}
}
