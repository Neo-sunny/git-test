/************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   11 Jul 2012
 * 
 * Purpose:    TP Pending Request Feedback Job 
 * 
 * Change History: 
 * Date                            Author                                       Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------
 * 11 Jul 2012                     Prabu P                                   	Initial Version 
 ************************************************************************************************************************************/

package com.bnp.scm.scheduler.job.handler;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;
import com.bnp.scm.services.scheduler.events.IEvent;
import com.bnp.scm.services.scheduler.exception.BNPSchedulerException;
import com.bnp.scm.services.scheduler.mb.email.TPPendingRequestEvent;

@Component
public class TPPendingRequestJob extends AbstractJob {

	public static final Logger LOGGER = LoggerFactory.getLogger(TPPendingRequestJob.class);

	/* (non-Javadoc)
	 * @see com.bnp.scm.scheduler.job.AbstractJob#run(java.util.Map)
	 */
	@Override
	public void run(Map<String, String> inputMap) throws SchedulerException {
		LOGGER.debug("TPPendingRequestJob--Beg");
		IEvent iEvent = (IEvent)ApplicationBeanContextFactory.getBean(TPPendingRequestEvent.class);
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("TPPendingRequestJob--iEvent" + iEvent);
		try {
			String[] arg = new String[2];
			iEvent.processEvent(arg);
		}
		catch (BNPSchedulerException e) {
			LOGGER.error(e.getMessage(), e);
			throw new SchedulerException(e.errorCode, e.getMessage());
		}
		finally {
			iEvent = null;
		}
		LOGGER.debug("TPPendingRequestJob--End");
	}
}
