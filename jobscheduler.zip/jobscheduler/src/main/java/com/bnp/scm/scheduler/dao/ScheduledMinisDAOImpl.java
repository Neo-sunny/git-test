package com.bnp.scm.scheduler.dao;

import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.vo.ScheduledMinisVO;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.ibatis.sqlmap.client.SqlMapClient;

@Component
public class ScheduledMinisDAOImpl extends SqlMapClientWrapper implements ScheduledMinisDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(ScheduledMinisDAOImpl.class);
	
	private static final String INSERT = "ScheduledMinisNS.insert";
	private static final String DELETE_BY_EVENT_REF = "ScheduledMinisNS.deleteScheduledMinisByEventRef";
	private static final String SELECT_SCHEDULEDMINIS_BY_EVENT_REF = "ScheduledMinisNS.selectScheduledMinisByEventRef";

	
    public void insert(List<ScheduledMinisVO> record) throws DBException{
    	try{
    		SqlMapClient sqlMapClient = getSqlMapClientTemplate().getSqlMapClient();
    		sqlMapClient.startBatch();
    		for(ScheduledMinisVO vo:record){
    			sqlMapClient.insert(INSERT, vo);
    		}
    		sqlMapClient.executeBatch();
    	}catch(DataAccessException e){
    		LOGGER.error("error in inserting data::"+e.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_INSERT);

    	}catch(SQLException e){
    		LOGGER.error("error in inserting data::"+e.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_INSERT, e);
    	}
    }

    public void deleteByEventRef(String eventRef) throws DBException{
    	try{
    		getSqlMapClientTemplate().insert(DELETE_BY_EVENT_REF, eventRef);
    	}catch(DataAccessException e){
    		LOGGER.error("error in deleting::"+e.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_DELETE);

    	}
    }
    
    public List<String> getScheduledMinisByEventRef(String eventRef) throws DBException{
    	List<String> minisList;
    	try{
    		minisList = getSqlMapClientTemplate().queryForList(SELECT_SCHEDULEDMINIS_BY_EVENT_REF,eventRef);
    	}
    	catch(DataAccessException exp){
    		LOGGER.error("method:getScheduledMinissByEventRef"+exp.getMessage());
    		throw new DBException(ErrorConstants.ERROR_CONDITION_FETCH);
    	}
    	return minisList;

    }
}
