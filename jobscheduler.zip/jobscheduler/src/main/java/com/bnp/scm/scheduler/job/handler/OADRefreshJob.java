/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   18 Jan 2012
 * 
 * Purpose: Refresh OAD refresh value
 * 
 * Change History: 
 * Date                             Author                                							Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 18 Jan 2012                      Oracle Financial Services Software                              Initial Version
 * 03 Jun 2014						Yashmika											Changes done for FO 6.0
 * 03 Sep 2014						Ravi												#CSCDEV - 2998: Changes done for FO 6.0 - Manual Discount Approval with Discount Date based on Time Zone issue
 * 08 Aug 2017						Ramachandran Subramani								R9.2 CSC-7566
 * 14 Sep 2017						Shilpa Modi								            R9.2 CSC-7566 Sonar Fix
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.job.handler;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.service.JobHandlerService;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.discounting.IDiscountRequestService;
import com.bnp.scm.services.discounting.util.BNPDiscountUtil;
import com.bnp.scm.services.discounting.vo.DiscountRequestVO;
import com.bnp.scm.scheduler.util.SchedulerConstants.SCH_TYPE;
import com.bnp.scm.scheduler.service.ISchedulerService;
import com.bnp.scm.scheduler.vo.ScheduleVO;
import com.bnp.scm.services.invoice.dao.IInvoiceUploadDAO;

@Component
public class OADRefreshJob extends AbstractJob {

	public static final Logger LOGGER = LoggerFactory.getLogger(OADRefreshJob.class);
	
	@Autowired
	JobHandlerService jobHandlerService;
	
	@Autowired
	IDiscountRequestService discountService;
	
	@Autowired 
	private IInvoiceUploadDAO invoiceUploadDAO;
	@Autowired
	ISchedulerService schedulerService;
	@Override
	public void run(Map<String, String> inputMap) throws SchedulerException {
		LOGGER.debug("OADRefreshJob--Beg");
		/** Added for CSC-7566 by a37126 on 08-Aug-2017 - Starts **/
		Map<String, Object> params = new HashMap<String, Object>(); 
		boolean status = false;
		/** Added for CSC-7566 by a37126 on 08-Aug-2017 - Ends **/
		try {
			/** Added for CSC-7566 by a37126 on 08-Aug-2017 - Starts **/
			params.put(SchedulerConstants.BRANCH_ID, inputMap.get(SchedulerConstants.PARAM_NAME_BRANCH_ID));
			params.put(SchedulerConstants.ACTION, SchedulerConstants.LOCK);
			params.put(SchedulerConstants.P_EXECUTOR, SchedulerConstants.SYSTEM);
			params.put(SchedulerConstants.JOB_TYPE, SchedulerConstants.OAD_REF_JOB);
			params.put(SchedulerConstants.CALL_FROM, SchedulerConstants.OAD);
			
			status = discountService.getOadRefreshJobStatus(params);
			/** Added for CSC-7566 by a37126 on 08-Aug-2017 - Ends **/
			
			if(!status) { // Added for CSC-7566 by a37126 
			String timezone = discountService.getSupportBranchTimeZone(inputMap.get(SchedulerConstants.PARAM_NAME_BRANCH_ID));
			//Changes done for FO 6.0
			List<DiscountRequestVO> discRequestList=jobHandlerService.getOadRecords(inputMap.get(SchedulerConstants.PARAM_NAME_BRANCH_ID));
			
				if(discRequestList != null && !discRequestList.isEmpty()) // Added for sonar fix for CSC-7566 by a01076
				{
			for(DiscountRequestVO discountRequestVO:discRequestList){
				try{
				// CSCDEV - 2998: Manual Discount Approval with Discount Date based on Time Zone issue [BEGIN]
				discountRequestVO.setTimeZoneTZ(TimeZone.getTimeZone(timezone));
				// CSCDEV - 2998: Manual Discount Approval with Discount Date based on Time Zone issue [END]
				discountRequestVO.setOadFlafg(true);
				discountRequestVO.setDiscountDate(jobHandlerService.calculateDiscDate(discountRequestVO));
				jobHandlerService.updateDiscountDate(inputMap.get(SchedulerConstants.PARAM_NAME_BRANCH_ID), discountRequestVO);
				}catch(BNPApplicationException e){
					int errorMessage=ErrorConstants.ERROR_CALCULATING_DISC;
					jobHandlerService.updateErrorMessage(errorMessage,discountRequestVO);
				}
			}
				}
			/*Date discountDate = BNPDiscountUtil.getDiscountDate(TimeZone.getTimeZone(timezone));*/
			jobHandlerService.refreshOADRecords(inputMap);
			}else { /** Added for CSC-7566 by a37126 on 08-Aug-2017 - Starts **/
				//Scheduling an Adhoc Job after 5 minutes as already OAD refresh job is running to avoid job scheduler hanging
				  long rescheduleOADRefreshStart = System.currentTimeMillis();
				  printLogs(rescheduleOADRefreshStart,0,"rescheduleOADRefresh");
				  rescheduleOADRefresh(inputMap.get(SchedulerConstants.PARAM_NAME_BRANCH_ID), inputMap.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID));
				  long rescheduleOADRefreshStop = System.currentTimeMillis();
				  printLogs(rescheduleOADRefreshStart,rescheduleOADRefreshStop,"rescheduleOADRefresh");
			} /** Added for CSC-7566 by a37126 on 08-Aug-2017 - Ends **/
		} catch(BNPApplicationException e){
			LOGGER.error(e.getMessage());
			throw new SchedulerException(e.errorCode, e.getMessage());
		} finally { /** Added for CSC-7566 by a37126 on 08-Aug-2017 - Starts **/
			if(!status){
				  try{
					long unlockOADRefreshReqStart = System.currentTimeMillis();
					printLogs(unlockOADRefreshReqStart,0,"unlockOADRefreshReq"); 
					params.put(SchedulerConstants.ACTION, SchedulerConstants.UNLOCK);
					status = discountService.getOadRefreshJobStatus(params);
				    long unlockOADRefreshReqEnd = System.currentTimeMillis();
					printLogs(unlockOADRefreshReqStart,unlockOADRefreshReqEnd,"unlockOADRefreshReq");
				  }catch(BNPApplicationException exception){
				    LOGGER.error("BNPApplicationException occured while executing the finally block in OAD refresh job with Exception trace : {} ", exception);
		}
				}
		} /** Added for CSC-7566 by a37126 on 08-Aug-2017 - Ends **/
		LOGGER.debug("OADRefreshJob--End");
	}
	/** Added for CSC-7566 by a37126 on 08-Aug-2017 - Starts **/
	
	/**
	 * Prints the logs.
	 *
	 * @param startTime the start time
	 * @param endTime the end time
	 * @param locate the locate
	 */
	private void printLogs(long startTime, long endTime, String locate){
	   LOGGER.warn("Adding loggers in OAD Refresh Job flow start time of "+ locate +" "+ startTime+" end time "+endTime+" difference time "+(endTime - startTime));
	 }
	
	/**
	 * Reschedule OAD Refresh Job.
	 *
	 * @param branchId 
	 * @param jobHistId
	 * @throws BNPApplicationException the BNP application exception
	 */
	private void rescheduleOADRefresh(String branchId, String jobHistId) throws BNPApplicationException{
	  Map<String,String> jobInput = new HashMap<String, String>();
	  long rescheduleOADRefreshStart = System.currentTimeMillis();
	  printLogs(rescheduleOADRefreshStart,0,"rescheduleOADRefresh");
	  try { // Added for Sonar Fix CSC-7566 by a01076
	  String refOADRefreshjob = discountService.getOADRefreshJobRef(jobHistId);
	  if(refOADRefreshjob != null && !refOADRefreshjob.equals("")){
		Map<String,String> resultMap = discountService.getOadParam();
		String reschOADRefreshInterval = resultMap.get(SchedulerConstants.RESCH_INT_MTS);
		ScheduleVO scheduleVO = new ScheduleVO();
		scheduleVO.setEventRef(refOADRefreshjob);
		Timestamp startDate = invoiceUploadDAO.getCurrentSystemDate();
		Calendar cal = Calendar.getInstance();
	    cal.setTimeInMillis(startDate.getTime());
	    // Added for Sonar Fix CSC-7566 by a01076
	    // cal.add(Calendar.MINUTE, Integer.valueOf(reschOADRefreshInterval));
	    cal.add(Calendar.MINUTE, Integer.parseInt(reschOADRefreshInterval));
	    startDate = new Timestamp(cal.getTime().getTime());
	    Date endDate = new Date(startDate.getTime()+(60000));
	    jobInput.put(SchedulerConstants.PARAM_NAME_BRANCH_ID, branchId);
		jobInput.put(SchedulerConstants.JOB_HIST_ID, jobHistId);
		jobInput.put(SchedulerConstants.ORIG_JOB_TYPE, SchedulerConstants.JOB_TYPE_BRANCH);
		scheduleVO.setBranchId(branchId);
		scheduleVO.setInput(jobInput);
		scheduleVO.setJobType(SchedulerConstants.JOB_TYPE_BRANCH);
		scheduleVO.setEventName(SchedulerConstants.OAD_REFRESH_JOB);
		scheduleVO.setStartDate(startDate);
		scheduleVO.setEndDate(endDate);
		scheduleVO.setScheduleType(SCH_TYPE.SCHEDULED);
		schedulerService.rescheduleJob(scheduleVO);
	  }
	  long rescheduleOADRefreshStop = System.currentTimeMillis();
	  printLogs(rescheduleOADRefreshStart,rescheduleOADRefreshStop,"rescheduleOADRefresh");
	  }
	  // Added for Sonar Fix CSC-7566 by a01076
	  catch (NumberFormatException numberFormatException) { 
		  LOGGER.error("numberFormatException occured while rescheduleOADRefresh in OAD refresh job with Exception trace : {} ", numberFormatException);
		  } 
	}
	/** Added for CSC-7566 by a37126 on 08-Aug-2017 - Ends **/
}
