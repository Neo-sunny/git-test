/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   25 Apr 2012
 * 
 * Purpose: DueDate InsuranceReminde rJob
 * 
 * Change History: 
 * Date                            Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 25 Apr 2012                     Ramesh A                              Initial Version
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.job.handler;

import java.util.Map;
import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;
import com.bnp.scm.services.scheduler.events.IEvent;
import com.bnp.scm.services.scheduler.events.InsuranceThresholdReminderEvent;
import com.bnp.scm.services.scheduler.exception.BNPSchedulerException;

@Component
public class ThresholdInsuranceReminderJob extends AbstractJob {

	public static final Logger LOGGER = LoggerFactory.getLogger(ThresholdInsuranceReminderJob.class);
	
	
	//QC2475 - Changes to just Test xml on LocalSetup end
	
	@Override
	public void run(Map<String, String> inputMap) throws SchedulerException {
		LOGGER.debug("DueDateInsuranceReminderJob--Beg");
		IEvent iEvent = (IEvent)ApplicationBeanContextFactory.getBean(InsuranceThresholdReminderEvent.class);
		try {
			iEvent.processEvent();
		}catch (BNPSchedulerException e) {
			LOGGER.error(e.getMessage(), e);
			throw new SchedulerException(e.errorCode,e.getMessage());
		}finally {
			iEvent = null;
		}	
		LOGGER.debug("DueDateInsuranceReminderJob--End");
	}
}
