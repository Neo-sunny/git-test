/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Sep 2011
 * 
 * Purpose:      Auto Discounting services
 * 
 * Change History: 
 * Date                                   Author                                Version                                 Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 02 Mar 2012                      Oracle Financial Services Software Ltd                                    Initial Version
 ***************************************************************************/

package com.bnp.scm.scheduler.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ApplicationBeanContextFactory {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationBeanContextFactory.class);
	private BeanFactory beanFactory;
	private static final ApplicationBeanContextFactory applicationBeanContextFactory = new ApplicationBeanContextFactory();
	
	//If server mode is not passed, then it will be considered as Client Mode
	private ApplicationBeanContextFactory() {
		String schedulerMode = System.getProperty(SchedulerConstants.SCHED_COMP_MODE_PROP_NAME);
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("inside application context scheduler component mode ="+schedulerMode);
		   if(SchedulerConstants.SCHED_COMP_MODE_SERVER.equalsIgnoreCase(schedulerMode)){
			   beanFactory = new ClassPathXmlApplicationContext(SchedulerConstants.SERVER_COM_APPCONTEXT_XML);
		   }else {
			   beanFactory = new ClassPathXmlApplicationContext(SchedulerConstants.CLIENT_COM_APPCONTEXT_XML);
		   }
	}
	
	public BeanFactory getBeanFactory() {
		 return beanFactory;
	}
	
	public static Object getBean(String bean)
	{
		return applicationBeanContextFactory.beanFactory.getBean(bean);
	}
	public static Object getBean(Class<?> className)
	{
		return applicationBeanContextFactory.beanFactory.getBean(className);
	}

}
