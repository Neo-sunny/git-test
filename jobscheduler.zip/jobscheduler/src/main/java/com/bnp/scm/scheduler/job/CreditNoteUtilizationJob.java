/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Jan 30, 2012 11:19:31 AM
 * 
 * Purpose:      CreditNoteUtilizationJob.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Jan 30, 2012 11:19:31 AM        Oracle Financial Services Software Ltd                  Initial Version  
************************************************************************************************************************************************************/

package com.bnp.scm.scheduler.job;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;

@Component
public class CreditNoteUtilizationJob extends AbstractJob {

	@Override
	public void run(Map<String, String> arg0) throws SchedulerException {
		
	}

}
