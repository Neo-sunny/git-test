/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   08 OCT 2012
 * 
 * Purpose: Colection Failed ERP Job Handler
 * 
 * Change History: 
 * Date                             Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 *  08 Oct 2012                      Arun G                               Initial Version
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.job.handler;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.scheduler.eipp.erp.CollectionFailedERPEvent;
import com.bnp.scm.services.scheduler.events.IEvent;
import com.bnp.scm.services.scheduler.exception.BNPSchedulerException;

@Component
public class CollectionFailedJob extends AbstractJob {

	public static final Logger LOGGER = LoggerFactory.getLogger(CollectionFailedJob.class);

	@Override
	public void run(Map<String, String> inputMap) throws SchedulerException {
		LOGGER.debug("CollectionFailedJob--Beg");
		IEvent iEvent = (IEvent)ApplicationBeanContextFactory.getBean(CollectionFailedERPEvent.class);
		try {
			String[] arg = new String[6];
			arg[0] = "";
			arg[1] = inputMap.get(SchedulerConstants.PARAM_NAME_BRANCH_ID);
			arg[2] = inputMap.get(SchedulerConstants.PARAM_NAME_ORG_ID);
			arg[3] = inputMap.get(SchedulerConstants.PARAM_NAME_CCY);
			arg[4] = inputMap.get(SchedulerConstants.PARAM_NAME_PYMT_METHOD);
			arg[5] = inputMap.get(SchedulerConstants.PARAM_NAME_CUSTOM_PARAM);
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("CollectionFailedJob--arg-0->" + arg[0] + "<arg-1->" + arg[1] + "<arg-2->" + arg[2] + "<arg-3->" + arg[3] + "<arg-4->" + arg[4] + "<arg-5->" + arg[5]);
			iEvent.processEvent(arg);
		}catch (BNPSchedulerException e) {
			LOGGER.error(e.getMessage(), e);
			throw new SchedulerException(e.errorCode,e.getMessage());
		}finally {
			iEvent = null;
		}	
		LOGGER.debug("CollectionFailedJob--End");
	}
}
