/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Apr 2012
 * 
 * Purpose: Settlement Request Job Handler
 * 
 * Change History: 
 * Date                             Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 05 FEB 2014          			Ravishankar V						  Rel5.0     Funding Loan Changes
 * 09 APR 2014                      Ravishankar V                         CSCDEV 1410
 * 15 OCT 2014                      Chaitanya A                           BO 3.1 Extension Settlement Request Message changes
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.job.handler;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.service.JobHandlerService;
import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.scheduler.events.ETLSettlementJobEvent;
import com.bnp.scm.services.scheduler.events.ETLSettlementMessageEvent;
import com.bnp.scm.services.scheduler.events.IEvent;
import com.bnp.scm.services.scheduler.exception.BNPSchedulerException;

@Component
public class FundSettlementRequestJob extends AbstractJob {

	public static final Logger LOGGER = LoggerFactory.getLogger(FundSettlementRequestJob.class);
	
	@Autowired
	JobHandlerService jobHandlerService;
	
	//FO 8.0 Sonar Fix -Starts
	private void loggerMsg(String msg){
		LOGGER.debug(msg);
	}
	//FO 8.0 Sonar Fix -Ends
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.scheduler.job.AbstractJob#run(java.util.Map)
	 */
	@Override
	public void run(Map<String, String> inputMap) throws SchedulerException {
		LOGGER.debug("FundSettlementRequestJob--Beg");
		/* Modified for CSCDEV 1410 Start */
		IEvent iEvent = null;
		/* Modified for CSCDEV 1410 End */
		try {
			inputMap.put(SchedulerConstants.IS_FUND_REQ, BNPConstants.EODSET);
			Map<String, String> resultMap = jobHandlerService.processFundSettlement(inputMap);
			//FO 7.0 Fortify Issue Fix
			//FO 8.0 Sonar Fix
			loggerMsg("After executing Settlement EOD Proc, resultMap:"+resultMap);
			/* Modified for CSCDEV 1410 Start */
			iEvent = (IEvent)ApplicationBeanContextFactory.getBean(ETLSettlementJobEvent.class);
			String[] arg = new String[7];
			arg[0] = "";
			arg[1] = inputMap.get(SchedulerConstants.PARAM_NAME_BRANCH_ID);
			arg[2] = inputMap.get(SchedulerConstants.PARAM_NAME_ORG_ID);
			arg[3] = inputMap.get(SchedulerConstants.PARAM_NAME_CCY);
			arg[4] = inputMap.get(SchedulerConstants.PARAM_NAME_PYMT_METHOD);
			arg[5] = inputMap.get(SchedulerConstants.PARAM_NAME_CUSTOM_PARAM);
			arg[6] = inputMap.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID);
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("SettlementRequestJob--arg-0->" + arg[0] + "<arg-1->" + arg[1] + "<arg-2->" + arg[2] + "<arg-3->" + arg[3] + "<arg-4->" + arg[4] + "<arg-5->" + arg[5] + "<arg-6->" + arg[6]);
			iEvent.processEvent(arg);
			/* Modified for CSCDEV 1410 End */
			// BO 3.1 : Added to handle Extension Settlement Message For Funding.
			LOGGER.debug("SettlementRequestJob--Afer Completing ETLSettlement Request");
			iEvent = (IEvent)ApplicationBeanContextFactory.getBean(ETLSettlementMessageEvent.class);
			iEvent.processEvent(arg);
			LOGGER.debug("SettlementRequestJob--Afer Completing ETLSettlement Message Event");

		} catch (BNPSchedulerException e) {
			LOGGER.error(e.getMessage(), e);
			throw new SchedulerException(e.errorCode,e.getMessage());
		}
		catch(BNPApplicationException be){
			LOGGER.error(be.getMessage(), be);
			throw new SchedulerException(be.errorCode,be.getMessage());
		}
		/*finally {
			iEvent = null;
		}	*/
		LOGGER.debug("FundSettlementRequestJob--End");
	}
}
