package com.bnp.scm.scheduler.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.dao.ISchedulerDAO;
import com.bnp.scm.scheduler.exception.SchedulerValidationException;
import com.bnp.scm.scheduler.util.SchedulerConstants.DAYS;
import com.bnp.scm.scheduler.vo.ScheduleVO;
import com.bnp.scm.services.common.exception.DBException;

@Component
public class SchedulerValidatorService implements ISchedulerValidatorService{

	private static final Logger LOGGER = LoggerFactory.getLogger(SchedulerValidatorService.class);
	
	private @Autowired ISchedulerDAO schedulerDAO;
	
	
	public ISchedulerDAO getSchedulerDAO() {
		return schedulerDAO;
	}


	public void setSchedulerDAO(ISchedulerDAO schedulerDAO) {
		this.schedulerDAO = schedulerDAO;
	}


	public void validate(ScheduleVO scheduleVO) throws SchedulerValidationException{
		String[] minis = scheduleVO.getMinis();
		String[] hours = scheduleVO.getHours();
		DAYS[] days = scheduleVO.getDays();
		boolean needCronExp = false;
		if(minis !=null && minis.length > 0 && hours!=null && hours.length > 0 && days!=null && days.length>0){
			needCronExp = true;
			//all have been entered
		}else if((minis ==null || minis.length == 0) && (hours==null || hours.length == 0) && (days==null || days.length==0)){
			//Any one of the array is not null. And its not allowed
			throw new SchedulerValidationException(SchedulerConstants.ERROR_CODE_INPUT_MISSING);
		}
		if(scheduleVO.getStartDate() != null && scheduleVO.getEndDate() != null){
			if(scheduleVO.getEndDate().before(scheduleVO.getStartDate())){
				throw new SchedulerValidationException(SchedulerConstants.ERROR_CODE_END_DATE_PRIORTOSTART_DT);
			}
		}
	}
	
	public void checkDuplicateStaticJobNameExists(String jobName, String groupName)throws SchedulerValidationException{
		try{
			String eventRef = schedulerDAO.getEventRefForStaticJob(jobName, groupName);
			if(eventRef != null && eventRef.length() > 0){
				throw new SchedulerValidationException(SchedulerConstants.ERROR_CODE_NAME_ALREADY_EXISTS);
			}
		}catch(DBException e){
			LOGGER.debug("DBException in isStaticJobNameExists"+e);
			throw new SchedulerValidationException(e.getErrorCode());
		}
	}
}
