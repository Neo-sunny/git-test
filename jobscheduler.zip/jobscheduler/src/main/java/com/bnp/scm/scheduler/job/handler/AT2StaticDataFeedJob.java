/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Apr 2012
 * 
 * Purpose: AT2 Static Data feed Job Handler
 * 
 * Change History: 
 * Date                         Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 25 Apr 2012                  Ramesh A                              Initial Version
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.job.handler;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.StringTokenizer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;

@Component
public class AT2StaticDataFeedJob extends AbstractJob {

	public static final Logger LOGGER = LoggerFactory.getLogger(AT2StaticDataFeedJob.class);
	//FO 8.0 Sonar Fix -Starts
	private void loggerMsg(String msg){
		LOGGER.debug(msg);
	}
	//FO 8.0 Sonar Fix -Ends

	@Override
	public void run(Map<String, String> inputMap) throws SchedulerException {
        InputStream is = null;
        InputStreamReader isr = null;
        BufferedReader br = null;
        try {
        	BNPPropertyLoaderConfigurer bnpPropertyLoader = (BNPPropertyLoaderConfigurer)ApplicationBeanContextFactory.getBean(BNPPropertyLoaderConfigurer.class);;
        	String shellScriptName = bnpPropertyLoader.getValue("scheduler.at2.shellscript.name");
        	String shellScriptPath = bnpPropertyLoader.getValue("scheduler.at2.shellscript.path");
        	//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("shellScriptName-->" + shellScriptName + "< Path-->" + shellScriptPath);
        	if(shellScriptName != null && shellScriptPath != null){
    			String branchId = inputMap.get(SchedulerConstants.PARAM_NAME_BRANCH_ID);
    			String orgId = inputMap.get(SchedulerConstants.PARAM_NAME_ORG_ID);
    			String ccy = inputMap.get(SchedulerConstants.PARAM_NAME_CCY);
    			String pmtMethod = inputMap.get(SchedulerConstants.PARAM_NAME_PYMT_METHOD);
    			String customParam = inputMap.get(SchedulerConstants.PARAM_NAME_CUSTOM_PARAM);
    			//FO 7.0 Fortify Issue Fix
    			//FO 8.0 Sonar Fix
    			loggerMsg("Job Input-branchId->" + branchId + "<orgId->" + orgId + "<ccy->" + ccy + "<pmtMethod->" + pmtMethod + "<customParam->" + customParam);
    			StringTokenizer custParamToken = new StringTokenizer(customParam,",");
    			while(custParamToken.hasMoreElements()){
    				String at2FileName = ((String)custParamToken.nextElement());
    				//FO 7.0 Fortify Issue Fix
					//LOGGER.debug("at2FileName-->" + at2FileName);
    				String nameContent[] = at2FileName.split("\\.");
    				if(nameContent.length > 2){
    					String countryCode = nameContent[1];
    					String bankCode = nameContent[2];
    					//FO 7.0 Fortify Issue Fix
						//LOGGER.debug("countryCode->" + countryCode + "<bankCode->" + bankCode);
	    				ProcessBuilder probuilder = new ProcessBuilder();
						probuilder.directory(new File(shellScriptPath));
						probuilder.command("./" + shellScriptName,countryCode,bankCode);
						Process process = probuilder.start();
				        
				        //Read out dir output
				        is = process.getInputStream();
				        isr = new InputStreamReader(is);
				        br = new BufferedReader(isr);
				        //FO 7.0 Fortify Issue Fix
				        /*String line;
				        while ((line = br.readLine()) != null) {
				        	LOGGER.debug("Debug info from shell script--->" + line);
				        }*/
				        //Wait to get exit value
			            int exitValue = process.waitFor();
			          //FO 7.0 Fortify Issue Fix
			          //FO 8.0 Sonar Fix
						loggerMsg("Exit Value for " + at2FileName + " is " + exitValue);
    				}else{
    					LOGGER.error("Invalid AT2 file name");
    				}
    			}    
        	}else{
        		throw new SchedulerException("Invalid Shell script file name and path");
        	}
        } catch (InterruptedException e) {
        	//976332 CSCDEV-2683 17-NOV-2014:START
        	//e.printStackTrace();
        	//976332 CSCDEV-2683 17-NOV-2014:ENd
            throw new SchedulerException("InterruptedException Exception while AT2StaticDataFeedJob");
        } catch (Exception e){
        	//976332 CSCDEV-2683 17-NOV-2014:START
        	//e.printStackTrace();
        	//976332 CSCDEV-2683 17-NOV-2014:END
        	throw new SchedulerException(e.getMessage());
        }finally{
        	try{
        		if(br != null){
        			br.close();
        		}
        	}catch(Exception e){
        		LOGGER.error("Error while closing the stream" + e);
        	}
        }
	}
}
