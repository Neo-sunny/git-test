package com.bnp.scm.scheduler.dao;

import java.util.List;

import com.bnp.scm.scheduler.vo.ScheduledMonthsVO;
import com.bnp.scm.services.common.exception.DBException;

public interface ScheduledMonthsDAO {
    void insert(List<ScheduledMonthsVO> record) throws DBException;
    void deleteByEventRef(String eventRef) throws DBException;
    List<String> getScheduledDaysByEventRef(String eventRef) throws DBException;
}
