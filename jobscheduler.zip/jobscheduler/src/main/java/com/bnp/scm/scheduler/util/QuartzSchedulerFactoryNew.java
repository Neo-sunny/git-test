/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   06 Mar 2011
 * 
 * Purpose:      Bank code  DAO Impl 
 * 
 * Change History: 
 * Date                                                  Author                                                 Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 06 Mar 2012                      Oracle Financial Services Software Ltd                                    Initial Version 
 *                                  										
 *****************************************************************************************************************************************************************/
package com.bnp.scm.scheduler.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;

public abstract class QuartzSchedulerFactoryNew {

	private static final Logger LOGGER = LoggerFactory.getLogger(QuartzSchedulerFactoryNew.class);
	
	private static QuartzSchedulerFactoryNew factory;
	
	static
	{
	   String schedulerMode = System.getProperty(SchedulerConstants.SCHED_COMP_MODE_PROP_NAME);
	   //FO 7.0 Fortify Issue Fix
		//LOGGER.debug("scheduler component mode ="+schedulerMode);
	   if(SchedulerConstants.SCHED_COMP_MODE_SERVER.equalsIgnoreCase(schedulerMode)){
		   factory = new QuartzSchedulerServerFactory();
	   }else if(schedulerMode == null || SchedulerConstants.SCHED_COMP_MODE_CLIENT.equalsIgnoreCase(schedulerMode)){
		   factory = new QuartzSchedulerClientFactory();
	   }else{
		   throw new RuntimeException("Invalid Mode");
	   }
	}
		
	protected Scheduler scheduler;
	
	protected QuartzSchedulerFactoryNew(){
	}

	//If server mode is not passed, then it will be considered as Client Mode
	public static QuartzSchedulerFactoryNew getSchedulerFactory(){
	   return factory;	
	}
	//This argument is required for only client component
	abstract public Scheduler getScheduler(String schedulerName) throws SchedulerException;
	
}
