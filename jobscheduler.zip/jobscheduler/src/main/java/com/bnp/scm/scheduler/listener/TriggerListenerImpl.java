package com.bnp.scm.scheduler.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.Trigger;
import org.quartz.TriggerListener;
import org.quartz.Trigger.CompletedExecutionInstruction;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;
import com.bnp.scm.scheduler.util.SchedulerConstants;

public class TriggerListenerImpl implements TriggerListener{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(JobListenerImpl.class);
	
	private String name;
	public String getName() {
        return name;
    }

	public void setName(String name) {
        this.name=name;
    }
	//FO 8.0 Sonar Fix -Starts
	private void loggerMsg(String msg){
		LOGGER.debug(msg);
	}
	//FO 8.0 Sonar Fix -Ends
	@Override
	public void triggerComplete(Trigger arg0, JobExecutionContext inContext,CompletedExecutionInstruction arg2) {
		JobDataMap data = inContext.getMergedJobDataMap();
		String eventName = data.getString(SchedulerConstants.PARAM_NAME_EVENT_NAME);
		String eventRef = data.getString(SchedulerConstants.PARAM_NAME_EVENT_REF);
		//FO 7.0 Fortify Issue Fix
		//FO 8.0 Sonar Fix 
		loggerMsg("TriggerListener says: triggerComplete for event "+eventName+" and ref ="+eventRef);

	}

	@Override
	public void triggerFired(Trigger arg0, JobExecutionContext inContext) {
		JobDataMap data = inContext.getMergedJobDataMap();
		String eventName = data.getString(SchedulerConstants.PARAM_NAME_EVENT_NAME);
		String eventRef = data.getString(SchedulerConstants.PARAM_NAME_EVENT_REF);
		//FO 7.0 Fortify Issue Fix
		//FO 8.0 Sonar Fix 
		loggerMsg("TriggerListener says: trigger fired for event "+eventName+" and ref ="+eventRef);

	}

	@Override
	public void triggerMisfired(Trigger arg0) {
		JobDataMap data = arg0.getJobDataMap();
		String eventName = data.getString(SchedulerConstants.PARAM_NAME_EVENT_NAME);
		String eventRef = data.getString(SchedulerConstants.PARAM_NAME_EVENT_REF);
		//FO 7.0 Fortify Issue Fix
		//FO 8.0 Sonar Fix 
		loggerMsg("TriggerListener says: trigger Misfired for event "+eventName+" and ref ="+eventRef);

		
	}

	@Override
	public boolean vetoJobExecution(Trigger arg0, JobExecutionContext inContext) {
		JobDataMap data = inContext.getMergedJobDataMap();
		String eventName = data.getString(SchedulerConstants.PARAM_NAME_EVENT_NAME);
		String eventRef = data.getString(SchedulerConstants.PARAM_NAME_EVENT_REF);
		//FO 7.0 Fortify Issue Fix
		//FO 8.0 Sonar Fix 
		loggerMsg("TriggerListener says: inside vetoJobExecution for event "+eventName+" and ref ="+eventRef);
    	
    	ExcludeFireTriggerService excludeFireTriggerService = (ExcludeFireTriggerService)ApplicationBeanContextFactory.getBean("excludeFireTriggerService");
    	boolean result = false;
    	try{
    		result = excludeFireTriggerService.excludeCurrentJobExecution(inContext);
    	}catch(SchedulerException e){
    		LOGGER.error(e.getMessage());
    	}
    	//FO 7.0 Fortify Issue Fix
    	//FO 8.0 Sonar Fix
    	loggerMsg("TriggerListener says: vetoJobExecution result is "+result+" for event "+eventName+" and ref ="+eventRef);
		return result;
	}
	
}
