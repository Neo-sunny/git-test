/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Apr 2012
 * 
 * Purpose: Common Job Handler DAO Implementation
 * 
 * Change History: 
 * Date                             Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 25 Apr 2012                      Ramesh A                              Initial Version
 * 05 FEB 2014          			Ravishankar V						  Rel5.0     Funding Loan Changes
 * 03 Jun 2014						Yashmika											Changes done for FO 6.0
 * 03 Feb 2016                      Vignesh & Jayadivya S                 8.0 New Archival and Purging Implementation
 * 03 May 2016                      Vigneshwaran.R         				  Pre-Archival and Post-Archival Job Implementation
 * 14 May 2016                      Anand.R                               VB9 - Execution Error column record should be empty when status column is completed
 * 22 June 2016                     Nirmal Kumar G H                      VB8 - JobHandlerNS.updatejobExecutionHistoryStatus throws invalid number exception
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.dao;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.discounting.vo.DiscountRequestVO;
import com.bnp.scm.services.upload.utils.BNPUtils;

@Component
public class JobHandlerDAOImpl extends SqlMapClientWrapper implements JobHandlerDAO {
	private static final Logger LOGGER = LoggerFactory.getLogger(JobHandlerDAOImpl.class);
	
	private static final String NAME_SPACE = "JobHandlerNS.";
	private static final String CALL_USER_VALIDATION = "callUserValidation";
	private static final String CALL_SETTLEMENT_PROC = "callSettlementProcess";
	private static final String JOB_VALIDATION_UPDATE = "JobValidationUpdate";
	private static final String CALL_EDRAFT_MAT_DT_REACHED_EOD = "callEdraftMaturedDraftProcess";
	private static final String OLAP_ARCHIVAL_PURGING = "OLAPArchivalandPurging";
	private static final String OLTP_PURGING = "OLTPPurging";
	private static final String CALL_OAD_REFRESH_PROC = "callOADRefreshProc";
	private static final String UPDATE_OAD_DISCOUNT_DATE = "updateDiscountDate";
	private static final String CALL_FUND_SETTLEMENT_PROC = "callFundSettlementProcess";
	private static final String FETCH_OAD_RECORDS="getOADRecords";
	private static final String UPDATE_ERROR_MESSAGE="updateErrorMessage";
	private static final String ARCHIVAL_BRANCH_ORG = "archivalOrgBanch";
	private static final String PURGING_BRANCH_ORG = "purgeBranchOrg";
	private static final String IS_ORG_ID_ELIGIBLE_FOR_PROCESS = "JobHandlerNS.isOrgIdEligibleForProcess";
	
	/** The Constant PRE_ARCHIVAL_REPORT. */
	private static final String PRE_ARCHIVAL_REPORT = "preArchivalReporting";
	
	/** The Constant PRE_PURGE_REPORT. */
	private static final String PRE_PURGE_REPORT = "prePurgeReporting";
	
	/** The Constant UPDATE_JOBEXECUTIONHISTORY_STATUS. */
	private static final String UPDATE_JOBEXECUTIONHISTORY_STATUS="updatejobExecutionHistoryStatus";
	
	@Override
	public void validateUsers() throws BNPApplicationException{
		try {
			getSqlMapClientTemplate().queryForObject(NAME_SPACE + CALL_USER_VALIDATION);
		} catch (DataAccessException e) {
			LOGGER.error("Error in validateUsers : "+ e.getMessage());
			throw new DBException(ErrorConstants.ERROR_IN_USER_VALIDATION_PROCESS);
		}
	}

	@Override
	public Map<String, String> processSettlement(Map<String, String> inputMap) throws BNPApplicationException{
		try {
			inputMap.put("JOB_STATUS", null);
			inputMap.put("ERROR_DESC", null);
			//BO 3.1 - Added For Extension Batching Changes : New parameter added for Settlement procedure to process based on Batch ref no.
			if(!inputMap.containsKey("BATCH_REF_NO")){
				inputMap.put("BATCH_REF_NO", null);
			}
			getSqlMapClientTemplate().queryForObject(NAME_SPACE + CALL_SETTLEMENT_PROC,inputMap);
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("processSettlement inputMap :"+inputMap);
		} catch (DataAccessException e) {
			LOGGER.error("Error in processSettlement : "+ e.getMessage());
			throw new DBException(ErrorConstants.ERROR_IN_SETTLEMENT_PROCESS);
		}
		return inputMap;
	}

	@Override
	public void validateJobs() throws BNPApplicationException{
		try {
			//FO 8.0 Sonar Fix
			//int updateCount = getSqlMapClientTemplate().update(NAME_SPACE + JOB_VALIDATION_UPDATE);
			getSqlMapClientTemplate().update(NAME_SPACE + JOB_VALIDATION_UPDATE);
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("Job Validation updateCount :"+ updateCount);
		} catch (DataAccessException e) {
			LOGGER.error("Error in validateJobs : "+ e.getMessage());
			throw new DBException(ErrorConstants.ERROR_IN_JOB_VALIDATION_PROCESS);
		}
	}

	@Override
	public void eDraftMaturedDraftProcess() throws BNPApplicationException{
		try {
			getSqlMapClientTemplate().queryForObject(NAME_SPACE + CALL_EDRAFT_MAT_DT_REACHED_EOD);
		} catch (DataAccessException e) {
			LOGGER.error("Error in eDraftMaturedDraftProcess : "+ e.getMessage());
			throw new DBException(ErrorConstants.ERROR_EDRAFT_MATURED_DRAFT_PROCESSING);
		}
	}
	
	/**
	 * Checks if is branch level job.
	 *
	 * @param inputMap the input map
	 * @return true, if is branch level job
	 */
	private boolean isBranchLevelJob(Map<String, String> inputMap){
	  return inputMap.containsKey(BNPConstants.CUSTOM_PARAMETER) && (BNPConstants.KEY_BRANCH.equals(inputMap.get(BNPConstants.CUSTOM_PARAMETER)));
	}
	
	/**
	 * Checks if is organizationh level job.
	 *
	 * @param inputMap the input map
	 * @return true, if is organizationh level job
	 */
	private boolean isOrganizationhLevelJob(Map<String, String> inputMap){
      return inputMap.containsKey(BNPConstants.CUSTOM_PARAMETER) && (BNPConstants.CUSTOM_PARAM_KEY_ORG.equals(inputMap.get(BNPConstants.CUSTOM_PARAMETER)));
	}
	
	/**
	 * Check organization eligibility.
	 *
	 * @param inputMap the input map
	 * @return true, if successful
	 * @throws DBException the DB exception
	 */
	private boolean checkOrganizationEligiblity(Map<String, String> inputMap,boolean isArchivalProcess) throws DBException{
	  return isOrganizationhLevelJob(inputMap) && BNPConstants.YES.equals(isOrgIdEligibleForProcess(inputMap.get(BNPConstants.KEY_ORG),isArchivalProcess));	
	}
	
	/**
	 * Checks if is branch or organization job.
	 *
	 * @param inputMap the input map
	 * @return true, if is branch or organization job
	 */
	private boolean isBranchOrOrganizationJob(Map<String, String> inputMap){
	  return inputMap.containsKey(BNPConstants.CUSTOM_PARAMETER) && (BNPConstants.CUSTOM_PARAM_KEY_ORG.equals(inputMap.get(BNPConstants.CUSTOM_PARAMETER)) || (BNPConstants.KEY_BRANCH.equals(inputMap.get(BNPConstants.CUSTOM_PARAMETER))));
	}
	
	/**
	 * Checks if is system level job.
	 *
	 * @param inputMap the input map
	 * @return true, if is system level job
	 */
	private boolean isSystemLevelJob(Map<String, String> inputMap){
	  return inputMap.containsKey("CUSTOM_PARAM") && ("SYSTEM".equals(inputMap.get("CUSTOM_PARAM")));
	}
	

	@Override
	public void refreshOADRecords(Map<String, String> inputMap)
			throws BNPApplicationException {
		try {
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("refreshOADRecords inputMap :"+inputMap);
			getSqlMapClientTemplate().queryForObject(NAME_SPACE + CALL_OAD_REFRESH_PROC,inputMap);
		} catch (DataAccessException e) {
			LOGGER.error("Error in refreshOADRecords : "+ e.getMessage());
			throw new DBException(ErrorConstants.ERROR_IN_OAD_REFRESH_PROC);
		}
	}
	
	//Changes done for FO 6.0
	@Override
	public void updateDiscountDate(String branchId,DiscountRequestVO discountRequestVO) throws BNPApplicationException {
		try {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("branchId", branchId);
			params.put("discountDate", discountRequestVO.getDiscountDate());
			params.put("sysDate", discountRequestVO.getSystemDate());
			params.put("ruleId", discountRequestVO.getDiscDateRuleId());
			params.put("discReqId", discountRequestVO.getDiscountRequestId());
			params.put("recalcDate", discountRequestVO.getRecalcDate());
			getSqlMapClientTemplate().update(NAME_SPACE + UPDATE_OAD_DISCOUNT_DATE,params);
		} catch (DataAccessException e) {
			LOGGER.error("Error in updateDiscountDate : "+ e.getMessage());
			throw new DBException(ErrorConstants.ERROR_IN_OAD_REFRESH_PROC);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.scheduler.dao.JobHandlerDAO#processFundSettlement(java.util.Map)
	 */
	@Override
	public Map<String, String> processFundSettlement(Map<String, String> inputMap) throws DBException{
		try {
			inputMap.put("JOB_STATUS", null);
			inputMap.put("ERROR_DESC", null);
			getSqlMapClientTemplate().queryForObject(NAME_SPACE + CALL_FUND_SETTLEMENT_PROC,inputMap);
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("processSettlement inputMap :"+inputMap);
		} catch (DataAccessException e) {
			LOGGER.error("Error in processSettlement : "+ e.getMessage());
			throw new DBException(ErrorConstants.ERROR_IN_SETTLEMENT_PROCESS);
		}
		return inputMap;
	}
	
	//Changes done for FO 6.0
	/* (non-Javadoc)
	 * @see com.bnp.scm.scheduler.dao.JobHandlerDAO#getOadRecords(java.lang.String)
	 */
	@Override
	public List<DiscountRequestVO> getOadRecords(String branchId) throws DBException {
		try {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("branchId", branchId);
			return getSqlMapClientTemplate().queryForList(NAME_SPACE + FETCH_OAD_RECORDS,params);
			
		} catch (DataAccessException e) {
			LOGGER.error("Error in getOadRecords : "+ e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.scheduler.dao.JobHandlerDAO#updateErrorMessage(int, com.bnp.scm.services.discounting.vo.DiscountRequestVO)
	 */
	public void updateErrorMessage(int errorMessage,DiscountRequestVO discountRequestVO){
		try{
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("branchId", discountRequestVO.getSupportBranchId());
			params.put("discReqId", discountRequestVO.getDiscountRequestId());
			params.put("errorMessage",errorMessage);
			getSqlMapClientTemplate().update(NAME_SPACE + UPDATE_ERROR_MESSAGE,params);
		}catch(DataAccessException e){
			LOGGER.error("Error in updateErrorMessage : "+ e.getMessage());
		}
	}
	
	/**
	 * Gets the archival purging active status.
	 *
	 * @return the archival purging active status
	 * @throws DBException the DB exception
	 */
	public String getArchivalPurgingActiveStatus() throws DBException {
	  return (String)getSqlMapClientTemplate().queryForObject("JobHandlerNS.getParameterStatus");
	}
	
	/**
	 * Gets the archival purging active status.
	 *
	 * @return the archival purging active status
	 * @throws DBException the DB exception
	 */
	public String isOrgIdEligibleForProcess(String orgId,boolean isArchivalProcess) throws DBException {
	  Object instance = null;
	  Map<String, Object> inputParameters = new HashMap<String, Object>();
	  inputParameters.put(BNPConstants.ORG_ID, orgId);
	  inputParameters.put(BNPConstants.DEFINE_PROCESS_KEY, isArchivalProcess ? BNPConstants.PROCESS_ARCHIVAL_KEY_STORE : BNPConstants.PROCESS_PURGE_KEY_STORE);
	  instance = getSqlMapClientTemplate().queryForObject(IS_ORG_ID_ELIGIBLE_FOR_PROCESS,inputParameters);
	  return instance != null && BNPConstants.STATUS_S.equals(String.valueOf(String.valueOf(instance))) ? BNPConstants.YES : BNPConstants.NO;
	}
	
	/**
	 * Updatejob execution history status.
	 *
	 * @param status the status
	 * @param jobHistoryId the job history id
	 * @throws DataAccessException the data access exception
	 */
	public void updatejobExecutionHistoryStatus(String status,String jobHistoryId,String errorTrace,boolean isArchivalProcess) throws DataAccessException {
	  try{
	    Map<String, Object> inputParamMap = new HashMap<String, Object>();
		//VB8 Start Converting String to Number
		if(jobHistoryId != null)
		{
			inputParamMap.put(BNPConstants.LOCAL_KEY_JOB_HISTOY_ID, Integer.valueOf(jobHistoryId));
		}
		else
		{
			inputParamMap.put(BNPConstants.LOCAL_KEY_JOB_HISTOY_ID, jobHistoryId);
		}
		//VB8 End
		if(BNPConstants.SUCCESS_FLAG.equals(status)){
			//VB9 Start  
		  //inputParamMap.put(BNPConstants.LOCAL_KEY_STATUS, isArchivalProcess ? BNPConstants.ARCHIVAL_SUCCESS_MESSAGE : BNPConstants.PURGE_SUCCESS_MESSAGE);	
			//VB9 End
		}else if(BNPConstants.FAILURE_FLAG.equals(status) || BNPConstants.ERROR_FLAG.equals(status)){
		  inputParamMap.put(BNPConstants.LOCAL_KEY_STATUS, isArchivalProcess ? BNPConstants.ARCHIVAL_FAILURE_MESSAGE : BNPConstants.PURGE_FAILURE_MESSAGE);
		}else if(BNPConstants.EXCEPTION_FLAG.equals(status)){
		  inputParamMap.put(BNPConstants.LOCAL_KEY_STATUS,errorTrace);
		}
		getSqlMapClientTemplate().update(NAME_SPACE + UPDATE_JOBEXECUTIONHISTORY_STATUS,inputParamMap);
	  }catch(DataAccessException exception){
	    LOGGER.error("Exception occured while executing the method updatejobExecutionHistoryStatus with exception trace :: {} ",exception);
	    throw exception;
	  }
	}
	
	public Map<String, Object> generatePreArchivalOrPurgeReports(Map<String, String> inputMap, boolean isArchivalProcess) throws DataAccessException {
	  Map<String, Object> inputMapForReporting = new HashMap<String, Object>();
	  try{
	    inputMapForReporting.put(BNPConstants.JOB_HISTORY_ID, Integer.valueOf(inputMap.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID)));
	    inputMapForReporting.put(BNPConstants.BUSINESS_DATE, null);
	    inputMapForReporting.put(BNPConstants.SUCCESS_ERROR_FLAG, null);
	    inputMapForReporting.put(BNPConstants.OUTPUT_RESULTSET, null);
	    inputMapForReporting.put(BNPConstants.CUSTOM_PARAMETER, inputMap.get(BNPConstants.CUSTOM_PARAMETER));
	    String sqlQueryIdentifier = isArchivalProcess ? PRE_ARCHIVAL_REPORT : PRE_PURGE_REPORT;
	    if(inputMap.containsKey(BNPConstants.CUSTOM_PARAMETER) && (BNPConstants.KEY_BRANCH.equals(inputMap.get(BNPConstants.CUSTOM_PARAMETER)))){
	      inputMapForReporting.put(BNPConstants.PARAMETER_BRANCH_ID, inputMap.get(BNPConstants.INPUT_MAP_BRANCH_KEY));
	      inputMapForReporting.put(BNPConstants.PARAMETER_ORG_ID, null);
	      getSqlMapClientTemplate().queryForObject(NAME_SPACE + sqlQueryIdentifier,inputMapForReporting);
	    }else if(inputMap.containsKey(BNPConstants.CUSTOM_PARAMETER) && (BNPConstants.CUSTOM_PARAM_KEY_ORG.equals(inputMap.get(BNPConstants.CUSTOM_PARAMETER)))){
		  inputMapForReporting.put(BNPConstants.PARAMETER_ORG_ID, inputMap.get(BNPConstants.KEY_ORG));
		  inputMapForReporting.put(BNPConstants.PARAMETER_BRANCH_ID,null);
		  getSqlMapClientTemplate().queryForObject(NAME_SPACE + sqlQueryIdentifier,inputMapForReporting);
	    }
	    if(inputMapForReporting.get(BNPConstants.SUCCESS_ERROR_FLAG) != null){
	      Object objectInstance = inputMapForReporting.get(BNPConstants.SUCCESS_ERROR_FLAG);
	      System.out.println("The Status of generatePreArchivalOrPurgeReports is :: "+String.valueOf(objectInstance));
	      updatejobExecutionHistoryStatus(String.valueOf(objectInstance),String.valueOf(inputMapForReporting.get(BNPConstants.JOB_HISTORY_ID)),null,isArchivalProcess);
	    }
	    inputMapForReporting.put(BNPConstants.RESULT_SET_OUT_PUT_KEY, BNPUtils.getContendsAsList(inputMapForReporting,BNPConstants.OUTPUT_RESULTSET));
	    inputMapForReporting.put(BNPConstants.IS_ARCHIVAL_PROCESS, isArchivalProcess);
	  }catch(DataAccessException exception){
	    LOGGER.error("Exception Occured while Executing the Method generatePreArchivalOrPurgeReports() in  JobHandlerDAOImpl with exception trace : {} ",exception);
	    StringWriter _errorInstance = new StringWriter();
		PrintWriter printWriterInstance = new PrintWriter(_errorInstance);
		LOGGER.error("Error occured in method generatePreArchivalOrPurgeReports() ",exception);
		updatejobExecutionHistoryStatus("EXCEPTION",String.valueOf(inputMapForReporting.get(BNPConstants.JOB_HISTORY_ID)),printWriterInstance.toString(),isArchivalProcess);
	    throw exception;
	  }
	  return inputMapForReporting;
	}
	
	/**
	 * Handle organization and branch level.
	 *
	 * @param inputMap the input map
	 * @param isArchivalProcess the is archival process
	 * @return the map
	 * @throws DBException the DB exception
	 */
	private Map<String, Object> handleOrganizationAndBranchLevel(Map<String, String> inputMap,boolean isArchivalProcess) throws DBException {
      List<String> resultSetList = new ArrayList<String>();
	  Map<String, Object> procedureInputOutputMap = new HashMap<String, Object>();
	  String procedureName = isArchivalProcess ? ARCHIVAL_BRANCH_ORG : PURGING_BRANCH_ORG;
	  procedureInputOutputMap.put(BNPConstants.JOB_HISTORY_ID, Integer.valueOf(inputMap.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID)));
	  procedureInputOutputMap.put(BNPConstants.SUCCESS_ERROR_FLAG, null);
	  procedureInputOutputMap.put(BNPConstants.OUTPUT_RESULTSET, null);
	  if(isBranchLevelJob(inputMap)){
	    procedureInputOutputMap.put(BNPConstants.PARAMETER_BRANCH_ID, inputMap.get(BNPConstants.INPUT_MAP_BRANCH_KEY));
		procedureInputOutputMap.put(BNPConstants.PARAMETER_ORG_ID, null);
	  }else if(isOrganizationhLevelJob(inputMap)){
	    procedureInputOutputMap.put(BNPConstants.PARAMETER_ORG_ID, inputMap.get(BNPConstants.KEY_ORG));
		procedureInputOutputMap.put(BNPConstants.PARAMETER_BRANCH_ID, null);
	  }
	  if(checkOrganizationEligiblity(inputMap,isArchivalProcess) || isBranchLevelJob(inputMap)){
	    getSqlMapClientTemplate().queryForObject(NAME_SPACE + procedureName,procedureInputOutputMap);
	  }else if(isOrganizationhLevelJob(inputMap) && BNPConstants.NO.equals(isOrgIdEligibleForProcess(inputMap.get("ORG_ID"),isArchivalProcess))){
	    procedureInputOutputMap.put(BNPConstants.SUCCESS_ERROR_FLAG, BNPConstants.MANDATORY_FIRTST_RUN_FAILURE);
	  }
	  LOGGER.debug("The Value in P_SUCCESS_ERROR_FLG is "+procedureInputOutputMap.get("P_SUCCESS_ERROR_FLG"));
	  LOGGER.debug("The Value in P_EMAIL_REFCUR is "+procedureInputOutputMap.get("P_EMAIL_REFCUR"));
	  resultSetList = BNPUtils.getContendsAsList(procedureInputOutputMap,"P_EMAIL_REFCUR");
	  procedureInputOutputMap.put("CUSTOM_CONTENTS", BNPUtils.removeSpecialCharacters(resultSetList));
	  updatejobExecutionHistoryStatus(String.valueOf(procedureInputOutputMap.get(BNPConstants.SUCCESS_ERROR_FLAG)),String.valueOf(procedureInputOutputMap.get(BNPConstants.JOB_HISTORY_ID)),null,isArchivalProcess);
	  return procedureInputOutputMap;
	}
	
	/**
	 * Handle system level job.
	 *
	 * @param inputMap the input map
	 * @param isArchivalProcess the is archival process
	 * @return the map
	 * @throws DBException the DB exception
	 */
	private Map<String, Object> handleSystemLevelJob(Map<String, String> inputMap,boolean isArchivalProcess) throws DBException {
      Map<String, Object> procedureInputOutputMap = new HashMap<String, Object>();
	  List<String> resultSetList = new ArrayList<String>();
	  String procedureName = isArchivalProcess ? OLAP_ARCHIVAL_PURGING : OLTP_PURGING;
	  procedureInputOutputMap.put("v_job_id", inputMap.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID));
	  procedureInputOutputMap.put("scf_success", null);
  	  procedureInputOutputMap.put("scf_process_det", null);
	  procedureInputOutputMap.put("v_branch_id", null);
	  procedureInputOutputMap.put("v_org_id", null);
	  getSqlMapClientTemplate().queryForObject(NAME_SPACE + procedureName,procedureInputOutputMap);
	  resultSetList = BNPUtils.getContendsAsList(procedureInputOutputMap,"P_EMAIL_REFCUR");
	  LOGGER.debug("SYSTEM : ARCHIVAL : The result Set from the processOLAPArchivalandPurging is :: \n"+resultSetList);
	  procedureInputOutputMap.put("CUSTOM_CONTENTS", BNPUtils.removeSpecialCharacters(resultSetList));
	  return procedureInputOutputMap;
	}
		
	@SuppressWarnings("unused")
	@Override
	public Map<String, Object> processOLAPArchivalandPurging(Map<String, String> inputMap, boolean isArchivalProcess) throws DBException {
	  Map<String, Object> outParameterMap = new HashMap<String, Object>();
	  List<String> resultSetList = new ArrayList<String>();
	  try {
	    if(isSystemLevelJob(inputMap)){
	      outParameterMap.putAll(handleSystemLevelJob(inputMap,isArchivalProcess));
		} else if(isBranchOrOrganizationJob(inputMap)){
		  outParameterMap.putAll(handleOrganizationAndBranchLevel(inputMap,isArchivalProcess));
		}
	  } catch (Exception exception) {
	    LOGGER.error("Exception Occured while Executing the method  processOLAPArchivalandPurging : {} ",exception);
		StringWriter _errorInstance = new StringWriter();
		PrintWriter printWriterInstance = new PrintWriter(_errorInstance);
		LOGGER.error("Error occured in method processOLAPArchivalandPurging() ", exception);
		//VB8 Start loading right value from map
		updatejobExecutionHistoryStatus("EXCEPTION",String.valueOf(inputMap.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID)),printWriterInstance.toString(),isArchivalProcess);
		//VB8 End
		if(_errorInstance != null){
		  throw new DBException(ErrorConstants.ERROR_IN_OLAP_ARCHIVAL_PURGING_PROCESS,_errorInstance.toString() + " \n \n " + "With input OLAPParamMap :: \n"+outParameterMap);  
		}else{
		  throw new DBException(ErrorConstants.ERROR_IN_OLAP_ARCHIVAL_PURGING_PROCESS);
		}
	  }
	  return outParameterMap;
	}
	
	/**
	 * Updatejob execution history status.
	 *
	 * @param status the status
	 * @param jobHistoryId the job history id
	 * @throws DataAccessException the data access exception
	 */
	public void updatejobExecutionHistory(String status,String jobHistoryId,String errorTrace,boolean isArchivalProcess) throws DataAccessException {
	  try{
	    Map<String, Object> inputParamMap = new HashMap<String, Object>();
		inputParamMap.put(BNPConstants.LOCAL_KEY_JOB_HISTOY_ID, jobHistoryId);
		if(BNPConstants.SUCCESS_FLAG.equals(status)){
		  inputParamMap.put(BNPConstants.LOCAL_KEY_STATUS, isArchivalProcess ? BNPConstants.ARCHIVAL_JOB_SUCCESS_MESSAGE : BNPConstants.PURGE_JOB_SUCCESS_MESSAGE);	
		}else if(BNPConstants.FAILURE_FLAG.equals(status) || BNPConstants.ERROR_FLAG.equals(status)){
		  inputParamMap.put(BNPConstants.LOCAL_KEY_STATUS, isArchivalProcess ? BNPConstants.ARCHIVAL_JOB_FAILURE_MESSAGE : BNPConstants.PURGE_JOB_FAILURE_MESSAGE);
		}else if(BNPConstants.EXCEPTION_FLAG.equals(status)){
		  inputParamMap.put(BNPConstants.LOCAL_KEY_STATUS,errorTrace);
		}
		getSqlMapClientTemplate().update(NAME_SPACE + UPDATE_JOBEXECUTIONHISTORY_STATUS,inputParamMap);
	  }catch(DataAccessException exception){
	    LOGGER.error("Exception occured while executing the method updatejobExecutionHistoryStatus with exception trace :: {} ",exception);
	    throw exception;
	  }
	}
	
}

