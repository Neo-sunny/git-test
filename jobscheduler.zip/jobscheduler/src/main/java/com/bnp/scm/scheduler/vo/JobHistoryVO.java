/*******************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   10 FEB 2012
 * 
 * Purpose:     Job Monitoring Value Object
 * 
 * Change History: 
 * Date                                  Author                                            Reason 
 * ------------------------------------------------------------------------------------------------------------------------------------------ 
 * 10 FEB 2012           	Oracle Financial Services Software Ltd                  	Initial Version 
 * *******************************************************************************************************************************************/
package com.bnp.scm.scheduler.vo;


import java.sql.Timestamp;

import com.bnp.scm.services.common.vo.AbstractVO;
/**
 * Created for Job Monitoring summary screen
 * @author VijayRag
 *
 */
public class JobHistoryVO extends AbstractVO{

	private static final long serialVersionUID = 3308322277178155405L;
	
	private Timestamp scheduleDate;
	private Timestamp startTime;
	private Timestamp endTime;
	private String jobRefId;
	private String jobName;
	private String jobStatus;
	private String jobExecError;
	private String timeZone;

	private String originalJobRefId;
	private String jobType;
	private Timestamp startTimeFrom;
	private Timestamp startTimeTo;
	private Timestamp endTimeFrom;
	private Timestamp endTimeTo;
	private String startTimeFromHrs;
	private String startTimeFromMin;
	private String startTimeToHrs;
	private String startTimeToMin;
	private String endTimeFromMin;
	private String endTimeFromHrs;
	private String endTimeToMin;
	private String endTimeToHrs;
	private String jobInput;

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Timestamp getScheduleDate() {
		return scheduleDate;
	}
	public void setScheduleDate(Timestamp scheduleDate) {
		this.scheduleDate = scheduleDate;
	}
	public Timestamp getStartTime() {
		return startTime;
	}
	public void setStartTime(Timestamp startTime) {
		this.startTime = startTime;
	}
	public Timestamp getEndTime() {
		return endTime;
	}
	public void setEndTime(Timestamp endTime) {
		this.endTime = endTime;
	}
	public String getJobRefId() {
		return jobRefId;
	}
	public void setJobRefId(String jobRefId) {
		this.jobRefId = jobRefId;
	}
	public String getJobName() {
		return jobName;
	}
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	public String getJobStatus() {
		return jobStatus;
	}
	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}
	public String getJobExecError() {
		return jobExecError;
	}
	public void setJobExecError(String jobExecError) {
		this.jobExecError = jobExecError;
	}
	public String getTimeZone() {
		return timeZone;
	}
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}
	public String getOriginalJobRefId() {
		return originalJobRefId;
	}
	public void setOriginalJobRefId(String originalJobRefId) {
		this.originalJobRefId = originalJobRefId;
	}
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getJobInput() {
		return jobInput;
	}
	public void setJobInput(String jobInput) {
		this.jobInput = jobInput;
	}
	public Timestamp getStartTimeFrom() {
		return startTimeFrom;
	}
	public void setStartTimeFrom(Timestamp startTimeFrom) {
		this.startTimeFrom = startTimeFrom;
	}
	public Timestamp getStartTimeTo() {
		return startTimeTo;
	}
	public void setStartTimeTo(Timestamp startTimeTo) {
		this.startTimeTo = startTimeTo;
	}
	public Timestamp getEndTimeFrom() {
		return endTimeFrom;
	}
	public void setEndTimeFrom(Timestamp endTimeFrom) {
		this.endTimeFrom = endTimeFrom;
	}
	public Timestamp getEndTimeTo() {
		return endTimeTo;
	}
	public void setEndTimeTo(Timestamp endTimeTo) {
		this.endTimeTo = endTimeTo;
	}
	public String getStartTimeFromHrs() {
		return startTimeFromHrs;
	}
	public void setStartTimeFromHrs(String startTimeFromHrs) {
		this.startTimeFromHrs = startTimeFromHrs;
	}
	public String getStartTimeFromMin() {
		return startTimeFromMin;
	}
	public void setStartTimeFromMin(String startTimeFromMin) {
		this.startTimeFromMin = startTimeFromMin;
	}
	public String getStartTimeToHrs() {
		return startTimeToHrs;
	}
	public void setStartTimeToHrs(String startTimeToHrs) {
		this.startTimeToHrs = startTimeToHrs;
	}
	public String getStartTimeToMin() {
		return startTimeToMin;
	}
	public void setStartTimeToMin(String startTimeToMin) {
		this.startTimeToMin = startTimeToMin;
	}
	public String getEndTimeFromMin() {
		return endTimeFromMin;
	}
	public void setEndTimeFromMin(String endTimeFromMin) {
		this.endTimeFromMin = endTimeFromMin;
	}
	public String getEndTimeFromHrs() {
		return endTimeFromHrs;
	}
	public void setEndTimeFromHrs(String endTimeFromHrs) {
		this.endTimeFromHrs = endTimeFromHrs;
	}
	public String getEndTimeToMin() {
		return endTimeToMin;
	}
	public void setEndTimeToMin(String endTimeToMin) {
		this.endTimeToMin = endTimeToMin;
	}
	public String getEndTimeToHrs() {
		return endTimeToHrs;
	}
	public void setEndTimeToHrs(String endTimeToHrs) {
		this.endTimeToHrs = endTimeToHrs;
	}
	
	public String toString(){
		StringBuffer buffer=new StringBuffer();
		buffer.append("jobRefId:");
		buffer.append(jobRefId);
		buffer.append(" :jobName:");
		buffer.append(jobName);
		buffer.append(" :jobStatus:");
		buffer.append(jobStatus);
		buffer.append(" :startTime:");
		buffer.append(startTime);
		buffer.append(" :endTime:");
		buffer.append(endTime);
		return buffer.toString();
	}
}
