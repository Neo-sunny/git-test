package com.bnp.scm.scheduler.job.handler;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.discounting.ICommitmentFeePymtStatusService;

@Component
public class CommtFeePymtStatusUpdateJob extends AbstractJob{

	public static final Logger LOGGER = LoggerFactory.getLogger(CommtFeePymtStatusUpdateJob.class);
	
	@Autowired
	private ICommitmentFeePymtStatusService comtFeePymtStatusService ;
	
	@Override
	public void run(Map<String, String> inputMap) {

		LOGGER.debug("CommtFeePymtStatusUpdateJob--Begins");
		try {
			String[] arg = new String[7];
			arg[0] = inputMap.get(SchedulerConstants.PARAM_NAME_BRANCH_ID);
			arg[1] = inputMap.get(SchedulerConstants.PARAM_NAME_ORG_ID);
			
			
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("CommtFeePymtStatusUpdateJob--arg[0]->" + arg[0] +"arg[1]"+arg[1]);
			
			comtFeePymtStatusService.updateCommtFeePymtStatus(arg);
			
		}catch(BNPApplicationException be){
    		LOGGER.error("BNPApplicationException in CommtFeePymtStatusUpdateJob--->",be);
    	}	
		LOGGER.debug("CommtFeePymtStatusUpdateJob--End");
	
	}

}
