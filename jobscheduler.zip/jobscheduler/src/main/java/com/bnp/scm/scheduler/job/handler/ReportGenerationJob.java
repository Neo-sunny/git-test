package  com.bnp.scm.scheduler.job.handler;
        
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.report.IScheduleReportService;
import com.bnp.scm.services.scheduler.events.IEvent;
import com.bnp.scm.services.scheduler.events.ReportDeliveryEmailEvent;
import com.bnp.scm.services.scheduler.events.ReportDeliveryH2HEvent;
import com.bnp.scm.services.scheduler.exception.BNPSchedulerException;

@Component
public class ReportGenerationJob extends AbstractJob{
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(ReportGenerationJob.class);
	
	/** The schedule report service. */
	@Autowired
	private IScheduleReportService scheduleReportService;
	
	/**
	 * Gets the logger.
	 *
	 * @return the logger
	 */
	public Logger getLogger(){
	  return LOGGER;
	}
	
	/**
	 * _debug information.
	 *
	 * @param information the information
	 */
	public void _debugInformation(String information){
	  getLogger().debug(information);
	}
	
	/**
	 * Checks if is h2 h event.
	 *
	 * @param parameterMap the parameter map
	 * @return true, if is h2 h event
	 */
	private boolean isH2HEvent(Map<String,Object> parameterMap){
	  return (parameterMap.containsKey(BNPConstants.H2H_EVENT) && (BNPConstants.YES.equalsIgnoreCase(parameterMap.get(BNPConstants.H2H_EVENT).toString())));	
	}
	
	/**
	 * Checks if is key generated.
	 *
	 * @param parameterMap the parameter map
	 * @return true, if is key generated
	 */
	private boolean isKeyGenerated(Map<String,Object> parameterMap){
	  return (parameterMap != null && parameterMap.size()!=0 && parameterMap.get(BNPConstants.GENERATION_ID_KEY) != null);
	}
	
	/**
	 * Checks if is email event.
	 *
	 * @param parameterMap the parameter map
	 * @return true, if is email event
	 */
	private boolean isEmailEvent(Map<String,Object> parameterMap){
	  return (parameterMap.containsKey(BNPConstants.EMAIL_EVENT) && (BNPConstants.YES.equalsIgnoreCase(parameterMap.get(BNPConstants.EMAIL_EVENT).toString())));	
	}
	
	
	public void run(Map<String,String> input) throws SchedulerException{
	  getLogger().debug("Entering Method run() in ReportGenerationJob");
	  String reportId = input.get(SchedulerConstants.PARAM_NAME_SCHEDULE_REPORT_ID);
	  String reportTypeId = input.get(SchedulerConstants.PARAM_NAME_SCHEDULE_REPORT_TYPE_ID);
	  String genReportId = BNPConstants.EMPTY;
	  try{
	    Map<String,Object> parameterMap=scheduleReportService.generateReport(new Long(reportId), new Long(reportTypeId));
		_debugInformation("Parameter Map returned from the service Class "+parameterMap);
		_debugInformation("Entering with  reportId"+reportId+ " and with reportTypeId "+reportTypeId);
		IEvent iEvent = null;
		if(isKeyGenerated(parameterMap)) {
		   genReportId = parameterMap.get(BNPConstants.GENERATION_ID_KEY).toString();
		  _debugInformation("genReportId -"+genReportId +" reportTypeId - "+reportTypeId);
		  
		  //Modified as part of R11.0 - Sprint 2 - S2018X0701
		  if (isH2HEvent(parameterMap) || isEmailEvent(parameterMap))
		  {
			  String[] args = new String[7];
			  args[0] = genReportId;
			  args[1] = reportTypeId;
			  
			  if(isEmailEvent(parameterMap))
			  {
				  triggerEmail(args);
			  }
		    
			  if(isH2HEvent(parameterMap))
			  {
				  iEvent = (IEvent) ApplicationBeanContextFactory.getBean(ReportDeliveryH2HEvent.class);
				  iEvent.processEvent(args);
			  }
		  }
		}
	  }catch (BNPSchedulerException exception) {
	    getLogger().error("BNPSchedulerException occured whil executing Method run in ReportGenerationJob : {} ",exception.getMessage(),exception);
		throw new SchedulerException("Exception Occured :: "+exception.getMessage()+" InputMap :: "+input);
	  }catch(BNPApplicationException exception){
		getLogger().error("BNPApplicationException occured whil executing Method run in ReportGenerationJob : {} ",exception.getMessage(),exception);
	  	throw new SchedulerException("Exception Occured :: "+exception.getMessage()+" InputMap :: "+input);
	  }catch(Exception exception){
		getLogger().error("Exception occured whil executing Method run in ReportGenerationJob : {} ",exception.getMessage(),exception);
		throw new SchedulerException("Exception Occured :: "+exception.getMessage()+" InputMap :: "+input);
	  }
	  getLogger().debug("Exit of Method run() in ReportGenerationJob");
	}
	
	/**
	 * Method to trigger email 
	 * @param args
	 * @throws BNPSchedulerException
	 */
	public void triggerEmail(String[] args)throws BNPSchedulerException
	{
		try
		{
			IEvent iEvent = (IEvent) ApplicationBeanContextFactory.getBean(ReportDeliveryEmailEvent.class);
			iEvent.processEvent(args);
		}
		catch(BNPSchedulerException e)
		{
			throw e;
		}
		catch(Exception e)
		{
			getLogger().debug("Email Not Triggered::" + e.getMessage());
		}
	}
}
