/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Apr 2012
 * 
 * Purpose: Common Job Handler Service Implementation
 * 
 * Change History: 
 * Date                             Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 25 Apr 2012                      Ramesh A                              Initial Version
 * 05 FEB 2014          			Ravishankar V						  Rel5.0     Funding Loan Changes
 * 03 Jun 2014						Yashmika											Changes done for FO 6.0
 * 19 Jan 2016                      Achchhelal Nishad                                   R 8.1 Added for CSCDEV 6584
 * 03 Feb 2016                      Vignesh & Jayadivya S                 8.0 New Archival and Purging Implementation
 * 03 May 2016                      Vigneshwaran.R         				  Pre-Archival and Post-Archival Job Implementation
 * 06 Oct 2016                       Shilpa Modi                          FO 8.2 CSC-5746.CSC-5904 CDD/DPD change
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.dao.JobHandlerDAO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.discounting.IDiscountCalculatorService;
import com.bnp.scm.services.discounting.IDiscountProcessService;
import com.bnp.scm.services.discounting.IDiscountRequestService;
import com.bnp.scm.services.discounting.dao.IDiscountRequestDAO;
import com.bnp.scm.services.discounting.vo.DiscountRequestVO;
import com.bnp.scm.services.common.vo.NameValueVO;

@Component
public class JobHandlerServiceImpl implements JobHandlerService{
	private static final Logger LOGGER = LoggerFactory.getLogger(JobHandlerServiceImpl.class);
	
	@Autowired
	JobHandlerDAO jobHandlerDAO;
	@Autowired
	private IDiscountRequestDAO requestDAO;
	@Autowired
	private IDiscountCalculatorService discountCalcService;
	@Autowired
	private IDiscountProcessService discountProcessService;
	//861827 CSCDEV-6584 06012016 start
	@Autowired
	private IDiscountRequestDAO discountRequestDAO;
	@Autowired
	private IDiscountRequestService discountRequestService;
	//861827 CSCDEV-6584 06012016 end
	@Override
	public void validateUsers() throws BNPApplicationException{
		LOGGER.debug("Calling User Validation.....");
		jobHandlerDAO.validateUsers();
	}

	@Override
	public void validateJobs() throws BNPApplicationException{
		LOGGER.debug("Calling Job Validation.....");
		jobHandlerDAO.validateJobs();
	}

	@Override
	public Map<String, String> processSettlement(Map<String, String> inputMap) throws BNPApplicationException{
		return jobHandlerDAO.processSettlement(inputMap);
	}

	@Override
	public void eDraftMaturedDraftProcess() throws BNPApplicationException{
		jobHandlerDAO.eDraftMaturedDraftProcess();
	}
	
	@Override
	public Map<String, Object> processArchivalPurgeData(Map<String, String> inputMap, boolean isArchivalProcess) throws BNPApplicationException{
		return jobHandlerDAO.processOLAPArchivalandPurging(inputMap,isArchivalProcess);
	}

	@Override
	public Map<String, Object> processOLTPPurging(Map<String, String> inputMap, boolean isArchivalProcess) throws BNPApplicationException{
		return jobHandlerDAO.processOLAPArchivalandPurging(inputMap,isArchivalProcess);
	}

	@Override
	public void refreshOADRecords(Map<String, String> inputMap)
			throws BNPApplicationException {
		jobHandlerDAO.refreshOADRecords(inputMap);
	}
	//Changes done for FO 6.0
	@Override
	public void updateDiscountDate(String branchId,DiscountRequestVO discountRequestVO) throws BNPApplicationException {
		jobHandlerDAO.updateDiscountDate(branchId, discountRequestVO);
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.scheduler.service.JobHandlerService#processFundSettlement(java.util.Map)
	 */
	@Override
	public Map<String, String> processFundSettlement(Map<String, String> inputMap) throws BNPApplicationException{
		return jobHandlerDAO.processFundSettlement(inputMap);
	}
	
	//Changes done for FO 6.0
	/* (non-Javadoc)
	 * @see com.bnp.scm.scheduler.service.JobHandlerService#getOadRecords(java.lang.String)
	 */
	@Override
	public List<DiscountRequestVO> getOadRecords(String branchId) throws BNPApplicationException {
		try{
		return jobHandlerDAO.getOadRecords(branchId);
		}catch(DBException e){
			throw new BNPApplicationException(e.errorMessage);
		}
	}
	//Changes done for FO 6.0
	/* (non-Javadoc)
	 * @see com.bnp.scm.scheduler.service.JobHandlerService#calculateDiscDate(com.bnp.scm.services.discounting.vo.DiscountRequestVO)
	 */
	@Override
	public Date calculateDiscDate(DiscountRequestVO discountRequestVO) throws BNPApplicationException{
		Date discDate = null;
		//861827 CSCDEV-6584 06012016 start
		Map<String, Map<Object, Object>> branchDiscMap = new HashMap<String, Map<Object,Object>>();
		Map<Object, Object> branchDisc = null;
		boolean validateCutOff;
		// Changes done for CSC-5915,CSC-5746 by 06-Oct-2016 Start
		NameValueVO dateTypeMap=null;
		dateTypeMap =requestDAO.isDiscAdjRuleAvailable(discountRequestVO);
		// Changes done for CSC-5915,CSC-5746 by 06-Oct-2016 Ends
		//branchDisc = branchDiscMap.get(keyBuilder);
		branchDisc = branchDiscMap.get(discountRequestVO.getSupportBranchId() + discountRequestVO.getPaymentCurrencyCode() + discountRequestVO.getRateType());
		if(branchDisc == null) {
			branchDisc = discountRequestDAO.getBranchDiscDefinitions(discountRequestVO);
			if(branchDisc == null) {
				throw new BNPApplicationException(ErrorConstants.BRANCH_DISC_DOESNOT_EXIST);
			}
			//branchDiscMap.put(keyBuilder, branchDisc);
			branchDiscMap.put(discountRequestVO.getSupportBranchId() + discountRequestVO.getPaymentCurrencyCode() + discountRequestVO.getRateType(), branchDisc);
		}
		//861827 CSCDEV-6584 06012016 end
			Map<String, Map<Object, Object>> buyerAcctMap = new HashMap<String, Map<Object,Object>>();
			discountCalcService.populateBuyerAccountDetails(discountRequestVO, buyerAcctMap);
		discountRequestVO.setCddDetailsMap(requestDAO.getCDDdetails(discountRequestVO.getPaymtId()));
		Map<String, Map<String,Object>> validateLeadDaysMap = new HashMap<String, Map<String,Object>>();
		discountCalcService.validateLeadDaysForSysDate(discountRequestVO, validateLeadDaysMap);
		// Changes done for CSC-5915,CSC-5746 by 06-Oct-2016 Start
		discountRequestVO.getCddDetailsMap().put("SYS_DISC_DATE",discountCalcService.getSystemdateForAdjDisDate(discountRequestVO));
		// Changes done for CSC-5915,CSC-5746 by 06-Oct-2016 End
		discountRequestVO.setDiscDateManualFlg(true);
		discDate=discountProcessService.calculateDiscountDate(discountRequestVO,discountRequestVO.getFileId());
	    // Changes done for CSC-5915,CSC-5746 by 06-Oct-2016 Starts
			if(dateTypeMap==null){
		// Changes done for CSC-5915,CSC-5746 by 06-Oct-2016 Ends
		//861827 CSCDEV-6584 06012016 start
		discountRequestVO.setExtCutoffTime(String.valueOf(branchDisc.get("DISC_REQ_EXT_CUTTOFF")));
		validateCutOff = discountRequestService.validateCutOffTime(discountRequestVO, discountRequestVO.getRateType()); 
		if (validateCutOff) {
			discDate=discountRequestService.getNextBusinessDay(discountRequestVO, 1);	
		}
		//861827 CSCDEV-6584 06012016 end
		// Changes done for CSC-5915,CSC-5746 by 06-Oct-2016 Starts
		}
		// Changes done for CSC-5915,CSC-5746 by 06-Oct-2016 Ends
		discountRequestVO.setDiscDateManualFlg(false);
		return discDate;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.scheduler.service.JobHandlerService#updateErrorMessage(int, com.bnp.scm.services.discounting.vo.DiscountRequestVO)
	 */
	public void updateErrorMessage(int errorMessage,DiscountRequestVO discountRequestVO){
		jobHandlerDAO.updateErrorMessage(errorMessage,discountRequestVO);
	}
	
	public Map<String, Object> generatePreArchivalOrPurgeReporting(Map<String, String> inputMap,boolean isArchivalprocess) throws BNPApplicationException {
	  return jobHandlerDAO.generatePreArchivalOrPurgeReports(inputMap, isArchivalprocess);
	}
}
