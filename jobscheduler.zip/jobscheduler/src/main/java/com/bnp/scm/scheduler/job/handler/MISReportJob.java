package com.bnp.scm.scheduler.job.handler;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.report.IScheduleReportService;

@Component
public class MISReportJob extends AbstractJob{
	private static final Logger LOGGER = LoggerFactory.getLogger(MISReportJob.class);

	@Autowired
	private IScheduleReportService scheduleReportService;
	
	public void run(Map<String,String> input) throws SchedulerException{
		LOGGER.debug("MISReportJob - run - Beg");
		try{
			scheduleReportService.createMISReportCount(input);
		}catch(BNPApplicationException e){
			LOGGER.error("exception in processing=" + e);
		}
		LOGGER.debug("MISReportJob - run - End");
	}

}
