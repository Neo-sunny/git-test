package com.bnp.scm.scheduler.dao;

import java.util.List;
import java.util.Map;

import org.w3c.dom.views.AbstractView;

import com.bnp.scm.scheduler.vo.JobConfigVO;
import com.bnp.scm.scheduler.vo.JobExecHistVO;
import com.bnp.scm.scheduler.vo.JobInfoVO;
import com.bnp.scm.scheduler.vo.ScheduleInfoVO;
import com.bnp.scm.scheduler.vo.ScheduleVO;
import com.bnp.scm.services.common.exception.DBException;

public interface ISchedulerDAO extends AbsctractSchedulerDAO{
	
	long insertAuditLog(JobExecHistVO histVO) throws DBException;
	void updateAuditLogStatus(JobExecHistVO histVO) throws DBException;
	//will return eventRef. It should insert groupname, classname, jobName, input as well
	String insertScheduleInfo(ScheduleVO scheduleVO) throws DBException; 
	void updateScheduleStatus(String eventRef, String scheduleStatus, String actionFlag) throws DBException;
	void deleteScheduleInfo(String eventRef) throws DBException;
	void insertInputParameters(String eventRef, Map<String, String> input) throws DBException;
	JobInfoVO getJobInfo(String eventName) throws DBException;
	void deleteInputParameters(String eventRef) throws DBException;
	List<JobConfigVO> getDeleteJobList()throws DBException;
	void removeDeleteJobList(List<Long> jobReferences)throws DBException;
	List<JobConfigVO> getJobListToAdd()throws DBException;
	void updateActionFlag(Long jobId)throws DBException;
	List<ScheduleInfoVO> getScheduledJobListToRemove()throws DBException;
	List<ScheduleInfoVO> getJobListToSchedule()throws DBException;
	List<ScheduleInfoVO> getJobListToResume() throws DBException;
	List<ScheduleInfoVO> getJobListToPause() throws DBException;
	
	ScheduleInfoVO getScheduleInfo(String eventRef)throws DBException;
	ScheduleVO getScheduleInfoDetail(String eventRef)throws DBException;
	void updateScheduleInfo(ScheduleVO scheduleVO)throws DBException ;
	void updateSchedulerError(ScheduleInfoVO scheduleInfoVO) throws DBException ;
    void updateJobCompletionStatus(String eventRef) throws DBException;
    String getJobCompletionStatus(String eventRef) throws DBException;
    String getEventRefForStaticJob(String jobName,String groupName)throws DBException;
    void updateJobSchedulerStatus(String jobRef, String scheduleStatus,String errorMessage) throws DBException;
}
