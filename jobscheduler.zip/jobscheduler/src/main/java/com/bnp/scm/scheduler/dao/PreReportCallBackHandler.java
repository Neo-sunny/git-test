package com.bnp.scm.scheduler.dao;

/**************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  03 May 2016  
 * 
 * Purpose:    Archival and Purging
 * 
 * Change History: 
 * Date                                  Author                         Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 03 May 2016                       Vigneshwaran.R         Pre-Archival and Post-Archival Job Implementation
 * 11 Jan 2017						Ramanareddy polaka	    R9.1 CSC-6410 Fortify fix : System Information Leak 
 * *******************************************************************************************************************************
 * */

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ibatis.sqlmap.client.extensions.ParameterSetter;
import com.ibatis.sqlmap.client.extensions.ResultGetter;
import com.ibatis.sqlmap.client.extensions.TypeHandlerCallback;

public class PreReportCallBackHandler implements TypeHandlerCallback{

	// B28303 CSC-6410 11-01-2017:START  Fortify fix : System Information Leak  // variable LOGGER cannot be referenced from a static context	
	//public final Logger LOGGER = LoggerFactory.getLogger(PreReportCallBackHandler.class);
	public static final Logger LOGGER = LoggerFactory.getLogger(PreReportCallBackHandler.class);
	//B28303 CSC-6410 11-01-2017:START
	
	public static void writeFileExample(String resultsetContentds){
		FileOutputStream fileoutputStream = null;
		File fileInstance;
		try {
		  fileInstance = new File("LOCAL_FILE_PATH");
		  fileoutputStream = new FileOutputStream(fileInstance);
		  if (!fileInstance.exists()) {
		    fileInstance.createNewFile();
		  }
		  byte[] contentInBytes = resultsetContentds.getBytes();
		  fileoutputStream.write(contentInBytes);
		  fileoutputStream.flush();
		  fileoutputStream.close();
		} catch (IOException exceptionTrace) {
		// B28303 CSC-6410 11-01-2017:START  Fortify fix : System Information Leak	
			//exceptionTrace.printStackTrace();
			LOGGER.error("Exception Occured while executing method writeFileExample from PreReportCallBackHandler: {} ",exceptionTrace);
		//B28303 CSC-6410 11-01-2017:START
		} finally {
		  try {
	        if (fileoutputStream != null) {
			  fileoutputStream.close();
			}
		  } catch (IOException exceptionTrace) {
		// B28303 CSC-6410 11-01-2017:START  Fortify fix : System Information Leak	
		   // exceptionTrace.printStackTrace();
			  LOGGER.error(" Exception Occured whil executing method writeFileExample from PreReportCallBackHandler: {} ",exceptionTrace);
		 //B28303 CSC-6410 11-01-2017:START
		  }
		}
	}
	
	/**
	 * Convert result set to list.
	 *
	 * @param _resultsetInstance the _resultset instance
	 * @return the list
	 * @throws SQLException the SQL exception
	 */
	public static List<String> convertResultSetToList(ResultSet _resultsetInstance) throws SQLException {
	  List<String> _resultInstance = new ArrayList<String>();
	  StringBuilder builderResultInstance = new StringBuilder();
      ResultSetMetaData metatdataInstance = _resultsetInstance.getMetaData() ;
      int numberOfColumns = metatdataInstance.getColumnCount() ; 
      String dataHeaders = "\"" + metatdataInstance.getColumnName(1) + "\"" ; 
      for (int index = 2 ; index < numberOfColumns + 1 ; index ++ ) { 
        dataHeaders += ",\"" + metatdataInstance.getColumnName(index) + "\"" ;
      }
      builderResultInstance.append(dataHeaders) ;
      builderResultInstance.append("\n");
      while (_resultsetInstance.next()) {
        String row = "\"" + _resultsetInstance.getString(1) + "\""  ; 
        for (int indexPointer = 2 ; indexPointer < numberOfColumns + 1 ; indexPointer ++ ) {
          row += ",\"" + _resultsetInstance.getString(indexPointer) + "\"" ;
        }
        builderResultInstance.append(row) ;
        builderResultInstance.append("\n");
      }
      _resultInstance.add(builderResultInstance.toString());
      //writeFileExample(_resultInstance.toString());
      return _resultInstance;
    }
	
	public List<String> getResult(ResultGetter getter) throws SQLException {
	  ResultSet resultSet = getter.getResultSet();  
	  List<String> _resultInstance = new ArrayList<String>();
	  try{
		_resultInstance = convertResultSetToList(resultSet);
	  }catch(SQLException exception){
	    LOGGER.error("SQLException Occured while Executing the method PreReportCallBackHandler with exception : {} ",exception);
	    throw exception;
	  }
	  LOGGER.debug("The result Set from the PreReportCallBackHandler is :: \n"+_resultInstance);
	  return _resultInstance;
	}

	@Override
	public void setParameter(ParameterSetter arg0, Object arg1) throws SQLException {
		
	}

	@Override
	public Object valueOf(String arg0) {
		return null;
	}
	
}
