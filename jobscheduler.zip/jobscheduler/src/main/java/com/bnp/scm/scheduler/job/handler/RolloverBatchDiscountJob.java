/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on: 25 Nov 2014
 * 
 * Purpose: Rollover Batch Discounting creation job
 * 
 * Change History: 
 * Date                             Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 25 Nov 2014                   	Pradip                         Initial Version 
 ********************************************************************************************************************************/
package com.bnp.scm.scheduler.job.handler;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.scheduler.events.IEvent;
import com.bnp.scm.services.scheduler.events.RolloverBatchDiscountEvent;
import com.bnp.scm.services.scheduler.exception.BNPSchedulerException;


@Component
public class RolloverBatchDiscountJob extends AbstractJob {
	/**
	 * Logger class
	 */
	public static final Logger LOGGER = LoggerFactory.getLogger(RolloverBatchDiscountJob.class);
	
	@Override
	public void run(Map<String, String> inputMap) throws SchedulerException {
		LOGGER.debug("Rollover Batch Discount Job -- Start");
		IEvent iEvent = null;
		try {
			iEvent = (IEvent) ApplicationBeanContextFactory.getBean(RolloverBatchDiscountEvent.class);
			String[] arg = new String[7];
			arg[0] = "";
			arg[1] = inputMap.get(SchedulerConstants.PARAM_NAME_BRANCH_ID);
			arg[2] = inputMap.get(SchedulerConstants.PARAM_NAME_ORG_ID);
			arg[3] = inputMap.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID);
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("Rollover Batch Discount Job --arg-0->" + arg[0] + "<arg-1->" + arg[1]);
			iEvent.processEvent(arg);
			LOGGER.debug("Rollover Batch Discount Job -- Afer Completing Rollover Batch Discount Request");
		}
		catch (BNPSchedulerException e) {
			LOGGER.error(e.getMessage(), e);
			throw new SchedulerException(e.errorCode,e.getMessage());
		}
		finally {
			iEvent = null;
		}	
		LOGGER.debug("Rollover Batch Discount Job -- End");
	}
}
