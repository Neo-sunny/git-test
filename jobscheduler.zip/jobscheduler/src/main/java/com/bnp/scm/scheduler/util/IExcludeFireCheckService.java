package com.bnp.scm.scheduler.util;

import java.util.Map;

import com.bnp.scm.scheduler.exception.SchedulerException;

public interface IExcludeFireCheckService {

	boolean checkExcludeCurrentFire(Map<String, String> inputParameter) throws SchedulerException;
	
}
