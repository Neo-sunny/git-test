package com.bnp.scm.scheduler.vo;

public class ScheduledMonthOfDayVO {
	
    private String eventRef;
    private String monthOfDay;

	public String getEventRef() {
		return eventRef;
	}

	public void setEventRef(String eventRef) {
		this.eventRef = eventRef;
	}

	public String getMonthOfDay() {
		return monthOfDay;
	}

	public void setMonthOfDay(String monthOfDay) {
		this.monthOfDay = monthOfDay;
	}
    
}