/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Apr 2012
 * 
 * Purpose: Common Job Validator Implementation
 * 
 * Change History: 
 * Date                             Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 25 Apr 2012                      Ramesh A                              Initial Version
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.service;

import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.dao.JobValidatorDAO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

@Component
public class JobValidatorServiceImpl implements JobValidatorService{

	private static final Logger LOGGER = LoggerFactory.getLogger(JobValidatorServiceImpl.class);

	@Autowired
	private JobValidatorDAO jobValidatorDAO;

	@Override
	public NameValueVO getBranchDetails(String branchId)throws BNPApplicationException{
		LOGGER.debug("getBranchDetails--Beg");
		return jobValidatorDAO.getBranchDetails(branchId);
	}

	@Override
	public String getSystemDate() throws BNPApplicationException{
		LOGGER.debug("getSystemDate--Beg");
		return jobValidatorDAO.getSystemDate();
	}
	
	@Override
	public int getBranchHolidayCount(String branchId,Timestamp currentDate) throws BNPApplicationException {
		LOGGER.debug("getBranchHolidayCount--Beg");
		return jobValidatorDAO.getBranchHolidayCount(branchId, currentDate);
	}

	@Override
	public NameValueVO getOrganizationDetails(String orgId)
			throws BNPApplicationException {
		return jobValidatorDAO.getOrganizationDetails(orgId);
	}

	@Override
	public int getOrganizationHolidayCount(String orgId,
			Timestamp currentDate) throws BNPApplicationException {
	return jobValidatorDAO.getOrganizationHolidayCount(orgId, currentDate);
	}

	
}
