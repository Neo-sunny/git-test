package com.bnp.scm.scheduler.util;

import com.bnp.scm.scheduler.exception.SchedulerValidationException;
import com.bnp.scm.scheduler.vo.ScheduleVO;

public interface ISchedulerValidatorService {
	
	void validate(ScheduleVO scheduleVO) throws SchedulerValidationException;
	void checkDuplicateStaticJobNameExists(String jobName, String groupName)throws SchedulerValidationException;
	
}
