/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   23 Nov 2012
 * 
 * Purpose:      For File Processing
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 23 Nov 2012                Arun G                 						 Initial Version  
 ******************************************************************************************************************************************************/
package com.bnp.scm.scheduler.job.handler;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.common.services.filemgmt.util.FileProcessor;
import com.bnp.eipp.services.filemgmt.IFileProcessService;
import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@Component
public class FileProcessJob extends AbstractJob{

	private static final Logger LOGGER = LoggerFactory.getLogger(FileProcessJob.class);
	
	@Autowired
	protected IFileProcessService fileProcessorService;
	
	@Autowired
	private FileProcessor fileProcessor;
	
	
	@Override
	public void run(Map<String, String> input) throws SchedulerException {
		LOGGER.debug("entering into FileProcessJob");
		try{
			String fileID = input.get(BNPConstants.FILE_ID);
			String msgType = input.get(BNPConstants.MSG_TYPE);
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("fileID - "+fileID);
			fileProcessor.processFileData(fileID,msgType);
		}catch(BNPApplicationException exception){
			LOGGER.error("Exception in processing File JOB"+exception);
			throw new SchedulerException(exception.getMessage());
		}
		LOGGER.debug("exit from FileProcessJob");
	}

}
