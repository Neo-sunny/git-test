package com.bnp.scm.scheduler.job.handler;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.service.JobHandlerService;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@Component
public class JobValidationEvent extends AbstractJob {

	public static final Logger LOGGER = LoggerFactory.getLogger(JobValidationEvent.class);
	
	@Autowired
	JobHandlerService jobHandlerService;
	
	@Override
	public void run(Map<String, String> arg0) throws SchedulerException {
		LOGGER.debug("JobValidationEvent--Beg");
		try{
			jobHandlerService.validateJobs();
		}catch(BNPApplicationException be){
			LOGGER.error("BNPApplicationException while JobValidationEvent-->" + be.errorMessage);
			throw new SchedulerException(be.errorCode,be.getMessage());
		}
		LOGGER.debug("JobValidationEvent--End");
	}
}

