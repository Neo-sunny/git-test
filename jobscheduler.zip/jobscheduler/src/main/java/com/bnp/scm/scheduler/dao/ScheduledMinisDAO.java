package com.bnp.scm.scheduler.dao;

import java.util.List;

import com.bnp.scm.scheduler.vo.ScheduledMinisVO;
import com.bnp.scm.services.common.exception.DBException;

public interface ScheduledMinisDAO {
	
    void insert(List<ScheduledMinisVO> record) throws DBException;
    void deleteByEventRef(String eventRef) throws DBException;
    List<String> getScheduledMinisByEventRef(String eventRef) throws DBException;
    
}