/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Apr 2012
 * 
 * Purpose: Branch Holiday validator for Jobs 
 * 
 * Change History: 
 * Date                             Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 25 Apr 2012                      Ramesh A                              Initial Version
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.job.validator;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.service.JobValidatorService;
import com.bnp.scm.scheduler.util.IExcludeFireCheckService;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

@Component("organizationHolidayValidator")
public class OrganizationHolidayValidator implements IExcludeFireCheckService {

	private static final Logger LOGGER = LoggerFactory.getLogger(OrganizationHolidayValidator.class);
	
	@Autowired
	private JobValidatorService jobValidatorService;
	
	@Override
	public boolean checkExcludeCurrentFire(Map<String, String> inputParameter) throws SchedulerException {
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("OganizationHolidayValidator--inputParameter" + inputParameter);
		boolean returnFlg = true;
		String orgId = inputParameter.get(SchedulerConstants.PARAM_NAME_ORG_ID);
		if(orgId != null && orgId.length() > 0){
			try{
				NameValueVO organizationDetail = jobValidatorService.getOrganizationDetails(orgId);
				//FO 7.0 Fortify Issue Fix
				//LOGGER.debug("organizationDetail-->" + organizationDetail);
				if(organizationDetail != null){
					String datePattern="dd/MM/yyyy HH:mm:ss";
					String datewithTZPattern="dd/MM/yyyy HH:mm:ss Z";
					String today = jobValidatorService.getSystemDate();
					//FO 7.0 Fortify Issue Fix
					//LOGGER.debug("today->" + today);
					String organizationTimezone = organizationDetail.getValue();
					//FO 7.0 Fortify Issue Fix
					//LOGGER.debug("organizationDetail-organizationTimezone->" + organizationTimezone);
					SimpleDateFormat serverDateFormatter = new SimpleDateFormat(datePattern);
					serverDateFormatter.setTimeZone(TimeZone.getDefault());
					//FO 7.0 Fortify Issue Fix
					//LOGGER.debug("Server TimeZone->" + serverDateFormatter.getTimeZone());
					Date convertedServerTime = serverDateFormatter.parse(today);
					//FO 7.0 Fortify Issue Fix
					//LOGGER.debug("convertedServerTime-->" + convertedServerTime);
			
					SimpleDateFormat orgDateFormatterWithTZ = new SimpleDateFormat(datewithTZPattern);
					orgDateFormatterWithTZ.setTimeZone(TimeZone.getTimeZone(organizationTimezone));
					//FO 7.0 Fortify Issue Fix
					//LOGGER.debug("Formatted Date-->" + orgDateFormatterWithTZ.format(convertedServerTime));
					
					SimpleDateFormat branchDateFormatter = new SimpleDateFormat(datePattern);
			        Timestamp organizationDate = new Timestamp((branchDateFormatter.parse(orgDateFormatterWithTZ.format(convertedServerTime))).getTime());
	
			        //FO 7.0 Fortify Issue Fix
					//LOGGER.debug("OrganizationTimeZne-->" + organizationDate);
					int organizationHolidayCount = jobValidatorService.getOrganizationHolidayCount(orgId, organizationDate);
					//FO 7.0 Fortify Issue Fix
					//LOGGER.debug("OrganizationHolidayCount-->" + organizationHolidayCount);
					if(organizationHolidayCount == 0){
						returnFlg = false;
					}else{
						returnFlg = true;
					}
				}	
			}catch(ParseException e){
				LOGGER.error("Error while parsing Date");
			}catch(BNPApplicationException be){
				LOGGER.error(be.getErrorMessage());
			}
		}else{
			returnFlg = false;
		}
		return returnFlg;
	}

}
