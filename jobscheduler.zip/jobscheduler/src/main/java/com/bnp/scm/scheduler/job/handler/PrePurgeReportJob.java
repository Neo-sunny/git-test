package com.bnp.scm.scheduler.job.handler;

/**************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  03 May 2016   
 * 
 * Purpose:    Archival and Purging
 * 
 * Change History: 
 * Date                                  Author                         Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 03 May 2016                       Vigneshwaran.R         Pre-Archival and Post-Archival Job Implementation
 * *******************************************************************************************************************************
 * 
 * */
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.job.AbstractJob;
import com.bnp.scm.scheduler.service.JobHandlerService;
import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.scheduler.events.PreReportEmailEvent;

@Component
public class PrePurgeReportJob  extends AbstractJob {
	
private static final Logger LOGGER = LoggerFactory.getLogger(PrePurgeReportJob.class);
	
	/**
	 * Gets the logger.
	 *
	 * @return the logger
	 */
	public Logger getLogger(){
	  return LOGGER;
	}

	/** The job handler service. */
	@Autowired
	JobHandlerService jobHandlerService;

	@Override
	public void run(Map<String, String> inputParam) throws SchedulerException {
	  getLogger().debug("Entering method run from PrePurgeReportJob  with input Parameters :: "+inputParam);
	  long startTime = System.currentTimeMillis();
	  PreReportEmailEvent preReportEmailEventInstance = null;
	  try{
		getLogger().debug("Entering to Execute the Archival procedure from OLAPArchivalandPurgeJob");
	    Map<String, Object> traversalMap = jobHandlerService.generatePreArchivalOrPurgeReporting(inputParam,false);
	    preReportEmailEventInstance = (PreReportEmailEvent) ApplicationBeanContextFactory.getBean(PreReportEmailEvent.class);
	    preReportEmailEventInstance.processResultSetContends(traversalMap);
	  }catch(BNPApplicationException applicationException){
		getLogger().error("BNPApplicationException Occured whil Executing the method run from  PrePurgeReportJob :: {} ",applicationException);
		throw new SchedulerException(applicationException.errorCode,applicationException.getMessage());
	  }finally{
		  
	  }
	  long stopTime = System.currentTimeMillis();
	  getLogger().debug("The Time Taken to Execute PrePurgeReportJob for the Job History Identifier :: "+inputParam.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID)+" is :: "+(stopTime - startTime)+" milli Seconds");
	  System.out.println("The Time Taken to Execute PrePurgeReportJob for the Job History Identifier :: "+inputParam.get(SchedulerConstants.PARAM_NAME_JOB_HIST_ID)+" is :: "+(stopTime - startTime)+" milli Seconds");
	  getLogger().debug("Exit of method run from PrePurgeReportJob ");
	}

}
