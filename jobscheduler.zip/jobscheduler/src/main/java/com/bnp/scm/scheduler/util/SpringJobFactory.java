/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Sep 2011
 * 
 * Purpose:      Auto Discounting services
 * 
 * Change History: 
 * Date                                   Author                                Version                                 Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 02 Mar 2012                      Oracle Financial Services Software Ltd                                    Initial Version
 ***************************************************************************/
package com.bnp.scm.scheduler.util;

import org.quartz.Job;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.spi.JobFactory;
import org.quartz.spi.TriggerFiredBundle;

/*
 * This class is used in scheduler startup class
 * */
public class SpringJobFactory implements JobFactory{

	@Override
	public Job newJob(TriggerFiredBundle arg0, Scheduler arg1) throws SchedulerException {
		//976332 CSCDEV-2683 28-NOV-2014:START-END
		//System.out.println("inside new jobclass creation");
		Class jobClass = arg0.getJobDetail().getJobClass();
		//976332 CSCDEV-2683 28-NOV-2014:START-END
		//System.out.println("inside new jobclass creation");
		Job job = (Job)ApplicationBeanContextFactory.getBean(jobClass);
		//976332 CSCDEV-2683 28-NOV-2014:START-END
		//System.out.println("inside new jobclass creation");
		return job;
		//return null;
	}

}
