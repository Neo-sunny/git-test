/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Apr 2012
 * 
 * Purpose: Common Job Validator DAO Interface
 * 
 * Change History: 
 * Date                             Author                                Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 25 Apr 2012                      Ramesh A                              Initial Version
 ********************************************************************************************************************************/

package com.bnp.scm.scheduler.dao;

import java.sql.Timestamp;

import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

public interface JobValidatorDAO {
	NameValueVO getBranchDetails(String branchId)throws BNPApplicationException;
	int getBranchHolidayCount(String branchId,Timestamp currentDate) throws BNPApplicationException;
	String getSystemDate() throws BNPApplicationException;
	NameValueVO getOrganizationDetails(String orgId)throws BNPApplicationException;
	int getOrganizationHolidayCount(String orgId,Timestamp currentDate) throws BNPApplicationException;
}
