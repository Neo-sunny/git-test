package com.bnp.scm.scheduler.listener;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.Trigger;
import org.quartz.TriggerListener;
import org.quartz.Trigger.CompletedExecutionInstruction;
import org.springframework.beans.factory.annotation.Autowired;

import com.bnp.scm.scheduler.dao.ISchedulerDAO;
import com.bnp.scm.scheduler.dao.JobInputDAO;
import com.bnp.scm.scheduler.exception.SchedulerException;
import com.bnp.scm.scheduler.util.ApplicationBeanContextFactory;
import com.bnp.scm.scheduler.util.IExcludeFireCheckService;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.scheduler.util.SchedulerUtil;
import com.bnp.scm.scheduler.vo.JobInputVO;
import com.bnp.scm.services.common.exception.DBException;

public class ExcludeFireTriggerService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ExcludeFireTriggerService.class);
	
	private Map<String,String> eventExcludeServiceMap;
	
	@Autowired
	private JobInputDAO jobInputDAO;
	
	public Map<String, String> getEventExcludeServiceMap() {
		return eventExcludeServiceMap;
	}

	public void setEventExcludeServiceMap(Map<String, String> eventExcludeServiceMap) {
		this.eventExcludeServiceMap = eventExcludeServiceMap;
	}
	
	public JobInputDAO getJobInputDAO() {
		return jobInputDAO;
	}

	public void setJobInputDAO(JobInputDAO jobInputDAO) {
		this.jobInputDAO = jobInputDAO;
	}

	public boolean excludeCurrentJobExecution(JobExecutionContext inContext) throws SchedulerException{
		LOGGER.debug("start excludeCurrentJobExecution");
		//Parameter Holiday Check required for a trigger or not
		//Take the service against eventName
		boolean result = false;
		try{
			JobDataMap data = inContext.getMergedJobDataMap();
			String eventName = data.getString(SchedulerConstants.PARAM_NAME_EVENT_NAME);
			String eventRef = data.getString(SchedulerConstants.PARAM_NAME_EVENT_REF);
	    	String serviceHandler = eventExcludeServiceMap.get(eventName);
	    	//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("exclude serviceHandler for eventName ="+eventName+" is ="+serviceHandler);
	    	if(serviceHandler != null && !"".equals(serviceHandler)){
	    		IExcludeFireCheckService checkService = (IExcludeFireCheckService)ApplicationBeanContextFactory.getBean(serviceHandler);
	    		Map<String,String> input = new HashMap<String, String>();
				if(eventRef != null){
					List<JobInputVO> params = jobInputDAO.getInputByEventRef(eventRef);
					SchedulerUtil.buildInput(params, input);
				}
				LOGGER.debug("befor calling the service");
	    		result = checkService.checkExcludeCurrentFire(input);
	    		//FO 7.0 Fortify Issue Fix
				//LOGGER.debug("after calling the service for eventRef="+eventRef);
	    	}
		}catch(DBException e){
			LOGGER.debug("Error "+e);
			throw new SchedulerException(e.getErrorMessage(), e);
		}
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("end excludeCurrentJobExecution "+result);
		return result;
	}
	
}
