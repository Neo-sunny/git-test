package com.bnp.bnpcommon.service;

public class CommonServices {

	static void main(String args[]){
	}
}
