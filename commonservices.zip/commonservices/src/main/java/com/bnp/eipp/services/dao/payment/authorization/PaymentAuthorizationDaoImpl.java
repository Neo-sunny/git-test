/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Aug 8, 20122:50:13 PM
 * 
 * Purpose:      PaymentAuthorizationDaoImpl
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Aug 8, 20122:50:13 PM        Oracle Financial Services Software Ltd                  Initial Version
 * Oct 23 , 2012                Raja S													Change Done for St Defect 7008  
************************************************************************************************************************************************************/

package com.bnp.eipp.services.dao.payment.authorization;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.vo.payment.EippPymtVO;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;

/**
 * The Class PaymentAuthorizationDaoImpl.
 */
@Component
public class PaymentAuthorizationDaoImpl extends SqlMapClientWrapper  implements IPaymentAuthorizationDao{

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentAuthorizationDaoImpl.class);
	
	/** The Constant CHECK_DUAL_CTL_FLAG. */
	private static final String CHECK_DUAL_CTL_FLAG = "PymtAuthNS.checkDualCtlMandateFlag";
	
	/** The Constant CHECK_AUTP_AUTH_RULE_AVAILABLE. */
	private static final String CHECK_AUTP_AUTH_RULE_AVAILABLE = "PymtAuthNS.checkAutoAuthRuleAvailable";
	
	/** The Constant UPDATE_PMT_STATUS. */
	private static final String UPDATE_PMT_STATUS = "PymtAuthNS.updatePmtStatus";
	
	private static final String GET_SUPPORT_BRANCH_ID="PymtAuthNS.getSupportBranchId";
	
	private static final String CALC_BEFORE_DUE_DATE="PymtAuthNS.validateBeforeDueDate";

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.authorization.IPaymentAuthorizationDao#checkDualCtlMandatory(java.lang.String)
	 */
	@Override
	public boolean checkDualCtlMandatory(String orgId)
			throws BNPApplicationException {
		Integer count;
		try{
			count = (Integer)getSqlMapClientTemplate().queryForObject(CHECK_DUAL_CTL_FLAG,orgId);
		}catch (DataAccessException e) {
			LOGGER.error("Exception while getting dual control mandatory flag" , e);
			throw new BNPApplicationException(ErrorConstants.PROCESSING_ERROR);
		}
		return count>0;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.authorization.IPaymentAuthorizationDao#checkPymtAuthRuleAvailable(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO, com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public EippPymtVO checkPymtAuthRuleAvailable(EippPymtVO pymtVO, EippInvoiceVO invoiceVO)
			throws BNPApplicationException {
		EippPymtVO authRuleVO = null;
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("paymentValDate", pymtVO.getPmtValueDate());
		params.put("invDueDate", invoiceVO.getInvDueDate());
		params.put("supplierOrgId", pymtVO.getSupplierOrgId());
		params.put("buyerOrgId", pymtVO.getBuyerOrgId());
		params.put("ccyCode", pymtVO.getCcyCode());
		params.put("billType", invoiceVO.getBillType());
		params.put("pymtInitDate", pymtVO.getPymtInitDate());
		params.put("pymtAmount", pymtVO.getPymtAmount());
		params.put("buyerAcctIdentifier", pymtVO.getBuyerAcctIdentifier());
		
		try {
			authRuleVO = (EippPymtVO)getSqlMapClientTemplate().queryForObject(CHECK_AUTP_AUTH_RULE_AVAILABLE, params);
		} catch (DataAccessException e) {
			LOGGER.error("Exception while checking payment authorization rule for auto authorization:::::  " , e);
			throw new BNPApplicationException(ErrorConstants.PROCESSING_ERROR);
		}catch(Exception e){
			LOGGER.error("In payment authorization - checkPymtAuthRuleAvailable exception :", e);
		}
		return authRuleVO ;

	}

	private String getSupportBranchId(String orgId){
		
		return (String) getSqlMapClientTemplate().queryForObject(GET_SUPPORT_BRANCH_ID , orgId);
	}
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.authorization.IPaymentAuthorizationDao#updatePymtStatus(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public void updatePymtStatus(EippPymtVO pymtVO)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().update(UPDATE_PMT_STATUS, pymtVO);			
		} catch (DataAccessException e) {
			LOGGER.error("Exception while updating pymt status for auto authorization  :::::  " , e);
			throw new BNPApplicationException(ErrorConstants.PROCESSING_ERROR);
		}
	}

	@Override
	public Date getBeforeDueDateWithLeadDays(String currencyCode,
			String buyerOrgId, Date invDueDate, int days,String orgId)
			throws BNPApplicationException {
		Map<String,Object> params = new HashMap<String,Object>();
		Date businessDay = null;
		params.put("currencyCode",currencyCode);
		params.put("supportBranchId", getSupportBranchId(buyerOrgId));
		params.put("invDueDate", invDueDate);
		params.put("orgId",orgId);
		params.put("days", days);
		try{
		getSqlMapClientTemplate().queryForObject(CALC_BEFORE_DUE_DATE, params);
		 businessDay = (Date)params.get("businessdays");
		}catch (DataAccessException e) {
			LOGGER.error("Exception while getting Before Due Date Validation for Auto Authorization  :::::  " , e);
		}
		return businessDay ;	
	}	
}
