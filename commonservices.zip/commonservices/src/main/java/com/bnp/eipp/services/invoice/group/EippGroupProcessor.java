/** ************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 02, 2012
 * 
 * Purpose:      EippGroupProcessor.java 
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 02, 2012                      	Oracle Financial Services Software Ltd                                    	Initial Version 
 * 07 Aug 2012							Vinoth Kumar M															  	Sony Performance Tuning
 * 12 Oct 2012							Merdith 														  			Method Parameter changed for validating line item
 *  23 Oct 2012							Merdith 														  		Gross Value Changes for Line Item
 *  1 Nov 2012							Merdith 														  			Code modified for Invoice Upload for MP users
 *   11 Nov 2012						Merdith 														  		SIT - 2892							  
 *   12 Nov 2012						Merdith 														  		SIT - 2939
 **************************** **************************************************************************************************************************/

package com.bnp.eipp.services.invoice.group;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;

import com.bnp.eipp.services.invoice.IEippInvcUploadService;
import com.bnp.eipp.services.invoice.dao.IEippInvcUploadDAO;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.vo.EippTransactionVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.ILocaleMessageLoaderService;
import com.bnp.scm.services.common.cache.ICacheService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.invoice.IInvoiceUploadService;
import com.bnp.scm.services.invoice.dao.IInvoiceUploadDAO;
import com.bnp.scm.services.invoice.vo.InvalidFileDataVO;

public abstract class EippGroupProcessor<T extends EippTransactionVO> {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(EippGroupProcessor.class);
	
	@Autowired
	protected IInvoiceUploadDAO invoiceUploadDao;
	@Autowired
	protected IInvoiceUploadService invoiceUploadService;
	@Autowired
	protected ICacheService cacheService;
	@Autowired
	protected IEippInvcUploadDAO eippInvcUploadDAO;
	@Autowired
	protected ILocaleMessageLoaderService msgService;
	
	@Autowired
	protected IEippInvcUploadService eippInvcUploadService;
	
	protected T selectedData;
	
	protected List<T> dataList;
	
	protected List<T> validInvalidList;
	
	protected List<InvalidFileDataVO> errorDataList;
	
	protected List<String> mappingFiles;
	
	protected DozerBeanMapper beanMapper;
	
	protected FileDetailsVO detailsVO;
	
	protected EippGroupProcessor () {
		dataList = new ArrayList<T>();
		errorDataList = new ArrayList<InvalidFileDataVO>();
		validInvalidList = new ArrayList<T>();
//		populateMappingFiles();
	}
	
//	private void populateMappingFiles() {
//		mappingFiles = new ArrayList<String>();
//		
//		mappingFiles.add("mapper/EippCntMapper.xml");
//		mappingFiles.add("mapper/EippInvMapper.xml");
//		mappingFiles.add("mapper/EippLineItemMapper.xml");
//		mappingFiles.add("mapper/EippCustFieldMapper.xml");
//		mappingFiles.add("mapper/EippCustItmFldMapper.xml");
//		mappingFiles.add("mapper/EippAddrMapper.xml"); 
//		mappingFiles.add("mapper/EippAttachmentDataMapper.xml");
//		
//		beanMapper = new DozerBeanMapper(mappingFiles);
//	}
	
	public abstract void processAndValidateData() throws BNPApplicationException;
	
	protected boolean validateOrgData(EippTransactionVO eippTransactionVO) throws BNPApplicationException{
		boolean isInvalid = false;
		int errorCode=0;
		populateFileDetails(detailsVO);
		
		if (isNull(eippTransactionVO.getSupplierOrgId()) &&
				isNull(eippTransactionVO.getSupplierErpId())) {
			errorCode = ErrorConstants.SUPP_ORG_OR_ERP_MANDATORY;
			addToErrorDataList(eippTransactionVO.getTransactionType(), eippTransactionVO.toDataString(), errorCode, eippTransactionVO);
			isInvalid = true;
			return isInvalid;
		}
		
		if (isNull(eippTransactionVO.getBuyerOrgId()) && 
				isNull(eippTransactionVO.getBuyerErpId())) {
			errorCode = ErrorConstants.BUYER_ORG_OR_ERP_MANDATORY;
			addToErrorDataList(eippTransactionVO.getTransactionType(), eippTransactionVO.toDataString(), errorCode, eippTransactionVO);
			isInvalid = true;
			return isInvalid;
		}
		
		if(detailsVO.getSenderOrgType().equals(BNPConstants.MARKET_PLACE)){
			if (isNull(eippTransactionVO.getMarketPlaceOrgId())){
				errorCode = ErrorConstants.MARKET_PLACE_ORG_ID_IS_MANDATORY;
				addToErrorDataList(eippTransactionVO.getTransactionType(), eippTransactionVO.toDataString(), errorCode, eippTransactionVO);
				isInvalid = true;
				return isInvalid;
			}

			if (!isNull(eippTransactionVO.getMarketPlaceOrgId()) && !detailsVO.getSenderOrgId().equals(eippTransactionVO.getMarketPlaceOrgId())){
				errorCode = ErrorConstants.MARKET_PLACE_ORG_ID_SHOULD_BE_SENDER_ORG_ID;
				addToErrorDataList(eippTransactionVO.getTransactionType(), eippTransactionVO.toDataString(), errorCode, eippTransactionVO);
				isInvalid = true;
				return isInvalid;
			}
			
			if(!isBillThroughMarketPlace(eippTransactionVO.getBillType(), eippTransactionVO.getMarketPlaceOrgId())){
				errorCode = ErrorConstants.BILL_THRO_MARKET_PLACE_NOT_ENABLED;
				addToErrorDataList(eippTransactionVO.getTransactionType(), eippTransactionVO.toDataString(), errorCode, eippTransactionVO);
				isInvalid = true;
				return isInvalid;
			}
		}
		
		if (detailsVO.getModelType().equals(BNPConstants.MODEL_TYPE_SCM)) {
			isInvalid =  getSellerId(eippTransactionVO, detailsVO.getModelType()) || isInvalid;
			isInvalid = getBuyerId(eippTransactionVO, detailsVO.getModelType()) || isInvalid;
			isInvalid = isBillTypeLinkedToMP(eippTransactionVO, detailsVO) || isInvalid;
			isInvalid = checkBuyerSellerLinked(eippTransactionVO.getSupplierOrgId(), 
					eippTransactionVO.getBuyerOrgId(), eippTransactionVO.getBillType(), eippTransactionVO) || isInvalid;
		} else if(detailsVO.getModelType().equals(BNPConstants.MODEL_TYPE_BCM)) {
			isInvalid = getBuyerId(eippTransactionVO, detailsVO.getModelType()) || isInvalid;
			isInvalid = getSellerId(eippTransactionVO, detailsVO.getModelType()) || isInvalid;
			isInvalid = isBillTypeLinkedToMP(eippTransactionVO, detailsVO) || isInvalid;
			isInvalid = checkBuyerSellerLinked(eippTransactionVO.getBuyerOrgId(), 
					eippTransactionVO.getSupplierOrgId(), eippTransactionVO.getBillType(), eippTransactionVO) || isInvalid;
		}
		
		if ( (detailsVO.getModelType().equals(BNPConstants.MODEL_TYPE_BCM) 
				&& !(detailsVO.getSenderOrgType().equals(BNPConstants.MARKET_PLACE))) &&  
				!(detailsVO.getSenderOrgId().equals(eippTransactionVO.getBuyerOrgId()) || 
						detailsVO.getSenderOrgId().equals(eippTransactionVO.getSupplierOrgId())) ) {
			errorCode = ErrorConstants.INVALID_BCM_SENDER_ORG;
			addToErrorDataList(eippTransactionVO.getTransactionType(), eippTransactionVO.toDataString(), errorCode, eippTransactionVO);
			isInvalid = true;
		}
		
		if ( (detailsVO.getModelType().equals(BNPConstants.MODEL_TYPE_SCM) 
				&& !(detailsVO.getSenderOrgType().equals(BNPConstants.MARKET_PLACE))) && 
				!(detailsVO.getSenderOrgId().equals(eippTransactionVO.getSupplierOrgId())) ){
			errorCode = ErrorConstants.INVALID_SCM_SENDER_ORG;
			addToErrorDataList(eippTransactionVO.getTransactionType(), eippTransactionVO.toDataString(), errorCode, eippTransactionVO);
			isInvalid = true;
		}
		
		return isInvalid;
		
	}
	
	private boolean isBillTypeLinkedToMP(EippTransactionVO dataVO, 
				FileDetailsVO detailsVO) throws BNPApplicationException {
		
		boolean isInvalid = false;
		
		String orgId = detailsVO.getModelType().equals(
				BNPConstants.MODEL_TYPE_BCM) ? dataVO.getBuyerOrgId() : 
					dataVO.getSupplierOrgId();
		
		String billType = dataVO.getBillType();
		String userTypeId = detailsVO.getUserType();
		
		
		if (eippInvcUploadDAO.isBillTypeLinkedToMarketPlace(orgId, billType) && 
				(!isUploadedByMPUser(userTypeId) && !BNPConstants.BANKADMIN.equals(userTypeId)) ) {
			addToErrorDataList(dataVO.getTransactionType(), 
					dataVO.toDataString(), ErrorConstants.BILL_TYPE_MP_USER_UPLOAD_ERROR, dataVO);
			isInvalid = true;
		}
		return isInvalid;
	}
	
	private boolean isUploadedByMPUser(String userTypeId) {
		return cacheService.isMarketPlaceUser(userTypeId);
	}
	
//	protected AddressVO getAddress(PostalAddress6 postalAddress) {
//		AddressVO addressVO = beanMapper.map(postalAddress, AddressVO.class);
//		if (postalAddress.getAdrTp() != null) {
//			addressVO.setAddrType(postalAddress.getAdrTp().value());
//		}
//		if (postalAddress.getAdrLine() != null && !postalAddress.getAdrLine().isEmpty()) {
//			populateAddrLines(postalAddress.getAdrLine(), addressVO);
//		}
//		return addressVO;
//	}
//	
//	private void populateAddrLines(List<String> addrLines,AddressVO addressVO) {
//		if (addrLines.size() > 0 && !isNull(addrLines.get(0))) {
//			addressVO.setAddress1(addrLines.get(0));
//		}
//		if (addrLines.size() > 1 && !isNull(addrLines.get(1))) {
//			addressVO.setAddress2(addrLines.get(1));
//		}
//		if (addrLines.size() > 2 && !isNull(addrLines.get(2))) {
//			addressVO.setAddress3(addrLines.get(2));
//		}
//	}
	protected String getCustomerOrgId(EippTransactionVO eippTransactionVO) {
		if (detailsVO.getModelType().equals(BNPConstants.MODEL_TYPE_SCM)) {
			return eippTransactionVO.getSupplierOrgId();
		} else {
			return eippTransactionVO.getBuyerOrgId();
		}
	}
	
	protected BigDecimal getBigDecimalValue(BigDecimal value) {
		if (value == null) {
			return BigDecimal.ZERO;
		} else {
			return value;
		}
	}
	
	protected String getCntpOrgId(EippTransactionVO eippTransactionVO) {
		if (detailsVO.getModelType().equals(BNPConstants.MODEL_TYPE_SCM)) {
			return eippTransactionVO.getBuyerOrgId();
		} else {
			return eippTransactionVO.getSupplierOrgId();
		}
	}
	
	protected static boolean isSameDates(Date source, Date destination) {
		Calendar sourceCalendar = Calendar.getInstance();
		sourceCalendar.setTime(source);
		sourceCalendar.set(Calendar.HOUR_OF_DAY, 0);
		sourceCalendar.set(Calendar.MINUTE, 0);
		sourceCalendar.set(Calendar.SECOND, 0);
		sourceCalendar.set(Calendar.MILLISECOND, 0);
		
		Calendar destCalendar = Calendar.getInstance();
		destCalendar.setTime(destination);
		destCalendar.set(Calendar.HOUR_OF_DAY, 0);
		destCalendar.set(Calendar.MINUTE, 0);
		destCalendar.set(Calendar.SECOND, 0);
		destCalendar.set(Calendar.MILLISECOND, 0);
			
		if (sourceCalendar.getTime().compareTo(destCalendar.getTime()) == 0)
			return true;
		else 
			return false;

	}
	protected void populateFileDetails(FileDetailsVO detailsVO) throws BNPApplicationException{
		
		detailsVO.setModelType(eippInvcUploadDAO.getModelTypeForOrganization
				(detailsVO.getSenderOrgId()));
		
		detailsVO.setSenderOrgType(eippInvcUploadService.getOrgTypeForOrganization(detailsVO.getSenderOrgId()));
		
		String branchTimezone = eippInvcUploadDAO.getTimezoneForOrganization
				(detailsVO.getSenderOrgId());
		detailsVO.setTimeZoneTZ(TimeZone.getTimeZone(branchTimezone));
		
	}
	protected boolean checkBuyerSellerLinked(String custOrgId,String cntpOrgId,String billType,EippTransactionVO eippTransactionVO) throws BNPApplicationException {
		boolean isInvalid = false;

		if(detailsVO.getSenderOrgType().equals(BNPConstants.MARKET_PLACE)){
			if (isNull(custOrgId) || isNull(cntpOrgId) || !eippInvcUploadService.isBuyerSellerLinkedToMarketPlace(custOrgId, cntpOrgId, billType, eippTransactionVO.getMarketPlaceOrgId())) {
				addToErrorDataList(eippTransactionVO.getTransactionType(), eippTransactionVO.toDataString(), 
						ErrorConstants.BUYER_SELLER_NOT_LINKED_MARKET_PLACE, eippTransactionVO);
				isInvalid = true;
			}
		}
		else{
			if (isNull(custOrgId) || isNull(cntpOrgId) || !eippInvcUploadDAO.isBuyerSellerLinked(custOrgId, cntpOrgId, billType)) {
				addToErrorDataList(eippTransactionVO.getTransactionType(), eippTransactionVO.toDataString(), 
						ErrorConstants.BUYER_SELLER_NOT_LINKED, eippTransactionVO);
				isInvalid = true;
			}
		}

		return isInvalid;
	}
	
	/**
	 * Validate line items data.
	 *
	 * @param eippTransactionVO the eipp transaction vo
	 * @param allocType the alloc type
	 * @return true, if successful
	 */
	protected boolean validateLineItemsData(EippTransactionVO eippTransactionVO,String allocType) {
		boolean isInvalid = false;
		int errorCode = 0;
		Set<String> itemNoSet = new HashSet<String>();
		for (EippInvCntLineItemVO lineItemVO : eippTransactionVO.getLineItemList()) {
			
			if (!itemNoSet.add(lineItemVO.getLineItemNo())) {
				errorCode = ErrorConstants.LINE_ITEM_NOT_UNIQUE;
				break;
			}	
			else if (allocType!=null){ 
				errorCode = validateLineItemAmt(lineItemVO,allocType,eippTransactionVO.getFractionalDigits());
			}
		}
		if (errorCode > 0) {
			
			addToErrorDataList(eippTransactionVO.getTransactionType(), eippTransactionVO.toDataString(), 
					errorCode, eippTransactionVO);
			isInvalid = true;
		}
		isInvalid =  validateLineItemCount(eippTransactionVO) || isInvalid;
		return isInvalid;
	}
	private boolean validateLineItemCount(EippTransactionVO eippTransactionVO) {
		boolean isInvalid = false;
		
		if (eippTransactionVO.getLineItemCnt() != eippTransactionVO.getLineItemList().size()) {
			
			addToErrorDataList(eippTransactionVO.getTransactionType(), eippTransactionVO.toDataString(), 
					ErrorConstants.INVALID_LINE_ITEM_COUNT, eippTransactionVO);
			isInvalid = true;
		}
		return isInvalid;
	}
	
	private String getCustomerOrgId(List<String> orgIdList, 
			String orgIdInFile) throws BNPApplicationException {
		String orgId = null;
		if (orgIdInFile != null) {
			if (orgIdList != null && !orgIdList.isEmpty()) {
				if (orgIdList.indexOf(orgIdInFile) != -1) {
					orgId = orgIdInFile; 
				}
			} 
		} else {
			if (orgIdList != null && !orgIdList.isEmpty()) {
				if (orgIdList.size() > 1) {
					throw new BNPApplicationException(ErrorConstants.MULTIPLE_CUSTOMERS_WITH_SAME_ERP_ERROR);
				} else if (orgIdList.size() == 1) {
					orgId = orgIdList.get(0);
				}
			} 
		}
		return orgId;
	}
	
	private String getCounterPartyOrgId(
			List<String> cntOrgIdList, String orgIdInFile) throws BNPApplicationException {
		String cntrPartyId = null;
		
		if (orgIdInFile != null) {
			if (cntOrgIdList != null && !cntOrgIdList.isEmpty()) {
				if (cntOrgIdList.indexOf(orgIdInFile) != -1) {
					cntrPartyId = orgIdInFile; 
				}
			} 
		} else {
			if (cntOrgIdList != null && !cntOrgIdList.isEmpty()) {
				if (cntOrgIdList.size() > 1) {
					throw new BNPApplicationException(ErrorConstants.MULTIPLE_COUNTER_PARTY_WITH_SAME_ERP_ERROR);
				} else if (cntOrgIdList.size() == 1) {
					cntrPartyId = cntOrgIdList.get(0);
				}
			} 
		}
		return cntrPartyId;
	}
	
	protected boolean getSellerId(EippTransactionVO dataVO,String modelType) {
		boolean isInvalid = false;
		String sellerId = null;
		String buyerOrgId=dataVO.getBuyerOrgId();
		String sellerOrgId=dataVO.getSupplierOrgId();
		String sellerERPId=dataVO.getSupplierErpId();
		String billType = dataVO.getBillType();
		int errorCode=0;
		try {

			if (!isNull(sellerERPId)) {
					List<String> sellerIdList = null;
					if (modelType.equals(BNPConstants.MODEL_TYPE_SCM)) {
						sellerIdList = eippInvcUploadDAO.getCustomerOrgId(billType, sellerERPId);
						
						try {
							sellerId = getCustomerOrgId(sellerIdList, sellerOrgId);
						} catch (BNPApplicationException e) {
							errorCode = e.getErrorCode();
							addToErrorDataList(dataVO.getTransactionType(), dataVO.toDataString(),errorCode, dataVO);
							isInvalid = true;
							errorCode = 0;
						}
						
						if(isNull(sellerId) && errorCode == 0) {
							//Seller Organization does not exist for the Seller ERP id.
							errorCode=ErrorConstants.INVALID_SUPPLIER_ORG_FOR_ERP_BILL;
							addToErrorDataList(dataVO.getTransactionType(), dataVO.toDataString(),errorCode, dataVO);
							isInvalid = true;
							errorCode = 0;
						}
						
						if (!isNull(sellerOrgId) && !isNull(sellerId) && !sellerOrgId.equals(sellerId)) {
							errorCode=ErrorConstants.CUSTOMER_SELLERORG_MISMATCH;
						}
						
					} else {
						sellerIdList = eippInvcUploadDAO.getCounterPartyOrgId(buyerOrgId, billType, sellerERPId);
						
						try {
							sellerId = getCounterPartyOrgId(sellerIdList, sellerOrgId);
						} catch (BNPApplicationException e) {
							errorCode = e.getErrorCode();
							addToErrorDataList(dataVO.getTransactionType(), dataVO.toDataString(),errorCode, dataVO);
							isInvalid = true;
							errorCode = 0;
						}
						
						if(isNull(sellerId) && errorCode == 0) {
							//Seller Organization does not exist for the Seller ERP id.
							errorCode=ErrorConstants.INVALID_SUP_ORG_ID_FOR_BUYORG_BILL_ERP;
							addToErrorDataList(dataVO.getTransactionType(), dataVO.toDataString(),errorCode, dataVO);
							isInvalid = true;
							errorCode = 0;
						}
						
						if (!isNull(sellerOrgId) && !isNull(sellerId) && !sellerOrgId.equals(sellerId)) {
							errorCode=ErrorConstants.COUNTER_PARTY_SELLER_ORG_MISMATCH;
						}
					}
			}
				
			if (errorCode>0) {
				addToErrorDataList(dataVO.getTransactionType(), dataVO.toDataString(),errorCode, dataVO);
				isInvalid = true;
			} else if(!isNull(sellerId)) {
				dataVO.setSupplierOrgId(sellerId);
			}

		} catch (BNPApplicationException e) {
			addToErrorDataList(dataVO.getTransactionType(), 
					dataVO.toDataString(), e.getErrorCode(), dataVO);
			isInvalid = true;

		}
		return isInvalid;
	}

	protected InvalidFileDataVO createInvalidFileDataVO(String transactionType,String errorData, 
			int errorCode) {
		InvalidFileDataVO invalidData = new InvalidFileDataVO();
		invalidData.setFileID(detailsVO.getFileId());
		invalidData.setErrorMessage(String.valueOf(errorCode));
		invalidData.setErrorData(errorData);
		invalidData.setPaymentType(transactionType);
		invalidData.setErrorDescription(msgService.getMessage("en_US", errorCode));
		return invalidData;
	}
	
	protected InvalidFileDataVO createInvalidFileDataVO(String transactionType,String errorData, 
			int errorCode, String refNo) {
		InvalidFileDataVO invalidData = new InvalidFileDataVO();
		invalidData.setFileID(detailsVO.getFileId());
		invalidData.setErrorMessage(String.valueOf(errorCode));
		invalidData.setErrorData(errorData);
		invalidData.setPaymentType(transactionType);
		invalidData.setErrorDescription(msgService.getMessage("en_US", errorCode));
		invalidData.setRefNo(refNo);
		return invalidData;
	}
	
	protected void addToErrorDataList (String transactionType , String errorData, int errorCode) {
		InvalidFileDataVO invalidData = createInvalidFileDataVO(transactionType, errorData, errorCode);
		
		errorDataList.add(invalidData);
		
	}
	
	
	protected void addToErrorDataList (String transactionType , String errorData, int errorCode, EippTransactionVO eippTransactionVO) {
		InvalidFileDataVO invalidData = createInvalidFileDataVO(transactionType, errorData, errorCode,eippTransactionVO.getRefNo());
		
		errorDataList.add(invalidData);
		
		eippTransactionVO.addToInvalidDataList(invalidData);
	}
	
	/**
	 * @return the dataList
	 */
	public List<T> getDataList() {
		return dataList;
	}
	
	public List<InvalidFileDataVO> getErrorDataList() {
		return errorDataList;
	}
	
	/**
	 * @return the validInvalidList
	 */
	public List<T> getValidInvalidList() {
		return validInvalidList;
	}

	/**
	 * @param invoiceUploadDao the invoiceUploadDao to set
	 */
	public void setInvoiceUploadDao(IInvoiceUploadDAO invoiceUploadDao) {
		this.invoiceUploadDao = invoiceUploadDao;
	}

	/**
	 * @param msgService the msgService to set
	 */
	public void setMsgService(ILocaleMessageLoaderService msgService) {
		this.msgService = msgService;
	}

	/**
	 * @param detailsVO the detailsVO to set
	 */
	public void setDetailsVO(FileDetailsVO detailsVO) {
		this.detailsVO = detailsVO;
	}

	/**
	 * @param selectedData the selectedData to set
	 */
	protected void setSelectedData(T selectedData) {
		this.selectedData = selectedData;
	}

	protected boolean getBuyerId(EippTransactionVO dataVO,String modelType) {
		boolean isInvalid = false;
		String buyerId = null;
		String buyerOrgId=dataVO.getBuyerOrgId();
		String sellerOrgId = dataVO.getSupplierOrgId();
		String buyerERPId = dataVO.getBuyerErpId();
		String billType = dataVO.getBillType();
		int errorCode=0;
		try {

			if (!isNull(buyerERPId)) {
					List<String> buyerIdList = null;
					if (modelType.equals(BNPConstants.MODEL_TYPE_BCM)) {
						 buyerIdList = eippInvcUploadDAO.getCustomerOrgId(billType, buyerERPId);
						
						try {
							buyerId = getCustomerOrgId(buyerIdList, buyerOrgId);
						} catch (BNPApplicationException e) {
							errorCode = e.getErrorCode();
							addToErrorDataList(dataVO.getTransactionType(), dataVO.toDataString(),errorCode, dataVO);
							isInvalid = true;
							errorCode = 0;
						}
						
						if(isNull(buyerId) && errorCode == 0) {
							errorCode=ErrorConstants.INVALID_BUYER_ORG_FOR_ERP_BILL;
							addToErrorDataList(dataVO.getTransactionType(), dataVO.toDataString(),errorCode, dataVO);
							isInvalid = true;
							errorCode = 0;
						}
						
						if (!isNull(buyerOrgId) && !isNull(buyerId) && !buyerOrgId.equals(buyerId)) {
							errorCode=ErrorConstants.CUSTOMER_BUYER_ORG_MISMATCH;
										
						}
					} else {
						buyerIdList = eippInvcUploadDAO.getCounterPartyOrgId(sellerOrgId, billType, buyerERPId);
						
						try {
							buyerId = getCounterPartyOrgId(buyerIdList, buyerOrgId);
						} catch (BNPApplicationException e) {
							errorCode = e.getErrorCode();
							addToErrorDataList(dataVO.getTransactionType(), dataVO.toDataString(),errorCode, dataVO);
							isInvalid = true;
							errorCode = 0;
						}
						
						if(isNull(buyerId) && errorCode == 0) {
							errorCode=ErrorConstants.INVALID_BUY_ORG_ID_FOR_SUPORG_BILL_ERP;
							addToErrorDataList(dataVO.getTransactionType(), dataVO.toDataString(),errorCode, dataVO);
							isInvalid = true;
							errorCode = 0;
						}
						
						if (!isNull(buyerOrgId) && !isNull(buyerId) && !buyerOrgId.equals(buyerId)) {
							errorCode=ErrorConstants.COUNTER_PARTY_BUYER_ORG_MISMATCH;
						}
					}
			}
			
			if (errorCode>0) {
				addToErrorDataList(dataVO.getTransactionType(), dataVO.toDataString(),errorCode, dataVO);
				isInvalid = true;
			} else if(!isNull(buyerId)) {
				dataVO.setBuyerOrgId(buyerId);
			}

		} catch (BNPApplicationException e) {
			addToErrorDataList(dataVO.getTransactionType(), 
					dataVO.toDataString(), e.getErrorCode(), dataVO);
			isInvalid = true;

		}
		return isInvalid;
	}
	
	protected boolean isNull(String userInput){
		if(userInput !=null && userInput.trim().length()>0){
			return false;	
		}else{
			return true;
		}
	}
	
	protected boolean isIssueDateFutureDate(Date issueDate,TimeZone timeZone) {
		Calendar sourceCalendar = Calendar.getInstance();
		sourceCalendar.setTime(issueDate);
		sourceCalendar.set(Calendar.HOUR_OF_DAY, 0);
		sourceCalendar.set(Calendar.MINUTE, 0);
		sourceCalendar.set(Calendar.SECOND, 0);
		sourceCalendar.set(Calendar.MILLISECOND, 0);
		Calendar currCalendar = Calendar.getInstance();
		currCalendar.setTimeZone(timeZone);
		currCalendar.setTime(new Date(System.currentTimeMillis()));
		currCalendar.set(Calendar.HOUR_OF_DAY, 0);
		currCalendar.set(Calendar.MINUTE, 0);
		currCalendar.set(Calendar.SECOND, 0);
		currCalendar.set(Calendar.MILLISECOND, 0);

		if (sourceCalendar.after(currCalendar)) {
			return true;
		} else {
			return false;
		}
	}
	
	protected boolean isSourceDateLesser(Date source, Date destination) {
		Calendar sourceCalendar = Calendar.getInstance();
		sourceCalendar.setTime(source);
		sourceCalendar.set(Calendar.HOUR_OF_DAY, 0);
		sourceCalendar.set(Calendar.MINUTE, 0);
		sourceCalendar.set(Calendar.SECOND, 0);
		sourceCalendar.set(Calendar.MILLISECOND, 0);

		Calendar destCalendar = Calendar.getInstance();
		destCalendar.setTime(destination);
		destCalendar.set(Calendar.HOUR_OF_DAY, 0);
		destCalendar.set(Calendar.MINUTE, 0);
		destCalendar.set(Calendar.SECOND, 0);
		destCalendar.set(Calendar.MILLISECOND, 0);

		return sourceCalendar.getTime().before(destCalendar.getTime());

	}

	/**
	 * @return the eippInvcUploadDAO
	 */
	public IEippInvcUploadDAO getEippInvcUploadDAO() {
		return eippInvcUploadDAO;
	}

	/**
	 * @param eippInvcUploadDAO the eippInvcUploadDAO to set
	 */
	public void setEippInvcUploadDAO(IEippInvcUploadDAO eippInvcUploadDAO) {
		this.eippInvcUploadDAO = eippInvcUploadDAO;
	}
	
	/**
	 * Validates whether bill through market place is enabled for the bill type 
	 * @param billType
	 * @param marketPlaceOrgId
	 * @return
	 * @throws BNPApplicationException 
	 */
	protected boolean isBillThroughMarketPlace(String billType, String marketPlaceOrgId) throws BNPApplicationException {
		return eippInvcUploadService.isBillThroughMarketPlace(billType, marketPlaceOrgId);
	}
	
	/**
	 * This method checks whether the customer organization is linked to this market place org id based on the Model type
	 * @param eippTransactionVO
	 * 
	 * @throws BNPApplicationException 
	 */
	protected boolean isCustomerOrgLinkedToMarketPlace(EippTransactionVO eippTransactionVO) throws BNPApplicationException {
		boolean isNotLinked = false;
		int errorCode=0;
		/*
		 * Method Call changed to check if the MP is linked to Buyer/Supplier for the bill Type
		 */
		if (detailsVO.getModelType().equals(BNPConstants.MODEL_TYPE_SCM)) {
			if(!eippInvcUploadService.isBuyerSellerLinkedToMarketPlace(eippTransactionVO.getSupplierOrgId(), eippTransactionVO.getBuyerOrgId(),
					eippTransactionVO.getBillType(),eippTransactionVO.getMarketPlaceOrgId())){
				errorCode = ErrorConstants.BUYER_NOT_LINKED_TO_MARKET_PLACE;
				isNotLinked = true;
			}

		} else {
			if(!eippInvcUploadService.isBuyerSellerLinkedToMarketPlace(eippTransactionVO.getBuyerOrgId(),eippTransactionVO.getSupplierOrgId(),
					eippTransactionVO.getBillType(),eippTransactionVO.getMarketPlaceOrgId())){
				errorCode = ErrorConstants.SELLER_NOT_LINKED_TO_MARKET_PLACE;
				isNotLinked = true;
			}
		}
		if (isNotLinked) {
			addToErrorDataList(eippTransactionVO.getTransactionType(), 
					eippTransactionVO.toDataString(), errorCode, eippTransactionVO);
		}
		return isNotLinked;
	}
	
	/**
	 * This API validates whether all the Invoice/Credit note has the same Buyer org for BCM & same Supplier Org for SCM
	 * @param dataList
	 * @param eippTransactionVO
	 * @throws BNPApplicationException 
	 */
	protected boolean checkAllRecordHasSameCustomer(List<T> dataList, EippTransactionVO eippTransactionVO) throws BNPApplicationException {
		boolean isInvalid = false;
		EippTransactionVO fstRecord = (EippTransactionVO) dataList.get(0);

		isInvalid = isCustomerOrgLinkedToMarketPlace(fstRecord);
		
	/*	if (isInvalid && detailsVO.getModelType().equals(BNPConstants.MODEL_TYPE_SCM)) {
			if(fstRecord.getSupplierOrgId() != null && !fstRecord.getSupplierOrgId().equals(eippTransactionVO.getSupplierOrgId())){
				addToErrorDataList(eippTransactionVO.getTransactionType(), 
						eippTransactionVO.toDataString(), ErrorConstants.ALL_RECORD_BUYER_IS_NOT_SAME, eippTransactionVO);
				isInvalid = true;
			}

		} else if (isInvalid && detailsVO.getModelType().equals(BNPConstants.MODEL_TYPE_BCM)){
			if(fstRecord.getBuyerOrgId() != null && !fstRecord.getBuyerOrgId().equals(eippTransactionVO.getBuyerOrgId())){
				addToErrorDataList(eippTransactionVO.getTransactionType(), 
						eippTransactionVO.toDataString(), ErrorConstants.ALL_RECORD_SELLER_IS_NOT_SAME, eippTransactionVO);
				isInvalid = true;
			}
		}*/
		return isInvalid;
	}
	
	/**
	 * Validate line item amt.
	 *
	 * @param lineItemVO the line item vo
	 * @param allocType the alloc type
	 * @return the int
	 */

	private int validateLineItemAmt(EippInvCntLineItemVO lineItemVO,String allocType , int fracDigits) {
		LOGGER.debug(" Method validateLineItemAmt Entered" );
		int errCode=0;
		BigDecimal taxRate=lineItemVO.getTaxRate();
		BigDecimal taxAmt=lineItemVO.getTaxAmount();
		BigDecimal itemtotPrice=lineItemVO.getItemTotalPrice();
		//FO 8.0 Sonar Fix
		//BigDecimal itemQty=lineItemVO.getItemQty();
		//BigDecimal itemUnitPrice=lineItemVO.getItemUnitPrice();
		lineItemVO.setItemSubTotal(getBigDecimalValue(lineItemVO.getItemQty()).multiply(getBigDecimalValue(lineItemVO.getItemUnitPrice())).setScale(3));
		boolean isFromFile = false;
		boolean taxAmtComputed = false;
		if(taxRate!=null ){
			isFromFile = true;
		}
		//FO 7.0 Fortify Issue Fix
		/*LOGGER.debug(" Method validateLineItemAmt ::::::::::" + " Tax Rate : " + taxRate + " TaxAmt :" 
				+ taxAmt + " ItemTotPrice :" + itemtotPrice + " ItemQuantity :" + itemQty + " ItemUnitPrice : " 
				+ itemUnitPrice + " subtotal :" + lineItemVO.getItemSubTotal()) ;*/
		if(allocType!=null && allocType.equalsIgnoreCase(BNPConstants.DEPT_ALLOC_TYPE_LINEITEM)){
			if(itemtotPrice!=null && !BigDecimal.ZERO.equals(itemtotPrice) && !itemtotPrice.setScale(3).equals(lineItemVO.getItemSubTotal().setScale(3))){ //R5.0 - Sonar Fix - Feb21
				errCode = ErrorConstants.EIPP_LINEITEM_SUBTOT_MISMATCH;
			}
			// If Tax Rate is null/taxamt exits and total price is not null
			if(taxRate==null && taxAmt!=null && !BigDecimal.ZERO.equals(taxAmt)&& itemtotPrice!=null&& !BigDecimal.ZERO.equals(itemtotPrice)){
				lineItemVO.setTaxRate(taxAmt.divide(itemtotPrice,6,RoundingMode.HALF_UP));
				//taxRate = lineItemVO.getTaxRate();
			}// if tax rate exits/tax amt is null and totalprice is available
			if(taxRate!=null && taxAmt==null && itemtotPrice!=null){
				lineItemVO.setTaxAmount(itemtotPrice.multiply(taxRate).setScale(3));
				taxAmt = lineItemVO.getTaxAmount();
				taxAmtComputed = true;
			}
			// if tax rate / taxmt is available and tax amt = item price*tax rt
			if(isFromFile && taxAmtComputed && taxRate!=null && taxAmt!=null && !taxAmt.setScale(3).equals(itemtotPrice.multiply(taxRate).setScale(3))){
				errCode = ErrorConstants.LINEITEM_TAXAMT_VALIDATN;
			}
		}else if (allocType!=null && allocType.equalsIgnoreCase(BNPConstants.DEPT_ALLOC_TYPE_INVOICE)){
			lineItemVO.setItemGrossAmt(getBigDecimalValue(lineItemVO.getItemSubTotal()).add(getBigDecimalValue(lineItemVO.getTaxAmount())));
		}
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug(" Method validateLineItemAmt Exit" + " Value of Err Code" + errCode);
		return errCode;
	}
}
