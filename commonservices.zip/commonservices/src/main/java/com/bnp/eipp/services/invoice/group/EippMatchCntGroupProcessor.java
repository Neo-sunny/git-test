/** ************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   
 * 
 * Purpose:      EippMatchCntGroupProcessor.java
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 12 Oct 2012						Merdith 														  		Method Parameter changed for validating line item
 ***************************************************************************************************************************************************/
package com.bnp.eipp.services.invoice.group;
import java.util.ArrayList;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.invoice.vo.AddressVO;
import com.bnp.eipp.services.invoice.vo.EippCreditNoteVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.vo.TaxDtlsVO;
import com.bnp.eipp.services.matching.document.bindingvo.DocumentIdentification25;
import com.bnp.eipp.services.matching.document.bindingvo.FinancialCreditNoteV01;
import com.bnp.eipp.services.matching.document.bindingvo.LineItem10;
import com.bnp.eipp.services.matching.document.bindingvo.PostalAddress6;
import com.bnp.eipp.services.matching.document.bindingvo.SettlementTax1;
import com.bnp.eipp.services.matching.document.bindingvo.TradeDelivery1;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.StatusConstants;

@Component
@Scope ("prototype")
public class EippMatchCntGroupProcessor<T> extends EippGroupProcessor<EippCreditNoteVO> {

	public EippMatchCntGroupProcessor(){
		super();
	}

	private List<FinancialCreditNoteV01> objectList;
	
	/**
	 * @return the objectList
	 */
	public List<FinancialCreditNoteV01> getObjectList() {
		return objectList;
	}

	/**
	 * @param objectList the objectList to set
	 */
	public void setObjectList(List<FinancialCreditNoteV01> objectList) {
		this.objectList = objectList;
	}
	
	private void populateMappingFiles() {
		mappingFiles = new ArrayList<String>();
		mappingFiles.add("mapper/MatchingCntMapper.xml");
		mappingFiles.add("mapper/MatchingLineItemMapper.xml");
		mappingFiles.add("mapper/MatchingAddrMapper.xml"); 
		mappingFiles.add("mapper/MatchingTaxMapper.xml");
		beanMapper = new DozerBeanMapper(mappingFiles);
	}

	@Override
	public void processAndValidateData() throws BNPApplicationException {
		
		populateMappingFiles();
		List<EippCreditNoteVO> cntList = new ArrayList<EippCreditNoteVO>();
		if(objectList !=null)
		{
		for (FinancialCreditNoteV01 creditNoteObj : objectList) {
			
			EippCreditNoteVO eippCreditNoteVO = beanMapper.map(
					creditNoteObj, EippCreditNoteVO.class);
			
			populateInvcDetails(creditNoteObj.getTradSttlm().getInvcRefdDoc(), eippCreditNoteVO);
			
			List<SettlementTax1> taxLst = (List<SettlementTax1>) creditNoteObj.getTradSttlm().getTax();
			for(SettlementTax1 stlmtTaxObj : taxLst){
				TaxDtlsVO taxDtlsVO = beanMapper.map(stlmtTaxObj, TaxDtlsVO.class);
				eippCreditNoteVO.getTaxDtls().add(taxDtlsVO);
			}
			
			if (creditNoteObj.getTradDlvry() != null) {
				populateAddressDetails(creditNoteObj.getTradDlvry(), eippCreditNoteVO);
			}
			
//			for (AdditionalInformation6 customField : creditNoteObj.getCrNtHdr().getInclNote()) {
//				EippCustFieldsVO custFieldVO = beanMapper.map(
//						customField, EippCustFieldsVO.class);
//				eippCreditNoteVO.getCustFields().add(custFieldVO);
//			}
			
			for (LineItem10 lineItem : creditNoteObj.getLineItm()) {
				
				EippInvCntLineItemVO eippInvCntLineItemVO = beanMapper.map(
										lineItem, EippInvCntLineItemVO.class);
				
//				for (AdditionalInformation1 customLtmField : lineItem.getInclNote()) {
//					EippCustFieldsVO custItmFieldVO = beanMapper.map(
//							customLtmField, EippCustFieldsVO.class);
//					eippInvCntLineItemVO.getCustFields().add(custItmFieldVO);
//				}
				eippCreditNoteVO.getLineItemList().add(eippInvCntLineItemVO);
			}
			eippCreditNoteVO.setMatchStatus(StatusConstants.PENDING_MATCH_STATUS);
			eippCreditNoteVO.setIsManual("N");
			eippCreditNoteVO.setProcessThruMatchRecon(BNPConstants.YES);
			cntList.add(eippCreditNoteVO);
		}
		}
		validateCreditNotes(cntList);
		
	}
	
	private void populateInvcDetails(List<DocumentIdentification25> invcDocs,EippCreditNoteVO eippCreditNoteVO) {
		
		for (DocumentIdentification25 documentIdentification25 : invcDocs) {
			
			if (documentIdentification25.getRefType().equals("ORIGINAL")) {
				eippCreditNoteVO.setOrgInvBillType(documentIdentification25.getBillType());
				eippCreditNoteVO.setOrgInvRefNo(documentIdentification25.getId());
				eippCreditNoteVO.setOrgInvRefDate(documentIdentification25.getDtOfIsse().getTime());
			} else if (documentIdentification25.getRefType().equals("LINKED")) {
				eippCreditNoteVO.setLinkedInvBillType(documentIdentification25.getBillType());
				eippCreditNoteVO.setLinkedInvRefNo(documentIdentification25.getId());
				eippCreditNoteVO.setLinkedInvRefDate(documentIdentification25.getDtOfIsse().getTime());
			}
		}
	}
	
	private void populateAddressDetails(TradeDelivery1 tradeDelivery,EippCreditNoteVO eippCreditNoteVO) {
		
		if (tradeDelivery.getBillTo() != null && tradeDelivery.getBillTo().getPstlAdr() != null) {
			eippCreditNoteVO.setBillToAddr(getAddress(tradeDelivery.getBillTo().getPstlAdr()));
		}
		if (tradeDelivery.getShipTo() != null && tradeDelivery.getShipTo().getPstlAdr() != null) {
			eippCreditNoteVO.setShipToAddr(getAddress(tradeDelivery.getShipTo().getPstlAdr()));
		}
				
	}
	
	/**
	 * Validate credit notes.
	 *
	 * @param cntList the cnt list
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void validateCreditNotes(List<EippCreditNoteVO> cntList) throws BNPApplicationException {
		List<EippCreditNoteVO> transList = new ArrayList<EippCreditNoteVO>();
		
		for (EippCreditNoteVO eippCreditNoteVO : cntList) {
			boolean isInvalid = false;
			
			isInvalid = validateOrgData(eippCreditNoteVO);
			
			if (isInvalid) {
				validInvalidList.add(eippCreditNoteVO);
				continue;
			}
			
			if(detailsVO.getSenderOrgType().equals(BNPConstants.MARKET_PLACE)){
				isInvalid = checkAllRecordHasSameCustomer(cntList,eippCreditNoteVO) || isInvalid ;
			}
			
			isInvalid = validateLineItemsData(eippCreditNoteVO,null);// // Added parameter for validating line item amounts
			
			if(detailsVO.getInstrumentType() != null && 
					detailsVO.getInstrumentType().trim().equalsIgnoreCase(BNPConstants.MATCH_EIPP_CN_INS_TYPE)){
				isInvalid = validateLinkedInvoiceDets(eippCreditNoteVO) || isInvalid;
				if (isIssueDateFutureDate(eippCreditNoteVO.getIssueDate(), detailsVO.getTimeZoneTZ())) {
					addToErrorDataList(eippCreditNoteVO.getTransactionType(), eippCreditNoteVO.toDataString(), 
							ErrorConstants.ISSUE_DATE_SHOULD_NOT_FUTURE, eippCreditNoteVO);
					isInvalid = true;
				}
			}
			
			if (eippCreditNoteVO.getEffectiveDate() == null) {
				eippCreditNoteVO.setEffectiveDate(eippCreditNoteVO.getIssueDate());
			}
			if (eippCreditNoteVO.getRefDate() == null) {
				eippCreditNoteVO.setRefDate(eippCreditNoteVO.getIssueDate());
			}
			if(detailsVO.getInstrumentType() != null && 
					detailsVO.getInstrumentType().trim().equalsIgnoreCase(BNPConstants.MATCH_EIPP_CN_INS_TYPE)){
				isInvalid = validateCreditNoteAmounts(eippCreditNoteVO) || isInvalid;
			}
			isInvalid = validateUniqueReference(eippCreditNoteVO, transList) || isInvalid;
			if(detailsVO.getInstrumentType() != null && 
					detailsVO.getInstrumentType().trim().equalsIgnoreCase(BNPConstants.MATCH_EIPP_CN_INS_TYPE)){
			isInvalid = validateLinkedInvCount(eippCreditNoteVO) || isInvalid;
			}
			
			if (!isInvalid) {
				eippCreditNoteVO.setFractionalDigits(invoiceUploadService.getCurrencyDecimals
						(eippCreditNoteVO.getCcyCode()));
				eippCreditNoteVO.setRecordStatus("A");
				dataList.add(eippCreditNoteVO);
				validInvalidList.add(eippCreditNoteVO);
			} else {
				validInvalidList.add(eippCreditNoteVO);
			}
			
		}
	}
	
	/*
	 *This API checks for the availability of more than one linked invoice for a given credit note 
	 */
	private boolean validateLinkedInvCount(EippCreditNoteVO creditNoteVO) {
		boolean isInvalid = false;
		
		try {
			eippInvcUploadDAO.checkInvCountForCreditNote(creditNoteVO);
		} catch (BNPApplicationException e) {
			isInvalid = true;
			addToErrorDataList(creditNoteVO.getTransactionType(), creditNoteVO.toDataString(), 
					e.getErrorCode(), creditNoteVO);
		}
		return isInvalid;
	}
	
	private boolean validateUniqueReference(EippCreditNoteVO eippCreditNoteVO,List<EippCreditNoteVO> transList)
	throws BNPApplicationException {
		boolean isInvalid = false;
		if (eippInvcUploadDAO.isUniqueCheckEnabled(getCustomerOrgId(eippCreditNoteVO), 
				getCntpOrgId(eippCreditNoteVO), eippCreditNoteVO.getBillType())) {
			isInvalid = eippInvcUploadDAO.isCreditNoteExists(eippCreditNoteVO) ||
						checkUniqueReference(eippCreditNoteVO, transList);
			if (isInvalid) {
				addToErrorDataList(eippCreditNoteVO.getTransactionType(), eippCreditNoteVO.toDataString(), 
						ErrorConstants.CREDITNOTE_NOT_UNIQUE, eippCreditNoteVO);
			} else {
				transList.add(eippCreditNoteVO);
			}
		}
		return isInvalid;
	}
	
	private boolean checkUniqueReference(EippCreditNoteVO eippCreditNoteVO,List<EippCreditNoteVO> transList) {
		boolean isInvalid = false;
		for (EippCreditNoteVO transactionVO : transList) {
			if (eippCreditNoteVO.getCntRefNo().equals(transactionVO.getCntRefNo()) &&
				isSameDates(eippCreditNoteVO.getRefDate(), transactionVO.getRefDate()) &&
				eippCreditNoteVO.getSupplierOrgId().equals(transactionVO.getSupplierOrgId())) {
				isInvalid = true;
				break;
			}
		}
		
		return isInvalid;
	}
	
	private boolean validateCreditNoteAmounts(EippCreditNoteVO eippCreditNoteVO) {
		boolean isInvalid = false;
		
		if (eippCreditNoteVO.getCntOrgAmt().compareTo(getBigDecimalValue
				(eippCreditNoteVO.getCntUtilAmt())) < 0) {
			addToErrorDataList(eippCreditNoteVO.getTransactionType(), eippCreditNoteVO.toDataString(), 
					ErrorConstants.ORG_AMT_LESSER_THAN_UTIL_AMT, eippCreditNoteVO);
			isInvalid = true;
		}
		
		if (eippCreditNoteVO.getSubTotAmt() != null && eippCreditNoteVO.getTaxAmount() != null && (eippCreditNoteVO.getSubTotAmt().compareTo
				(eippCreditNoteVO.getCntOrgAmt().subtract(eippCreditNoteVO.getTaxAmount())) != 0 ||
				eippCreditNoteVO.getSubTotAmt().compareTo(eippCreditNoteVO.getCntOrgAmt()) > 0)) {
			addToErrorDataList(eippCreditNoteVO.getTransactionType(), eippCreditNoteVO.toDataString(), 
					ErrorConstants.EIPP_CNT_TOT_AMT_MISMATCH, eippCreditNoteVO);
			isInvalid = true;
		}else if(eippCreditNoteVO.getSubTotAmt() == null && eippCreditNoteVO.getTaxAmount() == null) {
			eippCreditNoteVO.setSubTotAmt(eippCreditNoteVO.getCntOrgAmt());
			eippCreditNoteVO.setSubTotAmtCcy(eippCreditNoteVO.getCcyCode());
		}else if(eippCreditNoteVO.getTaxAmount() != null && eippCreditNoteVO.getSubTotAmt() == null) {
			eippCreditNoteVO.setSubTotAmt(eippCreditNoteVO.getCntOrgAmt().subtract(eippCreditNoteVO.getTaxAmount()));
			eippCreditNoteVO.setSubTotAmtCcy(eippCreditNoteVO.getCcyCode());
		}else if(eippCreditNoteVO.getSubTotAmt() != null && eippCreditNoteVO.getTaxAmount() == null &&
				eippCreditNoteVO.getSubTotAmt().compareTo(eippCreditNoteVO.getCntOrgAmt()) <=0) {
			eippCreditNoteVO.setTaxAmount(eippCreditNoteVO.getCntOrgAmt().subtract(eippCreditNoteVO.getSubTotAmt()));
			eippCreditNoteVO.setTaxAmtCcy(eippCreditNoteVO.getCcyCode());
		}
		
		if ((eippCreditNoteVO.getSubTotAmtCcy() !=null && !eippCreditNoteVO.getCcyCode().equals(eippCreditNoteVO.getSubTotAmtCcy())) || 
				(eippCreditNoteVO.getTaxAmtCcy() != null && !eippCreditNoteVO.getCcyCode().equals(eippCreditNoteVO.getTaxAmtCcy()))) {
			addToErrorDataList(eippCreditNoteVO.getTransactionType(), eippCreditNoteVO.toDataString(), 
					ErrorConstants.EIPP_CNT_TOT_AMT_CCY_MISMATCH, eippCreditNoteVO);
			isInvalid = true;
		}
		
		if (eippCreditNoteVO.getCntUtilAmtCcy() != null && 
				!eippCreditNoteVO.getCcyCode().equals(eippCreditNoteVO.getCntUtilAmtCcy())) {
			
			addToErrorDataList(eippCreditNoteVO.getTransactionType(), eippCreditNoteVO.toDataString(), 
					ErrorConstants.ORG_AMT_CCY_UTIL_AMT_CCY_MISMATCH, eippCreditNoteVO);
			isInvalid = true;
		}
		eippCreditNoteVO.setCntRemAmt(eippCreditNoteVO.getCntOrgAmt().subtract
				(getBigDecimalValue(eippCreditNoteVO.getCntUtilAmt())));
		return isInvalid;
	}
	
	private boolean validateLinkedInvoiceDets(EippCreditNoteVO eippCreditNoteVO) throws BNPApplicationException {
		boolean isInvalid = false;
		boolean canConvertToUnlinked = eippInvcUploadDAO.canConvertToUnlinked(eippCreditNoteVO.getSupplierOrgId());
		
		if (!isNull(eippCreditNoteVO.getLinkedInvRefNo()) && !eippInvcUploadDAO.isLinkedInvoiceExists(eippCreditNoteVO)
				&& !canConvertToUnlinked) {
			addToErrorDataList(eippCreditNoteVO.getTransactionType(), eippCreditNoteVO.toDataString(), 
					ErrorConstants.LINKED_INVOICE_UNAVAILABLE, eippCreditNoteVO);
			isInvalid = true;
		}
		return isInvalid;
	}

	private AddressVO getAddress(PostalAddress6 postalAddress) {
		AddressVO addressVO = beanMapper.map(postalAddress, AddressVO.class);
		if (postalAddress.getAdrTp() != null) {
			addressVO.setAddrType(postalAddress.getAdrTp().value());
		}
		if (postalAddress.getAdrLine() != null && !postalAddress.getAdrLine().isEmpty()) {
			populateAddrLines(postalAddress.getAdrLine(), addressVO);
		}
		return addressVO;
	}
	
	private void populateAddrLines(List<String> addrLines,AddressVO addressVO) {
		if (addrLines.size() > 0 && !isNull(addrLines.get(0))) {
			addressVO.setAddress1(addrLines.get(0));
		}
		if (addrLines.size() > 1 && !isNull(addrLines.get(1))) {
			addressVO.setAddress2(addrLines.get(1));
		}
		if (addrLines.size() > 2 && !isNull(addrLines.get(2))) {
			addressVO.setAddress3(addrLines.get(2));
		}
	}
}
