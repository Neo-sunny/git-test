/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Jan 18, 201210:32:41 AM
 * 
 * Purpose:      Implementation class for Bill Type Definition DAO Layer
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Jan 18, 201210:32:41 AM        Oracle Financial Services Software Ltd                  Initial Version
 * 21 Mar 2012					  Oracle Financial Services Software Ltd				 Release 2.1 I1				ST fix 5615, 5652, 5603, 5452, 5636, 5593
 * 18 Jul 2012                    Reena 												 Release 3.0	            Changes for EIPP-Phase II  
* 01 Jul 2014						Jayadivya S 																FO8.0 Improve User Experience 
 ************************************************************************************************************************************************************/

package com.bnp.eipp.services.dao.admin;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.vo.admin.BillTypeDefinitionVO;
import com.bnp.eipp.services.vo.admin.BillTypeShortCutsVO;
import com.bnp.scm.services.common.dao.AbstractCommonDaoImpl;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.vo.AbstractVO;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.ibatis.sqlmap.client.SqlMapExecutor;
import com.ibatis.sqlmap.engine.execution.BatchException;

@Component
@SuppressWarnings("unchecked")
public class BillTypeDefinitionDaoImpl extends AbstractCommonDaoImpl<BillTypeDefinitionVO> implements IBillTypeDefinitionDao {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(BillTypeDefinitionDaoImpl.class);

	private static final String NAME_SPACE = "BillTypeNS."; 

	/** The INSER t_ tran s_ record. */
	private static final String INSERT_TRANS_RECORD = "insertTransRecord";

	/** The INSER t_ his t_ tran s_ record. */
	private static final String INSERT_HIST_TRANS_RECORD = "insertIntoHistory";
	/** The INSER t_ ne w_ tran s_ record. */
	private static final String INSERT_NEW_TRANS_RECORD = "insertNewTransRecord";

	/** The UPDAT e_ statu s_ i n_ master. */
	private static final String UPDATE_STATUS_IN_MASTER = "updateStatusInMaster";

	/** The UPDAT e_ tran s_ record. */
	private static final String UPDATE_TRANS_RECORD = "updateTransRecord";

	/** The DELET e_ tran s_ record. */
	private static final String DELETE_TRANS_RECORD = "deleteTransRecord";

	/** The INSER t_ maste r_ record. */
	private static final String INSERT_MASTER_RECORD = "insertIntoMaster";

	/** The UPDAT e_ maste r_ record. */
	private static final String UPDATE_MASTER_RECORD = "updateMasterRecord";

	/** The INSER t_ his t_ record. */
	private static final String INSERT_HIST_RECORD = "insertIntoHistory";

	/** The Constant UPDATE_MASTER_RECORD_FOR_DELETE. */
	private static final String UPDATE_MASTER_RECORD_FOR_DELETE ="updateMasterRecordForDelete";

	/** The INSER t_ tran s_ chil d_ record. */
	private static final String INSERT_TRANS_CHILD_RECORD = "BillTypeNS.insertChildTrans";

	/** The INSER t_ his t_ chil d_ record. */
	private static final String INSERT_HIST_CHILD_RECORD = "BillTypeNS.insertChildHist";

	/** The INSER t_ maste r_ chil d_ record. */
	private static final String INSERT_MASTER_CHILD_RECORD = "BillTypeNS.insertChildMaster";

	/** The DELET e_ maste r_ chil d_ record. */
	private static final String DELETE_MASTER_CHILD_RECORD = "BillTypeNS.deleteChildMaster";

	/** The DELET e_ tran s_ chil d_ record. */
	private static final String DELETE_TRANS_CHILD_RECORD = "BillTypeNS.deleteChildTrans";

	/** The UPDAT e_ chil d_ statu s_ i n_ master. */
	private static final String UPDATE_CHILD_STATUS_IN_MASTER = "BillTypeNS.updateChildStatusInMaster";

	/** The UPDAT e_ chil d_ maste r_ recor d_ fo r_ delete. */
	private static final String UPDATE_CHILD_MASTER_RECORD_FOR_DELETE ="BillTypeNS.updateChildMasterRecordForDelete";

	/*QUERIES for MAKER CHECKER ENDS*/

	/** The Constant CHILD_PARAM1. */
	private static final String CHILD_PARAM1="CUST_ERP_ID";

	/** The Constant GET_LINK_PARAM_DETAILS. */
	private static final String GET_LINK_PARAM_DETAILS="getParamsForBillType";

	private static final String GET_DEF_DEPT_FOR_DISPUTE = "getDefDeptForDispute";
	
	private static final String GET_MRKTPLACE_ORG_LIST="getMarketPlaceOrganizations";
	
	private static final String DELETE_MASTER_RECORD_PERMNT = "BillTypeNS.deleteMasterRecordPermt";
	
	@Override
	public String getNameSpace() {
		return NAME_SPACE;
	}

	@Override
	public List<BillTypeDefinitionVO> getBillTypeDetails(
			BillTypeDefinitionVO searchVO) throws BNPApplicationException {
		try{
		List<BillTypeDefinitionVO> searchDatas=null;
		
		searchDatas=getSqlMapClientTemplate().queryForList("BillTypeNS.selectBillTypeSearchDetails",searchVO);
		return searchDatas;
	}
		catch (DataAccessException ex) {
			LOGGER.error("error in dao-selectBillTypeSearchDetails"+ ex.getMessage());
		   throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	} 

	
	@Override
	public List<NameValueVO> getOrganisationsListFromBilltype(NameValueVO inputVO) {
		return getSqlMapClientTemplate().queryForList("BillTypeNS.fetchOrgIdAndShortName",inputVO);
	}

	@Override
	public List<NameValueVO> getCustomerOrgListForMPOA(NameValueVO inputVO)throws BNPApplicationException {
		List<NameValueVO> custOrgList=null;
		try{
			custOrgList=getSqlMapClientTemplate().queryForList("BillTypeNS.fetchCustomerOrgForMPOA",inputVO);
		}
		catch(DataAccessException ex){
			LOGGER.error(ex.getMessage()); 
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		}
		return custOrgList;
	}
	
	@Override
	public BillTypeDefinitionVO getModifiedRecord(
			BillTypeDefinitionVO orgDiscount) throws BNPApplicationException {
		try{
		BillTypeDefinitionVO modData=null;
		//modData=(BillTypeDefinitionVO) getSqlMapClientTemplate().queryForObject("BillTypeNS.getModifiedRecord",orgDiscount);
		return modData;
		}catch (DataAccessException ex) {
			LOGGER.error("error in dao-selectBillTypeSearchDetails"+ ex.getMessage());
			   throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
	}

	@Override
	public NameValueVO getCustomerRoleName(String orgId)
			throws BNPApplicationException {
		return  (NameValueVO) getSqlMapClientTemplate().queryForObject("BillTypeNS.getCustOrgRoleType",orgId);
	}

	@Override
	public List<NameValueVO> getDeptListForBuyer(String orgId)
			throws BNPApplicationException {
		return getSqlMapClientTemplate().queryForList("BillTypeNS.fetchDeptListForBuyer",orgId);
	}

	@Override
	public List<NameValueVO> getDeptListForSupplier(String orgId)
			throws BNPApplicationException {
		return getSqlMapClientTemplate().queryForList("BillTypeNS.fetchDeptListForSupplier",orgId);
	}

	@Override
	public List<BillTypeShortCutsVO> getBillTypeLogoRecord(String orgId)
			throws BNPApplicationException {
		return   getSqlMapClientTemplate().queryForList("BillTypeNS.getBillTypeLogoRecord",orgId);
	}

	@Override
	public List<BillTypeShortCutsVO> getBillTypeStyleSheetRecord(String orgId)
			throws BNPApplicationException {
		return   getSqlMapClientTemplate().queryForList("BillTypeNS.getBillTypeStyleSheetRecord",orgId);
	}

	@Override
	public List<BillTypeShortCutsVO> getBrandingDetailsRecord(String orgId)
			throws BNPApplicationException {
		return   getSqlMapClientTemplate().queryForList("BillTypeNS.getBrandingDetailsRecord",orgId);
	}

	@Override
	public List<BillTypeShortCutsVO> getDisputeCodeRecord(String orgId)
			throws BNPApplicationException {
		return   getSqlMapClientTemplate().queryForList("BillTypeNS.getDisputeCodeRecord",orgId);
	}

	@Override
	public int chkRecordNotExistsAlready(BillTypeDefinitionVO searchVO)
			throws BNPApplicationException {
		Integer count=null;
		try {
			count = (Integer) getSqlMapClientTemplate().queryForObject("BillTypeNS.chkRecordExists", searchVO);
			
		} catch (DataAccessException ex) {
			LOGGER.error(ex.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
				
		}	
		return count;
	}

	@Override
	public int chkDependencyBeforDelete(BillTypeDefinitionVO searchVO)
			throws BNPApplicationException {
		Integer count=null;
		try {
			count = (Integer) getSqlMapClientTemplate().queryForObject("BillTypeNS.chkdeptRecordCount", searchVO);
			
		} catch (DataAccessException ex) {
			LOGGER.error(ex.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
				
		}	
		return count;
	}
	
	
/* Overridden methods for Maker Checker - Starts*/ 
	
	/* (non-Javadoc)
 * @see com.bnp.scm.services.common.dao.AbstractCommonDaoImpl#saveReModifiedRecord(com.bnp.scm.services.common.vo.AbstractVO)
 */
@Override
	public void saveReModifiedRecord(BillTypeDefinitionVO billTypeVO)
			throws BNPApplicationException {
		try {			
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(UPDATE_TRANS_RECORD), billTypeVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_HIST_TRANS_RECORD), billTypeVO);
			getSqlMapClientTemplate().delete(DELETE_TRANS_CHILD_RECORD, billTypeVO);
			
			insertChildTransAndHistRecords(billTypeVO);
			
		} catch (DataAccessException e) {
			LOGGER.error("Error while saving modified record " + e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.dao.AbstractCommonDaoImpl#saveNewRecord(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void saveNewRecord(BillTypeDefinitionVO billTypeVO)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_NEW_TRANS_RECORD), billTypeVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_HIST_TRANS_RECORD), billTypeVO);
			
			insertChildTransAndHistRecords(billTypeVO);
			
		} catch (DataAccessException e) {
			LOGGER.error("Error while saving new record " + e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.dao.AbstractCommonDaoImpl#saveModifiedRecord(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void saveModifiedRecord(BillTypeDefinitionVO billTypeVO)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_STATUS_IN_MASTER), billTypeVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_TRANS_RECORD), billTypeVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_HIST_TRANS_RECORD), billTypeVO);
			updateChildStatusInMaster(billTypeVO);
			
			insertChildTransAndHistRecords(billTypeVO);
			
		} catch (DataAccessException e) {
			LOGGER.error("Error while saving modified record " + e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.dao.AbstractCommonDaoImpl#approveNewRecord(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void approveNewRecord(BillTypeDefinitionVO billTypeVO)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_MASTER_RECORD), billTypeVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_HIST_RECORD), billTypeVO);
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(DELETE_TRANS_RECORD), billTypeVO);
			insertChildMaster(billTypeVO);
			insertChildHistoryDeleteTrans(billTypeVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error while approving new record " + e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.dao.AbstractCommonDaoImpl#approveModifiedOrDeletedRecord(com.bnp.scm.services.common.vo.AbstractVO, boolean)
	 */
	@Override
	public void approveModifiedOrDeletedRecord(BillTypeDefinitionVO billTypeVO,
			boolean isUpdateAllMasterCols) throws BNPApplicationException {
		try {
		if(isUpdateAllMasterCols){
				getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(UPDATE_MASTER_RECORD), billTypeVO);
				deleteMasterChild(billTypeVO);
				insertChildMaster(billTypeVO);
			}else{
				getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_MASTER_RECORD_FOR_DELETE), billTypeVO);
				getSqlMapClientTemplate().update(UPDATE_CHILD_MASTER_RECORD_FOR_DELETE,billTypeVO);
				getSqlMapClientTemplate().delete(DELETE_MASTER_RECORD_PERMNT, billTypeVO); //FO8.0 Improve User Experience
			}
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_HIST_RECORD), billTypeVO);
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(DELETE_TRANS_RECORD), billTypeVO);
			insertChildHistoryDeleteTrans(billTypeVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error while approving modified or deleted record " + e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.dao.AbstractCommonDaoImpl#undoNewRecord(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void undoNewRecord(BillTypeDefinitionVO billTypeVO)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_HIST_RECORD), billTypeVO);
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(DELETE_TRANS_RECORD), billTypeVO);
			insertChildHistoryDeleteTrans(billTypeVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error while performing undo on new record " + e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.dao.AbstractCommonDaoImpl#undoModifiedRecord(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void undoModifiedRecord(BillTypeDefinitionVO billTypeVO)
			throws BNPApplicationException {
		undoOrDeleteRecords(billTypeVO);
	}
	
	/**
	 * Undo or delete records.
	 *
	 * @param abstractVO the abstract vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void undoOrDeleteRecords(AbstractVO abstractVO) throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_STATUS_IN_MASTER), abstractVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_HIST_RECORD), abstractVO);
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(DELETE_TRANS_RECORD), abstractVO);
			updateChildStatusInMaster(abstractVO);
			insertChildHistoryDeleteTrans(abstractVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error while doing undo or delete record " + e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.dao.AbstractCommonDaoImpl#deleteApprovedRecord(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void deleteApprovedRecord(BillTypeDefinitionVO billTypeVO) throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_STATUS_IN_MASTER), billTypeVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_TRANS_RECORD), billTypeVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_HIST_TRANS_RECORD), billTypeVO);
			updateChildStatusInMaster(billTypeVO);
			
			insertChildTransAndHistRecords(billTypeVO);
			
		} catch (DataAccessException e) {
			LOGGER.error("Error while deleting an approved record " + e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	
	/**
	 * Insert child trans and hist records.
	 *
	 * @param abstractVO the abstract vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void insertChildTransAndHistRecords(AbstractVO abstractVO) throws BNPApplicationException{
		BillTypeDefinitionVO tempVO1 = null;
		if(abstractVO!=null && abstractVO instanceof BillTypeDefinitionVO){
		tempVO1 = (BillTypeDefinitionVO) abstractVO;
		}
		final BillTypeDefinitionVO tempVO = tempVO1;
		
	
		try{
			 getSqlMapClientTemplate().execute(new SqlMapClientCallback<List<Object>>() {
						@Override
						public List<Object> doInSqlMapClient(SqlMapExecutor executor)
								throws SQLException {
							List<Object> list = null;
							try {
								executor.startBatch();
								if(tempVO.getListOfCusERP()!=null && !tempVO.getListOfCusERP().isEmpty()){
									for (String custErp : tempVO.getListOfCusERP()) {
										tempVO.setFieldName(CHILD_PARAM1);
										tempVO.setFieldValue(custErp);
										executor.insert(INSERT_TRANS_CHILD_RECORD, tempVO);
										
									}
								}
								
								list = executor.executeBatchDetailed();
								// R7.0 Fortify issues
//								if (list != null) {
//									LOGGER.debug("Batch Result Size" + list.size());
//								}

							} catch (BatchException e) {
								LOGGER.error("Excecuting batch update in updateSettlement Failed "+ e.getMessage());
								throw new SQLException();
							}
							return list;
						}
					});
			 getSqlMapClientTemplate().insert(INSERT_HIST_CHILD_RECORD, abstractVO);
		}catch(Exception e){
			
		}
	}
	
	/**
	 * Update child status in master.
	 *
	 * @param abstractVO the abstract vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void updateChildStatusInMaster(AbstractVO abstractVO) throws BNPApplicationException{
		getSqlMapClientTemplate().update(UPDATE_CHILD_STATUS_IN_MASTER, abstractVO);
	}
	
	/**
	 * Insert child master.
	 *
	 * @param abstractVO the abstract vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void insertChildMaster(AbstractVO abstractVO) throws BNPApplicationException{
		getSqlMapClientTemplate().insert(INSERT_MASTER_CHILD_RECORD, abstractVO);
	}
	
	/**
	 * Delete master child.
	 *
	 * @param abstractVO the abstract vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void deleteMasterChild(AbstractVO abstractVO) throws BNPApplicationException{
		getSqlMapClientTemplate().delete(DELETE_MASTER_CHILD_RECORD,abstractVO);
	}
	
	
	/**
	 * Insert child history delete trans.
	 *
	 * @param abstractVO the abstract vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void insertChildHistoryDeleteTrans(AbstractVO abstractVO) throws BNPApplicationException{
		getSqlMapClientTemplate().insert(INSERT_HIST_CHILD_RECORD, abstractVO);
		getSqlMapClientTemplate().delete(DELETE_TRANS_CHILD_RECORD,abstractVO);
	}
	
	/* Overridden methods for Maker Checker - Ends*/

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.admin.ILinkOrgForEippDAO#getChildDetails(com.bnp.eipp.services.vo.admin.LinkOrgForEippVO)
	 */
	@Override
	public List<String> getChildDetails(BillTypeDefinitionVO fields)throws BNPApplicationException {
		List<String> fieldValueList=null;
		try {
			fieldValueList=getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_LINK_PARAM_DETAILS), fields);
			
		} catch (DataAccessException e) {
			LOGGER.error("Error while deleting an approved record " + e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return fieldValueList;
	}

	@Override
	public long getDefaultDepartmentForDispute(String customerOrgId, String billType)
			throws BNPApplicationException {
		
		Map<String, Object> params = new HashMap<String, Object>();
		
		Long object = null;
		
		try {
			params.put("custOrgId", customerOrgId);
			params.put("billType", billType);
			object = (Long) getSqlMapClientTemplate().queryForObject(
					getQueryNameWithNameSpace(GET_DEF_DEPT_FOR_DISPUTE), params);
		} catch (DataAccessException e) {
			LOGGER.error("Error while getting default depart for dispute " + e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return object == null ? 0 : object;
	}

	@Override
	public List<NameValueVO> getMarketPlaceOrgList(String custOrgId)throws BNPApplicationException {
		List<NameValueVO> marketPlaceOrgList=null;
		try{			
			marketPlaceOrgList=getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_MRKTPLACE_ORG_LIST), custOrgId);
			
			
		} 
			catch (DataAccessException ex) {
				LOGGER.error("error in dao-getMarketPlaceOrgList"+ ex.getMessage());
			   throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
			return marketPlaceOrgList;
	}

	



}
