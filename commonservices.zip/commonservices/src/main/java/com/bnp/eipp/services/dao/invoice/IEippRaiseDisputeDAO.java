/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  28 Aug 2012	   
 * 
 * Purpose:     Raise Dispute Dao Interface
 * 
 * Change History: 
 * Date                                      	 Author                              Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 28 Aug 2012	       							Dinesh D                 		 Initial Version  
 *****************************************************************************************************************************************************************/


package com.bnp.eipp.services.dao.invoice;

import java.util.List;

import com.bnp.eipp.services.dao.filemgmt.IEippAbstractFileReleaseDAO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.vo.dispute.DisputeCustFieldsVO;
import com.bnp.eipp.services.vo.dispute.DisputeVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.BNPRuntimeException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;

public interface IEippRaiseDisputeDAO extends IEippAbstractFileReleaseDAO {

	List<DisputeVO> getRaiseDisputeList(long fileId);

	List<DisputeCustFieldsVO> getRaiseDisputeListForLI(long fileId);

	int isInvAvailableForRaiseDispute(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException;

	void updateRecordStatusInTrans(long fileId, String deleteRecord) throws BNPApplicationException;

	void insertRaiseDisputeList(List<DisputeVO> validObjectList,FileDetailsVO detailsVO)throws BNPRuntimeException;

	int isValidResolutionCode(DisputeVO disputeVO)throws BNPApplicationException;

	List<DisputeCustFieldsVO> getValidLineItemNoList(DisputeVO disputeVO)throws BNPApplicationException;

	boolean isValidDeptUser(DisputeVO disputeVO)throws BNPApplicationException;

	String getDisputeAllocType(DisputeVO disputeVO)throws BNPApplicationException;

	int getDisputeAllocLevel(DisputeVO disputeVO)throws BNPApplicationException;

}
