package com.bnp.eipp.services.matching.invoice.bindingvo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for AdditionalInformation1 complex type.
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AdditionalInformation1">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="InfTp" type="{}ExternalInformationType1Code"/>
 *         &lt;element name="InfVal" type="{}Max150Text"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AdditionalInformation1", propOrder = { "infTp", "infVal" })
public class AdditionalInformation1 {

	@XmlElement(name = "InfTp", required = true)
	protected String infTp;

	@XmlElement(name = "InfVal", required = true)
	protected String infVal;

	/**
	 * Gets the value of the infTp property.
	 * @return possible object is {@link String }
	 */
	public String getInfTp() {
		return infTp;
	}

	/**
	 * Sets the value of the infTp property.
	 * @param value allowed object is {@link String }
	 */
	public void setInfTp(String value) {
		this.infTp = value;
	}

	/**
	 * Gets the value of the infVal property.
	 * @return possible object is {@link String }
	 */
	public String getInfVal() {
		return infVal;
	}

	/**
	 * Sets the value of the infVal property.
	 * @param value allowed object is {@link String }
	 */
	public void setInfVal(String value) {
		this.infVal = value;
	}

}
