/*****************************************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:    * 06 MARCH  2012   
 * 
 * Purpose:     Invoice Cancellation Services Interface
 * 
 * Change History: 
 * Date                                                  Author                             Version                   Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- ----------------------------------
 * 06 MARCH  2012                    Oracle Financial Services Software Ltd            Initial Version		Added for new screen invoice cancellation
 * 24/04/2012						 Sandhya R										   R2.1 SIT 2068 		Changed the parameter for approving cancellation of invoice for event log
 * 12-July 2012                    		 Oracle Financial Services Software Ltd            EIPP Phase II - Cancel Invoice MFU
 * 09 Nov 2012						 Raja S 											Change Done for Invoice Cancellation Check through screen
 ****************************************************************************************************************************************************************************************/


package com.bnp.eipp.services.invoice;

import java.util.List;

import org.dozer.DozerBeanMapper;

import com.bnp.eipp.services.filemgmt.IEippFileReleaseService;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.scm.services.common.vo.AttachmentVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceCancelVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.invoice.vo.EippTransactionVO;
import com.bnp.eipp.services.vo.invoice.InvoiceCancellationVO;
import com.bnp.scm.services.common.ITransactionService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;


public interface IEippInvoiceCancelServices extends ITransactionService,IEippFileReleaseService {
	/**
	 * API to fetch the invoice details 
	 * @param objInvVO : VO containing the invoice details 
	 * @return list : containing the invoice details 
	 * @throws BNPApplicationException : thrown when there is an exception 
	 */
	List<InvoiceCancellationVO> getInvoiceDetails(InvoiceCancellationVO searchVO)throws BNPApplicationException;
	
	/**
	 * API to get the invoice line item details 
	 * @param invoiceId: the invoice Identifier 
	 * @return list containing the invoice line item details 
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	List<EippInvCntLineItemVO> getInvoiceLineItemDetails(long invoiceId)throws BNPApplicationException;
	
	/**
	 * API To get the custom feild details
	 * @param invoiceId : the invoice identifier 
	 * @return list : containing teh custom feild details 
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	List<NameValueVO> getInvoiceCustomFields(long invoiceId)throws BNPApplicationException;
	/**
	 * 	API to the line item custom details 
	 * @param invcLineItemId : line item identifier  
	 * @return list : containing the invoice custom line item details 
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	List<NameValueVO> getInvcLineItemCustomFields(long invcLineItemId)throws BNPApplicationException;
	/**
	 * API To get the invoice details 
	 * @param invoiceId : invoice identifier 
	 * @return list containing the elements to be populated in Details page 
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	List<EippInvCntLineItemVO> getInvoiceDetailsFields(long invoiceId)throws BNPApplicationException;
	/**
	 * API to get the audit record details 
	 * @param invoiceId : invoice identifier 
	 * @return list : containing the audit record details 
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	List<InvoiceCancellationVO> getInvoiceAuditRecDetails(long invoiceId)throws BNPApplicationException;
	/**
	 * To get the line item audit details 
	 * @param lineItemId : line item identifier 
	 * @return list : containing the line item audit details 
	 *@throws BNPApplicationException : thrown when there is an exception
	 */
	List<InvoiceCancellationVO> getLineItemAuditDetails(long lineItemId)throws BNPApplicationException;
	/**
	 * API to cancel the record
	 * @param invoiceId : invoice identifier 
	 * @param discountRequestCancelled 
	 * @param string 
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	int cancelRecord(long invoiceId, String string, String discountRequestCancelled)throws BNPApplicationException;
	/**
	 * API to approve the records 
	 * @param invoiceId : invoice identifier 
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	int approveRecordDetails(InvoiceCancellationVO invoiceCancellationVO, String strUserId, String strStatus)throws BNPApplicationException;
	/**
	 * API to get the attachment details 
	 * @return LIST : containing the attachment details
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	List<AttachmentVO> getAttachmentDetails(long lInvoiceId)
			throws BNPApplicationException;

	/**
	 * API to get Supplier Org Id for Suggestion box
	 * @param userId: USER iD 
	 * @param userType: TYPE OF USER 
	 * @return List of Org Id 
	 * @throws BNPApplicationException : thrown in case of exceptions
	 */
	List<NameValueVO> getSupplierOrgList(String userId, String userType)throws BNPApplicationException;

	/**
	 * API to get Buyer Org Id for Suggestion box
	 * @param userId: USER iD 
	 * @param userType: TYPE OF USER 
	 * @return List of Org Id 
	 * @throws BNPApplicationException : thrown in case of exceptions
	 */
	List<NameValueVO> getBuyerOrgList(String userId, String userType)throws BNPApplicationException;
	
	/**
	 * Gets the CancelInvoice details
	 * @param long fileId
	 * @param String status
	 * @return
	 */
	List<InvoiceCancellationVO> getCancelInvoiceDetails(long fileId, String status) throws BNPApplicationException;
	
	/**
	 * @param eippInvoiceCancelVO
	 * @return
	 * @throws BNPApplicationException 
	 */
	int isInvoiceAvailableForCancel(EippInvoiceCancelVO eippInvoiceCancelVO) throws BNPApplicationException;

	/**
	 * @param message
	 * @param detailsVO
	 * @param dataList
	 * @param b
	 * @throws BNPApplicationException 
	 */
	<T extends EippTransactionVO> void releaseFile(AbstractMessage<?> message,
			FileDetailsVO detailsVO, List<T> dataList,DozerBeanMapper beanMapper,
			boolean b) throws BNPApplicationException;

	void releaseFile(FileDetailsVO detailsVO, 
			boolean autoAuthorization) throws BNPApplicationException;
	
	void processInvoiceCancellation(FileDetailsVO detailsVO, List<InvoiceCancellationVO> cancellationVOs) throws BNPApplicationException;
	
	/**
	 * @param eippInvoiceCancelVO
	 * @return
	 * @throws BNPApplicationException 
	 */
	List<EippInvoiceVO> getInvoiceListForValidation(EippInvoiceCancelVO eippInvoiceCancelVO) throws BNPApplicationException;

	/**
	 * @param detailsVO
	 */
	void cancelInvoiceForModify(FileDetailsVO detailsVO) throws BNPApplicationException;
	
	int doBusinessValidation(InvoiceCancellationVO invoiceCancellationVO) throws BNPApplicationException;

}
