/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  24 August 2012 
 * 
 * Purpose:     EIPP Payment Status Update DAO Implementation
 * 
 * Change History: 
 * Date                     Author                  Version                         Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 24 Aug 2012           Reena S                    Initial Version
 * 21 Sep 2012 			 Reena S											Modified for Billing
 * 24 Sep 2012			 Raja S												Change Done for Status Update in Payment Cancellation		
 * 23 Nov 2012			 Arun G									  			Regression Issue
 *****************************************************************************************************************************************************************/


package com.bnp.eipp.services.dao.payment;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.invoice.vo.EippPymtStatusUpdateVO;
import com.bnp.eipp.services.vo.payment.EippPaymentMsgDetailVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.BNPRuntimeException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.ibatis.sqlmap.client.SqlMapExecutor;
import com.ibatis.sqlmap.engine.execution.BatchException;

@Component 
public class EippPymtStatusUpdateDAOImpl extends SqlMapClientWrapper implements IEippPymtStatusUpdaetDAO {
	private static final Logger LOGGER = LoggerFactory.getLogger(EippPymtStatusUpdateDAOImpl.class);
	
	private static final String NAMESPACE="EippPymtStatusUpdateNS"; 
	private static final String INSERT_STATUS_UPDATE_DETAILS = "EippPymtStatusUpdateNS.insertStatusUpdate";
	private static final String GET_PYMT_REF_DETAILS="EippPymtStatusUpdateNS.fetchPaymentRefDetails";
	private static final String GET_SPLIT_PYMT_DETAILS="EippPymtStatusUpdateNS.fetchSplitPaymentDetails";
	private static final String GET_VALID_PYMTSTATUS_LIST="EippPymtStatusUpdateNS.fetchValidPymtStatusRecords";
	
	private static final String GET_ALLPAYMENTDET_FOR_UPDATE = "EippPymtStatusUpdateNS.getAllPaymentDetForUpdate";
	private static final String UPDATE_PAYMENT_STATUS_IN_MASTER = "EippPymtStatusUpdateNS.updatePaymentStatusInMaster";
	private static final String UPDATE_PAYMENT_STATUS_IN_SPLIT = "EippPymtStatusUpdateNS.updatePaymentStatusInSplit";
	private static final String GET_ANY_SPLIT_FAIL = "EippPymtStatusUpdateNS.getAnySplitFail";
	private static final String GET_ALL_SPLIT_SUCCESS = "EippPymtStatusUpdateNS.getAllSplitSuccess";
	
	private static final String UPDATE_TXN_TIMESTAMP="EippPymtStatusUpdateNS.updateTxnTimestamp";
	private static final String RESET_PROCESSING_FLAG="EippPymtStatusUpdateNS.resetProcessingFlag";
	private static final String GET_ALLBILLDET_FOR_UPDATE="EippPymtStatusUpdateNS.getAllBillingDetForUpdate";
	private static final String UPD_BILL_STATUS_IN_MASTER="EippPymtStatusUpdateNS.updateBillingStatusInMaster";
	private static final String GET_BILL_REF_DETAILS="EippPymtStatusUpdateNS.fetchBillingRefDetails";

	public EippPymtStatusUpdateDAOImpl(){
		nameSpace=NAMESPACE;
	}
	
	@Override
	public void insertFileDetailsIntoMaster(FileDetailsVO detailsVO)throws DBException {
	
	}

	@Override
	public void insertFileDetailsIntoHistFromTrans(FileDetailsVO detailsVO)
			throws DBException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insertFileDetailsIntoHistFromMaster(FileDetailsVO detailsVO)
			throws DBException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteFileDetailsFromTrans(FileDetailsVO detailsVO)
			throws DBException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insertStatusUpdateList(final List<EippPymtStatusUpdateVO> statusUpdateList,final FileDetailsVO fileVO)
			throws BNPRuntimeException {
		try {
			getSqlMapClientTemplate().execute(new SqlMapClientCallback<List<Object>>() {
				@Override
				@SuppressWarnings("unchecked")
				public List<Object> doInSqlMapClient(SqlMapExecutor executor)throws SQLException {
					List<Object> list = null;
					try {
						executor.startBatch();
						// inserting Pymt status update details
						for (EippPymtStatusUpdateVO pymtStatusVO : statusUpdateList) {				
							pymtStatusVO.setFileId(fileVO.getFileId());
							pymtStatusVO.setMakerId(BNPConstants.SYSTEM);							
							executor.insert(INSERT_STATUS_UPDATE_DETAILS, pymtStatusVO); 
						}
						list = executor.executeBatchDetailed();	
					} catch (BatchException e) {							
						LOGGER.error("Uploading the Payment Status update details in a batch failed"+e.getMessage());						
						throw new SQLException(e);
					} 
					// R7.0 Fortify issues
					//LOGGER.debug("List :: " + list);
					return list;
				}
			});
		} catch (DataAccessException e) {
			throw new BNPRuntimeException(ErrorConstants.DATABASE_ERROR);
		}
	
		/*
		try {
			for (EippPymtStatusUpdateVO pymtStatusVO : statusUpdateList) {				
				pymtStatusVO.setFileId(fileVO.getFileId());
				pymtStatusVO.setMakerId(BNPConstants.SYSTEM);			
				getSqlMapClientTemplate().insert(INSERT_STATUS_UPDATE_DETAILS, pymtStatusVO);				
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BNPRuntimeException(ErrorConstants.DATABASE_ERROR);
		} */
	}

	@Override
	public EippPymtStatusUpdateVO getPaymentDetails(String pymtRefNo)throws BNPApplicationException {
		EippPymtStatusUpdateVO pymtDetails=null;
		try {
			pymtDetails=(EippPymtStatusUpdateVO)getSqlMapClientTemplate().queryForObject(GET_PYMT_REF_DETAILS,pymtRefNo);
		}catch(DataAccessException dex) {
			LOGGER.error("::DB error in getPaymentDetails::"+dex);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return pymtDetails;
		
	}

	@Override
	public EippPymtStatusUpdateVO getBillingDetails(String billRefNo)throws BNPApplicationException {
		EippPymtStatusUpdateVO billDetails=null;
		try {
			billDetails=(EippPymtStatusUpdateVO)getSqlMapClientTemplate().queryForObject(GET_BILL_REF_DETAILS,billRefNo); 
		}catch(DataAccessException dex) {
			LOGGER.error("::DB error in getBillingDetails::"+dex);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return billDetails;	
	}

	@Override
	public List<EippPymtStatusUpdateVO> getSplitPaymentDetails(EippPymtStatusUpdateVO statusVO) throws BNPApplicationException {
		List<EippPymtStatusUpdateVO> splitDet=null;
		try {
			splitDet=getSqlMapClientTemplate().queryForList(GET_SPLIT_PYMT_DETAILS,statusVO);
		}catch(DataAccessException dex) {
			LOGGER.error("::DB error in getSplitPaymentDetails::"+dex.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return splitDet;
	}

	@Override
	public List<EippPymtStatusUpdateVO> getValidPymtStatusRecords(Long fileId)throws BNPApplicationException {
		List<EippPymtStatusUpdateVO> pymtStatusRec=null;
		try {
			pymtStatusRec=getSqlMapClientTemplate().queryForList(GET_VALID_PYMTSTATUS_LIST,fileId);
		}catch(DataAccessException dex) {
			LOGGER.error("::DB error in getValidPymtStatusRecords::"+dex.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return pymtStatusRec;
	}
	
	@Override
	public EippPaymentMsgDetailVO getAllPaymentDetForUpdate(String pymtRefNo) throws BNPApplicationException {
		EippPaymentMsgDetailVO outputVO = null;
		try {
			outputVO = (EippPaymentMsgDetailVO) getSqlMapClientTemplate().queryForObject(GET_ALLPAYMENTDET_FOR_UPDATE,pymtRefNo);
		 } catch (DataAccessException e) {
			 logger.error("Error while insertMessageInfo for discount request message formation " + e.getMessage());
			 throw new DBException(ErrorConstants.DATABASE_ERROR);
		 }
		 return outputVO;
	}
	
	@Override
	public void updatePaymentStatusInSplit(EippPaymentMsgDetailVO allDet,EippPymtStatusUpdateVO stsUpdVo) throws BNPApplicationException {
		try{
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("eippPaymentMsgDetailVO", allDet);
			params.put("eippPymtStatusUpdateVO", stsUpdVo);
			getSqlMapClientTemplate().update(UPDATE_PAYMENT_STATUS_IN_SPLIT, params);	
		} catch (DataAccessException e) {
			logger.error("Error while updating batchid in master table " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public void updatePaymentStatusInMaster(EippPaymentMsgDetailVO allDet) throws BNPApplicationException {
		try{
			String error;
			Map <String,Object> map = new HashMap<String,Object>();
			map.put("orgId", allDet.getOrgId());
			map.put("paymentId" , new java.lang.Long(allDet.getPaymentId()));
			map.put("paymentAmt" , allDet.getPaymentAmt()); 
			map.put("paymentCcy" , allDet.getPaymentCcy());
			map.put("paymentStatus" , allDet.getRecordStatus());
			map.put("userId" , allDet.getUserId());
			map.put("action" , allDet.getAction());
			map.put("remarks", allDet.getRemarks());
			getSqlMapClientTemplate().queryForObject(UPDATE_PAYMENT_STATUS_IN_MASTER, map);
			if(map.containsKey("currentRecordStatus")){
				error = (String) map.get("currentRecordStatus");
				// R7.0 Fortify issues
				//logger.debug("Error::"+error);
				if(error != null && !error.isEmpty()){
					throw new DBException(error);
				}
			}
		} catch (DataAccessException e) {
			logger.error("Error while updating batchid in master table " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public int getAllSplitSuccess(EippPaymentMsgDetailVO allDet) throws BNPApplicationException {
		int count;
		try{
			count=(Integer) getSqlMapClientTemplate().queryForObject(GET_ALL_SPLIT_SUCCESS,allDet);
		} catch (DataAccessException e) {
			logger.error("Error while updating batchid in master table " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		return count;
	}
	
	@Override
	public int getAnySplitFail(EippPaymentMsgDetailVO allDet) throws BNPApplicationException {
		int count;
		try{
			count=(Integer) getSqlMapClientTemplate().queryForObject(GET_ANY_SPLIT_FAIL,allDet);
		} catch (DataAccessException e) {
			logger.error("Error while updating batchid in master table " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		return count;
	}
	
	@Override
	public int updateTxnTimestamp(Object obj) throws BNPApplicationException {
		try{			
			EippPaymentMsgDetailVO eippPymtMsgVO = (EippPaymentMsgDetailVO) obj;
			Integer count = getSqlMapClientTemplate().update(UPDATE_TXN_TIMESTAMP, eippPymtMsgVO);
			// R7.0 Fortify issues
			//logger.debug("count in updateTxnTimestamp::" +count);
			return count;
		} catch (DataAccessException e) {
			logger.error("Error while updating batchid in master table " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public void resetProcessingFlag(Object obj) throws BNPApplicationException {
		try{
			EippPaymentMsgDetailVO eippPymtMsgVO = (EippPaymentMsgDetailVO) obj;
			getSqlMapClientTemplate().update(RESET_PROCESSING_FLAG, eippPymtMsgVO);
		} catch (DataAccessException e) {
			logger.error("Error while updating batchid in master table " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public EippPaymentMsgDetailVO getAllBillingDetForUpdate(String refNo) throws BNPApplicationException {
		EippPaymentMsgDetailVO outputVO = null;
		try {
			outputVO = (EippPaymentMsgDetailVO) getSqlMapClientTemplate().queryForObject(GET_ALLBILLDET_FOR_UPDATE,refNo);
		 } catch (DataAccessException e) {
			 logger.error("Error while insertMessageInfo for discount request message formation " + e.getMessage());
			 throw new DBException(ErrorConstants.DATABASE_ERROR);
		 }
		 return outputVO;
	}

	@Override
	public void updateBillingStatusInMaster(EippPaymentMsgDetailVO allDet) throws BNPApplicationException {
		try{
			getSqlMapClientTemplate().update(UPD_BILL_STATUS_IN_MASTER, allDet);
			logger.debug("count in updateTxnTimestamp::");
		} catch (DataAccessException e) {
			logger.error("Error while updating batchid in master table " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	
}
