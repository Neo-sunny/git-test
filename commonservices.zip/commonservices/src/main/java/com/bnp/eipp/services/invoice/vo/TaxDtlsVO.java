package com.bnp.eipp.services.invoice.vo;

import java.io.Serializable;
import java.util.Date;

public class TaxDtlsVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String taxRef;
	
	private Date taxRefDate;
	
	private String taxPercent;

	public String getTaxRef() {
		return taxRef;
	}

	public void setTaxRef(String taxRef) {
		this.taxRef = taxRef;
	}

	public Date getTaxRefDate() {
		return taxRefDate;
	}

	public void setTaxRefDate(Date taxRefDate) {
		this.taxRefDate = taxRefDate;
	}

	public String getTaxPercent() {
		return taxPercent;
	}

	public void setTaxPercent(String taxPercent) {
		this.taxPercent = taxPercent;
	}
	
	
}
