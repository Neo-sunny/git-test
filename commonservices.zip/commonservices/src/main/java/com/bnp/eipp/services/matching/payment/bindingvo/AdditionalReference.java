package com.bnp.eipp.services.matching.payment.bindingvo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for AdditionalReference complex type.
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AdditionalReference">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RefValue" type="{}Max35Text"/>
 *         &lt;element name="RefType" type="{}Max8Text"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AdditionalReference", propOrder = { "refValue", "refType" })
public class AdditionalReference {

	@XmlElement(name = "RefValue", required = true)
	protected String refValue;

	@XmlElement(name = "RefType", required = true)
	protected String refType;

	/**
	 * Gets the value of the refValue property.
	 * @return possible object is {@link String }
	 */
	public String getRefValue() {
		return refValue;
	}

	/**
	 * Sets the value of the refValue property.
	 * @param value allowed object is {@link String }
	 */
	public void setRefValue(String value) {
		this.refValue = value;
	}

	/**
	 * Gets the value of the refType property.
	 * @return possible object is {@link String }
	 */
	public String getRefType() {
		return refType;
	}

	/**
	 * Sets the value of the refType property.
	 * @param value allowed object is {@link String }
	 */
	public void setRefType(String value) {
		this.refType = value;
	}

}
