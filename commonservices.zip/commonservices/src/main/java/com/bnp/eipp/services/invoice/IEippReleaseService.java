/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 6, 20125:40:42 PM
 * 
 * Purpose:      IEippReleaseServiceImpl.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 6, 20125:40:42 PM        Oracle Financial Services Software Ltd                  Initial Version
 * 24 Sep 2012					Aarthi T											    Release File Inq - Rel 3.0 Matching and Reconcilation
 * 10 Oct 2012		  			Aarthi T												Release File Inq Payment details - Rel 3.0 Matching and Reconcilation
 * 17 Oct 2012					Sandhya R								   			    R3.0 Matchin Recon : Changes for auto match mail event  
************************************************************************************************************************************************************/

package com.bnp.eipp.services.invoice;

import java.util.Map;

import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.BNPRuntimeException;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;

public interface IEippReleaseService {
	
	void releaseFile(FileDetailsVO detailsVO) throws BNPApplicationException;

	NameValueVO getInvoiceTotalAmtForFile(long fileId, String fileUploadStatus)throws BNPApplicationException;

	NameValueVO getCntTotalAmtForFile(long fileId, String fileUploadStatus)throws BNPApplicationException;

	byte[] generateCreditNoteReportPdf(long cntId) throws BNPApplicationException;
	
	byte[] generateInvoiceReportPdf(long cntId) throws BNPApplicationException;
	
	boolean insertIntoMasterIfAutoAuthorizationEnabled(FileDetailsVO detailsVO) throws BNPRuntimeException;
	
	public void deleteFile(FileDetailsVO detailsVO) throws BNPApplicationException;
	
	 // Start : Added for Rel 3.0 Matching and Reconcilation
	public NameValueVO getMatchReconInvoiceCountForFile(long fileId, String fileUploadStatus) throws BNPApplicationException;
	
	public NameValueVO getMatchReconCntCountForFile(long fileId, String fileUploadStatus) throws BNPApplicationException;
	
	public NameValueVO getMatchReconPaymentCountForFile(long fileId, String fileUploadStatus) throws BNPApplicationException;
	// Ends : Added for Rel 3.0 Matching and Reconcilation
	boolean insertMthRecIntoMasIfAutoAuthEnb(FileDetailsVO detailsVO,Map<String, String> params) throws BNPApplicationException;
	
	void sendMailForAutoMatch(FileDetailsVO fileVO) throws BNPApplicationException;


}
