/****************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14 Oct 2012
 * 
 * Purpose: Eipp Matching Invoice ERP Message
 * 
 * Change History: 
 * Date                       	Author                                  Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 14 Oct 2012              	Prabu P                      			Initial Version
 ********************************************************************************************************************************/

package com.bnp.eipp.services.matching.invoice;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import org.dozer.DozerBeanMapper;

import com.bnp.eipp.services.invoice.vo.EippCreditNoteVO;
import com.bnp.eipp.services.invoice.vo.EippCustFieldsVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.matching.invoice.bindingvo.AdditionalInformation1;
import com.bnp.eipp.services.matching.invoice.bindingvo.Address01;
import com.bnp.eipp.services.matching.invoice.bindingvo.CreditNoteDetails01;
import com.bnp.eipp.services.matching.invoice.bindingvo.Document;
import com.bnp.eipp.services.matching.invoice.bindingvo.ErrorDescription;
import com.bnp.eipp.services.matching.invoice.bindingvo.File;
import com.bnp.eipp.services.matching.invoice.bindingvo.GeneralInfo01;
import com.bnp.eipp.services.matching.invoice.bindingvo.Header;
import com.bnp.eipp.services.matching.invoice.bindingvo.InvoiceAndPODetails01;
import com.bnp.eipp.services.matching.invoice.bindingvo.Message;
import com.bnp.eipp.services.matching.invoice.bindingvo.ObjectFactory;
import com.bnp.eipp.services.matching.invoice.bindingvo.ReconciliationDetails01;
import com.bnp.eipp.services.matching.invoice.bindingvo.SourceAndMatchDtls01;
import com.bnp.eipp.services.vo.common.EippMessageVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.AbstractVO;
import com.bnp.scm.services.txns.common.message.AbstractMsg;
import com.bnp.scm.services.txns.common.vo.MessageVO;
import com.bnp.scm.services.txns.util.PropertiesReader;
import com.bnp.scm.services.txns.util.xml.XmlValidationEventHandler;

public class EippMatchingInvoiceMessage extends AbstractMsg<Message> {

	private ObjectFactory factory;

	/**
	 * Constructor to create basic objects for message
	 */
	@Override
	public void createInstance() throws BNPApplicationException {
		this.factory = new ObjectFactory();
		this.message = new Message();
		this.body = new File();
		this.header = new Header();
		this.errorDescription = new ErrorDescription();
	}

	/*
	 * (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.AbstractMessage#createHeader(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void createHeader(AbstractVO abstractVO) throws BNPApplicationException {
		try {
			if (abstractVO instanceof EippMessageVO) {
				EippMessageVO matchInvMsgVO = (EippMessageVO)abstractVO;
				MessageVO messageVO = new MessageVO();
				messageVO.setMsgId(matchInvMsgVO.getMsgId());
				messageVO.setOrgId(matchInvMsgVO.getOrgId());
				matchInvMsgVO.setMessageVO(messageVO);
				
				Map<String, String> headerMap = matchInvMsgVO.getHeaderMap();
				GregorianCalendar greCal = new GregorianCalendar();
				header.setCountry(headerMap.get("COUNTRY_CODE"));
				header.setBankCode(headerMap.get("BANK_CODE"));
				header.setBranchCode(headerMap.get("BRANCH_CODE"));
				header.setSCMOrgId(matchInvMsgVO.getOrgId());
				header.setCntType(PropertiesReader.getProperty("message.content.type.xml"));
				header.setMsgFileSts(PropertiesReader.getProperty("message.type.na"));
				header.setSrcRefId(matchInvMsgVO.getMsgId());
				header.setCustFileName(PropertiesReader.getProperty("message.type.na"));
				header.setOrgin(PropertiesReader.getProperty("txns.label.fo"));
				if (BNPConstants.H2H.equals(matchInvMsgVO.getMode())) {
					header.setDestination(PropertiesReader.getProperty("txns.label.h2h"));
					header.setMsgFileType(PropertiesReader.getProperty("message.type.matching.eipp.matched.invoice"));
				}
				else {
					header.setDestination(PropertiesReader.getProperty("txns.label.erp"));
					header.setMsgFileType(PropertiesReader.getProperty("message.type.matching.eipp.status.erp"));
				}
				messageVO.setMsgType(header.getMsgFileType());
				messageVO.setTransportType(header.getDestination());
				messageVO.setSupportBranchId(headerMap.get("SUPPORT_BRANCH_ID"));
				header.setCustFileRecvTime(greCal);
				header.setSendTime(greCal);
				this.setHeader(header);
			}
		}
		catch (Exception exception) {
			throw new BNPApplicationException(exception.getMessage(), exception);
		}
	}

	/*
	 * (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.AbstractMessage#createBody(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void createBody(AbstractVO abstractVO) throws BNPApplicationException {

		if (abstractVO instanceof EippMessageVO) {
			EippMessageVO matchInvMsgVO = (EippMessageVO)abstractVO;

			Document document = factory.createDocument();
			((File)getBody()).setDocument(document);

			try {
				List<EippInvCntVO> eippInvCntVOList = (List<EippInvCntVO>)matchInvMsgVO.getDataList();
				List<String> mapperList = new ArrayList<String>(1);
				mapperList.add("mapper/EippMatchedInvoiceMapper.xml");

				// Mapping JAXB object to custom VO object
				DozerBeanMapper mapper = new DozerBeanMapper();
				mapper.setMappingFiles(mapperList);

				for (EippInvCntVO eippInvCntVO : eippInvCntVOList) {
					SourceAndMatchDtls01 sourceAndMatchDtls = getSourcAndMatchDetail(eippInvCntVO, mapper);
					document.getMatchingDtls().add(sourceAndMatchDtls);
				}
			}
			catch (Exception e) {
				throw new BNPApplicationException("Error while constructing message :: " + e);
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.AbstractMessage#createBody(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void createErrorDescription(AbstractVO abstractVO) throws BNPApplicationException {

	}

	/*
	 * (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.AbstractMessage#createMessage(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void createMessage() throws BNPApplicationException {
		if (factory == null) {
			this.factory = new ObjectFactory();
		}
		Message message = (Message)this.getMessage();
		message.setHeader((Header)this.getHeader());
		message.setFile((File)this.getBody());
		this.setMessage(message);
		this.setJaxbElementObj(factory.createMsg(message));
	}

	/*
	 * (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.IMessage#setBindingProperties()
	 */
	@Override
	public void setBindingProperties() throws BNPApplicationException {
		this.properties.setBindingClass(Message.class);
		this.properties.setValidateXsd(true);
		this.properties.setXsdPath(PropertiesReader.getProperty("message.eipp.matched.invoice.erp.xsd.path"));
		this.properties.setEventHandler(new XmlValidationEventHandler());
		this.setProperties(properties);
	}

	private SourceAndMatchDtls01 getSourcAndMatchDetail(EippInvCntVO eippInvCntVO, DozerBeanMapper mapper) {

		SourceAndMatchDtls01 srcMatchDetails = factory.createSourceAndMatchDtls01();

		GeneralInfo01 generalInfo = mapper.map(eippInvCntVO, GeneralInfo01.class);
		srcMatchDetails.setGeneralInfo(generalInfo);

		List<EippInvoiceVO> invoiceList = eippInvCntVO.getInvoiceList();
		if (invoiceList != null && !invoiceList.isEmpty()) {
			for (EippInvoiceVO invoiceVO : invoiceList) {
				ReconciliationDetails01 srcRecon = factory.createReconciliationDetails01();
				ReconciliationDetails01 matchRecon = factory.createReconciliationDetails01();
				
				InvoiceAndPODetails01 invoiceDetails = mapper.map(invoiceVO, InvoiceAndPODetails01.class);
				invoiceDetails.setBillTo(parseAddress(invoiceVO.getBillToAddrStr()));
				invoiceDetails.setShipTo(parseAddress(invoiceVO.getShipToAddrStr()));
				invoiceDetails.setRemitTo(parseAddress(invoiceVO.getRemitToAddrStr()));
				List<EippCustFieldsVO> custFieldList = invoiceVO.getCustFields();
				if(custFieldList != null && !custFieldList.isEmpty()) {
					for (EippCustFieldsVO eippCustFieldsVO : custFieldList) {
						AdditionalInformation1 customField = new AdditionalInformation1();
						customField.setInfTp(eippCustFieldsVO.getFieldName());
						customField.setInfVal(eippCustFieldsVO.getFieldValue());
						invoiceDetails.getInclNote().add(customField);
					}
				}
				
				if (BNPConstants.MATCH_TYPE_SOURCE.equals(invoiceVO.getMatchType())) {
					invoiceDetails.setMatchType(BNPConstants.SOURCE);
					srcRecon.setInvcDtls(invoiceDetails);
					srcMatchDetails.getSource().add(srcRecon);
				}
				else {
					invoiceDetails.setMatchType(BNPConstants.MATCH);
					matchRecon.setInvcDtls(invoiceDetails);
					srcMatchDetails.getMatch().add(matchRecon);
				}
			}
		}

		List<EippCreditNoteVO> creditNoteList = eippInvCntVO.getCntList();
		if (creditNoteList != null && !creditNoteList.isEmpty()) {
			for (EippCreditNoteVO eippCreditNoteVO : creditNoteList) {
				ReconciliationDetails01 srcRecon = factory.createReconciliationDetails01();
				ReconciliationDetails01 matchRecon = factory.createReconciliationDetails01();
				
				CreditNoteDetails01 crNtDetails = mapper.map(eippCreditNoteVO, CreditNoteDetails01.class);
				crNtDetails.setBillTo(parseAddress(eippCreditNoteVO.getBillToAddrStr()));
				crNtDetails.setShipTo(parseAddress(eippCreditNoteVO.getShipToAddrStr()));
				
				if (BNPConstants.MATCH_TYPE_SOURCE.equals(eippCreditNoteVO.getMatchType())) {
					srcRecon.setCnDtls(crNtDetails);
					srcMatchDetails.getSource().add(srcRecon);
				}
				else {
					matchRecon.setCnDtls(crNtDetails);
					srcMatchDetails.getMatch().add(matchRecon);
				}
			}
		}

		return srcMatchDetails;
	}
	
	/**
	 * Parse the address
	 * @param str
	 */
	private Address01 parseAddress(String str) {

		if (str != null && !str.isEmpty()) {
			Address01 address = factory.createAddress01();
			String[] strArray = str.split("~");
			
			for (int i = 0; i < strArray.length; i++) {
				if (i == 5) {
					address.setPstCd(strArray[i]);
				}
				else if (i == 6) {
					address.setTwnNm(strArray[i]);
				}
				else if (i == 8) {
					address.setState(strArray[i]);
				}
				else if (i == 9) {
					address.setCtry(strArray[i]);
				}
				else if (i == 10 || i == 11 || i == 12) {
					address.getAdrLine().add(strArray[i]);
				}
			}			
			return address;
		}
		return null;
	}
}
