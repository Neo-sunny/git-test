/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14 Jan 2012
 * 
 * Purpose:     Link Organization for EIPP DAO Interface
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 14 Jan 2012                      Oracle Financial Services Software Ltd             Initial Version
 * 09 Mar 2012		  Oracle Financial Services Software Ltd				 Release 2.1 I1				Changed for Auto Complete Text box Implementation
 * 05 Apr 2012		  Oracle Financial Services Software Ltd				 Release 2.1 I1				Fix for SIT TD-1866
 * 18 Jul 2012        Reena 												 Release 3.0	            Changes for EIPP-Phase II
 *****************************************************************************************************************************************************************/

package com.bnp.eipp.services.dao.admin;

import java.util.List;
import java.util.Map;

import com.bnp.eipp.services.vo.admin.LinkOrgForEippVO;
import com.bnp.scm.services.common.dao.IAbstractCommonDao;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;



// TODO: Auto-generated Javadoc
/**
 * The Interface ILinkOrgForEippDAO.
 */
public interface ILinkOrgForEippDAO extends IAbstractCommonDao<LinkOrgForEippVO> { 
	
	/**
	 * Gets the link org eipp details.
	 *
	 * @param searchVO the search vo
	 * @return the link org eipp details
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<LinkOrgForEippVO> getLinkOrgEippDetails(LinkOrgForEippVO searchVO)throws BNPApplicationException;
	
	/**
	 * Gets the customer org id list.
	 *
	 * @param userId the user id
	 * @return the customer org id list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getCustomerOrgIdListBA(String userId)throws BNPApplicationException;
	
	/**
	 * Gets the customer org id list.
	 *
	 * @param userId the user id
	 * @return the customer org id list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getCustomerOrgIdListOA(String userId)throws BNPApplicationException;
	
	/**
	 * Gets the customer org id list.
	 *
	 * @param userId the user id
	 * @return the customer org id list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getCustomerOrgIdListMPOA(String userId)throws BNPApplicationException;
	
	
	/**
	 * Gets the counter party org id list.
	 *
	 * @param primeOrgId the prime org id
	 * @return the counter party org id list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getCounterPartyOrgIdList(NameValueVO params)throws BNPApplicationException;
	
	/**
	 * Gets the counter party org id list.
	 *
	 * @param primeOrgId the prime org id
	 * @return the counter party org id list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getMPCounterPartyOrgIdList(NameValueVO params)throws BNPApplicationException;
	
	
	/**
	 * Gets the bill type list.
	 *
	 * @param orgId the org id
	 * @return the bill type list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getBillTypeList(String orgId)throws BNPApplicationException;
	
	/**
	 * Gets the bill type rule details.
	 *
	 * @param orgBillDet the org bill det
	 * @return the bill type rule details
	 * @throws BNPApplicationException the bNP application exception
	 */
	LinkOrgForEippVO getBillTypeRuleDetails(Map<String, Object> orgBillDet)throws BNPApplicationException;
	
	/**
	 * Gets the organization role.
	 *
	 * @param orgId the org id
	 * @return the organization role
	 * @throws BNPApplicationException the bNP application exception
	 */
	NameValueVO getOrganizationRole(String orgId)throws BNPApplicationException;
	
	/**
	 * Gets the org deparment list.
	 *
	 * @param orgId the org id
	 * @return the org deparment list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getOrgDeparmentList(String orgId)throws BNPApplicationException;
	
	/**
	 * Chk record already exists.
	 *
	 * @param searchVO the search vo
	 * @return the int
	 * @throws BNPApplicationException the bNP application exception
	 */
	int chkRecordAlreadyExists(LinkOrgForEippVO searchVO)throws BNPApplicationException;
	
	/**
	 * Chk dependency befor delete.
	 *
	 * @param searchVO the search vo
	 * @return the int
	 * @throws BNPApplicationException the bNP application exception
	 */
	int chkDependencyBeforDelete(LinkOrgForEippVO searchVO) throws BNPApplicationException;
	
	/**
	 * Gets the child details.
	 *
	 * @param fields the fields
	 * @return the child details
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<String> getChildDetails(LinkOrgForEippVO fields)throws BNPApplicationException;
	
	/**
	 * View audit link org eipp.
	 *
	 * @param linkOrgVO the link org vo
	 * @return the link org for eipp vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	LinkOrgForEippVO viewAuditLinkOrgEipp(LinkOrgForEippVO linkOrgVO)throws BNPApplicationException;
	
	/**
	 * This API returns the department for dispute resolution for the given buyer, supplier and bill type
	 * combination.
	 * @param params
	 * @return
	 * @throws BNPApplicationException
	 */
	long getDepartmentForDisputeResolution(Map<String, Object> params)
			throws BNPApplicationException;
	/**
	 * Gets the bill type rule details.
	 *
	 * @param orgBillDet the org bill det
	 * @return the bill type rule details
	 * @throws BNPApplicationException the bNP application exception
	 */	
	LinkOrgForEippVO getBillTypeDeptDetails(Map<String, Object> orgBillDet)throws BNPApplicationException;
	
	/**
	 * Gets the counter party org id list.
	 * Added for SIT TD-1866
	 * @param primeOrgId the prime org id
	 * @return the counter party org id list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getCounterPartyOrgIdListSummary(NameValueVO params)throws BNPApplicationException;
	
	/**
	 * Gets the Market Place Organization list.
	 *
	 * @param 
	 * @return the Market Place Organization list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getMarketPlaceOrgList(LinkOrgForEippVO searchVO)throws BNPApplicationException;
}
