/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  * 28 Aug 2012	   
 * 
 * Purpose:     Raise Dispute Services Implementation
 * 
 * Change History: 
 * Date                                      	 Author                              Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 28 Aug 2012	       							Dinesh D                 		 Initial Version  
 * 22 OCT 2012					                Sadhana A V						 Rel 3.0 - Message monitoring changes (Functional ack message type corrected)
 * 25 Oct 2012	       							Ravishankar V                 	 ST Defects 7042 and 7050
 * 23 Nov 2012									Reena S							 Msg Type for Raise Dispute and Resolve Dispute is Changed as 'EIPPDisputes'
 *****************************************************************************************************************************************************************/

package com.bnp.eipp.services.dispute;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.dao.dispute.IDisputeMgmtDao;
import com.bnp.eipp.services.dao.invoice.IEippRaiseDisputeDAO;
import com.bnp.eipp.services.filemgmt.EippAbstractFileReleaseServiceImpl;
import com.bnp.eipp.services.interfaces.disputeupload.EippDisputeMessage;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.invoice.vo.EippTransactionVO;
import com.bnp.eipp.services.txns.util.file.EippFileUtil;
import com.bnp.eipp.services.vo.dispute.DisputeCustFieldsVO;
import com.bnp.eipp.services.vo.dispute.DisputeVO;
import com.bnp.eipp.services.vo.dispute.bindingvo.DisputeDet;
import com.bnp.eipp.services.vo.dispute.bindingvo.Document;
import com.bnp.eipp.services.vo.dispute.bindingvo.ErrorMessage;
import com.bnp.eipp.services.vo.dispute.bindingvo.ErrorMessages;
import com.bnp.eipp.services.vo.dispute.bindingvo.File;
import com.bnp.eipp.services.vo.dispute.bindingvo.Header;
import com.bnp.eipp.services.vo.dispute.bindingvo.InvLineItem;
import com.bnp.eipp.services.vo.dispute.bindingvo.InvLineItemDetails;
import com.bnp.eipp.services.vo.dispute.bindingvo.RaiseDispute;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.BNPRuntimeException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.invoice.IInvoiceUploadService;
import com.bnp.scm.services.invoice.vo.InvalidFileDataVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;
import com.bnp.scm.services.txns.util.PropertiesReader;
import com.bnp.scm.services.txns.util.xml.XmlBinding;

// TODO: Auto-generated Javadoc
/**
 * The Class EippRaiseDisputeServiceImpl.
 */
@Component
public class EippRaiseDisputeServiceImpl extends EippAbstractFileReleaseServiceImpl implements IEippRaiseDisputeService {

	/** The raise dispute dao. */
	@Autowired 
	private IEippRaiseDisputeDAO raiseDisputeDAO;

	/** The dispute mgmt service. */
	@Autowired
	private IDisputeMgmtService disputeMgmtService;

	/** The upload service. */
	@Autowired
	private IInvoiceUploadService uploadService;

	/** The inv cancel dao. */
	@Autowired 
	private IDisputeMgmtDao disputeMgmtDao;

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.filemgmt.EippAbstractFileReleaseServiceImpl#getDao()
	 */
	@Override
	public SqlMapClientWrapper getDao() {
		return (SqlMapClientWrapper)raiseDisputeDAO;
	}

	/**
	 * Process raise dispute.
	 *
	 * @param detailsVO the details vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void processRaiseDispute(FileDetailsVO detailsVO) throws BNPApplicationException {
		List<DisputeVO> raiseDisputeList = raiseDisputeDAO.getRaiseDisputeList(detailsVO.getFileId());
		for (DisputeVO disputeVO : raiseDisputeList) {
			disputeVO.setDispStatus(StatusConstants.DISPUTED);
			disputeVO.setRaisedDate(new Date());
			disputeVO.setCurrentUserId(detailsVO.getUserId());
			//disputeVO.setAttachments(getAttachmentList());
			disputeVO.getEippInvoice().getDeptAllocMap().setUserId(disputeVO.getDisputeApprovedBy());
			if(StatusConstants.INVOICE.equalsIgnoreCase(disputeVO.getDisputedAt()))
			{
				disputeVO.getEippInvoice().getDeptAllocMap().setApprovalLevel(BNPConstants.DEPT_ALLOC_TYPE_INVOICE);
				disputeMgmtService.insertInvoiceDispute(disputeVO);
			}
			else
			{
				//disputeVO.setAttachments(getAttachmentList());
				disputeVO.getEippInvoice().getDeptAllocMap().setApprovalLevel(BNPConstants.DEPT_ALLOC_TYPE_LINEITEM);
				disputeVO.setCustFieldsList(raiseDisputeDAO.getRaiseDisputeListForLI(disputeVO.getEippInvoice().getInvId()));
				disputeMgmtService.insertInvoiceLIDispute(disputeVO);
			}
			disputeVO.getEippInvoice().getDeptAllocMap().setAllocLevel(raiseDisputeDAO.getDisputeAllocLevel(disputeVO));
			if(disputeVO.getEippInvoice().getDeptAllocMap().getUserId()!=null 
					&& disputeVO.getEippInvoice().getDeptAllocMap().getUserId().equals(BNPConstants.SYSTEM)){
				disputeVO.getEippInvoice().getDeptAllocMap().setUserId("*");
				disputeMgmtDao.batchInsertAllocMap(disputeVO);
			}else{
				disputeVO.setDeptId("0");
				disputeMgmtDao.insertDisuteInAllocMap(disputeVO);
			}
			
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dispute.IEippRaiseDisputeService#doBusinessValidation(com.bnp.eipp.services.vo.dispute.DisputeVO)
	 */
	public List<Integer> doBusinessValidation(DisputeVO disputeVO) throws BNPApplicationException {
		List<Integer> errorCodeList = new ArrayList<Integer>();
			if(!raiseDisputeDAO.isValidDeptUser(disputeVO))
			{
				errorCodeList.add(ErrorConstants.INVALID_DEPT_USER); 
			}
		String allocType= raiseDisputeDAO.getDisputeAllocType(disputeVO);
		if(disputeVO.getDisputedAt()==null || disputeVO.getDisputedAt().equals(allocType))
		{
			errorCodeList.add(ErrorConstants.ALLOCATION_TYPE_MISMATCH); 
		}

		return errorCodeList;
	}

	@Override
	public int isInvAvailableForRaiseDispute(EippInvoiceVO eippInvoiceVO)throws BNPApplicationException 
	{
		return raiseDisputeDAO.isInvAvailableForRaiseDispute(eippInvoiceVO);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.filemgmt.IEippFileReleaseService#insertFileDetailsIntoHistFromTrans(com.bnp.scm.services.filemgmt.vo.FileDetailsVO)
	 */
	@Override
	public void insertFileDetailsIntoHistFromTrans(FileDetailsVO detailsVO)
			throws BNPRuntimeException, BNPApplicationException {
		raiseDisputeDAO.insertFileDetailsIntoHistFromTrans(detailsVO);
	}

	// Release file starts
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.filemgmt.EippAbstractFileReleaseServiceImpl#releaseFile(com.bnp.scm.services.filemgmt.vo.FileDetailsVO,boolean)
	 */
	public void releaseFile(FileDetailsVO detailsVO, 
			boolean isAutoReleaseEnabled) throws BNPApplicationException {
		releaseFile(null, detailsVO, null, null, isAutoReleaseEnabled);
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.filemgmt.EippAbstractFileReleaseServiceImpl#releaseFile(com.bnp.scm.services.txns.common.message.AbstractMessage, com.bnp.scm.services.filemgmt.vo.FileDetailsVO, java.util.List, org.dozer.DozerBeanMapper, boolean)
	 */
	@Override
	public <T extends EippTransactionVO>void releaseFile(AbstractMessage<?> message,
			FileDetailsVO detailsVO, List<T> dataList,
			DozerBeanMapper beanMapper, boolean isAutoReleaseEnabled) throws BNPApplicationException {
		super.releaseFile(message, detailsVO, dataList, beanMapper, isAutoReleaseEnabled);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.filemgmt.IEippFileReleaseService#insertFileDetailsIntoMaster(com.bnp.scm.services.filemgmt.vo.FileDetailsVO)
	 */
	@Override
	public void insertFileDetailsIntoMaster(FileDetailsVO detailsVO) throws BNPApplicationException {
		raiseDisputeDAO.insertFileDetailsIntoMaster(detailsVO);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.filemgmt.IEippFileReleaseService#insertFileDetailsIntoHistFromMaster(com.bnp.scm.services.filemgmt.vo.FileDetailsVO)
	 */
	@Override
	public void insertFileDetailsIntoHistFromMaster(FileDetailsVO detailsVO)
			throws BNPRuntimeException, BNPApplicationException {
		raiseDisputeDAO.insertFileDetailsIntoHistFromMaster(detailsVO);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.filemgmt.IEippFileReleaseService#deleteFileDetailsFromTrans(com.bnp.scm.services.filemgmt.vo.FileDetailsVO)
	 */
	@Override
	public void deleteFileDetailsFromTrans(FileDetailsVO detailsVO) throws BNPApplicationException {
		raiseDisputeDAO.deleteFileDetailsFromTrans(detailsVO);		
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.filemgmt.EippAbstractFileReleaseServiceImpl#generateFunctionalAck(com.bnp.scm.services.txns.common.message.AbstractMessage, com.bnp.scm.services.filemgmt.vo.FileDetailsVO, java.util.List, org.dozer.DozerBeanMapper, boolean)
	 */
	@Override
	public <T extends EippTransactionVO>void generateFunctionalAck(AbstractMessage<?> message, FileDetailsVO detailsVO, List<T> dataList, DozerBeanMapper beanMapper, boolean isAutoReleaseEnabled) throws BNPApplicationException {
		if(message == null && !isAutoReleaseEnabled){
			message = prepareMessage(detailsVO);
		}
		else{ 
			if(dataList != null){
				( (File)message.getBody()).setDocument(mapVOToJAXB(dataList, beanMapper, isAutoReleaseEnabled ));
			}
		}
		if (message != null) {
			message.setHeader(getAckHeader((Header)message.getHeader(), detailsVO, "message.type.eipp.raiseDispute.funcack"));
			message.marshallMessage(message.getProperties());
			String xmlContent = message.getXmlMessage();
			XmlBinding.validate(xmlContent, PropertiesReader.getProperty("message.eippschema.dispute.xsd.path"));
			detailsVO.setFuncAckData(xmlContent.getBytes());
			detailsVO.setEippfuncAck(BNPConstants.EIPP_RAISE_DISPUTE_FUNC_ACK);
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.filemgmt.EippAbstractFileReleaseServiceImpl#postRelease(com.bnp.scm.services.filemgmt.vo.FileDetailsVO)
	 */
	@Override
	public void postRelease(FileDetailsVO detailsVO) throws BNPApplicationException {
		processRaiseDispute(detailsVO);
	}

	/**
	 * This API updates the file status as deleted and
	 * updates the trans record status as deleted, inserted into history from trans and
	 * deletes the record in raise dispute trans table.
	 *
	 * @param detailsVO the details vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	@Override
	public void deleteFile(FileDetailsVO detailsVO) throws BNPApplicationException {
		raiseDisputeDAO.updateRecordStatusInTrans(detailsVO.getFileId(), StatusConstants.DELETE_RECORD);
		raiseDisputeDAO.insertFileDetailsIntoHistFromTrans(detailsVO);
		raiseDisputeDAO.deleteFileDetailsFromTrans(detailsVO);
	}
	// Release file ends

	/**
	 * This API returns the EippDisputeMessage during manual release.
	 *
	 * @param detailsVO the details vo
	 * @return the abstract message
	 * @throws BNPApplicationException the bNP application exception
	 */
	private AbstractMessage<?> prepareMessage(FileDetailsVO detailsVO) throws BNPApplicationException {
		String msgDispute = propertyLoader.getValue("message.type.eipp.dispute");
		EippDisputeMessage raiseDisputeMessage = new EippDisputeMessage();

		raiseDisputeMessage.extractMessage(new String(eventLogDAO.getMsgData(detailsVO.getFileId()+"", msgDispute.trim())));
		List<InvalidFileDataVO> lstInvalidFileDataVO = uploadService.getRejectedRecords(detailsVO.getFileId());
		boolean bInvalid; 
		int pymtRecCntr = 0;
		StringBuffer refNo = new StringBuffer();
		for(RaiseDispute raiseDispute : ((File)raiseDisputeMessage.getBody()).getDocument().getRaiseDispute()){
			bInvalid = false;
			++pymtRecCntr;
			refNo.setLength(0);
			refNo.append(detailsVO.getFileId()).append(BNPConstants.VALUE_SEPARATOR).append(pymtRecCntr);
			raiseDispute.setErrMsgs(getErrorMessages(lstInvalidFileDataVO, refNo.toString()));

			if(raiseDispute.getErrMsgs() != null && raiseDispute.getErrMsgs().getErrMsg() != null && raiseDispute.getErrMsgs().getErrMsg().size() > 0) {
				bInvalid = true;
			} 				
			raiseDispute.setStatus((bInvalid == true) ? BNPConstants.RELEASED : BNPConstants.VALIDATION_FAILED);
		}
		return raiseDisputeMessage;
	}

	/**
	 * This API generates the Functional acknowledgment message during file release.
	 *
	 * @param <T> the generic type
	 * @param raiseDisputeList the raise dispute list
	 * @param beanMapper the bean mapper
	 * @param isAutoReleaseEnabled the is auto release enabled
	 * @return the document
	 */


	private <T extends EippTransactionVO>Document mapVOToJAXB(List<T> raiseDisputeList, DozerBeanMapper beanMapper, boolean isAutoReleaseEnabled) {
		Document document = new Document();
		document.getRaiseDispute().addAll(prepareJAXBObjects(raiseDisputeList, beanMapper, isAutoReleaseEnabled));
		return document;
	}

	/**
	 * This API returns the JAXB object with proper status & error messages.
	 *
	 * @param <T> the generic type
	 * @param raiseDisputeList the raise dispute list
	 * @param beanMapper the bean mapper
	 * @param isAutoReleaseEnabled the is auto release enabled
	 * @return the list
	 */
	private <T extends EippTransactionVO> List<RaiseDispute> prepareJAXBObjects(List<T> raiseDisputeList, DozerBeanMapper beanMapper, boolean isAutoReleaseEnabled){

		List<RaiseDispute> invoices = new ArrayList<RaiseDispute>();

		for(T disputeVO : raiseDisputeList){
			RaiseDispute invoice = beanMapper.map(disputeVO, RaiseDispute.class);	
			DisputeDet disputeDet = invoice.getDisputeDetails();
			if(BNPConstants.DISP_TYPE_INVOICE.equals(disputeDet.getDisputeType()))
			{
				disputeDet.setInvLineItemDetails(null);
			}
			else
			{
				disputeDet.setInvDispDetails(null);
				InvLineItemDetails lineItemDetails= disputeDet.getInvLineItemDetails();
				List<DisputeCustFieldsVO> custFields=((DisputeVO)disputeVO).getCustFieldsList();
				for(int i=0;i<custFields.size();i++)
				{
					DisputeCustFieldsVO quantity=custFields.get(i);
					DisputeCustFieldsVO unitPrice=custFields.get(++i);
					DisputeCustFieldsVO subtotal=custFields.get(++i);
					
					InvLineItem invLineItem = new InvLineItem();
					
					invLineItem.setLineItemNo(quantity.getRefNo());
					invLineItem.setNewItemQuantity(quantity.getNewValue().intValue());
					invLineItem.setOrigItemQuanity(quantity.getOldValue().intValue());
					
					invLineItem.setNewItemUnitPrice(unitPrice.getNewValue());
					invLineItem.setOrigItemPrice(unitPrice.getOldValue());
					
					invLineItem.setNewSubTotal(subtotal.getNewValue());
					invLineItem.setOrigSubTotal(subtotal.getOldValue());
					lineItemDetails.getInvLineItem().add(invLineItem);
				}
			}
			if (!EippFileUtil.isEmptyList(disputeVO.getInvalidFileDataList())){
				invoice.setErrMsgs(getErrorMessages(disputeVO.getInvalidFileDataList(), beanMapper));
				invoice.setStatus(BNPConstants.VALIDATION_FAILED);
			}
			else {
				invoice.setStatus((isAutoReleaseEnabled) ? BNPConstants.RELEASED : BNPConstants.VALIDATION_SUCCESS);
			}
			invoices.add(invoice);
		}
		return invoices;
	}

	/**
	 * This method prepares ErrorMessages list for Invalid data.
	 *
	 * @param invalidDataList the invalid data list
	 * @param beanMapper the bean mapper
	 * @return the error messages
	 */
	private ErrorMessages getErrorMessages(List<InvalidFileDataVO> invalidDataList, DozerBeanMapper beanMapper){

		ErrorMessages ermsgs = new ErrorMessages();

		for (InvalidFileDataVO invalidFileDataVO : invalidDataList) {
			ErrorMessage errorMessage = beanMapper.map(invalidFileDataVO, ErrorMessage.class);
			ermsgs.getErrMsg().add(errorMessage);
		}

		return ermsgs;
	}

	/**
	 * Gets the error messages.
	 *
	 * @param lstInvalidFileDataVO the lst invalid file data vo
	 * @param refNo the ref no
	 * @return the error messages
	 */
	private ErrorMessages getErrorMessages(List<InvalidFileDataVO> lstInvalidFileDataVO, String refNo) {
		ErrorMessages errmsgs = null;
		ErrorMessage errmsg = null;
		for(InvalidFileDataVO invalidFileDataVO :lstInvalidFileDataVO) {
			if(refNo.equals(invalidFileDataVO.getRefNo())){
				if(errmsgs == null) {
					errmsgs = new ErrorMessages();
				}

				errmsg = new ErrorMessage();
				errmsg.setErrorCode(invalidFileDataVO.getErrorMessage());
				errmsg.setErrorDesc(msgService.getMessage("en_US", Integer.parseInt(invalidFileDataVO.getErrorMessage())));
				errmsgs.getErrMsg().add(errmsg);
			}
		}
		return errmsgs;
	}	 

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dispute.IEippRaiseDisputeService#isValidResolutionCode(com.bnp.eipp.services.vo.dispute.DisputeVO)
	 */
	@Override
	public int isValidResolutionCode(DisputeVO disputeVO)
			throws BNPApplicationException {
		return raiseDisputeDAO.isValidResolutionCode(disputeVO);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dispute.IEippRaiseDisputeService#getValidLineItemNoList(java.util.List)
	 */
	@Override
	public List<DisputeCustFieldsVO> getValidLineItemNoList(DisputeVO disputeVO)
			throws BNPApplicationException {
		return raiseDisputeDAO.getValidLineItemNoList(disputeVO);

	}

	@Override
	public <T extends EippTransactionVO> void insertFileDetailsIntoTrans(
			List<T> valueObjectList, FileDetailsVO detailsVO)
					throws BNPApplicationException {
		raiseDisputeDAO.insertRaiseDisputeList((List<DisputeVO>)valueObjectList, detailsVO);
		saveAttachments(detailsVO.getFileId(), FILE_TYPE.RAISE_DISPUTE, detailsVO.getUserId());
	}

}
