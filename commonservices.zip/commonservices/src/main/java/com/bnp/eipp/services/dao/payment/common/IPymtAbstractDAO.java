/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Aug 2012
 * 
 * Purpose:    EIPP Payment Preparation 
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 01 Aug 2012                      Oracle Financial Services Software Ltd                                    Initial Version 
 * 26 Sep 2012                         Gangadharan R														Authorization matrix changes
 * 13 Oct 2012						Vinoth Kumar M																CSV Export Functionality Added
 *****************************************************************************************************************************************************************/
package com.bnp.eipp.services.dao.payment.common;

import java.util.List;
import java.util.Map;

import com.bnp.eipp.services.invoice.vo.EippCreditNoteVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.vo.admin.EippNonFinInqLineItemVO;
import com.bnp.eipp.services.vo.admin.PaymentAdjustMentCodeVO;
import com.bnp.eipp.services.vo.payment.EippPymtAuditVO;
import com.bnp.eipp.services.vo.payment.EippPymtVO;
import com.bnp.eipp.services.vo.payment.PymtAdjustmentCodeCustomVO;
import com.bnp.eipp.services.vo.payment.SplitPaymentVO;
import com.bnp.scm.services.common.dao.IAbstractCommonDao;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

// TODO: Auto-generated Javadoc
/**
 * The Interface IPymtAbstractDAO.
 *
 * @param <T> the generic type
 */
public interface IPymtAbstractDAO<T extends EippPymtVO> extends IAbstractCommonDao<T> {

	/**
	 * Gets the pymt cancellation summary records.
	 *
	 * @param dataVO the data vo
	 * @return the pymt cancellation summary records
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippPymtVO> getPymtCancellationSummaryRecords(EippPymtVO dataVO) throws BNPApplicationException;
	
	/**
	 * Gets the pymt authorization summary records.
	 *
	 * @param dataVO the data vo
	 * @return the pymt authorization summary records
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippPymtVO> getPymtAuthorizationSummaryRecords(EippPymtVO dataVO) throws BNPApplicationException;
	
	/**
	 * Gets the financial inquiry summary records.
	 *
	 * @param dataVO the data vo
	 * @return the financial inquiry summary records
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippPymtVO> getFinancialInquirySummaryRecords(EippPymtVO dataVO) throws BNPApplicationException;
	
	/**
	 * Gets the pymt audit rec details.
	 *
	 * @param pymtId the pymt id
	 * @return the pymt audit rec details
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippPymtVO> getPymtAuditRecDetails(long pymtId) throws BNPApplicationException;
	
	/**
	 * Gets the credit note rec details.
	 *
	 * @param dataVO the data vo
	 * @return the credit note rec details
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippCreditNoteVO> getCreditNoteRecDetails(EippPymtVO dataVO) throws BNPApplicationException;
	
	/**
	 * Gets the pymt adjustment rec details.
	 *
	 * @param dataVO the data vo
	 * @return the pymt adjustment rec details
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<PaymentAdjustMentCodeVO> getPymtAdjustmentRecDetails(EippPymtVO dataVO) throws BNPApplicationException;
	
	/**
	 * Gets the split pymt amt details.
	 *
	 * @param dataVO the data vo
	 * @return the split pymt amt details
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<SplitPaymentVO> getSplitPymtAmtDetails(EippPymtVO dataVO) throws BNPApplicationException;
	
	/**
	 * Gets the invoice details.
	 *
	 * @param dataVO the data vo
	 * @return the invoice details
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippInvoiceVO> getInvoiceDetails(EippPymtVO dataVO) throws BNPApplicationException;
	
	/**
	 * Gets the line item details.
	 *
	 * @param dataVO the data vo
	 * @return the line item details
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippInvCntLineItemVO> getLineItemDetails(EippPymtVO dataVO) throws BNPApplicationException;
	
	/**
	 * Authorize pymt record.
	 *
	 * @param pymtRefNo the pymt ref no
	 * @throws BNPApplicationException the bNP application exception
	 */
	void authorizePymtRecord(EippPymtVO eippPymtVO) throws BNPApplicationException;
	
	
	/**
	 * Checks if is dual control is enabled.
	 *
	 * @param dataVO the data vo
	 * @return the string
	 * @throws BNPApplicationException the bNP application exception
	 */
	String isDualControlIsEnabled(EippPymtVO dataVO) throws BNPApplicationException;
	
	/**
	 * Gets the pymt adj param details.
	 *
	 * @param adjId the adj id
	 * @return the pymt adj param details
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<PymtAdjustmentCodeCustomVO> getPymtAdjParamDetails(long adjId) throws BNPApplicationException;
	
	/**
	 * Reject pymt cancellation.
	 *
	 * @param dataVO the data vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void rejectPymtCancellation(EippPymtVO dataVO) throws BNPApplicationException;
	
	
	/**
	 * Gets the buyer org id list.
	 *
	 * @param userId the user id
	 * @param userTypeId the user type id
	 * @return the buyer org id list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getBuyerOrgIdList(String userId , String userTypeId)throws BNPApplicationException;
	
	/**
	 * Gets the supplier org id list.
	 *
	 * @param userId the user id
	 * @param userTypeId the user type id
	 * @return the supplier org id list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getSupplierOrgIdList(String userId , String userTypeId)throws BNPApplicationException;
	
	/**
	 * Gets the market place org id list.
	 *
	 * @param userId the user id
	 * @param userTypeId the user type id
	 * @return the market place org id list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getMarketPlaceOrgIdList(String userId , String userTypeId)throws BNPApplicationException;
	
	/**
	 * Insert pymt access log details.
	 *
	 * @param auditVO the audit vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	public abstract void insertPymtAccessLogDetails(EippPymtAuditVO auditVO) throws BNPApplicationException;
	//String getNameSpace();
	
	/**
	 * Gets the line item audit rec details.
	 *
	 * @param lineItemId the line item id
	 * @return the line item audit rec details
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippNonFinInqLineItemVO> getLineItemAuditRecDetails(long lineItemId) throws BNPApplicationException;
	
	
	String getBranchTimeZone(String orgId) throws BNPApplicationException;

	EippPymtVO getselectedDataDetails(long pymtId)throws BNPApplicationException;
	
	/**
	 * Insert auth audit.
	 *
	 * @param transVO the trans vo
	 * @param authLevelList the auth level list
	 * @throws BNPApplicationException the bNP application exception
	 */
	void insertAuthAuditMapping(EippPymtVO transVO, final List<String> authLevelList)  throws BNPApplicationException;
	
	/**
	 * Update authlevel in mapping.
	 *
	 * @param transVO the trans vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void updateAuthlevelInMapping(EippPymtVO transVO)  throws BNPApplicationException;
	
	/**
	 * Update payment auth matx.
	 *
	 * @param transVO the trans vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void updatePaymentAuthMatx(EippPymtVO transVO)  throws BNPApplicationException;
	
	/**
	 * Update payment auth matx mid levels.
	 *
	 * @param transVO the trans vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void updatePaymentAuthMatxMidLevels(EippPymtVO transVO)  throws BNPApplicationException;
	
	/**
	 * Check approved list for user.
	 *
	 * @param transVO the trans vo
	 * @return the int
	 * @throws BNPApplicationException the bNP application exception
	 */
	int checkApprovedListForUser(EippPymtVO transVO)  throws BNPApplicationException;
	
	/**
	 * Check valid user.
	 *
	 * @param transVO the trans vo
	 * @return the string
	 * @throws BNPApplicationException the bNP application exception
	 */
	String checkValidUser(EippPymtVO transVO) throws BNPApplicationException;
	
	/**
	  * Get the Lead Organization Details
	  * @param pymtVO
	  * @return Map
	  * @throws BNPApplicationException
	  */
	 Map<String, Integer> getLeadOrgDetails(final EippPymtVO pymtVO) throws BNPApplicationException;
	
	/**
	  * Get the Eipp Payment column Details
	  * @param pymtVO
	  * @return List
	  * @throws BNPApplicationException
	  */
	 List<String> getEippPaymentColumnDetails(final EippPymtVO pymtVO) throws BNPApplicationException;
	
	 /**
	  * Get the Eipp Payment Details to export into file
	  * @param pymtVO
	  * @return List
	  * @throws BNPApplicationException
	  */
	 List<String> getEippPaymentDetails(final EippPymtVO pymtVO) throws BNPApplicationException;
	 
	 /**
 	 * Gets the unlink credit note rec details.
 	 *
 	 * @param dataVO the data vo
 	 * @return the unlink credit note rec details
 	 * @throws BNPApplicationException the bNP application exception
 	 */
 	List<EippCreditNoteVO> getUnlinkCreditNoteRecDetails(EippPymtVO dataVO) throws BNPApplicationException;
}
