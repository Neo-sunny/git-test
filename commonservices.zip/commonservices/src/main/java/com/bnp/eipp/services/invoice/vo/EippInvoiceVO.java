/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 2, 2012
 * 
 * Purpose:      EippInvoiceVO.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 2, 2012      Oracle Financial Services Software Ltd                  Initial Version  
 * Mar 2,2012       Oracle Financial Services Software Ltd                  EIPP Dept Approval Changes
 * Apr 3,2012       Oracle Financial Services Software Ltd                  ST Defect #5812 and #5813
 * Apr 21,2012      Sandhya R							                    SIT Defect #2020
 * Aug 13,2012		Reena S													Release 3.0 EIPP PhaseII-Release File Inq Changes
 * Sep 08,2012      Arun G               								  Eipp Paymnet Erp Message
 * Sep 17,2012      Raja S              								  Eipp Paymnet IUT Sanity Testing Issue
 * Sep 18,2012      Raja S              								  Eipp Paymnet IUT Sanity Testing Issue
 * Sep 22,2012      Sriram Rengarajan              						  Eipp Paymnet UT Sanity Testing Issue
 * 10 Oct 2012		Aarthi T											  Release File Inq Payment details - Rel 3.0 Matching and Reconcilation
 * Oct 20,2012      Ravishankar V              						  	  ST Defect 6970
************************************************************************************************************************************************************/

package com.bnp.eipp.services.invoice.vo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.common.vo.AttachmentVO;
import com.bnp.scm.services.txns.util.calendar.DateAdapter;

/**
 * The Class EippInvoiceVO.
 */
public class EippInvoiceVO extends EippTransactionVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 180211655063117123L;

	private static final Logger LOGGER = LoggerFactory.getLogger(EippInvoiceVO.class);	
	
	//Added for 3.0 - Payment Preparation
	/** The pmt value date. */
	private Date pmtValueDate;
	
	/** The total disp amt. */
	private BigDecimal totalDispAmt;
	
	/** The adj outstanding amt. */
	private BigDecimal adjOutstandingAmt;
	
	/** The outstanding amt. */
	private BigDecimal outstandingAmt;
	
	/** The outstanding amt frm. */
	private BigDecimal outstandingAmtFrm;
	
	/** The outstanding amt to. */
	private BigDecimal outstandingAmtTo;
	
	/** The query params. */
	private Map<Object,Object> queryParams;
	
	/** The buyer acct no. */
	private String buyerAcctNo;
	
	/** The pay thru mkt place. */
	private String payThruMktPlace;
	
	/** The mkt place acc no. */
	private String mktPlaceAccNo;
	
	/** The inv due date on reb lt pmt. */
	private String invDueDateOnRebLtPmt;
	
	/** The rule type. */
	private String ruleType;
//	List<EippPymtVO> eippPymtVOList;
	/** The cnt util amount. */
	private BigDecimal cntUtilAmount;
	
	/** The inv id list. */
	private List<EippInvoiceVO> invIdList;
	
	/** The allow cn at pmt level. */
	private String allowCNAtPmtLevel;
	
	/** The total line item amt. */
	private BigDecimal totalLineItemAmt ;
	
	/** The temp init date. */
	private Date tempInitDate;
	
	/** The pmt type. */
	private String pmtType;
	
	/** The allow multi pymt. */
	private String allowMultiPymt;
	
	/** The pay at ln itm only. */
	private String payAtLnItmOnly;
	
	/** The user id. */
	private String userId;
	
	/** The allow future dt pymt. */
	private String allowFutureDtPymt;
	
	/** The max all fut dt pymt. */
	private long maxAllFutDtPymt;
	
	/** The allow over pmt. */
	private String allowOverPmt;
	
	/** The late fee amt. */
	private BigDecimal lateFeeAmt;
	
	/** The account identifier. */
	private String accountIdentifier;
	
	/** The fee rebate pymt. */
	private BigDecimal feeRebatePymt;
	
	/** The pmt at invoice. */
	private BigDecimal pmtAtInvoice;
	
	/** The buyr acct identifier. */
	private String buyrAcctIdentifier;
	
	/** The supplr acct identifier. */
	private String supplrAcctIdentifier;
	
	/** The mkt place acct identifier. */
	private String mktPlaceAcctIdentifier;
	
	/** The allow pymt adjustment. */
	private String allowPymtAdjustment;
	
	/** The allow partial pymt. */
	private String allowPartialPymt;
	
	/** The allow split pymt. */
	private String allowSplitPymt;
	
	/** The disable li. */
	private boolean disableLI;
	
	/** The reason. */
	private String reason;
	
	/** The allow bulk inv. */
	private String allowBulkInv;
	
	/** The buttonValue. */
	private String buttonValue;
	
	/** The ln itm selected. */
	private boolean lnItmSelected;
	
	
	private boolean lnItmBlockdStatus;
	
	private boolean pmtAlreadyPrep;
	// Total Line Item Count
	private int totLineItemCnt;
	
	
	//added for matching
	
	private String shippingTerms;
	
	private String taxpercent;
	
	private long totalPymtCnt;
	private boolean disablePymtAmt;
	
	/**
	 * Gets the cnt util amount.
	 *
	 * @return the cnt util amount
	 */
	public BigDecimal getCntUtilAmount() {
		return cntUtilAmount;
	}

	/**
	 * Gets the pmt at invoice.
	 *
	 * @return the pmt at invoice
	 */
	public BigDecimal getPmtAtInvoice() {
		return pmtAtInvoice;
	}

	

	/**
	 * Gets the buyr acct identifier.
	 *
	 * @return the buyr acct identifier
	 */
	public String getBuyrAcctIdentifier() {
		return buyrAcctIdentifier;
	}

	/**
	 * Sets the buyr acct identifier.
	 *
	 * @param buyrAcctIdentifier the new buyr acct identifier
	 */
	public void setBuyrAcctIdentifier(String buyrAcctIdentifier) {
		this.buyrAcctIdentifier = buyrAcctIdentifier;
	}

	/**
	 * Gets the supplr acct identifier.
	 *
	 * @return the supplr acct identifier
	 */
	public String getSupplrAcctIdentifier() {
		return supplrAcctIdentifier;
	}

	/**
	 * Sets the supplr acct identifier.
	 *
	 * @param supplrAcctIdentifier the new supplr acct identifier
	 */
	public void setSupplrAcctIdentifier(String supplrAcctIdentifier) {
		this.supplrAcctIdentifier = supplrAcctIdentifier;
	}

	/**
	 * Gets the mkt place acct identifier.
	 *
	 * @return the mkt place acct identifier
	 */
	public String getMktPlaceAcctIdentifier() {
		return mktPlaceAcctIdentifier;
	}

	/**
	 * Sets the mkt place acct identifier.
	 *
	 * @param mktPlaceAcctIdentifier the new mkt place acct identifier
	 */
	public void setMktPlaceAcctIdentifier(String mktPlaceAcctIdentifier) {
		this.mktPlaceAcctIdentifier = mktPlaceAcctIdentifier;
	}

	/**
	 * Gets the allow pymt adjustment.
	 *
	 * @return the allow pymt adjustment
	 */
	public String getAllowPymtAdjustment() {
		return allowPymtAdjustment;
	}

	/**
	 * Sets the allow pymt adjustment.
	 *
	 * @param allowPymtAdjustment the new allow pymt adjustment
	 */
	public void setAllowPymtAdjustment(String allowPymtAdjustment) {
		this.allowPymtAdjustment = allowPymtAdjustment;
	}

	/**
	 * Gets the allow partial pymt.
	 *
	 * @return the allow partial pymt
	 */
	public String getAllowPartialPymt() {
		return allowPartialPymt;
	}

	/**
	 * Sets the allow partial pymt.
	 *
	 * @param allowPartialPymt the new allow partial pymt
	 */
	public void setAllowPartialPymt(String allowPartialPymt) {
		this.allowPartialPymt = allowPartialPymt;
	}

	/**
	 * Gets the allow split pymt.
	 *
	 * @return the allow split pymt
	 */
	public String getAllowSplitPymt() {
		return allowSplitPymt;
	}

	/**
	 * Sets the allow split pymt.
	 *
	 * @param allowSplitPymt the new allow split pymt
	 */
	public void setAllowSplitPymt(String allowSplitPymt) {
		this.allowSplitPymt = allowSplitPymt;
	}

	/**
	 * Checks if is disable li.
	 *
	 * @return true, if is disable li
	 */
	public boolean isDisableLI() {
		return disableLI;
	}

	/**
	 * Sets the disable li.
	 *
	 * @param disableLI the new disable li
	 */
	public void setDisableLI(boolean disableLI) {
		this.disableLI = disableLI;
	}

	/**
	 * Gets the reason.
	 *
	 * @return the reason
	 */
	public String getReason() {
		return reason;
	}

	/**
	 * Sets the reason.
	 *
	 * @param reason the new reason
	 */
	public void setReason(String reason) {
		this.reason = reason;
	}


	/**
	 * Sets the pmt value date.
	 *
	 * @param pmtValueDate the new pmt value date
	 */
	public void setPmtValueDate(Date pmtValueDate) {
		this.pmtValueDate = pmtValueDate;
	}

	/**
	 * Gets the pmt value date.
	 *
	 * @return the pmt value date
	 */
	public Date getPmtValueDate() {
		return pmtValueDate;
	}

	/**
	 * Sets the total disp amt.
	 *
	 * @param totalDispAmt the new total disp amt
	 */
	public void setTotalDispAmt(BigDecimal totalDispAmt) {
		this.totalDispAmt = totalDispAmt;
	}

	/**
	 * Gets the total disp amt.
	 *
	 * @return the total disp amt
	 */
	public BigDecimal getTotalDispAmt() {
		return totalDispAmt;
	}

	/**
	 * Sets the adj outstanding amt.
	 *
	 * @param adjOutstandingAmt the new adj outstanding amt
	 */
	public void setAdjOutstandingAmt(BigDecimal adjOutstandingAmt) {
		this.adjOutstandingAmt = adjOutstandingAmt;
	}

	/**
	 * Gets the adj outstanding amt.
	 *
	 * @return the adj outstanding amt
	 */
	public BigDecimal getAdjOutstandingAmt() {
		return adjOutstandingAmt;
	}


	/**
	 * Sets the outstanding amt.
	 *
	 * @param outstandingAmt the new outstanding amt
	 */
	public void setOutstandingAmt(BigDecimal outstandingAmt) {
		this.outstandingAmt = outstandingAmt;
	}

	/**
	 * Gets the outstanding amt.
	 *
	 * @return the outstanding amt
	 */
	public BigDecimal getOutstandingAmt() {
		return outstandingAmt;
	}

	/**
	 * Sets the query params.
	 *
	 * @param queryParams the query params
	 */
	public void setQueryParams(Map<Object,Object> queryParams) {
		this.queryParams = queryParams;
	}

	/**
	 * Gets the query params.
	 *
	 * @return the query params
	 */
	public Map<Object,Object> getQueryParams() {
		return queryParams;
	}

	/**
	 * Sets the buyer acct no.
	 *
	 * @param buyerAcctNo the new buyer acct no
	 */
	public void setBuyerAcctNo(String buyerAcctNo) {
		this.buyerAcctNo = buyerAcctNo;
	}

	/**
	 * Gets the buyer acct no.
	 *
	 * @return the buyer acct no
	 */
	public String getBuyerAcctNo() {
		return buyerAcctNo;
	}

	/**
	 * Sets the pay thru mkt place.
	 *
	 * @param payThruMktPlace the new pay thru mkt place
	 */
	public void setPayThruMktPlace(String payThruMktPlace) {
		this.payThruMktPlace = payThruMktPlace;
	}

	/**
	 * Gets the pay thru mkt place.
	 *
	 * @return the pay thru mkt place
	 */
	public String getPayThruMktPlace() {
		return payThruMktPlace;
	}

	/**
	 * Sets the mkt place acc no.
	 *
	 * @param mktPlaceAccNo the new mkt place acc no
	 */
	public void setMktPlaceAccNo(String mktPlaceAccNo) {
		this.mktPlaceAccNo = mktPlaceAccNo;
	}

	/**
	 * Gets the mkt place acc no.
	 *
	 * @return the mkt place acc no
	 */
	public String getMktPlaceAccNo() {
		return mktPlaceAccNo;
	}

	/**
	 * Sets the inv due date on reb lt pmt.
	 *
	 * @param invDueDateOnRebLtPmt the new inv due date on reb lt pmt
	 */
	public void setInvDueDateOnRebLtPmt(String invDueDateOnRebLtPmt) {
		this.invDueDateOnRebLtPmt = invDueDateOnRebLtPmt;
	}

	/**
	 * Gets the inv due date on reb lt pmt.
	 *
	 * @return the inv due date on reb lt pmt
	 */
	public String getInvDueDateOnRebLtPmt() {
		return invDueDateOnRebLtPmt;
	}

	/**
	 * Sets the rule type.
	 *
	 * @param ruleType the new rule type
	 */
	public void setRuleType(String ruleType) {
		this.ruleType = ruleType;
	}

	/**
	 * Gets the rule type.
	 *
	 * @return the rule type
	 */
	public String getRuleType() {
		return ruleType;
	}

	/**
	 * Sets the cnt util amount.
	 *
	 * @param cntUtilAmount the new cnt util amount
	 */
	public void setCntUtilAmount(BigDecimal cntUtilAmount) {
		this.cntUtilAmount = cntUtilAmount;
	}


	/**
	 * Sets the inv id list.
	 *
	 * @param invIdList the new inv id list
	 */
	public void setInvIdList(List<EippInvoiceVO> invIdList) {
		this.invIdList = invIdList;
	}

	/**
	 * Gets the inv id list.
	 *
	 * @return the inv id list
	 */
	public List<EippInvoiceVO> getInvIdList() {
		return invIdList;
	}

	/**
	 * Sets the allow cn at pmt level.
	 *
	 * @param allowCNAtPmtLevel the new allow cn at pmt level
	 */
	public void setAllowCNAtPmtLevel(String allowCNAtPmtLevel) {
		this.allowCNAtPmtLevel = allowCNAtPmtLevel;
	}

	/**
	 * Gets the allow cn at pmt level.
	 *
	 * @return the allow cn at pmt level
	 */
	public String getAllowCNAtPmtLevel() {
		return allowCNAtPmtLevel;
	}

	/**
	 * Sets the total line item amt.
	 *
	 * @param totalLineItemAmt the new total line item amt
	 */
	public void setTotalLineItemAmt(BigDecimal totalLineItemAmt) {
		this.totalLineItemAmt = totalLineItemAmt;
	}

	/**
	 * Gets the total line item amt.
	 *
	 * @return the total line item amt
	 */
	public BigDecimal getTotalLineItemAmt() {
		return totalLineItemAmt;
	}

	/**
	 * Sets the allow over pmt.
	 *
	 * @param allowOverPmt the new allow over pmt
	 */
	public void setAllowOverPmt(String allowOverPmt) {
		this.allowOverPmt = allowOverPmt;
	}

	/**
	 * Gets the allow over pmt.
	 *
	 * @return the allow over pmt
	 */
	public String getAllowOverPmt() {
		return allowOverPmt;
	}

	/**
	 * Sets the late fee amt.
	 *
	 * @param lateFeeAmt the new late fee amt
	 */
	public void setLateFeeAmt(BigDecimal lateFeeAmt) {
		this.lateFeeAmt = lateFeeAmt;
	}

	/**
	 * Gets the late fee amt.
	 *
	 * @return the late fee amt
	 */
	public BigDecimal getLateFeeAmt() {
		return lateFeeAmt;
	}


	/**
	 * Sets the account identifier.
	 *
	 * @param accountIdentifier the new account identifier
	 */
	public void setAccountIdentifier(String accountIdentifier) {
		this.accountIdentifier = accountIdentifier;
	}

	/**
	 * Gets the account identifier.
	 *
	 * @return the account identifier
	 */
	public String getAccountIdentifier() {
		return accountIdentifier;
	}



	/**
	 * Sets the fee rebate pymt.
	 *
	 * @param feeRebatePymt the new fee rebate pymt
	 */
	public void setFeeRebatePymt(BigDecimal feeRebatePymt) {
		this.feeRebatePymt = feeRebatePymt;
	}

	/**
	 * Gets the fee rebate pymt.
	 *
	 * @return the fee rebate pymt
	 */
	public BigDecimal getFeeRebatePymt() {
		return feeRebatePymt;
	}

	/**
	 * Sets the pmt at invoice.
	 *
	 * @param pmtAtInvoice the new pmt at invoice
	 */
	public void setPmtAtInvoice(BigDecimal pmtAtInvoice) {
		this.pmtAtInvoice = pmtAtInvoice;
	}
	

	/**
	 * Checks if is ln itm selected.
	 *
	 * @return true, if is ln itm selected
	 */
	public boolean isLnItmSelected() {
		return lnItmSelected;
	}

	/**
	 * Sets the ln itm selected.
	 *
	 * @param lnItmSelected the new ln itm selected
	 */
	public void setLnItmSelected(boolean lnItmSelected) {
		this.lnItmSelected = lnItmSelected;
	}

	/**
	 * Gets the outstanding amt frm.
	 *
	 * @return the outstanding amt frm
	 */
	public BigDecimal getOutstandingAmtFrm() {
		return outstandingAmtFrm;
	}

	/**
	 * Sets the outstanding amt frm.
	 *
	 * @param outstandingAmtFrm the new outstanding amt frm
	 */
	public void setOutstandingAmtFrm(BigDecimal outstandingAmtFrm) {
		this.outstandingAmtFrm = outstandingAmtFrm;
	}

	/**
	 * Gets the outstanding amt to.
	 *
	 * @return the outstanding amt to
	 */
	public BigDecimal getOutstandingAmtTo() {
		return outstandingAmtTo;
	}

	/**
	 * Sets the outstanding amt to.
	 *
	 * @param outstandingAmtTo the new outstanding amt to
	 */
	public void setOutstandingAmtTo(BigDecimal outstandingAmtTo) {
		this.outstandingAmtTo = outstandingAmtTo;
	}

	/**
	 * Sets the temp init date.
	 *
	 * @param tempInitDate the new temp init date
	 */
	public void setTempInitDate(Date tempInitDate) {
		this.tempInitDate = tempInitDate;
	}

	/**
	 * Gets the temp init date.
	 *
	 * @return the temp init date
	 */
	public Date getTempInitDate() {
		return tempInitDate;
	}

	/**
	 * Sets the pmt type.
	 *
	 * @param pmtType the new pmt type
	 */
	public void setPmtType(String pmtType) {
		this.pmtType = pmtType;
	}

	/**
	 * Gets the pmt type.
	 *
	 * @return the pmt type
	 */
	public String getPmtType() {
		return pmtType;
	}

	/**
	 * Sets the allow multi pymt.
	 *
	 * @param allowMultiPymt the new allow multi pymt
	 */
	public void setAllowMultiPymt(String allowMultiPymt) {
		this.allowMultiPymt = allowMultiPymt;
	}

	/**
	 * Gets the allow multi pymt.
	 *
	 * @return the allow multi pymt
	 */
	public String getAllowMultiPymt() {
		return allowMultiPymt;
	}

	/**
	 * Sets the pay at ln itm only.
	 *
	 * @param payAtLnItmOnly the new pay at ln itm only
	 */
	public void setPayAtLnItmOnly(String payAtLnItmOnly) {
		this.payAtLnItmOnly = payAtLnItmOnly;
	}

	/**
	 * Gets the pay at ln itm only.
	 *
	 * @return the pay at ln itm only
	 */
	public String getPayAtLnItmOnly() {
		return payAtLnItmOnly;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Sets the allow future dt pymt.
	 *
	 * @param allowFutureDtPymt the new allow future dt pymt
	 */
	public void setAllowFutureDtPymt(String allowFutureDtPymt) {
		this.allowFutureDtPymt = allowFutureDtPymt;
	}

	/**
	 * Gets the allow future dt pymt.
	 *
	 * @return the allow future dt pymt
	 */
	public String getAllowFutureDtPymt() {
		return allowFutureDtPymt;
	}

	/**
	 * Sets the max all fut dt pymt.
	 *
	 * @param maxAllFutDtPymt the new max all fut dt pymt
	 */
	public void setMaxAllFutDtPymt(long maxAllFutDtPymt) {
		this.maxAllFutDtPymt = maxAllFutDtPymt;
	}

	/**
	 * Gets the max all fut dt pymt.
	 *
	 * @return the max all fut dt pymt
	 */
	public long getMaxAllFutDtPymt() {
		return maxAllFutDtPymt;
	}
	
	
	// start - MFU File Upload - Ganga
	/** The inv id. */
	private long invId;
	
	private String invRefNo;
	
	private String supplierRef;
	
	private BigDecimal grossAmt;
	
	private BigDecimal grossAmtFrom;
	
	private BigDecimal grossAmtTo;
	
	private BigDecimal netAmt;
	
	private String netAmtCcy;
	
	private BigDecimal totAmtPayable;
	
	private String totAmtPayCcy;
	
	private BigDecimal minAmtPayable;
	
	private String minAmtCcy;
	
	private String discRuleId;
	
	private BigDecimal totDiscAmt;
	
	private String totDiscAmtCcy;
	
	private String pymtTerms;
	
	private String delNoteNo;
	
	private Date delNoteDate;
	
	private String shippingRefNo;
	
	private Date shippingRefDate;
	
	private String supplierAcctNo;
	
	private String invStatus;
	
	private Date invDueDate;
	
	private Date invDueDateFrom;
	
	private Date invDueDateTo;
	
	private String pymtStatus;
	
	private BigDecimal invRemAmt;
	
	private String inquiryDept;
	
	private String disputeDept;
	
	private String taxNumber;
	
	private BigDecimal disputeAmt;
	
	private BigDecimal totCNAmt;
	
	private int totLineItem;
	
	private int allocLineItem;
	
	private int attachmentCount;
	
	private AddressVO addressVO;
	
	private List<EippCreditNoteUtilVO> cnUtilVO;
	
	private DeptAllocMapVO deptAllocMap = new DeptAllocMapVO();
	
	private List<EippInvCntLineItemVO> lineItemVO= new ArrayList<EippInvCntLineItemVO>();
	
	private List<EippAuditVO> invoiceAuditList;
	
	private List<String> invStatusList;
	
	private AddressVO remitToAddr;
	
	private long defDeptPKId;
	
	private boolean enableRaiseDisputeInv = true;
	
	private boolean enableRaiseDisputeLI = true;
	
	private boolean aprroveEnableLI = true;
	
	private String allocType;
	
	private String alwNonFinProcess;
	
	private String useDfltBussRules;
	
	private long deptIdForAudit;
	
	private String oldStatus;
	
	//Added for EIPP Phase II Release File Inq
	private boolean modifiedInvoice;
	
    private List<AttachmentVO> attachmentList;
	
	private EippInvoiceBusinessRulesVO businessRulesVO;
	
	private int utilizedCNCount;
	
	private long originalInvId;
	
	private BigDecimal blockedAmt;
	
	private BigDecimal paidAmt;
	/** The lineItems List. */
	private List<String> lineItemsList;
	
	private String remarks;
	private BigDecimal latePymtAmt;
	
	/** The inv ref date. */
	private Calendar invRefDate;
	
	/** The inv issue date. */
	private Calendar invIssueDate;
	
	/** The late fee amount. */
	private BigDecimal lateFeeAmount;
	
	/** The early pymt rebate. */
	private BigDecimal earlyPymtRebate;
	
	/** The process flag. */
	private String processFlag;
	
	/* Added for payment prep process - end */
	
	//Added for EIPP Phase II-MFU
	/** The payment id. */
	private long paymentId;
	
	/** The pymt ref no. */
	private String pymtRefNo;
	
	/** The pymt due date. */
	private Date pymtDueDate;
	
	/** The pymt type. */
	private String pymtType;
	
	/** The custom field count. */
	private int customFieldCount;

	private List<TaxDtlsVO> taxDtls;
	
	private List<ConsgnmtVO> consgnmtDtls;
	
	private String matchStatus;
	
	private String isManual;
	
	private String rebateFeeFlag;
	
	private BigDecimal taxAdjustment;
	
	private BigDecimal totDisputedAmt;
	
	private boolean payAtFlag;
	// Added for ST Defect 6970 Starts
	private String isPmtOverdue;
	
	private BigDecimal netValue;
	
	public String getIsPmtOverdue() {
		return isPmtOverdue;
	}

	public void setIsPmtOverdue(String isPmtOverdue) {
		this.isPmtOverdue = isPmtOverdue;
	}
    // Added for ST Defect 6970 Ends
	public String getMatchStatus() {
		return matchStatus;
	}

	public void setMatchStatus(String matchStatus) {
		this.matchStatus = matchStatus;
	}

	/**
	 * Instantiates a new eipp invoice vo.
	 */
	public EippInvoiceVO() {
		remitToAddr = new AddressVO();
		attachmentList = new ArrayList<AttachmentVO>();
	}
 
	/**
	 * Gets the inv id.
	 *
	 * @return the invId
	 */
	public long getInvId() {
		return invId;
	}

	/**
	 * Sets the inv id.
	 *
	 * @param invId the invId to set
	 */
	public void setInvId(long invId) {
		this.invId = invId;
	}

	/**
	 * Gets the inv ref no.
	 *
	 * @return the invRefNo
	 */
	public String getInvRefNo() {
		return invRefNo;
	}

	/**
	 * Sets the inv ref no.
	 *
	 * @param invRefNo the invRefNo to set
	 */
	public void setInvRefNo(String invRefNo) {
		this.invRefNo = invRefNo;
	}

	/**
	 * Gets the supplier ref.
	 *
	 * @return the supplierRef
	 */
	public String getSupplierRef() {
		return supplierRef;
	}

	/**
	 * Sets the supplier ref.
	 *
	 * @param supplierRef the supplierRef to set
	 */
	public void setSupplierRef(String supplierRef) {
		this.supplierRef = supplierRef;
	}

	/**
	 * Gets the gross amt.
	 *
	 * @return the grossAmt
	 */
	public BigDecimal getGrossAmt() {
		return grossAmt;
	}

	/**
	 * Sets the gross amt.
	 *
	 * @param grossAmt the grossAmt to set
	 */
	public void setGrossAmt(BigDecimal grossAmt) {
		this.grossAmt = grossAmt;
	}

	/**
	 * Gets the net amt.
	 *
	 * @return the netAmt
	 */
	public BigDecimal getNetAmt() {
		return netAmt;
	}

	/**
	 * Sets the net amt.
	 *
	 * @param netAmt the netAmt to set
	 */
	public void setNetAmt(BigDecimal netAmt) {
		this.netAmt = netAmt;
	}

	/**
	 * Gets the tot amt payable.
	 *
	 * @return the totAmtPayable
	 */
	public BigDecimal getTotAmtPayable() {
		return totAmtPayable;
	}

	/**
	 * Sets the tot amt payable.
	 *
	 * @param totAmtPayable the totAmtPayable to set
	 */
	public void setTotAmtPayable(BigDecimal totAmtPayable) {
		this.totAmtPayable = totAmtPayable;
	}

	/**
	 * Gets the min amt payable.
	 *
	 * @return the minAmtPayable
	 */
	public BigDecimal getMinAmtPayable() {
		return minAmtPayable;
	}

	/**
	 * Sets the min amt payable.
	 *
	 * @param minAmtPayable the minAmtPayable to set
	 */
	public void setMinAmtPayable(BigDecimal minAmtPayable) {
		this.minAmtPayable = minAmtPayable;
	}

	/**
	 * Gets the disc rule id.
	 *
	 * @return the discRuleId
	 */
	public String getDiscRuleId() {
		return discRuleId;
	}

	/**
	 * Sets the disc rule id.
	 *
	 * @param discRuleId the discRuleId to set
	 */
	public void setDiscRuleId(String discRuleId) {
		this.discRuleId = discRuleId;
	}

	/**
	 * Gets the tot disc amt.
	 *
	 * @return the totDiscAmt
	 */
	public BigDecimal getTotDiscAmt() {
		return totDiscAmt;
	}

	/**
	 * Sets the tot disc amt.
	 *
	 * @param totDiscAmt the totDiscAmt to set
	 */
	public void setTotDiscAmt(BigDecimal totDiscAmt) {
		this.totDiscAmt = totDiscAmt;
	}

	/**
	 * Gets the pymt terms.
	 *
	 * @return the pymtTerms
	 */
	public String getPymtTerms() {
		return pymtTerms;
	}

	/**
	 * Sets the pymt terms.
	 *
	 * @param pymtTerms the pymtTerms to set
	 */
	public void setPymtTerms(String pymtTerms) {
		this.pymtTerms = pymtTerms;
	}

	/**
	 * Gets the del note no.
	 *
	 * @return the delNoteNo
	 */
	public String getDelNoteNo() {
		return delNoteNo;
	}

	/**
	 * Sets the del note no.
	 *
	 * @param delNoteNo the delNoteNo to set
	 */
	public void setDelNoteNo(String delNoteNo) {
		this.delNoteNo = delNoteNo;
	}

	/**
	 * Gets the del note date.
	 *
	 * @return the delNoteDate
	 */
	public Date getDelNoteDate() {
		return delNoteDate;
	}

	/**
	 * Sets the del note date.
	 *
	 * @param delNoteDate the delNoteDate to set
	 */
	public void setDelNoteDate(Date delNoteDate) {
		this.delNoteDate = delNoteDate;
	}

	/**
	 * Gets the shipping ref no.
	 *
	 * @return the shippingRefNo
	 */
	public String getShippingRefNo() {
		return shippingRefNo;
	}

	/**
	 * Sets the shipping ref no.
	 *
	 * @param shippingRefNo the shippingRefNo to set
	 */
	public void setShippingRefNo(String shippingRefNo) {
		this.shippingRefNo = shippingRefNo;
	}

	public String getIsManual() {
		return isManual;
	}

	public void setIsManual(String isManual) {
		this.isManual = isManual;
	}

	/**
	 * Gets the shipping ref date.
	 *
	 * @return the shippingRefDate
	 */
	public Date getShippingRefDate() {
		return shippingRefDate;
	}

	/**
	 * Sets the shipping ref date.
	 *
	 * @param shippingRefDate the shippingRefDate to set
	 */
	public void setShippingRefDate(Date shippingRefDate) {
		this.shippingRefDate = shippingRefDate;
	}

	public List<ConsgnmtVO> getConsgnmtDtls() {
		return consgnmtDtls;
	}

	public void setConsgnmtDtls(List<ConsgnmtVO> consgnmtDtls) {
		this.consgnmtDtls = consgnmtDtls;
	}

	/**
	 * Gets the supplier acct no.
	 *
	 * @return the supplierAcctNo
	 */
	public String getSupplierAcctNo() {
		return supplierAcctNo;
	}

	/**
	 * Sets the supplier acct no.
	 *
	 * @param supplierAcctNo the supplierAcctNo to set
	 */
	public void setSupplierAcctNo(String supplierAcctNo) {
		this.supplierAcctNo = supplierAcctNo;
	}

	/**
	 * Gets the inv status.
	 *
	 * @return the invStatus
	 */
	public String getInvStatus() {
		return invStatus;
	}

	/**
	 * Sets the inv status.
	 *
	 * @param invStatus the invStatus to set
	 */
	public void setInvStatus(String invStatus) {
		this.invStatus = invStatus;
	}

	/**
	 * Sets the inv due date.
	 *
	 * @param invDueDate the invDueDate to set
	 */
	public void setInvDueDate(Date invDueDate) {
		this.invDueDate = invDueDate;
	}

	/**
	 * Gets the inv due date.
	 *
	 * @return the invDueDate
	 */
	public Date getInvDueDate() {
		return invDueDate;
	}

	/**
	 * Sets the inv rem amt.
	 *
	 * @param invRemAmt the invRemAmt to set
	 */
	public void setInvRemAmt(BigDecimal invRemAmt) {
		this.invRemAmt = invRemAmt;
	}

	/**
	 * Gets the inv rem amt.
	 *
	 * @return the invRemAmt
	 */
	public BigDecimal getInvRemAmt() {
		return invRemAmt;
	}

	/**
	 * Sets the pymt status.
	 *
	 * @param pymtStatus the pymtStatus to set
	 */
	public void setPymtStatus(String pymtStatus) {
		this.pymtStatus = pymtStatus;
	}

	/**
	 * Gets the pymt status.
	 *
	 * @return the pymtStatus
	 */
	public String getPymtStatus() {
		return pymtStatus;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.vo.EippTransactionVO#getTransactionType()
	 */
	public String getTransactionType() {
		return "INV";
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.vo.EippTransactionVO#getRefNo()
	 */
	public String getRefNo(){
		return invRefNo;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.vo.EippTransactionVO#toDataString()
	 */
	public String toDataString()
	{
		DateAdapter adapter = new DateAdapter();
		Calendar calendar = Calendar.getInstance();
		StringBuilder builder = new StringBuilder();
		builder.append(getTransactionType() + ",");
		builder.append( getRefNo() + ",");
		builder.append( getBillType() + ",");
		if(invDueDate != null) {
			calendar.setTime(invDueDate);
			builder.append( adapter.marshal(calendar)+ ",");
		} 
		else {
			builder.append(",");
		}
		builder.append( getCcyCode() + ",");
		builder.append( getBuyerOrgId() + ",");
		builder.append( getSupplierOrgId() + ",");
		builder.append( getGrossAmt() + ",");
		return builder.toString();
	}

	/**
	 * Sets the inquiry dept.
	 *
	 * @param inquiryDept the inquiryDept to set
	 */
	public void setInquiryDept(String inquiryDept) {
		this.inquiryDept = inquiryDept;
	}

	/**
	 * Gets the inquiry dept.
	 *
	 * @return the inquiryDept
	 */
	public String getInquiryDept() {
		return inquiryDept;
	}

	/**
	 * Sets the dispute dept.
	 *
	 * @param disputeDept the disputeDept to set
	 */
	public void setDisputeDept(String disputeDept) {
		this.disputeDept = disputeDept;
	}

	/**
	 * Gets the dispute dept.
	 *
	 * @return the disputeDept
	 */
	public String getDisputeDept() {
		return disputeDept;
	}

	/**
	 * Sets the net amt ccy.
	 *
	 * @param netAmtCcy the netAmtCcy to set
	 */
	public void setNetAmtCcy(String netAmtCcy) {
		this.netAmtCcy = netAmtCcy;
	}

	/**
	 * Gets the net amt ccy.
	 *
	 * @return the netAmtCcy
	 */
	public String getNetAmtCcy() {
		return netAmtCcy;
	}

	/**
	 * Sets the tot amt pay ccy.
	 *
	 * @param totAmtPayCcy the totAmtPayCcy to set
	 */
	public void setTotAmtPayCcy(String totAmtPayCcy) {
		this.totAmtPayCcy = totAmtPayCcy;
	}

	/**
	 * Gets the tot amt pay ccy.
	 *
	 * @return the totAmtPayCcy
	 */
	public String getTotAmtPayCcy() {
		return totAmtPayCcy;
	}

	/**
	 * Sets the min amt ccy.
	 *
	 * @param minAmtCcy the minAmtCcy to set
	 */
	public void setMinAmtCcy(String minAmtCcy) {
		this.minAmtCcy = minAmtCcy;
	}

	/**
	 * Gets the min amt ccy.
	 *
	 * @return the minAmtCcy
	 */
	public String getMinAmtCcy() {
		return minAmtCcy;
	}

	/**
	 * Sets the tot disc amt ccy.
	 *
	 * @param totDiscAmtCcy the totDiscAmtCcy to set
	 */
	public void setTotDiscAmtCcy(String totDiscAmtCcy) {
		this.totDiscAmtCcy = totDiscAmtCcy;
	}

	/**
	 * Gets the tot disc amt ccy.
	 *
	 * @return the totDiscAmtCcy
	 */
	public String getTotDiscAmtCcy() {
		return totDiscAmtCcy;
	}

	/**
	 * Sets the tax number.
	 *
	 * @param taxNumber the taxNumber to set
	 */
	public void setTaxNumber(String taxNumber) {
		this.taxNumber = taxNumber;
	}

	/**
	 * Gets the tax number.
	 *
	 * @return the taxNumber
	 */
	public String getTaxNumber() {
		return taxNumber;
	}

	/**
	 * Gets the gross amt from.
	 *
	 * @return the gross amt from
	 */
	public BigDecimal getGrossAmtFrom() {
		return grossAmtFrom;
	}

	/**
	 * Sets the gross amt from.
	 *
	 * @param grossAmtFrom the new gross amt from
	 */
	public void setGrossAmtFrom(BigDecimal grossAmtFrom) {
		this.grossAmtFrom = grossAmtFrom;
	}

	/**
	 * Gets the gross amt to.
	 *
	 * @return the gross amt to
	 */
	public BigDecimal getGrossAmtTo() {
		return grossAmtTo;
	}

	/**
	 * Sets the gross amt to.
	 *
	 * @param grossAmtTo the new gross amt to
	 */
	public void setGrossAmtTo(BigDecimal grossAmtTo) {
		this.grossAmtTo = grossAmtTo;
	}

	/**
	 * Gets the inv due date from.
	 *
	 * @return the inv due date from
	 */
	public Date getInvDueDateFrom() {
		return invDueDateFrom;
	}

	/**
	 * Sets the inv due date from.
	 *
	 * @param invDueDateFrom the new inv due date from
	 */
	public void setInvDueDateFrom(Date invDueDateFrom) {
		this.invDueDateFrom = invDueDateFrom;
	}

	/**
	 * Gets the inv due date to.
	 *
	 * @return the inv due date to
	 */
	public Date getInvDueDateTo() {
		return invDueDateTo;
	}

	/**
	 * Sets the inv due date to.
	 *
	 * @param invDueDateTo the new inv due date to
	 */
	public void setInvDueDateTo(Date invDueDateTo) {
		this.invDueDateTo = invDueDateTo;
	}

	/**
	 * Gets the dispute amt.
	 *
	 * @return the dispute amt
	 */
	public BigDecimal getDisputeAmt() {
		return disputeAmt;
	}

	/**
	 * Sets the dispute amt.
	 *
	 * @param disputeAmt the new dispute amt
	 */
	public void setDisputeAmt(BigDecimal disputeAmt) {
		this.disputeAmt = disputeAmt;
	}

	/**
	 * Gets the tot cn amt.
	 *
	 * @return the tot cn amt
	 */
	public BigDecimal getTotCNAmt() {
		return totCNAmt;
	}

	/**
	 * Sets the tot cn amt.
	 *
	 * @param totCNAmt the new tot cn amt
	 */
	public void setTotCNAmt(BigDecimal totCNAmt) {
		this.totCNAmt = totCNAmt;
	}

	/**
	 * Gets the tot line item.
	 *
	 * @return the tot line item
	 */
	public int getTotLineItem() {
		return totLineItem;
	}

	/**
	 * Sets the tot line item.
	 *
	 * @param totLineItem the new tot line item
	 */
	public void setTotLineItem(int totLineItem) {
		this.totLineItem = totLineItem;
	}

	/**
	 * Gets the alloc line item.
	 *
	 * @return the alloc line item
	 */
	public int getAllocLineItem() {
		return allocLineItem;
	}

	/**
	 * Sets the alloc line item.
	 *
	 * @param allocLineItem the new alloc line item
	 */
	public void setAllocLineItem(int allocLineItem) {
		this.allocLineItem = allocLineItem;
	}

	/**
	 * Gets the cn util vo.
	 *
	 * @return the cn util vo
	 */
	public List<EippCreditNoteUtilVO> getCnUtilVO() {
		return cnUtilVO;
	}

	/**
	 * Sets the cn util vo.
	 *
	 * @param cnUtilVO the new cn util vo
	 */
	public void setCnUtilVO(List<EippCreditNoteUtilVO> cnUtilVO) {
		this.cnUtilVO = cnUtilVO;
	}

	/**
	 * Sets the address vo.
	 *
	 * @param addressVO the new address vo
	 */
	public void setAddressVO(AddressVO addressVO) {
		this.addressVO = addressVO;
	}

	/**
	 * Gets the address vo.
	 *
	 * @return the address vo
	 */
	public AddressVO getAddressVO() {
		return addressVO;
	}

	/**
	 * Sets the attachment count.
	 *
	 * @param attachmentCount the attachmentCount to set
	 */
	public void setAttachmentCount(int attachmentCount) {
		this.attachmentCount = attachmentCount;
	}

	/**
	 * Gets the attachment count.
	 *
	 * @return the attachmentCount
	 */
	public int getAttachmentCount() {
		return attachmentCount;
	}

	/**
	 * Sets the dept alloc map.
	 *
	 * @param deptAllocMap the deptAllocMap to set
	 */
	public void setDeptAllocMap(DeptAllocMapVO deptAllocMap) {
		this.deptAllocMap = deptAllocMap;
	}

	/**
	 * Gets the dept alloc map.
	 *
	 * @return the deptAllocMap
	 */
	public DeptAllocMapVO getDeptAllocMap() {
		return deptAllocMap;
	}

	/**
	 * Sets the line item vo.
	 *
	 * @param lineItemVO the lineItemVO to set
	 */
	public void setLineItemVO(List<EippInvCntLineItemVO> lineItemVO) {
		this.lineItemVO = lineItemVO;
	}

	/**
	 * Gets the line item vo.
	 *
	 * @return the lineItemVO
	 */
	public List<EippInvCntLineItemVO> getLineItemVO() {
		return lineItemVO;
	}

	/**
	 * Sets the invoice audit list.
	 *
	 * @param invoiceAuditList the invoiceAuditList to set
	 */
	public void setInvoiceAuditList(List<EippAuditVO> invoiceAuditList) {
		this.invoiceAuditList = invoiceAuditList;
	}

	/**
	 * Gets the invoice audit list.
	 *
	 * @return the invoiceAuditList
	 */
	public List<EippAuditVO> getInvoiceAuditList() {
		return invoiceAuditList;
	}

	/**
	 * Sets the inv status list.
	 *
	 * @param invStatusList the invStatusList to set
	 */
	public void setInvStatusList(List<String> invStatusList) {
		this.invStatusList = invStatusList;
	}

	/**
	 * Gets the inv status list.
	 *
	 * @return the invStatusList
	 */
	public List<String> getInvStatusList() {
		return invStatusList;
	}
	
	/**
	 * Sets the remit to addr.
	 *
	 * @param remitToAddr the remitToAddr to set
	 */
	public void setRemitToAddr(AddressVO remitToAddr) {
		this.remitToAddr = remitToAddr;
	}

	/**
	 * Gets the remit to addr.
	 *
	 * @return the remitToAddr
	 */
	public AddressVO getRemitToAddr() {
		return remitToAddr;
	}
	
	/**
	 * @return the defDeptPKId
	 */
	public long getDefDeptPKId() {
		return defDeptPKId;
	}

	/**
	 * @param defDeptPKId the defDeptPKId to set
	 */
	public void setDefDeptPKId(long defDeptPKId) {
		this.defDeptPKId = defDeptPKId;
	}

	/**
	 * Can utilize inv fully.
	 *
	 * @param cntRemAmt the cnt rem amt
	 * @return true, if successful
	 */
	private boolean canUtilizeInvFully(BigDecimal cntRemAmt) {
		BigDecimal amtToBeUtilized = getInvRemAmt().subtract(getBlockedAmt());
		return amtToBeUtilized.compareTo(cntRemAmt) <= 0;
	}
	
	/**
	 * Can utilize inv partially.
	 *
	 * @param cntRemAmt the cnt rem amt
	 * @return true, if successful
	 */
	private boolean canUtilizeInvPartially(BigDecimal cntRemAmt) {
		BigDecimal amtToBeUtilized = getInvRemAmt().subtract(getBlockedAmt());
		return amtToBeUtilized.compareTo(cntRemAmt) > 0;
	}
	
	/**
	 * Can fully utilize credit note.
	 *
	 * @param creditNote the credit note
	 * @return true, if successful
	 */
	public boolean canFullyUtilizeCreditNote(EippCreditNoteVO creditNote) {
		BigDecimal amtToBeUtilized = getInvRemAmt().subtract(getBlockedAmt());
		return amtToBeUtilized.compareTo(creditNote.getCntRemAmt()) >= 0;
	}
	
	/**
	 * Utilize cn against invoice.
	 *
	 * @param creditNoteVO the credit note vo
	 */
	public void utilizeCNAgainstInvoice(EippCreditNoteVO creditNoteVO) {
		BigDecimal cntRemAmt = creditNoteVO.getCntRemAmt();
		
		if (canUtilizeInvFully(cntRemAmt)) {
			creditNoteVO.updateUtilizationDetails(getInvRemAmt().subtract(getBlockedAmt()));
			
			if (getBlockedAmt() == null || 
					BigDecimal.ZERO.compareTo(getBlockedAmt()) == 0) {
				this.setInvStatus(StatusConstants.EIPP_INV_STATUS_CLOSED);
				this.setPymtStatus(StatusConstants.EIPP_FULLY_PAID);
				this.setInvRemAmt(BigDecimal.ZERO);
			} else {
				this.setInvRemAmt(getBlockedAmt());
			}
		} else if (canUtilizeInvPartially(cntRemAmt)) {
			this.setPymtStatus(StatusConstants.EIPP_PARTIALLY_PAID);
			creditNoteVO.updateUtilizationDetails(cntRemAmt);
			this.setInvRemAmt(this.getInvRemAmt().subtract(cntRemAmt));
		}
	}
	
	/**
	 * Can utilize cn.
	 *
	 * @param creditNoteVO the credit note vo
	 * @param timeZone the time zone
	 * @return true, if successful
	 */
	public boolean canUtilizeCN(EippCreditNoteVO creditNoteVO, TimeZone timeZone) {
		Date effectiveDate = creditNoteVO.getEffectiveDate();
		
		// Check this validation for time zone fix
		if (effectiveDate.before(new Date()) && 
			this.getIssueDate().before(effectiveDate)) {
			return false;
		}
		return true;
	}

	public void setEnableRaiseDisputeInv(boolean enableRaiseDisputeInv) {
		this.enableRaiseDisputeInv = enableRaiseDisputeInv;
	}

	public boolean isEnableRaiseDisputeInv() {
		return enableRaiseDisputeInv;
	}

	public void setEnableRaiseDisputeLI(boolean enableRaiseDisputeLI) {
		this.enableRaiseDisputeLI = enableRaiseDisputeLI;
	}

	public boolean isEnableRaiseDisputeLI() {
		return enableRaiseDisputeLI;
	}

	public void setAprroveEnableLI(boolean aprroveEnableLI) {
		this.aprroveEnableLI = aprroveEnableLI;
	}

	public boolean isAprroveEnableLI() {
		return aprroveEnableLI;
	}

	/**
	 * Sets the alloc type.
	 *
	 * @param allocType the new alloc type
	 */
	public void setAllocType(String allocType) {
		this.allocType = allocType;
	}

	/**
	 * Gets the alloc type.
	 *
	 * @return the alloc type
	 */
	public String getAllocType() {
		return allocType;
	}
	
	public boolean isCancelled() {
		return (StatusConstants.CANCEL_PENDING_EIPP_APPROVAL.equals(invStatus) || 
				StatusConstants.INVOICE_CANCELLED.equals(invStatus));
	}
	
	public String getAlwNonFinProcess() {
		return alwNonFinProcess;
	}

	public void setAlwNonFinProcess(String alwNonFinProcess) {
		this.alwNonFinProcess = alwNonFinProcess;
	}

	public String getUseDfltBussRules() {
		return useDfltBussRules;
	}

	public void setUseDfltBussRules(String useDfltBussRules) {
		this.useDfltBussRules = useDfltBussRules;
	}

	public void setDeptIdForAudit(long deptIdForAudit) {
		this.deptIdForAudit = deptIdForAudit;
	}

	public long getDeptIdForAudit() {
		return deptIdForAudit;
	}

	/**
	 * @param oldStatus the oldStatus to set
	 */
	public void setOldStatus(String oldStatus) {
		this.oldStatus = oldStatus;
	}

	/**
	 * @return the oldStatus
	 */
	public String getOldStatus() {
		return oldStatus;
	}

	public boolean isModifiedInvoice() {
		return modifiedInvoice;
	}

	public void setModifiedInvoice(boolean modifiedInvoice) {
		this.modifiedInvoice = modifiedInvoice;
	}
	
		public List<AttachmentVO> getAttachmentList() {
		return attachmentList;
	}

	public void setAttachmentList(List<AttachmentVO> attachmentList) {
		this.attachmentList = attachmentList;
	}
	
	public EippInvoiceBusinessRulesVO getBusinessRulesVO() {
		return businessRulesVO;
	}

	public void setBusinessRulesVO(EippInvoiceBusinessRulesVO businessRulesVO) {
		this.businessRulesVO = businessRulesVO;
	}

	public int getUtilizedCNCount() {
		return utilizedCNCount;
	}

	public void setUtilizedCNCount(int utilizedCNCount) {
		this.utilizedCNCount = utilizedCNCount;
	}

	public long getOriginalInvId() {
		return originalInvId;
	}

	public void setOriginalInvId(long originalInvId) {
		this.originalInvId = originalInvId;
	}

	/**
	 * @return the blockedAmt
	 */
	public BigDecimal getBlockedAmt() {
		return blockedAmt;
	}

	/**
	 * @param blockedAmt the blockedAmt to set
	 */
	public void setBlockedAmt(BigDecimal blockedAmt) {
		this.blockedAmt = blockedAmt;
	}

	/**
	 * @return the paidAmt
	 */
	public BigDecimal getPaidAmt() {
		return paidAmt;
	}

	/**
	 * @param paidAmt the paidAmt to set
	 */
	public void setPaidAmt(BigDecimal paidAmt) {
		this.paidAmt = paidAmt;
	}
	/* Added for payment prep process- start */		

	/**
	 * Gets the line items list.
	 *
	 * @return the line items list
	 */
	public List<String> getLineItemsList() {
		return lineItemsList;
	}

	/**
	 * Sets the line items list.
	 *
	 * @param lineItemsList the new line items list
	 */
	public void setLineItemsList(List<String> lineItemsList) {
		this.lineItemsList = lineItemsList;
	}

	/**
	 * Gets the inv ref date.
	 *
	 * @return the inv ref date
	 */
	public Calendar getInvRefDate() {
		return invRefDate;
	}

	/**
	 * Sets the inv ref date.
	 *
	 * @param invRefDate the new inv ref date
	 */
	public void setInvRefDate(Calendar invRefDate) {
		this.invRefDate = invRefDate;
	}

	/**
	 * Gets the inv issue date.
	 *
	 * @return the inv issue date
	 */
	public Calendar getInvIssueDate() {
		return invIssueDate;
	}

	/**
	 * Sets the inv issue date.
	 *
	 * @param invIssueDate the new inv issue date
	 */
	public void setInvIssueDate(Calendar invIssueDate) {
		this.invIssueDate = invIssueDate;
	}		

	/**
	 * Gets the late fee amount.
	 *
	 * @return the late fee amount
	 */
	public BigDecimal getLateFeeAmount() {
		return lateFeeAmount;
	}

	/**
	 * Sets the late fee amount.
	 *
	 * @param lateFeeAmount the new late fee amount
	 */
	public void setLateFeeAmount(BigDecimal lateFeeAmount) {
		this.lateFeeAmount = lateFeeAmount;
	}

	/**
	 * Gets the early pymt rebate.
	 *
	 * @return the early pymt rebate
	 */
	public BigDecimal getEarlyPymtRebate() {
		return earlyPymtRebate;
	}

	/**
	 * Sets the early pymt rebate.
	 *
	 * @param earlyPymtRebate the new early pymt rebate
	 */
	public void setEarlyPymtRebate(BigDecimal earlyPymtRebate) {
		this.earlyPymtRebate = earlyPymtRebate;
	}

	/**
	 * Gets the process flag.
	 *
	 * @return the process flag
	 */
	public String getProcessFlag() {
		return processFlag;
	}

	/**
	 * Sets the process flag.
	 *
	 * @param processFlag the new process flag
	 */
	public void setProcessFlag(String processFlag) {
		this.processFlag = processFlag;
	}
	
	/* Added for payment prep process- end */

	/**
	 * Gets the pymt type.
	 *
	 * @return the pymt type
	 */
	public String getPymtType() {
		return pymtType;
	}

	public void setPymtType(String pymtType) {
		this.pymtType = pymtType;
	}

	public int getCustomFieldCount() {
		return customFieldCount;
	}

	public void setCustomFieldCount(int customFieldCount) {
		this.customFieldCount = customFieldCount;
	}

	public long getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(long paymentId) {
		this.paymentId = paymentId;
	}

	public String getPymtRefNo() {
		return pymtRefNo;
	}

	public void setPymtRefNo(String pymtRefNo) {
		this.pymtRefNo = pymtRefNo;
	}

	public Date getPymtDueDate() {
		return pymtDueDate;
	}

	public void setPymtDueDate(Date pymtDueDate) {
		this.pymtDueDate = pymtDueDate;
	}

	public void setTotLineItemCnt(int totLineItemCnt) {
		this.totLineItemCnt = totLineItemCnt;
	}

	public int getTotLineItemCnt() {
		return totLineItemCnt;
	}
	
	public BigDecimal getLatePymtAmt() {
		return latePymtAmt;
	}

	public void setLatePymtAmt(BigDecimal latePymtAmt) {
		this.latePymtAmt = latePymtAmt;
	}
	
	public void setLnItmBlockdStatus(boolean lnItmBlockdStatus) {
		this.lnItmBlockdStatus = lnItmBlockdStatus;
	}

	public boolean isLnItmBlockdStatus() {
		return lnItmBlockdStatus;
	}

	public void setPmtAlreadyPrep(boolean pmtAlreadyPrep) {
		this.pmtAlreadyPrep = pmtAlreadyPrep;
	}

	public boolean isPmtAlreadyPrep() {
		return pmtAlreadyPrep;
	}
	
	public String getShippingTerms() {
		return shippingTerms;
	}

	/**
	 * Sets the allow bulk inv.
	 *
	 * @param allowBulkInv the new allow bulk inv
	 */
	public void setAllowBulkInv(String allowBulkInv) {
		this.allowBulkInv = allowBulkInv;
	}
	
	/**
	 * Gets the allow bulk inv.
	 *
	 * @return the allow bulk inv
	 */
	public String getAllowBulkInv() {
		return allowBulkInv;
	}

	/**
	 * Sets the button value.
	 *
	 * @param buttonValue the new button value
	 */
	public void setButtonValue(String buttonValue) {
		this.buttonValue = buttonValue;
	}

	public String getButtonValue() {
		return buttonValue;
	}
		public void setShippingTerms(String shippingTerms) {
		this.shippingTerms = shippingTerms;
	}

	public String getTaxpercent() {
		return taxpercent;
	}

	public void setTaxpercent(String taxpercent) {
		this.taxpercent = taxpercent;
	}
	
	
	public List<TaxDtlsVO> getTaxDtls() {
		return taxDtls;
	}

	public void setTaxDtls(List<TaxDtlsVO> taxDtls) {
		this.taxDtls = taxDtls;
	}
	
	public void setRebateFeeFlag(String rebateFeeFlag) {
		this.rebateFeeFlag = rebateFeeFlag;
	}

	public String getRebateFeeFlag() {
		return rebateFeeFlag;
	}

	public void setTaxAdjustment(BigDecimal taxAdjustment) {
		this.taxAdjustment = taxAdjustment;
	}

	public BigDecimal getTaxAdjustment() {
		return taxAdjustment;
	}

	public void setTotDisputedAmt(BigDecimal totDisputedAmt) {
		this.totDisputedAmt = totDisputedAmt;
	}

	public BigDecimal getTotDisputedAmt() {
		return totDisputedAmt;
	}

	public void setPayAtFlag(boolean payAtFlag) {
		this.payAtFlag = payAtFlag;
	}

	public boolean isPayAtFlag() {
		return payAtFlag;
	}

	/**
	 * @return the totalPymtCnt
	 */
	public long getTotalPymtCnt() {
		return totalPymtCnt;
	}

	/**
	 * @param totalPymtCnt the totalPymtCnt to set
	 */
	public void setTotalPymtCnt(long totalPymtCnt) {
		this.totalPymtCnt = totalPymtCnt;
	}
	
	private boolean isClosed() {
		return StatusConstants.EIPP_INV_STATUS_CLOSED.equals(
				invStatus);
	}
	
	private boolean isFullPymtInitiated() {
		BigDecimal actualRemAmt = getInvRemAmt().subtract(getBlockedAmt());
		return BigDecimal.ZERO.compareTo(actualRemAmt) == 0; 
	}
	
	/**
	 * Checks whether the invoice is a valid or invalid one for credit note utilization
	 * @return
	 */
	public String checkForValidInvoice() {
		String msg = null;
		if (isCancelled()) {
			msg = BNPConstants.EIPP_INV_CANCELLED;
		} else if (isClosed()) {
			msg = BNPConstants.EIPP_INV_CLOSED;
		} else if (isFullPymtInitiated()) {
			msg = BNPConstants.EIPP_INV_PYMT_INITIATED;
		} else if (remarks != null) {
			try {
				int statusCode = Integer.valueOf(remarks);
				
				if (statusCode == ErrorConstants.CONCURRENT_ACCESS) {
					msg = BNPConstants.INV_CONCURRENTLY_MODIFIED;
				}
			} catch (NumberFormatException e) {
				LOGGER.error("Error while converting remarks " + e.getMessage());
			}
		}
		return msg;
	}
	
	

	public BigDecimal getNetValue() {
		return netValue;
	}

	public void setNetValue(BigDecimal netValue) {
		this.netValue = netValue;
	}

	public void setDisablePymtAmt(boolean disablePymtAmt) {
		this.disablePymtAmt = disablePymtAmt;
	}

	public boolean isDisablePymtAmt() {
		return disablePymtAmt;
	}

	

}
