package com.bnp.eipp.services.matching.invoice.bindingvo;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for LineItems01 complex type.
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LineItems01">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="LnItmRefNo" type="{}Max35Text"/>
 *         &lt;element name="PartNo" type="{}Max288Text" minOccurs="0"/>
 *         &lt;element name="ItemDesc" type="{}Max384Text" minOccurs="0"/>
 *         &lt;element name="UOM" type="{}Max60Text" minOccurs="0"/>
 *         &lt;element name="ItemQty" type="{}QuantityType" minOccurs="0"/>
 *         &lt;element name="UnitPrice" type="{}CurrencyAndAmount_SimpleType" minOccurs="0"/>
 *         &lt;element name="TotalPrice" type="{}CurrencyAndAmount_SimpleType" minOccurs="0"/>
 *         &lt;element name="PONo" type="{}Max35Text" minOccurs="0"/>
 *         &lt;element name="TaxAmt" type="{}CurrencyAndAmount_SimpleType" minOccurs="0"/>
 *         &lt;element name="TaxRate" type="{}Rate_SimpleType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LineItems01", propOrder = { "lnItmRefNo", "partNo", "itemDesc", "uom", "itemQty", "unitPrice",
		"totalPrice", "poNo", "taxAmt", "taxRate" })
public class LineItems01 {

	@XmlElement(name = "LnItmRefNo", required = true)
	protected String lnItmRefNo;

	@XmlElement(name = "PartNo")
	protected String partNo;

	@XmlElement(name = "ItemDesc")
	protected String itemDesc;

	@XmlElement(name = "UOM")
	protected String uom;

	@XmlElement(name = "ItemQty")
	protected BigDecimal itemQty;

	@XmlElement(name = "UnitPrice")
	protected BigDecimal unitPrice;

	@XmlElement(name = "TotalPrice")
	protected BigDecimal totalPrice;

	@XmlElement(name = "PONo")
	protected String poNo;

	@XmlElement(name = "TaxAmt")
	protected BigDecimal taxAmt;

	@XmlElement(name = "TaxRate")
	protected BigDecimal taxRate;

	/**
	 * Gets the value of the lnItmRefNo property.
	 * @return possible object is {@link String }
	 */
	public String getLnItmRefNo() {
		return lnItmRefNo;
	}

	/**
	 * Sets the value of the lnItmRefNo property.
	 * @param value allowed object is {@link String }
	 */
	public void setLnItmRefNo(String value) {
		this.lnItmRefNo = value;
	}

	/**
	 * Gets the value of the partNo property.
	 * @return possible object is {@link String }
	 */
	public String getPartNo() {
		return partNo;
	}

	/**
	 * Sets the value of the partNo property.
	 * @param value allowed object is {@link String }
	 */
	public void setPartNo(String value) {
		this.partNo = value;
	}

	/**
	 * Gets the value of the itemDesc property.
	 * @return possible object is {@link String }
	 */
	public String getItemDesc() {
		return itemDesc;
	}

	/**
	 * Sets the value of the itemDesc property.
	 * @param value allowed object is {@link String }
	 */
	public void setItemDesc(String value) {
		this.itemDesc = value;
	}

	/**
	 * Gets the value of the uom property.
	 * @return possible object is {@link String }
	 */
	public String getUOM() {
		return uom;
	}

	/**
	 * Sets the value of the uom property.
	 * @param value allowed object is {@link String }
	 */
	public void setUOM(String value) {
		this.uom = value;
	}

	/**
	 * Gets the value of the itemQty property.
	 * @return possible object is {@link BigDecimal }
	 */
	public BigDecimal getItemQty() {
		return itemQty;
	}

	/**
	 * Sets the value of the itemQty property.
	 * @param value allowed object is {@link BigDecimal }
	 */
	public void setItemQty(BigDecimal value) {
		this.itemQty = value;
	}

	/**
	 * Gets the value of the unitPrice property.
	 * @return possible object is {@link BigDecimal }
	 */
	public BigDecimal getUnitPrice() {
		return unitPrice;
	}

	/**
	 * Sets the value of the unitPrice property.
	 * @param value allowed object is {@link BigDecimal }
	 */
	public void setUnitPrice(BigDecimal value) {
		this.unitPrice = value;
	}

	/**
	 * Gets the value of the totalPrice property.
	 * @return possible object is {@link BigDecimal }
	 */
	public BigDecimal getTotalPrice() {
		return totalPrice;
	}

	/**
	 * Sets the value of the totalPrice property.
	 * @param value allowed object is {@link BigDecimal }
	 */
	public void setTotalPrice(BigDecimal value) {
		this.totalPrice = value;
	}

	/**
	 * Gets the value of the poNo property.
	 * @return possible object is {@link String }
	 */
	public String getPONo() {
		return poNo;
	}

	/**
	 * Sets the value of the poNo property.
	 * @param value allowed object is {@link String }
	 */
	public void setPONo(String value) {
		this.poNo = value;
	}

	/**
	 * Gets the value of the taxAmt property.
	 * @return possible object is {@link BigDecimal }
	 */
	public BigDecimal getTaxAmt() {
		return taxAmt;
	}

	/**
	 * Sets the value of the taxAmt property.
	 * @param value allowed object is {@link BigDecimal }
	 */
	public void setTaxAmt(BigDecimal value) {
		this.taxAmt = value;
	}

	/**
	 * Gets the value of the taxRate property.
	 * @return possible object is {@link BigDecimal }
	 */
	public BigDecimal getTaxRate() {
		return taxRate;
	}

	/**
	 * Sets the value of the taxRate property.
	 * @param value allowed object is {@link BigDecimal }
	 */
	public void setTaxRate(BigDecimal value) {
		this.taxRate = value;
	}

}
