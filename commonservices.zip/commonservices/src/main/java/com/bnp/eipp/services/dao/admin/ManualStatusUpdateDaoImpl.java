/***************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 *
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 *
 * Created on:   29 AUG 2012
 *
 * Purpose:     Manual Status Update Screen
 *
 * Change History:
 * Date                                                  Author                                                                                  Reason
 * ----------------------------------------------------------------------------------------------------------------------------------------------------
 * 29 AUG 2012                      Oracle Financial Services Software Ltd                                    Initial Version
 * 30 OCT 2012                      RAJA									                                   EVENTS ST FIX
 * 01 Nov 2012           			Arun G                                    									ST events fix
 ***************************************************************************/



package com.bnp.eipp.services.dao.admin;

//~--- non-JDK imports --------------------------------------------------------

import com.bnp.eipp.services.vo.admin.ManualStausUpdateVO;
import com.bnp.scm.services.common.dao.AbstractCommonDaoImpl;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.vo.NameValueVO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

//~--- JDK imports ------------------------------------------------------------

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class ManualStatusUpdateDaoImpl<MStausUpdateVO> extends AbstractCommonDaoImpl implements IManualStatusUpdateDao {

    /** Field GET_BUY_ORG_ID_FOR_USER */
    private static final String GET_BUY_ORG_ID_FOR_USER = "mangetBuyerOrgListForUser";

    /** Field GET_MKT_ORG_ID_FOR_USER */
    private static final String GET_MKT_ORG_ID_FOR_USER = "mangetMktOrgListForUser";

    /** Field GET_SUMMARY_GRID_RECORDS */
    private static final String GET_SUMMARY_GRID_RECORDS = "mangetSummaryGrid";

    /** Field GET_SUP_ORG_ID_FOR_USER */
    private static final String GET_SUP_ORG_ID_FOR_USER = "mangetSupOrgListForUser";

    /** Field LOGGER */
    private static final Logger LOGGER = LoggerFactory.getLogger(ManualStatusUpdateDaoImpl.class);

    /** Field MAKER_CHECKER_CHECK */
    private static final String MAKER_CHECKER_CHECK = "manmakerCheckerCheck";

    /** Field NAME_SPACE */
    private static final String NAME_SPACE = "PaymentOperationNS.";

    /** Field UPDATE_STATUS_IN_MASTER */
    private static final String UPDATE_STATUS_IN_MASTER = "manapproveStatusInMaster";

    /** Field UPDATE_STATUS_IN_MASTER_SAVE */
    private static final String UPDATE_STATUS_IN_MASTER_SAVE = "mansaveStatusInMaster";

    /** Field UPDATE_TXN_TIMESTAMP */
    private static final String UPDATE_TXN_TIMESTAMP = "manupdateTxnTimestamp";
    

    /** Field UPDATE_TXN_TIMESTAMP */
    private static final String RESET_TXN_TIMESTAMP = "manResetTxnTimestamp";
    
    /** Field UPDATE_INVOICE_STATUS */
    private static final String UPDATE_INVOICE_STATUS = "manUpdateInvoceStatus";
    
    private static final String UPDATE_PAYMENT_STATUS_IN_MASTER = "manUpdatePaymentStatusInMaster";
    
    private static final String GET_CLOSED_INV = "getClosedInvIDs";

    /**
     * Method getNameSpace
     *
     *
     * @return a value of String
     */
    @Override
    public String getNameSpace() {
        return NAME_SPACE;
    }

    /**
     * Method listbuyerorgid
     *
     *
     * @param userId of type String
     * @param userTypeId of type String
     *
     * @return a value of List<NameValueVO>
     *
     * @throws BNPApplicationException
     */
    @Override
    public List<NameValueVO> listBuyerOrgId(String userId, String userTypeId) throws BNPApplicationException {
        List<NameValueVO>       buyerOrgList = null;
        HashMap<String, String> param        = new HashMap<String, String>();

        param.put("userId", userId);
        param.put("userTypeId", userTypeId);

        try {
            buyerOrgList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_BUY_ORG_ID_FOR_USER),
                    param);
        } catch (DataAccessException e) {
            LOGGER.error("Error While fetching Buyer Org ID for User  in Manual Status Update Code " + e.getMessage());

            throw new DBException(ErrorConstants.ERROR_CONDITION_FETCH);
        }

        return buyerOrgList;
    }

    /**
     * Method listsupplierorgid
     *
     *
     * @param userId of type String
     * @param userTypeId of type String
     *
     * @return a value of List<NameValueVO>
     *
     * @throws BNPApplicationException
     */
    @Override
    public List<NameValueVO> listSupplierOrgId(String userId, String userTypeId) throws BNPApplicationException {
        List<NameValueVO>       supOrgList = null;
        HashMap<String, String> param      = new HashMap<String, String>();
        param.put("userId", userId);
        param.put("userTypeId", userTypeId);
        try {
            supOrgList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_SUP_ORG_ID_FOR_USER),
                    param);
        } catch (DataAccessException e) {
            LOGGER.error("Error While fetching Supplier Org ID for User  in Manual Status Update Code "
                         + e.getMessage());

            throw new DBException(ErrorConstants.ERROR_CONDITION_FETCH);
        }

        return supOrgList;
    }

    /**
     * Method listmarketplaceorgid
     *
     *
     * @param userId of type String
     * @param userTypeId of type String
     *
     * @return a value of List<NameValueVO>
     *
     * @throws BNPApplicationException
     */
    @Override
    public List<NameValueVO> listMarketplaceOrgId(String userId, String userTypeId) throws BNPApplicationException {
        List<NameValueVO>       mktOrgList = null;
        HashMap<String, String> param      = new HashMap<String, String>();
        param.put("userId", userId);
        param.put("userTypeId", userTypeId);
        try {
            mktOrgList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_MKT_ORG_ID_FOR_USER),
                    param);
        } catch (DataAccessException e) {
            LOGGER.error("Error While Market Place Supplier Org ID for User  in Manual Status Update Code "
                         + e.getMessage());

            throw new DBException(ErrorConstants.ERROR_CONDITION_FETCH);
        }

        return mktOrgList;
    }

    /**
     * Method getSummaryGridRecords
     *
     *
     * @param dataVO of type ManualStausUpdateVO
     *
     * @return a value of List<ManualStausUpdateVO>
     *
     * @throws BNPApplicationException
     */
    @Override
    public List<ManualStausUpdateVO> getSummaryGridRecords(ManualStausUpdateVO dataVO) throws BNPApplicationException {
        List<ManualStausUpdateVO> summaryList = null;

        try {
            summaryList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_SUMMARY_GRID_RECORDS),dataVO);
         // R7.0 Fortify issues
            //LOGGER.debug("dao-MANUALsTATUSUPDATE_SUMMARY: " + summaryList);
        } catch (DataAccessException ex) {
            LOGGER.error(ex.getMessage());
            throw new DBException(ErrorConstants.ERROR_CONDITION_FETCH);
        }

        return summaryList;
    }

    /**
     * Method approveRecordForManualStatus
     *
     *
     * @param approveVO of type ManualStausUpdateVO
     *
     * @return a value of int
     *
     * @throws BNPApplicationException
     */
    @Override
    public void approveRecordForManualStatus(ManualStausUpdateVO approveVO) throws BNPApplicationException {
        
        String errro=null;
      
        try {

            try{
    	//		Integer errorCode=0;
    			Map <String,Object> map = new HashMap<String,Object>();
    			map.put("orgId", approveVO.getSupplierOrgId());
    //			map.put("paymentId" , new java.lang.Long(approveVO.getPymtId()));
    			map.put("paymentId" , Long.valueOf(approveVO.getPymtId()));
    			map.put("paymentAmt" , approveVO.getPymtAmt().longValue()); 
    			map.put("paymentCcy" , approveVO.getCurrency());
    			map.put("paymentStatus" , approveVO.getNewFinancialStatus());
    			map.put("userId" , approveVO.getUserId());
    			map.put("action" , "ManualStatusUpdate");
    	//		errro = (String) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(UPDATE_PAYMENT_STATUS_IN_MASTER), map);
    			getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(UPDATE_PAYMENT_STATUS_IN_MASTER), map);
    			errro = (String) map.get("currentRecordStatus");
    			if(errro != null && errro.equals("1000007"))
    			{
    				throw new BNPApplicationException(ErrorConstants.AMT_NOT_MATCH);
    			}
    		} catch (DataAccessException e) {
    			logger.error("Error while updating batchid in master table " + e.getMessage());
    			throw new DBException(ErrorConstants.DATABASE_ERROR);
    		}
            
             getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_STATUS_IN_MASTER),
                    approveVO);
            
            
        } catch (DataAccessException e) {
            LOGGER.error("Error While Approve Record for User  in Manual Status Update Code " + e.getMessage());
        }
    }

    /**
     * Method saveRecordManual
     *
     *
     * @param selectedData of type ManualStausUpdateVO
     *
     * @return a value of int
     *
     * @throws BNPApplicationException
     */
    @Override
    public int saveRecordManual(ManualStausUpdateVO selectedData) throws BNPApplicationException {
    	int save = 0;

        try {
        	save = getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_STATUS_IN_MASTER_SAVE), selectedData);
        } catch (DataAccessException e) {
            LOGGER.error("Error While saving Record for User  in Manual Status Update Code " + e.getMessage());
        }

        return save;
    }

    /**
     * Method makerChecker
     *
     *
     * @param approveVO of type ManualStausUpdateVO
     *
     * @return a value of int
     *
     * @throws BNPApplicationException
     */
    @Override
    public int makerChecker(ManualStausUpdateVO approveVO) throws BNPApplicationException {
    	int count =0;
    	try {
    		count =   (Integer) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(MAKER_CHECKER_CHECK),
                approveVO);
    	}
    	catch (DataAccessException e) {
    		logger.error("Problem while doing maker checker check " + e);
    		throw new DBException(ErrorConstants.DATABASE_ERROR);
    	}
    	return count;
    }

    /**
     * Method updateTxnTimestamp
     *
     *
     * @param txnObject of type Object
     *
     * @return a value of int
     *
     * @throws BNPApplicationException
     */
    public int updateTxnTimestamp(Object txnObject) throws BNPApplicationException {
        try {
            return getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_TXN_TIMESTAMP), txnObject);
        } catch (DataAccessException e) {
            logger.error("Problem while updating txn timestamp " + e);
            throw new DBException(ErrorConstants.DATABASE_ERROR);
        }
    }

	@Override
	public void resetProcessingFlagcheck(Object txnObj)
			throws BNPApplicationException {
		try {
             getSqlMapClientTemplate().update(getQueryNameWithNameSpace(RESET_TXN_TIMESTAMP), txnObj);
        } catch (DataAccessException e) {
            logger.error("Problem while updating txn timestamp " + e);
            throw new DBException(ErrorConstants.DATABASE_ERROR);
        }
		
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Long> getClosedInvIds(Long pymtId) throws BNPApplicationException{

		try {
			return getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_CLOSED_INV), pymtId);
		} catch (DataAccessException e) {
			logger.error("Problem while getting Closed invoice ID's " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
}



