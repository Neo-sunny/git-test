/***************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 *
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 *
 * Created on:
 *
 * Purpose:
 *
 * Change History:
 * Date                                                  Author                                                                                  Reason
 * ----------------------------------------------------------------------------------------------------------------------------------------------------
 *                       Oracle Financial Services Software Ltd                                    Initial Version
 * 30 OCT 2012           Raja																		Events ST fix           
 * 01 Nov 2012           Arun G                                    									ST events fix

 ***************************************************************************/



package com.bnp.eipp.services.dao.admin;

//~--- non-JDK imports --------------------------------------------------------

import com.bnp.eipp.services.vo.admin.ManualStausUpdateVO;
import com.bnp.scm.services.common.dao.IAbstractCommonDao;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

//~--- JDK imports ------------------------------------------------------------

import java.util.List;

public interface IManualStatusUpdateDao extends IAbstractCommonDao {

    /**
     * Method description
     *
     *
     * @param userId
     * @param userTypeId
     *
     * @return
     *
     * @throws BNPApplicationException
     */
    List<NameValueVO> listBuyerOrgId(String userId, String userTypeId) throws BNPApplicationException;

    /**
     * Method description
     *
     *
     * @param userId
     * @param userTypeId
     *
     * @return
     *
     * @throws BNPApplicationException
     */
    List<NameValueVO> listSupplierOrgId(String userId, String userTypeId) throws BNPApplicationException;

    /**
     * Method description
     *
     *
     * @param userId
     * @param userTypeId
     *
     * @return
     *
     * @throws BNPApplicationException
     */
    List<NameValueVO> listMarketplaceOrgId(String userId, String userTypeId) throws BNPApplicationException;

    /**
     * Method description
     *
     *
     * @param dataVO
     *
     * @return
     *
     * @throws BNPApplicationException
     */
    List<ManualStausUpdateVO> getSummaryGridRecords(ManualStausUpdateVO dataVO) throws BNPApplicationException;

    /**
     * Method description
     *
     *
     * @param approveVO
     *
     * @return
     *
     * @throws BNPApplicationException
     */
    void approveRecordForManualStatus(ManualStausUpdateVO approveVO) throws BNPApplicationException;

    /**
     * Method description
     *
     *
     * @param selectedData
     *
     * @return
     *
     * @throws BNPApplicationException
     */
    int saveRecordManual(ManualStausUpdateVO selectedData) throws BNPApplicationException;

    /**
     * Method description
     *
     *
     * @param approveVO
     *
     * @return
     *
     * @throws BNPApplicationException
     */
    int makerChecker(ManualStausUpdateVO approveVO) throws BNPApplicationException;

    /**
     * Method description
     *
     *
     * @param txnObj
     *
     * @return
     *
     * @throws BNPApplicationException
     */
    int updateTxnTimestamp(Object txnObj) throws BNPApplicationException;

    /**
     * Method description
     *
     *
     * @param txnObj
     *
     * @return
     *
     * @throws BNPApplicationException
     */
	void resetProcessingFlagcheck(Object txnObj) throws BNPApplicationException;
	
	List<Long> getClosedInvIds(Long pymtId) throws BNPApplicationException;
}



