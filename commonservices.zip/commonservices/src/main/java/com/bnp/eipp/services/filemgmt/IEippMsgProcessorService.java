/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   20 Sep 2012
 * 
 * Purpose:      IEippMsgProcessorService
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 20 Sep 2012        Oracle Financial Services Software Ltd                  Initial Version   
 * 17 Oct 2012        Prabakaran S                  						  Fix for ST # 6893 
************************************************************************************************************************************************************/
package com.bnp.eipp.services.filemgmt;

import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;

public interface IEippMsgProcessorService {
	
	AbstractMessage<?> prepareStandardEippMessage(
			FileDetailsVO detailsVO) throws BNPApplicationException;
	
	
	AbstractMessage<?> prepareCustomEippMessage(
			FileDetailsVO detailsVO) throws BNPApplicationException;
	
	void sendMessage(FileDetailsVO detailsVO, 
			AbstractMessage<?> invoiceMessage) throws BNPApplicationException;

}
