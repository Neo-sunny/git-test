/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 9, 2012
 * 
 * Purpose:      EippCustFieldsVO.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 9, 2012       Oracle Financial Services Software Ltd                  Initial Version  
************************************************************************************************************************************************************/

package com.bnp.eipp.services.invoice.vo;

import com.bnp.scm.services.common.vo.AbstractVO;

public class EippCustFieldsVO extends AbstractVO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5365806181071993881L;
	
	private long fkId;
	
	private String fieldName;
	
	private String fieldValue;

	/**
	 * @param fkId the fkId to set
	 */
	public void setFkId(long fkId) {
		this.fkId = fkId;
	}

	/**
	 * @return the fkId
	 */
	public long getFkId() {
		return fkId;
	}

	/**
	 * @param fieldName the fieldName to set
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	/**
	 * @return the fieldName
	 */
	public String getFieldName() {
		return fieldName;
	}

	/**
	 * @param fieldValue the fieldValue to set
	 */
	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}

	/**
	 * @return the fieldValue
	 */
	public String getFieldValue() {
		return fieldValue;
	}
	

}
