/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Jul 29, 201212:43:26 PM
 * 
 * Purpose:      IEippFileReleaseService.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Jul 29, 201212:43:26 PM        Oracle Financial Services Software Ltd                  Initial Version  
 *  14 Sep 2012						Prabakaran S										  Modified for EIPP Inv Attachments 
************************************************************************************************************************************************************/

package com.bnp.eipp.services.filemgmt;

import java.util.List;

import org.dozer.DozerBeanMapper;

import com.bnp.eipp.services.invoice.vo.EippTransactionVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.BNPRuntimeException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;

public interface IEippFileReleaseService {

	/**
	 * @param message
	 * @param detailsVO
	 * @param dataList
	 * @param beanMapper
	 * @param isAutoReleaseEnabled
	 * @throws BNPApplicationException
	 */
	<T extends EippTransactionVO> void releaseFile(AbstractMessage<?> message, FileDetailsVO detailsVO,
			List<T> dataList, DozerBeanMapper beanMapper,
			boolean isAutoReleaseEnabled) throws BNPApplicationException;

	
	/**
	 * @param valueObjectList
	 * @param detailsVO
	 * @throws BNPRuntimeException 
	 */
	<T extends EippTransactionVO> void insertFileDetailsIntoTrans(
			List<T> valueObjectList,FileDetailsVO detailsVO) throws BNPApplicationException;

	/**
	 * @param detailsVO
	 * @throws BNPApplicationException 
	 */
	void insertFileDetailsIntoMaster(FileDetailsVO detailsVO) throws BNPApplicationException;

	/**
	 * @param detailsVO
	 * @throws BNPApplicationException 
	 */
	void deleteFileDetailsFromTrans(FileDetailsVO detailsVO) throws BNPApplicationException;
	
	/**
	 * @param detailsVO
	 * @throws BNPApplicationException 
	 */
	void insertFileDetailsIntoHistFromTrans(FileDetailsVO detailsVO) throws BNPApplicationException;

	/**
	 * @param detailsVO
	 * @throws BNPApplicationException 
	 */
	void insertFileDetailsIntoHistFromMaster(FileDetailsVO detailsVO) throws BNPApplicationException;
	
	/**
	 * @param detailsVO
	 * @throws BNPApplicationException
	 */
	void deleteFile(FileDetailsVO detailsVO) throws BNPApplicationException;

}
