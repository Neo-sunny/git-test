/******************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 6, 20126:47:54 PM
 * 
 * Purpose:      IEippReleaseFileDao.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 6, 20126:47:54 PM        Oracle Financial Services Software Ltd                  Initial Version
 * 24 Sep 2012					Aarthi T											    Release File Inq - Rel 3.0 Matching and Reconcilation
 * 10 Oct 2012			  		Aarthi T												Release File Inq Payment details - Rel 3.0 Matching and Reconcilation
 * 17 Oct 2012					Sandhya R								   			    R3.0 Matchin Recon : Changes for auto match mail event
 * 25 Oct 2012					Prabu P								   			   		Email Event changes moved to EventLogDAO  
************************************************************************************************************************************************************/

package com.bnp.eipp.services.dao.filemgmt;

import java.util.List;

import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;

public interface IEippReleaseFileDao {
	
	void releaseFile(FileDetailsVO detailsVO) throws BNPApplicationException;

	NameValueVO getInvoiceTotalAmtForFile(long fileId, String fileUploadStatus)throws BNPApplicationException;

	NameValueVO getCntTotalAmtForFile(long fileId, String fileUploadStatus)throws BNPApplicationException;
	
	byte[] generateCreditNoteReportPdf(long cntId) throws BNPApplicationException;
	
	byte[] generateInvoiceReportPdf(long invId) throws BNPApplicationException;

	void updateFileStatusForRelease(FileDetailsVO detailsVO) throws BNPApplicationException;
	
	void updateFileStatusForDelete(FileDetailsVO detailsVO)throws BNPApplicationException;
	
	void deleteTransDetails(FileDetailsVO detailsVO)throws BNPApplicationException;

	void insertHistoryDetails(FileDetailsVO detailsVO)throws BNPApplicationException;
	
	void updateInvAndCNStatusInTrans(long fileId, String status)
		throws BNPApplicationException;
	
	void createInvoiceAudit(long fileId, 
			 String makerId,  String status, String action);
	
	//Start : Added for Rel 3.0 Matching and Reconcilation
	NameValueVO getMatchReconInvoiceCountForFile(long fileId, String status) throws BNPApplicationException;
	
	NameValueVO getMatchReconCntCountForFile(long fileId, String status) throws BNPApplicationException;
	
	NameValueVO getMatchReconPaymentCountForFile(long fileId, String status) throws BNPApplicationException;
	//Ends : Added for Rel 3.0 Matching and Reconcilation
	
	public void releaseFile4Matching(FileDetailsVO detailsVO) throws BNPApplicationException;
	
	
	void updateMatchInvAndCNStsInTrans(long fileId, String status)
	throws BNPApplicationException;
	
	void insertMatchHistoryDetails(FileDetailsVO detailsVO)
	throws BNPApplicationException;
	
	void deleteMatchTransDetails(FileDetailsVO detailsVO)
	throws BNPApplicationException;
	
	List<String> getMatchRefNoForFileId(long fileID) throws BNPApplicationException;
	
}
