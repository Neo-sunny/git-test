/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   08 Mar 12  
 * 
 * Purpose:      For generating functional acknowledgement
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 08 Mar 12                      Oracle Financial Services Software Ltd                                  FO Bo Integration Changes
 *                                  
 * 
 *****************************************************************************************************************************************************************/

package com.bnp.eipp.services.invoice;

import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.eipp.services.invoice.bindingvo.File;
import com.bnp.eipp.services.invoice.bindingvo.Header;
import com.bnp.eipp.services.invoice.bindingvo.Message;
import com.bnp.eipp.services.invoice.bindingvo.ObjectFactory;
import com.bnp.scm.services.txns.common.message.AbstractMessage;
import com.bnp.scm.services.txns.util.PropertiesReader;
import com.bnp.scm.services.txns.util.xml.XmlValidationEventHandler;

public class EippInvCntMessage extends AbstractMessage<Message> {

	private ObjectFactory factory;

	@Override
	public void createInstance() throws BNPApplicationException {
		this.factory = new ObjectFactory();
		this.header = new Header();
		this.body = new File();
		this.message = new Message();

	}	
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.IMessage#setBindingProperties()
	 */
	public void setBindingProperties() {
		this.properties.setBindingClass(Message.class);
		this.properties.setValidateXsd(true);
		this.properties.setXsdPath(PropertiesReader.getProperty("message.invcnt.xsd.path"));
		this.properties.setEventHandler(new XmlValidationEventHandler());
		this.setProperties(properties);
	}
	
	@Override
	public void createMessage() throws BNPApplicationException {
		this.setJaxbElementObj(factory.createMsg((Message)this.getMessage()));
	}
	
	/**
	 * @return the factory
	 */
	public ObjectFactory getFactory() {
		return factory;
	}

	/**
	 * @param factory the factory to set
	 */
	public void setFactory(ObjectFactory factory) {
		this.factory = factory;
	}
}
