/** ************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 03, 2012
 * 
 * Purpose:      EippInvGroupProcessor.java 
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 03, 2012                     Oracle Financial Services Software Ltd                                    Initial Version 
 * 07 Aug 2012						Vinoth Kumar M															  Sony Performance Tuning
 *  14 Sep 2012						Prabakaran S															  Modified for EIPP Inv Attachments
 *  28 Sep 2012						Ravishankar V															  Modified for EIPP sampling Issue Improper error description
 *  12 Oct 2012						Merdith 														  			Method Parameter changed for validating line item
 *  23 Oct 2012						Merdith 														  		Gross Value Changes for Line Item
 * 11 Nov 2012						Merdith 														  		SIT - 2892
 ***************************************************************************/

package com.bnp.eipp.services.invoice.group;



import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.math.Fraction;
import org.dozer.DozerBeanMapper;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.invoice.bindingvo.AdditionalInformation1;
import com.bnp.eipp.services.invoice.bindingvo.AdditionalInformation6;
import com.bnp.eipp.services.invoice.bindingvo.AttachmentData;
import com.bnp.eipp.services.invoice.bindingvo.FinancialInvoiceV01;
import com.bnp.eipp.services.invoice.bindingvo.LineItem10;
import com.bnp.eipp.services.invoice.bindingvo.PostalAddress6;
import com.bnp.eipp.services.invoice.bindingvo.TradeDelivery1;
import com.bnp.eipp.services.invoice.vo.AddressVO;
import com.bnp.eipp.services.invoice.vo.EippCustFieldsVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceBusinessRulesVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.common.vo.AttachmentVO;

@Component
@Scope ("prototype")
public class EippInvGroupProcessor<T> extends EippGroupProcessor<EippInvoiceVO> {

	private List<FinancialInvoiceV01> objectList;
	
	
	public EippInvGroupProcessor () {
		super();	
	}


	/**
	 * @return the objectList
	 */
	public List<FinancialInvoiceV01> getObjectList() {
		return objectList;
	}


	/**
	 * @param objectList the objectList to set
	 */
	public void setObjectList(List<FinancialInvoiceV01> objectList) {
		this.objectList = objectList;
	}
	
	private void populateMappingFiles() {
		mappingFiles = new ArrayList<String>();
		
		mappingFiles.add("mapper/EippCntMapper.xml");
		mappingFiles.add("mapper/EippInvMapper.xml");
		mappingFiles.add("mapper/EippLineItemMapper.xml");
		mappingFiles.add("mapper/EippCustFieldMapper.xml");
		mappingFiles.add("mapper/EippCustItmFldMapper.xml");
		mappingFiles.add("mapper/EippAddrMapper.xml"); 
		mappingFiles.add("mapper/EippAttachmentDataMapper.xml");
		beanMapper = new DozerBeanMapper(mappingFiles);
	}
	
	
	@Override
	public void processAndValidateData() throws BNPApplicationException {
		populateMappingFiles();
		List<EippInvoiceVO> invList = new ArrayList<EippInvoiceVO>();
		for (FinancialInvoiceV01 invoiceObj : objectList) {
			EippInvoiceVO eippInvoiceVO = beanMapper.map(
					invoiceObj, EippInvoiceVO.class);
			
			if(invoiceObj.getInvcHdr().getModInvc() != null){
				String modInv = invoiceObj.getInvcHdr().getModInvc().value();
				eippInvoiceVO.setModifiedInvoice((BNPConstants.MOD_INV_YES.equals(modInv)) ? true: false);
			}
			
			eippInvoiceVO.setPymtTerms(populatePaymentTerms(invoiceObj.getTradSttlm().getPmtTerms().getDesc()));
			
			if(eippInvoiceVO.getAttachmentCount() > 0 ){
				for (AttachmentData attachmentData : invoiceObj.getAttchmntDet().getAttachmentData()){
					AttachmentVO attachmentVO = beanMapper.map(
							attachmentData, AttachmentVO.class);
					attachmentVO.setFileId(detailsVO.getFileId());
					eippInvoiceVO.getAttachmentList().add(attachmentVO);
				}
			}
			
			if (invoiceObj.getTradDlvry() != null) {
				populateAddressDetails(invoiceObj.getTradDlvry(), eippInvoiceVO);
			}
			
			for (AdditionalInformation6 customField : invoiceObj.getInvcHdr().getInclNote()) {
				EippCustFieldsVO custFieldVO = beanMapper.map(
						customField, EippCustFieldsVO.class);
				eippInvoiceVO.getCustFields().add(custFieldVO);
			}
			
			for (LineItem10 lineItem : invoiceObj.getLineItm()) {
				
				EippInvCntLineItemVO eippInvCntLineItemVO = beanMapper.map(
										lineItem, EippInvCntLineItemVO.class);
				
				for (AdditionalInformation1 customLtmField : lineItem.getInclNote()) {
					EippCustFieldsVO custItmFieldVO = beanMapper.map(
							customLtmField, EippCustFieldsVO.class);
					eippInvCntLineItemVO.getCustFields().add(custItmFieldVO);
				}
				eippInvoiceVO.getLineItemList().add(eippInvCntLineItemVO);
			}
			invList.add(eippInvoiceVO);
		}
		validateInvoices(invList);
		
	}
	private String populatePaymentTerms(List<String> descList) {
		StringBuilder builder = new StringBuilder();
		
		for (String desc : descList) {
			builder.append(desc);
		}
		
		return builder.toString();
	}
	
	private void populateAddressDetails(TradeDelivery1 tradeDelivery,EippInvoiceVO eippInvoiceVO) {
		if (tradeDelivery.getBillTo() != null && tradeDelivery.getBillTo().getPstlAdr() != null) {
			eippInvoiceVO.setBillToAddr(getAddress(tradeDelivery.getBillTo().getPstlAdr()));
		}
		if (tradeDelivery.getShipTo() != null && tradeDelivery.getShipTo().getPstlAdr() != null) {
			eippInvoiceVO.setShipToAddr(getAddress(tradeDelivery.getShipTo().getPstlAdr()));
		}
		if (tradeDelivery.getRemitTo() != null && tradeDelivery.getRemitTo().getPstlAdr() != null) {
			eippInvoiceVO.setRemitToAddr(getAddress(tradeDelivery.getRemitTo().getPstlAdr()));
		}
	}
	private void validateInvoices(List<EippInvoiceVO> invList) throws BNPApplicationException {
		
		List<EippInvoiceVO> transList = new ArrayList<EippInvoiceVO>();
		
		Map<String, Integer> decimalMap = new HashMap<String, Integer>();
		for (EippInvoiceVO eippInvoiceVO : invList) {
			boolean isInvalid = false;
			
			if (eippInvoiceVO.getRefDate() == null) {
				eippInvoiceVO.setRefDate(eippInvoiceVO.getIssueDate());
			}
			
			isInvalid = validateOrgData(eippInvoiceVO);
			
			if (isInvalid) {
				validInvalidList.add(eippInvoiceVO);
				continue;
			}
			
			if(detailsVO.getSenderOrgType().equals(BNPConstants.MARKET_PLACE)){
			isInvalid = checkAllRecordHasSameCustomer(invList,eippInvoiceVO) || isInvalid ;
			}
			
			if(eippInvoiceVO.isModifiedInvoice()) {
				isInvalid = validateInvoiceAvailablity(eippInvoiceVO) || isInvalid;
			}
			// Code to fetch the Allocation type
			eippInvoiceVO.setAllocType(eippInvcUploadDAO.fetchAllocType(eippInvoiceVO));
			isInvalid = validateLineItemsData(eippInvoiceVO,eippInvoiceVO.getAllocType()) || isInvalid;
			
			isInvalid = validateDepartments(eippInvoiceVO) || isInvalid;
			
			isInvalid = validateSupplierAccountIdentifier(eippInvoiceVO) || isInvalid;
			
			if (isSourceDateLesser(eippInvoiceVO.getInvDueDate(), eippInvoiceVO.getIssueDate())) {
				
				addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
						ErrorConstants.ISSUE_DATE_SHOULD_LESSTHAN_DUEDATE, eippInvoiceVO);
				isInvalid = true;
			}
			
			if (isIssueDateFutureDate(eippInvoiceVO.getIssueDate(), detailsVO.getTimeZoneTZ())) {
				
				addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
						ErrorConstants.ISSUE_DATE_SHOULD_NOT_FUTURE, eippInvoiceVO);
				isInvalid = true;
			}
			
			if (eippInvoiceVO.getDiscRuleId() != null && !isDiscountRuleIdValid(eippInvoiceVO)) {
				
				addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
						ErrorConstants.DISCOUNT_RULE_ID_NOT_LINKED_TO_REBATE, eippInvoiceVO);
				isInvalid = true;
			}
			
			isInvalid = validateInvoiceAmounts(eippInvoiceVO) || isInvalid;
			isInvalid =  validateUniqueReference(eippInvoiceVO, transList) || isInvalid;
			
			if (!isInvalid) {
				int fractionalDigits = 0;
				String ccyCode = eippInvoiceVO.getCcyCode();
				
				// caching the data
				if (decimalMap.containsKey(ccyCode)) {
					fractionalDigits = decimalMap.get(eippInvoiceVO.getCcyCode());
				} else {
					fractionalDigits = invoiceUploadService.getCurrencyDecimals
															(eippInvoiceVO.getCcyCode());
					decimalMap.put(ccyCode, fractionalDigits);
				}
				eippInvoiceVO.setFractionalDigits(fractionalDigits);
				eippInvoiceVO.setBusinessRulesVO(getBusinessProcessingRules(eippInvoiceVO));
				
				if(eippInvoiceVO.isModifiedInvoice()){
					EippInvoiceVO invoice = getInvoiceForProcessing(eippInvoiceVO);
					
					int statusCode = checkForValidInvoice(invoice);
					
					if (statusCode == 0) {
						eippInvoiceVO.setOriginalInvId(invoice.getInvId());
						eippInvoiceVO.setRecordStatus("A");
						dataList.add(eippInvoiceVO);
					} else {
						isInvalid = true;
						addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
								statusCode, eippInvoiceVO);
					}
				} else {
					eippInvoiceVO.setRecordStatus("A");
					dataList.add(eippInvoiceVO);
				}
				validInvalidList.add(eippInvoiceVO);
			} else {
				validInvalidList.add(eippInvoiceVO);
			}
			
		}
	}
	
	private int checkForValidInvoice(EippInvoiceVO invoiceVO) {
		if (invoiceVO == null) {
			return ErrorConstants.INV_DETS_UNAVAILABLE_FOR_MODIFICATION;
		} else if (invoiceVO.getInvStatus().equals(StatusConstants.INVOICE_CANCELLED) ||
				 invoiceVO.getInvStatus().equals(StatusConstants.CANCEL_PENDING_EIPP_APPROVAL) ||
				 invoiceVO.getInvStatus().equals(StatusConstants.EIPP_INV_STATUS_CLOSED)) {
			return ErrorConstants.INVOICE_NOT_AVAILABLE_ALREADY_CLOSED_CANCELLED;
		} else if (BigDecimal.ZERO.compareTo(invoiceVO.getBlockedAmt()) < 0 || 
				   BigDecimal.ZERO.compareTo(invoiceVO.getPaidAmt()) < 0) {
			return ErrorConstants.INVOICE_NOT_AVAILABLE_PAYMENT_CREATED;
		} else if (invoiceVO.getUtilizedCNCount() > 0) {
			return ErrorConstants.INVOICE_NOT_AVAILABLE_CREDITNOTE_UTILIZED;
		}
		return 0;
	}
	
	private boolean validateUniqueReference(EippInvoiceVO eippInvoiceVO,List<EippInvoiceVO> transList)
	throws BNPApplicationException {
		boolean isInvalid = false;
		if (!eippInvoiceVO.isModifiedInvoice() && eippInvcUploadDAO.isUniqueCheckEnabled(getCustomerOrgId(eippInvoiceVO), 
				getCntpOrgId(eippInvoiceVO), eippInvoiceVO.getBillType())) {
			isInvalid = eippInvcUploadDAO.isInvoiceExists(eippInvoiceVO) ||
						checkUniqueReference(eippInvoiceVO, transList);
			if (isInvalid) {
				addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
						ErrorConstants.INVOICE_NOT_UNIQUE, eippInvoiceVO);
			} else {
				transList.add(eippInvoiceVO);
			}
		}
		return isInvalid;
	}
	
	private boolean checkUniqueReference(EippInvoiceVO eippInvoiceVO,List<EippInvoiceVO> transList) {
		boolean isInvalid = false;
		for (EippInvoiceVO transactionVO : transList) {
			if (eippInvoiceVO.getInvRefNo().equals(transactionVO.getInvRefNo()) &&
				isSameDates(eippInvoiceVO.getRefDate(), transactionVO.getRefDate()) &&
				eippInvoiceVO.getSupplierOrgId().equals(transactionVO.getSupplierOrgId())) {
				isInvalid = true;
				break;
			}
		}
		
		return isInvalid;
	}
	private boolean validateDepartments(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException {
		boolean isInvalid = false;
		
		if (!isNull(eippInvoiceVO.getInquiryDept()) && !eippInvcUploadDAO.isDepartmentAvailable(eippInvoiceVO.getBuyerOrgId(),
				eippInvoiceVO.getInquiryDept())) {
			addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
					ErrorConstants.INVALID_INQUIRY_DEPARTMENT, eippInvoiceVO);
			isInvalid = true;
		}
		
		if (!isNull(eippInvoiceVO.getDisputeDept()) && !eippInvcUploadDAO.isDepartmentAvailable(eippInvoiceVO.getSupplierOrgId(),
				eippInvoiceVO.getDisputeDept())) {
			addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
					ErrorConstants.INVALID_DISPUTE_DEPARTMENT, eippInvoiceVO);
			isInvalid = true;
		}
		return isInvalid;
	}
	
	/**
	 * Validate invoice amounts.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @return true, if successful
	 * @throws BNPApplicationException the bNP application exception
	 */
	private boolean validateInvoiceAmounts(EippInvoiceVO eippInvoiceVO) 
	throws BNPApplicationException {
		boolean isInvalid = false;
		if (eippInvoiceVO.getTotAmtPayable() !=null && eippInvoiceVO.getTotAmtPayable().compareTo
				(eippInvoiceVO.getGrossAmt().subtract(getBigDecimalValue(eippInvoiceVO.getTotDiscAmt()))) != 0) {
			addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
					ErrorConstants.EIPP_INVC_AMTS_MISMATCH, eippInvoiceVO);
			isInvalid = true;
		} else if(eippInvoiceVO.getTotAmtPayable() ==null) {
			eippInvoiceVO.setTotAmtPayable(
					eippInvoiceVO.getGrossAmt().subtract(getBigDecimalValue(eippInvoiceVO.getTotDiscAmt())));
			eippInvoiceVO.setTotAmtPayCcy(eippInvoiceVO.getCcyCode());
		}
		
		if (eippInvoiceVO.getNetAmt() != null && eippInvoiceVO.getTaxAmount() != null && (eippInvoiceVO.getNetAmt().compareTo
				(eippInvoiceVO.getGrossAmt().subtract(eippInvoiceVO.getTaxAmount())) != 0 ||
				eippInvoiceVO.getNetAmt().compareTo(eippInvoiceVO.getGrossAmt()) > 0)) {
			addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
					ErrorConstants.EIPP_INV_NET_AMT_MISMATCH, eippInvoiceVO);
		isInvalid = true;
		}/*else if(eippInvoiceVO.getNetAmt() == null && eippInvoiceVO.getTaxAmount() == null) {
			eippInvoiceVO.setNetAmt(eippInvoiceVO.getGrossAmt());
			eippInvoiceVO.setNetAmtCcy(eippInvoiceVO.getCcyCode());
		}else if(eippInvoiceVO.getTaxAmount() != null && eippInvoiceVO.getNetAmt() == null) {
			eippInvoiceVO.setNetAmt(eippInvoiceVO.getGrossAmt().subtract(eippInvoiceVO.getTaxAmount()));
			eippInvoiceVO.setNetAmtCcy(eippInvoiceVO.getCcyCode());
		}else if(eippInvoiceVO.getNetAmt() != null && eippInvoiceVO.getTaxAmount() == null &&
				eippInvoiceVO.getNetAmt().compareTo(eippInvoiceVO.getGrossAmt()) <=0) {
			eippInvoiceVO.setTaxAmount(eippInvoiceVO.getGrossAmt().subtract(eippInvoiceVO.getNetAmt()));
			eippInvoiceVO.setTaxAmtCcy(eippInvoiceVO.getCcyCode());
		}*/
		
		isInvalid=validateInvoiceAmtswithAllocType(eippInvoiceVO)||isInvalid;
		eippInvoiceVO.setInvRemAmt(eippInvoiceVO.getTotAmtPayable());
		return isInvalid;
	}
	private boolean validateSupplierAccountIdentifier(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException {
		boolean isInvalid = false;
		boolean acctIdRequired = eippInvcUploadDAO.isAccountIdentifierRequired(getCustomerOrgId(eippInvoiceVO), 
				getCntpOrgId(eippInvoiceVO), eippInvoiceVO.getBillType());
		if (acctIdRequired && isNull(eippInvoiceVO.getSupplierAcctNo())) {
			addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
					ErrorConstants.SUPPLIER_ACCT_IDNT_MANDATORY, eippInvoiceVO);
			isInvalid = true;
		} else if(acctIdRequired && !eippInvcUploadDAO.isAccountIdentifierExists(eippInvoiceVO.getSupplierOrgId(),
				eippInvoiceVO.getSupplierAcctNo())) {
			addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
					ErrorConstants.SUPPLIER_ACCT_IDNT_INVALID, eippInvoiceVO);
			isInvalid = true;
		}
		return isInvalid;
	}
	
	/**
	 * This method checks the discount rule is linked with rule type - Early payment rebate   
	 * @param discRuleId
	 * @return
	 * @throws BNPApplicationException 
	 */
	private boolean isDiscountRuleIdValid(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException {
		String ruleType = eippInvcUploadService.getRuleTypeForDiscountRuleId(eippInvoiceVO);
		if (ruleType != null && ruleType.equals("R")) {
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * Validates whether Invoice already exists in the system
	 * @param eippInvoiceCancelVO
	 * @throws BNPApplicationException 
	 */
	private boolean validateInvoiceAvailablity(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException {
		boolean isInvalid = false;
		int invoiceCount = eippInvcUploadService.isInvoiceAvailableInSystem(eippInvoiceVO);
		if(invoiceCount == 0 ){
			isInvalid = true;
			addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
					ErrorConstants.INV_DETS_UNAVAILABLE_FOR_MODIFICATION, eippInvoiceVO);
		}
		return isInvalid;
	}
	
	/**
	 * Gets the Invoice ID for file processing  
	 * @param eippInvoiceVO
	 * @return
	 * @throws BNPApplicationException 
	 */
	private EippInvoiceVO getInvoiceForProcessing(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException {
		List<EippInvoiceVO> invoiceList = (List<EippInvoiceVO>) eippInvcUploadService.getInvoiceListForValidation(eippInvoiceVO);
		return eippInvcUploadService.getInvoiceForProcessing(invoiceList);
	}
	
	/**
	 * @param eippInvoiceVO
	 * @return
	 * @throws BNPApplicationException 
	 */
	private EippInvoiceBusinessRulesVO getBusinessProcessingRules(
			EippInvoiceVO eippInvoiceVO) throws BNPApplicationException {

		EippInvoiceBusinessRulesVO businessRulesVO = new EippInvoiceBusinessRulesVO();
		if (detailsVO.getModelType().equals(BNPConstants.MODEL_TYPE_SCM)) {
			businessRulesVO = eippInvcUploadService.getBusinessProcessingRules(eippInvoiceVO.getSupplierOrgId(), 
					eippInvoiceVO.getBuyerOrgId(), eippInvoiceVO.getBillType());
		} else if (detailsVO.getModelType().equals(BNPConstants.MODEL_TYPE_BCM)){
			businessRulesVO = eippInvcUploadService.getBusinessProcessingRules(eippInvoiceVO.getBuyerOrgId(), 
					eippInvoiceVO.getSupplierOrgId(), eippInvoiceVO.getBillType());
		}
		return businessRulesVO;
	}
	
	private AddressVO getAddress(PostalAddress6 postalAddress) {
		AddressVO addressVO = beanMapper.map(postalAddress, AddressVO.class);
		if (postalAddress.getAdrTp() != null) {
			addressVO.setAddrType(postalAddress.getAdrTp().value());
		}
		if (postalAddress.getAdrLine() != null && !postalAddress.getAdrLine().isEmpty()) {
			populateAddrLines(postalAddress.getAdrLine(), addressVO);
		}
		return addressVO;
	}
	
	private void populateAddrLines(List<String> addrLines,AddressVO addressVO) {
		if (addrLines.size() > 0 && !isNull(addrLines.get(0))) {
			addressVO.setAddress1(addrLines.get(0));
		}
		if (addrLines.size() > 1 && !isNull(addrLines.get(1))) {
			addressVO.setAddress2(addrLines.get(1));
		}
		if (addrLines.size() > 2 && !isNull(addrLines.get(2))) {
			addressVO.setAddress3(addrLines.get(2));
		}
	}

	/**
	 * Validate invoice amtswith alloc type.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @return true, if successful
	 */
	private boolean validateInvoiceAmtswithAllocType(EippInvoiceVO eippInvoiceVO){
		boolean isInValid= false;
		BigDecimal taxRt = eippInvoiceVO.getTaxRate();
		BigDecimal taxAmt = eippInvoiceVO.getTaxAmount();
		BigDecimal netVal = eippInvoiceVO.getNetAmt();
		BigDecimal grossVal = eippInvoiceVO.getGrossAmt();
		BigDecimal totLItaxAmt= BigDecimal.ZERO;
		BigDecimal lisubTotal = BigDecimal.ZERO;
		BigDecimal ligrossVal= BigDecimal.ZERO;
		boolean isFromFile = false;
		if(taxRt!=null){
			isFromFile = true;
		}

	if(eippInvoiceVO.getAllocType()!=null && eippInvoiceVO.getAllocType().equalsIgnoreCase(BNPConstants.DEPT_ALLOC_TYPE_INVOICE)){
			// Set tax rate Tax Rate =  (Gross / net)-1  X 100%  if tax rate/netvale/taxamt is null
			if(taxRt==null && taxAmt!=null && netVal !=null && !BigDecimal.ZERO.equals(netVal) && grossVal!=null ){
				taxRt= (grossVal.divide(netVal,6,RoundingMode.HALF_UP).subtract(BigDecimal.ONE));
				eippInvoiceVO.setTaxRate(taxRt);
			}else if (taxRt==null && taxAmt==null && netVal !=null && grossVal!=null){ 
				// If gross - net is negative
				if(grossVal.compareTo(netVal)<0){
					addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
							ErrorConstants.INV_TAX_NEGATIV, eippInvoiceVO);
					isInValid = true;
				}else /*if (!BigDecimal.ZERO.equals(netVal)&& netVal!=null)*/{ //R5.0 - Sonar Fix - Feb21
					eippInvoiceVO.setTaxRate(grossVal.divide(netVal,6,RoundingMode.HALF_UP).subtract(BigDecimal.ONE));
					eippInvoiceVO.setTaxAmount(grossVal.subtract(netVal));
				}
				eippInvoiceVO.setTaxAmtCcy(eippInvoiceVO.getCcyCode());	
			}
			// If taxamt does not tally netVal* taxRate
			if(isFromFile && taxRt!=null && taxAmt!=null && !eippInvoiceVO.getTaxAmount().setScale(3).equals(netVal.multiply(taxRt).setScale(3))){
				addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
					ErrorConstants.INV_TAX_INVALID, eippInvoiceVO);
			isInValid = true;
			}else if (taxRt!=null && taxAmt==null && netVal!=null  ){
				eippInvoiceVO.setTaxAmount(grossVal.subtract(netVal));
				if(isFromFile && !eippInvoiceVO.getTaxAmount().setScale(3).equals(netVal.multiply(taxRt).setScale(3))){
					addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
							ErrorConstants.INV_GROSS_INVALID, eippInvoiceVO);
					isInValid = true;
				}
			}else if(taxRt!=null&& taxAmt==null && netVal==null){
				eippInvoiceVO.setNetAmt(grossVal.divide(BigDecimal.ONE.add(taxRt),eippInvoiceVO.getFractionalDigits()));
				eippInvoiceVO.setTaxAmount(grossVal); //R5.0 - Sonar Fix - Feb21 (grossVal.subtract(netVal))
			}
			if((taxAmt!=null || taxRt!=null) && netVal==null ){
				eippInvoiceVO.setNetAmt(grossVal.subtract(taxAmt));
				eippInvoiceVO.setNetAmtCcy(eippInvoiceVO.getCcyCode());
			}
			// If tax rate /taxamt and net value is null set tax rate/tax amt as 0 and net val as gross value
			if(taxAmt==null && taxRt==null && netVal==null ){
				eippInvoiceVO.setNetAmt(grossVal);
				eippInvoiceVO.setTaxRate(BigDecimal.ZERO);
				eippInvoiceVO.setTaxAmount(BigDecimal.ZERO);
				eippInvoiceVO.setNetAmtCcy(eippInvoiceVO.getCcyCode());
			}

		}else 
			if(eippInvoiceVO.getAllocType()!=null && eippInvoiceVO.getAllocType().equalsIgnoreCase(BNPConstants.DEPT_ALLOC_TYPE_LINEITEM)){
			// Set the line item gross/sub total/total tax
			for (EippInvCntLineItemVO lineItemVO : eippInvoiceVO.getLineItemList()) {
				totLItaxAmt = totLItaxAmt.add(getBigDecimalValue(lineItemVO.getTaxAmount().setScale(3)));
				lisubTotal = lisubTotal.add(getBigDecimalValue(lineItemVO.getItemSubTotal().setScale(3)));
				ligrossVal = ligrossVal.add(getBigDecimalValue(lineItemVO.getItemSubTotal().setScale(3)).add(getBigDecimalValue(lineItemVO.getTaxAmount())));
				lineItemVO.setItemGrossAmt(getBigDecimalValue(lineItemVO.getItemSubTotal()).add(getBigDecimalValue(lineItemVO.getTaxAmount())));
			}
			
			// Validate if tax amount equals line item tax amount 
			if(taxAmt!=null && !totLItaxAmt.equals(BigDecimal.ZERO)&& !taxAmt.setScale(3).equals(totLItaxAmt.setScale(3))){
				addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
						ErrorConstants.EIPP_LINEITEM_TAX_MISMATCH, eippInvoiceVO);
				isInValid = true;
			}
			if(taxAmt==null){
				eippInvoiceVO.setTaxAmount(totLItaxAmt);
				taxAmt = eippInvoiceVO.getTaxAmount();
			}
			
			// Validate if the invoice net value equals the line item sub total 
			if(netVal!=null && !netVal.setScale(3).equals(lisubTotal)){
				addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
						ErrorConstants.EIPP_LINEITEM_NET_MISMATCH, eippInvoiceVO);
				isInValid = true;
			}else if(netVal==null){
				eippInvoiceVO.setNetAmt(lisubTotal);
				netVal = eippInvoiceVO.getNetAmt();
			}
			if(taxRt==null && netVal !=null && !BigDecimal.ZERO.equals(netVal) /*&& grossVal!=null && !BigDecimal.ZERO.equals(grossVal)*/){ //R5.0 - Sonar Fix - Feb21
				eippInvoiceVO.setTaxRate(grossVal.divide(netVal,6,RoundingMode.HALF_UP).subtract(BigDecimal.ONE));
				taxRt= eippInvoiceVO.getTaxRate();
			}
			// Validate Invoice gross amt equals Line item gross amt 
			if(!grossVal.setScale(3).equals(ligrossVal.setScale(3))){
				addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
						ErrorConstants.EIPP_LINEITEM_GROSS_MISMATCH, eippInvoiceVO);
				isInValid = true;
			}// If tax rate is not null then Tax Rate =  (Gross / net)-1  X 100% 
			if(isFromFile && taxAmt!=null  && !BigDecimal.ZERO.equals(netVal) && taxRt!=null ){/*&& taxRt.equals(grossVal.divide(netVal,eippInvoiceVO.getFractionalDigits()).subtract(BigDecimal.ONE))){*/
				eippInvoiceVO.setNetAmt(grossVal.subtract(taxAmt));
			}else if(!isFromFile && taxAmt!=null  && !BigDecimal.ZERO.equals(netVal) && taxRt!=null &&  !taxRt.equals(grossVal.divide(netVal,6,RoundingMode.HALF_UP).subtract(BigDecimal.ONE))){
				addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
						ErrorConstants.EIPP_LINEITEM_TAXRATE_MISMATCH, eippInvoiceVO);
				isInValid = true;
			}
			// If tax rate is null then Tax Rate =  (Gross / net)-1  X 100% 
			if(taxRt==null && netVal!=null && !BigDecimal.ZERO.equals(netVal)){
				eippInvoiceVO.setTaxRate(grossVal.divide(netVal,6,RoundingMode.HALF_UP).subtract(BigDecimal.ONE));
				eippInvoiceVO.setNetAmt(grossVal.subtract(taxAmt));
			}
		}

		if ((eippInvoiceVO.getTotAmtPayCcy() !=null && !eippInvoiceVO.getCcyCode().equals(eippInvoiceVO.getTotAmtPayCcy())) || 
				(eippInvoiceVO.getTotDiscAmtCcy() != null && !eippInvoiceVO.getCcyCode().equals(eippInvoiceVO.getTotDiscAmtCcy()))) {
			addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
					ErrorConstants.EIPP_INVC_CCY_MISMATCH, eippInvoiceVO);
			isInValid = true;
		}
		
		if ((eippInvoiceVO.getNetAmtCcy() !=null && !eippInvoiceVO.getCcyCode().equals(eippInvoiceVO.getNetAmtCcy())) || 
				(eippInvoiceVO.getTaxAmtCcy() != null && !eippInvoiceVO.getCcyCode().equals(eippInvoiceVO.getTaxAmtCcy()))) {
			addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
					ErrorConstants.EIPP_INV_NET_AMT_CCY_MISMATCH, eippInvoiceVO);
			isInValid = true;
		}
		return isInValid;
	}
}
