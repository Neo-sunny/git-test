/******************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 6, 20126:48:13 PM
 * 
 * Purpose:      EippReleaseFileDaoImpl.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 6, 20126:48:13 PM        Oracle Financial Services Software Ltd                  Initial Version  
 * 14 Sep 2012					Prabakaran S	  								        Modified for EIPP Inv Attachments
 * 24 Sep 2012					Arun G 													sonar fix
 * 24 Sep 2012					Aarthi T											    Release File Inq - Rel 3.0 Matching and Reconcilation
 * 10 Oct 2012					Aarthi T								   			    Release File Inq Payment details - Rel 3.0 Matching and Reconcilation  
 * 17 Oct 2012					Sandhya R								   			    R3.0 Matchin Recon : Changes for auto match mail event
 * 25 Oct 2012					Prabu P								   			   		Email Event changes moved to EventLogDAO
*************************************************************************************************************************************************************/

package com.bnp.eipp.services.dao.filemgmt;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.dao.invoice.IEippInvoiceDao;
import com.bnp.eipp.services.invoice.util.EippAuditConstants;
import com.bnp.eipp.services.invoice.vo.EippAuditVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.report.util.ReportUtil;
import com.bnp.scm.services.report.vo.BrandingReportVO;
import com.ibatis.sqlmap.client.SqlMapExecutor;
import com.ibatis.sqlmap.engine.execution.BatchException;

@Component
public class EippReleaseFileDaoImpl extends SqlMapClientWrapper implements IEippReleaseFileDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(EippReleaseFileDaoImpl.class);

	private static final String INSERT_INVOICE_INTO_HISTORY = "insertInvoiceIntoHistory";

	private static final String INSERT_INVOICE_INTO_MASTER = "insertInvoiceIntoMaster";

	private static final String INSERT_INVOICE_DETAIL_INTO_HISTORY = "insertInvoiceDetIntoHistory";

	private static final String INSERT_INVOICE_DETAIL_INTO_MASTER = "insertInvoiceDetIntoMaster";

	private static final String INSERT_CN_INTO_HISTORY = "insertCreditNoteToHistory";

	private static final String INSERT_CN_INTO_MASTER = "insertCreditNoteToMaster";

	private static final String INSERT_CN_DET_INTO_HISTORY = "insertCreditNoteDetToHistory";

	private static final String INSERT_CN_DET_INTO_MASTER = "insertCreditNoteDetToMaster";

	private static final String INSERT_INV_CUSTOM_FIELDS_INTO_MASTER = "insertInvCustomFieldsToMaster";

	private static final String INSERT_INV_CUSTOM_FIELDS_INTO_HIST = "insertInvCustomFieldsToHist";

	private static final String INSERT_INV_DET_CUSTOM_FIELDS_INTO_MASTER = "insertInvDetCustomFieldsToMaster";

	private static final String INSERT_INV_DET_CUSTOM_FIELDS_INTO_HIST = "insertInvDetCustomFieldsToHist";

	private static final String INSERT_CN_CUSTOM_FIELDS_INTO_MASTER = "insertCNCustomFieldsToMaster";

	private static final String INSERT_CN_CUSTOM_FIELDS_INTO_HIST = "insertCNCustomFieldsToHist";

	private static final String INSERT_CN_DET_CUSTOM_FIELDS_INTO_MASTER = "insertCNDetCustomFieldsToMaster";

	private static final String INSERT_CN_DET_CUSTOM_FIELDS_INTO_HIST = "insertCNDetCustomFieldsToHist";

	private static final String DELETE_INVOICES_FROM_TRANS = "deleteInvoicesFromTrans";

	private static final String DELETE_INVOICE_DET_FROM_TRANS = "deleteInvoiceDetFromTrans";

	private static final String DELETE_INV_CUST_FIELDS_FROM_TRANS = "deleteInvoiceCustFieldsFromTrans";

	private static final String DELETE_INV_DET_CUST_FIELDS_FROM_TRANS = "deleteInvDetCustFieldsFromTrans";

	private static final String DELETE_CN_FROM_TRANS = "deleteCreditNotesFromTrans";

	private static final String DELETE_CN_DET_FROM_TRANS = "deleteCreditNoteDetFromTrans";

	private static final String DELETE_CN_CUST_FIELDS_FROM_TRANS = "deleteCNCustFieldsFromTrans";

	private static final String DELETE_CN_DET_CUST_FIELDS_FROM_TRANS = "deleteCNDetCustFieldsFromTrans";

	private static final String GET_TOTAL_DEL_INV_AMOUNT_FOR_FILE = "getTotalDelInvAmtForFile";

	private static final String GET_TOTAL_INVOICE_AMOUNT_FOR_FILE = "getTotalInvoiceAmtForFile";

	private static final String GET_TOTAL_CNT_AMOUNT_FOR_FILE_FROM_TRANS_MASTER="getTotalCntAmtForFileTransMaster";

	private static final String GET_TOTAL_CNT_AMOUNT_FOR_FILE_FROM_TRANS = "getTotalCntAmtForFileFromTrans";

	private static final String GET_TOTAL_CNT_AMOUNT_FOR_FILE_FROM_HIST = "getTotalCNAmtForFileFromHist";

	private static final String GET_CREDIT_NOTE_REPORT_DETAILS = "getCreditNoteReportDetails";

	private static final String GET_INVOICE_REPORT_DETAILS = "getInvoiceReportDetails";
	
	private static final String UPD_FILE_STATUS_FOR_RELEASE = "updateFileStatusForRelease";
	
	private static final String UPD_FILE_STATUS_FOR_DELETE = "updateFileStatusForDelete";
	
	private static final String INSERT_DELETED_INVOICE_INTO_HISTORY = "insertDeletedInvoiceIntoHistory";
	
	private static final String INSERT_DELETED_CN_INTO_HISTORY = "insertDeletedCreditNoteToHistory";
	
	private static final String UPDATE_INV_STATUS_IN_TRANS = "updateInvStatusInTrans";
	
	private static final String UPDATE_CN_STATUS_IN_TRANS = "updateCNStatusInTrans";
	
	private static final String CREATE_INV_AUDIT = "EippFileUpload.createInvoiceAudit";
	
	private static final String INSERT_INV_ATTACHMENTS = "insertInvoiceAttachment";
	
	private static final String DELETE_ATTACHMENTS_FROM_TRANS = "deleteAttachmentsFromTrans";
	
	// Start : Added for Rel 3.0 Matching and Reconcilation
	private static final String GET_TOTAL_DEL_MATCH_RECON_INV_COUNT_FOR_FILE = "getTotalDelMatchReconInvCountForFile";
	
	private static final String GET_TOTAL_MATCH_RECON_INVOICE_COUNT_FOR_FILE_FROM_TRANS_MASTER = "getTotalMatchReconInvoiceCountForFileTransMaster";
	
	private static final String GET_TOTAL_CNT_MATCH_RECON_COUNT_FOR_FILE_FROM_TRANS = "getTotalCntMatchReconCountForFile";
	
	private static final String GET_TOTAL_CNT_MATCH_RECON_COUNT_FOR_FILE_FROM_HIST = "getTotalCNMatchReconCountForFile";
	
	private static final String GET_TOTAL_CNT_MATCH_RECON_COUNT_FOR_FILE_FROM_TRANS_MASTER="getTotalCntMatchReconCountForFileTransMaster";
	
	private static final String GET_TOTAL_DEL_MATCH_RECON_PYMT_COUNT_FOR_FILE = "getTotalDelMatchReconPymtCountForFile";
	
	private static final String GET_TOTAL_MATCH_RECON_PYMT_COUNT_FOR_FILE_FROM_TRANS_MASTER = "getTotalMatchReconPymtCountForFileTransMaster";
	// Ends : Added for Rel 3.0 Matching and Reconcilation
	private static final String INSERT_MATCH_INVOICE_INTO_MASTER="MatchingRecon.insertMatchInvMasterFromTrans";
	
	private static final String INSERT_MATCH_INVOICE_INTO_HISTORY="MatchingRecon.insertMatchInvHistFromMaster";
	
	private static final String INSERT_MATCH_INV_CUSTOM_FIELDS_INTO_MASTER="MatchingRecon.insertMatchInvCustFldsMasterFromTrans";
	
	private static final String INSERT_MATCH_INV_CUSTOM_FIELDS_INTO_HIST="MatchingRecon.insertMatchInvCustFldsHisFromMaster";
	
	private static final String INSERT_MATCH_INVOICE_DETAIL_INTO_MASTER="MatchingRecon.insertMatchInvItmsMasterFromTrans";
	
	private static final String INSERT_MATCH_INVOICE_DETAIL_INTO_HISTORY="MatchingRecon.insertMatchInvItmsHistFromMaster";
	
	private static final String DELETE_MATCH_CUST_FIELDS_FROM_TRANS="MatchingRecon.deleteMatCustFieldsFromTrans";
	
	private static final String DELETE_MATCH_INVC_DTLS_FROM_TRANS="MatchingRecon.deleteMatchInvcDetFromTrans";
	
	private static final String DELETE_MATCH_INVC_FROM_TRANS="MatchingRecon.deleteMatchInvcsFromTrans";
	
	private static final String INSERT_MATCH_CN_INTO_MASTER="MatchingRecon.insertMatchCnMasterFromTrans";
	
	private static final String INSERT_MATCH_CN_LI_INTO_MASTER="MatchingRecon.insertMatchCnItmsMasterFromTrans";
	
	private static final String INSERT_MATCH_CN_INTO_HISTORY="MatchingRecon.insertMatchCntoHist";
	
	private static final String INSERT_MATCH_CN_LI_INTO_HISTORY="MatchingRecon.insertMatchCnItmsHistFromMaster";
	
	private static final String DELETE_MATCH_CN_DET_FROM_TRANS ="MatchingRecon.deleteMatchCreditNoteDetFromTrans";
	
	private static final String DELETE_MATCH_CN_FROM_TRANS="MatchingRecon.deleteMatchCreditNotesFromTrans";
	
	
	private static final String UPD_MAT_INV_RECORD_STS_IN_TRANS = "MatchingRecon.updMatchInvRecordStatusInTrans";
	
	private static final String UPD_MAT_INV_ITEMS_RECORD_STS_IN_TRANS = "MatchingRecon.updMatchInvItemRecordStatusInTrans";
	
	private static final String UPD_MAT_CN_RECORD_STS_IN_TRANS = "MatchingRecon.updMatchCNRecordStatusInTrans";
	
	private static final String UPD_MAT_CN_ITEMS_RECORD_STS_IN_TRANS = "MatchingRecon.updMatchCNItemRecordStatusInTrans";
	
	private static final String UPD_MAT_INV_CUSTOM_RECORD_STS_IN_TRANS = "MatchingRecon.updMatchInvCustomRecordStatusInTrans";
	
	private static final String INS_MAT_INVOICE_HISTORY_FROM_TRANS = "MatchingRecon.insertMatchInvHistFromTrans";
	private static final String INS_MAT_INVCUST_FLDS_HIST_FROM_TRANS = "MatchingRecon.insertMatchInvCustFldsHisFromTrans";
	private static final String INS_MAT_INVOICE_ITEMS_HISTORY_FROM_TRANS = "MatchingRecon.insertMatchInvItmsHistFromTrans";
	private static final String INS_MAT_CREDIT_NOTE_HISTORY_FROM_TRANS = "MatchingRecon.insertMatchCnHistFromTrans";
	private static final String INS_MAT_CREDIT_NOTE_ITEMS_HISTORY_FROM_TRANS = "MatchingRecon.insertMatchCnItmsHistFromTrans";
	
	private static final String GET_MATCH_REF_NOS = "MatchingRecon.getMatchRefNos";
	
	@Autowired
	private IEippInvoiceDao invoiceDao;

	/** The report util. */
	@Autowired
	private ReportUtil reportUtil;
	public EippReleaseFileDaoImpl() {
		this.nameSpace = "EippReleaseFileNS";
	}

	@Override
	public void releaseFile(FileDetailsVO detailsVO)
	throws BNPApplicationException {
		try {
			insertInvoiceAndLineItemsIntoMaster(detailsVO);
			deleteInvoicesAndLineItemsFromTrans(detailsVO);
			insertCNAndLineItemsIntoMaster(detailsVO);
			deleteCNAndLineItemsFromTrans(detailsVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error while releasing a file : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public void releaseFile4Matching(FileDetailsVO detailsVO) throws BNPApplicationException {
		
		try {
			insertMatchInvAndLineItmsIntoMaster(detailsVO);
			deleteMatInvsAndLineItemsFromTrans(detailsVO);
			insertMatchCNAndLineItemsIntoMaster(detailsVO);
			deleteMatCNAndLineItemsFromTrans(detailsVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error while releasing a file : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	private void deleteMatCNAndLineItemsFromTrans(
			FileDetailsVO detailsVO) throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().delete(DELETE_MATCH_CN_DET_FROM_TRANS, 
					detailsVO.getFileId());
			getSqlMapClientTemplate().delete(DELETE_MATCH_CN_FROM_TRANS, 
					detailsVO.getFileId());
		} catch (DataAccessException e) {
			LOGGER.error("Error while deleting credit notes : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	private void insertMatchCNAndLineItemsIntoMaster(FileDetailsVO detailsVO) throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(INSERT_MATCH_CN_INTO_MASTER, 
					detailsVO.getFileId());
			getSqlMapClientTemplate().insert(INSERT_MATCH_CN_INTO_HISTORY, 
					detailsVO.getFileId());
			getSqlMapClientTemplate().insert(INSERT_MATCH_CN_LI_INTO_MASTER, 
					detailsVO.getFileId());
			getSqlMapClientTemplate().insert(INSERT_MATCH_CN_LI_INTO_HISTORY, 
					detailsVO.getFileId());
		} catch (DataAccessException e) {
			LOGGER.error("Error while releasing credit notes : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	private void insertMatchInvAndLineItmsIntoMaster(FileDetailsVO detailsVO) 
	throws BNPApplicationException{
		try{
			getSqlMapClientTemplate().insert(INSERT_MATCH_INVOICE_INTO_MASTER, 
					detailsVO);
			getSqlMapClientTemplate().insert(INSERT_MATCH_INVOICE_INTO_HISTORY, 
					detailsVO);
			getSqlMapClientTemplate().insert(INSERT_MATCH_INV_CUSTOM_FIELDS_INTO_MASTER, 
					detailsVO);
			getSqlMapClientTemplate().insert(INSERT_MATCH_INV_CUSTOM_FIELDS_INTO_HIST, 
					detailsVO);
			getSqlMapClientTemplate().insert(INSERT_MATCH_INVOICE_DETAIL_INTO_MASTER, 
					detailsVO);
			getSqlMapClientTemplate().insert(INSERT_MATCH_INVOICE_DETAIL_INTO_HISTORY, 
					detailsVO);
		} catch(DataAccessException e){
			LOGGER.error("Error while inserting data in master table" +e.getMessage());
			
			//976332 CSCDEV-2683 17-NOV-2014:START
			//e.printStackTrace();
			LOGGER.error("Error while insertMatchInvAndLineItmsIntoMaster : " + e);
			//976332 CSCDEV-2683 17-NOV-2014:END
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	private void deleteMatInvsAndLineItemsFromTrans(
			FileDetailsVO detailsVO) throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().delete(DELETE_MATCH_CUST_FIELDS_FROM_TRANS, 
					detailsVO.getFileId());
			getSqlMapClientTemplate().delete(DELETE_MATCH_INVC_DTLS_FROM_TRANS, 
					detailsVO.getFileId());
			getSqlMapClientTemplate().delete(DELETE_MATCH_INVC_FROM_TRANS, 
					detailsVO.getFileId());
		} catch (DataAccessException e) {
			//976332 CSCDEV-2683 17-NOV-2014:START
			//e.printStackTrace();
			//976332 CSCDEV-2683 17-NOV-2014:END
			LOGGER.error("Error while deleting invoices : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	private void deleteInvoicesAndLineItemsFromTrans(
			FileDetailsVO detailsVO) throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(DELETE_INV_DET_CUST_FIELDS_FROM_TRANS), 
					detailsVO.getFileId());
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(DELETE_INVOICE_DET_FROM_TRANS), 
					detailsVO.getFileId());
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(DELETE_INV_CUST_FIELDS_FROM_TRANS), 
					detailsVO.getFileId());
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(DELETE_INVOICES_FROM_TRANS), 
					detailsVO.getFileId());
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(DELETE_ATTACHMENTS_FROM_TRANS), 
					detailsVO.getFileId());

		} catch (DataAccessException e) {
			LOGGER.error("Error while deleting invoices : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	private void deleteCNAndLineItemsFromTrans(
			FileDetailsVO detailsVO) throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(DELETE_CN_CUST_FIELDS_FROM_TRANS), 
					detailsVO.getFileId());
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(DELETE_CN_DET_CUST_FIELDS_FROM_TRANS), 
					detailsVO.getFileId());
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(DELETE_CN_DET_FROM_TRANS), 
					detailsVO.getFileId());
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(DELETE_CN_FROM_TRANS), 
					detailsVO.getFileId());
		} catch (DataAccessException e) {
			LOGGER.error("Error while deleting credit notes : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	private void insertCNAndLineItemsIntoMaster(FileDetailsVO detailsVO) throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_CN_INTO_MASTER), 
					detailsVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_CN_INTO_HISTORY), 
					detailsVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_CN_CUSTOM_FIELDS_INTO_MASTER), 
					detailsVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_CN_CUSTOM_FIELDS_INTO_HIST), 
					detailsVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_CN_DET_INTO_MASTER), 
					detailsVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_CN_DET_INTO_HISTORY), 
					detailsVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_CN_DET_CUSTOM_FIELDS_INTO_MASTER), 
					detailsVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_CN_DET_CUSTOM_FIELDS_INTO_HIST), 
					detailsVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error while releasing credit notes : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	private void insertInvoiceAndLineItemsIntoMaster(FileDetailsVO detailsVO) throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_INVOICE_INTO_MASTER), 
					detailsVO);
			createInvoiceAudit(detailsVO.getFileId(), 
					detailsVO.getReleasedBy(), StatusConstants.RELEASED, EippAuditConstants.INV_RELEASED);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_INVOICE_INTO_HISTORY), 
					detailsVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_INV_CUSTOM_FIELDS_INTO_MASTER), 
					detailsVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_INV_CUSTOM_FIELDS_INTO_HIST), 
					detailsVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_INVOICE_DETAIL_INTO_MASTER), 
					detailsVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_INVOICE_DETAIL_INTO_HISTORY), 
					detailsVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_INV_DET_CUSTOM_FIELDS_INTO_MASTER), 
					detailsVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_INV_DET_CUSTOM_FIELDS_INTO_HIST), 
					detailsVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_INV_ATTACHMENTS), 
					detailsVO);
			
		} catch (DataAccessException e) {
			LOGGER.error("Error while releasing invoices : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}

	}
	private void insertInvoiceAndLineItemsIntoHistory(FileDetailsVO detailsVO) throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_DELETED_INVOICE_INTO_HISTORY), 
					detailsVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_INV_CUSTOM_FIELDS_INTO_HIST), 
					detailsVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_INVOICE_DETAIL_INTO_HISTORY), 
					detailsVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_INV_DET_CUSTOM_FIELDS_INTO_HIST), 
					detailsVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error while releasing invoices : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}

	}
	private void insertCNAndLineItemsIntoHistory(FileDetailsVO detailsVO) throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_DELETED_CN_INTO_HISTORY), 
					detailsVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_CN_CUSTOM_FIELDS_INTO_HIST), 
					detailsVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_CN_DET_INTO_HISTORY), 
					detailsVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_CN_DET_CUSTOM_FIELDS_INTO_HIST), 
					detailsVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error while releasing credit notes : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public NameValueVO getInvoiceTotalAmtForFile(long fileId, String status) throws BNPApplicationException{
		Object object = null;
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("fileId", fileId);
		params.put("status",status);
		try{
			if (status != null && status.equals(StatusConstants.VALIDATION_FAILED)) {
				object = getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_TOTAL_DEL_INV_AMOUNT_FOR_FILE), fileId);

			} else {
				object = getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_TOTAL_INVOICE_AMOUNT_FOR_FILE), params);
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		return (NameValueVO) object;
	}
	@Override
	public NameValueVO getCntTotalAmtForFile(long fileId, String status) throws BNPApplicationException{
		Object object = null;
		try{
			if (status.equalsIgnoreCase(StatusConstants.PENDING_FOR_APPROVAL)) {
				object = getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_TOTAL_CNT_AMOUNT_FOR_FILE_FROM_TRANS), fileId);
			} else if (status.equalsIgnoreCase(StatusConstants.VALIDATION_FAILED)) {
				Map<String, Object> params = new HashMap<String, Object>();
				params.put("fileId", fileId);
				params.put("status", StatusConstants.DELETE);
				object = getSqlMapClientTemplate().queryForObject(
						getQueryNameWithNameSpace(GET_TOTAL_CNT_AMOUNT_FOR_FILE_FROM_HIST), params);
			} else {
				object = getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_TOTAL_CNT_AMOUNT_FOR_FILE_FROM_TRANS_MASTER), fileId);

			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		return (NameValueVO) object ;
	}
	@Override
	public byte[] generateCreditNoteReportPdf(long cntId) throws BNPApplicationException {
		return generateReportPdf(cntId,GET_CREDIT_NOTE_REPORT_DETAILS);
	}
	@Override
	public byte[] generateInvoiceReportPdf(long invId) throws BNPApplicationException {
		return generateReportPdf(invId,GET_INVOICE_REPORT_DETAILS);
	}

	private byte[] generateReportPdf(long pkId ,String query)throws BNPApplicationException {
		try
		{
			byte[] reportByteArray;
			BrandingReportVO brandingReportVO=(BrandingReportVO) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(query),pkId);
			if(brandingReportVO!=null && brandingReportVO.getStyleSheet()!=null)
			{
				reportByteArray= reportUtil.generatePDF(brandingReportVO);
			}
			else
			{
				throw new BNPApplicationException(ErrorConstants.BRANDING_SET_UP_NOT_AVAILABLE);
			}
			return reportByteArray;
		}
		catch (DataAccessException e) {
			LOGGER.error("Error while generateInvoiceReportPdf : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	@Override
	public void updateFileStatusForRelease(FileDetailsVO fileVO) throws BNPApplicationException {

		Map<String,Object> params = new HashMap<String,Object>();
		params.put("fileId", fileVO.getFileId());
		params.put("fileStatus", StatusConstants.RELEASED);
		params.put("releasedBy", fileVO.getReleasedBy());
		params.put("releasedDate",new Date(System.currentTimeMillis()));
		params.put("remarks", ErrorConstants.FILE_RELEASE_SUCCESS);
		try{
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPD_FILE_STATUS_FOR_RELEASE), params);
		}
		catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	@Override
	public void updateFileStatusForDelete(FileDetailsVO detailsVO) throws BNPApplicationException {

		Map<String,Object> params = new HashMap<String,Object>();
		params.put("fileId", detailsVO.getFileId());
		params.put("fileStatus", detailsVO.getFileUploadStatus());
		params.put("deletedBy", detailsVO.getCurrentUserId());
		params.put("releasedDate",new Date(System.currentTimeMillis()));
		try{
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPD_FILE_STATUS_FOR_DELETE), params);
		}
		catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public void deleteTransDetails(FileDetailsVO detailsVO)
			throws BNPApplicationException {
		deleteInvoicesAndLineItemsFromTrans(detailsVO);
		deleteCNAndLineItemsFromTrans(detailsVO);
	}
	
	@Override
	public void deleteMatchTransDetails(FileDetailsVO detailsVO)
			throws BNPApplicationException {
		deleteMatchInvcAndLineItmsFromTrans(detailsVO);
		deleteMatchCNAndLineItmsFromTrans(detailsVO);
	}
	
	
	private void deleteMatchInvcAndLineItmsFromTrans(
			FileDetailsVO detailsVO) throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().delete(DELETE_MATCH_CUST_FIELDS_FROM_TRANS, 
					detailsVO.getFileId());
			getSqlMapClientTemplate().delete(DELETE_MATCH_INVC_DTLS_FROM_TRANS, 
					detailsVO.getFileId());
			getSqlMapClientTemplate().delete(DELETE_MATCH_INVC_FROM_TRANS, 
					detailsVO.getFileId());

		} catch (DataAccessException e) {
			LOGGER.error("Error while deleting invoices : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	private void deleteMatchCNAndLineItmsFromTrans(
			FileDetailsVO detailsVO) throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().delete(DELETE_MATCH_CN_DET_FROM_TRANS, 
					detailsVO.getFileId());
			getSqlMapClientTemplate().delete(DELETE_MATCH_CN_FROM_TRANS, 
					detailsVO.getFileId());
		} catch (DataAccessException e) {
			LOGGER.error("Error while deleting credit notes : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	

	@Override
	public void insertHistoryDetails(FileDetailsVO detailsVO)
			throws BNPApplicationException {
		insertInvoiceAndLineItemsIntoHistory(detailsVO);
		insertCNAndLineItemsIntoHistory(detailsVO);
	}
	
	@Override
	public void insertMatchHistoryDetails(FileDetailsVO detailsVO)
			throws BNPApplicationException {
		insertMatchInvcAndLineItmsIntoHist(detailsVO);
		insertMatchCNAndLineItmsIntoHist(detailsVO);
	}
	
	private void insertMatchInvcAndLineItmsIntoHist(FileDetailsVO detailsVO) throws BNPApplicationException{
		try {
			getSqlMapClientTemplate().insert(INS_MAT_INVOICE_HISTORY_FROM_TRANS, 
					detailsVO.getFileId());
			getSqlMapClientTemplate().insert(INS_MAT_INVCUST_FLDS_HIST_FROM_TRANS, 
					detailsVO.getFileId());
			getSqlMapClientTemplate().insert(INS_MAT_INVOICE_ITEMS_HISTORY_FROM_TRANS, 
					detailsVO.getFileId());
			
		} catch (DataAccessException e) {
			LOGGER.error("Error while releasing invoices : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	private void insertMatchCNAndLineItmsIntoHist(FileDetailsVO detailsVO) throws BNPApplicationException{
		try {
			getSqlMapClientTemplate().insert(INS_MAT_CREDIT_NOTE_HISTORY_FROM_TRANS, 
					detailsVO.getFileId());
			getSqlMapClientTemplate().insert(INS_MAT_CREDIT_NOTE_ITEMS_HISTORY_FROM_TRANS, 
					detailsVO.getFileId());
		} catch (DataAccessException e) {
			LOGGER.error("Error while releasing invoices : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	public void updateInvAndCNStatusInTrans(long fileId, String status)
			throws BNPApplicationException {
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("fileId", fileId);
		params.put("status", status);
		
		try{
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_INV_STATUS_IN_TRANS), params);
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_CN_STATUS_IN_TRANS), params);
		} catch (DataAccessException e) {
			LOGGER.error(e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}		
	}
	
	public void updateMatchInvAndCNStsInTrans(long fileId, String status)
	throws BNPApplicationException {
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("fileId", fileId);
		params.put("status", status);
		
		try{
			getSqlMapClientTemplate().update(UPD_MAT_INV_RECORD_STS_IN_TRANS, params);
			getSqlMapClientTemplate().update(UPD_MAT_INV_ITEMS_RECORD_STS_IN_TRANS, params);
			getSqlMapClientTemplate().update(UPD_MAT_INV_CUSTOM_RECORD_STS_IN_TRANS, params);
			getSqlMapClientTemplate().update(UPD_MAT_CN_RECORD_STS_IN_TRANS, params);
			getSqlMapClientTemplate().update(UPD_MAT_CN_ITEMS_RECORD_STS_IN_TRANS, params);
		} catch (DataAccessException e) {
			LOGGER.error(e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}		
	}
	
	public void createInvoiceAudit(final long fileId, final String makerId, 
			final String status, final String action) {
		try {
			final List<EippInvoiceVO> invoiceList = invoiceDao.getInvoicesForFile(fileId, status);
			
			getSqlMapClientTemplate().execute(new SqlMapClientCallback<List<Object>>() {
				public List<Object> doInSqlMapClient(SqlMapExecutor executor)
				throws SQLException {
					
					try {
						List<Object> list = new ArrayList<Object>();
						EippAuditVO auditVO = null;
						
						executor.startBatch();
						for (EippInvoiceVO invoice : invoiceList) {
							auditVO = new EippAuditVO();
							
							auditVO.setInvId(invoice.getInvId());
							auditVO.setAuditUser(makerId);
							auditVO.setStatus(invoice.getInvStatus());
							auditVO.setAction(action);
							
							try {
								executor.insert(CREATE_INV_AUDIT, auditVO);
							} catch (SQLException e) {
								LOGGER.error("Error while creating invoice audit " + e.getMessage());
								// Not propogating the exception as issues while creating audit 
								// should not stop the actual invoice upload
							}
						}
						executor.executeBatchDetailed();
						return list;
					} catch (BatchException e) {
						throw new SQLException(e.getMessage());
					}
				}
			});
		} catch (Exception e) {
			LOGGER.error("Error while creating invoice audit " + e.getMessage());
			// Not propogating the exception as issues while creating audit 
			// should not stop the actual invoice upload
		}
	}
	
	 // Start: Added for Rel 3.0 Matching and Reconcilation
	@Override
	public NameValueVO getMatchReconInvoiceCountForFile(long fileId, String status) throws BNPApplicationException{
		Object object = null;
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("fileId", fileId);
		params.put("status",status);
		try{
			if (StatusConstants.VALIDATION_FAILED.equals(status)) {
				object = getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_TOTAL_DEL_MATCH_RECON_INV_COUNT_FOR_FILE), params);
			} else {
				object = getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_TOTAL_MATCH_RECON_INVOICE_COUNT_FOR_FILE_FROM_TRANS_MASTER), fileId);
			}

		} catch (DataAccessException e) {
			LOGGER.error("Error while executing method getMatchReconInvoiceCountForFile :"+e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		return (NameValueVO) object;
	}
	
	@Override
	public NameValueVO getMatchReconCntCountForFile(long fileId, String status) throws BNPApplicationException{
		Object object = null;
		try{
			if (status.equalsIgnoreCase(StatusConstants.PENDING_FOR_APPROVAL)) {
				object = getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_TOTAL_CNT_MATCH_RECON_COUNT_FOR_FILE_FROM_TRANS), fileId);
			} else if (status.equalsIgnoreCase(StatusConstants.VALIDATION_FAILED)) {
				Map<String, Object> params = new HashMap<String, Object>();
				params.put("fileId", fileId);
				params.put("status", StatusConstants.DELETE);
				object = getSqlMapClientTemplate().queryForObject(
						getQueryNameWithNameSpace(GET_TOTAL_CNT_MATCH_RECON_COUNT_FOR_FILE_FROM_HIST), params);
			} else {
				object = getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_TOTAL_CNT_MATCH_RECON_COUNT_FOR_FILE_FROM_TRANS_MASTER), fileId);
			}
		} catch (Exception e) {
			LOGGER.error("Error while executing method getMatchReconCntCountForFile :"+e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		return (NameValueVO) object ;
	}
	
	@Override
	public NameValueVO getMatchReconPaymentCountForFile(long fileId, String status) throws BNPApplicationException{
		Object object = null;
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("fileId", fileId);
		params.put("status",StatusConstants.DELETE);
		try{
			if (StatusConstants.VALIDATION_FAILED.equals(status)) {
				object = getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_TOTAL_DEL_MATCH_RECON_PYMT_COUNT_FOR_FILE), params);

			} else {
				object = getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_TOTAL_MATCH_RECON_PYMT_COUNT_FOR_FILE_FROM_TRANS_MASTER), fileId);
			}

		} catch (DataAccessException e) {
			LOGGER.error("Error while executing method getMatchReconPaymentCountForFile :"+e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		return (NameValueVO) object;
	}
	// Ends : Added for Rel 3.0 Matching and Reconcilation

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.filemgmt.IEippReleaseFileDao#getMatchRefNoForFileId(com.bnp.scm.services.filemgmt.vo.FileDetailsVO)
	 */
	@Override
	public List<String> getMatchRefNoForFileId(long fileID)
			throws BNPApplicationException {
		
		List<String> matchRefNos = null;
		try{
			matchRefNos =  getSqlMapClientTemplate().queryForList(GET_MATCH_REF_NOS, fileID);	
		} catch (DataAccessException e) {
			LOGGER.error("Exception while getting match ref nos for the file id in release file" , e);
			throw new BNPApplicationException(ErrorConstants.PROCESSING_ERROR);
		}
		
		return matchRefNos;
	}
}	

