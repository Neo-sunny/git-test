/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Jul 29, 201212:43:26 PM
 * 
 * Purpose:      InstrumentTypeEnum.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Jul 29, 201212:43:26 PM        Oracle Financial Services Software Ltd                  Initial Version  
 *  14 Sep 2012						Prabakaran S										  Modified for EIPP Inv Attachments
 *  17 Sep 2012 					Reena S												  Modified for Billing Customer Charges MFU
 *  24 Sep 2012						Aarthi T											  Release File Inq - Rel 3.0 Matching and Reconcilation 
 *  26 Sep 2012 					Dinesh D											  Modified for EIPP Disputes MFU
 *  17 Oct 2012						Prabakaran S										  Fix for ST Defect # 6793
 *  22 OCT 2012 					Sadhana A V											  Modified for Rel 3.0 Message Monitoring
 *  23 Nov 2012						Reena S												  Added DocType for EIPPDisputes
************************************************************************************************************************************************************/

package com.bnp.eipp.services.filemgmt.util;

import java.util.HashMap;
import java.util.Map;

import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;

public enum InstrumentTypeEnum {
	
	EIPP_INV_CREDIT_NOTE("EIPP", "5", "EIPP - Invoice/Creditnote"),
	EIPP_BILLING_CUSTOMER_CHARGES("EIPP-BillingCount","7", "EIPP-BillingCount"),
	EIPP_INV_CANCEL("EIPP Invoice Cancellation", "8", "EIPP Invoice Cancellation"),
	EIPP_DISPUTE("EIPPDisputes", "10", "EIPPDisputes"),
	EIPP_PYMT_PREP("EIPPPymtPrep", "12", "EIPP Payment Preparation"),
	EIPP_PYMT_STATUS_UPDATE("EIPP-PymtStatusUpdate","13","EIPP Payment Status Update"),
	EIPP_INV_ATTACHMENTS("EIPPInvAttachments", "14","EIPP - Inv Attachments");
	// Start:  Added for Rel 3.0 Matching and Reconcilation
//	MATCHING_EIPP_INVOICE("MATCHEIPPINVC", "15"),
//	MATCHING_EIPP_CREDIT_NOTE("MATCHEIPPCN", "16"),
//	EIPP_MATCHING_AND_RECONCILATION("MATCHRECON", "17"),
//	MATCHING_EIPP_PAYMENT_RESPONSE("MATCHEIPPPMTRESP", "18");
	// Ends :  Added for Rel 3.0 Matching and Reconcilation

	
	private InstrumentTypeEnum(String fileFrmtType, String instrumentType, String docType) {
		this.fileFormatType = fileFrmtType;
		this.instrumentType = instrumentType;
		this.msgType = docType;
	}
	
	private String msgType;
	
	private String instrumentType;
	
	private String fileFormatType;
	
	private static Map<String, InstrumentTypeEnum> fileFormatTypeMap = new HashMap<String, InstrumentTypeEnum>();
	private static Map<String, InstrumentTypeEnum> instrumentTypeMap = new HashMap<String, InstrumentTypeEnum>();
	private static Map<String, InstrumentTypeEnum> msgTypeMap = new HashMap<String, InstrumentTypeEnum>();
	
	static {
		for (InstrumentTypeEnum instrumentType : InstrumentTypeEnum.values()) {
			fileFormatTypeMap.put(instrumentType.getFileFormatType(), instrumentType);
			instrumentTypeMap.put(instrumentType.getInstrumentType(), instrumentType);
			msgTypeMap.put(instrumentType.getMsgType(), instrumentType);
		}
	}

	public String getFileFormatType() {
		return fileFormatType;
	}

	public String getMsgType() {
		return msgType;
	}

	public String getInstrumentType() {
		return instrumentType;
	}

	public static String getInstrumentType(String fileFormatType) throws BNPApplicationException {
		fileFormatType = fileFormatType.trim();
		
		InstrumentTypeEnum instrEnum = fileFormatTypeMap.get(fileFormatType);
		
		if (instrEnum == null) {
			throw new BNPApplicationException(ErrorConstants.INCORRECT_FILE_FORMAT);
		}
		
		return instrEnum.getInstrumentType();
	}
	
	public static String getFileFormatType(String instrumentType) throws BNPApplicationException {
		instrumentType = instrumentType.trim();
		
		InstrumentTypeEnum instrEnum = instrumentTypeMap.get(instrumentType);
		
		if (instrEnum == null) {
			throw new BNPApplicationException(ErrorConstants.INVALID_INSTRUMENT_TYPE);
		}
		
		return instrEnum.getFileFormatType();
	}
	
	public static boolean isEippInstrumentType(String instrumentType) {
		
		boolean isEippType = false;
		
		if (instrumentTypeMap.get(instrumentType) != null) {
			isEippType = true;
		}
		return isEippType;
	}
	
	public static boolean isEippFile(String fileFormatType) {
		
		boolean isEippFile = false;
		if (fileFormatTypeMap.get(fileFormatType) != null) {
			isEippFile = true;
		}
		return isEippFile;
	}
	
	public static boolean isEippMessageType(String msgType) {
		
		boolean isEippMessage = false;
		if (msgTypeMap.get(msgType) != null) {
			isEippMessage = true;
		}
		return isEippMessage;
	}
	
	public static String getFileFormatTypeForMsgType(String msgType) throws BNPApplicationException {
		msgType = msgType.trim();
		
		InstrumentTypeEnum instrEnum = msgTypeMap.get(msgType);
		
		if (instrEnum == null) {
			throw new BNPApplicationException(ErrorConstants.INVALID_MESSAGE_TYPE);
		}
		
		return instrEnum.getFileFormatType();
	}
	
	public static String getMsgTypeForFileFormatType(String fileFormatType) throws BNPApplicationException {
		fileFormatType = fileFormatType.trim();
		
		InstrumentTypeEnum instrEnum = fileFormatTypeMap.get(fileFormatType);
		
		if (instrEnum == null) {
			throw new BNPApplicationException(ErrorConstants.INCORRECT_FILE_FORMAT);
		}
		
		return instrEnum.getMsgType();
	}
}
