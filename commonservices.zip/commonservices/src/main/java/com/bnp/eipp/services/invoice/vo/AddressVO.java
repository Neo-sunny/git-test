/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 9, 2012
 * 
 * Purpose:      AddressVO.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 9, 2012       Oracle Financial Services Software Ltd                  Initial Version  
 * Mar 3, 2012		 Oracle Financial Services Software Ltd                  Added attribute city for dept approval
************************************************************************************************************************************************************/

package com.bnp.eipp.services.invoice.vo;

/**
 * The Class AddressVO.
 */
public class AddressVO {

	private String addrType;
	
	private String dept;
	
	private String subDept;
	
	private String streetName;
	
	private String bldgNb;
	
	private String postalCode;
	
	private String townName;
	
	private String ctrySubDvsn;
	
	private String state;
	
	private String country;
	
	private String city;
	
	private String address1;
	
	private String address2;
	
	private String address3;
	
	private String fax;
	
	private String telephone;

	/**
	 * Gets the addr type.
	 *
	 * @return the addrType
	 */
	public String getAddrType() {
		return addrType;
	}

	/**
	 * Sets the addr type.
	 *
	 * @param addrType the addrType to set
	 */
	public void setAddrType(String addrType) {
		this.addrType = addrType;
	}

	/**
	 * Gets the dept.
	 *
	 * @return the dept
	 */
	public String getDept() {
		return dept;
	}

	/**
	 * Sets the dept.
	 *
	 * @param dept the dept to set
	 */
	public void setDept(String dept) {
		this.dept = dept;
	}

	/**
	 * Gets the sub dept.
	 *
	 * @return the subDept
	 */
	public String getSubDept() {
		return subDept;
	}

	/**
	 * Sets the sub dept.
	 *
	 * @param subDept the subDept to set
	 */
	public void setSubDept(String subDept) {
		this.subDept = subDept;
	}

	/**
	 * Gets the street name.
	 *
	 * @return the streetName
	 */
	public String getStreetName() {
		return streetName;
	}

	/**
	 * Sets the street name.
	 *
	 * @param streetName the streetName to set
	 */
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	/**
	 * Gets the postal code.
	 *
	 * @return the postalCode
	 */
	public String getPostalCode() {
		return postalCode;
	}

	/**
	 * Sets the postal code.
	 *
	 * @param postalCode the postalCode to set
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * Gets the town name.
	 *
	 * @return the townName
	 */
	public String getTownName() {
		return townName;
	}

	/**
	 * Sets the town name.
	 *
	 * @param townName the townName to set
	 */
	public void setTownName(String townName) {
		this.townName = townName;
	}

	/**
	 * Gets the state.
	 *
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * Sets the state.
	 *
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * Gets the country.
	 *
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * Sets the country.
	 *
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}
	
	/**
	 * Gets the address1.
	 *
	 * @return the address1
	 */
	public String getAddress1() {
		return address1;
	}

	/**
	 * Sets the address1.
	 *
	 * @param address1 the new address1
	 */
	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	/**
	 * Gets the address2.
	 *
	 * @return the address2
	 */
	public String getAddress2() {
		return address2;
	}

	/**
	 * Sets the address2.
	 *
	 * @param address2 the new address2
	 */
	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	/**
	 * Gets the address3.
	 *
	 * @return the address3
	 */
	public String getAddress3() {
		return address3;
	}

	/**
	 * Sets the address3.
	 *
	 * @param address3 the new address3
	 */
	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	/**
	 * Gets the fax.
	 *
	 * @return the fax
	 */
	public String getFax() {
		return fax;
	}

	/**
	 * Sets the fax.
	 *
	 * @param fax the new fax
	 */
	public void setFax(String fax) {
		this.fax = fax;
	}

	/**
	 * Gets the telephone.
	 *
	 * @return the telephone
	 */
	public String getTelephone() {
		return telephone;
	}

	/**
	 * Sets the telephone.
	 *
	 * @param telephone the new telephone
	 */
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param bldgNb the bldgNb to set
	 */
	public void setBldgNb(String bldgNb) {
		this.bldgNb = bldgNb;
	}

	/**
	 * @return the bldgNb
	 */
	public String getBldgNb() {
		return bldgNb;
	}

	/**
	 * @param ctrySubDvsn the ctrySubDvsn to set
	 */
	public void setCtrySubDvsn(String ctrySubDvsn) {
		this.ctrySubDvsn = ctrySubDvsn;
	}

	/**
	 * @return the ctrySubDvsn
	 */
	public String getCtrySubDvsn() {
		return ctrySubDvsn;
	}

	private String getEmptyString(String value) {
		if (value == null) {
			return "";
		} else {
			return value;
		}
	}
	public String getDataString() {
		StringBuilder builder = new StringBuilder();
		builder.append(getEmptyString(getAddrType()) + "~");
		builder.append(getEmptyString(getDept()) + "~");
		builder.append(getEmptyString(getSubDept()) + "~");
		builder.append(getEmptyString(getStreetName()) + "~");
		builder.append(getEmptyString(getBldgNb()) + "~");
		builder.append(getEmptyString(getPostalCode()) + "~");
		builder.append(getEmptyString(getTownName()) + "~");
		builder.append(getEmptyString(getCtrySubDvsn()) + "~");
		builder.append(getEmptyString(getState()) + "~");
		builder.append(getEmptyString(getCountry()) + "~");
		builder.append(getEmptyString(getAddress1()) + "~");
		builder.append(getEmptyString(getAddress2()) + "~");
		builder.append(getEmptyString(getAddress3()));
		return builder.toString();
	}
}
