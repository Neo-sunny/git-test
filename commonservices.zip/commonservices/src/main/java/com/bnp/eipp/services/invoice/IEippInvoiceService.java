/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 6, 20128:14:33 PM
 * 
 * Purpose:      IEippInvoiceService.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 6, 20128:14:33 PM        Oracle Financial Services Software Ltd                  Initial Version
 * 21/04/2012  					Sandhya R												SIT #2020
 * 21/04/2012  					Sandhya R												SIT #1997
 * 14/05/2012  					Sandhya R												UAT #2240
 * 24 Aug 2012    				Gangadharan R							                MFU - Payment Preparation
 * 06 Sep 2012 			        Reena S													Release 3.0		Release File Inq:Pymt preparation & Pymt status update
 * 24 Sep 2012					Aarthi T											    Release File Inq - Rel 3.0 Matching and Reconcilation
************************************************************************************************************************************************************/

package com.bnp.eipp.services.invoice;

import java.util.List;
import java.util.Properties;

import com.bnp.eipp.services.invoice.vo.EippAuditVO;
import com.bnp.eipp.services.invoice.vo.EippCreditNoteVO;
import com.bnp.eipp.services.invoice.vo.EippCustFieldsVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.invoice.vo.EippPymtStatusUpdateVO;
import com.bnp.eipp.services.vo.dispute.DisputeVO;
import com.bnp.scm.services.common.ITransactionService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

public interface IEippInvoiceService extends ITransactionService {

	List<EippInvoiceVO> getInvoices(long fileId) throws BNPApplicationException;

	void processDepartmentApproval(long fileId) throws BNPApplicationException;

	Properties getOrgConfigForCNUtilization(String supplierOrgId)
	throws BNPApplicationException;

	EippInvoiceVO getInvoice(EippCreditNoteVO creditNoteVO)
	throws BNPApplicationException;

	void updateEippInvoice(EippInvoiceVO invoiceVO)
	throws BNPApplicationException;

	void updateEippCreditNote(EippCreditNoteVO creditNoteVO)
	throws BNPApplicationException;

	void insertInvoiceIntoHistory(EippInvoiceVO invoice)
	throws BNPApplicationException;

	void insertCreditNoteIntoHistory(EippCreditNoteVO creditNote)
	throws BNPApplicationException;

	List<EippInvoiceVO> getInvoicesForFile(long fileId, String status)
	throws BNPApplicationException;

	List<EippCreditNoteVO> getCreditNotesForFile(long fileId, String status)
	throws BNPApplicationException;

	List<EippInvCntLineItemVO> getInvoiceLineItems(long invoiceId, String status)
	throws BNPApplicationException;

	List<EippInvCntLineItemVO> getCreditNoteLineItems(long creditNoteId,
			String status) throws BNPApplicationException;

	List<EippCustFieldsVO> getCreditNoteCustomFields(long creditNoteId,
			String status) throws BNPApplicationException;

	List<EippCustFieldsVO> getInvoiceCustomFields(long creditNoteId,
			String status) throws BNPApplicationException;

	List<EippCustFieldsVO> getInvoiceLineItemCustomFields(long lineItemId,
			String status) throws BNPApplicationException;

	List<EippCustFieldsVO> getCNLineItemCustomFields(long lineItemId,
			String status) throws BNPApplicationException;

	/**
	 * This API returns the invoice details for the corresponding invoice id
	 * @param invoiceId
	 * @return
	 * @throws BNPApplicationException
	 */
	EippInvoiceVO getInvoiceDetails(long invoiceId) 
			throws BNPApplicationException;
	
	List<EippInvoiceVO> getInvoiceDetails(EippInvoiceVO invoiceVO)throws BNPApplicationException;

	List<EippCreditNoteVO> getCreditNoteDetails(EippCreditNoteVO creditNoteVO)throws BNPApplicationException;
	
	List<EippInvCntLineItemVO> getInvLineItemDetails(long invId, String status) throws BNPApplicationException;
	
	List<EippInvCntLineItemVO> getCrnLineItemDetails(String orgId, long fileId, long cntId,String status)throws BNPApplicationException;
	
	List<EippAuditVO> getInvoiceAuditDetails(
			long invId) throws BNPApplicationException;

	/**
	 * Reset invoice status.
	 * 
	 * @param dispute
	 *            the dispute
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	void updateInvStatusAndRemAmt(
			DisputeVO dispute) throws BNPApplicationException;
	
	String updateInvLnItmStatusAndRemAmt(
			DisputeVO dispute) throws BNPApplicationException;

	String getPrevInvoiceStatus(
			long invoiceId) throws BNPApplicationException;

	void updateLineItemStatus(List<Long> lineItemIds, 
			String status) throws BNPApplicationException;
	
	void createInvoiceAudit(EippAuditVO auditVO) 
		throws BNPApplicationException;
	
	void updateInvStatusAndRemAmtWithTimeStamp(DisputeVO dispute) 
		throws BNPApplicationException;
	
	void createInvLineItemAudit(EippAuditVO auditVO)
		throws BNPApplicationException ;
	
	String getPrevInvoiceStatusForCancel(long invoiceId) throws BNPApplicationException;
	
	List<Long> getDeptIds(EippInvoiceVO invoiceVO) throws BNPApplicationException;

	/**
	 * It returns a single invoice from the list of invoices with the same data
	 * @param eippInvoiceVO
	 * @return
	 * @throws BNPApplicationException
	 */
	EippInvoiceVO getInvoiceFromInvoiceList(EippInvoiceVO eippInvoiceVO)
		throws BNPApplicationException;
	
	int getPymtPreparationCountForFile(long fileId,String fileStatus)throws BNPApplicationException;
	
	List<EippInvoiceVO> getPymtPrepRecordDetails(long fileId,String fileStatus) throws BNPApplicationException;
	
	int getPymtStatusCountForFile(long fileId)throws BNPApplicationException;
	
	List<EippPymtStatusUpdateVO> getPymtStatusFileDetails(long fileId) throws BNPApplicationException;
	
	List<NameValueVO> getCustomFieldsForEippPymt(long pymtId,String fileStatus)throws BNPApplicationException;
		
	/**
	 * It returns the complete invoice details including the configuration level flags
	 * @param eippInvoiceVO
	 * @return
	 * @throws BNPApplicationException
	 */
	EippInvoiceVO getInvoiceFullDetails(EippInvoiceVO eippInvoiceVO)
		throws BNPApplicationException;	

	// Start : Added for Rel 3.0 Matching and Reconcilation
	List<EippInvoiceVO> getMatchReconPymtDetails(long fileId,String fileStatus)throws BNPApplicationException;
	
	List<EippInvoiceVO> getMatchReconInvoiceDetails(EippInvoiceVO invoiceVO)throws BNPApplicationException;
	
	List<EippCreditNoteVO> getMatchReconCreditNoteDetails(EippCreditNoteVO creditNoteVO) throws BNPApplicationException;
	
	List<EippInvCntLineItemVO> getMatchReconInvLineItemDetails(long invId)throws BNPApplicationException;
	
	List<EippInvCntLineItemVO> getMatchReconCrnLineItemDetails(String orgId, long fileId, long cntId)throws BNPApplicationException;
	
	List<EippCustFieldsVO> getMatchReconInvoiceCustomFields(long invoiceId, String status) throws BNPApplicationException;
	// Ends : Added for Rel 3.0 Matching and Reconcilation
}
