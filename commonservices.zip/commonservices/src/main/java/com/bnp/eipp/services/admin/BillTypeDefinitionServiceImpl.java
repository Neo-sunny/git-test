/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Jan 18, 201210:32:41 AM
 * 
 * Purpose:      Implementation class for Bill Type Definition Service Layer
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Jan 18, 201210:32:41 AM        Oracle Financial Services Software Ltd                  Initial Version
 * 21 Mar 2012					  Oracle Financial Services Software Ltd				 Release 2.1 I1				ST fix 5615, 5652, 5603, 5452, 5636, 5593
 * 18 Jul 2012                    Reena 												 Release 3.0	            Changes for EIPP-Phase II  
 ************************************************************************************************************************************************************/
package com.bnp.eipp.services.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.dao.admin.IBillTypeDefinitionDao;
import com.bnp.eipp.services.vo.admin.BillTypeDefinitionVO;
import com.bnp.eipp.services.vo.admin.BillTypeShortCutsVO;
import com.bnp.scm.services.common.AbstractServiceImpl;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.dao.IAbstractDAO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;


@Component
public class BillTypeDefinitionServiceImpl extends AbstractServiceImpl<BillTypeDefinitionVO> implements 
		IBillTypeDefinitionService {
	
	//private static final Logger LOGGER = LoggerFactory.getLogger(BillTypeDefinitionServiceImpl.class);
	
	@Autowired 
	private IBillTypeDefinitionDao billTypeDao;
	
	/** The Constant CHILD_PARAM1. */
	private static final String CHILD_PARAM1="CUST_ERP_ID";
	

	@Override
	public IAbstractDAO getDAO() {
		return (IAbstractDAO) billTypeDao;
	}

	@Override
	public List<BillTypeDefinitionVO> getBillTypeDetails(
			BillTypeDefinitionVO searchVO) throws BNPApplicationException {
		return billTypeDao.getBillTypeDetails(searchVO);
	}

	@Override
	public BillTypeDefinitionVO getModifiedRecord(
			BillTypeDefinitionVO orgDiscount) throws BNPApplicationException {
		return billTypeDao.getModifiedRecord(orgDiscount);
	}

	@Override
	public boolean chkDependencyBeforDelete(BillTypeDefinitionVO searchVO)
			throws BNPApplicationException {
		boolean flag=true;
		
		int count=billTypeDao.chkDependencyBeforDelete(searchVO);
		if(count==0){
			flag=false;
		}
		else if(count>0){
			flag=true;
		}		
		return flag;
	}
	
	@Override
	public List<NameValueVO> getOrganisationsListFromBilltype(NameValueVO inputVO)throws BNPApplicationException {
		if(null !=inputVO && (BNPConstants.BCMMPOA.equals(inputVO.getValue()) ||BNPConstants.BCMMPALL.equals(inputVO.getValue())
				|| BNPConstants.SCMMPOA.equals(inputVO.getValue())|| BNPConstants.SCMMPALL.equals(inputVO.getValue()) ))	
		{
			return billTypeDao.getCustomerOrgListForMPOA(inputVO);
		}
		else{
		return billTypeDao.getOrganisationsListFromBilltype(inputVO);
		}
	}

	@Override
	public NameValueVO getCustomerRoleName(String orgId)
			throws BNPApplicationException {
		return billTypeDao.getCustomerRoleName(orgId);
	}

	@Override
	public List<NameValueVO> getDeptListForBuyer(String orgId)
			throws BNPApplicationException {
		return billTypeDao.getDeptListForBuyer(orgId);
	}

	@Override
	public List<NameValueVO> getDeptListForSupplier(String orgId)
			throws BNPApplicationException {
		return billTypeDao.getDeptListForSupplier(orgId);
	}

	
	
	@Override
	public List<BillTypeShortCutsVO> getBillTypeLogoRecord(String orgId)
			throws BNPApplicationException {
		return billTypeDao.getBillTypeLogoRecord(orgId);
	}

	@Override
	public List<BillTypeShortCutsVO> getBillTypeStyleSheetRecord(String orgId)
			throws BNPApplicationException {
		return billTypeDao.getBillTypeStyleSheetRecord(orgId);
	}

	@Override
	public List<BillTypeShortCutsVO> getBrandingDetailsRecord(String orgId)
			throws BNPApplicationException {
		return billTypeDao.getBrandingDetailsRecord(orgId);
	}

	@Override
	public List<BillTypeShortCutsVO> getDisputeCodeRecord(String orgId)
			throws BNPApplicationException {
		return billTypeDao.getDisputeCodeRecord(orgId);
	}

	
	@Override
	public boolean chkRecordNotExistsAlready(BillTypeDefinitionVO searchVO)throws BNPApplicationException {
		boolean flag=false;
		
		int count=billTypeDao.chkRecordNotExistsAlready(searchVO);
		if(count==0){
			flag=true;
		}
		else if(count>0){
			flag=false;
		}		
		return flag;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.admin.ILinkOrgForEippServices#getChildDetails(long, java.lang.String)
	 */
	@Override
	public BillTypeDefinitionVO getChildDetails(long pkId, String masterStatus)throws BNPApplicationException {

		BillTypeDefinitionVO detailVO=new BillTypeDefinitionVO();
		detailVO.setPkId(pkId);
		detailVO.setMasterRecordStatus(masterStatus);
		detailVO.setFieldName(CHILD_PARAM1);
		detailVO.setListOfCusERP(billTypeDao.getChildDetails(detailVO));

		return detailVO;
	
	}

	@Override
	public long getDefaultDepartmentForDispute(String customerOrgId, String billType)
			throws BNPApplicationException {
		return billTypeDao.getDefaultDepartmentForDispute(customerOrgId, billType);
	} 

	@Override
	public List<NameValueVO> getMarketPlaceOrgList(String custOrgId)throws BNPApplicationException {
				return billTypeDao.getMarketPlaceOrgList(custOrgId);
	}

	
}
