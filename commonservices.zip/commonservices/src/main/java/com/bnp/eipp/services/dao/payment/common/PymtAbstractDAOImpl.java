/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 AUG 2012
 * 
 * Purpose:      EIPP Payment Preparation 
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 01 Aug 2012                      Oracle Financial Services Software Ltd                                    Initial Version 
 * 17 Sep 2012						Raja S			                                                          Change Done for IUT issue
 * 
 * 21 Sep 2012 						Raja S	                                                                  Change Done for SONAR Fix
 * 26 Sep 2012                     	Gangadharan R															Authorization matrix changes
 * 04 Sep 2012                     	Gangadharan R															Authorization matrix changes
 * 13 Oct 2012						Vinoth Kumar M																CSV Export Functionality Added
 * 19 Oct 2012						Gangadharan R															Fix for ST defect 6979
 * 09 Nov 2012 						Raja S																	Change Done for Audit Trail 	
 *****************************************************************************************************************************************************************/

package com.bnp.eipp.services.dao.payment.common;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.invoice.vo.EippCreditNoteVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.vo.admin.EippNonFinInqLineItemVO;
import com.bnp.eipp.services.vo.admin.PaymentAdjustMentCodeVO;
import com.bnp.eipp.services.vo.payment.EippPymtAuditVO;
import com.bnp.eipp.services.vo.payment.EippPymtVO;
import com.bnp.eipp.services.vo.payment.PymtAdjustmentCodeCustomVO;
import com.bnp.eipp.services.vo.payment.SplitPaymentVO;
import com.bnp.scm.services.common.dao.AbstractCommonDaoImpl;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.BNPRuntimeException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.ScreenConstants;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.ibatis.sqlmap.client.SqlMapExecutor;
import com.ibatis.sqlmap.engine.execution.BatchException;

// TODO: Auto-generated Javadoc
/**
 * The Class PymtAbstractDAOImpl.
 *
 * @param <T> the generic type
 */
@Component
public  class PymtAbstractDAOImpl <T extends EippPymtVO> extends AbstractCommonDaoImpl<T> implements IPymtAbstractDAO<T> {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(PymtAbstractDAOImpl.class);
	
	/** The Constant GET_PYMT_CANCEL_SUMMARY. */
	private static final String GET_PYMT_CANCEL_SUMMARY="getpymtCancellationSummary";
	
	/** The Constant GET_PYMT_AUDIT_DET. */
	private static final String GET_PYMT_AUDIT_DET="getpymtAuditRecDetails";
	
	/** The Constant GET_CREDIT_NOTE_DET. */
	private static final String GET_CREDIT_NOTE_DET="getcreditNoteRecDetails";
	
	/** The Constant GET_SPLIT_PYMT_AMT_DET. */
	private static final String GET_SPLIT_PYMT_AMT_DET="getSplitPymtAmtDet";
	
	/** The Constant GET_PYMT_ADJ_DET. */
	private static final String GET_PYMT_ADJ_DET="getPymtAdjAmtDet"; 
	
	/** The Constant GET_INV_DET. */
	private static final String GET_INV_DET="getInvDet";
	
	/** The Constant GET_LINE_ITEM_DET. */
	private static final String GET_LINE_ITEM_DET="getLineItemDetForPayment";
	
	/** The Constant GET_PYMT_AUTHO_SUMMARY. */
	private static final String GET_PYMT_AUTHO_SUMMARY="getpymtAuthorizeSummary";
	
	/** The Constant UPDATE_PYMT_REC_STATUS_FOR_APPROVAL. */
	private static final String UPDATE_PYMT_REC_STATUS_FOR_APPROVAL="updatePymtRecStatusForAuthorization";
	
	/** The Constant GET_DUAL_CONTROL_STATUS_FOR_ORG_ID. */
	private static final String GET_DUAL_CONTROL_STATUS_FOR_ORG_ID="getDualControlStatus";
	
	/** The Constant GET_FIN_INQ_DETAIL. */
	private static final String GET_FIN_INQ_DETAIL="getFinancialInqSummary";
	
	/** The Constant GET_PYMT_ADJ_PARAM_DET. */
	private static final String GET_PYMT_ADJ_PARAM_DET="getPymtAdjParamDet";
	
	/** The Constant UPDATE_PYMT_REJECTION_STATUS. */
	private static final String UPDATE_PYMT_REJECTION_STATUS="updatePymtRejectionStatus";
	
	/** The Constant GET_BUYER_ORG_LIST. */
	private static final String GET_BUYER_ORG_LIST="getBuyerOrgList";
	
	/** The Constant GET_SUPPLIER_ORG_LIST. */
	private static final String GET_SUPPLIER_ORG_LIST="getSupplierOrgList";
	
	/** The Constant GET_MARKET_PLACE_ORG_LIST. */
	private static final String GET_MARKET_PLACE_ORG_LIST="getMarketPlaceOrgIdList";
	
	/** The Constant NAME_SPACE. */
	private static final String NAME_SPACE="PaymentOperationNS.";
	
	/** The Constant INSERT_PYMT_ACCESS_LOG. */
	private static final String INSERT_PYMT_ACCESS_LOG="insertPymtAccessLog";
	
	/** The Constant GET_LINE_ITM_AUDIT_DET. */
	private static final String GET_LINE_ITM_AUDIT_DET="getInvLineAuditDetails";
	
	/** The Constant GET_PREV_PYMT_STATUS. */
	private static final String GET_PREV_PYMT_STATUS="getPreviousPymtRecStatus";
	
	/** The Constant GET_BRANCH_TIME_ZONE. */
	private static final String GET_BRANCH_TIME_ZONE = "getBranchTimeZone";	

	
	/** The Constant GET_FIN_INQ_DETAIL_FRM_THR_SCREEN. */
	private static final String GET_FIN_INQ_DETAIL_FRM_THR_SCREEN="getFinInqDetailsForPmt";
	
	/** The Constant GET_INV_DET_OTHER. */
	private static final String GET_INV_DET_OTHER = "getInvDetForOtherScreen";
	
	/** The Constant INSERT_AUTH_MTX_AUDIT. */
	private static final String INSERT_AUTH_MTX_MAPPING = "inserAuthMapping";
	
	/** The Constant UPDATE_AUTH_MTX_MAPPING. */
	private static final String UPDATE_AUTH_MTX_MAPPING = "updateAuthMapping";
	
	/** The Constant UPDATE_AUTH_MTX_MAP_MID_LVLS. */
	private static final String UPDATE_AUTH_MTX_MAP_MID_LVLS = "updatePaymentAuthMatxMidLevels";	
	
	/** The Constant UPDATE_PYMT_AUT_MATX. */
	private static final String UPDATE_PYMT_AUT_MATX = "updatePaymentAuthMatx";
	
	/** The Constant GET_USER_EXIST_APPR_COUNT. */
	private static final String GET_USER_EXIST_APPR_COUNT = "checkApprovedListForUser";
	
	/** The Constant CHECK_VALID_USER. */
	private static final String CHECK_VALID_USER = "checkUserValid";
	
	private static final String GEP_LEAD_ORG_DETAILS = "getLeadOrgDetails";
	
	private static final String GET_EIPP_CN_COL_DETAILS = "getEippPaymentColumnDetails";
	
	private static final String GET_EIPP_CN_DETAILS = "getEippPaymentDetails";
	
	private static final String GET_UNLINK_CREDIT_NOTE_DET="getUnlinkCNRecDetails";
	
	/**
	 * Instantiates a new pymt abstract dao impl.
	 */
	public PymtAbstractDAOImpl()
	{
		nameSpace=NAME_SPACE;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payments.common.IPymtAbstractDAO#getPymtCancellationSummaryRecords(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public List<EippPymtVO> getPymtCancellationSummaryRecords(
			EippPymtVO dataVO) throws BNPApplicationException {
		List<EippPymtVO> pymtCancelSummaryList = null;
		try{
			pymtCancelSummaryList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_PYMT_CANCEL_SUMMARY), dataVO);
		}catch (DataAccessException e) {
			LOGGER.error("Error Occured while getting getPymtCancellationSummaryRecords "+e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return pymtCancelSummaryList;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payments.common.IPymtAbstractDAO#getPymtAuditRecDetails(long)
	 */
	@Override
	public List<EippPymtVO> getPymtAuditRecDetails(long pymtId)
			throws BNPApplicationException {
			List<EippPymtVO> pymtAuditDet = null;
			try{
				pymtAuditDet = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_PYMT_AUDIT_DET) , pymtId);
			}catch (DataAccessException e) {
				LOGGER.error("Error Occured while getting getPymtAuditRecDetails "+e.getMessage());
				throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
			}
		return pymtAuditDet;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payments.common.IPymtAbstractDAO#getCreditNoteRecDetails(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public List<EippCreditNoteVO> getCreditNoteRecDetails(
			EippPymtVO dataVO) throws BNPApplicationException {
		List<EippCreditNoteVO> creditNoteDetList = null;
		try{
			creditNoteDetList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_CREDIT_NOTE_DET) , dataVO);
		}catch (DataAccessException e) {
			LOGGER.error("Error Occured while getting getCreditNoteRecDetails "+e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return creditNoteDetList;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payments.common.IPymtAbstractDAO#getPymtAdjustmentRecDetails(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public List<PaymentAdjustMentCodeVO> getPymtAdjustmentRecDetails(
			EippPymtVO dataVO) throws BNPApplicationException {
		List<PaymentAdjustMentCodeVO> pymtAdjDetList = null ;
		try{
			pymtAdjDetList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_PYMT_ADJ_DET), dataVO);
		}catch (DataAccessException e) {
			LOGGER.error("Error Occured while getting getPymtAdjustmentRecDetails "+e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return pymtAdjDetList;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payments.common.IPymtAbstractDAO#getSplitPymtAmtDetails(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public List<SplitPaymentVO> getSplitPymtAmtDetails(
			EippPymtVO dataVO) throws BNPApplicationException {
		List<SplitPaymentVO> splitPymtAmtDetList = null;
		try{
			splitPymtAmtDetList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_SPLIT_PYMT_AMT_DET), dataVO);
		}catch (DataAccessException e) {
			LOGGER.error("Error Occured while getting getSplitPymtAmtDetails "+e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return splitPymtAmtDetList;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payments.common.IPymtAbstractDAO#getInvoiceDetails(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public List<EippInvoiceVO> getInvoiceDetails(EippPymtVO dataVO)
			throws BNPApplicationException {
		List<EippInvoiceVO> invDetailList =null;
		try{
			invDetailList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_INV_DET ), dataVO);
		}catch (DataAccessException e) {
			LOGGER.error("Error Occured while getting InvoiceDetails "+e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return invDetailList;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payments.common.IPymtAbstractDAO#getLineItemDetails(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public List<EippInvCntLineItemVO> getLineItemDetails(EippPymtVO dataVO)
			throws BNPApplicationException {
		List<EippInvCntLineItemVO> lineItemDetList = null;
		try{
			lineItemDetList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_LINE_ITEM_DET), dataVO);
		}catch (DataAccessException e) {
			LOGGER.error("Error Occured while getting LineItemDetails "+e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return lineItemDetList;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payments.common.IPymtAbstractDAO#getPymtAuthorizationSummaryRecords(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public List<EippPymtVO> getPymtAuthorizationSummaryRecords(
			EippPymtVO dataVO) throws BNPApplicationException {
		List<EippPymtVO> pymtAuthoSummaryList = null;
		try{
			pymtAuthoSummaryList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_PYMT_AUTHO_SUMMARY),dataVO);
		}catch (DataAccessException e) {
			LOGGER.error("Error Occured while getting PymtAuthorizationSummaryRecords "+e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return pymtAuthoSummaryList;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payments.common.IPymtAbstractDAO#authorizePymtRecord(java.lang.String)
	 */
	@Override
	public void authorizePymtRecord(EippPymtVO eippPymtVO)
			throws BNPApplicationException {
		try{
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_PYMT_REC_STATUS_FOR_APPROVAL), eippPymtVO);
		}catch (DataAccessException e) {
			LOGGER.error("Error Occured While Authorizing Pymt record"+e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		
	}
	
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payments.common.IPymtAbstractDAO#isDualControlIsEnabled(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public String isDualControlIsEnabled(EippPymtVO dataVO)
			throws BNPApplicationException {
			String dualControl = null;
			try{
				dualControl = (String)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_DUAL_CONTROL_STATUS_FOR_ORG_ID), dataVO);
				if(dualControl == null){
					dualControl="N";
				}
			}catch (DataAccessException e) {
				LOGGER.error("Error Occured in isDualControlIsEnabled "+e.getMessage());
				throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
			}
		return dualControl;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payments.common.IPymtAbstractDAO#getFinancialInquirySummaryRecords(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public List<EippPymtVO> getFinancialInquirySummaryRecords(
			EippPymtVO dataVO) throws BNPApplicationException {
		List<EippPymtVO> financialInqDet = null;
		try{
			dataVO.setOrgType(getOrgType(dataVO.getUserType()));
			financialInqDet = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_FIN_INQ_DETAIL), dataVO);
		}catch (DataAccessException e) {
			LOGGER.error("Error Occured while fectching the Financial Inquiry Summary Records"+e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return financialInqDet;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payments.common.IPymtAbstractDAO#getPymtAdjParamDetails(long)
	 */
	@Override
	public List<PymtAdjustmentCodeCustomVO> getPymtAdjParamDetails(
			long adjId) throws BNPApplicationException {
		List<PymtAdjustmentCodeCustomVO> pymtAdjParamDet =null;
		try{
			
			pymtAdjParamDet= getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_PYMT_ADJ_PARAM_DET), adjId);
		}catch (DataAccessException e) {
			LOGGER.error("Error Occured while fectching the Pymt Adj Param Details"+e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return pymtAdjParamDet;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payments.common.IPymtAbstractDAO#rejectPymtCancellation(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public void rejectPymtCancellation(EippPymtVO dataVO)
			throws BNPApplicationException {
			String prevRecStatus = null;
		try{
			prevRecStatus = (String) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace( GET_PREV_PYMT_STATUS), dataVO.getPymtId());
			dataVO.setPreviousRecStatus(prevRecStatus);	
			dataVO.setRemarks(null);
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_PYMT_REJECTION_STATUS), dataVO);
			
		}catch (DataAccessException e) {
			LOGGER.error("Error Occured in While rejecting Payment Cancellation screen"+ e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		
	}

	/**
	 * Checks if is market place.
	 *
	 * @param userType the user type
	 * @return the string
	 */
	private String isMarketPlace(String userType){
		
		if(userType.contains(ScreenConstants.BCMMPALL) || userType.contains(ScreenConstants.SCMMPALL) || 
				userType.contains(ScreenConstants.SCMMPU) || userType.contains(ScreenConstants.BCMMPU) ||
				userType.contains(ScreenConstants.BCMMPOA) || userType.contains(ScreenConstants.SCMMPOA)){
			return "Y";
		}else {
			return "N";
		}
		
	}
	
	/**
	 * Gets the org type.
	 *
	 * @param userType the user type
	 * @return the org type
	 */
	private String getOrgType(String userType){
		String orgType = null;
		if(userType.equalsIgnoreCase("BA")){
			
			orgType ="BA";
		}
		else if(userType.equalsIgnoreCase(ScreenConstants.BCMBOA) || userType.equalsIgnoreCase(ScreenConstants.BCMBALL) || userType.equalsIgnoreCase(ScreenConstants.BCMB) ||
			userType.equalsIgnoreCase(ScreenConstants.SCMBOA) || userType.equalsIgnoreCase(ScreenConstants.SCMB) || userType.equalsIgnoreCase(ScreenConstants.SCMBALL) ||
			userType.equalsIgnoreCase(ScreenConstants.BCMMPBOA) || userType.equalsIgnoreCase(ScreenConstants.BCMMPBALL) || userType.equalsIgnoreCase(ScreenConstants.BCMMPB) ||
			userType.equalsIgnoreCase(ScreenConstants.SCMMPBOA) || userType.equalsIgnoreCase(ScreenConstants.SCMMPBALL) || userType.equalsIgnoreCase(ScreenConstants.SCMMPB) )
			
		{
			orgType = "B";
		}else if (userType.equalsIgnoreCase(ScreenConstants.SCMSOA) || userType.equalsIgnoreCase(ScreenConstants.SCMS) || userType.equalsIgnoreCase(ScreenConstants.SCMSALL) ||
				userType.equalsIgnoreCase(ScreenConstants.BCMSOA) || userType.equalsIgnoreCase(ScreenConstants.BCMS) || userType.equalsIgnoreCase(ScreenConstants.BCMSALL) ||
				userType.equalsIgnoreCase(ScreenConstants.BCMMPSOA) || userType.equalsIgnoreCase(ScreenConstants.BCMMPSALL) || userType.equalsIgnoreCase(ScreenConstants.BCMMPS) ||
				userType.equalsIgnoreCase(ScreenConstants.SCMMPSOA) || userType.equalsIgnoreCase(ScreenConstants.SCMMPSALL) || userType.equalsIgnoreCase(ScreenConstants.SCMMPS)) {
			orgType = "S";
		}else if (userType.contains("MP")) {
			orgType = "M";
		}
		return orgType;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payments.common.IPymtAbstractDAO#getBuyerOrgIdList(java.lang.String, java.lang.String)
	 */
	@Override
	public List<NameValueVO> getBuyerOrgIdList(String userId , String userTypeId)
			throws BNPApplicationException {
		List<NameValueVO> buyerOrgIdList =null;
		HashMap<String, String> paramDet = null;
		paramDet = getParamDetails(userId ,userTypeId);
		buyerOrgIdList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_BUYER_ORG_LIST), paramDet);
		return buyerOrgIdList;
	}
	
	private HashMap<String, String> getParamDetails(String userId , String userTypeId ){
		HashMap<String, String> param = new HashMap<String, String>();
		param.put("userId", userId);
		param.put("UserTypeId", userTypeId);
		param.put("isMarketPlace", isMarketPlace(userTypeId));
		param.put("orgType", getOrgType(userTypeId));
		return param;
	}
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payments.common.IPymtAbstractDAO#getSupplierOrgIdList(java.lang.String, java.lang.String)
	 */
	@Override
	public List<NameValueVO> getSupplierOrgIdList(String userId , String userTypeId)
			throws BNPApplicationException {
		List<NameValueVO> supplierOrgIdList =null;
		HashMap<String, String> paramDet = null;
		paramDet = getParamDetails(userId ,userTypeId);
		supplierOrgIdList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_SUPPLIER_ORG_LIST), paramDet);
		return supplierOrgIdList;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payments.common.IPymtAbstractDAO#getMarketPlaceOrgIdList(java.lang.String, java.lang.String)
	 */
	@Override
	public List<NameValueVO> getMarketPlaceOrgIdList( String userId , String userTypeId)
			throws BNPApplicationException {
		List<NameValueVO> marketPlaceOrgIdList =null;
		HashMap<String, String> paramDet = null;
		paramDet = getParamDetails(userId ,userTypeId);
		marketPlaceOrgIdList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_MARKET_PLACE_ORG_LIST), paramDet);
		return marketPlaceOrgIdList;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payments.common.IPymtAbstractDAO#insertPymtAccessLogDetails(com.bnp.eipp.services.vo.payments.common.EippPymtAuditVO)
	 */
	@Override
	public void insertPymtAccessLogDetails(EippPymtAuditVO auditVO)
			throws BNPApplicationException {
		
		try{
		getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_PYMT_ACCESS_LOG), auditVO);
		}catch(DataAccessException e){
			LOGGER.error("Error While insering   Payment Audit  Data "+e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payments.common.IPymtAbstractDAO#getLineItemAuditRecDetails(long)
	 */
	@Override
	public List<EippNonFinInqLineItemVO> getLineItemAuditRecDetails(long lineItemId) throws BNPApplicationException{
		
		List<EippNonFinInqLineItemVO> lineItemAuditDetList =null;
		try{
			lineItemAuditDetList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_LINE_ITM_AUDIT_DET), lineItemId);
		}catch (DataAccessException e) {
			LOGGER.error("Error While getting LineItemAuditRecDetails    "+e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		
		return lineItemAuditDetList;
	}
	
	@Override
	public String getBranchTimeZone(String orgId)
			throws BNPApplicationException {
		String branchTimeZone = null;
		
		
		try{
			branchTimeZone = (String) getSqlMapClientTemplate().queryForObject((getQueryNameWithNameSpace( GET_BRANCH_TIME_ZONE)), orgId);
		}catch(DataAccessException e){
			LOGGER.error("in PymtAbstractDAOImpl getBranchTimeZone - exception :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return branchTimeZone;

	}

	@Override
	public String getNameSpace() {
		
		return NAME_SPACE;
	}
	
	@Override
	public EippPymtVO getselectedDataDetails(long pymtId)
			throws BNPApplicationException {
		List<EippPymtVO> financialInqDet = null;
		HashMap<String, Long> param = new HashMap<String, Long>();
		param.put("pymtId", pymtId);
		try{
			financialInqDet = (List<EippPymtVO>)getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_FIN_INQ_DETAIL_FRM_THR_SCREEN),param );
			((EippPymtVO)financialInqDet.get(0)).setInvoiceList(getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_INV_DET_OTHER ), param));
		}
		catch(DataAccessException e) 
		{
			LOGGER.error("Error Occured in While retriving record for detail screen"+ e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return (EippPymtVO)financialInqDet.get(0);
	}

	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.common.IPymtAbstractDAO#insertAuthAuditMapping(com.bnp.eipp.services.vo.payment.EippPymtVO, java.util.List)
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public void insertAuthAuditMapping(EippPymtVO transVO,
			List<String> authLevelList) throws BNPApplicationException {
		final EippPymtVO finalTransVO = transVO;
		final List<String> finalAuthLevelList = authLevelList;
		try {
			getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
				@SuppressWarnings("unchecked")
				public List<Object> doInSqlMapClient(SqlMapExecutor executor)
				throws SQLException {
					List<Object> list = null;
	
					try {
						int count = 0;
						for (String authLevel : finalAuthLevelList) {
							count++;
							EippPymtVO vo = new EippPymtVO();
							vo.setPymtId(finalTransVO.getPymtId());
							vo.setNextEligibleAuthLevel(authLevel);
							vo.setAuthLevelOrd(count);
							if(count == 1){
								vo.setCheckerId(finalTransVO.getCheckerId());
							}
							executor.startBatch();
	
							executor.insert(getQueryNameWithNameSpace(INSERT_AUTH_MTX_MAPPING), vo);
						}
	
						list = executor.executeBatchDetailed();
	
					} catch (BatchException e) {							
						LOGGER.error("Batch exception in insertAuthAuditMapping",e);
						throw new SQLException(e);
					} 
					// R7.0 Fortify issues
					//LOGGER.debug("List :: " + list);
					return list;
				}
			});
		} catch (DataAccessException e) {
			LOGGER.error("DataAccessException in insertAuthAuditMapping",e);
			throw new BNPRuntimeException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.common.IPymtAbstractDAO#updateAuthlevelInMapping(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	@Override
	public void updateAuthlevelInMapping(EippPymtVO transVO)
			throws BNPApplicationException {
		LOGGER.info("In PymtAbstractDAOImpl updateAuthlevelInMapping");
		try{
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_AUTH_MTX_MAPPING), transVO);
		}catch (DataAccessException exception){
			LOGGER.error("DataAccessException in updateAuthlevelInMapping:",exception);
			throw new BNPRuntimeException(ErrorConstants.DATABASE_ERROR);
		}catch (Exception exception) {
			LOGGER.error("Exception in updateAuthlevelInMapping:",exception);
			throw new BNPRuntimeException(ErrorConstants.DATABASE_ERROR);
		}		
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.common.IPymtAbstractDAO#updatePaymentAuthMatxMidLevels(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	@Override
	public void updatePaymentAuthMatxMidLevels(EippPymtVO transVO)
			throws BNPApplicationException {
		LOGGER.info("In PymtAbstractDAOImpl updatePaymentAuthMatxMidLevels");
		try{
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_AUTH_MTX_MAP_MID_LVLS), transVO);
		}catch (DataAccessException exception){
			LOGGER.error("DataAccessException in updatePaymentAuthMatxMidLevels:",exception);
			throw new BNPRuntimeException(ErrorConstants.DATABASE_ERROR);
		}catch (Exception exception) {
			LOGGER.error("Exception in updatePaymentAuthMatxMidLevels:",exception);
			throw new BNPRuntimeException(ErrorConstants.DATABASE_ERROR);
		}				
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.common.IPymtAbstractDAO#updatePaymentAuthMatx(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	@Override
	public void updatePaymentAuthMatx(EippPymtVO transVO)
			throws BNPApplicationException {
		LOGGER.info("In PymtAbstractDAOImpl updatePaymentAuthMatx");
		try{
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_PYMT_AUT_MATX), transVO);
		}catch (DataAccessException exception){
			LOGGER.error("DataAccessException in updatePaymentAuthMatx:",exception);
			throw new BNPRuntimeException(ErrorConstants.DATABASE_ERROR);
		}catch (Exception exception) {
			LOGGER.error("Exception in updatePaymentAuthMatx:",exception);
			throw new BNPRuntimeException(ErrorConstants.DATABASE_ERROR);
		}		
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.common.IPymtAbstractDAO#checkApprovedListForUser(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	@Override
	public int checkApprovedListForUser(EippPymtVO transVO)
			throws BNPApplicationException {
		int recordCount = 0;
		try{
			recordCount = (Integer) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(
					GET_USER_EXIST_APPR_COUNT), transVO);
		}catch (Exception exception) {
			LOGGER.error("Exception in checkApprovedListForUser:",exception);
			throw new BNPRuntimeException(ErrorConstants.DATABASE_ERROR);
		}
		return recordCount;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.common.IPymtAbstractDAO#checkValidUser(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	@Override
	public String checkValidUser(EippPymtVO transVO) throws BNPApplicationException {
		String validUser = null;
		try{
			validUser = (String) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(
					CHECK_VALID_USER), transVO);
		}catch (Exception exception) {
			LOGGER.error("Exception in checkValidUser:",exception);
			throw new BNPRuntimeException(ErrorConstants.DATABASE_ERROR);
		}
		return validUser;

	}
	
	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Integer> getLeadOrgDetails(final EippPymtVO pymtVO) throws BNPApplicationException {
		Map<String, Integer> leadOrgMap = null;
		try {
			leadOrgMap = (Map<String, Integer>) getSqlMapClientTemplate().queryForMap(getQueryNameWithNameSpace(GEP_LEAD_ORG_DETAILS), pymtVO, "key", "value");
		}
		catch (DataAccessException ex) {
			LOGGER.debug("Exception while getting lead org details", ex);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		catch (RuntimeException ex) {
			LOGGER.debug("Exception while getting lead org details", ex);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return leadOrgMap;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<String> getEippPaymentColumnDetails(final EippPymtVO pymtVO) throws BNPApplicationException {
		List<String> columnLst = null ;
		try {
			columnLst = (List<String>) getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_EIPP_CN_COL_DETAILS), pymtVO);
		} 
		catch (DataAccessException ex) {
			LOGGER.debug("Exception while getting eipp payment column details", ex);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		catch (RuntimeException ex) {
			LOGGER.debug("Exception while getting eipp payment column details", ex);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return columnLst;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<String> getEippPaymentDetails(final EippPymtVO pymtVO) throws BNPApplicationException {
		List<String> cnLst = null ;
		try {
			cnLst = (List<String>) getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_EIPP_CN_DETAILS), pymtVO);
		} 
		catch (DataAccessException ex) {
			LOGGER.debug("Exception while getting eipp payment details", ex);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		catch (RuntimeException ex) {
			LOGGER.debug("Exception while getting eipp payment details", ex);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return cnLst;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.common.IPymtAbstractDAO#getUnlinkCreditNoteRecDetails(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	@Override
	public List<EippCreditNoteVO> getUnlinkCreditNoteRecDetails(
			EippPymtVO dataVO) throws BNPApplicationException {
		List<EippCreditNoteVO> creditNoteDetList = null;
		try{
			creditNoteDetList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_UNLINK_CREDIT_NOTE_DET),
					dataVO);
		}catch (DataAccessException e) {
			LOGGER.error("Error Occured while getting getUnlinkCreditNoteRecDetails "+e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return creditNoteDetList;

	}
}
