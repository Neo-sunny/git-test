/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 17, 201211:35:09 AM
 * 
 * Purpose:      DeptAllocMapVO.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 17, 201211:35:09 AM        Oracle Financial Services Software Ltd                  Initial Version
 * March 02 2012		          Oracle Financial Services Software Ltd                  Added users list for dept approval process   
************************************************************************************************************************************************************/

package com.bnp.eipp.services.invoice.vo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class DeptAllocMapVO {

	private long invId;
	
	private long lineItemId;
	
	private String deptId;
	
	private String userId;
	
	private String allocType;
	
	private String active;
	
	private int allocLevel;
	
	private String status;
	
	private String reassignedBy;
	
	private Date reassignedDate;
	
	private String approvedBy;
	
	private Date approvedDate;
	
	private String approvalLevel;
	
	private String approvalFlag;
	
	private List<String> reassignUserList = new ArrayList<String>();
	
	private List<String> reassignDeptList = new ArrayList<String>();
	
	private boolean saveButton;
	
	private boolean enableReassignInvBtn = true;
	
	private boolean enableReassignInvLnItmBtn = true;
	
	private List<Long> lineItemIdList;
	
	private long deptPkId;
	
	/**
	 * @return the invId
	 */
	public long getInvId() {
		return invId;
	}

	/**
	 * @param invId the invId to set
	 */
	public void setInvId(long invId) {
		this.invId = invId;
	}

	/**
	 * @return the lineItemId
	 */
	public long getLineItemId() {
		return lineItemId;
	}

	/**
	 * @param lineItemId the lineItemId to set
	 */
	public void setLineItemId(long lineItemId) {
		this.lineItemId = lineItemId;
	}

	/**
	 * @return the deptId
	 */
	public String getDeptId() {
		return deptId;
	}

	/**
	 * @param deptId the deptId to set
	 */
	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the allocType
	 */
	public String getAllocType() {
		return allocType;
	}

	/**
	 * @param allocType the allocType to set
	 */
	public void setAllocType(String allocType) {
		this.allocType = allocType;
	}

	/**
	 * @return the active
	 */
	public String getActive() {
		return active;
	}

	/**
	 * @param active the active to set
	 */
	public void setActive(String active) {
		this.active = active;
	}

	/**
	 * @return the allocLevel
	 */
	public int getAllocLevel() {
		return allocLevel;
	}

	/**
	 * @param allocLevel the allocLevel to set
	 */
	public void setAllocLevel(int allocLevel) {
		this.allocLevel = allocLevel;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the reassignedBy
	 */
	public String getReassignedBy() {
		return reassignedBy;
	}

	/**
	 * @param reassignedBy the reassignedBy to set
	 */
	public void setReassignedBy(String reassignedBy) {
		this.reassignedBy = reassignedBy;
	}

	/**
	 * @return the reassignedDate
	 */
	public Date getReassignedDate() {
		return reassignedDate;
	}

	/**
	 * @param reassignedDate the reassignedDate to set
	 */
	public void setReassignedDate(Date reassignedDate) {
		this.reassignedDate = reassignedDate;
	}

	/**
	 * @return the approvedBy
	 */
	public String getApprovedBy() {
		return approvedBy;
	}

	/**
	 * @param approvedBy the approvedBy to set
	 */
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	/**
	 * @return the approvedDate
	 */
	public Date getApprovedDate() {
		return approvedDate;
	}

	/**
	 * @param approvedDate the approvedDate to set
	 */
	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	public void setApprovalLevel(String approvalLevel) {
		this.approvalLevel = approvalLevel;
	}

	public String getApprovalLevel() {
		return approvalLevel;
	}

	/**
	 * @param approvalFlag the approvalFlag to set
	 */
	public void setApprovalFlag(String approvalFlag) {
		this.approvalFlag = approvalFlag;
	}

	/**
	 * @return the approvalFlag
	 */
	public String getApprovalFlag() {
		return approvalFlag;
	}

	/**
	 * @param reassignUserList the reassignUserList to set
	 */
	public void setReassignUserList(List<String> reassignUserList) {
		this.reassignUserList = reassignUserList;
	}

	/**
	 * @return the reassignUserList
	 */
	public List<String> getReassignUserList() {
		return reassignUserList;
	}

	/**
	 * @param reassignDeptList the reassignDeptList to set
	 */
	public void setReassignDeptList(List<String> reassignDeptList) {
		this.reassignDeptList = reassignDeptList;
	}

	/**
	 * @return the reassignDeptList
	 */
	public List<String> getReassignDeptList() {
		return reassignDeptList;
	}

	/**
	 * @param saveButton the saveButton to set
	 */
	public void setSaveButton(boolean saveButton) {
		this.saveButton = saveButton;
	}

	/**
	 * @return the saveButton
	 */
	public boolean isSaveButton() {
		return saveButton;
	}

	/**
	 * @param lineItemIdList the lineItemIdList to set
	 */
	public void setLineItemIdList(List<Long> lineItemIdList) {
		this.lineItemIdList = lineItemIdList;
	}

	/**
	 * @return the lineItemIdList
	 */
	public List<Long> getLineItemIdList() {
		return lineItemIdList;
	}
	
	/**
	 * @param enableReassignInvBtn the enableReassignInvBtn to set
	 */
	public void setEnableReassignInvBtn(boolean enableReassignInvBtn) {
		this.enableReassignInvBtn = enableReassignInvBtn;
	}

	/**
	 * @return the enableReassignInvBtn
	 */
	public boolean isEnableReassignInvBtn() {
		return enableReassignInvBtn;
	}

	/**
	 * @param enableReassignInvLnItmBtn the enableReassignInvLnItmBtn to set
	 */
	public void setEnableReassignInvLnItmBtn(boolean enableReassignInvLnItmBtn) {
		this.enableReassignInvLnItmBtn = enableReassignInvLnItmBtn;
	}

	/**
	 * @return the enableReassignInvLnItmBtn
	 */
	public boolean isEnableReassignInvLnItmBtn() {
		return enableReassignInvLnItmBtn;
	}

	public void setDeptPkId(long deptPkId) {
		this.deptPkId = deptPkId;
	}

	public long getDeptPkId() {
		return deptPkId;
	}
	
}
