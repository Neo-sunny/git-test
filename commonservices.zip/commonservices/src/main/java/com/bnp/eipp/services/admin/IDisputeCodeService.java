/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   23 JAN 2012
 * 
 * Purpose:      Dispute Code Screen  
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 23 JAN 2012                      Oracle Financial Services Software Ltd                      Initial Version 
 * 21 Jul 2012						Reena S										Release 3.0		EIPP Phase II Changes
 ***************************************************************************/
package com.bnp.eipp.services.admin;

import java.util.List;

import com.bnp.eipp.services.vo.admin.DisputeCodeVO;
import com.bnp.scm.services.common.IAbstractService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

public interface IDisputeCodeService  extends IAbstractService<DisputeCodeVO>{
	/**
	 * to fetch the   Dispute Code  Summary Table Data List
	 * @param disputeVO
	 * @return
	 * @throws BNPApplicationException
	 */
	List<DisputeCodeVO> getDisputeCodeSummaryDetails (DisputeCodeVO disputeVO) throws BNPApplicationException;
	
	/**
	 * to fetch the Bill Type Details for the selected Org Id
	 * @param orgId
	 * @return
	 * @throws BNPApplicationException
	 */
	List<NameValueVO> getBillTypeForOrgId(String orgId) throws BNPApplicationException;
	
	/**
	 * to fetch the Customer Role for the  selected Org Id
	 * @param orgId
	 * @return
	 * @throws BNPApplicationException
	 */
	String getCustRoleForOrgId (String orgId) throws BNPApplicationException;
	
	/**
	 * to fetch the OrgId List for the Logged-in User
	 * @param userId
	 * @return
	 * @throws BNPApplicationException
	 */
	List<NameValueVO> getOrgIdListForUser(String userId,String userType) throws BNPApplicationException;
	
	/**
	 * to check the Duplicate Record for the Dispute Code
	 * @param disputecodeVO
	 * @return
	 * @throws BNPApplicationException
	 */
	int checkDuplicateRecords(DisputeCodeVO disputecodeVO) throws BNPApplicationException;
	/**
	 * to fetch the modified record Details from the Trans Table
	 * @param disputecodeVO
	 * @return
	 * @throws BNPApplicationException
	 */
	DisputeCodeVO getModifiedRecord(DisputeCodeVO disputecodeVO) throws BNPApplicationException;

	/**
	 * This API returns the resolution codes available for the 
	 * given customer organization and its bill type
	 * @param codeVO
	 * @return
	 * @throws BNPApplicationException
	 */
	List<DisputeCodeVO> getDisputeCodeList(DisputeCodeVO codeVO) throws BNPApplicationException;
	/**
	 * This API is to check the Dependency to Delete the Dispute Code
	 * @param dataVO
	 * @return
	 * @throws BNPApplicationException
	 */
	boolean checkDependencyForDelete(DisputeCodeVO dataVO) throws BNPApplicationException;
					
	
}
