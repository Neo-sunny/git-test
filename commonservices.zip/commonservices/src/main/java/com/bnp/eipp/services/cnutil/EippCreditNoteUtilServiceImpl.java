/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 6, 20127:00:50 PM
 * 
 * Purpose:      CreditNoteUtilServiceImpl.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 6, 20127:00:50 PM        Oracle Financial Services Software Ltd                  Initial Version  
 * 24/04/2012					Sandhya R												SIT #2068
 * 13 Aug 2012					Arun G												 Eipp Phase2 events
 * 30 Oct 2012 		 			Arun G													Events ST Issues
************************************************************************************************************************************************************/

package com.bnp.eipp.services.cnutil;

import java.math.BigDecimal;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.dao.cnutil.IEippCNUtilDao;
import com.bnp.eipp.services.invoice.IEippInvoiceService;
import com.bnp.eipp.services.invoice.util.EippAuditConstants;
import com.bnp.eipp.services.invoice.vo.EippAuditVO;
import com.bnp.eipp.services.invoice.vo.EippCreditNoteVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.vo.cnutil.EippCNUtilizationVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.event.EventType;
import com.bnp.scm.services.common.event.IEventDelegate;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.EventLogVO;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;

@Component
public class EippCreditNoteUtilServiceImpl implements IEippCreditNoteUtilService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(EippCreditNoteUtilServiceImpl.class);
	
	@Autowired
	private IEippCNUtilDao eippCNUtilDao;
	
	@Autowired
	private IEippInvoiceService invoiceService;
	
	@Autowired
	private IEventDelegate eventDelegateImpl;
	
	@Override
	public List<EippCreditNoteVO> getLinkedCreditNotes(long fileId)
			throws BNPApplicationException {
		return eippCNUtilDao.getLinkedCreditNotes(fileId);
	}

	@Override
	public void createCreditNoteUtilization(EippCNUtilizationVO cntUtilVO)
			throws BNPApplicationException {
		eippCNUtilDao.createCreditNoteUtilization(cntUtilVO);
	}

	@Override
	public void utilizeLinkedCreditNotes(FileDetailsVO detailsVO) throws BNPApplicationException {
		long fileId = detailsVO.getFileId();
		
		List<EippCreditNoteVO> creditNoteList = getLinkedCreditNotes(fileId);
		
		EippInvoiceVO invoiceVO = null;
		EippCNUtilizationVO cnUtilVO = null;
		
		BigDecimal cntRemAmt = null;
		BigDecimal remInvAmt = null;
		
		String action = null;
		
		for (EippCreditNoteVO creditNoteVO : creditNoteList) {
			
			if (BigDecimal.ZERO.compareTo(
					creditNoteVO.getCntRemAmt()) == 0) {
				// Ignoring the credit note that is already utilized
				continue;
			}
			
			invoiceVO = invoiceService.getInvoice(creditNoteVO);
			
			// Handling concurrency
			updateTxnTimestamp(invoiceVO);
			
			Properties values = invoiceService.getOrgConfigForCNUtilization(
										creditNoteVO.getSupplierOrgId());
			creditNoteVO.setUtilParams(values);
			
			if (creditNoteVO.isCNUtilizedAgainstInvalidInvoice(invoiceVO)) {
					checkAndUpdateCreditNote(creditNoteVO);
					insertEventLog(creditNoteVO, 
							EventType.EIPP_CN_AUTO_OFFSET_FAILED);
					resetProcessingFlag(invoiceVO);
					continue;
			}
			
			cntRemAmt = creditNoteVO.getCntRemAmt();
			
			remInvAmt = invoiceVO.getInvRemAmt().subtract(
					invoiceVO.getBlockedAmt());

			if (BigDecimal.ZERO.compareTo(remInvAmt) < 0) {
				// Full utilization of credit note
				if (invoiceVO.canFullyUtilizeCreditNote(creditNoteVO)) {
					invoiceVO.utilizeCNAgainstInvoice(creditNoteVO);
					
					cnUtilVO = EippCNUtilizationVO.createCNUtilVO(invoiceVO, 
							creditNoteVO, cntRemAmt);
					// Inserting invoice closed event only when the remaining invoice amount is zero
					if (BigDecimal.ZERO.compareTo(invoiceVO.getInvRemAmt()) == 0) {
						action = EippAuditConstants.INV_CLOSED;
						insertEventLog(invoiceVO, 
								EventType.EIPP_INV_CLOSED);
					}
				} else {
					 if (!creditNoteVO.checkPartialUtilization()) {
						 updateEippCreditNote(creditNoteVO);
						 insertEventLog(creditNoteVO, 
									EventType.EIPP_CN_AUTO_OFFSET_FAILED);
						 resetProcessingFlag(invoiceVO);
						 continue;
					 }
					 remInvAmt = invoiceVO.getInvRemAmt();
					invoiceVO.utilizeCNAgainstInvoice(creditNoteVO);
					cnUtilVO = EippCNUtilizationVO.createCNUtilVO(invoiceVO, 
							creditNoteVO, remInvAmt);
					action = EippAuditConstants.INV_PARTIALLY_UTILIZED;
				}
				updateEippInvoice(invoiceVO, action);
				updateEippCreditNote(creditNoteVO);
				createCreditNoteUtilization(cnUtilVO);
				insertEventLog(creditNoteVO,
						EventType.EIPP_CN_AUTO_OFFSET_SUCCESS);			
			}
		}
	}
	
	private void checkAndUpdateCreditNote(
			EippCreditNoteVO creditNoteVO) throws BNPApplicationException {
		
		if (creditNoteVO.checkOrgUnlikedFlag() || 
				creditNoteVO.checkToRejectCrdNote()) {
				updateEippCreditNote(creditNoteVO);	
			}
		
	}
	
	
	private void insertEventLog(EippInvoiceVO invoiceVO, EventType eventType) {

		EventLogVO eventVO = new EventLogVO();
		
		try {
			eventVO.setReferenceKey(String.valueOf(invoiceVO.getInvId()));
			eventVO.setEventType(eventType);
			eventVO.setSellerOrgId(invoiceVO.getSupplierOrgId());
			eventVO.setBuyerOrgId(invoiceVO.getBuyerOrgId());
			eventVO.setMarketPlaceOrgID(invoiceVO.getMarketPlaceOrgId());
			eventVO.setEventInitiator(invoiceVO.getMakerId());
			eventDelegateImpl.initEvents(eventVO);
		} catch (BNPApplicationException e) {
			LOGGER.error("Error while inserting into event log" + e);
		}
	}
	
	private void insertEventLog(EippCreditNoteVO creditNoteVO, EventType eventType) {
		EventLogVO eventVO = new EventLogVO();
		
		try {
			eventVO.setReferenceKey(String.valueOf(creditNoteVO.getCntId()));
			eventVO.setEventType(eventType);
			eventVO.setSellerOrgId(creditNoteVO.getSupplierOrgId());
			eventVO.setBuyerOrgId(creditNoteVO.getBuyerOrgId());
			eventVO.setMarketPlaceOrgID(creditNoteVO.getMarketPlaceOrgId());
			eventDelegateImpl.initEmailEvent(eventVO);
		} catch (BNPApplicationException e) {
			LOGGER.error("Error while inserting into event log" + e);
		}
	}
	
	private void updateEippInvoice(EippInvoiceVO invoiceVO, 
					String action) throws BNPApplicationException {
		invoiceService.updateEippInvoice(invoiceVO);		
		invoiceService.insertInvoiceIntoHistory(invoiceVO);
		createInvoiceAudit(invoiceVO, action);
	}
	
	private void updateEippCreditNote(EippCreditNoteVO creditNoteVO) throws BNPApplicationException {
		invoiceService.updateEippCreditNote(creditNoteVO);
		invoiceService.insertCreditNoteIntoHistory(creditNoteVO);
	}
	
	private void createInvoiceAudit(EippInvoiceVO invoice, String action) {
		EippAuditVO invAudit = new EippAuditVO();
		try {
			invAudit.setStatus(invoice.getInvStatus());
			invAudit.setAction(action);
			invAudit.setAuditUser(BNPConstants.SYSTEM);
			invAudit.setInvId(invoice.getInvId());
			invoiceService.createInvoiceAudit(invAudit);
		} catch (BNPApplicationException e) {
			LOGGER.error("Error while inserting invoice audit " + e.getErrorCode());
		}
	}
	
	private void updateTxnTimestamp(EippInvoiceVO invoice) {
		try {
			if (invoice != null) {
				invoiceService.updateTxnTimestamp(invoice);
			}
		} catch (BNPApplicationException e) {
			invoice.setRemarks(String.valueOf(e.getErrorCode()));
			LOGGER.error("Error while updating txn timestamp : " + e.getErrorCode());
		}
	}
	
	private void resetProcessingFlag(EippInvoiceVO invoice) {
		try {
			if (invoice != null) {
				invoiceService.resetProcessingFlag(invoice);
			}
		} catch (BNPApplicationException e) {
			LOGGER.error("Error while resetting process flag " + e.getErrorCode());
		}
	}
	
}
