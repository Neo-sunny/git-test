/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   23 JAN 2012
 * 
 * Purpose:      Dispute Code Screen  
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 23 JAN 2012                      Oracle Financial Services Software Ltd                                    Initial Version 
 * 21 Jul 2012 						Reena S										Release 3.0    EIPP Phase II changes
 ***************************************************************************/
package com.bnp.eipp.services.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.dao.admin.IDisputeCodeDAO;
import com.bnp.eipp.services.vo.admin.DisputeCodeVO;
import com.bnp.scm.services.common.AbstractServiceImpl;
import com.bnp.scm.services.common.dao.IAbstractDAO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

@Component
public class DisputeCodeServiceImpl extends AbstractServiceImpl<DisputeCodeVO> implements IDisputeCodeService {
	
	@Autowired
	private IDisputeCodeDAO disputeCodeDAO;
	
	@Override
	public IAbstractDAO getDAO() {
		return (IAbstractDAO) disputeCodeDAO;
	}

	
	@Override
	public List<DisputeCodeVO> getDisputeCodeSummaryDetails(
			DisputeCodeVO disputeVO) throws BNPApplicationException {
		
		return disputeCodeDAO.getDisputeCodeSummaryDetails(disputeVO);
	}



	@Override
	public List<NameValueVO> getBillTypeForOrgId(String orgId)
			throws BNPApplicationException {
		
		return disputeCodeDAO.getBillTypeDetailsForOrgId(orgId);
	}

	@Override
	public String getCustRoleForOrgId(String orgId)
			throws BNPApplicationException {
		
		return disputeCodeDAO.getCustRoleForOrgId(orgId);
	}

	@Override
	public List<NameValueVO> getOrgIdListForUser(String userId,String userType)
			throws BNPApplicationException {
		NameValueVO userDet=new NameValueVO();
		userDet.setValue(userId);
		userDet.setType(userType);
		
		return disputeCodeDAO.getOrgIdListForUser(userDet);
	}

	@Override
	public int checkDuplicateRecords(DisputeCodeVO disputecodeVO)
			throws BNPApplicationException {
		
		return disputeCodeDAO.checkDuplicateRecords(disputecodeVO);
	}


	@Override
	public DisputeCodeVO getModifiedRecord(DisputeCodeVO disputecodeVO)
			throws BNPApplicationException {
		
		return disputeCodeDAO.getModifiedRecord(disputecodeVO);
	}
	
	@Override
	public List<DisputeCodeVO> getDisputeCodeList(DisputeCodeVO codeVO) throws BNPApplicationException {
		return disputeCodeDAO.getDisputeCodeList(codeVO);
	}


	@Override
	public boolean checkDependencyForDelete(DisputeCodeVO dataVO)
			throws BNPApplicationException {
		boolean	flag = false;
		int count = disputeCodeDAO.getDisputeCodeCountForDelete(dataVO);
		if(count >0){
			flag = true;
		}else {
			flag= false;
		}
		return flag;
	}

}
