/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 6, 20128:21:34 PM
 * 
 * Purpose:      EippInvoiceDaoImpl.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 6, 20128:21:34 PM        Oracle Financial Services Software Ltd                  Initial Version
 * 21/04/2012			        Sandhya R												SIT # 1997
 * 23/04/2012			        Sandhya R												SIT # 1997
 * 14/05/2012			        Sandhya R												UAT #2240
 * 24 Aug 2012    				Gangadharan R							                MFU - Payment Preparation     
 * 06 Sep 2012 			        Reena S													Release 3.0		Release File Inq:Pymt preparation & Pymt status update     
 * 13 Sep 2012					Sandhya R												R3.0 Eipp Ph 2 : Dispute line item changes
 * 24 Sep 2012					Aarthi T											    Release File Inq - Rel 3.0 Matching and Reconcilation
************************************************************************************************************************************************************/

package com.bnp.eipp.services.dao.invoice;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.invoice.vo.DeptAllocMapVO;
import com.bnp.eipp.services.invoice.vo.EippAuditVO;
import com.bnp.eipp.services.invoice.vo.EippCreditNoteVO;
import com.bnp.eipp.services.invoice.vo.EippCustFieldsVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.invoice.vo.EippPymtStatusUpdateVO;
import com.bnp.eipp.services.vo.admin.DeptAllocRuleVO;
import com.bnp.eipp.services.vo.admin.DeptRuleCriteriaVO;
import com.bnp.eipp.services.vo.dispute.DisputeCustFieldsVO;
import com.bnp.eipp.services.vo.dispute.DisputeVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.ibatis.sqlmap.client.SqlMapExecutor;
import com.ibatis.sqlmap.engine.execution.BatchException;

@Component
@SuppressWarnings ("unchecked")
public class EippInvoiceDaoImpl extends SqlMapClientWrapper implements IEippInvoiceDao {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(EippInvoiceDaoImpl.class);
	
	private static final String GET_INVOICES_FOR_FILE_ID = "EippInvoiceNS.getInvoicesForFileId";
	private static final String GET_DEFAULT_DEPARTMENT = "EippInvoiceNS.getDefaultDepartment";
	private static final String GET_EXISTING_DEPT_RULES = "EippInvoiceNS.getExistingDeptRules";
	private static final String GET_DEPARTMENT_LIST = "EippInvoiceNS.getDepartmentList";
	private static final String GET_LINE_ITEM_LIST = "EippInvoiceNS.getLineItemList";
	private static final String INSERT_DEPT_ALLOC_MAP = "EippInvoiceNS.insertDeptAllocMap";
	private static final String INSERT_DEPT_ALLOC_MAP_HIST = "EippInvoiceNS.insertDeptAllocMapHist";
	private static final String GET_DEPT_ALLOC_TYPE = "EippInvoiceNS.getDeptAllocType";
	private static final String GET_INV_CUST_FIELDS = "EippInvoiceNS.getInvCustFields";
	private static final String GET_LINEITEM_CUST_FIELDS = "EippInvoiceNS.getLineItemCustFields";
	private static final String GET_CRITERIA_CUST_FIELDS = "EippInvoiceNS.getCriteriaCustFields";
	
	private static final String GET_INVOICE_FOR_CREDIT_NOTE = "getInvoiceForCreditNote";
	
	private static final String UPDATE_EIPP_INVOICE = "updateEippInvoice";
	
	private static final String UPDATE_EIPP_CREDIT_NOTE = "updateEippCreditNote";
	
	private static final String INSERT_EIPP_INV_TO_HIST = "insertInvoiceToHist";
	
	private static final String INSERT_EIPP_CN_TO_HIST = "insertCNToHist";
	
	private static final String GET_INVOICES_FROM_TRANS = "getInvoicesForFileFromTrans";
	
	private static final String GET_INVOICES_FROM_MASTER = "getInvoicesForFileFromMaster";
	
	private static final String GET_CREDIT_NOTES_FROM_TRANS = "getCreditNotesForFileFromTrans";
	
	private static final String GET_CREDIT_NOTES_FROM_MASTER = "getCreditNotesForFileFromMaster";
	
	private static final String GET_INV_LN_ITM_FROM_MASTER = "getInvoiceDetForFileFromMaster";
	
	private static final String GET_INV_LN_ITM_FROM_TRANS = "getInvoiceDetForFileFromTrans";
	
	private static final String GET_CN_LN_ITM_FROM_MASTER = "getCNDetForFileFromMaster";
	
	private static final String GET_CN_LN_ITM_FROM_TRANS = "getCNDetForFileFromTrans";
	
	private static final String GET_CN_CUST_FIELDS_FROM_TRANS = "getCNCustFieldsFromTrans";
	
	private static final String GET_CN_CUST_FIELDS_FROM_MASTER = "getCNCustFieldsFromMaster";
	
	private static final String GET_INV_CUST_FIELDS_FROM_TRANS = "getInvCustFieldsFromTrans";
	
	private static final String GET_INV_CUST_FIELDS_FROM_MASTER = "getInvCustFieldsFromMaster";
	
	private static final String GET_INV_LN_ITM_CUST_FIELDS_FROM_TRANS = "getInvDetCustFieldsFromTrans";
	
	private static final String GET_INV_LN_ITM_CUST_FIELDS_FROM_MASTER = "getInvDetCustFieldsFromMaster";
	
	private static final String GET_CN_LN_ITM_CUST_FIELDS_FROM_TRANS = "getCNDetCustFieldsFromTrans";
	
	private static final String GET_CN_LN_ITM_CUST_FIELDS_FROM_MASTER = "getCNDetCustFieldsFromMaster";
	
	private static final String GET_UTIL_CONFIG_FOR_SUPPLIER = "getCNUtilConfigForSupplier";
	
	private static final String GET_INVOICE_DETAILS = "getInvoiceDetails";
	
	private static final String GET_DELETED_INVOICES_DTLS = "getDeletedInvoicesDtls";
	
	private static final String GET_INVOICE_SUMMARY_DTLS = "getInvoiceSummaryDtls";
	
	private static final String GET_DELETED_CREDIT_NOTE_DTLS = "getDeletedCredtiNoteDtls";
	
	private static final String GET_CREDIT_NOTE_SUMMARY_DTLS = "getCredtiNoteSummaryDtls";
	
	private static final String GET_DELETED_INV_LINE_ITEM_DETAILS = "getDeletedInvLineItemDetails";
	
	private static final String GET_INV_LINE_ITEM_DETAILS = "getInvLineItemDetails";
	
	private static final String GET_DELETED_CRN_LINE_ITEM_DETAILS = "getDeletedCrnLineItemDetails";
	
	private static final String GET_CRN_LINE_ITEM_DETAILS = "getCrnLineItemDetails";
	
	private static final String  FETCH_INVOICE_AUDIT = "fetchInvoiceAudit";
	
	private static final String UPDATE_INV_STATUS_REM_AMT = "updateInvStatusAndRemAmt";
	
	private static final String GET_PREV_INV_STATUS = "getPrevInvStatus";
	
	private static final String GET_CN_CUST_FIELDS_FROM_HIST = "getCNCustFieldsFromHist";
	
	private static final String GET_INV_CUST_FIELDS_FROM_HIST = "getInvCustFieldsFromHist";

	private static final String GET_INV_LN_ITM_CUST_FIELDS_FROM_HIST = "getInvDetCustFieldsFromHist";

	private static final String GET_CN_LN_ITM_CUST_FIELDS_FROM_HIST = "getCNDetCustFieldsFromHist";
	
	private static final String UPDATE_INV_LN_ITM_STATUS = "updateInvLnItemStatus";
	
	private static final String UPDATE_DISP_DETAILS_ON_LN_ITM = "updateDispDetailsOnLnItem"; 
	
	private static final String CHECK_USE_DEFLT_BUSS_RULES = "EippInvoiceNS.checkUseDefltBussRules";
	
	private static final String CHECK_ALLOW_NON_FIN_PROC = "EippInvoiceNS.checkCustOrgNonFinProcess";
	
	private static final String CREATE_INVOICE_AUDIT = "createInvoiceAudit";

	private static final String CREATE_INVOICE_LI_AUDIT ="createInvoiceLineItemAudit";
	
	private static final String UPDATE_INV_STATUS_REM_AMT_TIMESTAMP = "updateInvStatusAndRemAmtWithTimeStamp";
	
	private static final String GET_TIME_STAMP = "getLastUpdatedTS";
	
	private static final String  GET_PREV_INV_STATUS_FOR_CANCEL = "getPrevInvStatusForCancel";
	
	private static final String  GET_DEPT_IDS = "getDeptIds";
	
	private static final String GET_INVOICES_FROM_HISTORY = "getDeletedInvoicesFromHistory";

	private static final String GET_INVOICE_FROM_INVOICE_LIST = "EippInvoiceNS.getInvoiceFromInvoiceList";
	
	private static final String GET_PYMT_PREP_COUNT_FORFILE="EippInvoiceNS.getPymtPrepCount";
	private static final String GET_PYMTPREP_RECORD_DETAILS="EippInvoiceNS.getPymtPrepFileDetails";
	private static final String GET_PYMT_STATUS_COUNT_FORFILE="EippInvoiceNS.getPymtStatusUpdateCount";
	private static final String GET_PYMTSTATUS_RECORD_DETAILS="EippInvoiceNS.getPymtStatusUpdateFileDetails";
	private static final String GET_PYMT_CUSTOM_FIELDS="EippInvoiceNS.getPymtCustomFields";

	private static final String GET_INVOICE_FULL_DETAILS = "EippInvoiceNS.getInvoiceFullDetails";	
	
	private static final String UPDATE_DISPUTED_LI_AMT = "updateLIDisputedAmount";
	
	private static final String UPDATE_DISPUTED_INV_AMT = "updateInvDisputedAmount";
	
	// Start : Added for Rel 3.0 Matching and Reconcilation
	private static final String GET_MATCH_RECON_PYMT_RECORD_DETAILS="EippInvoiceNS.getmatchReconPymtDetails"; 
	
	private static final String GET_DELETED_MATCH_RECON_INVOICES_DTLS = "getMatchReconDeletedInvoicesDtls";
	
	private static final String GET_MATCH_RECON_INVOICE_SUMMARY_DTLS = "getMatchReconInvoiceSummaryDtls";
	
	private static final String GET_DELETED_MATCH_RECON_CREDIT_NOTE_DTLS = "getDeletedMatchReconCredtiNoteDtls";
	
	private static final String GET_MATCH_RECON_CREDIT_NOTE_SUMMARY_DTLS = "getMatchReconCredtiNoteSummaryDtls";
	
	private static final String GET_MATCH_RECON_INV_LINE_ITEM_DETAILS = "getMatchReconInvLineItemDetails";
	
	private static final String GET_MATCH_RECON_CRN_LINE_ITEM_DETAILS = "getMatchReconCrnLineItemDetails";
	
	private static final String GET_MATCH_RECON_INV_CUST_FIELDS_FROM_HIST = "getMatchReconInvCustFieldsFromHist";
	
	private static final String GET_MATCH_RECON_INV_CUST_FIELDS_FROM_TRANS = "getMatchReconInvCustFieldsFromTrans";
	
	private static final String GET_MATCH_RECON_INV_CUST_FIELDS_FROM_MASTER = "getMatchReconInvCustFieldsFromMaster";
	// Ends : Added for Rel 3.0 Matching and Reconcilation
	

	@Override
	public List<EippInvoiceVO> getInvoices(long fileId)
			throws BNPApplicationException {
		try {
			return  getSqlMapClientTemplate().queryForList(
					GET_INVOICES_FOR_FILE_ID, fileId);
		} catch (DataAccessException e) {
			LOGGER.error("Error while fetching invoices for file id : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public String getDefaultDepartment(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException {
		try {
			return (String) getSqlMapClientTemplate().queryForObject(
					GET_DEFAULT_DEPARTMENT, eippInvoiceVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error while fetching default department : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public List<DeptAllocRuleVO> getExistingDeptRules(EippInvoiceVO eippInvoiceVO) 
	throws BNPApplicationException {
		try {
			return  getSqlMapClientTemplate().queryForList(
					GET_EXISTING_DEPT_RULES, eippInvoiceVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error while fetching department rules : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public List<String> getDepartmentList(long ruleId,String orgId) throws BNPApplicationException {
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("ruleId", ruleId);
		params.put("orgId", orgId);
		try {
			return  getSqlMapClientTemplate().queryForList(
					GET_DEPARTMENT_LIST, params);
		} catch (DataAccessException e) {
			LOGGER.error("Error while fetching department list : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public List<EippInvCntLineItemVO> getLineItemList(long invId) 
	throws BNPApplicationException {
		try {
			return  getSqlMapClientTemplate().queryForList(
					GET_LINE_ITEM_LIST, invId);
		} catch (DataAccessException e) {
			LOGGER.error("Error while fetching line item list : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public void insertDeptAllocationMap(final List<DeptAllocMapVO> mapList) 
	throws BNPApplicationException {
		 getSqlMapClientTemplate().execute(
				new SqlMapClientCallback<List<Object>>() {
					@Override
					public List<Object> doInSqlMapClient(SqlMapExecutor executor)
							throws SQLException {
						List<Object> list =null;
						try {
							executor.startBatch();
							for (DeptAllocMapVO deptAllocMapVO : mapList) {
								executor.insert(INSERT_DEPT_ALLOC_MAP, deptAllocMapVO);
								executor.insert(INSERT_DEPT_ALLOC_MAP_HIST, deptAllocMapVO);
							}
							list = executor.executeBatchDetailed();
							// R7.0 Fortify issues
//							if (list != null) {
//								LOGGER.debug("Batch Result Size" + list.size());
//							}

						} catch (BatchException e) {
							LOGGER.error("Excecuting batch insert in insertDeptAllocationMap Failed "+ e.getMessage());
							throw new SQLException();
						}
						return list;
					}
				});
	}
	
	@Override
	public String getDeptAllocationType(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException {
		try {
			return (String) getSqlMapClientTemplate().queryForObject(
					GET_DEPT_ALLOC_TYPE, eippInvoiceVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error while fetching department allocation type : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public Map<String,String> getCustomFields(long pkId,String type) 
	throws BNPApplicationException {
		
		try {
			if (type.equals(BNPConstants.DEPT_ALLOC_TYPE_INVOICE)) {
				return  getSqlMapClientTemplate().queryForMap(GET_INV_CUST_FIELDS, 
						pkId, "name", "value");
			} else {
				return  getSqlMapClientTemplate().queryForMap(GET_LINEITEM_CUST_FIELDS, 
						pkId, "name", "value");
			}
			
		} catch (DataAccessException e) {
			LOGGER.error("Error while fetching custom fields for invoice or lineitem : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}


	@Override
	public DeptRuleCriteriaVO getCriteriaCustomFields(long critId) 
	throws BNPApplicationException {
		
		try {
			return (DeptRuleCriteriaVO) getSqlMapClientTemplate().queryForObject(
					GET_CRITERIA_CUST_FIELDS, critId);
		} catch (DataAccessException e) {
			LOGGER.error("Error while fetching criteria custom fields : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	public EippInvoiceDaoImpl () {
		nameSpace = "EippInvoiceNS";
	}

	@Override
	public EippInvoiceVO getInvoice(EippCreditNoteVO creditNoteVO)
			throws BNPApplicationException {
		EippInvoiceVO invoice = null;
		try {
			List<EippInvoiceVO> eippInvoiceVOList = (List<EippInvoiceVO>) getSqlMapClientTemplate().queryForList(
					getQueryNameWithNameSpace(GET_INVOICE_FOR_CREDIT_NOTE), creditNoteVO);
			
			if (eippInvoiceVOList !=null && eippInvoiceVOList.size() > 1) {
				throw new BNPApplicationException(ErrorConstants.DUPLICATE_INVOICE_REF_NUM);
			} else if (eippInvoiceVOList != null && eippInvoiceVOList.size() == 1){
				invoice = eippInvoiceVOList.get(0);
			}
			return invoice;
		} catch (DataAccessException e) {
			LOGGER.error("Error while fetching invoice : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public void updateEippInvoice(EippInvoiceVO invoiceVO)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().update(
					getQueryNameWithNameSpace(UPDATE_EIPP_INVOICE), invoiceVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error while updating invoice : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public void updateEippCreditNote(EippCreditNoteVO creditNoteVO)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().update(
					getQueryNameWithNameSpace(UPDATE_EIPP_CREDIT_NOTE), creditNoteVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error while updating credit note: " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public void insertInvoiceIntoHistory(EippInvoiceVO invoice)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(
					getQueryNameWithNameSpace(INSERT_EIPP_INV_TO_HIST), invoice);
		} catch (DataAccessException e) {
			LOGGER.error("Error while inserting invoice : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public void insertCreditNoteIntoHistory(EippCreditNoteVO creditNote)
			throws BNPApplicationException {
		
		try {
			getSqlMapClientTemplate().insert(
					getQueryNameWithNameSpace(INSERT_EIPP_CN_TO_HIST), creditNote);
		} catch (DataAccessException e) {
			LOGGER.error("Error while inserting credit note : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public List<EippInvoiceVO> getInvoicesForFile(long fileId, String status)
			throws BNPApplicationException {
		
		String queryName = null;
		try {
			if (status.equals(StatusConstants.PENDING_FOR_APPROVAL)) {
				queryName = GET_INVOICES_FROM_TRANS;
			} else if (status.equals(StatusConstants.RELEASED)) {
				queryName = GET_INVOICES_FROM_MASTER;
			} else if (status.equals(StatusConstants.DELETE)) {
				queryName = GET_INVOICES_FROM_HISTORY;
			}
			return (List<EippInvoiceVO>) getSqlMapClientTemplate().queryForList(
					getQueryNameWithNameSpace(queryName), fileId);
		} catch (DataAccessException e) {
			LOGGER.error("Error while fetching invoices : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public List<EippCreditNoteVO> getCreditNotesForFile(long fileId,
			String status) throws BNPApplicationException {
		
		String queryName = null;
		try {
			if (status.equals(StatusConstants.PENDING_FOR_APPROVAL)) {
				queryName = GET_CREDIT_NOTES_FROM_TRANS;
			} else if (status.equals(StatusConstants.RELEASED)) {
				queryName = GET_CREDIT_NOTES_FROM_MASTER;
			}
			return (List<EippCreditNoteVO>) getSqlMapClientTemplate().queryForList(
					getQueryNameWithNameSpace(queryName), fileId);
		} catch (DataAccessException e) {
			LOGGER.error("Error while fetching credit notes : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public List<EippInvCntLineItemVO> getInvoiceLineItems(
				long invoiceId, String status) throws BNPApplicationException {
		
		String queryName = null;
		try {
			if (status.equals(StatusConstants.PENDING_FOR_APPROVAL)) {
				queryName = GET_INV_LN_ITM_FROM_TRANS;
			} else if (status.equals(StatusConstants.RELEASED)) {
				queryName = GET_INV_LN_ITM_FROM_MASTER;
			}
			return (List<EippInvCntLineItemVO>) getSqlMapClientTemplate().queryForList(
					getQueryNameWithNameSpace(queryName), invoiceId);
		} catch (DataAccessException e) {
			LOGGER.error("Error while fetching inv line items : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public List<EippInvCntLineItemVO> getCreditNoteLineItems(
			long creditNoteId, String status) throws BNPApplicationException {
		
		String queryName = null;
		try {
			if (status.equals(StatusConstants.PENDING_FOR_APPROVAL)) {
				queryName = GET_CN_LN_ITM_FROM_TRANS;
			} else if (status.equals(StatusConstants.RELEASED)) {
				queryName = GET_CN_LN_ITM_FROM_MASTER;
			}
			return (List<EippInvCntLineItemVO>) getSqlMapClientTemplate().queryForList(
					getQueryNameWithNameSpace(queryName), creditNoteId);
		} catch (DataAccessException e) {
			LOGGER.error("Error while fetching credit note line items : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	public List<EippCustFieldsVO> getCreditNoteCustomFields(
			long creditNoteId, String status) throws BNPApplicationException {
		
		String queryName = null;
		try {
			if (status.equals(StatusConstants.VALIDATION_FAILED)) {
				queryName = GET_CN_CUST_FIELDS_FROM_HIST;
			}
			else if (status.equals(StatusConstants.PENDING_FOR_APPROVAL)) {
				queryName = GET_CN_CUST_FIELDS_FROM_TRANS;
			} else if (status.equals(StatusConstants.RELEASED)) {
				queryName = GET_CN_CUST_FIELDS_FROM_MASTER;
			}
			return (List<EippCustFieldsVO>) getSqlMapClientTemplate().queryForList(
					getQueryNameWithNameSpace(queryName), creditNoteId);
		} catch (DataAccessException e) {
			LOGGER.error("Error while fetching credit note custom fields : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	public List<EippCustFieldsVO> getInvoiceCustomFields(
			long invoiceId, String status) throws BNPApplicationException {
		
		String queryName = null;
		try {
			if (status.equals(StatusConstants.VALIDATION_FAILED)) {
				queryName = GET_INV_CUST_FIELDS_FROM_HIST;
			}
			else if (status.equals(StatusConstants.PENDING_FOR_APPROVAL)) {
				queryName = GET_INV_CUST_FIELDS_FROM_TRANS;
			} else if (status.equals(StatusConstants.RELEASED)) {
				queryName = GET_INV_CUST_FIELDS_FROM_MASTER;
			}
			return (List<EippCustFieldsVO>) getSqlMapClientTemplate().queryForList(
					getQueryNameWithNameSpace(queryName), invoiceId);
		} catch (DataAccessException e) {
			LOGGER.error("Error while fetching invoice custom fields : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public List<EippCustFieldsVO> getInvoiceLineItemCustomFields(
			long lineItemId, String status) throws BNPApplicationException {

		String queryName = null;
		try {
			if (status.equals(StatusConstants.VALIDATION_FAILED)) {
				queryName = GET_INV_LN_ITM_CUST_FIELDS_FROM_HIST;
			}
			else if (status.equals(StatusConstants.PENDING_FOR_APPROVAL)) {
				queryName = GET_INV_LN_ITM_CUST_FIELDS_FROM_TRANS;
			} else if (status.equals(StatusConstants.RELEASED)) {
				queryName = GET_INV_LN_ITM_CUST_FIELDS_FROM_MASTER;
			}
			return (List<EippCustFieldsVO>) getSqlMapClientTemplate().queryForList(
					getQueryNameWithNameSpace(queryName), lineItemId);
		} catch (DataAccessException e) {
			LOGGER.error("Error while fetching invoice custom fields : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public List<EippCustFieldsVO> getCNLineItemCustomFields(long lineItemId,
			String status) throws BNPApplicationException {
		String queryName = null;
		try {
			if (status.equals(StatusConstants.VALIDATION_FAILED)) {
				queryName = GET_CN_LN_ITM_CUST_FIELDS_FROM_HIST;
			}
			else if (status.equals(StatusConstants.PENDING_FOR_APPROVAL)) {
				queryName = GET_CN_LN_ITM_CUST_FIELDS_FROM_TRANS;
			} else if (status.equals(StatusConstants.RELEASED)) {
				queryName = GET_CN_LN_ITM_CUST_FIELDS_FROM_MASTER;
			}
			return (List<EippCustFieldsVO>) getSqlMapClientTemplate().queryForList(
					getQueryNameWithNameSpace(queryName), lineItemId);
		} catch (DataAccessException e) {
			LOGGER.error("Error while fetching invoice custom fields : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public Properties getOrgConfigForCNUtilization(String supplierOrgId)
			throws BNPApplicationException {
		try {
			return (Properties) getSqlMapClientTemplate().queryForObject(
					getQueryNameWithNameSpace(GET_UTIL_CONFIG_FOR_SUPPLIER), supplierOrgId);
		} catch (DataAccessException e) {
			LOGGER.error("Error while fetching org details : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public EippInvoiceVO getInvoiceDetails(long invoiceId)
			throws BNPApplicationException {
		try {
			return (EippInvoiceVO) getSqlMapClientTemplate().queryForObject(
					getQueryNameWithNameSpace(GET_INVOICE_DETAILS), invoiceId);
		} catch (DataAccessException e) {
			LOGGER.error("Error while fetching org details : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public List<EippInvoiceVO> getInvoiceDetails(EippInvoiceVO invoiceVO)throws BNPApplicationException 
	{
		List<EippInvoiceVO> invoiceList = null;
		if (StatusConstants.VALIDATION_FAILED.equalsIgnoreCase(invoiceVO.getStatus())) {
			invoiceVO.setStatus(StatusConstants.DELETE);
			invoiceList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_DELETED_INVOICES_DTLS),invoiceVO);
		} else {
			invoiceList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_INVOICE_SUMMARY_DTLS),invoiceVO);
		}
		return invoiceList;
	}
	@Override
	public List<EippCreditNoteVO> getCreditNoteDetails(EippCreditNoteVO creditNoteVO) throws BNPApplicationException {
		List<EippCreditNoteVO> creditNoteList = null;
		if (StatusConstants.VALIDATION_FAILED.equalsIgnoreCase(creditNoteVO.getStatus())) {
			creditNoteList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_DELETED_CREDIT_NOTE_DTLS),creditNoteVO);
		} else {
			creditNoteList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_CREDIT_NOTE_SUMMARY_DTLS),creditNoteVO);
		}
		return creditNoteList;
	}

	@Override
	public List<EippInvCntLineItemVO> getInvLineItemDetails(long invId,String status) throws BNPApplicationException 
	{
		List<EippInvCntLineItemVO> lineItemsList = null;
		if (StatusConstants.DELETE.equalsIgnoreCase(status)) {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("invId", invId);
			params.put("invStatus", StatusConstants.DELETE);
			lineItemsList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_DELETED_INV_LINE_ITEM_DETAILS),params);
		} else {
			lineItemsList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_INV_LINE_ITEM_DETAILS),invId);
		}
		return lineItemsList;
	}

	@Override
	public List<EippInvCntLineItemVO> getCrnLineItemDetails(String orgId,long fileId, long cntId, String status)throws BNPApplicationException 
	{
		List<EippInvCntLineItemVO> lineItemList = null;
		Map<String, Object> params = new HashMap<String, Object>();
		if (StatusConstants.DELETE.equalsIgnoreCase(status)) {
			params.put("fileId", fileId);
			params.put("cntId", cntId);
			params.put("cntStatus", StatusConstants.DELETE);
			lineItemList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_DELETED_CRN_LINE_ITEM_DETAILS),params);
		} else {
			params.put("orgId", orgId);
			params.put("cntId", cntId);
			params.put("cntStatus", status);
			lineItemList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_CRN_LINE_ITEM_DETAILS),params);
		}
		return lineItemList;
	}

	@Override
	public List<EippAuditVO> getInvoiceAuditDetails(long invId)
			throws BNPApplicationException {
		List<EippAuditVO> resultList= null;
		try{
			resultList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(FETCH_INVOICE_AUDIT), invId);
		}catch(DataAccessException e){
			LOGGER.error("Exception while fetching inv line audit details - DepartmentApprovalDao------------",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return resultList;
	}
	
	public String getPrevInvoiceStatus(
			long invoiceId) throws BNPApplicationException {
		try {
			return (String) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(
					GET_PREV_INV_STATUS), invoiceId);
		} catch (DataAccessException e) {
			LOGGER.error("Exception while fetching previous inv status ",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}

	public void updateInvStatusAndRemAmt(
			DisputeVO dispute) throws BNPApplicationException {
		
		Map<String, Object> params = new HashMap<String, Object>();
		
		params.put("status", getPrevInvoiceStatus(dispute.getEippInvoice().getInvId()));
		params.put("disputedAmt", dispute.getOldNetAmt().subtract(dispute.getNewNetAmt()));
		params.put("invoiceId", dispute.getEippInvoice().getInvId());
		
		try {
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(
					UPDATE_INV_STATUS_REM_AMT), params);
			insertInvoiceIntoHistory(dispute.getEippInvoice());
		} catch (DataAccessException e) {
			LOGGER.error("Exception while updating inv status ",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	public String updateInvLnItmStatusAndRemAmt(
			final DisputeVO dispute) throws BNPApplicationException {
		try {
			final String status = getPrevInvoiceStatus(
						dispute.getEippInvoice().getInvId());
			
			getSqlMapClientTemplate().execute(
					new SqlMapClientCallback<List<Object>>() {
						@Override
						public List<Object> doInSqlMapClient(SqlMapExecutor executor)
								throws SQLException {
							List<Object> list =null;
							try {
								List<DisputeCustFieldsVO> disputeFields = dispute.getCustFieldsList();
								HashMap<String, Object> params = null;

								Map<Long, HashMap<String, Object>> lineItemMap = 
											new HashMap<Long, HashMap<String, Object>>();
								
								DisputeCustFieldsVO disputeField = null;
								for ( int i = 0 ; i < disputeFields.size() ; i++ ) {
									disputeField = disputeFields.get(i);
								
									if (lineItemMap.containsKey(disputeField.getFkId())) {
											params = lineItemMap.get(disputeField.getFkId());
									} else {
										params = new HashMap<String, Object>();
										params.put("lnItmId", disputeField.getFkId());
										params.put("invId", dispute.getEippInvoice().getInvId());
										params.put("status", status);
										lineItemMap.put(disputeField.getFkId(), params);
									}
									
									if (disputeField.getFieldName().equals("Quantity (Nos.)") && 
											BigDecimal.ZERO.compareTo(disputeField.getNewValue()) < 0) {
										params.put("Quantity", disputeField.getNewValue());
									} else if (disputeField.getFieldName().equals("Unit Price") && 
											BigDecimal.ZERO.compareTo(disputeField.getNewValue()) < 0) {
										params.put("UnitPrice", disputeField.getNewValue());
									} else if (disputeField.getFieldName().equals("Subtotal") && 
											BigDecimal.ZERO.compareTo(disputeField.getNewValue()) < 0) {
										params.put("Subtotal", disputeField.getNewValue());
									} 
								}
								
								Set<Long> lineItemSet = lineItemMap.keySet();
								
								executor.startBatch();								
								for (Long  lineItemId : lineItemSet) {
									params = lineItemMap.get(lineItemId);
									executor.update(getQueryNameWithNameSpace(UPDATE_DISPUTED_INV_AMT),params);
									executor.update(getQueryNameWithNameSpace(UPDATE_DISPUTED_LI_AMT),params);
									executor.update(getQueryNameWithNameSpace(UPDATE_DISP_DETAILS_ON_LN_ITM), params);
								}
								list = executor.executeBatchDetailed();
							} catch (BatchException e) {
								LOGGER.error("Excecuting batch update after dispute " +
										"resolution for ln itm"+ e.getMessage());
								throw new SQLException(e.getMessage());
							}
							return list;
						}
					});
			return status;
		} catch (DataAccessException e) {
			LOGGER.error("Exception while updating inv line item status ",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public void updateLineItemStatus(List<Long> lineItemIds, String status)
			throws BNPApplicationException {
		
		Map<String, Object> params = new HashMap<String, Object>();
		
		params.put("lineItems", lineItemIds);
		params.put("status", status);
		
		try {
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(
					UPDATE_INV_LN_ITM_STATUS), params);
		} catch (DataAccessException e) {
			LOGGER.error("Exception while updating inv line item status ",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public boolean checkAllowNonFinProcess(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException {
		boolean allowNonFinProcess=false;
		try
		{
			EippInvoiceVO  invoiceVO = (EippInvoiceVO) getSqlMapClientTemplate().queryForObject(CHECK_USE_DEFLT_BUSS_RULES, eippInvoiceVO);
			String alwNonFinProcess=invoiceVO.getAlwNonFinProcess();
			if(BNPConstants.YES.equals(invoiceVO.getUseDfltBussRules()))
			{
				alwNonFinProcess=(String)getSqlMapClientTemplate().queryForObject(CHECK_ALLOW_NON_FIN_PROC, invoiceVO);
			}
			if(BNPConstants.YES.equals(alwNonFinProcess))
			{
				allowNonFinProcess=true;
			}
		} catch (DataAccessException e) {
			LOGGER.error("Error while fetching default department : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		return allowNonFinProcess;
	}
	
	@Override
	public void createInvoiceAudit(EippAuditVO auditVO)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(
					CREATE_INVOICE_AUDIT), auditVO);
		} catch (DataAccessException e) {
			//exception suppressed to avoid transaction disturbance 
			LOGGER.error("Exception while updating inv line item status ",e);

		}
	}
	
	@Override
	public void createInvLineItemAudit(EippAuditVO auditVO)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(
					CREATE_INVOICE_LI_AUDIT), auditVO);
		} catch (DataAccessException e) {
			//exception suppressed to avoid transaction disturbance 
			LOGGER.error("Exception while updating inv line item status ",e);
		}
	}

	@Override
	public void updateInvStatusAndRemAmtWithTimeStamp(DisputeVO disputeVO)
			throws BNPApplicationException {
		Map<String, Object> params = new HashMap<String, Object>();
		
		params.put("status", getPrevInvoiceStatus(disputeVO.getEippInvoice().getInvId()));
		params.put("disputedAmt", disputeVO.getOldNetAmt().subtract(disputeVO.getNewNetAmt()));
		params.put("invoiceId", disputeVO.getEippInvoice().getInvId());
		
		try {
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(
					UPDATE_INV_STATUS_REM_AMT_TIMESTAMP), params);
			insertInvoiceIntoHistory(disputeVO.getEippInvoice());
			disputeVO.setLastUpdatedTimestamp((Timestamp) 
					getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(
							GET_TIME_STAMP),disputeVO.getEippInvoice().getInvId()));
			
		} catch (DataAccessException e) {
			LOGGER.error("Exception while updating inv status ",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);

		}
		
	}

	@Override
	public String getPrevInvoiceStatusForCancel(long invoiceId)
			throws BNPApplicationException {
		try {
			return (String) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(
					GET_PREV_INV_STATUS_FOR_CANCEL), invoiceId);
		} catch (DataAccessException e) {
			LOGGER.error("Exception while fetching previous inv status for cancel scenario",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public List<Long> getDeptIds(EippInvoiceVO invoiceVO)
			throws BNPApplicationException {
		try {
			return getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(
					GET_DEPT_IDS), invoiceVO);
		} catch (DataAccessException e) {
			LOGGER.error("Exception while fetching department ids",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}

	/**
	 * It returns a single invoice from the list of invoices with the same data 
	 */
	@Override
	public EippInvoiceVO getInvoiceFromInvoiceList(EippInvoiceVO eippInvoiceVO)
			throws BNPApplicationException {
		try {
			return (EippInvoiceVO) getSqlMapClientTemplate().queryForObject(
					GET_INVOICE_FROM_INVOICE_LIST, eippInvoiceVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error while fetching the invoice from the invoice list : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public int getPymtPreparationCountForFile(NameValueVO params)throws BNPApplicationException {
		try {
			if (StatusConstants.VALIDATION_FAILED.equalsIgnoreCase(params.getParam1())) {
				params.setParam1(StatusConstants.DELETE);				
			}	
			return (Integer) getSqlMapClientTemplate().queryForObject(GET_PYMT_PREP_COUNT_FORFILE, params);
		} catch (DataAccessException ex) {
			LOGGER.error("Error while getting Payment Preparation count " + ex);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public List<EippInvoiceVO> getPymtPrepRecordDetails(NameValueVO params)throws BNPApplicationException {
		List<EippInvoiceVO> pymtPrepList=null;
		try {
			if (StatusConstants.VALIDATION_FAILED.equalsIgnoreCase(params.getParam1())) {
				params.setParam1(StatusConstants.DELETE);				
			}			
			pymtPrepList=getSqlMapClientTemplate().queryForList(GET_PYMTPREP_RECORD_DETAILS, params);			
			
		} catch (DataAccessException ex) {
			LOGGER.error("Error while getting getPymtPrepRecordDetails " + ex);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		
		return pymtPrepList; 
	}

	@Override
	public int getPymtStatusCountForFile(long fileId)throws BNPApplicationException {
		try {
			return (Integer) getSqlMapClientTemplate().queryForObject(GET_PYMT_STATUS_COUNT_FORFILE, fileId);
		} catch (DataAccessException ex) {
			LOGGER.error("Error while getting Payment status count " + ex);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public List<EippPymtStatusUpdateVO> getPymtStatusFileDetails(long fileId)throws BNPApplicationException {
		List<EippPymtStatusUpdateVO> pymtStatusList=null;
		try {			
			pymtStatusList=getSqlMapClientTemplate().queryForList(GET_PYMTSTATUS_RECORD_DETAILS, fileId);
		} catch (DataAccessException ex) {
			LOGGER.error("Error while getting getPymtStatusFileDetails " + ex);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		
		return pymtStatusList; 
	}
 
	@Override
	public List<NameValueVO> getCustomFieldsForEippPymt(NameValueVO params)throws BNPApplicationException {
		List<NameValueVO> custFields=null;
		try {
			if (StatusConstants.VALIDATION_FAILED.equalsIgnoreCase(params.getParam1())) {
				params.setParam1(StatusConstants.DELETE);				
			}	
			custFields=getSqlMapClientTemplate().queryForList(GET_PYMT_CUSTOM_FIELDS, params);
		} catch (DataAccessException ex) {
			LOGGER.error("Error while getting getCustomFieldsForEippPymt " + ex);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}		
		return custFields;
	}	
	
	/**
	 * It returns the complete invoice details including the configuration level flags
	 */
	@Override
	public EippInvoiceVO getInvoiceFullDetails(EippInvoiceVO eippInvoiceVO)
			throws BNPApplicationException {
		try {
			return (EippInvoiceVO) getSqlMapClientTemplate().queryForObject(
					GET_INVOICE_FULL_DETAILS, eippInvoiceVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error in EippInvoiceDaoImpl getInvoiceFullDetails : ", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	// Start : Added for Rel 3.0 Matching and Reconcilation
	@Override
	public List<EippInvoiceVO> getMatchReconPymtDetails(NameValueVO params)throws BNPApplicationException {
		List<EippInvoiceVO> matchReconPymtList=null;
		try {
			if (StatusConstants.VALIDATION_FAILED.equalsIgnoreCase(params.getParam1())) {
				params.setParam1(StatusConstants.DELETE);				
			}			
			matchReconPymtList=getSqlMapClientTemplate().queryForList(GET_MATCH_RECON_PYMT_RECORD_DETAILS, params);			
			
		} catch (DataAccessException ex) {
			LOGGER.error("Error while getting getMatchReconPymtDetails " + ex);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		
		return matchReconPymtList; 
	}
		
	@Override
	public List<EippInvoiceVO> getMatchReconInvoiceDetails(EippInvoiceVO invoiceVO)throws BNPApplicationException 
	{
		List<EippInvoiceVO> invoiceList = null;
		if (StatusConstants.VALIDATION_FAILED.equalsIgnoreCase(invoiceVO.getStatus())) {
			invoiceVO.setStatus(StatusConstants.DELETE);
			invoiceList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_DELETED_MATCH_RECON_INVOICES_DTLS),invoiceVO);
		} else {
			invoiceList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_MATCH_RECON_INVOICE_SUMMARY_DTLS),invoiceVO);
		}
		return invoiceList;
	}
	
	@Override
	public List<EippCreditNoteVO> getMatchReconCreditNoteDetails(EippCreditNoteVO creditNoteVO) throws BNPApplicationException {
		List<EippCreditNoteVO> creditNoteList = null;
		if (StatusConstants.VALIDATION_FAILED.equalsIgnoreCase(creditNoteVO.getStatus())) {
			creditNoteList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_DELETED_MATCH_RECON_CREDIT_NOTE_DTLS),creditNoteVO);
		} else {
			creditNoteList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_MATCH_RECON_CREDIT_NOTE_SUMMARY_DTLS),creditNoteVO);
		}
		return creditNoteList;
	}
	
	@Override
	public List<EippInvCntLineItemVO> getMatchReconInvLineItemDetails(long invId) throws BNPApplicationException 
	{
		List<EippInvCntLineItemVO> lineItemsList = null;
		lineItemsList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_MATCH_RECON_INV_LINE_ITEM_DETAILS),invId);
		return lineItemsList;
	}
	
	@Override
	public List<EippInvCntLineItemVO> getMatchReconCrnLineItemDetails(String orgId,long fileId, long cntId)throws BNPApplicationException 
	{
		List<EippInvCntLineItemVO> lineItemList = null;
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("orgId", orgId);
		params.put("cntId", cntId);
		lineItemList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_MATCH_RECON_CRN_LINE_ITEM_DETAILS),params);
		return lineItemList;
	}
	
	public List<EippCustFieldsVO> getMatchReconInvoiceCustomFields(long invoiceId, String status) throws BNPApplicationException {
		
		String queryName = null;
		try {
			if (StatusConstants.VALIDATION_FAILED.equals(status)) {
				queryName = GET_MATCH_RECON_INV_CUST_FIELDS_FROM_HIST;
			}
			else if (StatusConstants.PENDING_FOR_APPROVAL.equals(status)) {
				queryName = GET_MATCH_RECON_INV_CUST_FIELDS_FROM_TRANS;
			} else if (StatusConstants.RELEASED.equals(status)) {
				queryName = GET_MATCH_RECON_INV_CUST_FIELDS_FROM_MASTER;
			}
			return (List<EippCustFieldsVO>) getSqlMapClientTemplate().queryForList(
					getQueryNameWithNameSpace(queryName), invoiceId);
		} catch (DataAccessException e) {
			LOGGER.error("Error while fetching Matching and Reconcilation invoice custom fields : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	// Ends : Added for Rel 3.0 Matching and Reconcilation
	
}
