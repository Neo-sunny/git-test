/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Apr 21, 20126:48:13 PM
 * 
 * Purpose:      InvoiceAuditConstants.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Apr 21, 20126:48:13 PM        Oracle Financial Services Software Ltd                  Initial Version
 * 12-July 2012                  Oracle Financial Services Software Ltd                  EIPP Phase II - Cancel Invoice MFU  
 * 29 Nov 2012						Gangadharan R										 EIPP - Payment Response logic added
 ************************************************************************************************************************************************************/
package com.bnp.eipp.services.invoice.util;


public interface EippAuditConstants {
	
	String INV_UPLOADED = "UPLOADED";
	
	String INV_RELEASED = "RELEASED";
	
	String INV_PENDING = "VIEW INVOICE";
	
	String INV_DISPUTED = "DISPUTE APPROVAL BY BUYER";
	
	String INV_DISPUTE_PENDING_APPROVAL = "DISPUTE CREATION BY BUYER";
	
	String INV_APPROVED = "INVOICE FULLY APPROVED";
	
	String INV_PARTIALLY_APPROVED = "INVOICE PARTIALLY APPROVED";
	
	String INV_APPROVAL_IN_PROGRESS = "INVOICE APPROVAL IN PROGRESS";
	
	String DISPUTE_PENDING_ACCEPTANCE = "DISPUTE RESOLUTION BY SUPPLIER";
	
	String DISPUTE_ACCEPTED = "DISPUTE RESOLUTION APPROVAL BY SUPPLIER";
	
	String DISPUTE_PENDING_REJECTION = "DISPUTE RESOLUTION BY SUPPLIER";
	
	String DISPUTE_REJECTED = "DISPUTE RESOLUTION APPROVAL BY SUPPLIER";
	
	String DISPUTE_CANCELLED = "DISPUTE CANCELLED BY BUYER";
	
	String DISPUTE_OVERRIDDEN = "DISPUTE OVERRIDDEN BY SUPPLIER";
	
	String INV_CANCELLED = "INVOICE CANCELLED BY SUPPLIER";
	
	String INV_PENDING_CANCELLATION = "INVOICE PENDING FOR CANCELLATION";
	
	String INV_REASSIGNED = "INVOICE REASSIGNED";
	
	String DISPUTE_REASSIGNED_BY_SUPPLIER = "DISPUTE REASSIGNED BY SUPPLIER";
	
	String DISPUTE_REASSIGNED_BY_BUYER = "DISPUTE REASSIGNED BY BUYER";
	
	String INV_REJECTED = "INVOICE REJECTED";
	
	String INV_DELETED = "INVOICE DELETED";
	
	String INV_CLOSED = "INVOICE FULLY UTILIZED AGAINST CREDIT NOTE";
	
	String INV_PARTIALLY_UTILIZED = "INVOICE PARTIALLY UTILIZED AGAINST CREDIT NOTE";
	
	String CANCEL_INV_UPLOADED = "CANCEL INVOICE UPLOADED";
	
	String CANCEL_INV_DELETED = "CANCEL INVOICE DELETED";

	String BILLING_COUNT_UPLOADED="BILLING CUSTOMER CHARGE COUNT UPLOADED";
	
	String EIPP_PYMT_STATUS_UPDATE="PAYMENT STATUS UPDATE RELEASED";

	String BILLING_COUNT_RELEASED="BILLING CUSTOMER CHARGE COUNT RELEASED";
	
	String EIPP_PYMT_RESP_STATUS_UPDATE="PAYMENT RESPONSE STATUS UPDATE";
}
