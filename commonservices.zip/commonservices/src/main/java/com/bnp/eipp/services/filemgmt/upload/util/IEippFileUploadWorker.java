/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   07 Feb 2012
 * 
 * Purpose:      EIPP Invoice Upload Screen 
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 07 Feb 2012                     Oracle Financial Services Software Ltd                                  Thread Pool  for file upload 
 * 
 *****************************************************************************************************************************************************************/
package com.bnp.eipp.services.filemgmt.upload.util;

import com.bnp.eipp.services.invoice.IEippInvcUploadService;
import com.bnp.scm.services.common.IBNPPropertyLoaderConfigurer;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.filemgmt.vo.FileUploadVO;
import com.bnp.scm.services.invoice.IInvoiceUploadService;
import com.bnp.scm.services.txns.common.message.AbstractMessage;

public interface IEippFileUploadWorker extends Runnable {
	
	void setDetailsVO(FileDetailsVO detailsVO);
	
	void setInvoiceMessage(AbstractMessage<?> message);

	void setUploadVO(FileUploadVO uploadVO);
	
	void setEippInvcUploadService(IEippInvcUploadService eippInvcUploadService);
	
	void setPropertyLoader(IBNPPropertyLoaderConfigurer propertyLoader);
	
	void setInvoiceUploadService(IInvoiceUploadService service);
	
}
