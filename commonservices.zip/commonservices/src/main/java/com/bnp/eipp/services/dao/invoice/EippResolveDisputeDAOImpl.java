/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  18 Aug 2012	   
 * 
 * Purpose:     Resolve Dispute Dao Implementation
 * 
 * Change History: 
 * Date                                      	 Author                              Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 Aug 2012	       							Dinesh D                 		 Initial Version  
 * 25 Oct 2012	       							Ravishankar V                 	 ST Defects 7042 and 7050  
 *****************************************************************************************************************************************************************/


package com.bnp.eipp.services.dao.invoice;

import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.vo.dispute.DisputeVO;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.BNPRuntimeException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.ibatis.sqlmap.client.SqlMapExecutor;
import com.ibatis.sqlmap.engine.execution.BatchException;

@Component 
public class EippResolveDisputeDAOImpl extends SqlMapClientWrapper implements IEippResolveDisputeDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(EippResolveDisputeDAOImpl.class);

	private static final String NAMESPACE="DisputeMgmtNS";
	private static final String GET_AVAILABLE_COUNT_FOR_RESOLVE_DISPUTE="getAvailableCountForResolveDispute";
	private static final String UPDATE_RECORD_STATUS_IN_TRANS = "updateResolveDisputeStatusInTrans";

	private static final String INSERT_RESOLVE_DISPUTE_DETAILS = "insertResolveDisputeDetails";
//	private static final String INSERT_INTO_DISPUTE_AUDIT = "insertIntoDisputeAudit";
	private static final String INSERT_RESOLVE_DISPUTE_INTO_HISTORY_FROM_TRANS = "insertResolveDisputeIntoHistoryFromTrans";
	private static final String INSERT_RESOLVE_DISPUTE_INTO_MASTER = "insertResolveDisputeIntoMaster";
	private static final String INSERT_RESOLVE_DISPUTE_INTO_HISTORY_FROM_MASTER = "insertResolveDisputeIntoHistoryFromMaster";
	private static final String DELETE_RESOLVE_DISPUTE_FROM_TRANS = "deleteResolveDisputeFromTrans";
	private static final String GET_RESOLVE_DISPUTE_LIST = "getResolveDisputeList";
	private static final String IS_VALID_RESOLUTION_CODE = "isValidResolutionCode";

	private static final String INSERT_DISPUTE_ATTACHMENTS = "insertDispAttachments";

    private static final String GET_VALID_DISP_USER_LIST="getValidDispDeptUserList";

    private static final String GET_INV_DISPUTE_DETAILS = "getInvDisputeDetail";



	public EippResolveDisputeDAOImpl()
	{
		nameSpace=NAMESPACE;
	}
	@Override
	public List<DisputeVO> getResolveDisputeList(long fileId){
		List<DisputeVO> invoiceList = null;
		invoiceList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_RESOLVE_DISPUTE_LIST),fileId);
		return invoiceList;
	}	

	@Override
	public int isResolveDisputeAllowed(DisputeVO disputeVO,String status)throws BNPApplicationException {
		int count = 0;
		try{
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("orgId", disputeVO.getOrgId());
			paramMap.put("dispRefNo", disputeVO.getDispRefNo());
			paramMap.put("status", status);

			count =  (Integer) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_AVAILABLE_COUNT_FOR_RESOLVE_DISPUTE), paramMap);
			return count;
		}catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public void insertFileDetailsIntoHistFromTrans(FileDetailsVO detailsVO)
			throws DBException {
		try {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("fileId", detailsVO.getFileId());
			paramMap.put("requestStatus", "WA");
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_RESOLVE_DISPUTE_INTO_HISTORY_FROM_TRANS), 
					paramMap);
		} catch (DataAccessException e) {
			LOGGER.error("Error while processing resolve disputes : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}

	}
	@Override
	public void insertFileDetailsIntoMaster(FileDetailsVO detailsVO) throws DBException {
		try {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("fileId", detailsVO.getFileId());
			paramMap.put("requestStatus", "WA");
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_RESOLVE_DISPUTE_INTO_MASTER), 
					paramMap);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_DISPUTE_ATTACHMENTS), 
					paramMap);
		} catch (DataAccessException e) {
			LOGGER.error("Error while releasing resolve disputes : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public void insertFileDetailsIntoHistFromMaster(FileDetailsVO detailsVO) throws DBException {
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_RESOLVE_DISPUTE_INTO_HISTORY_FROM_MASTER), 
					detailsVO.getFileId());
		} catch (DataAccessException e) {
			LOGGER.error("Error while releasing resolve disputes : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}

	}

	@Override
	public void deleteFileDetailsFromTrans(FileDetailsVO detailsVO) throws DBException {
		try {
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(DELETE_RESOLVE_DISPUTE_FROM_TRANS), 
					detailsVO.getFileId());

		} catch (DataAccessException e) {
			LOGGER.error("Error while deleting resolve disputes : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}

	}

	@Override
	public void updateRecordStatusInTrans(long fileId, String status) throws BNPApplicationException {
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("fileId", fileId);
		params.put("status", status);

		try{
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_RECORD_STATUS_IN_TRANS), params);
		} catch (DataAccessException e) {
			LOGGER.error(e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}		
	}

	@Override
	public void insertResolveDisputeList(final List<DisputeVO> resolveDisputeList,final FileDetailsVO fileVO) throws BNPRuntimeException{
		try {
			getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
				public List<Object> doInSqlMapClient(SqlMapExecutor executor)
						throws SQLException {
					List<Object> list = null;

					try {

						// inserting resolve dispute details
						for (DisputeVO disputeVO : resolveDisputeList) {
							executor.startBatch();

							disputeVO.setDispRefNo(disputeVO.getDispRefNo().trim());
							disputeVO.setFileId(fileVO.getFileId());
							disputeVO.setMakerId(fileVO.getUserId());
							disputeVO.setMakerDate(new Date(System.currentTimeMillis()));
							disputeVO.setRecordStatus(StatusConstants.WAITING_FOR_APPROVAL_REQUEST);
							disputeVO.setStatus(StatusConstants.PENDING_FOR_APPROVAL);
							//disputeVO.getEippInvoice().setInvId();
							executor.insert(getQueryNameWithNameSpace(INSERT_RESOLVE_DISPUTE_DETAILS), disputeVO);
							list = executor.executeBatchDetailed();

							/*							DisputeAuditVO auditVO = new DisputeAuditVO();

							auditVO.setDispRefNo(disputeVO.getDispRefNo());
							auditVO.setUserId(disputeVO.getMakerId());
							auditVO.setDisputeStatus(disputeVO.getRecordStatus());
							auditVO.setAction(EippAuditConstants.DISPUTE_PENDING_ACCEPTANCE);

							// insert into dispute audit
							executor.startBatch();
							executor.insert(getQueryNameWithNameSpace(INSERT_INTO_DISPUTE_AUDIT), auditVO);
							executor.executeBatchDetailed();*/

						}
					} catch (BatchException e) {							
						LOGGER.error("Uploading the resolve dispute details in a batch failed");
						throw new SQLException(e);
					} 
					// R7.0 Fortify issues
					//LOGGER.debug("List :: " + list);
					return list;
				}
			});
		} catch (DataAccessException e) {
			throw new BNPRuntimeException(ErrorConstants.DATABASE_ERROR);
		}
	}
	@Override
	public int isValidResolutionCode(DisputeVO disputeVO)
			throws BNPApplicationException {
		int count = 0;
		try{
			disputeVO.setCodeType(StatusConstants.DISPUTE_RESOLUTION_CODE);
			count =  (Integer) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(IS_VALID_RESOLUTION_CODE), disputeVO);
			return count;
		}catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public boolean isValidDeptUser(DisputeVO disputeVO)
			throws BNPApplicationException {
		List<String> deptUserList=getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_VALID_DISP_USER_LIST),disputeVO);
		if(disputeVO.getResolvedBy()!=null && disputeVO.getResolutionApprovedBy()!=null)
		{
			return (deptUserList.contains(disputeVO.getCurrentUserId()) && deptUserList.contains(disputeVO.getResolvedBy())&& deptUserList.contains(disputeVO.getResolutionApprovedBy()));

		}else{
			return (deptUserList.contains(disputeVO.getCurrentUserId()));		
			}
	}
	@Override
	public DisputeVO getDisputeDetail(DisputeVO dispute){
		return (DisputeVO) getSqlMapClientTemplate().queryForObject(
				getQueryNameWithNameSpace(GET_INV_DISPUTE_DETAILS), dispute);
	}
}
