package com.bnp.eipp.services.matching.payment.bindingvo;

import java.util.Calendar;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.bnp.scm.services.txns.util.calendar.DateAdapter;

/**
 * <p>
 * Java class for InvoiceInformation complex type.
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="InvoiceInformation">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="InvRefNo" type="{}Max35Text"/>
 *         &lt;element name="InvIssueDt" type="{}MandatoryDate"/>
 *         &lt;element name="InvRefDt" type="{}Date" minOccurs="0"/>
 *         &lt;element name="AmountPaid" type="{}ActiveCurrencyAndAmount"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InvoiceInformation", propOrder = { "invRefNo", "invIssueDt", "invRefDt", "amountPaid" })
public class InvoiceInformation {

	@XmlElement(name = "InvRefNo", required = true)
	protected String invRefNo;

	@XmlElement(name = "InvIssueDt", required = true, type = String.class)
	@XmlJavaTypeAdapter(DateAdapter.class)
	protected Calendar invIssueDt;

	@XmlElement(name = "InvRefDt", type = String.class)
	@XmlJavaTypeAdapter(DateAdapter.class)
	protected Calendar invRefDt;

	@XmlElement(name = "AmountPaid", required = true)
	protected ActiveCurrencyAndAmount amountPaid;

	/**
	 * Gets the value of the invRefNo property.
	 * @return possible object is {@link String }
	 */
	public String getInvRefNo() {
		return invRefNo;
	}

	/**
	 * Sets the value of the invRefNo property.
	 * @param value allowed object is {@link String }
	 */
	public void setInvRefNo(String value) {
		this.invRefNo = value;
	}

	/**
	 * Gets the value of the invIssueDt property.
	 * @return possible object is {@link String }
	 */
	public Calendar getInvIssueDt() {
		return invIssueDt;
	}

	/**
	 * Sets the value of the invIssueDt property.
	 * @param value allowed object is {@link String }
	 */
	public void setInvIssueDt(Calendar value) {
		this.invIssueDt = value;
	}

	/**
	 * Gets the value of the invRefDt property.
	 * @return possible object is {@link String }
	 */
	public Calendar getInvRefDt() {
		return invRefDt;
	}

	/**
	 * Sets the value of the invRefDt property.
	 * @param value allowed object is {@link String }
	 */
	public void setInvRefDt(Calendar value) {
		this.invRefDt = value;
	}

	/**
	 * Gets the value of the amountPaid property.
	 * @return possible object is {@link ActiveCurrencyAndAmount }
	 */
	public ActiveCurrencyAndAmount getAmountPaid() {
		return amountPaid;
	}

	/**
	 * Sets the value of the amountPaid property.
	 * @param value allowed object is {@link ActiveCurrencyAndAmount }
	 */
	public void setAmountPaid(ActiveCurrencyAndAmount value) {
		this.amountPaid = value;
	}

}
