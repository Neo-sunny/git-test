/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 15, 201210:47:39 AM
 * 
 * Purpose:      IDepartmentApprovalDao.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 15, 201210:47:39 AM        Oracle Financial Services Software Ltd                  Initial Version
 * Apr 3,2012       		      Oracle Financial Services Software Ltd                  ST Defect #5812 and #5813
 * Apr 21,2012					  Sandhya R												  SIT #2020
 * 27/04/2012					  Sandhya R												  R2.1 SIT Defect #2142 - Added a boolean parameter for fetching record to diff from pending action access  
************************************************************************************************************************************************************/

package com.bnp.eipp.services.dao.invoice;

import java.sql.Timestamp;
import java.util.List;

import com.bnp.eipp.services.invoice.vo.EippAuditVO;
import com.bnp.eipp.services.invoice.vo.EippCreditNoteUtilVO;
import com.bnp.eipp.services.invoice.vo.EippCustFieldsVO;
import com.bnp.eipp.services.invoice.vo.EippDeptDisplayVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.scm.services.common.vo.AttachmentVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

/**
 * The Interface IDepartmentApprovalDao.
 */
public interface IDepartmentApprovalDao {
	
	/**
	 * Fetch dept approval summary.
	 *
	 * @param invoiceVO the invoice vo
	 * @return the list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippInvoiceVO> fetchDeptApprovalSummary(EippInvoiceVO invoiceVO, boolean isPendingAction) throws BNPApplicationException;
	
	/**
	 * Gets the custom fields for invoice.
	 *
	 * @param invId the inv id
	 * @return the custom fields for invoice
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippCustFieldsVO> getCustomFieldsForInvoice(long invId) throws BNPApplicationException;
	
	/**
	 * Gets the cnt util list.
	 *
	 * @param invId the inv id
	 * @return the cnt util list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippCreditNoteUtilVO> getCntUtilList(long invId) throws BNPApplicationException;
	
	/**
	 * Gets the inv line items.
	 *
	 * @param inputVO the input vo
	 * @return the inv line items
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippInvCntLineItemVO> getInvLineItems(EippInvCntLineItemVO inputVO) throws BNPApplicationException;
	
	/**
	 * Approve invoice in dept alloc map.
	 *
	 * @param invoiceVO the invoice vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void approveInvoiceInDeptAllocMap(EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
	/**
	 * Gets the pending inv for approval count.
	 *
	 * @param invId the inv id
	 * @return the pending inv for approval count
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<Integer> getPendingInvForApprovalCount(EippInvoiceVO invId) throws BNPApplicationException;
	
	/**
	 * Approve invoice.
	 *
	 * @param invoiceVO the invoice vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void approveInvoice(EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
	/**
	 * Approve line item.
	 *
	 * @param invoiceVO the invoice vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void approveLineItem(EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
	
	/**
	 * Check inv count for line items.
	 *
	 * @param invoiceVO the invoice vo
	 * @return the int
	 * @throws BNPApplicationException the bNP application exception
	 */
	int checkInvCountForLineItems(EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
	/**
	 * Approve invoice for linet item.
	 *
	 * @param invoiceVO the invoice vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void approveInvoiceForLinetItem(EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
	/**
	 * Gets the users list for reassigning.
	 *
	 * @param invoiceVO the invoice vo
	 * @return the users list for reassigning
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<String> getUsersListForReassigning(EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
	/**
	 * Gets the department list for reassigning.
	 *
	 * @param invoiceVO the invoice vo
	 * @return the department list for reassigning
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippDeptDisplayVO> getDepartmentListForReassigning(EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
	/**
	 * Gets the existing assignees.
	 *
	 * @param invoiceVO the invoice vo
	 * @return the existing assignees
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getExistingAssignees(EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
	/**
	 * Change status to pending.
	 *
	 * @param invoiceVO the invoice vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void changeStatusToPending(EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
	/**
	 * Reassign to departments.
	 *
	 * @param invoiceVO the invoice vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void reassignToDepartments(EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
	/**
	 * Reassign to users.
	 *
	 * @param invoiceVO the invoice vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void reassignToUsers(EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
	/**
	 * Gets the line items ids.
	 *
	 * @param invoiceVO the invoice vo
	 * @return the line items ids
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<Long> getLineItemsIds(EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
	 /**
 	 * Gets the line items for invoice.
 	 *
 	 * @param invoiceVO the invoice vo
 	 * @return the line items for invoice
 	 * @throws BNPApplicationException the bNP application exception
 	 */
 	List<EippInvCntLineItemVO> getLineItemsForInvoice(EippInvoiceVO invoiceVO) throws BNPApplicationException;

	/**
	 * Reject invoice.
	 *
	 * @param invoiceVO the invoice vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void rejectInvoice(EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
	/**
	 * Gets the invoice audit details.
	 *
	 * @param invID the inv id
	 * @return the invoice audit details
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippAuditVO> getInvoiceAuditDetails(long invID) throws BNPApplicationException;

	/**
	 * Gets the invoice line item audit details.
	 *
	 * @param lineItemID the line item id
	 * @return the invoice line item audit details
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippAuditVO> getInvoiceLineItemAuditDetails(long lineItemID) throws BNPApplicationException;
	
	/**
	 * Approve invoice line item in dept alloc map.
	 *
	 * @param input the input
	 * @throws BNPApplicationException the bNP application exception
	 */
	void approveInvoiceLineItemInDeptAllocMap(EippInvCntLineItemVO input) throws BNPApplicationException;
	
	/**
	 * Gets the pending inv ln itm for approval count.
	 *
	 * @param input the input
	 * @return the pending inv ln itm for approval count
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<Integer> getPendingInvLnItmForApprovalCount(EippInvCntLineItemVO input) throws BNPApplicationException;
	
	/**
	 * Approve line item level.
	 *
	 * @param input the input
	 * @throws BNPApplicationException the bNP application exception
	 */
	void approveLineItemLevel(EippInvCntLineItemVO input) throws BNPApplicationException ;
	
	/**
	 * Reassign invoice line items.
	 *
	 * @param input the input
	 * @throws BNPApplicationException the bNP application exception
	 */
	void reassignInvoiceLineItems(EippInvCntLineItemVO input) throws BNPApplicationException;
	
	/**
	 * Upload invoice attachment.
	 *
	 * @param attachVO the attach vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void uploadInvoiceAttachment(AttachmentVO attachVO) throws BNPApplicationException;
	
	/**
	 * Gets the attachments.
	 *
	 * @param invId the inv id
	 * @return the attachments
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<AttachmentVO> getAttachments(long invId) throws BNPApplicationException;
	
	/**
	 * Gets the custom fields for line items.
	 *
	 * @param lineItemId the line item id
	 * @return the custom fields for line items
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippCustFieldsVO> getCustomFieldsForLineItems(long lineItemId) throws BNPApplicationException;
	

	/**
	 * Gets the old dept ids.
	 *
	 * @param _tmpVO the _tmp vo
	 * @return the old dept ids
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<String> getOldDeptIds(EippInvCntLineItemVO tmpVO) throws BNPApplicationException;
	
	/**
	 * Gets the new dept ids.
	 *
	 * @param invoiceVO the invoice vo
	 * @return the new dept ids
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippDeptDisplayVO> getNewDeptIds(EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
	/**
	 * Gets the buyer org list.
	 *
	 * @param input the input
	 * @return the buyer org list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getBuyerOrgList(NameValueVO input) throws BNPApplicationException ;

	/**
	 * Gets the supplier org list.
	 *
	 * @param input the input
	 * @return the supplier org list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getSupplierOrgList(NameValueVO input) throws BNPApplicationException;
		
	/**
	 * Gets the last updated ts.
	 *
	 * @param invId the inv id
	 * @return the last updated ts
	 * @throws BNPApplicationException the bNP application exception
	 */
	Timestamp getLastUpdatedTS(long invId) throws BNPApplicationException;
	
	/**
	 * Gets the inv status from line item.
	 *
	 * @param invoiceVO the invoice vo
	 * @return the inv status from line item
	 * @throws BNPApplicationException the bNP application exception
	 */
	String getInvStatusFromLineItem(EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
	/**
	 * Gets the dept ids.
	 *
	 * @param invoiceVO the invoice vo
	 * @return the dept ids
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<Long> getDeptIds(EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
}
