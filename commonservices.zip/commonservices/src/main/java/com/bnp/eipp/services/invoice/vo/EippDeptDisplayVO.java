/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Mar 10th, 2012
 * 
 * Purpose:      EippDeptDisplayVO.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Mar 10th , 20127:55:00 PM        Oracle Financial Services Software Ltd                  Initial Version  
************************************************************************************************************************************************************/

package com.bnp.eipp.services.invoice.vo;

public class EippDeptDisplayVO {
	
	private long pkId;
	
	private String name;

	public void setPkId(long pkId) {
		this.pkId = pkId;
	}

	public long getPkId() {
		return pkId;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

}
