/****************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14 Oct 2012
 * 
 * Purpose: Eipp Matching Message DAO Impl
 * 
 * Change History: 
 * Date                       	Author                                  Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 14 Oct 2012              	Prabu P                      			Initial Version
 ********************************************************************************************************************************/

package com.bnp.eipp.services.matching.dao;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.invoice.vo.EippCreditNoteVO;
import com.bnp.eipp.services.invoice.vo.EippCustFieldsVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.invoice.vo.EippTransactionVO;
import com.bnp.eipp.services.vo.common.EippMessageVO;
import com.bnp.eipp.services.vo.payment.EippPymtVO;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;

@Component
public class EippMatchingMessageDAOImpl extends SqlMapClientWrapper implements IEippMatchingMessageDAO {

	private static final String NAME_SPACE = "EippMatchingMessageNS.";

	private static final String GET_MSG_HEADER = NAME_SPACE + "getHeaderDetails";

	private static final String GET_MATCHING_UNLINKED_CREDIT_NOTE = NAME_SPACE + "getMatchingUnlinkedCreditNote";

	private static final String GET_MATCHING_CREDIT_NOTE = NAME_SPACE + "getMatchingCreditNote";

	private static final String GET_MATCHING_INVOICE = NAME_SPACE + "getMatchingInvoice";

	private static final String GET_MATCH_REC_GROUP_LIST = NAME_SPACE + "getMatchRecGroupList";

	private static final String INSERT_PYMT_TRANS_RECORD = NAME_SPACE + "insertPaymentTransRecord";
	
	private static final String INSERT_PYMT_HIST_RECORD = NAME_SPACE + "insertPaymentHistRecord";
	
	private static final String APPROVE_PYMT_RECORD = NAME_SPACE + "approvePaymentRecord";
	
	private static final String DELETE_PYMT_TRANS_RECORD = NAME_SPACE + "deletePaymentTransRecord";
	
	private static final String GET_UNMATCH_PMT = NAME_SPACE + "getUnmatchedPayments";
	
	private static final String GET_FILE_ID_LIST = NAME_SPACE + "getFileIdList";
	
	private static final String GET_MSG_BATCH_REF = NAME_SPACE + "getMsgBatchRefId";
	
	private static final String UPDATE_INVC_STATUS = NAME_SPACE + "updateInvcMsgStatus";
	
	private static final String UPDATE_CN_STATUS = NAME_SPACE + "updateCNMsgStatus";

	private static final Logger LOGGER = LoggerFactory.getLogger(EippMatchingMessageDAOImpl.class);

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.matching.dao.IEippMatchingMessageDAO#getHeaderDetails(java.lang.String)
	 */
	@Override
	public Map<String, String> getHeaderDetails(String orgId) throws BNPApplicationException {
		try {
			return (Map<String, String>)getSqlMapClientTemplate().queryForObject(GET_MSG_HEADER, orgId);
		}
		catch (DataAccessException e) {
			LOGGER.error("Database error ::"+ e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.matching.dao.IEippMatchingMessageDAO#insertPaymentDetails(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	@Override
	public void insertPaymentDetails(EippPymtVO eippPymtVO) throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(INSERT_PYMT_TRANS_RECORD, eippPymtVO);
			getSqlMapClientTemplate().insert(INSERT_PYMT_HIST_RECORD, eippPymtVO);
		}
		catch (DataAccessException e) {
			LOGGER.error("Database error ::"+ e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.matching.dao.IEippMatchingMessageDAO#approvePaymentDetails(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	@Override
	public void approvePaymentDetails(EippPymtVO eippPymtVO) throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(APPROVE_PYMT_RECORD, eippPymtVO);
			getSqlMapClientTemplate().insert(INSERT_PYMT_HIST_RECORD, eippPymtVO);
			getSqlMapClientTemplate().delete(DELETE_PYMT_TRANS_RECORD, eippPymtVO);
		}
		catch (DataAccessException e) {
			LOGGER.error("Database error ::"+ e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.matching.dao.IEippMatchingMessageDAO#getMatchRecGroupList()
	 */
	@Override
	public List<EippInvCntVO> getMatchRecGroupList(EippMessageVO invoiceMsgVO) throws BNPApplicationException {
		try {
			return (List<EippInvCntVO>)getSqlMapClientTemplate().queryForList(GET_MATCH_REC_GROUP_LIST, invoiceMsgVO);
		}
		catch (DataAccessException e) {
			LOGGER.error("Database error ::"+ e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public List<EippInvoiceVO> getMatchingInvoiceList(EippInvCntVO eippInvCntVO) throws BNPApplicationException {
		try {
			return (List<EippInvoiceVO>)getSqlMapClientTemplate().queryForList(GET_MATCHING_INVOICE, eippInvCntVO);
		}
		catch (DataAccessException e) {
			LOGGER.error("Database error ::"+ e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.matching.dao.IEippMatchingMessageDAO#getMatchingCreditNoteList(java.util.List)
	 */
	@Override
	public List<EippCreditNoteVO> getMatchingCreditNoteList(List<EippInvoiceVO> invcList) throws BNPApplicationException {
		try {
			return (List<EippCreditNoteVO>)getSqlMapClientTemplate().queryForList(GET_MATCHING_CREDIT_NOTE, invcList);
		}
		catch (DataAccessException e) {
			LOGGER.error("Database error ::"+ e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.matching.dao.IEippMatchingMessageDAO#getMatchingUnlinkedCreditNoteList(com.bnp.eipp.services.invoice.vo.EippInvCntVO)
	 */
	@Override
	public List<EippCreditNoteVO> getMatchingUnlinkedCreditNoteList(EippInvCntVO eippInvCntVO) throws BNPApplicationException {
		try {
			return (List<EippCreditNoteVO>)getSqlMapClientTemplate().queryForList(GET_MATCHING_UNLINKED_CREDIT_NOTE,
					eippInvCntVO);
		}
		catch (DataAccessException e) {
			LOGGER.error("Database error ::"+ e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.matching.dao.IEippMatchingMessageDAO#getUnmatchedPayments(java.lang.String)
	 */
	@Override
	public List<EippPymtVO> getUnmatchedPayments(String orgId) throws BNPApplicationException {
		try {
			return (List<EippPymtVO>)getSqlMapClientTemplate().queryForList(GET_UNMATCH_PMT, orgId);
		}
		catch (DataAccessException e) {
			LOGGER.error("Database error ::"+ e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.matching.dao.IEippMatchingMessageDAO#getFileIdList(java.lang.String)
	 */
	@Override
	public List<String> getFileIdList(String fileId) throws BNPApplicationException {
		try {
			return (List<String>)getSqlMapClientTemplate().queryForList(GET_FILE_ID_LIST, fileId);
		}
		catch (DataAccessException e) {
			LOGGER.error("Database error ::"+ e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.matching.dao.IEippMatchingMessageDAO#getMatchingMsgBatchRefId()
	 */
	@Override
	public String getMatchingMsgBatchRefId() throws BNPApplicationException {
		try {
			return (String)getSqlMapClientTemplate().queryForObject(GET_MSG_BATCH_REF);
		}
		catch (DataAccessException e) {
			LOGGER.error("Database error ::"+ e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.matching.dao.IEippMatchingMessageDAO#updateMsgDeliveryStatus(com.bnp.eipp.services.vo.common.EippMessageVO)
	 */
	@Override
	public void updateMsgDeliveryStatus(EippMessageVO eippMessageVO) throws BNPApplicationException {
		try {
			List<EippInvCntVO> invcCNList = (List<EippInvCntVO>)eippMessageVO.getDataList();
			if(invcCNList != null) {
				for (EippInvCntVO eippInvCntVO : invcCNList) {
					List<EippInvoiceVO> invcList = eippInvCntVO.getInvoiceList();
					List<EippCreditNoteVO> creditNoteList = eippInvCntVO.getCntList();
					
					eippInvCntVO.setFileRefId(eippMessageVO.getFileRefId());
					eippInvCntVO.setStatusCode(eippMessageVO.getStatusCode());
					eippInvCntVO.setMode(eippMessageVO.getMode());
					if(invcList != null && !invcList.isEmpty()) {
						getSqlMapClientTemplate().update(UPDATE_INVC_STATUS, eippInvCntVO);
					}
					if(creditNoteList != null && !creditNoteList.isEmpty()) {
						getSqlMapClientTemplate().update(UPDATE_CN_STATUS, eippInvCntVO);
					}
				}
			}
		}
		catch (DataAccessException e) {
			LOGGER.error("Database error ::"+ e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.matching.dao.IEippMatchingMessageDAO#getCustomFieldList(com.bnp.eipp.services.invoice.vo.EippTransactionVO)
	 */
	@Override
	public List<EippCustFieldsVO> getCustomFieldList(EippTransactionVO transactionVO) throws BNPApplicationException {
		try {
			return getSqlMapClientTemplate().queryForList(NAME_SPACE +"getCustomFields", transactionVO);
		}
		catch (DataAccessException e) {
			LOGGER.error("Database error ::"+ e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	
}
