/** ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 2, 2012
 * 
 * Purpose:      EippInvCntLineItemVO.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 2, 2012       Oracle Financial Services Software Ltd                  Initial Version
 * Mar 2, 2012       Oracle Financial Services Software Ltd                  Added attributes for department approval  
 * Mar 6, 2012       Oracle Financial Services Software Ltd                  Added attributes for invoice cancellation
 * Sep 17, 2012			Sandhya R												R3.0 Eipp Ph2.0 Dispute changes
 * 17 Oct 2012			Sriram Rengarajan				Fix for Ahoc ST defects for Line Items
 * 23 Oct 2012			Merdith 											Gross Value Changes for Line Item
************************************************************************************************************************************************************/

package com.bnp.eipp.services.invoice.vo;

import java.math.BigDecimal;
import java.util.List;

/**
 * The Class EippInvCntLineItemVO.
 */
public class EippInvCntLineItemVO extends EippTransactionVO{

	
	private static final long serialVersionUID = -4766548244316109138L;
	
	private long fkId;

	private long lineItemId;
	
	private String lineItemNo;
	
	private String partNo;
	
	private String itemDesc;
	
	private String itemPoNumber;
	
	private String uomCode;
	
	private BigDecimal itemQty;
	
	private BigDecimal itemUnitPrice;
	
	private BigDecimal itemTotalPrice;
	
	private String lineItemStatus;
	
	private String fieldName;
	
	private String operator;
	
	private Object value;
	
	private boolean ignoreCase;
	
	private List<String> oldDeptIds;
	
	private List<EippDeptDisplayVO> newDeptIds;
	
	private List<EippAuditVO> lineItemAuditVO;
	
	private String approvalLevel;	
	
	private int allocLevel;
	
	private String active;
	
	private long dept;
	
	private String itemTotalPriceCcy;
	
	private String itemUnitPriceCcy;
	
	private long deptPkId;
	
	// added for eipp 3.0 releae
	private BigDecimal disputedAmt;
	
	private long pymtId;
	
	private long invId;
	
	private boolean disableUtildLI;
	
	private BigDecimal disputedQty;
	
	private BigDecimal disputedUnitPrice;
	
	private BigDecimal disputedSubTotal;
	
	/** The derivd item tot price. */
	private BigDecimal derivdItemTotPrice;
	
	private String lnItmStatus;
	
	private BigDecimal blockedAmt;
	
	private String allPymtBefAllItm;
	
	private BigDecimal itemGrossAmt;
	private BigDecimal itemSubTotal;
	
	private BigDecimal taxAmt;
	
	private BigDecimal adjusOutAmt;
	
	public BigDecimal getAdjusOutAmt() {
		return adjusOutAmt;
	}

	public void setAdjusOutAmt(BigDecimal adjusOutAmt) {
		this.adjusOutAmt = adjusOutAmt;
	}

	public BigDecimal getTaxAmt() {
		return taxAmt;
	}

	public void setTaxAmt(BigDecimal taxAmt) {
		this.taxAmt = taxAmt;
	}
	/**
	 * Gets the field name.
	 *
	 * @return the field name
	 */
	public String getFieldName() {
		return fieldName;
	}

	/**
	 * Sets the field name.
	 *
	 * @param fieldName the new field name
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	/**
	 * Gets the operator.
	 *
	 * @return the operator
	 */
	public String getOperator() {
		return operator;
	}

	/**
	 * Sets the operator.
	 *
	 * @param operator the new operator
	 */
	public void setOperator(String operator) {
		this.operator = operator;
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public Object getValue() {
		return value;
	}

	/**
	 * Sets the value.
	 *
	 * @param value the new value
	 */
	public void setValue(Object value) {
		this.value = value;
	}

	/**
	 * Checks if is ignore case.
	 *
	 * @return true, if is ignore case
	 */
	public boolean isIgnoreCase() {
		return ignoreCase;
	}

	/**
	 * Sets the ignore case.
	 *
	 * @param ignoreCase the new ignore case
	 */
	public void setIgnoreCase(boolean ignoreCase) {
		this.ignoreCase = ignoreCase;
	}

	/**
	 * Gets the line item id.
	 *
	 * @return the lineItemId
	 */
	public long getLineItemId() {
		return lineItemId;
	}

	/**
	 * Sets the line item id.
	 *
	 * @param lineItemId the lineItemId to set
	 */
	public void setLineItemId(long lineItemId) {
		this.lineItemId = lineItemId;
	}

	/**
	 * Gets the line item no.
	 *
	 * @return the lineItemNo
	 */
	public String getLineItemNo() {
		return lineItemNo;
	}

	/**
	 * Sets the line item no.
	 *
	 * @param lineItemNo the lineItemNo to set
	 */
	public void setLineItemNo(String lineItemNo) {
		this.lineItemNo = lineItemNo;
	}

	/**
	 * Gets the part no.
	 *
	 * @return the partNo
	 */
	public String getPartNo() {
		return partNo;
	}

	/**
	 * Sets the part no.
	 *
	 * @param partNo the partNo to set
	 */
	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}

	/**
	 * Gets the item desc.
	 *
	 * @return the itemDesc
	 */
	public String getItemDesc() {
		return itemDesc;
	}

	/**
	 * Sets the item desc.
	 *
	 * @param itemDesc the itemDesc to set
	 */
	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	/**
	 * Gets the uom code.
	 *
	 * @return the uomCode
	 */
	public String getUomCode() {
		return uomCode;
	}

	/**
	 * Sets the uom code.
	 *
	 * @param uomCode the uomCode to set
	 */
	public void setUomCode(String uomCode) {
		this.uomCode = uomCode;
	}

	/**
	 * Gets the item qty.
	 *
	 * @return the itemQty
	 */
	public BigDecimal getItemQty() {
		return itemQty;
	}

	/**
	 * Sets the item qty.
	 *
	 * @param itemQty the itemQty to set
	 */
	public void setItemQty(BigDecimal itemQty) {
		this.itemQty = itemQty;
	}

	/**
	 * Gets the item unit price.
	 *
	 * @return the itemUnitPrice
	 */
	public BigDecimal getItemUnitPrice() {
		return itemUnitPrice;
	}

	/**
	 * Sets the item unit price.
	 *
	 * @param itemUnitPrice the itemUnitPrice to set
	 */
	public void setItemUnitPrice(BigDecimal itemUnitPrice) {
		this.itemUnitPrice = itemUnitPrice;
	}

	/**
	 * Gets the item total price.
	 *
	 * @return the itemTotalPrice
	 */
	public BigDecimal getItemTotalPrice() {
		return itemTotalPrice;
	}

	/**
	 * Sets the item total price.
	 *
	 * @param itemTotalPrice the itemTotalPrice to set
	 */
	public void setItemTotalPrice(BigDecimal itemTotalPrice) {
		this.itemTotalPrice = itemTotalPrice;
	}

	/**
	 * Gets the fk id.
	 *
	 * @return the fkId
	 */
	public long getFkId() {
		return fkId;
	}

	/**
	 * Sets the fk id.
	 *
	 * @param fkId the fkId to set
	 */
	public void setFkId(long fkId) {
		this.fkId = fkId;
	}

	/**
	 * Gets the line item status.
	 *
	 * @return the lineItemStatus
	 */
	public String getLineItemStatus() {
		return lineItemStatus;
	}

	/**
	 * Sets the line item status.
	 *
	 * @param lineItemStatus the lineItemStatus to set
	 */
	public void setLineItemStatus(String lineItemStatus) {
		this.lineItemStatus = lineItemStatus;
	}

	/**
	 * Sets the new dept ids.
	 *
	 * @param newDeptIds the newDeptIds to set
	 */
	public void setNewDeptIds(List<EippDeptDisplayVO> newDeptIds) {
		this.newDeptIds = newDeptIds;
	}

	/**
	 * Gets the new dept ids.
	 *
	 * @return the newDeptIds
	 */
	public List<EippDeptDisplayVO> getNewDeptIds() {
		return newDeptIds;
	}

	/**
	 * Sets the old dept ids.
	 *
	 * @param oldDeptIds the oldDeptIds to set
	 */
	public void setOldDeptIds(List<String> oldDeptIds) {
		this.oldDeptIds = oldDeptIds;
	}

	/**
	 * Gets the old dept ids.
	 *
	 * @return the oldDeptIds
	 */
	public List<String> getOldDeptIds() {
		return oldDeptIds;
	}

	/**
	 * Sets the line item audit vo.
	 *
	 * @param lineItemAuditVO the lineItemAuditVO to set
	 */
	public void setLineItemAuditVO(List<EippAuditVO> lineItemAuditVO) {
		this.lineItemAuditVO = lineItemAuditVO;
	}

	/**
	 * Gets the line item audit vo.
	 *
	 * @return the lineItemAuditVO
	 */
	public List<EippAuditVO> getLineItemAuditVO() {
		return lineItemAuditVO;
	}

	/**
	 * @param approvalLevel the approvalLevel to set
	 */
	public void setApprovalLevel(String approvalLevel) {
		this.approvalLevel = approvalLevel;
	}

	/**
	 * @return the approvalLevel
	 */
	public String getApprovalLevel() {
		return approvalLevel;
	}
	
	public int getAllocLevel() {
		return allocLevel;
	}

	public void setAllocLevel(int allocLevel) {
		this.allocLevel = allocLevel;
	}

	/**
	 * @param dept the dept to set
	 */
	public void setDept(long dept) {
		this.dept = dept;
	}

	/**
	 * @return the dept
	 */
	public long getDept() {
		return dept;
	}

	/**
	 * @param active the active to set
	 */
	public void setActive(String active) {
		this.active = active;
	}

	/**
	 * @return the active
	 */
	public String getActive() {
		return active;
	}

	/**
	 * @param itemTotalPriceCcy the itemTotalPriceCcy to set
	 */
	public void setItemTotalPriceCcy(String itemTotalPriceCcy) {
		this.itemTotalPriceCcy = itemTotalPriceCcy;
	}

	/**
	 * @return the itemTotalPriceCcy
	 */
	public String getItemTotalPriceCcy() {
		return itemTotalPriceCcy;
	}

	/**
	 * @param itemUnitPriceCcy the itemUnitPriceCcy to set
	 */
	public void setItemUnitPriceCcy(String itemUnitPriceCcy) {
		this.itemUnitPriceCcy = itemUnitPriceCcy;
	}

	/**
	 * @return the itemUnitPriceCcy
	 */
	public String getItemUnitPriceCcy() {
		return itemUnitPriceCcy;
	}

	public String getItemPoNumber() {
		return itemPoNumber;
	}

	public void setItemPoNumber(String itemPoNumber) {
		this.itemPoNumber = itemPoNumber;
	}

	public void setDeptPkId(long deptPkId) {
		this.deptPkId = deptPkId;
	}

	public long getDeptPkId() {
		return deptPkId;
	}

	public BigDecimal getDisputedAmt() {
		return disputedAmt;
	}

	public void setDisputedAmt(BigDecimal disputedAmt) {
		this.disputedAmt = disputedAmt;
	}

	public long getPymtId() {
		return pymtId;
	}

	public void setPymtId(long pymtId) {
		this.pymtId = pymtId;
	}

	public long getInvId() {
		return invId;
	}

	public void setInvId(long invId) {
		this.invId = invId;
	}

	public boolean isDisableUtildLI() {
		return disableUtildLI;
	}

	public void setDisableUtildLI(boolean disableUtildLI) {
		this.disableUtildLI = disableUtildLI;
	}

	/**
	 * @return the disputedQty
	 */
	public BigDecimal getDisputedQty() {
		return disputedQty;
	}

	/**
	 * @param disputedQty the disputedQty to set
	 */
	public void setDisputedQty(BigDecimal disputedQty) {
		this.disputedQty = disputedQty;
	}

	/**
	 * @return the disputedUnitPrice
	 */
	public BigDecimal getDisputedUnitPrice() {
		return disputedUnitPrice;
	}

	/**
	 * @param disputedUnitPrice the disputedUnitPrice to set
	 */
	public void setDisputedUnitPrice(BigDecimal disputedUnitPrice) {
		this.disputedUnitPrice = disputedUnitPrice;
	}

	/**
	 * @return the disputedSubTotal
	 */
	public BigDecimal getDisputedSubTotal() {
		return disputedSubTotal;
	}

	/**
	 * @param disputedSubTotal the disputedSubTotal to set
	 */
	public void setDisputedSubTotal(BigDecimal disputedSubTotal) {
		this.disputedSubTotal = disputedSubTotal;
	}

	public void setDerivdItemTotPrice(BigDecimal derivdItemTotPrice) {
		this.derivdItemTotPrice = derivdItemTotPrice;
	}

	public BigDecimal getDerivdItemTotPrice() {
		return derivdItemTotPrice;
	}

	public void setLnItmStatus(String lnItmStatus) {
		this.lnItmStatus = lnItmStatus;
	}

	public String getLnItmStatus() {
		return lnItmStatus;
	}

	public void setBlockedAmt(BigDecimal blockedAmt) {
		this.blockedAmt = blockedAmt;
	}

	public BigDecimal getBlockedAmt() {
		return blockedAmt;
	}

	public void setAllPymtBefAllItm(String allPymtBefAllItm) {
		this.allPymtBefAllItm = allPymtBefAllItm;
	}

	public String getAllPymtBefAllItm() {
		return allPymtBefAllItm;
	}

	/**
	 * @param itemGrossAmt the itemGrossAmt to set
	 */
	public void setItemGrossAmt(BigDecimal itemGrossAmt) {
		this.itemGrossAmt = itemGrossAmt;
	}

	/**
	 * @return the itemGrossAmt
	 */
	public BigDecimal getItemGrossAmt() {
		return itemGrossAmt;
	}

	/**
	 * @param itemSubTotal the itemSubTotal to set
	 */
	public void setItemSubTotal(BigDecimal itemSubTotal) {
		this.itemSubTotal = itemSubTotal;
	}

	/**
	 * @return the itemSubTotal
	 */
	public BigDecimal getItemSubTotal() {
		return itemSubTotal;
	}



}
