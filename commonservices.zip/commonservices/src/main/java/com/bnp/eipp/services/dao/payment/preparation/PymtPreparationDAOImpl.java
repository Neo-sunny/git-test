/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   06 Aug 2012
 * 
 * Purpose:      PymtPreparationDAOImpl
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 06 Aug 2012       Oracle Financial Services Software Ltd                 Initial Version
 * 14 Sep 2012				Sandhya R										Auto Payment Preparation
 * 21 Sep 2012				Sriram Rengarajan								Removed the duplicate code
 * 22 Sep 2012				Sriram Rengarajan								Eipp 3.0 - UTP - Unit Testing fix
 * 03 OCt 2012				Arun G								            Eipp 3.0 - UTP - Unit Testing fix
 * 26 Sep 2012              Gangadharan R									Authorization matrix changes
 * 03 OCt 2012				Arun G								            Eipp 3.0 - UTP - Unit Testing fix
 * 10 Oct 2012    			Gangadharan R							  		Fix for ST defect 6864
 * 15 Oct 2012				Gangadharan R							 		Fix for ST defects 6918, 6935
 * 16 Oct 2012				Gangadharan R							 		Fix for ST defects 6944
 * 20 Oct 2012 				Reena S											Fix for ST TD: 6936 Inserting custom fields
 * 23 Oct 2012				Gangadharan R									Fix for ST defect 6987
 * 25 Oct 2012              Reena S											Fix for ST TD: 7092
 * 26 Oct 2012				Gangadharan R									Fix for ST defect 6998
 * 27 Oct 2012				Gangadharan R									Fix for ST sanity testing
 * 31 Oct 2012				Gangadharan R									Fix for ST sanity testing
 * 04 Dec 2012				Gangadharan R									Adhoc - Line items not getting inserted during MFU
 * 10 Sep 2013				Merdith Silvester								3714: To Display the EarlyPayment/LateRule Id
 * 11 SEP 2013					Merdith S							       QC 3712
************************************************************************************************************************************************************/

package com.bnp.eipp.services.dao.payment.preparation;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.invoice.vo.EippAuditVO;
import com.bnp.eipp.services.invoice.vo.EippCreditNoteVO;
import com.bnp.eipp.services.invoice.vo.EippCustFieldsVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.vo.admin.MarketPlaceAccountVO;
import com.bnp.eipp.services.vo.payment.AutoPaymentRuleVO;
import com.bnp.eipp.services.vo.payment.EippPymtAuditVO;
import com.bnp.eipp.services.vo.payment.EippPymtVO;
import com.bnp.eipp.services.vo.payment.PaymentInitiateAccountVO;
import com.bnp.eipp.services.vo.payment.PymtAdjustMentCodeVO;
import com.bnp.eipp.services.vo.payment.PymtAdjustmentCodeCustomVO;
import com.bnp.eipp.services.vo.payment.SplitPaymentVO;
import com.bnp.scm.services.admin.vo.BuyerAccountVO;
import com.bnp.scm.services.admin.vo.SupplierAccountVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.dao.AbstractCommonDaoImpl;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.ibatis.sqlmap.client.SqlMapExecutor;
import com.ibatis.sqlmap.engine.execution.BatchException;

// TODO: Auto-generated Javadoc
// 
/**
 * The Class PymtPreparationDAOImpl.
 */
@SuppressWarnings("rawtypes")
@Component
public class PymtPreparationDAOImpl extends AbstractCommonDaoImpl implements IPymtPreparationDAO  {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(PymtPreparationDAOImpl.class);
	
	/** The Constant GET_INV_FOR_SUMMARY. */
	private static final String GET_INV_FOR_SUMMARY = "getInvoiceRecordsForSummary";

	/** The Constant GET_PYMT_ID. */
	private static final String GET_PYMT_ID = "getPymtID";	
	
	
	/* Payment details */
	/** The Constant INSERT_PYMT_DTL_TRANS. */
	private static final String INSERT_PYMT_DTL_TRANS = "insertPaymentPrepIntoTrans";
	
	/** The Constant INSERT_PYMT_DTL_HIST. */
	private static final String INSERT_PYMT_DTL_HIST = "insertPaymentPrepIntoHist";
	
	/* Invoice mapping */
	/** The Constant INSERT_INV_DTL_TRANS. */
	private static final String INSERT_INV_DTL_TRANS = "insertInvPymtMapTrans";
	
	/* Payment Credit Note */
	/** The Constant INSERT_CN_DTL_TRANS. */
	private static final String INSERT_CN_DTL_TRANS = "insertPymtCredNoteMapTrans";
	
	/* Payment Adjustment */
	/** The Constant INSERT_PYMT_ADJ_DTL_TRANS. */
	private static final String INSERT_PYMT_ADJ_DTL_TRANS = "insertPymtAdjMapTrans";
	
	/* Split Payment */
	/** The Constant INSERT_SPLIT_PYMT_DTL_TRANS. */
	private static final String INSERT_SPLIT_PYMT_DTL_TRANS = "insertSplitPymtMapTrans";
	
	/* Invoice Line Items */
	/** The Constant INSERT_LINE_ITEM_DTL_TRANS. */
	private static final String INSERT_LINE_ITEM_DTL_TRANS = "insertLnItemPymtMapTrans";
	
	/* Custom Fields */
	/** The Constant INSERT_CUST_FLD_DTL_TRANS. */
	private static final String INSERT_CUST_FLD_DTL_TRANS = "insertPymtCustFldMapTrans";
	
	/** The constant EIPP_PYMT_DATE_CALC. */
	private static final String EIPP_PYMT_DATE_CALC = "callEippPymtDateCalc";
	
		
	/** The Constant GET_BRANCH_TIME_ZONE. */
	private static final String GET_BRANCH_TIME_ZONE = "getBranchTimeZone";	
	
	/** The Constant CHECK_POST_CUT_OFF_TIME. */
	private static final String CHECK_POST_CUT_OFF_TIME = "checkPostCutOffTime";
	
	/** The Constant INSERT_PYMT_ACCESS_LOG. */
	private static final String INSERT_PYMT_ACCESS_LOG = "insertPymtAccessLog";
	
	/** The Constant UPDATE_PYMT_STATUS. */
	private static final String UPDATE_PYMT_STATUS = "updatePymtStatus";	
	
	/** The Constant GET_PYMT_PREP_LEAD_DAYS. */
	private static final String GET_PYMT_PREP_LEAD_DAYS = "getPaymentPrepLeadDays";
	
	/** The Constant GET_NEXT_WORK_DATE. */
	private static final String GET_NEXT_WORK_DATE = "getNextWorkingDate";
	
	/** The Constant GET_DEFAULT_SUPP_ACCT. */
	private static final String GET_DEFAULT_SUPP_ACCT = "getDefaultSupplrAcct";
	
	/** The Constant GET_SUPLR_ACCT_FOR_TXN_CCY. */
	private static final String GET_SUPLR_ACCT_FOR_TXN_CCY = "getSuplrAcctForTxnCcy";
	
	/** The Constant GET_BUYER_ACCT. */
	private static final String GET_BUYER_ACCT = "getBuyerAcct";;
	
	/** The Constant GET_MKT_PLACE_ACCT. */
	private static final String GET_MKT_PLACE_ACCT = "getMktPlaceAcct";
	
	/** The Constant GET_CN_DETAILS. */
	private static final String GET_CN_DETAILS = "getCNDetails";
	
	/** The Constant GET_LINE_ITEM_DETAILS. */
	private static final String GET_LINE_ITEM_DETAILS = "getLineItemDetails";
	
	/** The Constant GET_PMT_ADJ_CODE_DETAILS. */
	private static final String GET_PMT_ADJ_CODE_DETAILS = "getPmtAdjCodeDetails";
	
	/** The Constant GET_BUSINESS_DAY. */
	private static final String GET_BUSINESS_DAY = "getHolidayAdjustedDate" ;
	
	/** The Constant GET_SUPPLIER_PMT_METHOD. */
	private static final String GET_SUPPLIER_PMT_METHOD = "getSupplierPmtMthd";
	
	/** The Constant GET_MKT_PLACE_PMT_MTHD. */
	private static final String GET_MKT_PLACE_PMT_MTHD = "getMktPlacePmtMthd";
	
	/** The Constant GET_BUYER_PMT_MTHD. */
	private static final String GET_BUYER_PMT_MTHD = "getBuyerPmtMthd";
	
	/** The Constant GET_PYMT_PROC_FOR_BUYER. */
	private static final String GET_PYMT_PROC_FOR_BUYER = "getPymtProcForBuyer";
	
	/** The Constant GET_PYMT_PROC_FOR_SUPPLR. */
	private static final String GET_PYMT_PROC_FOR_SUPPLR = "getPymtProcForSupplr";
	
	/** The Constant GET_PYMT_PROC_FOR_MKTPLACE. */
	private static final String GET_PYMT_PROC_FOR_MKTPLACE = "getPymtProcForMktPlace";
	
	/** The Constant GET_PMT_REF_NO. */
	private static final String GET_PMT_REF_NO = "getPmtRefNo";
	
	/** The Constant GET_BUYER_MAP_ID. */
	private static final String GET_BUYER_MAP_ID = "getBuyrMapId";
	
	/** The Constant GET_SUPPLR_MAP_ID. */
	private static final String GET_SUPPLR_MAP_ID = "getSupplrMapId";
	
	/** The Constant GET_MPLACE_MAP_ID. */
	private static final String GET_MPLACE_MAP_ID = "getMplaceMapId";
	
	/** The Constant INSERT_INTO_PYMT_MASTER_TABLE. */
	private static final String INSERT_INTO_PYMT_MASTER_TABLE = "insertIntoPymtMasterTable";
	
	/** The Constant INSERT_INTO_PYMT_HIST_TABLE. */
	private static final String INSERT_INTO_PYMT_HIST_TABLE ="insertIntoPymtHistTable";
	
	/** The Constant INSERT_INTO_INV_PYMT_MAPPING_TABLE. */
	private static final String INSERT_INTO_INV_PYMT_MAPPING_TABLE = "insertIntoInvPymtMappingTable";
	
	/** The Constant INSERT_INTO_CN_PYM_MAP_TABLE. */
	private static final String	INSERT_INTO_CN_PYM_MAP_TABLE = "insertIntoCNPymtMappingTable";
	
	/** The Constant INSERT_INTO_CN_PYM_MAP_TABLE_HIST. */
	private static final String	INSERT_INTO_CN_PYM_MAP_TABLE_HIST = "insertIntoCNPymtMappingTableHist";
	
	/** The Constant UPDATE_CREDIT_NOTE_TABLE. */
	private static final String UPDATE_CREDIT_NOTE_TABLE = "updateCreditNoteTable";
	
	/** The Constant INSERT_INTO_PYMT_ADJ_MAP_TABLE. */
	private static final String	INSERT_INTO_PYMT_ADJ_MAP_TABLE = "insertIntoPymtAdjMappingTable";
	
	/** The Constant INSERT_INTO_PYMT_ADJ_MAP_TABLE_HIST. */
	private static final String	INSERT_INTO_PYMT_ADJ_MAP_TABLE_HIST = "insertIntoPymtAdjMappingTableHist";
	
	/** The Constant INSERT_INTO_PYMT_ADJ_PARAM_TABLE. */
	private static final String INSERT_INTO_PYMT_ADJ_PARAM_TABLE = "insertIntoPymtAdjParamTable";
	
	/** The Constant INSERT_INTO_PYMT_ADJ_PARAM_TABLE_HIST. */
	private static final String INSERT_INTO_PYMT_ADJ_PARAM_TABLE_HIST = "insertIntoPymtAdjParamTableHist";
	
	/** The Constant INSERT_INTO_SPLIT_PYMT_TABLE. */
	private static final String INSERT_INTO_SPLIT_PYMT_TABLE = "insertIntoSplitPymtTable";
	
	/** The Constant INSERT_INTO_SPLIT_PYMT_TABLE_HIST. */
	private static final String INSERT_INTO_SPLIT_PYMT_TABLE_HIST = "insertIntoSplitPymtTableHist";
	
	/** The Constant INSERT_INTO_PYMT_ACC_DET_MAP. */
	private static final String	INSERT_INTO_PYMT_ACC_DET_MAP = "insertIntoPymtAccDetMap";
	
	/** The Constant INSERT_INTO_LINE_ITM_PYM_MAP_TABLE. */
	private static final String	INSERT_INTO_LINE_ITM_PYM_MAP_TABLE = "insertIntolineItemPymtMappingTable";
	
	/** The Constant INSERT_INTO_LINE_ITM_PYM_MAP_TABLE_HIST. */
	private static final String	INSERT_INTO_LINE_ITM_PYM_MAP_TABLE_HIST = "insertIntolineItemPymtMappingTableHist";
	
	/** The Constant INSERT_INTO_LINE_ITM_AUDIT_TABLE. */
	private static final String INSERT_INTO_LINE_ITM_AUDIT_TABLE = "insertIntoLineItemAudit";
	
	/** The Constant UPDATE_LINE_ITEM_DETAILS. */
	private static final String UPDATE_LINE_ITEM_DETAILS = "updateLineItemDetails";
	
	/** The Constant UPDATE_INVOICE. */
	private static final String UPDATE_INVOICE = "updateInvoice";
	
	/** The Constant INSERT_INVOICE_AUDIT. */
	private static final String INSERT_INVOICE_AUDIT = "insertInvoiceAudit";
	
	/** The Constant UPDATE_TXN_TIMESTAMP. */
	private static final String UPDATE_TXN_TIMESTAMP = "updateTxnTimestampInInvoice";
	
	/** The Constant REVERT_TXN_TIMESTAMP. */
	private static final String REVERT_TXN_TIMESTAMP = "revertTxnTimestamp";
	
	/** The Constant RESET_PROCESSING_FLAG. */
	private static final String RESET_PROCESSING_FLAG = "resetProcessingFlagInInvoiceTable";
	
	/** The Constant GET_BUYER_ORG. */
	private static final String GET_BUYER_ORG = "getBuyerOrgListForPymt"; 

	/** The Constant GET_SUPPLIER_ORG. */
	private static final String	GET_SUPPLIER_ORG = "getSupplierOrgListForPymt";
	
	/** The Constant GET_MPLACE_ORG. */
	private static final String	GET_MPLACE_ORG = "getMplaceOrgListForPymt";
	
	/** The Constant ONLINE. */
	private static final String ONLINE = "ONLINE";
	
	/** The Constant FETCH_INV_LN_ITM_RECORD. */
	private static final String FETCH_INV_LN_ITM_RECORD= "getInvLineItemRecord";
	
	/** The Constant FETCH_CRED_NOTE_RECORD. */
	private static final String FETCH_CRED_NOTE_RECORD= "getCNMappingRecords";
	
	/** The Constant GET_PYMT_MTHD_MAX_AMT. */
	private static final String GET_PYMT_MTHD_MAX_AMT = "getMaxPymtAmtFromPymtMthdBranch";	
	
	/*Auto Preparation changes*/
	/** The Constant CHECK_AUTP_PYMT_RULE_AVAILABLE. */
	private static final String CHECK_AUTP_PYMT_RULE_AVAILABLE = "checkAutoPymtRuleAvailable";
	
	/** The Constant GET_DEFAULT_SUPP_IDENTIFIER. */
	private static final String GET_DEFAULT_SUPP_IDENTIFIER = "getDefaultSupplierAccntIdentifier";
	
	/** The Constant CHECK_DISALL_PYMT_MTHD. */
	private static final String CHECK_DISALL_PYMT_MTHD = "checkDisallowPaymentMethod";
	
	/** The Constant GET_MAX_PYMT_AMT. */
	private static final String GET_MAX_PYMT_AMT = "getMaxPymtAmtFrmPymtMthdBranch";
	
	/** The Constant CALCULATE_PAYMENT_DATE. */
	private static final String CALCULATE_PAYMENT_DATE = "calculatePaymentDates";
	
	/** The Constant GET_MP_ACCNT_IDENTIFIER. */
	private static final String GET_MP_ACCNT_IDENTIFIER = "getMarketPlaceIdentifier";
	
	/** The Constant GET_SUPP_PYMT_MTHD_ID. */
	private static final String GET_SUPP_PYMT_MTHD_ID = "getSuppPymtMthdID";
	
	/** The Constant INSERT_AUTO_PYMT_MASTER. */
	private static final String INSERT_AUTO_PYMT_MASTER = "insertAutoPaymentMaster";
	
	/** The Constant POPULATE_PYMT_ID. */
	private static final String  POPULATE_PYMT_ID = "getPymtID";
	
	/** The Constant INSERT_AUTO_PYMT_HIST. */
	private static final String  INSERT_AUTO_PYMT_HIST =  "insertAutoPaymentHist";
	
	/** The Constant INSERT_INV_PYMT_MAP_MASTER. */
	private static final String  INSERT_INV_PYMT_MAP_MASTER =  "insertInvPymtMap";
	
	/** The Constant INSERT_INV_PYMT_MAP_HIST. */
	private static final String  INSERT_INV_PYMT_MAP_HIST  = "insertInvPymtMapHistory";
	
	/** The Constant INSERT_PYMT_AUDIT. */
	private static final String INSERT_PYMT_AUDIT = "insertPymtAccessLog";
	
	/** The Constant UPDATE_AUTH_PROF_REF_ID. */
	private static final String UPDATE_AUTH_PROF_REF_DET = "updateAuthProfDetails";
	
	/** The Constant GET_LINK_CN_DETAILS. */
	private static final String GET_LINK_CN_DETAILS = "getLinkedCreditNotes";
	
	private static final String GET_ALLOC_TYPE = "getAllocationType";
	
	/** The Constant CHECK_VALID_MKT_PLC_ORG. */
	private static final String CHECK_VALID_MKT_PLC_ORG = "checkValidMktPlaceOrg";
	
	private static final String UPDATE_INV_PYMT_MAP_HIST = "updatePymtMapHist";
	
	/** The Constant CHECK_VALID_MKT_PLC_ORG. */
	private static final String UPDATE_INV_PYMT_MAP_MASTER = "updatePymtMapMaster";
	private static final String GETLI_AMT = "getAmtforLI";
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.dao.AbstractDAOImpl#getNameSpace()
	 */
	public String getNameSpace() {
		return "PaymentOperationNS.";
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#getInvoiceForPymtPreparation

(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	public List<EippInvoiceVO> getInvoiceForPymtPreparation(EippInvoiceVO eippInvoiceVO)throws BNPApplicationException{
		List<EippInvoiceVO> invoiceList = null;
		try{
			invoiceList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_INV_FOR_SUMMARY), eippInvoiceVO);
		}catch(DataAccessException e){
			LOGGER.error(" Database exception occured in getInvoiceForPymtPreparation() method " + e.getMessage() ); 
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return invoiceList;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#getDefaultSupplrAcct(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	public List <NameValueVO> getDefaultSupplrAcct(EippInvoiceVO eippInvoiceVO)throws BNPApplicationException{
		List<NameValueVO> defltSuppAccList = null;
		try{
			defltSuppAccList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_DEFAULT_SUPP_ACCT), eippInvoiceVO);
		}catch(DataAccessException e){
			LOGGER.error(" Database exception occured in getDefaultSupplrAcct() method " + e.getMessage() ); 
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return defltSuppAccList;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#getSuplrAcctForTxnCcy(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	public List <NameValueVO> getSuplrAcctForTxnCcy(EippInvoiceVO eippInvoiceVO)throws BNPApplicationException{
		List<NameValueVO> suppAccList = null;
		try{
			suppAccList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_SUPLR_ACCT_FOR_TXN_CCY), eippInvoiceVO);
		}catch(DataAccessException e){
			LOGGER.error(" Database exception occured in getSuplrAcctForTxnCcy() method " + e.getMessage() ); 
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return suppAccList;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#getBuyerAcct(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	public List <NameValueVO> getBuyerAcct(EippInvoiceVO eippInvoiceVO)throws BNPApplicationException{
		List<NameValueVO> buyrAccList = null;
		try{
			buyrAccList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_BUYER_ACCT), eippInvoiceVO);
		}catch(DataAccessException e){
			LOGGER.error(" Database exception occured in getBuyerAcct() method " + e.getMessage() ); 
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return buyrAccList;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#getMktPlaceAcct(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	public List <NameValueVO> getMktPlaceAcct(EippInvoiceVO eippInvoiceVO)throws BNPApplicationException{
		List<NameValueVO> mktPlcAccList = null;
		try{
			mktPlcAccList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_MKT_PLACE_ACCT), eippInvoiceVO);
		}catch(DataAccessException e){
			LOGGER.error(" Database exception occured in getMktPlaceAcct() method " + e.getMessage() ); 
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return mktPlcAccList;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#getCNDetails(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	public EippPymtVO getCNDetails(EippPymtVO eippPymtVO)throws BNPApplicationException{
		List<EippCreditNoteVO> eippCNVOList = null;
		try{
			if( eippPymtVO.getInvoiceList() !=null ){
				EippInvoiceVO eippInvVO = eippPymtVO.getInvoiceList().get(0);
				
				if( eippInvVO !=null ){
					eippInvVO.setCcyCode(eippPymtVO.getCcyCode());
					eippCNVOList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_CN_DETAILS), eippInvVO);
					eippPymtVO.setCreditNoteList(eippCNVOList);
				}
			}
		}catch(DataAccessException e){
			LOGGER.error(" Database exception occured in getCNDetails() method " + e.getMessage() ); 
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return eippPymtVO;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#getLineItemDetails(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	public List<EippInvCntLineItemVO> getLineItemDetails(EippInvoiceVO eippInvVO)throws BNPApplicationException{
		List<EippInvCntLineItemVO> eippInvCntLineItemVO = null;
		try{
			eippInvCntLineItemVO = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_LINE_ITEM_DETAILS), eippInvVO);
		}catch(DataAccessException e){
			LOGGER.error(" Database exception occured in getLineItemDetails() method " + e.getMessage() ); 
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return eippInvCntLineItemVO;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#getPmtAdjustmentDetails(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	public List<PymtAdjustMentCodeVO> getPmtAdjustmentDetails(EippInvoiceVO eippInvVO)throws BNPApplicationException{
		List<PymtAdjustMentCodeVO> paymentAdjCodeList= null;
		
		try{
			paymentAdjCodeList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_PMT_ADJ_CODE_DETAILS), eippInvVO);
		}catch(DataAccessException e){
			LOGGER.error(" Database exception occured in getPmtAdjustmentDetails() method " + e.getMessage() ); 
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return paymentAdjCodeList;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#getRebateOrFee(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	public EippPymtVO getRebateOrFee(EippPymtVO eippPymtVO)throws BNPApplicationException{
		try {
			List<EippInvoiceVO> invoiceVOList = eippPymtVO.getInvoiceList();
			for( int i=0; i< invoiceVOList.size(); i++ ){
			
				EippInvoiceVO eippInvVO = invoiceVOList.get(i);
				Map<String,Object> params = new HashMap<String, Object>();
				params.put("invoiceDueDate", eippInvVO.getInvDueDate());
				params.put("supplrOrgId", eippInvVO.getSupplierOrgId());
				params.put("buyrOrgId", eippInvVO.getBuyerOrgId());
				params.put("billType", eippInvVO.getBillType());
				params.put("pmtMthdId", eippPymtVO.getSupplrPmtMethodId());
				params.put("ccyCode", eippInvVO.getCcyCode());
				params.put("pymtDateOpt", null);
				params.put("noDaysBdd", 0);
				params.put("paymentAmount", eippInvVO.getPmtAtInvoice());
				params.put("pymtPrepMode", ONLINE);
				params.put("invIssueDate", eippInvVO.getIssueDate());
				params.put("pmtValueDateInOut", eippInvVO.getPmtValueDate());				
				params.put("pmtInitDateInOut", eippPymtVO.getPymtInitDate());
				
				getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace( EIPP_PYMT_DATE_CALC), params);
				
				eippPymtVO.setPmtValueDate( (Date)params.get("pmtValueDateInOut") );
				eippPymtVO.setPymtInitDate(  (Date)params.get("pmtInitDateInOut") );
				eippInvVO.setLateFeeAmt( (BigDecimal)params.get("lateFeeAmt") );
				eippInvVO.setEarlyPymtRebate( (BigDecimal)params.get("earlyPmtRebate") );
				eippInvVO.setDiscRuleId((String)params.get("ruleId"));
				eippPymtVO.setEarlyPymtLatePymtRuleId((String)params.get("ruleId"));//3714
				eippInvVO.setPmtValueDate( (Date)params.get("pmtValueDateInOut") );
				eippInvVO.setTempInitDate( (Date)params.get("pmtInitDateInOut") );
				
				invoiceVOList.set(i, eippInvVO);
				
				// error code 
				String errorCode = (String)params.get("errorFlag");
				eippPymtVO.setErrorFlag(errorCode);
				
				/*if( errorCode!=null && !errorCode.trim().equals(BNPConstants.EMPTY) &&
						!(ErrorConstants.ALERT_INIT_DT_CUTOFF_TO_FUT+BNPConstants.EMPTY).equals(errorCode)){
					throw new BNPApplicationException(errorCode);
				}
				if( (ErrorConstants.ALERT_INIT_DT_CUTOFF_TO_FUT+BNPConstants.EMPTY).equals(errorCode ) ) {
					break;
				}*/
				if( !BNPConstants.QUICK_PAYMENT.equals(eippPymtVO.getPmtType()) && 
						errorCode!=null && !errorCode.trim().equals(BNPConstants.EMPTY) 
						&& !errorCode.equals(1001+"")
				){
					throw new BNPApplicationException(Integer.parseInt(errorCode));
				}
				
			}
			eippPymtVO.setInvoiceList(invoiceVOList);
		}catch(DataAccessException e){
			LOGGER.error(" Database exception occured in getRebateOrFee() method " + e.getMessage() ); 
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return eippPymtVO;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#getNextPmtInitDate(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	@Override
	public void getNextPmtInitDate(EippPymtVO eippPymtVO) throws BNPApplicationException {
		try {
			List<EippInvoiceVO> invoiceVOList = eippPymtVO.getInvoiceList();
			for( int i=0; i< invoiceVOList.size(); i++ ){
				EippInvoiceVO eippInvVO = invoiceVOList.get(i);
				String errorFlag = "";
				Map<String,Object> params = new HashMap<String, Object>();
				params.put("paymentCurrencyCode", eippInvVO.getCcyCode());
				params.put("supportBranchId", eippPymtVO.getBranchId());
				params.put("dueDate", eippPymtVO.getPymtInitDate());
				//added for R6.0 Organization Holiday enhancement
				params.put("orgId", eippPymtVO.getOrgId());
				getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace( GET_BUSINESS_DAY), params);
				Date businessDay = (Date) params.get("businessDay");
				errorFlag = (String) params.get("errorFlag");
				if(errorFlag.equals(BNPConstants.YES)){
					LOGGER.error("Error occured in executing the getNextPmtInitDate stored procedure in db");
					throw new DBException(ErrorConstants.ERROR_IN_GET_BUSINESS_DAY);
				}
				// This is temporarily set and wud be useful in case of Single Payment
				eippInvVO.setTempInitDate(businessDay);
				
				eippPymtVO.setPymtInitDate(businessDay);
			}
		} catch (DataAccessException e) {
			LOGGER.error("error in getNextPmtInitDate : "+ e.getMessage());
			throw new DBException(ErrorConstants.ERROR_IN_GET_BUSINESS_DAY);		
		}
	}
	
	@Override
	public void getNextPmtValueDate(EippPymtVO eippPymtVO) throws BNPApplicationException{
		try {
			List<EippInvoiceVO> invoiceVOList = eippPymtVO.getInvoiceList();
			for( int i=0; i< invoiceVOList.size(); i++ ){
				EippInvoiceVO eippInvVO = invoiceVOList.get(i);
				String errorFlag = "";
				Map<String,Object> params = new HashMap<String, Object>();
				params.put("paymentCurrencyCode", eippInvVO.getCcyCode());
				params.put("supportBranchId", eippPymtVO.getBranchId());
				params.put("dueDate", eippPymtVO.getPmtValueDate());
				params.put("orgId", eippPymtVO.getOrgId());
				getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace( GET_BUSINESS_DAY), params);
				Date businessDay = (Date) params.get("businessDay");
				errorFlag = (String) params.get("errorFlag");
				if(errorFlag.equals(BNPConstants.YES)){
					LOGGER.error("Error occured in executing the getNextPmtInitDate stored procedure in db");
					throw new DBException(ErrorConstants.ERROR_IN_GET_BUSINESS_DAY);
				}
				eippPymtVO.setPmtValueDate(businessDay);
				eippInvVO.setPmtValueDate(businessDay);
			}
		} catch (DataAccessException e) {
			LOGGER.error("error in getNextPmtInitDate : "+ e.getMessage());
			throw new DBException(ErrorConstants.ERROR_IN_GET_BUSINESS_DAY);		
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#getSupplierPmtMthd(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	public SupplierAccountVO getSupplierPmtMthd(EippInvoiceVO eippInvoiceVO)throws BNPApplicationException{
		SupplierAccountVO supplierAccountVO = null;
		
		try{
			supplierAccountVO = (SupplierAccountVO)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_SUPPLIER_PMT_METHOD), 

eippInvoiceVO);
		}catch(DataAccessException e){
			LOGGER.error(" Database exception occured in getSupplierPmtMthd() method " + e.getMessage() ); 
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return supplierAccountVO;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#getMktPlacePmtMthd(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	public List<MarketPlaceAccountVO> getMktPlacePmtMthd(EippInvoiceVO eippInvoiceVO)throws BNPApplicationException{
		List<MarketPlaceAccountVO> mktPlaceAcctList= null;
		try{
			mktPlaceAcctList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_MKT_PLACE_PMT_MTHD), eippInvoiceVO);
		}catch(DataAccessException e){
			LOGGER.error(" Database exception occured in getMktPlacePmtMthd() method " + e.getMessage() ); 
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return mktPlaceAcctList;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#getBuyerPmtMthd(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	public BuyerAccountVO getBuyerPmtMthd(EippInvoiceVO eippInvoiceVO)throws BNPApplicationException{
		BuyerAccountVO buyerAccountVO = null;
		try{
			buyerAccountVO = (BuyerAccountVO)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_BUYER_PMT_MTHD), 

eippInvoiceVO);			
		}catch(DataAccessException e){
			LOGGER.error(" Database exception occured in getBuyerPmtMthd() method " + e.getMessage() ); 
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return buyerAccountVO;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#getPymtProcForBuyer(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	public List<PaymentInitiateAccountVO> getPymtProcForBuyer(EippPymtVO eippPymtVO)throws BNPApplicationException{
		List<PaymentInitiateAccountVO> pymtInitAcctVOList = null;
		try{
			pymtInitAcctVOList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_PYMT_PROC_FOR_BUYER), eippPymtVO);	
		}catch(DataAccessException dataAccessException){
			LOGGER.error(" Database exception occured in getPymtProcForBuyer() method " + dataAccessException.getMessage() ); 
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return pymtInitAcctVOList;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#getPymtProcForSupplr(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	public List<PaymentInitiateAccountVO> getPymtProcForSupplr(EippPymtVO eippPymtVO)throws BNPApplicationException{
		List<PaymentInitiateAccountVO> pymtInitAcctVOList = null;
		try{
			pymtInitAcctVOList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_PYMT_PROC_FOR_SUPPLR), eippPymtVO);	
		}catch(DataAccessException dataAccessException){
			LOGGER.error(" Database exception occured in getPymtProcForSupplr() method " + dataAccessException.getMessage() ); 
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return pymtInitAcctVOList;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#getPymtProcForMktPlace(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	public List<PaymentInitiateAccountVO> getPymtProcForMktPlace(EippPymtVO eippPymtVO)throws BNPApplicationException{
		List<PaymentInitiateAccountVO> pymtInitAcctVOList = null;
		try{
			pymtInitAcctVOList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_PYMT_PROC_FOR_MKTPLACE), eippPymtVO);	
		}catch(DataAccessException dataAccessException){
			LOGGER.error(" Database exception occured in getPymtProcForMktPlace() method " + dataAccessException.getMessage() ); 
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return pymtInitAcctVOList;
	}
	
	/**
	 * This method is responsible to
	 * Buyer, Supplier & MarketPlace Map Id.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void generateMapId(EippPymtVO eippPymtVO)throws BNPApplicationException{
		if( !BNPConstants.SPLIT_BULK_PAYMENT.equals(eippPymtVO.getPmtType()) &&
			 !BNPConstants.SPLIT_SINGLE_PAYMENT.equals(eippPymtVO.getPmtType()) ){
			 eippPymtVO.setBuyerMapId((String)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_BUYER_MAP_ID)));
		 }
		 eippPymtVO.setSupplierMapId((String)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_SUPPLR_MAP_ID)));
		 
		 List<EippInvoiceVO> eippInvVOList = eippPymtVO.getInvoiceList();
		 if( eippInvVOList!=null && !eippInvVOList.isEmpty()){
			 
			EippInvoiceVO eippInvVO = eippInvVOList.get(0);
			if( BNPConstants.YES.equals( eippInvVO.getPayThruMktPlace()) ){
		 		eippPymtVO.setMktPlaceMapId((String)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_MPLACE_MAP_ID)));
			}
		 }
	}
	
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#savePymt(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	public void savePymt(EippPymtVO eippPymtVO)throws BNPApplicationException{
		try{  
			
			 eippPymtVO.setPmtRefNo(getPaymentRefNo(eippPymtVO));
			 
			/* if( !BNPConstants.SPLIT_BULK_PAYMENT.equals(eippPymtVO.getPmtType()) &&
				 !BNPConstants.SPLIT_SINGLE_PAYMENT.equals(eippPymtVO.getPmtType()) ){
				 eippPymtVO.setBuyerMapId((String)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_BUYER_MAP_ID)));
			 }
			 eippPymtVO.setSupplierMapId((String)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_SUPPLR_MAP_ID)));
			 eippPymtVO.setMktPlaceMapId((String)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_MPLACE_MAP_ID)));*/
			 
			generateMapId(eippPymtVO); 
			 
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_INTO_PYMT_MASTER_TABLE), eippPymtVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_INTO_PYMT_HIST_TABLE), eippPymtVO);
			
			saveInvPmtMap(eippPymtVO);
			
			saveCreditNotes(eippPymtVO);
			savePymtAdjustment(eippPymtVO);
			// If Split Single/Bulk Payment
			if(  BNPConstants.SPLIT_SINGLE_PAYMENT.equals(eippPymtVO.getPmtType()) || BNPConstants.SPLIT_BULK_PAYMENT.equals

(eippPymtVO.getPmtType())
				){
				List<SplitPaymentVO> splitPmtList = saveSplitPayment(eippPymtVO);
				savePymtProcInfo(eippPymtVO, splitPmtList);
			}else{
				savePymtProcInfo(eippPymtVO, null);
			}
			
			// update line item
			// if line item flag is checked
			// only line item table would be updated
			if ( eippPymtVO.isLnItmSelected() ){
				saveLineItem(eippPymtVO);
				updateLineItemDetails(eippPymtVO);
			}
			// update invoice
			updateInvoice(eippPymtVO);
			
			
		}catch(DataAccessException dataAccessException){
			LOGGER.error("Inserting details in a batch failed in savePymt() method " + dataAccessException.getMessage());
			throw new BNPApplicationException("Inserting details in a batch failed in savePymt() method ");
		}
	}
	
	/**
	 * This method inserts the Invoice Pymt Mapping Table.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void saveInvPmtMap(final EippPymtVO eippPymtVO)throws BNPApplicationException{
		LOGGER.debug("Enter saveInvPmtMap() method ");
		final List<EippInvoiceVO> invList = eippPymtVO.getInvoiceList();
		if( invList!=null && invList.size()>0){
				getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
				public List doInSqlMapClient(SqlMapExecutor executor)throws SQLException {
								List list = null;
								try {
									executor.startBatch();
									for (EippInvoiceVO eippInvVO : invList ) {
										eippInvVO.setPkId(eippPymtVO.getPkId());
										executor.insert(getQueryNameWithNameSpace(INSERT_INTO_INV_PYMT_MAPPING_TABLE), 
														eippInvVO);
									}
									list = executor.executeBatchDetailed();
								} catch (BatchException e) {
									LOGGER.error("Inserting details in a batch failed");
									throw new SQLException("Inserting details in a batch failed");
								}
								return list;
							}
						});
		}
	}
	
	/**
	 * Save credit notes.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void saveCreditNotes(final EippPymtVO eippPymtVO)throws BNPApplicationException{
		
		LOGGER.debug("Enter saveCreditNotes() method ");
		final List<EippCreditNoteVO> creditNoteList = eippPymtVO.getSaveCNList();
		if( creditNoteList!=null && creditNoteList.size()>0){
				getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
				public List doInSqlMapClient(SqlMapExecutor executor)throws SQLException {
								List list = null;
								try {
									executor.startBatch();
									for (EippCreditNoteVO eippCreditNoteVO : creditNoteList ) {
										if(eippCreditNoteVO.isDisableCheckBox()){
											eippCreditNoteVO.setPkId(eippPymtVO.getPkId());
											executor.insert(getQueryNameWithNameSpace(INSERT_INTO_CN_PYM_MAP_TABLE),	
													eippCreditNoteVO);
											executor.update(getQueryNameWithNameSpace(INSERT_INTO_CN_PYM_MAP_TABLE_HIST),	
													eippCreditNoteVO);
											executor.update(getQueryNameWithNameSpace(UPDATE_CREDIT_NOTE_TABLE), 	
													eippCreditNoteVO);
										}
									}
									list = executor.executeBatchDetailed();
									//executor.executeBatch();
								} catch (BatchException e) {
									LOGGER.error("Inserting details in a batch failed");
									throw new SQLException("Inserting details in a batch failed");
								}
								return list;
							}
						});
		}
		// update the credit note detail table
	/*	if( creditNoteList!=null && creditNoteList.size()>0){
			getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
			public List doInSqlMapClient(SqlMapExecutor executor)throws SQLException {
							List list = null;
							try {
								executor.startBatch();
								for (EippCreditNoteVO eippCreditNoteVO : creditNoteList ) {
									
									executor.update(getQueryNameWithNameSpace(UPDATE_CREDIT_NOTE_TABLE), 

eippCreditNoteVO);
								}
								list = executor.executeBatchDetailed();
								//executor.executeBatch();
							} catch (BatchException e) {
								LOGGER.error("Inserting details in a batch failed");
								throw new SQLException("Inserting details in a batch failed");
							}
							return list;
						}
					});
		} */
	}
	
	/**
	 * Save pymt adjustment.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void savePymtAdjustment(final EippPymtVO eippPymtVO)throws BNPApplicationException{
		LOGGER.debug("Enter savePymtAdjustment() method ");
		final List<PymtAdjustMentCodeVO> pmtAdjList = eippPymtVO.getPymtAdjustmentList();
		if( pmtAdjList!=null && pmtAdjList.size()>0){
				getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
				public List doInSqlMapClient(SqlMapExecutor executor)throws SQLException {
								List list = null;
								try {
									for (PymtAdjustMentCodeVO pmtAdjustMentCodeVO : pmtAdjList ) {
										executor.startBatch();
										pmtAdjustMentCodeVO.setPymtId(eippPymtVO.getPkId());
										executor.insert(getQueryNameWithNameSpace(INSERT_INTO_PYMT_ADJ_MAP_TABLE), 

pmtAdjustMentCodeVO);
										executor.insert(getQueryNameWithNameSpace

(INSERT_INTO_PYMT_ADJ_MAP_TABLE_HIST), pmtAdjustMentCodeVO);
										executor.executeBatchDetailed();						

			/*	
																	
			final List<PaymentAdjustMentCodeFieldsVO> pmtAdjFieldDataList = pmtAdjustMentCodeVO.getPmtAdjustMentCodeFieldsVOList();
			executor.startBatch();	
										
			if(pmtAdjFieldDataList!=null && !pmtAdjFieldDataList.isEmpty()){
										
			for (PaymentAdjustMentCodeFieldsVO pmtAdjCodeFieldsVO : pmtAdjFieldDataList ) 
			{
				pmtAdjCodeFieldsVO.setAdjId(pmtAdjustMentCodeVO.getAdjId());
				executor.insert(getQueryNameWithNameSpace(INSERT_INTO_PYMT_ADJ_PARAM_TABLE), pmtAdjCodeFieldsVO);
				executor.update(getQueryNameWithNameSpace(INSERT_INTO_PYMT_ADJ_PARAM_TABLE_HIST), pmtAdjCodeFieldsVO);
			}}
			list = executor.executeBatchDetailed(); */
	        //Added for ST TD:6936 Inserting Custom Fields
			final List<PymtAdjustmentCodeCustomVO>	pmtAdjFieldDataList=pmtAdjustMentCodeVO.getCustomTableDataList();
			executor.startBatch();
			if(pmtAdjFieldDataList!=null && !pmtAdjFieldDataList.isEmpty()){				
				for (PymtAdjustmentCodeCustomVO pmtAdjCodeFieldsVO : pmtAdjFieldDataList ) 
				{
					if( pmtAdjCodeFieldsVO != null){
					if(BNPConstants.FIELD_TEXT.equals(pmtAdjCodeFieldsVO.getFieldDesc())){
						pmtAdjCodeFieldsVO.setFieldValue(pmtAdjCodeFieldsVO.getTextFldValue());
					}
					else if(BNPConstants.FIELD_MEMO.equals(pmtAdjCodeFieldsVO.getFieldDesc())){
						pmtAdjCodeFieldsVO.setFieldValue(pmtAdjCodeFieldsVO.getMemoFldValue());						
					}
					else if(BNPConstants.FIELD_DATE.equals(pmtAdjCodeFieldsVO.getFieldDesc())){			
						if(null != pmtAdjCodeFieldsVO.getDateFldValue()){								
							pmtAdjCodeFieldsVO.setFieldValue(pmtAdjCodeFieldsVO.getDateFldValue().toString());
						}						
					}
						
					pmtAdjCodeFieldsVO.setPkId(pmtAdjustMentCodeVO.getAdjId());
					executor.insert(getQueryNameWithNameSpace(INSERT_INTO_PYMT_ADJ_PARAM_TABLE), pmtAdjCodeFieldsVO);
					executor.update(getQueryNameWithNameSpace(INSERT_INTO_PYMT_ADJ_PARAM_TABLE_HIST), pmtAdjCodeFieldsVO);
				}
			}
			}
			list = executor.executeBatchDetailed();
		}
									
									
									//executor.executeBatch();
								} catch (BatchException e) {
									LOGGER.error("Inserting details in a batch failed");
									throw new SQLException("Inserting details in a batch failed");
								}
								return list;
							}
						});
				
			/*	for (final PymtAdjustMentCodeVO pmtAdjustMentCodeVO : pmtAdjList ) {
					final List<PaymentAdjustMentCodeFieldsVO> pmtAdjFieldDataList = pmtAdjustMentCodeVO.getPmtAdjustMentCodeFieldsVOList

();
					if( pmtAdjFieldDataList!=null && pmtAdjFieldDataList.size()>0){
						getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
						public List doInSqlMapClient(SqlMapExecutor executor)throws SQLException {
										List list = null;
										try {
											executor.startBatch();
											for (PaymentAdjustMentCodeFieldsVO pmtAdjCodeFieldsVO : 

pmtAdjFieldDataList ) {
												pmtAdjCodeFieldsVO.setAdjId(pmtAdjustMentCodeVO.getAdjId());
												executor.insert(getQueryNameWithNameSpace

(INSERT_INTO_PYMT_ADJ_PARAM_TABLE), pmtAdjCodeFieldsVO);
												executor.update(getQueryNameWithNameSpace

(INSERT_INTO_PYMT_ADJ_PARAM_TABLE_HIST), pmtAdjCodeFieldsVO);
											}
											list = executor.executeBatchDetailed();
											//executor.executeBatch();
										} catch (BatchException e) {
											LOGGER.error("Inserting details in a batch failed");
											throw new SQLException("Inserting details in a batch failed");
										}
										return list;
									}
								});
					}
				}*/
		}
	}
	
	/**
	 * Save split payment.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @return the list
	 * @throws BNPApplicationException the bNP application exception
	 */
	private List<SplitPaymentVO> saveSplitPayment(final EippPymtVO eippPymtVO)throws BNPApplicationException{
		LOGGER.debug("Enter saveSplitPayment() method ");
		
		final List<SplitPaymentVO> splitPmtList = eippPymtVO.getSplitPymtList();
		if( splitPmtList!=null && splitPmtList.size()>0){
				getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
				public List doInSqlMapClient(SqlMapExecutor executor)throws SQLException {
								List<SplitPaymentVO> list = null;
								try {
									executor.startBatch();
									for (SplitPaymentVO splitPaymentVO : splitPmtList ) {
										splitPaymentVO.setPymtId(eippPymtVO.getPkId());			
										
										if( BNPConstants.SPLIT_BULK_PAYMENT.equals(eippPymtVO.getPmtType()) ||
												BNPConstants.SPLIT_SINGLE_PAYMENT.equals

(eippPymtVO.getPmtType())
											){
											splitPaymentVO.setBuyerMapId((String)getSqlMapClientTemplate

().queryForObject(getQueryNameWithNameSpace(GET_BUYER_MAP_ID)));
										}
//										splitPaymentVO.setDeductAmt(new BigDecimal(0));
										executor.insert(getQueryNameWithNameSpace(INSERT_INTO_SPLIT_PYMT_TABLE), 

splitPaymentVO);
										executor.update(getQueryNameWithNameSpace(INSERT_INTO_SPLIT_PYMT_TABLE_HIST), 

splitPaymentVO);
									}
									list = executor.executeBatchDetailed();
									//executor.executeBatch();
								} catch (BatchException e) {
									LOGGER.error("Inserting details in a batch failed");
									throw new SQLException("Inserting details in a batch failed");
								}
								return list;
							}
						});
		}
		return splitPmtList;
	}
	
	/**
	 * Save pymt proc info.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @param splitPmtList the split pmt list
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void savePymtProcInfo(final EippPymtVO eippPymtVO, final List<SplitPaymentVO> splitPmtList)throws BNPApplicationException{
		LOGGER.debug("Enter savePymtProcInfo() method ");

		// if Split Payment Buyer Id has to be obtained from Split Pymt Id
		if(  BNPConstants.SPLIT_SINGLE_PAYMENT.equals(eippPymtVO.getPmtType()) 
				||
				BNPConstants.SPLIT_BULK_PAYMENT.equals(eippPymtVO.getPmtType()))
		{

			// for Buyer - if split payment
			final List<PaymentInitiateAccountVO> pymtProcForBuyerList = eippPymtVO.getPymtProcForBuyerList();
			if( pymtProcForBuyerList!=null && pymtProcForBuyerList.size()>0){
				getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
					public List doInSqlMapClient(SqlMapExecutor executor)throws SQLException {
						List list = null;
						try {
							executor.startBatch();
							for( int i=0; i< splitPmtList.size(); i++ ){

								SplitPaymentVO splitPaymentVO = splitPmtList.get(i);
								for (int j = 0; j<pymtProcForBuyerList.size(); j++  ) {
									PaymentInitiateAccountVO paymentInitiateAccountVO = 

										pymtProcForBuyerList.get(j);

									if( splitPaymentVO.getBuyerAcctIdentifier().equals

											(paymentInitiateAccountVO.getAccountIden()) ){
										paymentInitiateAccountVO.setPaymentId

										(eippPymtVO.getPkId());
										paymentInitiateAccountVO.setMapId

										(splitPaymentVO.getBuyerMapId());
										paymentInitiateAccountVO.setBuyerOrgId

										(eippPymtVO.getBuyerOrgId());
										paymentInitiateAccountVO.setAccountIden

										(splitPaymentVO.getBuyerAcctIdentifier());
										paymentInitiateAccountVO.setAcctCcy

										(eippPymtVO.getCcyCode());
										executor.insert(getQueryNameWithNameSpace

												(INSERT_INTO_PYMT_ACC_DET_MAP), paymentInitiateAccountVO);
									}
								}
							}
							list = executor.executeBatchDetailed();
							executor.executeBatch();
						} catch (BatchException e) {
							LOGGER.error("Inserting details in a batch failed");
							throw new SQLException("Inserting details in a batch failed");
						}
						return list;
					}
				});
			}

		}else{

			// for Buyer - if Not a Split Payment
			final List<PaymentInitiateAccountVO> pymtProcForBuyerList = eippPymtVO.getPymtProcForBuyerList();
			if( pymtProcForBuyerList!=null && pymtProcForBuyerList.size()>0){
				getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
					public List doInSqlMapClient(SqlMapExecutor executor)throws SQLException {
						List list = null;
						try {
							executor.startBatch();
							for (PaymentInitiateAccountVO paymentInitiateAccountVO : pymtProcForBuyerList 

							) {
								paymentInitiateAccountVO.setPaymentId(eippPymtVO.getPkId());
								paymentInitiateAccountVO.setMapId(eippPymtVO.getBuyerMapId());
								paymentInitiateAccountVO.setBuyerOrgId(eippPymtVO.getBuyerOrgId());
								paymentInitiateAccountVO.setAccountIden

								(eippPymtVO.getBuyerAcctIdentifier());
								paymentInitiateAccountVO.setAcctCcy(eippPymtVO.getCcyCode());
								executor.insert(getQueryNameWithNameSpace

										(INSERT_INTO_PYMT_ACC_DET_MAP), paymentInitiateAccountVO);
							}
							list = executor.executeBatchDetailed();
							executor.executeBatch();
						} catch (BatchException e) {
							LOGGER.error("Inserting details in a batch failed");
							throw new SQLException("Inserting details in a batch failed");
						}
						return list;
					}
				});
			}
		}

		// for Supplier
		final List<PaymentInitiateAccountVO> pymtProcForSupplierList = eippPymtVO.getPymtProcForSupplierList();
		if( pymtProcForSupplierList!=null && pymtProcForSupplierList.size()>0){
			getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
				public List doInSqlMapClient(SqlMapExecutor executor)throws SQLException {
					List list = null;
					try {
						executor.startBatch();
						for (PaymentInitiateAccountVO paymentInitiateAccountVO : pymtProcForSupplierList ) {
							paymentInitiateAccountVO.setPaymentId(eippPymtVO.getPkId());
							paymentInitiateAccountVO.setMapId(eippPymtVO.getSupplierMapId());
							paymentInitiateAccountVO.setSupplierOrgId(eippPymtVO.getSupplierOrgId());
							paymentInitiateAccountVO.setAccountIden(eippPymtVO.getSupplierAcctIdentifier

									());
							paymentInitiateAccountVO.setAcctCcy(eippPymtVO.getCcyCode());
							executor.insert(getQueryNameWithNameSpace(INSERT_INTO_PYMT_ACC_DET_MAP), 

									paymentInitiateAccountVO);
						}
						list = executor.executeBatchDetailed();
						executor.executeBatch();
					} catch (BatchException e) {
						LOGGER.error("Inserting details in a batch failed");
						throw new SQLException("Inserting details in a batch failed");
					}
					return list;
				}
			});
		}

		// for MarketPlace
		final List<PaymentInitiateAccountVO> pymtProcForMPlaceList = eippPymtVO.getPymtProcForMPlaceList();
		if( pymtProcForMPlaceList!=null && pymtProcForMPlaceList.size()>0){
			getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
				public List doInSqlMapClient(SqlMapExecutor executor)throws SQLException {
					List list = null;
					try {
						executor.startBatch();
						for (PaymentInitiateAccountVO paymentInitiateAccountVO : pymtProcForMPlaceList ) {
							paymentInitiateAccountVO.setPaymentId(eippPymtVO.getPkId());
							paymentInitiateAccountVO.setMapId(eippPymtVO.getMktPlaceMapId());
							paymentInitiateAccountVO.setMarketPlaceOrgId(eippPymtVO.getMarketPlaceOrgId

									());
							paymentInitiateAccountVO.setAccountIden(eippPymtVO.getMktPlaceAcctIdentifier

									());
							paymentInitiateAccountVO.setAcctCcy(eippPymtVO.getCcyCode());
							executor.insert(getQueryNameWithNameSpace(INSERT_INTO_PYMT_ACC_DET_MAP), 

									paymentInitiateAccountVO);										
						}
						list = executor.executeBatchDetailed();
						executor.executeBatch();
					} catch (BatchException e) {
						LOGGER.error("Inserting details in a batch failed");
						throw new SQLException("Inserting details in a batch failed");
					}
					return list;
				}
			});
		}
	}
	
	/**
	 * Save line item.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void saveLineItem(final EippPymtVO eippPymtVO)throws BNPApplicationException{
		final List<EippInvCntLineItemVO> lnItmList = new ArrayList<EippInvCntLineItemVO>();
		
		List<EippInvoiceVO> eippInvoiceVOList = eippPymtVO.getInvoiceList();
		for( int i=0; i<eippInvoiceVOList.size(); i++ ){
			
			EippInvoiceVO eippInvVO = eippInvoiceVOList.get(i);
			/*if(eippPymtVO.isLnItmSelected()){
				 eippInvVO.setLnItmSelected(true);
				 eippInvVO.setLineItemList(eippPymtVO.getLineItemList());
			}*/
			if( eippInvVO.isLnItmSelected() ){
				lnItmList.addAll(eippInvVO.getLineItemList());
			}
		}
		
		if( lnItmList!=null && lnItmList.size()>0){
			getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
			public List doInSqlMapClient(SqlMapExecutor executor)throws SQLException {
							List list = null;
							try {
								executor.startBatch();
								for (EippInvCntLineItemVO eippInvCntLineItemVO : lnItmList ) {
									if(eippInvCntLineItemVO.isDisableCheckBox()){
										eippInvCntLineItemVO.setPymtId(eippPymtVO.getPkId());
										executor.insert(getQueryNameWithNameSpace(INSERT_INTO_LINE_ITM_PYM_MAP_TABLE), eippInvCntLineItemVO);
										executor.update(getQueryNameWithNameSpace(INSERT_INTO_LINE_ITM_PYM_MAP_TABLE_HIST), eippInvCntLineItemVO);
										
										
										// audit Logger Entry in Line Item Audit Table									
										EippAuditVO auditVO = setLineItemAuditEntry(eippPymtVO, eippInvCntLineItemVO);									
										executor.insert(getQueryNameWithNameSpace(INSERT_INTO_LINE_ITM_AUDIT_TABLE), auditVO);
									}
									
								}
								list = executor.executeBatchDetailed();
								executor.executeBatch();
							} catch (BatchException e) {
								LOGGER.error("Inserting details in a batch failed");
								throw new SQLException("Inserting details in a batch failed");
							}
							return list;
						}
					});
		}
	}
	
	/**
	 * Gets the audit action.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @return the audit action
	 */
	private String getAuditAction(EippPymtVO eippPymtVO){
		
		if( BNPConstants.SINGLE_PAYEMNT.equals(eippPymtVO.getPmtType() ) ){
			return BNPConstants.SINGLE_PAYEMNT_ACTION;
		}else if( BNPConstants.QUICK_PAYMENT.equals(eippPymtVO.getPmtType() ) ){
			return BNPConstants.QUICK_PAYMENT_ACTION;
		}else if( BNPConstants.SPLIT_BULK_PAYMENT.equals(eippPymtVO.getPmtType() ) ){
			return BNPConstants.SPLIT_BULK_PAYMENT_ACTION;
		}else if( BNPConstants.SPLIT_SINGLE_PAYMENT.equals(eippPymtVO.getPmtType() ) ){
			return BNPConstants.SPLIT_SINGLE_PAYMENT_ACTION;
		}else if( BNPConstants.BULK_PAYMENT.equals(eippPymtVO.getPmtType() ) ){
			return BNPConstants.BULK_PAYMENT_ACTION;
		}
		return null;
	}
	
	
	/**
	 * Update line item details.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void updateLineItemDetails(EippPymtVO eippPymtVO)throws BNPApplicationException{
		try{
			
			final List<EippInvCntLineItemVO> lnItmList = new ArrayList<EippInvCntLineItemVO>();
			
			List<EippInvoiceVO> eippInvoiceVOList = eippPymtVO.getInvoiceList();
			for( int i=0; i<eippInvoiceVOList.size(); i++ ){
				
				EippInvoiceVO eippInvVO = eippInvoiceVOList.get(i);
				
				if( eippInvVO.isLnItmSelected() ){
					lnItmList.addAll(eippInvVO.getLineItemList());
				}
			}
			if( lnItmList!=null && lnItmList.size()>0){
				getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
				public List doInSqlMapClient(SqlMapExecutor executor)throws SQLException {
								List list = null;
								try {
									executor.startBatch();
									for (EippInvCntLineItemVO lnItmVO : lnItmList ) {
										// only if the line item is selected it'll be updated
										if( lnItmVO.isDisableCheckBox() ) {	
											executor.update(getQueryNameWithNameSpace(UPDATE_LINE_ITEM_DETAILS),lnItmVO);
										}
									}
									list = executor.executeBatchDetailed();
									executor.executeBatch();
								} catch (BatchException e) {
									LOGGER.error("Inserting details in a batch failed");
									throw new SQLException("Inserting details in a batch failed");
								}
								return list;
							}
						});
			}
		}catch(DataAccessException dataAccessException){
			LOGGER.error("Error in updating Line Item Details" + dataAccessException.getMessage());
			throw new BNPApplicationException("Error in updating Line Item Details");
		}
	}
	
	/**
	 * Update invoice.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void updateInvoice(final EippPymtVO eippPymtVO)throws BNPApplicationException{
		final List<EippInvoiceVO> eippInvoiceVOList = eippPymtVO.getInvoiceList();
		if( eippInvoiceVOList!=null && eippInvoiceVOList.size()>0){
			getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
			public List doInSqlMapClient(SqlMapExecutor executor)throws SQLException {
							List list = null;
							try {
								executor.startBatch();
								for (EippInvoiceVO eippInvoiceVO : eippInvoiceVOList ) {
									executor.update(getQueryNameWithNameSpace(UPDATE_INVOICE), eippInvoiceVO);
									
									// audit Logger Entry in Invoice Audit Table
									EippAuditVO auditVO = setInvoiceAuditEntry(eippPymtVO, eippInvoiceVO);									
									executor.insert(getQueryNameWithNameSpace(INSERT_INVOICE_AUDIT), auditVO);
								}
								list = executor.executeBatchDetailed();
							} catch (BatchException e) {
								LOGGER.error("Inserting details in a batch failed");
								throw new SQLException("Inserting details in a batch failed");
							}
							return list;
						}
					});
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#updateBlockAmtInInvoice(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public void updateBlockAmtInInvoice(EippInvoiceVO eippInvoiceVO)
			throws BNPApplicationException {
		try{
			if(eippInvoiceVO != null){
				getSqlMapClientTemplate().update(getQueryNameWithNameSpace(
										UPDATE_INVOICE), eippInvoiceVO);
			}
		}catch (DataAccessException e) {
			LOGGER.error("error in pymtpreparationdaoimpl updateBlockAmtInInvoice : ", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.dao.SqlMapClientWrapper#updateTxnTimestamp(java.lang.Object)
	 */
	public int updateTxnTimestamp(Object txnObject)throws BNPApplicationException{
		EippPymtVO eippPymtVO = null;
		int count = 0;
		if ( txnObject!=null &&  txnObject instanceof EippPymtVO ){
			eippPymtVO = (EippPymtVO)txnObject;
		}
		
		if(eippPymtVO != null && (eippPymtVO.getInvoiceList() != null &&
				!eippPymtVO.getInvoiceList().isEmpty())){
			List<EippInvoiceVO> eippInvoiceVOList = eippPymtVO.getInvoiceList();
			
			try{
				for( EippInvoiceVO eippInvoiceVO: eippInvoiceVOList ){
				
					count = getSqlMapClientTemplate().update(getQueryNameWithNameSpace(
							UPDATE_TXN_TIMESTAMP), eippInvoiceVO);
					if ( count == 0){
						throw new BNPApplicationException(ErrorConstants.CONCURRENT_ACCESS);
					}
				}
			} catch (DataAccessException e) {
				LOGGER.error("error in updateTxnTimestamp : "+ e.getMessage());
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
		}
		return count;
	}
	
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.dao.SqlMapClientWrapper#updateTxnTimestamp(java.lang.Object)
	 */
	public int revertTxnTimestamp(EippPymtVO eippPymtVO)throws BNPApplicationException{
		
		List<EippInvoiceVO> eippInvoiceVOList = eippPymtVO.getInvoiceList();
		int count = 0;
		try{
			for( EippInvoiceVO eippInvoiceVO: eippInvoiceVOList ){
				count = getSqlMapClientTemplate().update(getQueryNameWithNameSpace(REVERT_TXN_TIMESTAMP), eippInvoiceVO);
			}
		} catch (DataAccessException e) {
			LOGGER.error("error in updateTxnTimestamp : "+ e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		return count;
	}
	
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.dao.SqlMapClientWrapper#resetProcessingFlag(java.lang.Object)
	 */
	public void resetProcessingFlag(Object txnObj) throws BNPApplicationException{
		
		final EippPymtVO eippPymtVO = (EippPymtVO)txnObj;
		final List<EippInvoiceVO> eippInvoiceVOList = eippPymtVO.getInvoiceList();
		if( eippInvoiceVOList!=null && eippInvoiceVOList.size()>0){
			getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
			public List doInSqlMapClient(SqlMapExecutor executor)throws SQLException {
							List list = null;
							try {
								executor.startBatch();
								for (EippInvoiceVO eippInvoiceVO : eippInvoiceVOList ) {
									executor.update(getQueryNameWithNameSpace(RESET_PROCESSING_FLAG), eippInvoiceVO);	

									
								}
								list = executor.executeBatchDetailed();
							} catch (BatchException e) {
								LOGGER.error("resetProcessingFlag in a batch failed");
								throw new SQLException("Error in resetProcessingFlag");
							}
							return list;
						}
					});
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#getBuyerOrgList(com.bnp.scm.services.common.vo.NameValueVO)
	 */
	@Override
	public List<NameValueVO> getBuyerOrgList(NameValueVO input) throws BNPApplicationException {
		List<NameValueVO> result= null;
		try{
			result = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_BUYER_ORG), input);
		}catch(DataAccessException e){
			LOGGER.error("Exception in getBuyerOrgList() ",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return result;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#getSupplierOrgList(com.bnp.scm.services.common.vo.NameValueVO)
	 */
	@Override
	public List<NameValueVO> getSupplierOrgList(NameValueVO input) throws BNPApplicationException {
		List<NameValueVO> result= null;
		try{
			result = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_SUPPLIER_ORG), input);
		}catch(DataAccessException e){
			LOGGER.error("Exception in getSupplierOrgList() ",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return result;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#getMplaceOrgList(com.bnp.scm.services.common.vo.NameValueVO)
	 */
	@Override
	public List<NameValueVO> getMplaceOrgList(NameValueVO input) throws BNPApplicationException{
		List<NameValueVO> result= null;
		try{
			result = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_MPLACE_ORG), input);
		}catch(DataAccessException e){
			LOGGER.error("Exception in getMplaceOrgList() ",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return result;
	}
	

	/**
	 * This method persist the payment record in Payment Table with Remarks
	 * when the payment is failed.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	public void savePymtOnError(EippPymtVO eippPymtVO)throws BNPApplicationException{
		try{  
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_INTO_PYMT_MASTER_TABLE), eippPymtVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_INTO_PYMT_HIST_TABLE), eippPymtVO);
		}catch(DataAccessException e){
			LOGGER.error("Exception in savePymtOnError() method ",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPreparationDAO#getPaymentID()
	 */
	@Override
	public long getPaymentID() throws BNPApplicationException {
		long pymtId = 0;
		try{
			pymtId = (Long) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_PYMT_ID));
		}catch(DataAccessException e){
			LOGGER.error("in PymtPreparationDAOImpl getPaymentID - exception :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return pymtId;
	}
	
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPreparationDAO#getPaymentRefNo(EippPymtVO pymtPrepVO)
	 */
	@Override
	public String getPaymentRefNo(EippPymtVO pymtPrepVO) throws BNPApplicationException {
		String pymtRefNo = null;
		try{
			pymtRefNo = (String) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_PMT_REF_NO),
					pymtPrepVO);
		}catch(DataAccessException e){
			LOGGER.error("in PymtPreparationDAOImpl getPaymentRefNo - exception :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return pymtRefNo;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPreparationDAO#insertPymtDetailsInoTrans(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public void insertPymtDetailsInoTrans(EippPymtVO pymtPrepVO)
			throws BNPApplicationException {
		try{
			//976332 CSCDEV-2683 19-NOV-2014:START
			//LOGGER.debug("In PymtPreparationDAOImpl insertPymtDetailsInoTrans :" + pymtPrepVO);
			//976332 CSCDEV-2683 19-NOV-2014:END
			if(pymtPrepVO != null){
				pymtPrepVO.setPymtRefNo(getPaymentRefNo(pymtPrepVO));
				
				pymtPrepVO.setBuyerMapId((String)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_BUYER_MAP_ID)));
				pymtPrepVO.setSupplierMapId((String)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_SUPPLR_MAP_ID)));
				pymtPrepVO.setMktPlaceMapId((String)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_MPLACE_MAP_ID)));
				
				getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(
						INSERT_PYMT_DTL_TRANS), pymtPrepVO);
				LOGGER.debug("Insert into the child tables");
				//Insert invoice details
				insertPymtInvDetailTrans(pymtPrepVO.getInvoiceList(), INSERT_INV_DTL_TRANS);

				//Insert invoice line item details
				insertInvLineItemTrans(pymtPrepVO.getLineItemList(), INSERT_LINE_ITEM_DTL_TRANS);
				
				//Insert payment level credit note details
				insertPymtCredNoteTrans(pymtPrepVO.getCreditNoteList(), INSERT_CN_DTL_TRANS);
				
				//Insert payment adjustment details
				insertPymtAdjDetailTrans(pymtPrepVO.getPymtAdjustmentList(), INSERT_PYMT_ADJ_DTL_TRANS);
				
				//Insert split payment details
				insertSplitPymtTrans(pymtPrepVO.getSplitPymtList(), INSERT_SPLIT_PYMT_DTL_TRANS);
				
				//Insert custom fields details
				insertCustFieldsTrans(pymtPrepVO, INSERT_CUST_FLD_DTL_TRANS);
			}
		}catch(Exception e){
			LOGGER.error("In PymtPreparationDAOImpl insertPymtDetailsInoTrans - Exception :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPreparationDAO#insertPymtDetailsIntoHist(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public void insertPymtDetailsIntoHist(EippPymtVO pymtPrepVO)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(
					INSERT_PYMT_DTL_HIST), pymtPrepVO);
		} catch (DataAccessException e) {
			LOGGER.error("In PymtPreparationDAOImpl insertPymtDetailsIntoHist - Exception :::::  ", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPreparationDAO#insertPymtDetails(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public void insertPymtDetails(EippPymtVO pymtPrepVO)
			throws BNPApplicationException {
		// TODO Auto-generated method stub
	}

	/**
	 * Insert pymt inv detail trans.
	 *
	 * @param invoiceList the invoice list
	 * @param queryName the query name
	 * @throws BNPApplicationException the bNP application exception
	 */
	@SuppressWarnings("rawtypes")
	private void insertPymtInvDetailTrans(final List<EippInvoiceVO> invoiceList, 
			final String queryName) throws BNPApplicationException{
		try{
			if(invoiceList != null && !invoiceList.isEmpty()){
				getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
					@Override
					public List doInSqlMapClient(SqlMapExecutor executor)
							throws SQLException {
						List list = null;
						try {
							executor.startBatch();
							for(EippInvoiceVO invoiceVO : invoiceList){
								
								executor.insert(getQueryNameWithNameSpace(
										queryName), invoiceVO);
							}
							list = executor.executeBatchDetailed();
//							if (list != null) {
//								LOGGER.debug("Batch Result Size" + list.size());
//							}
						} catch (BatchException e) {
							LOGGER.error("Excecuting batch update in PymtPreparationDAOImpl " +
									"insertPymtInvDetailTrans Failed ", e);
							throw new SQLException(e.getMessage(), e);
						}
						return list;
					}
				});
			}
		}catch(Exception e){
			LOGGER.error("In PymtPreparationDAOImpl insertPymtInvDetailTrans - Exception :", e);
			throw new BNPApplicationException(e.getMessage(),e);
		}
	}

	/**
	 * Insert inv line item trans.
	 *
	 * @param invLineItemList the inv line item list
	 * @param queryName the query name
	 * @throws BNPApplicationException the bNP application exception
	 */
	@SuppressWarnings("rawtypes")
	private void insertInvLineItemTrans(final List<EippInvCntLineItemVO> invLineItemList, 
			final String queryName) throws BNPApplicationException{
		try{
			if(invLineItemList != null && !invLineItemList.isEmpty()){
				getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
					@Override
					public List doInSqlMapClient(SqlMapExecutor executor)
							throws SQLException {
						List list = null;
						try {
							executor.startBatch();
							for(EippInvCntLineItemVO lineItemVO : invLineItemList){
								executor.insert(getQueryNameWithNameSpace(
										queryName), lineItemVO);
							}
							list = executor.executeBatchDetailed();
//							if (list != null) {
//								LOGGER.debug("Batch Result Size" + list.size());
//							}
						} catch (BatchException e) {
							LOGGER.error("Excecuting batch update in PymtPreparationDAOImpl " +
									"insertInvLineItemTrans Failed ", e);
							throw new SQLException(e.getMessage(), e);
						}
						return list;
					}
				});
			}
		}catch(Exception e){
			LOGGER.error("In PymtPreparationDAOImpl insertInvLineItemTrans - Exception :", e);
			throw new BNPApplicationException(e.getMessage(),e);
		}
	}
	
	/**
	 * Insert pymt cred note trans.
	 *
	 * @param credNoteList the cred note list
	 * @param queryName the query name
	 * @throws BNPApplicationException the bNP application exception
	 */
	@SuppressWarnings("rawtypes")
	private void insertPymtCredNoteTrans(final List<EippCreditNoteVO> credNoteList, 
			final String queryName) throws BNPApplicationException{
		try{
			if(credNoteList != null && !credNoteList.isEmpty()){
				getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
					@Override
					public List doInSqlMapClient(SqlMapExecutor executor)
							throws SQLException {
						List list = null;
						try {
							executor.startBatch();
							for(EippCreditNoteVO credNoteVO : credNoteList){
								executor.insert(getQueryNameWithNameSpace(
										queryName), credNoteVO);
							}
							list = executor.executeBatchDetailed();
//							if (list != null) {
//								LOGGER.debug("Batch Result Size" + list.size());
//							}
						} catch (BatchException e) {
							LOGGER.error("Excecuting batch update in PymtPreparationDAOImpl " +
									"insertPymtCredNoteTrans Failed ", e);
							throw new SQLException(e.getMessage(), e);
						}
						return list;
					}
				});
			}
		}catch(Exception e){
			LOGGER.error("In PymtPreparationDAOImpl insertPymtCredNoteTrans - Exception :", e);
			throw new BNPApplicationException(e.getMessage(),e);
		}		
	}

	/**
	 * Insert pymt adj detail trans.
	 *
	 * @param pymtAdjList the pymt adj list
	 * @param queryName the query name
	 * @throws BNPApplicationException the bNP application exception
	 */
	@SuppressWarnings("rawtypes")
	private void insertPymtAdjDetailTrans(final List<PymtAdjustMentCodeVO> pymtAdjList, 
			final String queryName) throws BNPApplicationException{
		try{
			if(pymtAdjList != null && !pymtAdjList.isEmpty()){
				getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
					@Override
					public List doInSqlMapClient(SqlMapExecutor executor)
							throws SQLException {
						List list = null;
						try {
							executor.startBatch();
							for(PymtAdjustMentCodeVO pymtAdjVO : pymtAdjList){
								executor.insert(getQueryNameWithNameSpace(
										queryName), pymtAdjVO);
							}
							list = executor.executeBatchDetailed();
							// R7.0 Fortify issues
//							if (list != null) {
//								LOGGER.debug("Batch Result Size" + list.size());
//							}
						} catch (BatchException e) {
							LOGGER.error("Excecuting batch update in PymtPreparationDAOImpl " +
									"insertPymtAdjDetailTrans Failed ", e);
							throw new SQLException(e.getMessage(), e);
						}
						return list;
					}
				});
			}
		}catch(Exception e){
			LOGGER.error("In PymtPreparationDAOImpl insertPymtAdjDetailTrans - Exception :", e);
			throw new BNPApplicationException(e.getMessage(),e);
		}		
	}
	
	/**
	 * Insert split pymt trans.
	 *
	 * @param splitPymtList the split pymt list
	 * @param queryName the query name
	 * @throws BNPApplicationException the bNP application exception
	 */
	@SuppressWarnings("rawtypes")
	private void insertSplitPymtTrans(final List<SplitPaymentVO> splitPymtList, 
			final String queryName) throws BNPApplicationException{
		try{
			if(splitPymtList != null && !splitPymtList.isEmpty()){
				getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
					@Override
					public List doInSqlMapClient(SqlMapExecutor executor)
							throws SQLException {
						List list = null;
						try {
							executor.startBatch();
							for(SplitPaymentVO splitPymtVO : splitPymtList){
								splitPymtVO.setBuyerMapId((String)getSqlMapClientTemplate().queryForObject

(getQueryNameWithNameSpace(GET_BUYER_MAP_ID)));								
								executor.insert(getQueryNameWithNameSpace(
										queryName), splitPymtVO);
							}
							list = executor.executeBatchDetailed();
							// R7.0 Fortify issues
//							if (list != null) {
//								LOGGER.debug("Batch Result Size" + list.size());
//							}
						} catch (BatchException e) {
							LOGGER.error("Excecuting batch update in PymtPreparationDAOImpl " +
									"insertSplitPymtTrans Failed ", e);
							throw new SQLException(e.getMessage(), e);
						}
						return list;
					}
				});
			}
		}catch(Exception e){
			LOGGER.error("In PymtPreparationDAOImpl insertSplitPymtTrans - Exception :", e);
			throw new BNPApplicationException(e.getMessage(),e);
		}		
	}
	
	/**
	 * Insert cust fields trans.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @param queryName the query name
	 * @throws BNPApplicationException the bNP application exception
	 */
	@SuppressWarnings("rawtypes")
	private void insertCustFieldsTrans(EippPymtVO eippPymtVO, final String queryName) throws BNPApplicationException{
		try{
			final List<EippCustFieldsVO> finCustFldsList = eippPymtVO.getCusFldsList();
			final EippPymtVO pymtVO = eippPymtVO;
			if(finCustFldsList != null && !finCustFldsList.isEmpty()){
				getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
					@Override
					public List doInSqlMapClient(SqlMapExecutor executor)
							throws SQLException {
						List list = null;
						try {
							executor.startBatch();
							for(EippCustFieldsVO custFldVO : finCustFldsList){
								custFldVO.setStatusCode(pymtVO.getCustPymtStatus());
								executor.insert(getQueryNameWithNameSpace(
										queryName), custFldVO);
							}
							list = executor.executeBatchDetailed();
							// R7.0 Fortify issues
//							if (list != null) {
//								LOGGER.debug("Batch Result Size" + list.size());
//							}
						} catch (BatchException e) {
							LOGGER.error("Excecuting batch update in PymtPreparationDAOImpl " +
									"insertCustFieldsTrans Failed ", e);
							throw new SQLException(e.getMessage(), e);
						}
						return list;
					}
				});
			}
		}catch(Exception e){
			LOGGER.error("In PymtPreparationDAOImpl insertCustFieldsTrans - Exception :", e);
			throw new BNPApplicationException(e.getMessage(),e);
		}		
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPreparationDAO#getRebateOrFee(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public EippPymtVO getRebateOrFeeMFU(EippPymtVO eippPymtVO)throws BNPApplicationException{
		LOGGER.debug("In PymtPreparationDAOImpl getRebateOrFeeMFU - Starts");
		try {
			List<EippInvoiceVO> invoiceVOList = eippPymtVO.getInvoiceList();
			Map<String,Object> params = new HashMap<String, Object>();
			EippInvoiceVO eippInvVO = null;
			eippPymtVO.setLateFeeAmount(BigDecimal.ZERO);
			eippPymtVO.setDiscountAmount(BigDecimal.ZERO);
			
			if(invoiceVOList != null && !invoiceVOList.isEmpty()){
				eippInvVO = invoiceVOList.get(0);				
				params.put("invoiceDueDate", eippInvVO.getInvDueDate());
				params.put("supplrOrgId", eippPymtVO.getSupplierOrgId());
				params.put("buyrOrgId", eippPymtVO.getBuyerOrgId());
				params.put("billType", eippPymtVO.getBillType());
				params.put("pmtMthdId", eippPymtVO.getPaymentMethodID());
				params.put("ccyCode", eippPymtVO.getPymtCurrency());
				params.put("pymtDateOpt", null);
				params.put("noDaysBdd", 0);
				params.put("paymentAmount", eippInvVO.getTotAmtPayable());
				params.put("pymtPrepMode", ONLINE);
				params.put("invIssueDate", eippInvVO.getIssueDate());
				params.put("pmtValueDateInOut", null);
				params.put("pmtInitDateInOut", eippPymtVO.getPymtInitDate());
				
				getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(EIPP_PYMT_DATE_CALC), params);
			
				eippPymtVO.setPmtValueDate( (Date)params.get("pmtValueDateInOut"));
				eippPymtVO.setEarlyPymtLatePymtRuleId((String)params.get("ruleId"));//3714
				
				for( int i=0; i< invoiceVOList.size(); i++ ){
					EippInvoiceVO invoiceVO = invoiceVOList.get(i);
					if(invoiceVO != null){
						getRebLateFeeAmount(params, invoiceVO, eippPymtVO);
					}
					
					String errorCode = (String)params.get("errorFlag");
					eippPymtVO.setErrorFlag(errorCode);
				
					invoiceVOList.set(i, invoiceVO);
				}
				eippPymtVO.setInvoiceList(invoiceVOList);
			}
		}catch(DataAccessException e){
			LOGGER.error(" Database exception occured in getRebateOrFeeMFU() method " + e.getMessage() ); 
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		LOGGER.debug("In PymtPreparationDAOImpl getRebateOrFeeMFU - Ends");
		return eippPymtVO;
	}	
	
	/**
	 * Gets the reb late fee amount.
	 *
	 * @param params the params
	 * @param eippInvoiceVO the eipp invoice vo
	 * @param pymtPrepVO the pymt prep vo
	 * @return the reb late fee amount
	 */
	private void getRebLateFeeAmount(Map<String,Object> params, EippInvoiceVO eippInvoiceVO, EippPymtVO pymtPrepVO){
		BigDecimal resultAmount = null;
		BigDecimal pymtAmount = eippInvoiceVO.getTotAmtPayable();
		BigDecimal diffDays = BigDecimal.ZERO;
		BigDecimal percent = BigDecimal.ZERO; 
		BigDecimal lateFeeAmt = BigDecimal.ZERO;
		BigDecimal discAmt = BigDecimal.ZERO;
		if(params != null){
			try{
				if(params.get("diffDays") != null){
					diffDays = (BigDecimal)params.get("diffDays");
				}
				if(params.get("percentage") != null){
					percent = (BigDecimal)params.get("percentage");
				}
				if(params.get("lateFeeAmt") != null){
					lateFeeAmt = (BigDecimal)params.get("lateFeeAmt");
				}
				if(params.get("earlyPmtRebate") != null){
					discAmt = (BigDecimal)params.get("earlyPmtRebate");
				}							
			}catch(Exception e){
				LOGGER.error("In getRebLateFeeAmount - parsing exception :", e);
			}
			
			if(params.get("lateFlag") != null){
				if(StatusConstants.YES.equalsIgnoreCase((String) params.get("lateFlag"))){				
					if(percent != null && BigDecimal.ZERO.compareTo(percent) != 0){
						resultAmount = getPercentComputedAmount(percent, pymtAmount, diffDays);
					}else{
						resultAmount = lateFeeAmt;
					}
					if(resultAmount != null){
						eippInvoiceVO.setLateFeeAmount(resultAmount);
						pymtPrepVO.setLateFeeAmount(pymtPrepVO.getLateFeeAmount().add(resultAmount));
					}
				}else{
					if(percent != null && BigDecimal.ZERO.compareTo(percent) != 0){
						resultAmount = getPercentComputedAmount(percent, pymtAmount, diffDays);
					}else{
						resultAmount = discAmt;
					}
					if(resultAmount != null){
						eippInvoiceVO.setTotDiscAmt(resultAmount);
						pymtPrepVO.setDiscountAmount(pymtPrepVO.getDiscountAmount().add(resultAmount));
					}
				}
			}
		}
	}
	
	/**
	 * Gets the percent computed amount.
	 *
	 * @param percent the percent
	 * @param pymtAmount the pymt amount
	 * @param diffDays the diff days
	 * @return the percent computed amount
	 */
	private BigDecimal getPercentComputedAmount(BigDecimal percent,BigDecimal pymtAmount,BigDecimal diffDays  ){
		BigDecimal resultAmount = null;
		BigDecimal noOfDays = new BigDecimal(365);
		
		resultAmount = (BigDecimal.ZERO.compareTo(diffDays) != 0)?(pymtAmount.multiply((diffDays.divide(
				noOfDays, RoundingMode.HALF_UP))).multiply(percent)):null;
		return resultAmount;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPreparationDAO#getBranchTimeZone(java.lang.String)
	 */
	@Override
	public String getBranchTimeZone(String orgId)
			throws BNPApplicationException {
		String branchTimeZone = null;
		try{
			branchTimeZone = (String) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(
					GET_BRANCH_TIME_ZONE), orgId);
		}catch(DataAccessException e){
			LOGGER.error("in PymtPreparationDAOImpl getBranchTimeZone - exception :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return branchTimeZone;

	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPreparationDAO#getPostCutOffTime(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public String getPostCutOffTime(EippPymtVO pymtPrepVO)
			throws BNPApplicationException {
		String branchCutOffTime = null;
		try{
			branchCutOffTime = (String) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(
					CHECK_POST_CUT_OFF_TIME), pymtPrepVO);
		}catch(DataAccessException e){
			LOGGER.error("in PymtPreparationDAOImpl getPostCutOffTime - exception :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return branchCutOffTime;
	}
		
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPreparationDAO#insertPymtAccessLogDetails(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	/**
	 * Insert pymt access log details.
	 *
	 * @param auditVO the audit vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	@Override
	public void insertPymtAccessLogDetails(EippPymtAuditVO auditVO)
			throws BNPApplicationException {
		try{
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(
					INSERT_PYMT_ACCESS_LOG), auditVO);
		}catch(DataAccessException e){
			LOGGER.error("in PymtPreparationDAOImpl insertPymtAccessLogDetails - Payment Audit  Data :", e);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPreparationDAO#updatePaymentStatus(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public void updatePaymentStatus(EippPymtVO pymtVO)
			throws BNPApplicationException {
		try {
			if(pymtVO.getPkId() == 0){
				pymtVO.setPkId(pymtVO.getPymtId());
			}
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_PYMT_STATUS), pymtVO);		
		} catch (DataAccessException e) {
			LOGGER.error("Exception in PymtPreparationDAOImpl updatePaymentStatus :::::" , e);
			throw new BNPApplicationException(ErrorConstants.PROCESSING_ERROR);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPreparationDAO#updateInvoiceBlockAmt(java.util.List)
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public void updateInvoiceBlockAmt(EippPymtVO pymtVO)
			throws BNPApplicationException {
		try{
			final EippPymtVO pymtPrepVO = pymtVO;
			final List<EippInvoiceVO> invDetailList = pymtPrepVO.getInvoiceList();
			final List<EippInvCntLineItemVO> pymtLevelLineItemList = getInvLineItemRecord(pymtVO);
			if(invDetailList != null && !invDetailList.isEmpty()){				
				getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
					@Override
					public List doInSqlMapClient(SqlMapExecutor executor)
							throws SQLException {
						List list = null;
						List<EippInvCntLineItemVO> invLineItemList = null;
						try {
							executor.startBatch();
							for(EippInvoiceVO invDtlVO : invDetailList){
								pymtPrepVO.setCreatedBy(StatusConstants.SYSTEM);
								invLineItemList = prepareLineItemList(invDtlVO, pymtLevelLineItemList);
								if(invLineItemList != null && !invLineItemList.isEmpty()){
									for(EippInvCntLineItemVO lineItemVO : invLineItemList){
										lineItemVO.setItemTotalPrice(lineItemVO.getDerivdItemTotPrice());
										executor.update(getQueryNameWithNameSpace
												(UPDATE_LINE_ITEM_DETAILS), lineItemVO);
										// audit Logger Entry in Line Item Audit Table									
										EippAuditVO auditVO = setLineItemAuditEntry(pymtPrepVO, lineItemVO);									
										executor.insert(getQueryNameWithNameSpace(INSERT_INTO_LINE_ITM_AUDIT_TABLE), auditVO);										
									}										
								}
								invDtlVO.setBlockedAmt(invDtlVO.getTotAmtPayable());
								invDtlVO.setDiscRuleId(pymtPrepVO.getEarlyPymtLatePymtRuleId());//3714
								executor.update(getQueryNameWithNameSpace(UPDATE_INVOICE), invDtlVO);
								executor.update(getQueryNameWithNameSpace(UPDATE_INV_PYMT_MAP_HIST), invDtlVO);//3714
								executor.update(getQueryNameWithNameSpace(UPDATE_INV_PYMT_MAP_MASTER), invDtlVO);//3714
								// audit Logger Entry in Invoice Audit Table								
								EippAuditVO auditVO = setInvoiceAuditEntry(pymtPrepVO, invDtlVO);									
								executor.insert(getQueryNameWithNameSpace(INSERT_INVOICE_AUDIT), auditVO);
							}
							list = executor.executeBatchDetailed();
							// R7.0 Fortify issues
//							if (list != null) {
//								LOGGER.debug("Batch Result Size" + list.size());
//							}
						} catch (BatchException e) {
							LOGGER.error("Excecuting batch update in PymtPreparationDAOImpl " +
									"updateInvoiceBlockAmt Failed ", e);
							throw new SQLException(e.getMessage(), e);
						} catch (BNPApplicationException e) {
							LOGGER.error("In PymtPreparationDAOImpl updateInvoiceBlockAmt :: Batch execution - " +
									"BNPApplicationException :", e);
						}
						return list;
					}
				});
			}
		}catch(Exception e){
			LOGGER.error("In PymtPreparationDAOImpl updateInvoiceBlockAmt - Exception :", e);
			throw new BNPApplicationException(e.getMessage(),e);
		}			
	}
	
	/**
	 * Prepare line item list.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @param lineItemList the line item list
	 * @return the list
	 * @throws BNPApplicationException the bNP application exception
	 */
	private List<EippInvCntLineItemVO>prepareLineItemList(EippInvoiceVO eippInvoiceVO, List<EippInvCntLineItemVO> 
		lineItemList) throws BNPApplicationException{
		List<EippInvCntLineItemVO> invLineItemList = new ArrayList<EippInvCntLineItemVO>();
		try {
			if(lineItemList != null && !lineItemList.isEmpty()){
				for(EippInvCntLineItemVO lineItemVO : lineItemList){
					if(lineItemVO.getInvId() == eippInvoiceVO.getInvId()){
						invLineItemList.add(lineItemVO);
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("In PymtPreparationDAOImpl prepareLineItemList - Exception :", e);
			throw new BNPApplicationException(e.getMessage(),e);
		}
		return invLineItemList;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPreparationDAO#getPaymentLeadDays(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public int getPaymentLeadDays(EippPymtVO pymtVO)
			throws BNPApplicationException {
		int pymtLeadDays = 0;
		try{
			Object objData  = getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(
					GET_PYMT_PREP_LEAD_DAYS), pymtVO);
			if(objData != null && objData instanceof Integer){
				pymtLeadDays = (Integer)objData;
			}
		}catch(DataAccessException e){
			LOGGER.error("in PymtPreparationDAOImpl getPaymentLeadDays - exception :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return pymtLeadDays;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPreparationDAO#getNextWorkingDate(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public Date getNextWorkingDate(EippPymtVO pymtVO, Date inputDate)
			throws BNPApplicationException {
		Map<String,Object> params = new HashMap<String, Object>();
		Date resultDate = null;
		
		try{
			if(pymtVO != null){
				params.put("ccyCode", pymtVO.getPymtCurrency());
				params.put("branchId", pymtVO.getBranchId());
				params.put("inputDate", inputDate);
				params.put("orgId",pymtVO.getOrgId());
				getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_NEXT_WORK_DATE), params);
				
				if(params.get("businessDay") != null){
					resultDate = ((Date)params.get("businessDay"));
				}
			}
		}catch(DataAccessException e){
			LOGGER.error("in PymtPreparationDAOImpl getNextWorkingDate - exception :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return resultDate;
	}	
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#insertPymtSnapshotDetails(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	@Override
	public void insertPymtSnapshotDetails(EippPymtVO eippPymtVO)
			throws BNPApplicationException {
		LOGGER.debug("In PymtPreparationDAOImpl insertPymtSnapshotDetails - Starts");
		savePymtProcInfo(eippPymtVO, eippPymtVO.getSplitPymtList());
		LOGGER.debug("In PymtPreparationDAOImpl insertPymtSnapshotDetails - Ends");
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#getInvLineItemRecord(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<EippInvCntLineItemVO> getInvLineItemRecord(EippPymtVO eippPymtVO)
			throws BNPApplicationException {
		List<EippInvCntLineItemVO> lineItemList = null;
		try{
			lineItemList = (List<EippInvCntLineItemVO>) getSqlMapClientTemplate().queryForList(
					getQueryNameWithNameSpace(FETCH_INV_LN_ITM_RECORD), eippPymtVO);
		}catch(DataAccessException e){
			LOGGER.error("In PymtPreparationDAOImpl getInvLineItemRecord - exception :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return lineItemList;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#getPymtCreditNoteRecords(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<EippCreditNoteVO> getPymtCreditNoteRecords(EippPymtVO eippPymtVO)
			throws BNPApplicationException {
		List<EippCreditNoteVO> creditNotelist = null;
		try{
			creditNotelist = (List<EippCreditNoteVO>) getSqlMapClientTemplate().queryForList(
					getQueryNameWithNameSpace(FETCH_CRED_NOTE_RECORD), eippPymtVO);
		}catch(DataAccessException e){
			LOGGER.error("In PymtPreparationDAOImpl getPymtCreditNoteRecords - exception :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return creditNotelist;	
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#getPymtMethodMaxAmt(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	@Override
	public BigDecimal getPymtMethodMaxAmt(EippPymtVO pymtPrepVO)
			throws BNPApplicationException {
		try{
			return  (BigDecimal) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(
					GET_PYMT_MTHD_MAX_AMT), pymtPrepVO);
		}catch(DataAccessException e){
			LOGGER.error("in PymtPreparationDAOImpl getPymtMethodMaxAmt - exception :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}

	}	
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#updatePymtCreditNotes(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	@Override
	public void updatePymtCreditNotes(EippPymtVO pymtPrepVO)
			throws BNPApplicationException {		
		if(pymtPrepVO != null){
			final List<EippCreditNoteVO> creditNotelist = getPymtCreditNoteRecords(pymtPrepVO); 
			if(creditNotelist != null){
				getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
					@Override
					public List doInSqlMapClient(SqlMapExecutor executor)
							throws SQLException {
						List list = null;
						try {
							executor.startBatch();
							for(EippCreditNoteVO creditNoteVO : creditNotelist){
								BigDecimal remCNAmt = creditNoteVO.getCntRemAmt().subtract( creditNoteVO.getCntUtilAmt());
								if( remCNAmt.compareTo(BigDecimal.ZERO)  != 1){
									creditNoteVO.setTempCntStatus(StatusConstants.UTILIZED_STATUS);
								}else{
									creditNoteVO.setTempCntStatus(StatusConstants.EIPP_CN_AVAILABLE);
								}
								
								executor.update(getQueryNameWithNameSpace(UPDATE_CREDIT_NOTE_TABLE), 
										creditNoteVO);
							}
							list = executor.executeBatchDetailed();
							// R7.0 Fortify issues
//							if (list != null) {
//								LOGGER.debug("Batch Result Size" + list.size());
//							}
						} catch (BatchException e) {
							LOGGER.error("Excecuting batch update in PymtPreparationDAOImpl " +
									"updatePymtCreditNotes Failed ", e);
							throw new SQLException(e.getMessage(), e);
						} 
						return list;
					}
				});
			}
		}
	}
	
	/**
	 * Sets the invoice audit entry.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @param eippInvoiceVO the eipp invoice vo
	 * @return the eipp audit vo
	 */
	private EippAuditVO setInvoiceAuditEntry(EippPymtVO eippPymtVO, EippInvoiceVO eippInvoiceVO){
		EippAuditVO auditVO = new EippAuditVO();
		auditVO.setInvId(eippInvoiceVO.getInvId());
		auditVO.setAuditUser(eippPymtVO.getCreatedBy());
		auditVO.setStatus(eippInvoiceVO.getInvStatus());
		auditVO.setAction(getAuditAction(eippPymtVO));	
		return auditVO;
	}
	
	/**
	 * Sets the line item audit entry.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @param eippInvCntLineItemVO the eipp inv cnt line item vo
	 * @return the eipp audit vo
	 */
	private EippAuditVO setLineItemAuditEntry(EippPymtVO eippPymtVO, EippInvCntLineItemVO eippInvCntLineItemVO){
		EippAuditVO auditVO = new EippAuditVO();
		auditVO.setAction(getAuditAction(eippPymtVO));
		auditVO.setAuditUser(eippPymtVO.getCreatedBy());
		auditVO.setInvId(eippInvCntLineItemVO.getInvId());
		auditVO.setLineItemId(eippInvCntLineItemVO.getLineItemId());
		auditVO.setStatus(eippInvCntLineItemVO.getLineItemStatus());
		return auditVO;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPaymentPreparationDao#checkPymtAutoRuleAvailable(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public AutoPaymentRuleVO checkPymtAutoRuleAvailable(EippInvoiceVO eippInvoiceVO)
			throws BNPApplicationException {
		AutoPaymentRuleVO ruleVO = null;
		try {
			ruleVO = (AutoPaymentRuleVO)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(CHECK_AUTP_PYMT_RULE_AVAILABLE), eippInvoiceVO);
		} catch (DataAccessException e) {
			LOGGER.error("Exception while getting financial processing flag invoice for payment preparation  :::::  " , e);
			throw new BNPApplicationException(ErrorConstants.PROCESSING_ERROR);
		}
		return ruleVO ;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPaymentPreparationDao#getDefaultSuppAccntIdentifier(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public Map<String, String> getDefaultSuppAccntIdentifier(EippPymtVO pymtPrepVO)
			throws BNPApplicationException {
		Map<String, String> suppAccntIdentfr = null;
		try {
			suppAccntIdentfr = (Map<String, String>)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_DEFAULT_SUPP_IDENTIFIER), pymtPrepVO);
		} catch (DataAccessException e) {
			LOGGER.error("Exception while getting default supplier account during payment preparation  :::::  " , e);
			throw new BNPApplicationException(ErrorConstants.PROCESSING_ERROR);
		}
		return suppAccntIdentfr;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPaymentPreparationDao#checkDisallowPymtMthd(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public boolean checkDisallowPymtMthd(EippInvoiceVO eippInvoiceVO)
			throws BNPApplicationException {
		Integer count = null;
		try{
			count = (Integer)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(CHECK_DISALL_PYMT_MTHD),eippInvoiceVO);
		}catch(DataAccessException e){
			LOGGER.error("Exception while checking disallow payment method  during payment preparation  :::::  " , e);
			throw new BNPApplicationException(ErrorConstants.PROCESSING_ERROR);
		}
		return count > 0;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPaymentPreparationDao#getMaxPymtAmtFrmPymtMthdBranch(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public BigDecimal getMaxPymtAmtFrmPymtMthdBranch(EippPymtVO pymtPrepVO)
			throws BNPApplicationException {
		BigDecimal maxPymtAmt = null;
		try{
			maxPymtAmt = (BigDecimal)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_MAX_PYMT_AMT), pymtPrepVO);
		}catch(DataAccessException e){
			LOGGER.error("Exception while checking disallow payment method  during payment preparation ::::: " , e);
			throw new BNPApplicationException(ErrorConstants.PROCESSING_ERROR);
		}
		return maxPymtAmt;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPaymentPreparationDao#calculatePaymentDates(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public void calculatePaymentDates (Map<String, Object> param)
		throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(CALCULATE_PAYMENT_DATE), param);
		} catch (DataAccessException e) {
			LOGGER.error("Error while executing procedure for calculating payment value date and pymt init date ::::: "+ e);
			throw new BNPApplicationException(ErrorConstants.PROCESSING_ERROR);		
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPaymentPreparationDao#getMarketPlaceIdentifier(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public Map<String, String> getMarkpetPlaceAccntIdentifier(
			EippInvoiceVO eippInvoiceVO) throws BNPApplicationException {
		Map<String, String> result = null;
		try{
			result = (Map<String,String>)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_MP_ACCNT_IDENTIFIER), eippInvoiceVO);
		}catch(DataAccessException e){
			LOGGER.error("Exception while getting market place accnt identifier and pymt mthd during payment preparation  ::::: " , e);
			throw new BNPApplicationException(ErrorConstants.PROCESSING_ERROR);
		}
		return result;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPaymentPreparationDao#getSupplierPymtMthdID(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public String getSupplierPymtMthdID(EippInvoiceVO eippInvoiceVO)
			throws BNPApplicationException {
		String pymtMthdId = null;
		try{
			pymtMthdId = (String)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_SUPP_PYMT_MTHD_ID), eippInvoiceVO);
		}catch(DataAccessException e){
			LOGGER.error("Exception while getting market place accnt identifier and pymt mthd during payment preparation  ::::: " , e);
			throw new BNPApplicationException(ErrorConstants.PROCESSING_ERROR);
		}
		return pymtMthdId;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPaymentPreparationDao#insertAutoPayment(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public void insertAutoPayment(EippPymtVO pymtVO)
			throws BNPApplicationException {
		try{
			if(pymtVO.isPymtPrepFlag()){
				pymtVO.setPmtType("PA");
				pymtVO.setPymtRefNo(getPaymentRefNo(pymtVO));
			}
			pymtVO.setPkId(populatePymtID());
			generateMapId(pymtVO);
			getSqlMapClientTemplate().insert( getQueryNameWithNameSpace(INSERT_AUTO_PYMT_MASTER) , pymtVO);
			getSqlMapClientTemplate().insert( getQueryNameWithNameSpace(INSERT_AUTO_PYMT_HIST) , pymtVO);
			if(pymtVO.isPymtPrepFlag()){
				getSqlMapClientTemplate().insert( getQueryNameWithNameSpace(INSERT_INV_PYMT_MAP_MASTER) , pymtVO);
				getSqlMapClientTemplate().insert( getQueryNameWithNameSpace(INSERT_INV_PYMT_MAP_HIST) , pymtVO);
			}
		} catch (DataAccessException e) {
			LOGGER.error("Exception while inserting auto payent record :::::  " , e);
			throw new BNPApplicationException(ErrorConstants.PROCESSING_ERROR);
		}
	}
	
	/**
	 * Populate pymt id.
	 *
	 * @return the long
	 * @throws BNPApplicationException the bNP application exception
	 */
	private long populatePymtID() throws BNPApplicationException{
		try{
			return (Long)getSqlMapClientTemplate().queryForObject( getQueryNameWithNameSpace(POPULATE_PYMT_ID));
		} catch (DataAccessException e) {
			LOGGER.error("Exception while getting payment reference number :::::  " , e);
			throw new BNPApplicationException(ErrorConstants.PROCESSING_ERROR);
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPaymentPreparationDao#insertAudit(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public void insertPaymentAudit(EippPymtVO pymtVO) throws BNPApplicationException {
		try{
			getSqlMapClientTemplate().insert( getQueryNameWithNameSpace(INSERT_PYMT_AUDIT) , pymtVO);
		} catch (DataAccessException e) {
			LOGGER.error("Exception while inserting audit entry :::::  " , e);
			throw new BNPApplicationException(ErrorConstants.PROCESSING_ERROR);
		}
		
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#updateAuthProfileDetails(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	@Override
	public void updateAuthProfileDetails(EippPymtVO pymtVO)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_AUTH_PROF_REF_DET), pymtVO);		
		} catch (DataAccessException e) {
			LOGGER.error("Exception in PymtPreparationDAOImpl updateAuthProfileRefId :::::" , e);
			throw new BNPApplicationException(ErrorConstants.PROCESSING_ERROR);
		}
	}
	
		
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#setLinkedCreditNotes(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<EippCreditNoteVO> getLinkedCreditNotes(EippInvoiceVO eippInvoiceVO)
			throws BNPApplicationException {
		try{
			if(eippInvoiceVO != null && eippInvoiceVO.getInvId() > 0){
				return (List<EippCreditNoteVO>)getSqlMapClientTemplate().
					queryForList(getQueryNameWithNameSpace(GET_LINK_CN_DETAILS), eippInvoiceVO);
			}
		} catch (DataAccessException e) {
			LOGGER.error("Exception in PymtPreparationDAOImpl getLinkedCreditNotes :::::" , e);
			throw new BNPApplicationException(ErrorConstants.PROCESSING_ERROR);
		}
		
		return null;
	}
	
	public boolean isAllocatedAtInvLevel(EippInvoiceVO invoice)
									throws BNPApplicationException {
		boolean isInvAllocType = false;
		try{
				String allocType = (String) getSqlMapClientTemplate().
					queryForObject(getQueryNameWithNameSpace(GET_ALLOC_TYPE), invoice);
				isInvAllocType = (allocType == null || StatusConstants.INV.equalsIgnoreCase(allocType));
		} catch (DataAccessException e) {
			LOGGER.error("Exception in PymtPreparationDAOImpl isAllocatedAtInvLevel :::::" , e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return isInvAllocType;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPreparationDAO#checkValidMktPlaceOrg(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	@Override
	public boolean checkValidMktPlaceOrg(EippPymtVO pymtVO)
			throws BNPApplicationException {
		int count = 0;
		try{
			Object objCount = getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(
					CHECK_VALID_MKT_PLC_ORG), pymtVO);
			if(objCount != null){
				count = (Integer)objCount;
			}
		}catch(DataAccessException e){
			LOGGER.error("Exception in pymtpreparationdaoimpl checkValidMktPlaceOrg  :::::  ", e);
			throw new BNPApplicationException(ErrorConstants.PROCESSING_ERROR);
		}
		return (count > 0);
	}


	@Override
	public BigDecimal getAmtforLI(long invId) {
	BigDecimal bgAmt = (BigDecimal)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(
					GETLI_AMT), invId);
	return bgAmt;
	}
	

}

