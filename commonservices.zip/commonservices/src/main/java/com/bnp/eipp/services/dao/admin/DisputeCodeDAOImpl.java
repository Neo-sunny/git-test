/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   23 JAN 2012
 * 
 * Purpose:      Dispute Code Screen  
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 23 JAN 2012                      Oracle Financial Services Software Ltd        Initial Version 
 * 21 Jul 2012						Reena S										  Release 3.0 				EIPP Phase II changes
 ***************************************************************************/
package com.bnp.eipp.services.dao.admin;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.vo.admin.DisputeCodeVO;
import com.bnp.scm.services.common.dao.AbstractCommonDaoImpl;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.vo.NameValueVO;




@Component
public class DisputeCodeDAOImpl extends AbstractCommonDaoImpl<DisputeCodeVO>  implements IDisputeCodeDAO{

	private static final Logger LOGGER = LoggerFactory.getLogger(DisputeCodeDAOImpl.class);
	
	private static final String NAME_SPACE = "disputeCodeNS.";
	
	private static final String GET_DISPUTE_SUMMARY_DETAILS="disputeCodeNS.getDisputeCodeSummary";
	
	private static final String GET_BILL_TYPE_DETAILS="disputeCodeNS.getBillTypeDetails";
	
	private static final String GET_CUST_ROLE="disputeCodeNS.getCustRole";
	
	private static final String GET_CUST_ORG_LIST_FOR_USER="disputeCodeNS.getOrgIdListForUser";
	
	private static final String CHECK_DUPLICATE_REC="disputeCodeNS.checkDuplicatRecord";
	
	private static final String GET_MODIFIED_REC_DETAIL="disputeCodeNS.getModifiedRecord";
	
	private static final String GET_DISP_RESOLUTION_CODE = "disputeCodeNS.getDisputeResolutionCode";
	
	private static final String GET_DISPUTE_CODE_COUNT="disputeCodeNS.getDisputeCodeCountinDispAllocRule";

	@Override
	public List<DisputeCodeVO> getDisputeCodeSummaryDetails(
			DisputeCodeVO disputeVO) throws BNPApplicationException {
		List<DisputeCodeVO> disputeCodeList = null;
		try{
			disputeCodeList = getSqlMapClientTemplate().queryForList(GET_DISPUTE_SUMMARY_DETAILS , disputeVO);
		}catch (DataAccessException e) {
			LOGGER.error("Error in fetching DisputeCodeSummaryDetails"+e);
			throw new DBException(ErrorConstants.ERROR_IN_SEARCH);
		}
		return disputeCodeList;
	}

	@Override
	public String getNameSpace() {

		return NAME_SPACE;
	}

	@Override
	public List<NameValueVO> getBillTypeDetailsForOrgId(String orgId)
			throws BNPApplicationException {
		List<NameValueVO> billTypeDetail =null;
		try{
			billTypeDetail = getSqlMapClientTemplate().queryForList(GET_BILL_TYPE_DETAILS ,orgId);
		}catch (DataAccessException e) {
			LOGGER.error("Error in fetching BillTypeDetailsForOrgId"+e.getMessage());
			throw new DBException(ErrorConstants.ERROR_IN_SEARCH);
		}
		return billTypeDetail;
	}

	@Override
	public String getCustRoleForOrgId(String orgId)
			throws BNPApplicationException {
		String custRole =null;
		try{
			custRole = (String)getSqlMapClientTemplate().queryForObject(GET_CUST_ROLE , orgId);
		}catch (DataAccessException e) {
			LOGGER.error("Error in fetching Customer Role for Selected Org ID"+e.getMessage());
			throw new DBException(ErrorConstants.ERROR_IN_SEARCH);
		}
		return custRole;
	}

	@Override
	public List<NameValueVO> getOrgIdListForUser(NameValueVO userDetails)
			throws BNPApplicationException {
		List<NameValueVO> orgIdListForUser = null;
		
		try{
			orgIdListForUser = getSqlMapClientTemplate().queryForList(GET_CUST_ORG_LIST_FOR_USER , userDetails);
		}catch (DataAccessException e) {
			LOGGER.error("Error in fetching  Org ID for Loggeed in User "+e.getMessage());
			throw new DBException(ErrorConstants.ERROR_IN_SEARCH);
		}
		
		return orgIdListForUser;
	}

	@Override
	public int checkDuplicateRecords(DisputeCodeVO disputecodeVO)
			throws BNPApplicationException {
		int count =0;
		try {
			count = (Integer) getSqlMapClientTemplate().queryForObject(CHECK_DUPLICATE_REC,disputecodeVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error in Checking Duplicate Record in   Dispute Code "+e.getMessage());
			throw new DBException(ErrorConstants.ERROR_CONDITION_FETCH);
		}
		return count;
	}

	@Override
	public DisputeCodeVO getModifiedRecord(DisputeCodeVO disputecodeVO)
			throws BNPApplicationException {
		DisputeCodeVO modifiedRecDetails = null;
		try{
			modifiedRecDetails = (DisputeCodeVO)getSqlMapClientTemplate().queryForObject(GET_MODIFIED_REC_DETAIL,disputecodeVO);
		}catch (DataAccessException e) {
			LOGGER.error("Error in fetching  Modified Record in   Dispute Code "+e.getMessage());
			throw new DBException(ErrorConstants.ERROR_CONDITION_FETCH);
		}
		return modifiedRecDetails;
	}
	
	public List<DisputeCodeVO> getDisputeCodeList(
			DisputeCodeVO codeVO) throws BNPApplicationException {
		List<DisputeCodeVO> dataList = null;
		try{
			dataList = (List<DisputeCodeVO>)getSqlMapClientTemplate().queryForList(
					GET_DISP_RESOLUTION_CODE, codeVO);
		}catch (DataAccessException e) {
			LOGGER.error("Error while getting Dispute resolution Code "+e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		return dataList;
	}

	@Override
	public int getDisputeCodeCountForDelete(DisputeCodeVO codeVO)
			throws BNPApplicationException {
		int count = 0;
		try{
			
			count =(Integer)getSqlMapClientTemplate().queryForObject( GET_DISPUTE_CODE_COUNT ,codeVO);
		}catch (DataAccessException e) {
			LOGGER.error("Error in fetching   Dispute Code count in Dispute Allocation Rule "+e.getMessage());
			throw new DBException(ErrorConstants.ERROR_CONDITION_FETCH);
		}
		return count;
	}

}
