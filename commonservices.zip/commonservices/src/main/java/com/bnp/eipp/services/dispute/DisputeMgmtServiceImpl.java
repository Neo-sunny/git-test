/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 22, 20121:13:22 PM
 * 
 * Purpose:      DisputeMgmtServiceImpl.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 22, 20121:13:22 PM        Oracle Financial Services Software Ltd         		Initial Version
 * Mar 10th 2012        		 Oracle Financial Services Software Ltd                 UT Fixes
 * Apr 2 2012			         Oracle Financial Services Software Ltd                 R2.1 SIT 1895 Fixes
 * 18 April 2012		         Sandhya R				  								SIT #2020 and #2017
 * 20 April 2012		         Sandhya R				  								SIT #2020
 * 21 April 2012		 		 Prabakaran S											Create Invoice Audit & Dispute Audit Changes
 * 14 May   2012		 		 Sandhya											    R2.1 UAT # 2240
 * 03 Aug 2012					 Reena S								Release 3.0		EIPP PhaseII-Release File Inq Changes
 * 06 Sep 2012                   Reena S								Release 3.0     For getting Validation Failed Record details
 * 26 Sep 2012    				 Dinesh D							                    MFU - EIPP Disputes 
 * 24 Oct 2012    				 Ravishankar V							                For Adhoc Issue and a part of 6968
 * 30 Oct 2012 		 			 Arun G													Events ST Issues
 * 08 Nov 2012 					 Reena S								Release 3.0     Raise Dispute when dual control=N;Cancel dispute issue
 * 09-Nov-2012				     Yashmika												UAT Bug Fix # 2916
************************************************************************************************************************************************************/

package com.bnp.eipp.services.dispute;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnp.eipp.services.admin.IBillTypeDefinitionService;
import com.bnp.eipp.services.admin.IDisputeCodeService;
import com.bnp.eipp.services.admin.ILinkOrgForEippServices;
import com.bnp.eipp.services.dao.dispute.IDisputeMgmtDao;
import com.bnp.eipp.services.invoice.IEippInvoiceService;
import com.bnp.eipp.services.invoice.util.EippAuditConstants;
import com.bnp.eipp.services.invoice.vo.EippAuditVO;
import com.bnp.eipp.services.invoice.vo.EippCustFieldsVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.vo.admin.DisputeCodeVO;
import com.bnp.eipp.services.vo.dispute.DisputeAllocationMappingVO;
import com.bnp.eipp.services.vo.dispute.DisputeAuditVO;
import com.bnp.eipp.services.vo.dispute.DisputeCustFieldsVO;
import com.bnp.eipp.services.vo.dispute.DisputeVO;
import com.bnp.scm.services.common.TransactionServiceImpl;
import com.bnp.scm.services.common.cache.ICacheService;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.event.EventType;
import com.bnp.scm.services.common.event.IEventDelegate;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.common.vo.AttachmentVO;
import com.bnp.scm.services.common.vo.EventLogVO;
import com.bnp.scm.services.common.vo.NameValueVO;

@Component
public class DisputeMgmtServiceImpl extends TransactionServiceImpl implements IDisputeMgmtService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DisputeMgmtServiceImpl.class);
	
	@Autowired
	private IDisputeMgmtDao disputeMgmtDao;
	
	@Autowired
	private IEippInvoiceService invoiceService;
	
	@Autowired
	private ILinkOrgForEippServices linkOrgForEippService;
	
	@Autowired
	private IBillTypeDefinitionService billTypeService;
	
	@Autowired
	private IDisputeCodeService disputeCodeService;
	
	@Autowired
	private ICacheService cacheService;
	
	@Autowired
	private IEventDelegate eventDelegateImpl;
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	public void insertInvoiceDispute(DisputeVO disputeVO) 
			throws BNPApplicationException {
	disputeMgmtDao.insertInvoiceDispute(disputeVO);
	disputeVO.setDisputedAt(StatusConstants.DISPUTED_AT_INVOICE_LEVEL);
	String userId=disputeVO.getEippInvoice().getDeptAllocMap().getUserId();
	if (disputeVO.getFileId() == 0) {
		if("*".equals(userId)){
			disputeMgmtDao.batchInsertAllocMap(disputeVO);
		}else{
			disputeMgmtDao.insertDisuteInAllocMap(disputeVO);
		}
	}
	
	if (disputeVO.getFileId() == 0 && 
			checkForResolutionApproval(disputeVO.getEippInvoice().getBuyerOrgId())) {
		insertBuyerEventLog(disputeVO, 
				EventType.EIPP_DISPUTE_PENDING_APPROVAL);
		getDeptId(disputeVO.getEippInvoice());
		createDisputeAudit(disputeVO, 
				EippAuditConstants.INV_DISPUTE_PENDING_APPROVAL, null);
	} else {
		List<DisputeVO> _tmpList = new ArrayList<DisputeVO>();
		disputeVO.setDisputedAt(StatusConstants.DISPUTED_AT_INVOICE_LEVEL);
		disputeVO.setBillType(disputeVO.getEippInvoice().getBillType());
		_tmpList.add(disputeVO);
		getDeptId(disputeVO.getEippInvoice());
		disputeVO.setAction(EippAuditConstants.INV_DISPUTE_PENDING_APPROVAL);
		approveAndSendItToSupplier(_tmpList);
	}
	
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	public void insertInvoiceLIDispute(DisputeVO disputeVO) 
				throws BNPApplicationException {
		 
		List<Long> lineItemList = disputeMgmtDao.insertInvoiceLIDispute(disputeVO);
		disputeVO.setDisputedAt(StatusConstants.DISPUTED_AT_LINE_ITEM_LEVEL);
		
		if (disputeVO.getFileId()==0) {
			if(disputeVO.getEippInvoice().getDeptAllocMap().getUserId()!=null 
					&& disputeVO.getEippInvoice().getDeptAllocMap().getUserId().equals("*")){
				disputeMgmtDao.batchInsertAllocMap(disputeVO);
			}else{
				disputeMgmtDao.insertDisuteInAllocMap(disputeVO);
			}
		}
		
		if(disputeVO.getFileId()==0 && 
				checkForResolutionApproval(disputeVO.getEippInvoice().getBuyerOrgId())){
			insertBuyerEventLog(disputeVO, 
					EventType.EIPP_DISPUTE_PENDING_APPROVAL);
			getDeptId(disputeVO.getEippInvoice());
			createDisputeAudit(disputeVO, 
					EippAuditConstants.INV_DISPUTE_PENDING_APPROVAL,lineItemList);
		}else{
			List<DisputeVO> _tmpList = new ArrayList<DisputeVO>();
			disputeVO.setDisputedAt(StatusConstants.DISPUTED_AT_LINE_ITEM_LEVEL);
			_tmpList.add(disputeVO);
			disputeVO.setBillType(disputeVO.getEippInvoice().getBillType());
			getDeptId(disputeVO.getEippInvoice());
			disputeVO.setAction(EippAuditConstants.INV_DISPUTE_PENDING_APPROVAL);
			approveAndSendItToSupplier(_tmpList);
		}
	}
	
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	public void insertInvoiceDetailDispute(DisputeVO disputeVO)
				throws BNPApplicationException {
		disputeMgmtDao.insertInvoiceDetailDispute(disputeVO);
	}
	
	@Override
	public List<NameValueVO> getDisputeCodes(EippInvoiceVO eippInvoiceVO)
	throws BNPApplicationException {
		return disputeMgmtDao.getDisputeCodes(eippInvoiceVO);
	}
	
	@Override
	public void checkExistingDispute(long invId)
	throws BNPApplicationException {
		disputeMgmtDao.checkExistingDispute(invId);
	}
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	public void insertInvDispAttachment(AttachmentVO attachmentVO)
	throws BNPApplicationException {
		disputeMgmtDao.insertInvDispAttachment(attachmentVO);
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	public void insertDisputeAllocationMapping(
			DisputeAllocationMappingVO mappingVO)
			throws BNPApplicationException {
		disputeMgmtDao.insertDisputeAllocationMapping(mappingVO);
		
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	public void reassignDispute(DisputeVO dispute)
			throws BNPApplicationException {
		disputeMgmtDao.reassignDispute(dispute);
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	public void acceptDisputes(List<DisputeVO> invDispute)
			throws BNPApplicationException {
		
		String status = null;
		boolean isApprovalReqd = true;
		
		for (DisputeVO dispute : invDispute) {
			if(dispute.getFileId()==0)
			{
				isApprovalReqd = checkForResolutionApproval(
						dispute.getEippInvoice().getSupplierOrgId());
			}
			else
			{
				isApprovalReqd=false;
			}
			status = StatusConstants.DISPUTE_PENDING_ACCEPTANCE;
			acceptDispute(status, dispute);
			
			dispute.setDispStatus(status);
			if (!isApprovalReqd) {
				dispute.setResolutionApprovedBy(StatusConstants.SYSTEM);
				dispute.setAction(EippAuditConstants.DISPUTE_PENDING_ACCEPTANCE);
				approveDisputeResolution(dispute);
			} else {
				insertSupplierEventLog(dispute, 
						EventType.EIPP_DISPUTE_SUPPLIER_APPROVAL);
				dispute.setOrgRole(StatusConstants.SELLER);
				createDisputeAudit(dispute, 
						EippAuditConstants.DISPUTE_PENDING_ACCEPTANCE, null);
			}
		}
	}
	
	private void acceptDispute(String status, 
			DisputeVO dispute) throws BNPApplicationException {
		disputeMgmtDao.acceptDispute(status, dispute);
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	public void rejectDisputes(List<DisputeVO> invDispute)
			throws BNPApplicationException {

		String status = null;
		boolean isApprovalReqd = true;
		
		for (DisputeVO dispute : invDispute) {
			if(dispute.getFileId()==0)
			{
				isApprovalReqd = checkForResolutionApproval(
						dispute.getEippInvoice().getSupplierOrgId());
			}
			else
			{
				isApprovalReqd=false;
			}
			status = StatusConstants.DISPUTE_PENDING_REJECTION;		
			disputeMgmtDao.rejectDispute(status, dispute);
			dispute.setDispStatus(status);
			if (!isApprovalReqd) {
				dispute.setResolutionApprovedBy(StatusConstants.SYSTEM);
				dispute.setAction(EippAuditConstants.DISPUTE_PENDING_REJECTION);
				approveDisputeResolution(dispute);
			} else {
				insertSupplierEventLog(dispute, 
					EventType.EIPP_DISPUTE_SUPPLIER_APPROVAL);
				dispute.setOrgRole(StatusConstants.SELLER);
				createDisputeAudit(dispute,
						EippAuditConstants.DISPUTE_PENDING_REJECTION, null);
			}
		}
	}
	
	private void approveDisputeResolution(
			DisputeVO dispute) throws BNPApplicationException {
		List<DisputeVO> disputeList = new ArrayList<DisputeVO>();
		disputeList.add(dispute);
		approveDisputeResolution(disputeList);
	}
	
	private void resetInvoiceStatusWithTimeStamp(DisputeVO dispute) throws BNPApplicationException{
		invoiceService.updateInvStatusAndRemAmtWithTimeStamp(dispute);
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	public void approveDisputeResolution(List<DisputeVO> disputeList)
			throws BNPApplicationException {
		String action = null;
		
		for (DisputeVO dispute : disputeList) {
			disputeMgmtDao.updateDisputeResolution(dispute);
			
			if (StatusConstants.DISPUTE_PENDING_ACCEPTANCE.equals(
					dispute.getDispStatus())) {
				if (StatusConstants.DISPUTED_AT_INVOICE_LEVEL.equals(
						dispute.getDisputedAt())) {
					resetInvoiceStatusWithTimeStamp(dispute);
				} else {
					List<DisputeCustFieldsVO> disputedFields = 
								disputeMgmtDao.getLineItemDispFields(
													dispute.getDispRefNo());
					dispute.setCustFieldsList(disputedFields);
					String status = invoiceService.updateInvLnItmStatusAndRemAmt(dispute);
					dispute.setLastUpdatedTimestamp(updateInvoiceStatusWithTimeStamp(status,dispute.getEippInvoice().getInvId()));
					invoiceService.insertInvoiceIntoHistory(dispute.getEippInvoice());
				}
				insertBuyerEventLog(dispute, EventType.EIPP_INV_DISPUTE_ACCEPT);
				dispute.setDispStatus(StatusConstants.DISPUTE_ACCEPTED);
				
				if (dispute.getAction() != null) {
					action = dispute.getAction();
				} else {
					action = EippAuditConstants.DISPUTE_ACCEPTED;
				}
			} else if (StatusConstants.DISPUTE_PENDING_REJECTION.equals(
					dispute.getDispStatus())) {
				long invoiceId = dispute.getEippInvoice().getInvId();
				String status = invoiceService.getPrevInvoiceStatus(invoiceId);
				dispute.setLastUpdatedTimestamp(disputeMgmtDao.updateInvoiceStatus(
						status, invoiceId));
				invoiceService.insertInvoiceIntoHistory(dispute.getEippInvoice());
				
				if (StatusConstants.DISPUTED_AT_LINE_ITEM_LEVEL.equals(
						dispute.getDisputedAt())) {
					List<Long> lineItemIds = getDisputedLineItems(dispute.getDispRefNo());
					invoiceService.updateLineItemStatus(lineItemIds, status);
				}
				insertBuyerEventLog(dispute, EventType.EIPP_INV_DISPUTE_REJECT);
				dispute.setDispStatus(StatusConstants.DISPUTE_REJECTED);
				
				if (dispute.getAction() != null) {
					action = dispute.getAction();
				} else {
					action = EippAuditConstants.DISPUTE_REJECTED;
				}
			}
			dispute.setOrgRole(StatusConstants.SELLER);
			createDisputeAudit(dispute, action, null);
		}
	}

	@Override
	public void updateDisputeStatus(String status, DisputeVO disputeVO)
			throws BNPApplicationException {
		disputeMgmtDao.updateDisputeStatus(status, disputeVO);
	}

	@Override
	public List<DisputeVO> getDisputeDetails(DisputeVO disputeVO)
			throws BNPApplicationException {
		return disputeMgmtDao.getDisputeDetails(disputeVO);
	}
	
	private Timestamp updateInvoiceStatusWithTimeStamp(String status, long invoiceId)
		throws BNPApplicationException {
		return disputeMgmtDao.updateInvoiceStatus(status, invoiceId);
	}
	
	public void updateInvoiceStatus(String status, long invoiceId) 
			throws BNPApplicationException {
		disputeMgmtDao.updateInvoiceStatus(status, invoiceId);
	}
	
	private DisputeAllocationMappingVO createDisputeAllocMapping(
			DisputeVO dispute, long deptPKId) {
		
		DisputeAllocationMappingVO 
				allocMapVO = new DisputeAllocationMappingVO();
		
		allocMapVO.setUserId(StatusConstants.ALL_RECORDS);
		allocMapVO.setDeptId(deptPKId);
		allocMapVO.setLevel(1);
		allocMapVO.setDisputeRefNo(dispute.getDispRefNo());
		allocMapVO.setActive(StatusConstants.YES);
		allocMapVO.setAllocationType(StatusConstants.ALLOC_TYPE_DEFAULT);
		allocMapVO.setOrgRole(StatusConstants.SELLER);
		allocMapVO.setStatus("PENDING");
		
		return allocMapVO;
	}
	
	private boolean isDisputeDepartmentAvailable(DisputeVO dispute) {
		EippInvoiceVO invoice = dispute.getEippInvoice();
		
		if (invoice.getDefDeptPKId() > 0) {
			return true;
		}
		return false;
	}
	
	public boolean isDisputeAllocRuleAvailable(
			DisputeVO dispute) throws BNPApplicationException {
		return disputeMgmtDao.isDisputeAllocRuleAvailable(dispute);
	}
	
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	public void approveAndSendItToSupplier(List<DisputeVO> disputeList)
			throws BNPApplicationException {
		
		DisputeAllocationMappingVO mappingVO = null;
		String action = null;
		
		for (DisputeVO dispute : disputeList) {
			if (isDisputeDepartmentAvailable(dispute)) {
				EippInvoiceVO invoice = dispute.getEippInvoice();
				
				mappingVO = createDisputeAllocMapping(
						dispute, invoice.getDefDeptPKId());
				insertDisputeAllocationMapping(mappingVO);
			} else if (isDisputeAllocRuleAvailable(dispute)){
				disputeMgmtDao.populateDisputeAllocMapping(dispute);
			} else {
				Map<String, Object> params = populateDispResolutionParams(dispute);
				long deptPKId = linkOrgForEippService.getDepartmentForDisputeResolution(params);
				
				if (deptPKId  == 0) {
					deptPKId = billTypeService.getDefaultDepartmentForDispute(
								dispute.getEippInvoice().getSupplierOrgId(), dispute.getBillType());
					
					if (deptPKId == 0) {
						throw new BNPApplicationException(ErrorConstants.NO_SUP_DEFAULT_DEPT_AVAILABLE);
					}
				} 
				mappingVO = createDisputeAllocMapping(dispute, deptPKId);
				insertDisputeAllocationMapping(mappingVO);
			}
			approveDispute(StatusConstants.DISPUTED, dispute);
			updateInvoiceStatus(StatusConstants.DISPUTED, 
					dispute.getEippInvoice().getInvId());
			invoiceService.insertInvoiceIntoHistory(dispute.getEippInvoice());
			insertSupplierEventLog(dispute, EventType.EIPP_INV_DISPUTE);
			dispute.setOrgRole(StatusConstants.BUYER);
			
			if (dispute.getAction() != null) {
				action = dispute.getAction();
			} else {
				action = EippAuditConstants.INV_DISPUTED;				
			}
			createDisputeAudit(dispute, action, null);
		}
	}
	
	private void approveDispute(String status, DisputeVO dispute) 
						throws BNPApplicationException {

		dispute.setDispStatus(StatusConstants.DISPUTED);
		if (StatusConstants.DISPUTED_AT_INVOICE_LEVEL.equals(
				dispute.getDisputedAt())) {
			disputeMgmtDao.approveInvoiceDispute(dispute);	
		} else {
			disputeMgmtDao.approveInvDetDispute(dispute);
		}
		
	}
	
	private Map<String, Object> populateDispResolutionParams(
				DisputeVO dispute) throws BNPApplicationException {
		Map<String, Object> params = new HashMap<String, Object>();
		
		String custOrgId = null;
		String cpOrgId = null;
		
		if (isBuyercentricModel(dispute.getEippInvoice().getBuyerOrgId())) {
			custOrgId = dispute.getEippInvoice().getBuyerOrgId();
			cpOrgId = dispute.getEippInvoice().getSupplierOrgId();
		} else {
			custOrgId = dispute.getEippInvoice().getSupplierOrgId();
			cpOrgId = dispute.getEippInvoice().getBuyerOrgId();
		}
		params.put("custOrgId", custOrgId);
		params.put("cpOrgId", cpOrgId);
		params.put("billType", dispute.getBillType());
		
		return params;
	}
	
	public boolean checkForResolutionApproval (
			String orgId) throws BNPApplicationException {
		return disputeMgmtDao.checkForResolutionApproval(orgId);
	}

	@Override
	public SqlMapClientWrapper getDao() {
		return (SqlMapClientWrapper) disputeMgmtDao;
	}
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	public void cancelDisputes(List<DisputeVO> disputesList)
			throws BNPApplicationException {
		for (DisputeVO dispute : disputesList) {
			disputeMgmtDao.cancelDispute(dispute);
			//String status = invoiceService.getPrevInvoiceStatusForCancel(
			//		dispute.getEippInvoice().getInvId());
			String status = getPrevInvcStatusForCancel(dispute.getEippInvoice().getInvId());
			dispute.setLastUpdatedTimestamp(disputeMgmtDao.updateInvoiceStatus(status, 
					dispute.getEippInvoice().getInvId()));
			invoiceService.insertInvoiceIntoHistory(dispute.getEippInvoice());
			
			if (StatusConstants.DISPUTED_AT_LINE_ITEM_LEVEL.equals(
					dispute.getDisputedAt())) {
				List<Long> lineItemIds = getDisputedLineItems(dispute.getDispRefNo());
				invoiceService.updateLineItemStatus(lineItemIds, status);
			}
			dispute.setDispStatus(StatusConstants.DISPUTE_CANCELLED);
			dispute.setOrgRole(StatusConstants.BUYER);
			createDisputeAudit(dispute, EippAuditConstants.DISPUTE_CANCELLED, null);
		}
	}
	
	private List<Long> getDisputedLineItems(
			String dispRefNo) throws BNPApplicationException {
		return disputeMgmtDao.getDisputedLineItems(dispRefNo);
	}
	
	private String getPrevInvcStatusForCancel(long invoiceId)throws BNPApplicationException {
		return disputeMgmtDao.getPrevInvcStatusForCancel(invoiceId);
	}
 
	@Override
	public DisputeVO getDisputeDetail(DisputeVO dispute)
			throws BNPApplicationException {
		return disputeMgmtDao.getDisputeDetail(dispute);
	}
	
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	public void overrideDisputes(List<DisputeVO> disputeList) throws BNPApplicationException {
		
		for (DisputeVO dispute : disputeList) {
			if (StatusConstants.ACTION_ACCEPTED.equals(
					dispute.getActionRequired())) {
				dispute.setDispStatus(StatusConstants.DISPUTE_ACCEPTED);
				
				if (dispute.getDisputedAt().equals(
						StatusConstants.DISPUTED_AT_INVOICE_LEVEL)) {
					disputeMgmtDao.overrideInvDispute(dispute);
					resetInvoiceStatusWithTimeStamp(dispute);
				} else {
					disputeMgmtDao.overrideInvDetDispute(dispute);
					
					String status = invoiceService.updateInvLnItmStatusAndRemAmt(dispute);
					dispute.setLastUpdatedTimestamp(updateInvoiceStatusWithTimeStamp(status,dispute.getEippInvoice().getInvId()));
				}
			} else if (StatusConstants.ACTION_REJECTED.equals(
					dispute.getActionRequired())) {
				dispute.setDispStatus(StatusConstants.DISPUTE_REJECTED);
				
				long invoiceId = dispute.getEippInvoice().getInvId();
				String status = invoiceService.getPrevInvoiceStatus(
						invoiceId);
				
				dispute.setLastUpdatedTimestamp(disputeMgmtDao.updateInvoiceStatus(
						status, invoiceId));
				invoiceService.insertInvoiceIntoHistory(dispute.getEippInvoice());
				
				if (dispute.getDisputedAt().equals(
						StatusConstants.DISPUTED_AT_INVOICE_LEVEL)) {
					disputeMgmtDao.overrideInvDispute(dispute);
				} else {
					disputeMgmtDao.overrideInvDetDispute(dispute);
					List<Long> lineItemIds = getDisputedLineItems(dispute.getDispRefNo());
					invoiceService.updateLineItemStatus(lineItemIds, status);
				}
			}
			dispute.setOrgRole(StatusConstants.SELLER);
			createDisputeAudit(dispute, EippAuditConstants.DISPUTE_OVERRIDDEN, null);
		}
	}
	
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	public void saveReassignmentDetails(DisputeVO dispute)
			throws BNPApplicationException {
		List<DisputeAllocationMappingVO> allocMapList = new ArrayList<DisputeAllocationMappingVO>();
		DisputeAllocationMappingVO mapVO = null;
		
		disputeMgmtDao.updateDisputeAllocMapping(dispute);
		
		List<String> approverDepts = dispute.getApproverDepts();
		List<String> approverUsers = dispute.getApproverUserIds();
		
		if (approverDepts != null && !approverDepts.isEmpty()) {
			List<Integer> deptIdList = getDeptIdList(dispute);
			for (int deptPKId : deptIdList) {
				mapVO = new DisputeAllocationMappingVO();
				
				mapVO.setDeptId(deptPKId);
				mapVO.setUserId(StatusConstants.ALL_RECORDS);
				mapVO.setDisputeRefNo(dispute.getDispRefNo());
				mapVO.setAllocationType(StatusConstants.ALLOC_TYPE_REASSIGNED);
				mapVO.setActive(StatusConstants.YES);
				mapVO.setStatus(StatusConstants.DISPUTE_PENDING);

				if (isBuyerUser(dispute.getUserType())) {
					mapVO.setOrgRole(StatusConstants.BUYER);
				} else if (isSupplierUser(dispute.getUserType())) {
					mapVO.setOrgRole(StatusConstants.SELLER);
				}
				
				allocMapList.add(mapVO);
			}
		} else if (approverUsers != null && !approverUsers.isEmpty()) {
			for (String user : approverUsers) {
				mapVO = new DisputeAllocationMappingVO();

				mapVO.setDeptId(0);
				mapVO.setUserId(user);
				mapVO.setDisputeRefNo(dispute.getDispRefNo());
				mapVO.setAllocationType(StatusConstants.ALLOC_TYPE_REASSIGNED);
				mapVO.setActive(StatusConstants.YES);
				mapVO.setStatus(StatusConstants.DISPUTE_PENDING);
				
				if (isBuyerUser(dispute.getUserType())) {
					mapVO.setOrgRole(StatusConstants.BUYER);
				} else if (isSupplierUser(dispute.getUserType())) {
					mapVO.setOrgRole(StatusConstants.SELLER);
				}
				
				allocMapList.add(mapVO);
			}
		}
		disputeMgmtDao.insertDisputeAllocationMapping(allocMapList);
	}
	
	private List<Integer> getDeptIdList(
			DisputeVO dispute) throws BNPApplicationException {
		return disputeMgmtDao.getDeptIdList(dispute);
	}
	
	private boolean isBuyercentricModel(
			String buyerOrgId) throws BNPApplicationException {
		return disputeMgmtDao.isBuyercentricModel(buyerOrgId);
	}
	
	@Override
	public List<DisputeCodeVO> getResolutionCodeList(DisputeVO dispute)
			throws BNPApplicationException {
		DisputeCodeVO codeVO = new DisputeCodeVO();
		
		String custOrgId = null;
		if (isBuyercentricModel(dispute.getEippInvoice().getBuyerOrgId())) {
			custOrgId = dispute.getEippInvoice().getBuyerOrgId();
		} else {
			custOrgId = dispute.getEippInvoice().getSupplierOrgId();
		}
		codeVO.setCustOrgId(custOrgId);
		codeVO.setBillType(dispute.getBillType());
		codeVO.setCodeType(StatusConstants.DISPUTE_RESOLUTION_CODE);
		
		return disputeCodeService.getDisputeCodeList(codeVO);
	}
	
	public EippInvoiceVO getInvoiceDetail(long invoiceId) 
			throws BNPApplicationException {		
		return  disputeMgmtDao.getInvoiceDetails(invoiceId);		
	}
	
	public List<DisputeAllocationMappingVO> getExistingAssignees(
			DisputeVO dispute) throws BNPApplicationException {
		return disputeMgmtDao.getExistingAssignees(dispute);
	}

	@Override
	public List<String> getAvailableDepartments(DisputeVO dispute)
			throws BNPApplicationException {
		return disputeMgmtDao.getAvailableDepartments(dispute);
	}

	@Override
	public List<String> getAvailableUsers(DisputeVO dispute) 
			throws BNPApplicationException {
		return disputeMgmtDao.getAvailableUsers(dispute);
	}

	@Override
	public List<NameValueVO> getEippSupplierOrgs(String userId)
			throws BNPApplicationException {
		return cacheService.getSuppOrgsForNonFinProcessing(userId);
	}

	@Override
	public List<NameValueVO> getEippBuyerOrgs(String userId)
			throws BNPApplicationException {
		return cacheService.getBuyerOrgsForNonFinProcessing(userId);
	}

	@Override
	public List<AttachmentVO> getAttachmentDetails(DisputeVO dispute)
			throws BNPApplicationException {
		return disputeMgmtDao.getAttachmentDetails(dispute);
	}

	@Override
	public List<EippAuditVO> getInvoiceAuditDetails(long invId)
			throws BNPApplicationException {
		return invoiceService.getInvoiceAuditDetails(invId);
	}

	@Override
	public List<String> getDisputeStatusList() throws BNPApplicationException {
		return cacheService.getDisputeStatusList();
	}

	@Override
	public List<DisputeVO> getDisputeDetailSummary(long invId)
			throws BNPApplicationException {
		return disputeMgmtDao.getDisputeDetailSummary(invId);
	}
	
	
	private void insertSupplierEventLog(DisputeVO dispute, 
				EventType eventType) {

		EventLogVO eventVO = new EventLogVO();
		
		try {
			eventVO.setReferenceKey(String.valueOf(dispute.getDispRefNo()));
			eventVO.setEventType(eventType);
			eventVO.setSellerOrgId(dispute.getEippInvoice().getSupplierOrgId());
			if(!eventType.equals(EventType.EIPP_INV_DISPUTE)){
				eventDelegateImpl.initEmailEvent(eventVO);
			}
			else{
				eventVO.setInvId(dispute.getEippInvoice().getInvId());
				eventDelegateImpl.initEmailERPEvent(eventVO);
			}
		} catch (BNPApplicationException e) {
			LOGGER.error("Error while raising event log : " + e );
		}
	}
	
	private void insertBuyerEventLog(DisputeVO dispute, 
			EventType eventType) {
		EventLogVO eventVO = new EventLogVO();
		 
		try {
			eventVO.setReferenceKey(String.valueOf(dispute.getDispRefNo()));
			eventVO.setEventInitiator(dispute.getCurrentUserId());
			eventVO.setEventType(eventType);		
			eventVO.setBuyerOrgId(dispute.getEippInvoice().getBuyerOrgId());
			eventVO.setInvId(dispute.getEippInvoice().getInvId());
			eventDelegateImpl.initEvents(eventVO);
		
		} catch (BNPApplicationException e) {
			LOGGER.error("Error while raising event log : " + e );
		}
	}
	
	private String getInvStatus(long invId) throws BNPApplicationException {
		EippInvoiceVO invoice = invoiceService.getInvoiceDetails(invId);
		return invoice.getInvStatus();
	}
	
	private void createInvoiceAudit(DisputeVO dispute, String action,
			List<Long> lineItemList) {
		EippAuditVO invAudit = new EippAuditVO();
		try {
			invAudit.setDisputeStatus(dispute.getDispStatus());
			invAudit.setStatus(getInvStatus(dispute.getEippInvoice().getInvId()));
			invAudit.setAction(action);
			invAudit.setAuditUser(dispute.getCurrentUserId());
			invAudit.setInvId(dispute.getEippInvoice().getInvId());
			if( 0L == dispute.getEippInvoice().getDeptIdForAudit() ){
				List<Long> deptIdList =  disputeMgmtDao.getDeptIdForSupplier(dispute);
				if( deptIdList != null && !deptIdList.isEmpty() ){
					invAudit.setDeptPKId(deptIdList.get(0));
				}
			}else{
				invAudit.setDeptPKId(dispute.getEippInvoice().getDeptIdForAudit());
			}
			
			invoiceService.createInvoiceAudit(invAudit);
			if(EippAuditConstants.INV_DISPUTE_PENDING_APPROVAL.equals(action)
			&& 	!isDisputeAtInvoiceLevel(dispute)){
				createInvLineItemAudit(invAudit,lineItemList);
			}
		} catch (BNPApplicationException e) {
			LOGGER.error("Error while inserting invoice audit " + e.getErrorCode());
		}
	}
	
	private void createInvLineItemAudit(EippAuditVO auditVO,List<Long> lineItemList) 
		throws BNPApplicationException{
		
		if(lineItemList!=null)
		{
			for (Long lineItemId : lineItemList ) {
				auditVO.setLineItemId(lineItemId);
				invoiceService.createInvLineItemAudit(auditVO);
			}
		}
		
	}
	
	private void getDeptId(EippInvoiceVO invoiceVO) throws BNPApplicationException {
		invoiceVO.setChangedStatus(StatusConstants.EIPP_DEPT_APPR_PENDING);
		List<Long> deptIds = invoiceService.getDeptIds(invoiceVO);
		
		if( deptIds != null && !deptIds.isEmpty()){
			invoiceVO.setDeptIdForAudit(deptIds.get(0));
		}
		
	}
	
	private DisputeAuditVO createDisputeAudit(DisputeVO dispute, String action, List<Long> lineItemList) {
		DisputeAuditVO audit = new DisputeAuditVO();
		
		audit.setDispRefNo(dispute.getDispRefNo());
		audit.setUserId(dispute.getCurrentUserId());
		audit.setAction(action);
		audit.setDisputeStatus(dispute.getDispStatus());
		
		try {
			createInvoiceAudit(dispute, action,lineItemList);
			disputeMgmtDao.insertDisputeAudit(audit);
		} catch (BNPApplicationException e) { 
			LOGGER.error("Error while inserting dispute audit " + e.getErrorCode());
		}
		return audit;
	}
	
	private boolean isDisputeAtInvoiceLevel(DisputeVO dispute) {
		if (dispute.getDisputedAt().equals(
				StatusConstants.DISPUTED_AT_INVOICE_LEVEL)) {
			return true;
		}
		return false;
	}

	@Override
	public int getDisputeRaisedCountForFile(long fileId,String fileStatus)throws BNPApplicationException {
		NameValueVO params=new NameValueVO();
		params.setPkId(fileId);
		params.setParam1(fileStatus);
		return disputeMgmtDao.getDisputeRaisedCountForFile(params); 
	}

	@Override
	public int getDisputeResolvedCountForFile(long fileId,String fileStatus)throws BNPApplicationException {
		NameValueVO params=new NameValueVO();
		params.setPkId(fileId);
		params.setParam1(fileStatus);
		return disputeMgmtDao.getDisputeResolvedCountForFile(params);
	}

	@Override
	public List<DisputeVO> getRaiseDisputeRecordDetails(long fileId,String fileStatus)throws BNPApplicationException {
		NameValueVO params=new NameValueVO();
		params.setPkId(fileId);
		params.setParam1(fileStatus);
		return disputeMgmtDao.getRaiseDisputeRecordDetails(params); 
	}

	@Override
	public List<DisputeVO> getDisputeResolvedRecordDetails(long fileId,String fileStatus)throws BNPApplicationException {
		NameValueVO params=new NameValueVO();
		params.setPkId(fileId);
		params.setParam1(fileStatus); 
		return disputeMgmtDao.getDisputeResolvedRecordDetails(params); 
	}
	
	@Override
	public List<EippCustFieldsVO> getInvoiceCustFields(long invoiceId)
			throws BNPApplicationException {
		
		return disputeMgmtDao.getInvoiceCustFields(invoiceId);  
	}
}
