/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   06 Aug 2012
 * 
 * Purpose:      PymtPrepFileDAOImpl - It is used only for payment preparation MFU
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 06 Aug 2012       Oracle Financial Services Software Ltd                  Initial Version
 * 15 Oct 2012						Gangadharan R							 Fix for ST defects
************************************************************************************************************************************************************/

package com.bnp.eipp.services.dao.payment.preparation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.invoice.vo.EippCreditNoteVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.vo.payment.EippPymtVO;
import com.bnp.eipp.services.vo.payment.PymtAdjustMentCodeVO;
import com.bnp.scm.services.admin.vo.SupplierAccountVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;

/**
 * The Class PymtPrepFileDAOImpl.
 */
@Component 
public class PymtPrepFileDAOImpl extends SqlMapClientWrapper implements IPymtPrepFileDAO {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(PymtPrepFileDAOImpl.class);
	
	/** The Constant NAMESPACE. */
	private static final String NAMESPACE="PaymentOperationNS";
	
	/** The Constant IS_VALID_BUYER_ACCT_ID. */
	private static final String IS_VALID_BUYER_ACCT_ID = "checkValidBuyerAcctId";
	
	/** The Constant IS_VALID_SUPPLIER_ACCT_ID. */
	private static final String IS_VALID_SUPPLIER_ACCT_ID = "checkValidSupplierAcctId";
	
	/** The Constant GET_CN_AVAIL_AMT. */
	private static final String GET_CN_AVAIL_AMT = "getCreditNoteAvailAmt";
	
	/** The Constant CHECK_MULTI_PAID_INVOICE. */
	private static final String CHECK_MULTI_PAID_INVOICE = "checkMultiPaidInvoice";
	
	/** The Constant GET_PYMT_REF_NO. */
	private static final String GET_PYMT_REF_NO = "getPymtRefNO";
	
	/** The Constant GET_PYMT_ID. */
	private static final String GET_PYMT_ID = "getPymtID";
	
	/** The Constant GET_PYMT_PREP_TRANS_REC. */
	private static final String GET_PYMT_PREP_TRANS_REC = "getPaymentPrepTransRecord";
	
	/** The Constant GET_PYMT_PREP_REC. */
	private static final String GET_PYMT_PREP_REC = "getPaymentPrepRecord";
	
	/** The Constant GET_PYMT_INV_REC. */
	private static final String GET_PYMT_INV_REC = "getPaymentInvoiceRecord";
	
	/** The Constant GET_LN_ITEM_DETAIL. */
	private static final String GET_LN_ITEM_DETAIL = "getLineItemDetailsMFU";
	
	/* Payment details */
	/** The Constant INSERT_PYMT_DTL_HIST. */
	private static final String INSERT_PYMT_DTL_HIST = "insertPymtHistFromTrans";
	
	/** The Constant INSERT_PYMT_DTL. */
	private static final String INSERT_PYMT_DTL = "insertPymtMasterFromTrans";

	/* Invoice mapping */
	/** The Constant INSERT_INV_DTL_HIST. */
	private static final String INSERT_INV_DTL_HIST = "insertInvPymtMapHist";
	
	/** The Constant INSERT_INV_DTL. */
	private static final String INSERT_INV_DTL = "insertInvPymtMapMaster";

	/* Payment Credit Note */
	/** The Constant INSERT_CN_DTL_HIST. */
	private static final String INSERT_CN_DTL_HIST = "insertPymtCredNoteMapHist";
	
	/** The Constant INSERT_CN_DTL. */
	private static final String INSERT_CN_DTL = "insertPymtCredNoteMapMaster";

	/* Payment Adjustment */
	/** The Constant INSERT_PYMT_ADJ_DTL_HIST. */
	private static final String INSERT_PYMT_ADJ_DTL_HIST = "insertPymtAdjMapHist";
	
	/** The Constant INSERT_PYMT_ADJ_DTL. */
	private static final String INSERT_PYMT_ADJ_DTL = "insertPymtAdjMapMaster";

	/* Split Payment */
	/** The Constant INSERT_SPLIT_PYMT_DTL_HIST. */
	private static final String INSERT_SPLIT_PYMT_DTL_HIST = "insertSplitPymtMapHist";
	
	/** The Constant INSERT_SPLIT_PYMT_DTL. */
	private static final String INSERT_SPLIT_PYMT_DTL = "insertSplitPymtMapMaster";

	/* Invoice Line Items */
	/** The Constant INSERT_LINE_ITEM_DTL_HIST. */
	private static final String INSERT_LINE_ITEM_DTL_HIST = "insertLnItemPymtMapHist";
	
	/** The Constant INSERT_LINE_ITEM_DTL. */
	private static final String INSERT_LINE_ITEM_DTL = "insertLnItemPymtMap";

	/* Custom Fields */
	/** The Constant INSERT_CUST_FLD_DTL_HIST. */
	private static final String INSERT_CUST_FLD_DTL_HIST = "insertPymtCustFldMapHist";
	
	/** The Constant INSERT_CUST_FLD_DTL. */
	private static final String INSERT_CUST_FLD_DTL = "insertPymtCustFldMapMaster";	
		
	/** The Constant UPDATE_PYMT_STATUS. */
	private static final String UPDATE_PYMT_STATUS = "updatePymtStatusInTrans";
	
	/** The Constant DELETE_PYMT_TRANS. */
	private static final String DELETE_PYMT_TRANS = "deletePymtPrepFromTrans";
	
	/** The Constant DELETE_INV_TRANS. */
	private static final String DELETE_INV_TRANS = "deleteInvFromTrans";
	
	/** The Constant DELETE_INV_LN_ITEM_TRANS. */
	private static final String DELETE_INV_LN_ITEM_TRANS = "deleteInvLnItemFromTrans";
	
	/** The Constant DELETE_PYMT_CN_TRANS. */
	private static final String DELETE_PYMT_CN_TRANS = "deletePymtCNFromTrans";
	
	/** The Constant DELETE_PYMT_ADJ_TRANS. */
	private static final String DELETE_PYMT_ADJ_TRANS = "deletePymtAdjFromTrans";
	
	/** The Constant DELETE_SPLIT_PYMT_TRANS. */
	private static final String DELETE_SPLIT_PYMT_TRANS = "deleteSplitPymtFromTrans";
	
	/** The Constant DELETE_CUST_FLD_TRANS. */
	private static final String DELETE_CUST_FLD_TRANS = "deleteCustFldFromTrans";
	
	/** The Constant CHECK_PYMT_ADJ_CODE_VALID. */
	private static final String CHECK_PYMT_ADJ_CODE_VALID = "checkPmtAdjCodeDetails";
	
	/** The payment status. */
	private String paymentStatus;
	
	/**
	 * Instantiates a new pymt prep file dao impl.
	 */
	public PymtPrepFileDAOImpl(){
		nameSpace = NAMESPACE;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.filemgmt.IEippAbstractFileReleaseDAO#insertFileDetailsIntoMaster(com.bnp.scm.services.filemgmt.vo.FileDetailsVO)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void insertFileDetailsIntoMaster(FileDetailsVO detailsVO)
			throws DBException {
		LOGGER.debug("In PymtPrepDAOImpl insertFileDetailsIntoMaster - Starts");
		List<EippPymtVO> pymtPrepList = null;
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_PYMT_DTL), 
					detailsVO.getFileId());
			pymtPrepList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_PYMT_PREP_TRANS_REC), 
					detailsVO.getFileId());

			LOGGER.debug("Inserting record into child tables");
			
			if(pymtPrepList != null){
				for(EippPymtVO pymtPrepVO : pymtPrepList){
					//Insert invoice details
					insertPymtInvDetail(pymtPrepVO, INSERT_INV_DTL);
		
					//Insert invoice line item details
					insertInvLineItem(pymtPrepVO, INSERT_LINE_ITEM_DTL);
					
					//Insert payment level credit note details
					insertPymtCredNote(pymtPrepVO, INSERT_CN_DTL);
					
					//Insert payment adjustment details
					insertPymtAdjDetail(pymtPrepVO, INSERT_PYMT_ADJ_DTL);
					
					//Insert split payment details
					insertSplitPymt(pymtPrepVO, INSERT_SPLIT_PYMT_DTL);
					
					//Insert custom fields details
					insertCustFields(pymtPrepVO, INSERT_CUST_FLD_DTL);
				}
			}

		} catch (DataAccessException e) {
			LOGGER.error("in PymtPrepDAOImpl insertFileDetailsIntoMaster - exception : ", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		} catch (BNPApplicationException e) {
			LOGGER.error("in PymtPrepDAOImpl insertFileDetailsIntoMaster - bnpappexception : ", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);			
		}
		LOGGER.debug("In PymtPrepDAOImpl insertFileDetailsIntoMaster - Ends");
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPrepFileDAO#insertPymtPrepHistDetails(com.bnp.scm.services.filemgmt.vo.FileDetailsVO, com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public void insertPymtPrepHistDetails(FileDetailsVO detailsVO,
			EippPymtVO pymtPrepVO) throws BNPApplicationException {
		try {
			if(pymtPrepVO != null && pymtPrepVO.getCustPymtStatus() != null){
				paymentStatus = pymtPrepVO.getCustPymtStatus();
			}
			insertFileDetailsIntoHistFromTrans(detailsVO);		
			paymentStatus = null;
		} catch (DataAccessException e) {
			LOGGER.error("in PymtPrepDAOImpl insertPymtPrepHistDetails - exception : ", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.filemgmt.IEippAbstractFileReleaseDAO#insertFileDetailsIntoHistFromTrans(com.bnp.scm.services.filemgmt.vo.FileDetailsVO)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void insertFileDetailsIntoHistFromTrans(FileDetailsVO detailsVO)
			throws DBException {
		List<EippPymtVO> pymtPrepList = null;
		LOGGER.debug("In PymtPrepDAOImpl insertFileDetailsIntoHistFromTrans - Starts");
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_PYMT_DTL_HIST), 
					detailsVO.getFileId());
			pymtPrepList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_PYMT_PREP_TRANS_REC), 
					detailsVO.getFileId());

			LOGGER.debug("Inserting record into child tables");
			
			if(pymtPrepList != null){
				for(EippPymtVO pymtPrepVO : pymtPrepList){
					//Insert invoice details
					insertPymtInvDetail(pymtPrepVO, INSERT_INV_DTL_HIST);
		
					//Insert invoice line item details
					insertInvLineItem(pymtPrepVO, INSERT_LINE_ITEM_DTL_HIST);
					
					//Insert payment level credit note details
					insertPymtCredNote(pymtPrepVO, INSERT_CN_DTL_HIST);
					
					//Insert payment adjustment details
					insertPymtAdjDetail(pymtPrepVO, INSERT_PYMT_ADJ_DTL_HIST);
					
					//Insert split payment details
					insertSplitPymt(pymtPrepVO, INSERT_SPLIT_PYMT_DTL_HIST);
					
					//Insert custom fields details
					insertCustFields(pymtPrepVO, INSERT_CUST_FLD_DTL_HIST);
				}
			}

		} catch (DataAccessException e) {
			LOGGER.error("in PymtPrepDAOImpl insertFileDetailsIntoHistFromTrans - exception : ", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		} catch (BNPApplicationException e) {
			LOGGER.error("in PymtPrepDAOImpl insertFileDetailsIntoHistFromTrans - bnpappexception : ", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);			
		}
		LOGGER.debug("In PymtPrepDAOImpl insertFileDetailsIntoHistFromTrans - Ends");
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.filemgmt.IEippAbstractFileReleaseDAO#insertFileDetailsIntoHistFromMaster(com.bnp.scm.services.filemgmt.vo.FileDetailsVO)
	 */
	@Override
	public void insertFileDetailsIntoHistFromMaster(FileDetailsVO detailsVO)
			throws DBException {
		insertFileDetailsIntoHistFromTrans(detailsVO);
	}	
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPrepFileDAO#isValidBuyerAcctIdentifier(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public boolean isValidBuyerAcctIdentifier(EippPymtVO pymtPrepVO)
			throws BNPApplicationException {
		int buyerAcctIdCount = 0;
		try{
			buyerAcctIdCount = (Integer) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(
					IS_VALID_BUYER_ACCT_ID), pymtPrepVO);
			
			if(buyerAcctIdCount > 0){
				return true;
			}
		}catch(DataAccessException e){
			LOGGER.error("in PymtPrepDAOImpl isValidBuyerAcctIdentifier - exception :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}

		return false;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPrepFileDAO#isValidSupplierAcctIdentifier(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean isValidSupplierAcctIdentifier(EippPymtVO pymtPrepVO)
			throws BNPApplicationException {
		SupplierAccountVO suppAccountVO = null;
		int supplierAcctIdCount = 0;
		try{
			
			 suppAccountVO = (SupplierAccountVO)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(
						IS_VALID_SUPPLIER_ACCT_ID), pymtPrepVO);
			
			 if(suppAccountVO != null){
				 String invAccountId = suppAccountVO.getAccountIdentifier();
				 String defAccountId = suppAccountVO.getAccountNumber();
				 String accountIdCount = suppAccountVO.getMasterNumber(); 
				//Check the invoice level account identifier
				if(pymtPrepVO.getSupplierAcctIdentifier().equalsIgnoreCase(invAccountId)){
					return true;
				}else{
					if(invAccountId != null && invAccountId.trim().length() > 0){
						return false;
					}
				}
				
				//Check the default level account identifier				
				if(pymtPrepVO.getSupplierAcctIdentifier().equalsIgnoreCase(defAccountId)){
					return true;
				}else{
					if(defAccountId != null && defAccountId.trim().length() > 0){
						return false;
					}
				}

				//Check the organization level account identifier
				supplierAcctIdCount = Integer.parseInt(accountIdCount);				
				if(supplierAcctIdCount > 0){
					return true;
				}				
			}			
		}catch(DataAccessException e){
			LOGGER.error("in PymtPrepDAOImpl isValidSupplierAcctIdentifier - exception :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}

		return false;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPrepFileDAO#getCreditNoteAvailAmt(com.bnp.eipp.services.invoice.vo.EippCreditNoteVO)
	 */
	@Override
	public EippCreditNoteVO getCreditNoteAvailAmt(EippCreditNoteVO creidtNoteVO)
			throws BNPApplicationException {
		try{
			return  (EippCreditNoteVO) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(
					GET_CN_AVAIL_AMT), creidtNoteVO);
		}catch(DataAccessException e){
			LOGGER.error("in PymtPrepDAOImpl getCreditNoteAvailAmt - exception :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}

	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPrepFileDAO#getPaymentRefNo(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@Override
	public String getPaymentRefNo(EippPymtVO pymtPrepVO) throws BNPApplicationException {
		String pymtRefNo = null;
		try{
			pymtRefNo = (String) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(
					GET_PYMT_REF_NO),
					pymtPrepVO);
		}catch(DataAccessException e){
			LOGGER.error("in PymtPrepDAOImpl getPaymentRefNo - exception :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return pymtRefNo;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPrepFileDAO#getPaymentID()
	 */
	@Override
	public long getPaymentID() throws BNPApplicationException {
		long pymtId = 0;
		try{
			pymtId = (Long) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_PYMT_ID));
		}catch(DataAccessException e){
			LOGGER.error("in PymtPrepDAOImpl getPaymentID - exception :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return pymtId;

	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPrepFileDAO#getPaymentPrepRecords(com.bnp.scm.services.filemgmt.vo.FileDetailsVO)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<EippPymtVO> getPaymentPrepRecords(FileDetailsVO detailsVO) 
		throws BNPApplicationException {
		List<EippPymtVO> pymtPrepList = null;
		try{
			pymtPrepList = (List<EippPymtVO>) getSqlMapClientTemplate().queryForList(
					getQueryNameWithNameSpace(GET_PYMT_PREP_REC), detailsVO.getFileId());
		}catch(DataAccessException e){
			LOGGER.error("in PymtPrepDAOImpl getPaymentPrepRecord - exception :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return pymtPrepList;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPrepFileDAO#getPaymentInvoiceRecords(com.bnp.eipp.services.vo.payments.preparation.EippPymtVO)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<EippInvoiceVO> getPaymentInvoiceRecords(EippPymtVO pymtPrepVO) 
		throws BNPApplicationException {
		List<EippInvoiceVO> pymtInvList = null;
		try{
			pymtInvList = (List<EippInvoiceVO>) getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(
					GET_PYMT_INV_REC), pymtPrepVO);
		}catch(DataAccessException e){
			LOGGER.error("in PymtPrepDAOImpl getPaymentInvoiceRecords - exception :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return pymtInvList;
	}
	

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPrepFileDAO#checkMultiPaidInvoice(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public boolean checkMultiPaidInvoice(EippInvoiceVO invoiceVO)
			throws BNPApplicationException {
		int multiPaidInvoice = 0;
		try{
			multiPaidInvoice = (Integer) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(
					CHECK_MULTI_PAID_INVOICE), invoiceVO);
			
			if(multiPaidInvoice > 0){
				return true;
			}
		}catch(DataAccessException e){
			LOGGER.error("in PymtPrepDAOImpl checkMultiPaidInvoice - exception :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}

		return false;
	}

	/**
	 * Insert pymt inv detail.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @param queryName the query name
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void insertPymtInvDetail(EippPymtVO eippPymtVO, String queryName) throws BNPApplicationException{
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(queryName), 
					eippPymtVO);
		} catch (DataAccessException e) {
			LOGGER.error("in PymtPrepDAOImpl insertPymtInvDetail - exception : ", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}		
	}
	
	/**
	 * Insert inv line item.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @param queryName the query name
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void insertInvLineItem(EippPymtVO eippPymtVO, String queryName) throws BNPApplicationException{
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(queryName), 
					eippPymtVO);
		} catch (DataAccessException e) {
			LOGGER.error("in PymtPrepDAOImpl insertInvLineItem - exception : ", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}		
	}
	
	/**
	 * Insert pymt cred note.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @param queryName the query name
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void insertPymtCredNote(EippPymtVO eippPymtVO, String queryName) throws BNPApplicationException{
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(queryName), 
					eippPymtVO);
		} catch (DataAccessException e) {
			LOGGER.error("in PymtPrepDAOImpl insertPymtCredNote - exception : ", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}		
	}

	/**
	 * Insert pymt adj detail.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @param queryName the query name
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void insertPymtAdjDetail(EippPymtVO eippPymtVO, String queryName) throws BNPApplicationException{
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(queryName), 
					eippPymtVO);
		} catch (DataAccessException e) {
			LOGGER.error("in PymtPrepDAOImpl insertPymtAdjDetail - exception : ", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}		
	}
	
	/**
	 * Insert split pymt.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @param queryName the query name
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void insertSplitPymt(EippPymtVO eippPymtVO, String queryName) throws BNPApplicationException{
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(queryName), 
					eippPymtVO);
		} catch (DataAccessException e) {
			LOGGER.error("in PymtPrepDAOImpl insertSplitPymt - exception : ", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}		
	}
	
	/**
	 * Insert cust fields.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @param queryName the query name
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void insertCustFields(EippPymtVO eippPymtVO, String queryName) throws BNPApplicationException{
		try {
			eippPymtVO.setCustPymtStatus(paymentStatus);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(queryName), 
					eippPymtVO);
		} catch (DataAccessException e) {
			LOGGER.error("in PymtPrepDAOImpl insertCustFields - exception : ", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}		
	}	
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.filemgmt.IEippAbstractFileReleaseDAO#deleteFileDetailsFromTrans(com.bnp.scm.services.filemgmt.vo.FileDetailsVO)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void deleteFileDetailsFromTrans(FileDetailsVO detailsVO)
			throws DBException {
		List<EippPymtVO> pymtPrepList = null;

		try {
			pymtPrepList = (List<EippPymtVO>) getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(
					GET_PYMT_PREP_TRANS_REC), detailsVO.getFileId());

			if(pymtPrepList != null){
				for(EippPymtVO pymtPrepVO : pymtPrepList){
					//Deleting child tables
					deleteInvFromTrans(pymtPrepVO, DELETE_INV_TRANS);				
					deleteInvLnItemFromTrans(pymtPrepVO, DELETE_INV_LN_ITEM_TRANS);
					deletePymtCNFromTrans(pymtPrepVO, DELETE_PYMT_CN_TRANS);
					deletePymtAdjFromTrans(pymtPrepVO, DELETE_PYMT_ADJ_TRANS);
					deleteSplitPymtFromTrans(pymtPrepVO, DELETE_SPLIT_PYMT_TRANS);
					deleteCustFldFromTrans(pymtPrepVO, DELETE_CUST_FLD_TRANS);
					
					getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(DELETE_PYMT_TRANS), 
							detailsVO.getFileId());
				}
			}
		} catch (BNPApplicationException e) {
			LOGGER.error("in PymtPrepDAOImpl deleteFileDetailsFromTrans - exception :", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/**
	 * Delete inv from trans.
	 *
	 * @param pymtPrepVO the pymt prep vo
	 * @param queryName the query name
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void deleteInvFromTrans(EippPymtVO pymtPrepVO, String queryName) 
		throws BNPApplicationException{
		try {
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(queryName), 
					pymtPrepVO);

		} catch (DataAccessException e) {
			LOGGER.error("in PymtPrepDAOImpl deleteInvFromTrans - exception :", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/**
	 * Delete inv ln item from trans.
	 *
	 * @param pymtPrepVO the pymt prep vo
	 * @param queryName the query name
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void deleteInvLnItemFromTrans(EippPymtVO pymtPrepVO, String queryName) 
	throws BNPApplicationException{
		try {
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(queryName), 
					pymtPrepVO);
	
		} catch (DataAccessException e) {
			LOGGER.error("in PymtPrepDAOImpl deleteInvLnItemFromTrans - exception :", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}	

	/**
	 * Delete pymt cn from trans.
	 *
	 * @param pymtPrepVO the pymt prep vo
	 * @param queryName the query name
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void deletePymtCNFromTrans(EippPymtVO pymtPrepVO, String queryName) 
	throws BNPApplicationException{
		try {
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(queryName), 
					pymtPrepVO);
	
		} catch (DataAccessException e) {
			LOGGER.error("in PymtPrepDAOImpl deletePymtCNFromTrans - exception :", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}		
	
	/**
	 * Delete pymt adj from trans.
	 *
	 * @param pymtPrepVO the pymt prep vo
	 * @param queryName the query name
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void deletePymtAdjFromTrans(EippPymtVO pymtPrepVO, String queryName) 
	throws BNPApplicationException{
		try {
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(queryName), 
					pymtPrepVO);
	
		} catch (DataAccessException e) {
			LOGGER.error("in PymtPrepDAOImpl deletePymtAdjFromTrans - exception :", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}		

	/**
	 * Delete split pymt from trans.
	 *
	 * @param pymtPrepVO the pymt prep vo
	 * @param queryName the query name
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void deleteSplitPymtFromTrans(EippPymtVO pymtPrepVO, String queryName) 
	throws BNPApplicationException{
		try {
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(queryName), 
					pymtPrepVO);
	
		} catch (DataAccessException e) {
			LOGGER.error("in PymtPrepDAOImpl deleteSplitPymtFromTrans - exception :", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}		

	/**
	 * Delete cust fld from trans.
	 *
	 * @param pymtPrepVO the pymt prep vo
	 * @param queryName the query name
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void deleteCustFldFromTrans(EippPymtVO pymtPrepVO, String queryName) 
	throws BNPApplicationException{
		try {
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(queryName), 
					pymtPrepVO);
	
		} catch (DataAccessException e) {
			LOGGER.error("in PymtPrepDAOImpl deleteCustFldFromTrans - exception :", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}	
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPrepFileDAO#updateRecordStatusInTrans(long, java.lang.String)
	 */
	@Override
	public void updateRecordStatusInTrans(long fileId, String status)
			throws BNPApplicationException {
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("fileId", fileId);
		params.put("status", status);
		
		try{
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_PYMT_STATUS), params);
		} catch (DataAccessException e) {
			LOGGER.error("in PymtPrepDAOImpl updateRecordStatusInTrans - exception :", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}		

	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.IPymtPrepFileDAO#getLineItemDetails(com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO)
	 */
	@Override
	public EippInvCntLineItemVO getLineItemDetails(
			EippInvCntLineItemVO lineItemVO) throws BNPApplicationException {
		try{
			return  (EippInvCntLineItemVO) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(
					GET_LN_ITEM_DETAIL), lineItemVO);
		}catch(DataAccessException e){
			LOGGER.error("in PymtPrepDAOImpl getLineItemDetails - exception :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}		
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.payment.preparation.IPymtPrepFileDAO#checkPmtAdjCodeDetails(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	@Override
	public boolean checkPmtAdjCodeDetails(EippPymtVO pymtPrepVO)
			throws BNPApplicationException {
		int recCount = 0;
		try{
			if(pymtPrepVO.getPymtAdjustmentList() != null && 
					!pymtPrepVO.getPymtAdjustmentList().isEmpty()){
				for (PymtAdjustMentCodeVO pymtAdjVO : pymtPrepVO.getPymtAdjustmentList() ) {
					pymtAdjVO.setSupplierOrgId(pymtPrepVO.getSupplierOrgId());
					if(BNPConstants.ADDITION.equalsIgnoreCase(pymtAdjVO.getCodeType())){
						pymtAdjVO.setCodeType(BNPConstants.ADDITION);	
					}else if(BNPConstants.DEDUCTION.equalsIgnoreCase(pymtAdjVO.getCodeType())){
						pymtAdjVO.setCodeType(BNPConstants.DEDUCTION);	
					}
					
					recCount = (Integer)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(
							CHECK_PYMT_ADJ_CODE_VALID), pymtAdjVO);
					if(recCount == 0){
						return false;
					}
				}
			}
		}catch(DataAccessException e){
			LOGGER.error("in PymtPrepDAOImpl checkPmtAdjCodeDetails - exception :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return true;
	}	
}
