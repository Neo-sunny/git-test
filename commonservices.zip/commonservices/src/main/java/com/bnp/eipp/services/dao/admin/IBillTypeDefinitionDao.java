/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Jan 18, 201210:32:41 AM
 * 
 * Purpose:      Interface declaration for Bill Type Definition DAO Layer
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Jan 18, 201210:32:41 AM        Oracle Financial Services Software Ltd                  Initial Version
 * 21 Mar 2012					  Oracle Financial Services Software Ltd				 Release 2.1 I1				ST fix 5615, 5652, 5603, 5452, 5636, 5593
 * 18 Jul 2012                    Reena 												 Release 3.0	            Changes for EIPP-Phase II  
 * 20 June 2013                   Pratheep												 Release 6.0				For Toolkit changes of Manual work around moved from eipp to common
 ************************************************************************************************************************************************************/
package com.bnp.eipp.services.dao.admin;

import java.util.List;

import com.bnp.eipp.services.vo.admin.BillTypeDefinitionVO;
import com.bnp.eipp.services.vo.admin.BillTypeShortCutsVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

// TODO: Auto-generated Javadoc
/**
 * The Interface IBillTypeDefinitionDao.
 */
public interface IBillTypeDefinitionDao { 

	/**
	 * Gets the bill type details.
	 *
	 * @param searchVO the search vo
	 * @return BillTypeDetails
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<BillTypeDefinitionVO> getBillTypeDetails(BillTypeDefinitionVO searchVO)throws BNPApplicationException;
	
	/**
	 * Gets the organisations list from billtype.
	 *
	 * @param inputVO the input vo
	 * @return OrganisationsList
	 */
	List<NameValueVO> getOrganisationsListFromBilltype(NameValueVO inputVO);
	
	/**
	 * Gets the customer org list for mpoa.
	 *
	 * @param inputVO the input vo
	 * @return OrganisationsList
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getCustomerOrgListForMPOA(NameValueVO inputVO)throws BNPApplicationException;	
	
	/**
	 * Gets the modified record.
	 *
	 * @param orgDiscount the org discount
	 * @return ModifiedRecord
	 * @throws BNPApplicationException the bNP application exception
	 */
	BillTypeDefinitionVO getModifiedRecord(BillTypeDefinitionVO orgDiscount) throws BNPApplicationException;
	
	/**
	 * Gets the customer role name.
	 *
	 * @param orgId the org id
	 * @return the customer role name
	 * @throws BNPApplicationException the bNP application exception
	 */
	NameValueVO getCustomerRoleName(String orgId)throws BNPApplicationException;
	
	/**
	 * Gets the dept list for buyer.
	 *
	 * @param orgId the org id
	 * @return Buyer list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getDeptListForBuyer(String orgId)throws BNPApplicationException;
	
	/**
	 * Gets the dept list for supplier.
	 *
	 * @param orgId the org id
	 * @return Supplier list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getDeptListForSupplier(String orgId)throws BNPApplicationException;
	
	/**
	 * Gets the bill type logo record.
	 *
	 * @param orgId the org id
	 * @return BillTypeShortCutsVO
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<BillTypeShortCutsVO> getBillTypeLogoRecord(String orgId)throws BNPApplicationException;
	
	/**
	 * Gets the bill type style sheet record.
	 *
	 * @param orgId the org id
	 * @return BillTypeShortCutsVO
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<BillTypeShortCutsVO> getBillTypeStyleSheetRecord(String orgId)throws BNPApplicationException;
	
	/**
	 * Gets the branding details record.
	 *
	 * @param orgId the org id
	 * @return BillTypeShortCutsVO
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<BillTypeShortCutsVO> getBrandingDetailsRecord(String orgId)throws BNPApplicationException;
	
	/**
	 * Gets the dispute code record.
	 *
	 * @param orgId the org id
	 * @return BillTypeShortCutsVO
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<BillTypeShortCutsVO> getDisputeCodeRecord(String orgId)throws BNPApplicationException;
	
	/**
	 * Chk record not exists already.
	 *
	 * @param searchVO the search vo
	 * @return number value
	 * @throws BNPApplicationException the bNP application exception
	 */
	int chkRecordNotExistsAlready(BillTypeDefinitionVO searchVO)throws BNPApplicationException;
	
	/**
	 * Chk dependency befor delete.
	 *
	 * @param searchVO the search vo
	 * @return number value
	 * @throws BNPApplicationException the bNP application exception
	 */
	int chkDependencyBeforDelete(BillTypeDefinitionVO searchVO)throws BNPApplicationException;
	
	/**
	 * Gets the child details.
	 *
	 * @param fields the fields
	 * @return the child details
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<String> getChildDetails(BillTypeDefinitionVO fields)throws BNPApplicationException;
	
	/**
	 * This API returns the default department pk_id value
	 * for the given customer org id and bill type.
	 *
	 * @param customerOrgId the customer org id
	 * @param billType the bill type
	 * @return the default department for dispute
	 * @throws BNPApplicationException the bNP application exception
	 */
	long getDefaultDepartmentForDispute(String customerOrgId, String billType)
			throws BNPApplicationException;
	
	/**
	 * Gets the market place org list.
	 *
	 * @param custOrgId the cust org id
	 * @return the market place org list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getMarketPlaceOrgList(String custOrgId) throws BNPApplicationException;

}
