/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 2, 2012
 * 
 * Purpose:      EippCreditNoteVO.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 2, 2012       Oracle Financial Services Software Ltd                  Initial Version
 * 24/04/2012		 Sandhya R												 SIT #2068  
 * 26/10/2012		 Gangadharan R											 Removed the duplicate occurance of disableCheckBox
************************************************************************************************************************************************************/

package com.bnp.eipp.services.invoice.vo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;

import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.txns.util.calendar.DateAdapter;

public class EippCreditNoteVO extends EippTransactionVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = -818278511823899321L;
	
	private long cntId;
	
	private String cntRefNo;
	
	private BigDecimal cntOrgAmt;
	
	private BigDecimal cntUtilAmt;
	
	private String cntUtilAmtCcy;
	
	private BigDecimal subTotAmt;
	
	private String subTotAmtCcy;
	
	private String orgInvRefNo;
	
	private Date orgInvRefDate;
	
	private String orgInvBillType;
	
	private String linkedInvRefNo;
	
	private Date linkedInvRefDate;
	
	private String linkedInvBillType;
	
	private String cntStatus;
	
	private String tempCntStatus;
	
	private Date effectiveDate;
	
	private BigDecimal cntRemAmt;
	
	private Properties utilValues;
	
	private boolean unlinked;

	private Date cntUtilDate;
	
	private String errorMessage;
	
	private List<EippInvCntLineItemVO> lineItemVO= new ArrayList<EippInvCntLineItemVO>();
	
	// added for 3.0 eipp changes
	
	private BigDecimal cntRemAmtTemp;
	
	private BigDecimal totalAmount;
	
	//added for matching
	
	private String shippingTerms;
	
	private List<TaxDtlsVO> taxDtls;
	
	private List<ConsgnmtVO> consgnmtDtls;
	
	private String matchStatus;
	
	private String isManual;

	public String getMatchStatus() {
		return matchStatus;
	}

	public void setMatchStatus(String matchStatus) {
		this.matchStatus = matchStatus;
	}

	/**
	 * @return the unlinked
	 */
	public boolean isUnlinked() {
		return unlinked;
	}

	/**
	 * @param unlinked the unlinked to set
	 */
	public void setUnlinked(boolean unlinked) {
		this.unlinked = unlinked;
	}

	/**
	 * @return the cntId
	 */
	public long getCntId() {
		return cntId;
	}

	/**
	 * @param cntId the cntId to set
	 */
	public void setCntId(long cntId) {
		this.cntId = cntId;
	}

	/**
	 * @return the cntRefNo
	 */
	public String getCntRefNo() {
		return cntRefNo;
	}

	/**
	 * @param cntRefNo the cntRefNo to set
	 */
	public void setCntRefNo(String cntRefNo) {
		this.cntRefNo = cntRefNo;
	}

	/**
	 * @return the cntOrgAmt
	 */
	public BigDecimal getCntOrgAmt() {
		return cntOrgAmt;
	}

	/**
	 * @param cntOrgAmt the cntOrgAmt to set
	 */
	public void setCntOrgAmt(BigDecimal cntOrgAmt) {
		this.cntOrgAmt = cntOrgAmt;
	}

	/**
	 * @return the cntUtilAmt
	 */
	public BigDecimal getCntUtilAmt() {
		return cntUtilAmt;
	}

	/**
	 * @param cntUtilAmt the cntUtilAmt to set
	 */
	public void setCntUtilAmt(BigDecimal cntUtilAmt) {
		this.cntUtilAmt = cntUtilAmt;
	}

	/**
	 * @return the orgInvRefNo
	 */
	public String getOrgInvRefNo() {
		return orgInvRefNo;
	}

	/**
	 * @param orgInvRefNo the orgInvRefNo to set
	 */
	public void setOrgInvRefNo(String orgInvRefNo) {
		this.orgInvRefNo = orgInvRefNo;
	}

	/**
	 * @return the orgInvRefDate
	 */
	public Date getOrgInvRefDate() {
		return orgInvRefDate;
	}

	/**
	 * @param orgInvRefDate the orgInvRefDate to set
	 */
	public void setOrgInvRefDate(Date orgInvRefDate) {
		this.orgInvRefDate = orgInvRefDate;
	}

	/**
	 * @return the orgInvBillType
	 */
	public String getOrgInvBillType() {
		return orgInvBillType;
	}

	/**
	 * @param orgInvBillType the orgInvBillType to set
	 */
	public void setOrgInvBillType(String orgInvBillType) {
		this.orgInvBillType = orgInvBillType;
	}

	/**
	 * @return the linkedInvRefNo
	 */
	public String getLinkedInvRefNo() {
		return linkedInvRefNo;
	}

	/**
	 * @param linkedInvRefNo the linkedInvRefNo to set
	 */
	public void setLinkedInvRefNo(String linkedInvRefNo) {
		this.linkedInvRefNo = linkedInvRefNo;
	}

	/**
	 * @return the linkedInvRefDate
	 */
	public Date getLinkedInvRefDate() {
		return linkedInvRefDate;
	}

	/**
	 * @param linkedInvRefDate the linkedInvRefDate to set
	 */
	public void setLinkedInvRefDate(Date linkedInvRefDate) {
		this.linkedInvRefDate = linkedInvRefDate;
	}

	/**
	 * @return the linkedInvBillType
	 */
	public String getLinkedInvBillType() {
		return linkedInvBillType;
	}

	/**
	 * @param linkedInvBillType the linkedInvBillType to set
	 */
	public void setLinkedInvBillType(String linkedInvBillType) {
		this.linkedInvBillType = linkedInvBillType;
	}

	/**
	 * @return the cntStatus
	 */
	public String getCntStatus() {
		return cntStatus;
	}

	/**
	 * @param cntStatus the cntStatus to set
	 */
	public void setCntStatus(String cntStatus) {
		this.cntStatus = cntStatus;
	}

	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * @param cntRemAmt the cntRemAmt to set
	 */
	public void setCntRemAmt(BigDecimal cntRemAmt) {
		this.cntRemAmt = cntRemAmt;
	}

	public String getIsManual() {
		return isManual;
	}

	public void setIsManual(String isManual) {
		this.isManual = isManual;
	}

	public String getShippingTerms() {
		return shippingTerms;
	}

	public void setShippingTerms(String shippingTerms) {
		this.shippingTerms = shippingTerms;
	}

	public List<TaxDtlsVO> getTaxDtls() {
		return taxDtls;
	}

	public void setTaxDtls(List<TaxDtlsVO> taxDtls) {
		this.taxDtls = taxDtls;
	}

	public List<ConsgnmtVO> getConsgnmtDtls() {
		return consgnmtDtls;
	}

	public void setConsgnmtDtls(List<ConsgnmtVO> consgnmtDtls) {
		this.consgnmtDtls = consgnmtDtls;
	}

	/**
	 * @return the cntRemAmt
	 */
	public BigDecimal getCntRemAmt() {
		return cntRemAmt;
	}
	
	public String getTransactionType() {
		return "CNT";
	}
	
	public String getRefNo(){
		return cntRefNo;
	}
	
	public String toDataString()
	{
		DateAdapter adapter = new DateAdapter();
		Calendar calendar = Calendar.getInstance();
		StringBuilder builder = new StringBuilder();
		builder.append(getTransactionType() + ",");
		builder.append( getRefNo() + ",");
		builder.append( getBillType() + ",");
		if(effectiveDate != null) {
			calendar.setTime(effectiveDate);
			builder.append( adapter.marshal(calendar)+ ",");
		} 
		else {
			builder.append(",");
		}
		builder.append( getCcyCode() + ",");
		builder.append( getBuyerOrgId() + ",");
		builder.append( getSupplierOrgId() + ",");
		builder.append( getCntOrgAmt() + ",");
		return builder.toString();
	}

	/**
	 * @param cntUtilAmtCcy the cntUtilAmtCcy to set
	 */
	public void setCntUtilAmtCcy(String cntUtilAmtCcy) {
		this.cntUtilAmtCcy = cntUtilAmtCcy;
	}

	/**
	 * @return the cntUtilAmtCcy
	 */
	public String getCntUtilAmtCcy() {
		return cntUtilAmtCcy;
	}

	/**
	 * @param subTotAmt the subTotAmt to set
	 */
	public void setSubTotAmt(BigDecimal subTotAmt) {
		this.subTotAmt = subTotAmt;
	}

	/**
	 * @return the subTotAmt
	 */
	public BigDecimal getSubTotAmt() {
		return subTotAmt;
	}

	/**
	 * @param subTotAmtCcy the subTotAmtCcy to set
	 */
	public void setSubTotAmtCcy(String subTotAmtCcy) {
		this.subTotAmtCcy = subTotAmtCcy;
	}

	/**
	 * @return the subTotAmtCcy
	 */
	public String getSubTotAmtCcy() {
		return subTotAmtCcy;
	}

	
	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/******************************* Utility methods ***************************************/
	
	public boolean checkPartialUtilization() {
		if (!canUtilizePartially()) {
			this.setErrorMessage(
				BNPConstants.EIPP_CN_PARTIAL_UTIL_NOT_ALLOWED);
			checkOrgUnlikedFlag();
			checkToRejectCrdNote();
			return false;
		}
		return true;
	}
	
	public void updateUtilizationDetails(BigDecimal amtToBeUtilized) {
		if (amtToBeUtilized.compareTo(this.getCntRemAmt()) >= 0) {
			this.setCntStatus(StatusConstants.EIPP_CN_FULLY_UTILIZED);
			this.setCntRemAmt(BigDecimal.ZERO);
		} else if (amtToBeUtilized.compareTo(this.getCntRemAmt()) < 0) {
			this.setCntRemAmt(getCntRemAmt().subtract(amtToBeUtilized));
			if (!checkOrgUnlikedFlag()) {
				this.setCntStatus(StatusConstants.EIPP_CN_FULLY_UTILIZED);
			}
		}
		
		if (this.getCntUtilAmt() == null) {
			this.setCntUtilAmt(amtToBeUtilized);
		} else {
			this.setCntUtilAmt(amtToBeUtilized.add(this.getCntUtilAmt()));
		}
	}
	
	public boolean canUtilizePartially() {
		return utilValues.get("allowPartialUtilize").equals
		(StatusConstants.ALLOW_PARTIAL_UTILIZE);
	}
	
	public boolean checkOrgUnlikedFlag() {
		if( utilValues.get("applyLCN").equals
		(StatusConstants.CONVERT_TO_UNLINKED)){
			this.setCntStatus(StatusConstants.EIPP_CN_AVAILABLE);
			this.setUnlinked(true);
			return true;
		}else{
			return false;
		}
	}
	
	public boolean checkToRejectCrdNote() {
		if(utilValues.get("applyLCN").equals
		(StatusConstants.CAN_REJECT_CREDIT_NOTE)){
			this.setCntStatus(StatusConstants.REJECT);
			return true;
		}else{
			return false;
		}
	}
	
	public void setUtilParams(Properties values) {
		this.utilValues = values;
	}

	/**
	 * @return the cntUtilDate
	 */
	public Date getCntUtilDate() {
		return cntUtilDate;
	}

	
	/**
	 * @param cntUtilDate the cntUtilDate to set
	 */
	public void setCntUtilDate(Date cntUtilDate) {
		this.cntUtilDate = cntUtilDate;
    }

	public List<EippInvCntLineItemVO> getLineItemVO() {
		return lineItemVO;
	}

	public void setLineItemVO(List<EippInvCntLineItemVO> lineItemVO) {
		this.lineItemVO = lineItemVO;
	}

	public void setCntRemAmtTemp(BigDecimal cntRemAmtTemp) {
		this.cntRemAmtTemp = cntRemAmtTemp;
	}

	public BigDecimal getCntRemAmtTemp() {
		return cntRemAmtTemp;
	}

	/**
	 * @param totalAmount the totalAmount to set
	 */
	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}

	/**
	 * @return the totalAmount
	 */
	public BigDecimal getTotalAmount() {
		return totalAmount;
	}

	public void setTempCntStatus(String tempCntStatus) {
		this.tempCntStatus = tempCntStatus;
	}

	public String getTempCntStatus() {
		return tempCntStatus;
	}
	
	public boolean isCNUtilizedAgainstInvalidInvoice(EippInvoiceVO invoice) {
		boolean status = false;
		
		if (invoice == null) {
			this.setErrorMessage(BNPConstants.EIPP_INV_NOT_AVAILABLE);
			status = true;
		} else if (!invoice.canUtilizeCN(
					this, TimeZone.getDefault())) {
			this.setErrorMessage(BNPConstants.EIPP_INV_ISSUE_DATE_BEFORE_EFF_DATE);
			status = true;
		} else {
			String errorMessage = invoice.checkForValidInvoice();
		
			if (errorMessage != null) {
				this.setErrorMessage(errorMessage);
				status = true;
			}
		}
		return status;
	}
}
