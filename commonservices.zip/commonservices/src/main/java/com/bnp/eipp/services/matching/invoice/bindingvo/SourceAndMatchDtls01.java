package com.bnp.eipp.services.matching.invoice.bindingvo;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for SourceAndMatchDtls01 complex type.
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SourceAndMatchDtls01">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GeneralInfo" type="{}GeneralInfo01"/>
 *         &lt;element name="Source" type="{}ReconciliationDetails01" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Match" type="{}ReconciliationDetails01" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SourceAndMatchDtls01", propOrder = { "generalInfo", "source", "match" })
public class SourceAndMatchDtls01 {

	@XmlElement(name = "GeneralInfo", required = true)
	protected GeneralInfo01 generalInfo;

	@XmlElement(name = "Source")
	protected List<ReconciliationDetails01> source;

	@XmlElement(name = "Match")
	protected List<ReconciliationDetails01> match;

	/**
	 * Gets the value of the generalInfo property.
	 * @return possible object is {@link GeneralInfo01 }
	 */
	public GeneralInfo01 getGeneralInfo() {
		return generalInfo;
	}

	/**
	 * Sets the value of the generalInfo property.
	 * @param value allowed object is {@link GeneralInfo01 }
	 */
	public void setGeneralInfo(GeneralInfo01 value) {
		this.generalInfo = value;
	}

	/**
	 * Gets the value of the source property.
	 * <p>
	 * This accessor method returns a reference to the live list, not a snapshot. Therefore any modification you make to the returned list will be present inside the JAXB object. This is why there is
	 * not a <CODE>set</CODE> method for the source property.
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
     *    getSource().add(newItem);
     * </pre>
	 * <p>
	 * Objects of the following type(s) are allowed in the list {@link ReconciliationDetails01 }
	 */
	public List<ReconciliationDetails01> getSource() {
		if (source == null) {
			source = new ArrayList<ReconciliationDetails01>();
		}
		return this.source;
	}

	/**
	 * Gets the value of the match property.
	 * <p>
	 * This accessor method returns a reference to the live list, not a snapshot. Therefore any modification you make to the returned list will be present inside the JAXB object. This is why there is
	 * not a <CODE>set</CODE> method for the match property.
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
     *    getMatch().add(newItem);
     * </pre>
	 * <p>
	 * Objects of the following type(s) are allowed in the list {@link ReconciliationDetails01 }
	 */
	public List<ReconciliationDetails01> getMatch() {
		if (match == null) {
			match = new ArrayList<ReconciliationDetails01>();
		}
		return this.match;
	}

}
