/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   06 Aug 2012
 * 
 * Purpose:      IPymtPreparationDAO
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 06 Aug 2012       Oracle Financial Services Software Ltd                  Initial Version
 * 14 Sep 2012					Sandhya R									Auto Payment Preparation Changes
 * 26 Sep 2012                  Gangadharan R								Authorization matrix changes
 * 10 Oct 2012    				Gangadharan R							    Fix for ST defect 6864
 * 16 Oct 2012					Gangadharan R							    Fix for ST defects 6944
 * 23 Oct 2012					Gangadharan R							    Fix for ST defect 6987
 * 11 SEP 2013					Merdith S							       QC 3712
************************************************************************************************************************************************************/

package com.bnp.eipp.services.dao.payment.preparation;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.bnp.eipp.services.invoice.vo.EippCreditNoteVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.vo.admin.MarketPlaceAccountVO;
import com.bnp.eipp.services.vo.payment.AutoPaymentRuleVO;
import com.bnp.eipp.services.vo.payment.EippPymtAuditVO;
import com.bnp.eipp.services.vo.payment.EippPymtVO;
import com.bnp.eipp.services.vo.payment.PaymentInitiateAccountVO;
import com.bnp.eipp.services.vo.payment.PymtAdjustMentCodeVO;
import com.bnp.scm.services.admin.vo.BuyerAccountVO;
import com.bnp.scm.services.admin.vo.SupplierAccountVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

// TODO: Auto-generated Javadoc
/**
 * The Interface IPymtPreparationDAO.
 */
public interface IPymtPreparationDAO {
	
	/**
	 * Gets the invoice for pymt preparation.
	 *
	 * @param eippInvVO the eipp inv vo
	 * @return the invoice for pymt preparation
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippInvoiceVO> getInvoiceForPymtPreparation(EippInvoiceVO eippInvVO)throws BNPApplicationException;
	
	/**
	 * Gets the payment ref no.
	 *
	 * @param pymtPrepVO the pymt prep vo
	 * @return the payment ref no
	 * @throws BNPApplicationException the bNP application exception
	 */
	String getPaymentRefNo(EippPymtVO pymtPrepVO) throws BNPApplicationException;
	
	/**
	 * Gets the payment id.
	 *
	 * @return the payment id
	 * @throws BNPApplicationException the bNP application exception
	 */
	long getPaymentID() throws BNPApplicationException;
	
	/**
	 * Insert pymt details ino trans.
	 *
	 * @param pymtPrepVO the pymt prep vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void insertPymtDetailsInoTrans(EippPymtVO pymtPrepVO) throws BNPApplicationException;
	
	/**
	 * Insert pymt details into hist.
	 *
	 * @param pymtPrepVO the pymt prep vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void insertPymtDetailsIntoHist(EippPymtVO pymtPrepVO) throws BNPApplicationException;
	
	/**
	 * Insert pymt details.
	 *
	 * @param pymtPrepVO the pymt prep vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void insertPymtDetails(EippPymtVO pymtPrepVO) throws BNPApplicationException;
		
	/**
	 * Gets the branch time zone.
	 *
	 * @param orgId the org id
	 * @return the branch time zone
	 * @throws BNPApplicationException the bNP application exception
	 */
	String getBranchTimeZone(String orgId) throws BNPApplicationException;
	
	/**
	 * Gets the post cut off time.
	 *
	 * @param pymtPrepVO the pymt prep vo
	 * @return the post cut off time
	 * @throws BNPApplicationException the bNP application exception
	 */
	String getPostCutOffTime(EippPymtVO pymtPrepVO) throws BNPApplicationException;;
	
	/**
	 * Insert pymt access log details.
	 *
	 * @param auditVO the audit vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void insertPymtAccessLogDetails(EippPymtAuditVO auditVO)	throws BNPApplicationException;
	
	/**
	 * Update payment status.
	 *
	 * @param pymtVO the pymt vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void updatePaymentStatus(EippPymtVO pymtVO)	throws BNPApplicationException;
	
	/**
	 * Update invoice block amt.
	 *
	 * @param pymtVO the pymt vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void updateInvoiceBlockAmt(EippPymtVO pymtVO) throws BNPApplicationException;
	
	/**
	 * Gets the payment lead days.
	 *
	 * @param pymtVO the pymt vo
	 * @return the payment lead days
	 * @throws BNPApplicationException the bNP application exception
	 */
	int getPaymentLeadDays(EippPymtVO pymtVO) throws BNPApplicationException;	
		
	/**
	 * Gets the next working date.
	 *
	 * @param pymtVO the pymt vo
	 * @param inputDate the input date
	 * @return the payment value date
	 * @throws BNPApplicationException the bNP application exception
	 */
	Date getNextWorkingDate(EippPymtVO pymtVO, Date inputDate) throws BNPApplicationException;
	
	/**
	 * Gets the default supplr acct.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @return the default supplr acct
	 * @throws BNPApplicationException the bNP application exception
	 */
	List <NameValueVO> getDefaultSupplrAcct(EippInvoiceVO eippInvoiceVO)throws BNPApplicationException;
	
	/**
	 * Gets the suplr acct for txn ccy.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @return the suplr acct for txn ccy
	 * @throws BNPApplicationException the bNP application exception
	 */
	List <NameValueVO> getSuplrAcctForTxnCcy(EippInvoiceVO eippInvoiceVO)throws BNPApplicationException;
	
	/**
	 * Gets the buyer acct.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @return the buyer acct
	 * @throws BNPApplicationException the bNP application exception
	 */
	List <NameValueVO> getBuyerAcct(EippInvoiceVO eippInvoiceVO)throws BNPApplicationException;
	
	/**
	 * Gets the mkt place acct.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @return the mkt place acct
	 * @throws BNPApplicationException the bNP application exception
	 */
	List <NameValueVO> getMktPlaceAcct(EippInvoiceVO eippInvoiceVO)throws BNPApplicationException;
	
	/**
	 * Gets the cN details.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @return the cN details
	 * @throws BNPApplicationException the bNP application exception
	 */
	EippPymtVO getCNDetails(EippPymtVO eippPymtVO)throws BNPApplicationException;
	
	/**
	 * Gets the line item details.
	 *
	 * @param eippInvVO the eipp inv vo
	 * @return the line item details
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippInvCntLineItemVO> getLineItemDetails(EippInvoiceVO eippInvVO)throws BNPApplicationException;

	/**
	 * Insert pymt snapshot details.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void insertPymtSnapshotDetails(EippPymtVO eippPymtVO) throws BNPApplicationException;	
	
	/**
	 * Gets the pmt adjustment details.
	 *
	 * @param eippInvVO the eipp inv vo
	 * @return the pmt adjustment details
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<PymtAdjustMentCodeVO> getPmtAdjustmentDetails(EippInvoiceVO eippInvVO)throws BNPApplicationException;
	
	/**
	 * Gets the rebate or fee.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @return the rebate or fee
	 * @throws BNPApplicationException the bNP application exception
	 */
	EippPymtVO getRebateOrFee(EippPymtVO eippPymtVO)throws BNPApplicationException;
	
	/**
	 * Gets the next pmt init date.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @return the next pmt init date
	 * @throws BNPApplicationException the bNP application exception
	 */
	void getNextPmtInitDate(EippPymtVO eippPymtVO) throws BNPApplicationException;
	
	/**
	 * 
	 * @param eippPymtVO
	 * @throws BNPApplicationException
	 */
	void getNextPmtValueDate(EippPymtVO eippPymtVO) throws BNPApplicationException;
	
	/**
	 * Gets the supplier pmt mthd.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @return the supplier pmt mthd
	 * @throws BNPApplicationException the bNP application exception
	 */
	SupplierAccountVO getSupplierPmtMthd(EippInvoiceVO eippInvoiceVO)throws BNPApplicationException;
	
	/**
	 * Gets the mkt place pmt mthd.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @return the mkt place pmt mthd
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<MarketPlaceAccountVO> getMktPlacePmtMthd(EippInvoiceVO eippInvoiceVO)throws BNPApplicationException;
	
	/**
	 * Gets the buyer pmt mthd.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @return the buyer pmt mthd
	 * @throws BNPApplicationException the bNP application exception
	 */
	BuyerAccountVO getBuyerPmtMthd(EippInvoiceVO eippInvoiceVO)throws BNPApplicationException;
	
	/**
	 * Gets the pymt proc for buyer.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @return the pymt proc for buyer
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<PaymentInitiateAccountVO> getPymtProcForBuyer(EippPymtVO eippPymtVO)throws BNPApplicationException;
	
	/**
	 * Gets the pymt proc for supplr.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @return the pymt proc for supplr
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<PaymentInitiateAccountVO> getPymtProcForSupplr(EippPymtVO eippPymtVO)throws BNPApplicationException;
	
	/**
	 * Gets the pymt proc for mkt place.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @return the pymt proc for mkt place
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<PaymentInitiateAccountVO> getPymtProcForMktPlace(EippPymtVO eippPymtVO)throws BNPApplicationException;
	
	/**
	 * Save pymt.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void savePymt(EippPymtVO eippPymtVO)throws BNPApplicationException;
	
	/**
	 * Gets the buyer org list.
	 *
	 * @param input the input
	 * @return the buyer org list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getBuyerOrgList(NameValueVO input) throws BNPApplicationException;
	
	/**
	 * Gets the supplier org list.
	 *
	 * @param input the input
	 * @return the supplier org list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getSupplierOrgList(NameValueVO input) throws BNPApplicationException;
	
	/**
	 * Gets the mplace org list.
	 *
	 * @param input the input
	 * @return the mplace org list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getMplaceOrgList(NameValueVO input) throws BNPApplicationException;
	
	/**
	 * This code persist the records in Payment Table on Error.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void savePymtOnError(EippPymtVO eippPymtVO)throws BNPApplicationException;

	/**
	 * Gets the rebate or fee mfu.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @return the rebate or fee mfu
	 * @throws BNPApplicationException the bNP application exception
	 */
	EippPymtVO getRebateOrFeeMFU(EippPymtVO eippPymtVO) throws BNPApplicationException;
	
	/**
	 * This method is responsible to revert the Transaction Timestamp created.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @return the inv line item record
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippInvCntLineItemVO> getInvLineItemRecord(EippPymtVO eippPymtVO) throws BNPApplicationException;
		
	/**
	 * Check pymt auto rule available.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @return the eipp pymt vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	AutoPaymentRuleVO checkPymtAutoRuleAvailable (EippInvoiceVO eippInvoiceVO) throws BNPApplicationException;
	
	/**
	 * Gets the default supp accnt identifier.
	 *
	 * @param pymtPrepVO the pymt prep vo
	 * @return the default supp accnt identifier
	 * @throws BNPApplicationException the bNP application exception
	 */
	Map<String, String> getDefaultSuppAccntIdentifier (EippPymtVO pymtPrepVO) throws BNPApplicationException;
	
	/**
	 * Check disallow pymt mthd.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @return true, if successful
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean checkDisallowPymtMthd (EippInvoiceVO eippInvoiceVO) throws BNPApplicationException;
	
	/**
	 * Gets the max pymt amt frm pymt mthd branch.
	 *
	 * @param pymtPrepVO the pymt prep vo
	 * @return the max pymt amt frm pymt mthd branch
	 * @throws BNPApplicationException the bNP application exception
	 */
	BigDecimal getMaxPymtAmtFrmPymtMthdBranch (EippPymtVO pymtPrepVO) throws BNPApplicationException;
	
	/**
	 * Calculate payment dates.
	 *
	 * @param param the param
	 * @throws BNPApplicationException the bNP application exception
	 */
	void calculatePaymentDates (Map<String,Object> param) throws BNPApplicationException;
	
	/**
	 * Gets the markpet place accnt identifier.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @return the markpet place accnt identifier
	 * @throws BNPApplicationException the bNP application exception
	 */
	Map<String, String> getMarkpetPlaceAccntIdentifier (EippInvoiceVO eippInvoiceVO) throws BNPApplicationException;
	
	/**
	 * Gets the supplier pymt mthd id.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @return the supplier pymt mthd id
	 * @throws BNPApplicationException the bNP application exception
	 */
	String getSupplierPymtMthdID (EippInvoiceVO eippInvoiceVO) throws BNPApplicationException;
	
	/**
	 * Insert auto payment.
	 *
	 * @param pymtVO the pymt vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void insertAutoPayment (EippPymtVO pymtVO) throws BNPApplicationException;
	
	/**
	 * Insert payment audit entry.
	 *
	 * @param pymtVO the pymt vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void insertPaymentAudit(EippPymtVO pymtVO) throws BNPApplicationException;
	
	/**
	 * This method is responsible to revert the Transaction Timestamp created.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @return the int
	 * @throws BNPApplicationException the bNP application exception
	 */
	int revertTxnTimestamp(EippPymtVO eippPymtVO)throws BNPApplicationException;
	
	/**
	 * Gets the pymt mthd max amt.
	 *
	 * @param pymtPrepVO the pymt prep vo
	 * @return the pymt mthd max amt
	 * @throws BNPApplicationException the bNP application exception
	 */
	BigDecimal getPymtMethodMaxAmt(EippPymtVO pymtPrepVO)	throws BNPApplicationException;
	
	/**
	 * Gets the pymt credit note records.
	 *
	 * @param eippPymtVO the eipp pymt vo
	 * @return the pymt credit note records
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippCreditNoteVO> getPymtCreditNoteRecords(EippPymtVO eippPymtVO) throws BNPApplicationException;
	
	/**
	 * Update pymt credit notes.
	 *
	 * @param pymtPrepVO the pymt prep vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void updatePymtCreditNotes(EippPymtVO pymtPrepVO)	throws BNPApplicationException;

	/**
	 * Update auth profile ref id.
	 *
	 * @param pymtVO the pymt vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void updateAuthProfileDetails(EippPymtVO pymtVO)throws BNPApplicationException;
		
	/**
	 * Gets the linked credit notes.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @return the linked credit notes
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippCreditNoteVO> getLinkedCreditNotes(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException;
	
	/**
	 * Update block amt in invoice.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void updateBlockAmtInInvoice(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException;
	
	boolean isAllocatedAtInvLevel(EippInvoiceVO invoice) throws BNPApplicationException;
	
	/**
	 * Check valid mkt place org.
	 *
	 * @param pymtVO the pymt vo
	 * @return true, if successful
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean checkValidMktPlaceOrg(EippPymtVO pymtVO) throws BNPApplicationException;

	BigDecimal getAmtforLI(long invId);
}
