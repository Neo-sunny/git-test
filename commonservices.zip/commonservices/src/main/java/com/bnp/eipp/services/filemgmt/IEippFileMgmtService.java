/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   02 Feb 2012
 * 
 * Purpose:      EIPP File management service
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 02 Feb 2012                      Oracle Financial Services Software Ltd                                    Initial Version 
 *                                  
 *****************************************************************************************************************************************************************/

package com.bnp.eipp.services.filemgmt;


import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileUploadVO;
import com.bnp.scm.services.interfaces.common.vo.ConfVO;

public interface IEippFileMgmtService {
	
	/**
	 * @Name : uploadDataFile
	 * @Description : This method is used to parse & upload the data file 
	 * @param dataFile
	 * @throws BNPApplicationException
	 */
	long uploadDataFile(FileUploadVO dataFile) throws BNPApplicationException;
	
	ConfVO getQueueNameForOrg(ConfVO confVO) throws BNPApplicationException;
	
}
