/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  18 Aug 2012	   
 * 
 * Purpose:     Resolve Dispute Dao Interface
 * 
 * Change History: 
 * Date                                      	 Author                              Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 Aug 2012	       							Dinesh D                 		 Initial Version  
 * 25 Oct 2012	       							Ravishankar V                 	 ST Defects 7042 and 7050  
 *****************************************************************************************************************************************************************/


package com.bnp.eipp.services.dao.invoice;

import java.util.List;

import com.bnp.eipp.services.dao.filemgmt.IEippAbstractFileReleaseDAO;
import com.bnp.eipp.services.vo.dispute.DisputeVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.BNPRuntimeException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;

public interface IEippResolveDisputeDAO extends IEippAbstractFileReleaseDAO {

	List<DisputeVO> getResolveDisputeList(long fileId);

	int isResolveDisputeAllowed(DisputeVO disputeVO,String status)throws BNPApplicationException;

	void updateRecordStatusInTrans(long fileId, String deleteRecord) throws BNPApplicationException;

	void insertResolveDisputeList(List<DisputeVO> validObjectList,FileDetailsVO detailsVO)throws BNPRuntimeException;

	int isValidResolutionCode(DisputeVO disputeVO)throws BNPApplicationException;

	boolean isValidDeptUser(DisputeVO disputeVO) throws BNPApplicationException;

	DisputeVO getDisputeDetail(DisputeVO dispute);
}
