/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Jul 29, 201212:54:59 PM
 * 
 * Purpose:      EippFileReleaseService.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Jul 29, 201212:54:59 PM        Oracle Financial Services Software Ltd                  Initial Version  
************************************************************************************************************************************************************/

package com.bnp.eipp.services.filemgmt;

import java.util.GregorianCalendar;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnp.eipp.services.invoice.vo.EippTransactionVO;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.IEventLogService;
import com.bnp.scm.services.common.ILocaleMessageLoaderService;
import com.bnp.scm.services.common.TransactionServiceImpl;
import com.bnp.scm.services.common.dao.IEventLogDAO;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.invoice.IInvoiceUploadService;
import com.bnp.scm.services.txns.common.message.AbstractMessage;
import com.bnp.scm.services.txns.common.message.bindingvo.BaseHeader;
import com.bnp.scm.services.txns.util.PropertiesReader;

/**
 * This class serves as a base class for all EIPP file release functionality.
 */
public abstract class EippAbstractFileReleaseServiceImpl extends TransactionServiceImpl implements IEippFileReleaseService{

	@Autowired 
	private IEventLogService eventLogService;
	
	@Autowired
	protected BNPPropertyLoaderConfigurer propertyLoader;
	
	@Autowired 
	protected IEventLogDAO eventLogDAO;
	
	@Autowired 
	protected ILocaleMessageLoaderService msgService;
	
	@Autowired
	private IInvoiceUploadService invoiceService;
	
	/**
	 * This API generates the Functional acknowledgment message during file release
	 * @param message
	 * @param detailsVO
	 * @param dataList
	 * @param beanMapper
	 * @param isAutoReleaseEnabled
	 */
	public abstract <T extends EippTransactionVO> void generateFunctionalAck(AbstractMessage<?> message,FileDetailsVO detailsVO, List<T> dataList,
			DozerBeanMapper beanMapper, boolean isAutoReleaseEnabled) throws BNPApplicationException;
	
	public abstract void postRelease(FileDetailsVO detailsVO) throws BNPApplicationException;
	
	@Override
	public abstract SqlMapClientWrapper getDao();
	
	/**
	 * This API triggers file release activities from corresponding service   
	 * 	- Inserts the record details into their corresponding master table
	 * 	- Inserts the record details into their corresponding history table from master
	 *  - Deletes the record details from their corresponding trans table
	 *  - Generates the Functional acknowledgment message
	 *  - Triggers corresponding post release
	 *  - Updates the file status as released 
	 *  - Triggers file release event 
	 * 
	 * @param message
	 * @param detailsVO
	 * @param dataList
	 * @param beanMapper
	 * @param isAutoReleaseEnabled
	 * @throws BNPApplicationException
	 */
	@Override
	@Transactional(propagation=Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public <T extends EippTransactionVO>  void releaseFile(AbstractMessage<?> message,
			FileDetailsVO detailsVO, List<T> dataList,
			DozerBeanMapper beanMapper, boolean isAutoReleaseEnabled) throws BNPApplicationException {
		insertFileDetailsIntoMaster(detailsVO);
		insertFileDetailsIntoHistFromMaster(detailsVO);
		deleteFileDetailsFromTrans(detailsVO);
		generateFunctionalAck(message, detailsVO, dataList, beanMapper, isAutoReleaseEnabled);
		postRelease(detailsVO);
		detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.release.ok"));
		invoiceService.updateFileStatus(detailsVO);
		invoiceService.triggerEventLog(detailsVO,"RELEASE");
	}
	
	/**
	 * Sets the functional acknowledge message header details 
	 * @param header
	 * @param detailsVO
	 * @param ackMsgFileType
	 * @return
	 * @throws BNPApplicationException
	 */
	protected BaseHeader getAckHeader(BaseHeader header, FileDetailsVO detailsVO, String ackMsgFileType) throws BNPApplicationException {
		header.setOrgin(PropertiesReader.getProperty("txns.label.fo"));
		header.setDestination(PropertiesReader.getProperty("txns.label.erp"));
		header.setMsgFileType(PropertiesReader.getProperty(ackMsgFileType));
		detailsVO.setFuncAckId(eventLogService.getMessageId());
		header.setSrcRefId(detailsVO.getFuncAckId());
		header.setMsgFileSts(PropertiesReader.getProperty("message.type.na"));
		header.setSendTime(new GregorianCalendar());
		return header;
	}
	
}
