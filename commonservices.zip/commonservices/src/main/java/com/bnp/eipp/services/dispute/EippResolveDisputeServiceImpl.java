/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  18 Aug 2012	       
 * 
 * Purpose:     Resolve Dispute Services Implementation
 * 
 * Change History: 
 * Date                                      	 Author                              Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 Aug 2012	       							Dinesh D                 		 Initial Version
 * 22 OCT 2012					                Sadhana A V						 Rel 3.0 - Message monitoring changes (Functional ack message type corrected)
 * 24 Oct 2012    				 				Ravishankar V                    For Adhoc-- Issue and a part of 6968  
 * 25 Oct 2012	       							Ravishankar V                 	 ST Defects 7042 and 7050
 * 23 Nov 2012									Reena S							 Changed Resolve Dispute MsgType as 'EIPPDisputes' FuncAck as 'EIPPDisputeFileFunctionalAck'  
 *****************************************************************************************************************************************************************/

package com.bnp.eipp.services.dispute;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.dao.invoice.IEippResolveDisputeDAO;
import com.bnp.eipp.services.filemgmt.EippAbstractFileReleaseServiceImpl;
import com.bnp.eipp.services.interfaces.disputeupload.EippDisputeMessage;
import com.bnp.eipp.services.invoice.vo.EippTransactionVO;
import com.bnp.eipp.services.txns.util.file.EippFileUtil;
import com.bnp.eipp.services.vo.dispute.DisputeVO;
import com.bnp.eipp.services.vo.dispute.bindingvo.Document;
import com.bnp.eipp.services.vo.dispute.bindingvo.ErrorMessage;
import com.bnp.eipp.services.vo.dispute.bindingvo.ErrorMessages;
import com.bnp.eipp.services.vo.dispute.bindingvo.File;
import com.bnp.eipp.services.vo.dispute.bindingvo.Header;
import com.bnp.eipp.services.vo.dispute.bindingvo.ResolveDispute;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.BNPRuntimeException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.invoice.IInvoiceUploadService;
import com.bnp.scm.services.invoice.vo.InvalidFileDataVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;
import com.bnp.scm.services.txns.util.PropertiesReader;
import com.bnp.scm.services.txns.util.xml.XmlBinding;

@Component
public class EippResolveDisputeServiceImpl extends EippAbstractFileReleaseServiceImpl implements IEippResolveDisputeService {

	private static final Logger LOGGER = LoggerFactory.getLogger(EippResolveDisputeServiceImpl.class);

	@Autowired 
	private IEippResolveDisputeDAO resolveDisputeDAO;

	@Autowired
	private IDisputeMgmtService disputeMgmtService;

	@Autowired
	private IInvoiceUploadService uploadService;

	@Override
	public SqlMapClientWrapper getDao() {
		return (SqlMapClientWrapper)resolveDisputeDAO;
	}

	private void processResolveDispute(FileDetailsVO detailsVO) throws BNPApplicationException {
		List<DisputeVO> resolveDisputeList = resolveDisputeDAO.getResolveDisputeList(detailsVO.getFileId());
		List<DisputeVO> tempResolveDisputeList=null;
		for (DisputeVO disputeVO : resolveDisputeList) 
		{
			tempResolveDisputeList=new ArrayList<DisputeVO>();
			DisputeVO dispute=disputeMgmtService.getDisputeDetail(disputeVO);
			dispute.setFileId(disputeVO.getFileId());
			dispute.setDisputedAt(disputeVO.getDisputedAt());
			dispute.setResolutionCode(disputeVO.getResolutionCode());
			dispute.setSupplierMemo(disputeVO.getSupplierMemo());
			dispute.setOtherResolutionReason(disputeVO.getOtherResolutionReason());
			tempResolveDisputeList.add(dispute);
			if(BNPConstants.REJECT.equals(disputeVO.getActionRequired()))
			{
				disputeMgmtService.rejectDisputes(tempResolveDisputeList);
			}
			else
			{
				disputeMgmtService.acceptDisputes(tempResolveDisputeList);
			}
		}
	}


	@Override
	public int isResolveDisputeAllowed(DisputeVO disputeVO,String status) throws BNPApplicationException {
		return resolveDisputeDAO.isResolveDisputeAllowed(disputeVO,status);
	}

	@Override
	public void insertFileDetailsIntoHistFromTrans(FileDetailsVO detailsVO)
			throws BNPRuntimeException, BNPApplicationException {
		resolveDisputeDAO.insertFileDetailsIntoHistFromTrans(detailsVO);
	}

	// Release file starts
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.filemgmt.EippAbstractFileReleaseServiceImpl#releaseFile(com.bnp.scm.services.filemgmt.vo.FileDetailsVO,boolean)
	 */
	public void releaseFile(FileDetailsVO detailsVO, 
			boolean isAutoReleaseEnabled) throws BNPApplicationException {
		releaseFile(null, detailsVO, null, null, isAutoReleaseEnabled);
	}
	@Override
	public <T extends EippTransactionVO>void releaseFile(AbstractMessage<?> message,
			FileDetailsVO detailsVO, List<T> dataList,
			DozerBeanMapper beanMapper, boolean isAutoReleaseEnabled) throws BNPApplicationException {
		super.releaseFile(message, detailsVO, dataList, beanMapper, isAutoReleaseEnabled);
	}

	@Override
	public void insertFileDetailsIntoMaster(FileDetailsVO detailsVO) throws BNPApplicationException {
		resolveDisputeDAO.insertFileDetailsIntoMaster(detailsVO);
	}

	@Override
	public void insertFileDetailsIntoHistFromMaster(FileDetailsVO detailsVO)
			throws BNPRuntimeException, BNPApplicationException {
		resolveDisputeDAO.insertFileDetailsIntoHistFromMaster(detailsVO);
	}

	@Override
	public void deleteFileDetailsFromTrans(FileDetailsVO detailsVO) throws BNPApplicationException {
		resolveDisputeDAO.deleteFileDetailsFromTrans(detailsVO);		
	}

	@Override
	public <T extends EippTransactionVO>void generateFunctionalAck(AbstractMessage<?> message, FileDetailsVO detailsVO, List<T> dataList, DozerBeanMapper beanMapper, boolean isAutoReleaseEnabled) throws BNPApplicationException {

		if(message == null && !isAutoReleaseEnabled){
			message = prepareMessage(detailsVO);
		}
		else{ 
			if(dataList != null){
				( (File)message.getBody()).setDocument(mapVOToJAXB(dataList, beanMapper, isAutoReleaseEnabled ));
			}
		}
		if (message != null) {
			message.setHeader(getAckHeader((Header)message.getHeader(), detailsVO, "message.type.eipp.raiseDispute.funcack")); //Changing as 'EIPPDisputeFileFunctionalAck' 
			message.marshallMessage(message.getProperties());
			String xmlContent = message.getXmlMessage();
			XmlBinding.validate(xmlContent, PropertiesReader.getProperty("message.eippschema.dispute.xsd.path"));
			detailsVO.setFuncAckData(xmlContent.getBytes());
			detailsVO.setEippfuncAck(BNPConstants.EIPP_RAISE_DISPUTE_FUNC_ACK); //Changing as 'EIPPDisputeFileFunctionalAck'
		}
	}

	@Override
	public void postRelease(FileDetailsVO detailsVO) throws BNPApplicationException {
		processResolveDispute(detailsVO);
	}

	/**
	 * This API updates the file status as deleted and 
	 * updates the trans record status as deleted, inserted into history from trans and
	 * deletes the record in resolve dispute trans table
	 * @param detailsVO
	 * @throws BNPApplicationException
	 */
	@Override
	public void deleteFile(FileDetailsVO detailsVO) throws BNPApplicationException {
		resolveDisputeDAO.updateRecordStatusInTrans(detailsVO.getFileId(), StatusConstants.DELETE_RECORD);
		resolveDisputeDAO.insertFileDetailsIntoHistFromTrans(detailsVO);
		resolveDisputeDAO.deleteFileDetailsFromTrans(detailsVO);
	}
	// Release file ends

	/**
	 * This API returns the EippDisputeMessage during manual release
	 * @param detailsVO
	 * @throws BNPApplicationException 
	 */
	private AbstractMessage<?> prepareMessage(FileDetailsVO detailsVO) throws BNPApplicationException {
		String msgDispute = propertyLoader.getValue("message.type.eipp.dispute");
		EippDisputeMessage resolveDisputeMessage = new EippDisputeMessage();

		resolveDisputeMessage.extractMessage(new String(eventLogDAO.getMsgData(detailsVO.getFileId()+"", msgDispute.trim())));
		List<InvalidFileDataVO> lstInvalidFileDataVO = uploadService.getRejectedRecords(detailsVO.getFileId());
		boolean bInvalid; 
		int pymtRecCntr = 0;
		StringBuffer refNo = new StringBuffer();
		for(ResolveDispute resolveDispute : ((File)resolveDisputeMessage.getBody()).getDocument().getResolveDispute()){
			bInvalid = false;
			++pymtRecCntr;
			refNo.setLength(0);
			refNo.append(detailsVO.getFileId()).append(BNPConstants.VALUE_SEPARATOR).append(pymtRecCntr);
			resolveDispute.setErrMsgs(getErrorMessages(lstInvalidFileDataVO, refNo.toString()));

			if(resolveDispute.getErrMsgs() != null && resolveDispute.getErrMsgs().getErrMsg() != null && resolveDispute.getErrMsgs().getErrMsg().size() > 0) {
				bInvalid = true;
			} 				
			resolveDispute.setStatus((bInvalid == true) ? BNPConstants.RELEASED : BNPConstants.VALIDATION_FAILED);
		}
		return resolveDisputeMessage;
	}
	/**
	 * This API generates the Functional acknowledgment message during file release
	 * @param message
	 * @param detailsVO
	 * @param dataList
	 * @param beanMapper
	 * @param isAutoReleaseEnabled
	 */


	private <T extends EippTransactionVO>Document mapVOToJAXB(List<T> resolveDisputeList, DozerBeanMapper beanMapper, boolean isAutoReleaseEnabled) {
		Document document = new Document();
		document.getResolveDispute().addAll(prepareJAXBObjects(resolveDisputeList, beanMapper, isAutoReleaseEnabled));
		return document;
	}

	/**
	 * This API returns the JAXB object with proper status & error messages
	 * @param resolveDisputeList
	 * @param beanMapper
	 * @param isAutoReleaseEnabled
	 * @throws BNPApplicationException 
	 */
	private <T extends EippTransactionVO> List<ResolveDispute> prepareJAXBObjects(List<T> resolveDisputeList, DozerBeanMapper beanMapper, boolean isAutoReleaseEnabled){

		List<ResolveDispute> invoices = new ArrayList<ResolveDispute>();

		for(T disputeVO : resolveDisputeList){
			ResolveDispute invoice = beanMapper.map(disputeVO, ResolveDispute.class);	
			if (!EippFileUtil.isEmptyList(disputeVO.getInvalidFileDataList())){
				invoice.setErrMsgs(getErrorMessages(disputeVO.getInvalidFileDataList(), beanMapper));
				invoice.setStatus(BNPConstants.VALIDATION_FAILED);
			}
			else {
				invoice.setStatus((isAutoReleaseEnabled) ? BNPConstants.RELEASED : BNPConstants.VALIDATION_SUCCESS);
			}
			invoices.add(invoice);
		}
		return invoices;
	}

	/**
	 * This method prepares ErrorMessages list for Invalid data
	 * @param invalidDataList
	 * @param beanMapper
	 * @return
	 */
	private ErrorMessages getErrorMessages(List<InvalidFileDataVO> invalidDataList, DozerBeanMapper beanMapper){

		ErrorMessages ermsgs = new ErrorMessages();

		for (InvalidFileDataVO invalidFileDataVO : invalidDataList) {
			ErrorMessage errorMessage = beanMapper.map(invalidFileDataVO, ErrorMessage.class);
			ermsgs.getErrMsg().add(errorMessage);
		}

		return ermsgs;
	}

	/**
	 * This method sets the error code & description to the ErrorMessages list for Invalid data based on ref_no
	 * @param lstInvalidFileDataVO
	 * @param id
	 * @return
	 */
	private ErrorMessages getErrorMessages(List<InvalidFileDataVO> lstInvalidFileDataVO, String refNo) {
		ErrorMessages errmsgs = null;
		ErrorMessage errmsg = null;
		for(InvalidFileDataVO invalidFileDataVO :lstInvalidFileDataVO) {
			if(refNo.equals(invalidFileDataVO.getRefNo())){
				if(errmsgs == null) {
					errmsgs = new ErrorMessages();
				}

				errmsg = new ErrorMessage();
				errmsg.setErrorCode(invalidFileDataVO.getErrorMessage());
				errmsg.setErrorDesc(msgService.getMessage("en_US", Integer.parseInt(invalidFileDataVO.getErrorMessage())));
				errmsgs.getErrMsg().add(errmsg);
			}
		}
		return errmsgs;
	}

	@Override
	public int isValidResolutionCode(DisputeVO disputeVO)
			throws BNPApplicationException {
		DisputeVO dispute=resolveDisputeDAO.getDisputeDetail(disputeVO);
		disputeVO.setBuyerOrgId(dispute.getEippInvoice().getBuyerOrgId());
		disputeVO.setSupplierOrgId(dispute.getEippInvoice().getSupplierOrgId());
		disputeVO.setBillType(dispute.getBillType());
		return resolveDisputeDAO.isValidResolutionCode(disputeVO);
	}

	@Override
	public <T extends EippTransactionVO> void insertFileDetailsIntoTrans(
			List<T> valueObjectList, FileDetailsVO detailsVO)
					throws BNPRuntimeException {
		resolveDisputeDAO.insertResolveDisputeList((List<DisputeVO>)valueObjectList, detailsVO);
		try {
			saveAttachments(detailsVO.getFileId(), FILE_TYPE.RESOLVE_DISPUTE, detailsVO.getUserId());
		} catch (BNPApplicationException e) {
			LOGGER.error("Error while saving attachments : " + e.getErrorCode());
		}		
	}
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dispute.IEippRaiseDisputeService#doBusinessValidation(com.bnp.eipp.services.vo.dispute.DisputeVO)
	 */
	public List<Integer> doBusinessValidation(DisputeVO disputeVO) throws BNPApplicationException {
		List<Integer> errorCodeList = new ArrayList<Integer>();
		if(!resolveDisputeDAO.isValidDeptUser(disputeVO))
			{
				errorCodeList.add(ErrorConstants.INVALID_DEPT_RESOL_USER); 
			}

		return errorCodeList;
	}
}
