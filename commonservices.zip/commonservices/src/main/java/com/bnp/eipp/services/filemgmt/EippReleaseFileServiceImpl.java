/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 6, 20125:39:16 PM
 * 
 * Purpose:      EippReleaseFileServiceImpl.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 6, 2012 5:39:16 PM        Oracle Financial Services Software Ltd                  Initial Version  
 * 12-July 2012                  Oracle Financial Services Software Ltd                  EIPP Phase II - Cancel Invoice MFU
 * 21-August 2012                Vignesh B												 Attachment Processing
 * 16 Aug 2012    				    Gangadharan R							             MFU - Payment Preparation
*  14 Sep 2012					 Prabakaran S										  	 Modified for EIPP Inv Attachments
 * 24 Sep 2012					 Aarthi T											    Release File Inq - Rel 3.0 Matching and Reconcilation 
 * 26 Sep 2012					 Dinesh D											  	 MFU - EIPP Disputes
 * 10 Oct 2012					 Aarthi T												 Release File Inq Payment details - Rel 3.0 Matching and Reconcilation
 * 17 Oct 2012					Sandhya R								   			    R3.0 Matchin Recon : Changes for auto match mail event
 * 26 Oct 2012		    		Aarthi T												Modified for Matching EIPP Invoice and Credit note 
 ************************************************************************************************************************************************************/

package com.bnp.eipp.services.filemgmt;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnp.eipp.services.cnutil.IEippCreditNoteUtilService;
import com.bnp.eipp.services.dao.filemgmt.IEippReleaseFileDao;
import com.bnp.eipp.services.dispute.IEippRaiseDisputeService;
import com.bnp.eipp.services.dispute.IEippResolveDisputeService;
import com.bnp.eipp.services.invoice.IEippInvcUploadService;
import com.bnp.eipp.services.invoice.IEippInvoiceCancelServices;
import com.bnp.eipp.services.invoice.IEippInvoiceService;
import com.bnp.eipp.services.invoice.IEippReleaseService;
import com.bnp.eipp.services.invoice.dao.IEippInvcUploadDAO;
import com.bnp.eipp.services.invoice.util.EippAuditConstants;
import com.bnp.eipp.services.matching.dao.IEippMatchingMessageDAO;
import com.bnp.eipp.services.matching.invoice.IEippMatchingInvoiceMsgService;
import com.bnp.eipp.services.payment.preparation.IPymtPrepFileService;
import com.bnp.eipp.services.vo.common.EippMessageVO;
import com.bnp.eipp.services.vo.payment.EippPymtVO;
import com.bnp.scm.services.admin.dao.IorganizationDAO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.TransactionServiceImpl;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.BNPRuntimeException;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.interfaces.common.message.MessageFactory;
import com.bnp.scm.services.invoice.IInvoiceUploadService;
import com.bnp.scm.services.txns.common.message.AbstractMessage;

@Component
public class EippReleaseFileServiceImpl extends TransactionServiceImpl implements IEippReleaseService {

	private static final Logger LOGGER = LoggerFactory.getLogger(EippReleaseFileServiceImpl.class);
	
	@Autowired
	private IEippReleaseFileDao releaseFileDao;

	@Autowired
	private IEippCreditNoteUtilService creditNoteUtilService;
	
	@Autowired
	private IorganizationDAO orgService;
	
	@Autowired
	private IEippInvoiceService eippInvoiceService;
	
	@Autowired
	private IEippInvcUploadService invoiceUploadService;
	
	@Autowired
	private IEippInvoiceCancelServices cancellationServiceImpl; 
	
	@Autowired
	private IPymtPrepFileService pymtPrepFileService;

	@Autowired
	private IEippRaiseDisputeService raiseDisputeService; 
	
	@Autowired
	private IEippResolveDisputeService resolveDisputeService; 
	
	 @Autowired
	 private IEippInvcUploadDAO eippInvcUploadDao;
	 
	 @Autowired
	protected BNPPropertyLoaderConfigurer propertyLoader;
	 
	@Autowired
	private IInvoiceUploadService invoiceService;
	
	@Autowired
	private IEippMatchingMessageDAO eippMatchingMessageDAO;
	
	@Autowired
	private IEippMatchingInvoiceMsgService eippMatchInvMsgService;

	
	@Autowired
	private IEippInvcUploadService eippInvcUploadService;
	
	/*@Autowired
	private BNPEmailSender emailSender;*/
	
	@Autowired
	@Qualifier("bnpMessageFactory")
	private MessageFactory messageFactory;
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	public void releaseFile(FileDetailsVO detailsVO)
	throws BNPApplicationException {
		releaseFile(detailsVO, false);
	}
	
	private void releaseFile(FileDetailsVO detailsVO,boolean autoAuthorization) throws BNPApplicationException{
		if(detailsVO.getInstrumentType().equals(BNPConstants.EIPP_CANCEL_FILE)){
			cancellationServiceImpl.releaseFile(detailsVO, autoAuthorization);
		}else if(detailsVO.getInstrumentType().equals(BNPConstants.EIPP_PYMT_PREP_FILE)){
			 pymtPrepFileService.releaseFile(detailsVO, autoAuthorization);
		 }else if(detailsVO.getInstrumentType().equals(BNPConstants.EIPP_RAISE_DISPUTE_FILE)){
			 raiseDisputeService.releaseFile(detailsVO, autoAuthorization);
		 }else if(detailsVO.getInstrumentType().equals(BNPConstants.EIPP_PYMT_PREP_FILE)){
			 resolveDisputeService.releaseFile(detailsVO, autoAuthorization);
		 }else if(detailsVO.getInstrumentType().equals(BNPConstants.MATCH_RECON_INS_TYPE)){
			 releaseFileDao.releaseFile4Matching(detailsVO);
			 matchAndUpdateFileStatus(detailsVO);
			 sendMailForAutoMatch(detailsVO);
		 }
		 else if(detailsVO.getInstrumentType().equals(BNPConstants.MATCH_EIPP_PMT_RESP_INS_TYPE)){
			 EippPymtVO eippPymtVO = new EippPymtVO();
			 eippPymtVO.setFileId(detailsVO.getFileId());
			 eippPymtVO.setCheckerId(detailsVO.getReleasedBy());
			 eippPymtVO.setAuditRecordStatus(StatusConstants.APPROVE_RECORD);
			 eippPymtVO.setRequestStatus(StatusConstants.REQ_SATUS_NA);
			 eippMatchingMessageDAO.approvePaymentDetails(eippPymtVO);
			 matchAndUpdateFileStatus(detailsVO);
		 }
		else{
			cancellationServiceImpl.cancelInvoiceForModify(detailsVO);
			releaseFileDao.releaseFile(detailsVO);
			if(!autoAuthorization){
				releaseFileDao.updateFileStatusForRelease(detailsVO);
				try{
					String instrumentType = detailsVO.getInstrumentType();
					if (BNPConstants.EIPP_ATTACHMENT_INSTRUMENT_TYPE.equals(instrumentType) && 
							!isUploadedForExistingInvoices(detailsVO)) {
						createFuncAckForAttachments(detailsVO);
					} else {
						invoiceUploadService.createFuncAck(detailsVO, detailsVO.getReleasedBy());
					}
				}catch(Exception funcAckErr){
					LOGGER.info("Error in createing the functional ack "+funcAckErr.getMessage());
				}
			}
			creditNoteUtilService.utilizeLinkedCreditNotes(detailsVO);
			eippInvoiceService.processDepartmentApproval(detailsVO.getFileId());
		}
	}
	
	private void createFuncAckForAttachments(
			FileDetailsVO detailsVO) throws BNPApplicationException {
		AbstractMessage message = messageFactory.getMessageInstance(
				propertyLoader.getValue("message.type.invoiceupload"));
		eippInvcUploadService.createFuncAck(message, detailsVO);
	}
		
	private boolean isUploadedForExistingInvoices(
			FileDetailsVO detailsVO) throws BNPApplicationException {
		return eippInvcUploadDao.isAttUploadedForExistingInvoices(detailsVO);
	}

	@Override
	public void sendMailForAutoMatch(FileDetailsVO fileVO) throws BNPApplicationException{

		
	//	List<String> matchRefList = releaseFileDao.getMatchRefNoForFileId(fileVO.getFileId());
		EippMessageVO matchInvMsgVO = new EippMessageVO();
		matchInvMsgVO.setMode(BNPConstants.H2H);
		matchInvMsgVO.setOrgId(fileVO.getSenderOrgId()); 
		matchInvMsgVO.setFileRefId(String.valueOf(fileVO.getFileId()));
		eippMatchInvMsgService.sendEmailAndH2HMessage(matchInvMsgVO);
	}
	
	/*private boolean checkNull(String userInput){
		boolean isValid=false;
		if(userInput !=null && userInput.trim().length()>0){
			isValid= true;	
		}
		return isValid;
	}*/
	
	private void matchAndUpdateFileStatus(FileDetailsVO detailsVO) throws BNPApplicationException{
		String errorCode = eippInvcUploadDao.matchRecords(detailsVO.getFileId());
		 LOGGER.info("Error Code is   "+ errorCode);
		 if (errorCode != null)
			 throw new BNPApplicationException(Integer.parseInt(errorCode));
		 else
			detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.release.ok"));
			invoiceService.updateFileStatus(detailsVO);
			invoiceService.triggerEventLog(detailsVO,"RELEASE");
	}

	@Override
	public NameValueVO getInvoiceTotalAmtForFile(long fileId,
			String fileUploadStatus) throws BNPApplicationException {
		return releaseFileDao.getInvoiceTotalAmtForFile(fileId,fileUploadStatus);
	}

	@Override
	public NameValueVO getCntTotalAmtForFile(long fileId,
			String fileUploadStatus) throws BNPApplicationException {
		return releaseFileDao.getCntTotalAmtForFile(fileId,fileUploadStatus);	
	}
	
	@Override
	public byte[] generateCreditNoteReportPdf(long cntId) throws BNPApplicationException
	{
		return releaseFileDao.generateCreditNoteReportPdf(cntId);
	}
	
	@Override
	public byte[] generateInvoiceReportPdf(long invId) throws BNPApplicationException
	{
		return releaseFileDao.generateInvoiceReportPdf(invId);

	}
	
	 @Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	 @Override
	public boolean insertMthRecIntoMasIfAutoAuthEnb(FileDetailsVO detailsVO,Map<String, String> params) 
	 								throws BNPApplicationException {
		 boolean isAutoReleaseEnabled = orgService.isAutoAuthorizationEnabled(detailsVO.getSenderOrgId());
//			String matchSchedule ="I";
//			
//			Map<String,String> resultMap = orgService.getLoadTypeAndMthSchedule(params);
//			if(resultMap != null && resultMap.get("loadType")!=null && resultMap.get("loadType").equalsIgnoreCase("A"))
//				isAutoReleaseEnabled = true; 
//			if(resultMap != null && resultMap.get("schedule")!=null && resultMap.get("schedule").equalsIgnoreCase("S"))
//				matchSchedule = "S"; 
//			
			if (isAutoReleaseEnabled) {
				try {
					detailsVO.setReleasedBy("SYSTEM");
					releaseFile(detailsVO,isAutoReleaseEnabled);
					
				} catch (BNPApplicationException e) {
					throw new BNPApplicationException(e.getErrorCode(),	e.getErrorMessage());
				}
			}
			return isAutoReleaseEnabled;
		}
	
	 @Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	 @Override
		public boolean insertIntoMasterIfAutoAuthorizationEnabled(FileDetailsVO detailsVO) throws BNPRuntimeException {
			boolean isAutoReleaseEnabled = orgService.isAutoAuthorizationEnabled(detailsVO.getSenderOrgId());
			if (isAutoReleaseEnabled) {
				try {
					detailsVO.setReleasedBy("SYSTEM");
					releaseFile(detailsVO,isAutoReleaseEnabled);
					
				} catch (BNPApplicationException e) {
					throw new BNPRuntimeException(e.getErrorCode(),	e.getErrorMessage());
				}
			}
			return isAutoReleaseEnabled;
		}
	 @Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	 @Override
	 public void deleteFile(FileDetailsVO detailsVO) throws BNPApplicationException{
		 // Making this a generic update to avoid table lock issue
		 releaseFileDao.updateFileStatusForDelete(detailsVO);
		 if(detailsVO.getInstrumentType().equals(BNPConstants.EIPP_CANCEL_FILE)){
			 cancellationServiceImpl.deleteFile(detailsVO);
		 }else if(detailsVO.getInstrumentType().equals(BNPConstants.EIPP_PYMT_PREP_FILE)){
			 pymtPrepFileService.deleteFile(detailsVO);
		 }else if(detailsVO.getInstrumentType().equals(BNPConstants.EIPP_RAISE_DISPUTE_FILE)){
			 raiseDisputeService.deleteFile(detailsVO);
			 deleteDispAttachments(detailsVO.getFileId());
		 }else if(detailsVO.getInstrumentType().equals(BNPConstants.EIPP_RESOLVE_DISPUTE_FILE)){
			 resolveDisputeService.deleteFile(detailsVO);
			 deleteDispAttachments(detailsVO.getFileId());
		 }else{
			if(detailsVO.getInstrumentType().equals(BNPConstants.MATCH_RECON_INS_TYPE) ||
			   detailsVO.getInstrumentType().equals(BNPConstants.MATCH_EIPP_PMT_RESP_INS_TYPE)){
				 releaseFileDao.updateMatchInvAndCNStsInTrans(detailsVO.getFileId(), StatusConstants.DELETE_RECORD);
				 releaseFileDao.insertMatchHistoryDetails(detailsVO);
				 releaseFileDao.deleteMatchTransDetails(detailsVO);
			 }else{
				 releaseFileDao.updateInvAndCNStatusInTrans(detailsVO.getFileId(), StatusConstants.DELETE);
				 releaseFileDao.insertHistoryDetails(detailsVO);
				 releaseFileDao.createInvoiceAudit(detailsVO.getFileId(), 
						 detailsVO.getCurrentUserId(), StatusConstants.DELETE, EippAuditConstants.INV_DELETED);
				 releaseFileDao.deleteTransDetails(detailsVO);
				 //Attachment Processing
				 deleteInvAttachments(detailsVO.getFileId());
				//Attachment Processing
			 }
		 }
	 }

	@Override
	public SqlMapClientWrapper getDao() {
		return (SqlMapClientWrapper) releaseFileDao;
	}
	 
	 //Start : Added for Rel 3.0 Matching and Reconcilation
	 @Override
		public NameValueVO getMatchReconInvoiceCountForFile(long fileId,
				String fileUploadStatus) throws BNPApplicationException {
			return releaseFileDao.getMatchReconInvoiceCountForFile(fileId,fileUploadStatus);
		}
	 
	 @Override
		public NameValueVO getMatchReconCntCountForFile(long fileId,
				String fileUploadStatus) throws BNPApplicationException {
			return releaseFileDao.getMatchReconCntCountForFile(fileId,fileUploadStatus);	
		}
	 
	 @Override
		public NameValueVO getMatchReconPaymentCountForFile(long fileId,
				String fileUploadStatus) throws BNPApplicationException {
			return releaseFileDao.getMatchReconPaymentCountForFile(fileId,fileUploadStatus);
		}
	 //Ends : Added for Rel 3.0 Matching and Reconcilation

}
