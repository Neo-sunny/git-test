/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   06 Aug 2012
 * 
 * Purpose:      IPymtPrepFileDAO - It is used only for payment preparation MFU
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 06 Aug 2012       Oracle Financial Services Software Ltd                  Initial Version
************************************************************************************************************************************************************/

package com.bnp.eipp.services.dao.payment.preparation;

import java.math.BigDecimal;
import java.util.List;

import com.bnp.eipp.services.dao.filemgmt.IEippAbstractFileReleaseDAO;
import com.bnp.eipp.services.invoice.vo.EippCreditNoteVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.vo.payment.EippPymtVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;

/**
 * The Interface IPymtPrepFileDAO.
 */
public interface IPymtPrepFileDAO extends IEippAbstractFileReleaseDAO {
	
	/**
	 * Insert pymt prep hist details.
	 *
	 * @param detailsVO the details vo
	 * @param pymtPrepVO the pymt prep vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void insertPymtPrepHistDetails(FileDetailsVO detailsVO, EippPymtVO pymtPrepVO) throws BNPApplicationException;
	
	/**
	 * Update record status in trans.
	 *
	 * @param fileId the file id
	 * @param status the status
	 * @throws BNPApplicationException the bNP application exception
	 */
	void updateRecordStatusInTrans(long fileId, String status)  throws BNPApplicationException;
	
	/**
	 * Checks if is valid buyer acct identifier.
	 *
	 * @param pymtPrepVO the pymt prep vo
	 * @return true, if is valid buyer acct identifier
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean isValidBuyerAcctIdentifier(EippPymtVO pymtPrepVO) throws BNPApplicationException;
	
	/**
	 * Checks if is valid supplier acct identifier.
	 *
	 * @param pymtPrepVO the pymt prep vo
	 * @return true, if is valid supplier acct identifier
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean isValidSupplierAcctIdentifier(EippPymtVO pymtPrepVO) throws BNPApplicationException;
	
	/**
	 * Gets the credit note avail amt.
	 *
	 * @param creidtNoteVO the creidt note vo
	 * @return the credit note avail amt
	 * @throws BNPApplicationException the bNP application exception
	 */
	EippCreditNoteVO getCreditNoteAvailAmt(EippCreditNoteVO creidtNoteVO) throws BNPApplicationException;
	
	/**
	 * Gets the payment ref no.
	 *
	 * @param pymtPrepVO the pymt prep vo
	 * @return the payment ref no
	 * @throws BNPApplicationException the bNP application exception
	 */
	String getPaymentRefNo(EippPymtVO pymtPrepVO) throws BNPApplicationException;
	
	/**
	 * Gets the payment id.
	 *
	 * @return the payment id
	 * @throws BNPApplicationException the bNP application exception
	 */
	long getPaymentID() throws BNPApplicationException;
	
	/**
	 * Check multi paid invoice.
	 *
	 * @param invoiceVO the invoice vo
	 * @return true, if successful
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean checkMultiPaidInvoice(EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
	/**
	 * Gets the line item details.
	 *
	 * @param lineItemVO the line item vo
	 * @return the line item details
	 * @throws BNPApplicationException the bNP application exception
	 */
	EippInvCntLineItemVO getLineItemDetails(EippInvCntLineItemVO lineItemVO) throws BNPApplicationException;
	
	/**
	 * Gets the payment prep records.
	 *
	 * @param detailsVO the details vo
	 * @return the payment prep records
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippPymtVO> getPaymentPrepRecords(FileDetailsVO detailsVO) throws BNPApplicationException;
	
	/**
	 * Gets the payment invoice records.
	 *
	 * @param pymtPrepVO the pymt prep vo
	 * @return the payment invoice records
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippInvoiceVO> getPaymentInvoiceRecords(EippPymtVO pymtPrepVO) throws BNPApplicationException;
	
	/**
	 * Check pmt adj code details.
	 *
	 * @param pymtPrepVO the pymt prep vo
	 * @return the boolean
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean checkPmtAdjCodeDetails(EippPymtVO pymtPrepVO) throws BNPApplicationException;
}
