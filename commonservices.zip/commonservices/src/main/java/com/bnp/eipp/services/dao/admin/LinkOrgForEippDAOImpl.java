/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14 Jan 2012
 * 
 * Purpose:     Link Organization for EIPP DAO Implementation
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 14 Jan 2012                      Oracle Financial Services Software Ltd             Initial Version
 * 09 Mar 2012		  Oracle Financial Services Software Ltd				 Release 2.1 I1				Changed for Auto Complete Text box Implementation
 * 05 Apr 2012		  Oracle Financial Services Software Ltd				 Release 2.1 I1				Fix for SIT TD-1866
 * 18 Jul 2012        Reena 												 Release 3.0	            Changes for EIPP-Phase II
 *****************************************************************************************************************************************************************/

package com.bnp.eipp.services.dao.admin;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.vo.admin.LinkOrgForEippVO;
import com.bnp.scm.services.common.dao.AbstractCommonDaoImpl;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.vo.AbstractVO;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.ibatis.sqlmap.client.SqlMapExecutor;
import com.ibatis.sqlmap.engine.execution.BatchException;
 


// TODO: Auto-generated Javadoc
/**
 * The Class LinkOrgForEippDAOImpl. 
 */ 
@Component
public class LinkOrgForEippDAOImpl extends AbstractCommonDaoImpl<LinkOrgForEippVO> implements	ILinkOrgForEippDAO { 

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(LinkOrgForEippDAOImpl.class);
	private static final String NAMESPACE="LinkOrgForEippNS.";
	
	/** The Constant SUMMARY_LINKORGEIPP. */
	private static final String SUMMARY_LINKORGEIPP="searchLinkOrgEipp"; 
	
	/** The Constant GET_CUST_ORGLIST. */
	private static final String GET_CUST_ORGLIST_FORBA="getCustOrgIdListforBA";
	
	private static final String GET_CUST_ORGLIST_FOROA="getCustOrgIdListforOA";
	
	private static final String GET_CUST_ORGLIST_FORMPOA="getCustOrgIdListforMPOA";	
	/** The Constant GET_COUNTER_PARTY_ORGLIST. */ 
	private static final String GET_COUNTER_PARTY_ORGLIST="getCounterOrgList"; 
	
	/** The Constant GET_BILLTYPE_LIST. */
	private static final String GET_BILLTYPE_LIST="getBillTypeList";
	
	/** The Constant GET_BILLTYPE_DETAILS. */
	private static final String GET_BILLTYPE_DETAILS="getBillTypeDetails";
	
	/** The Constant GET_ORG_ROLE. */
	private static final String GET_ORG_ROLE="getCustOrgRoleType";
	
	/** The Constant GET_DEPARTMENT_LIST. */
	private static final String GET_DEPARTMENT_LIST="getDepartmentList";
	
	private static final String VIEW_AUDIT_RECORD="viewAuditRecord"; 

/*QUERIES for MAKER CHECKER STARTS*/
	
	/** The INSER t_ tran s_ record. */
	private static final String INSERT_TRANS_RECORD = "insertTransRecord";
	
	/** The INSER t_ ne w_ tran s_ record. */
	private static final String INSERT_NEW_TRANS_RECORD = "insertNewTransRecord";
	
	/** The UPDAT e_ statu s_ i n_ master. */
	private static final String UPDATE_STATUS_IN_MASTER = "updateStatusInMaster";
	
	/** The UPDAT e_ tran s_ record. */
	private static final String UPDATE_TRANS_RECORD = "updateTransRecord";
	
	/** The DELET e_ tran s_ record. */
	private static final String DELETE_TRANS_RECORD = "deleteTransRecord";
	
	/** The INSER t_ maste r_ record. */
	private static final String INSERT_MASTER_RECORD = "insertIntoMaster";
	
	/** The UPDAT e_ maste r_ record. */
	private static final String UPDATE_MASTER_RECORD = "updateMasterRecord";
	
	/** The INSER t_ his t_ record. */
	private static final String INSERT_HIST_RECORD = "insertIntoHistory";
	
	/** The INSER t_ his t_ tran s_ record. */
	private static final String INSERT_HIST_TRANS_RECORD = "insertInHistTransRecord";
	
	/** The Constant UPDATE_MASTER_RECORD_FOR_DELETE. */
	private static final String UPDATE_MASTER_RECORD_FOR_DELETE ="updateMasterRecordForDelete";
	
	/** The INSER t_ tran s_ chil d_ record. */
	private static final String INSERT_TRANS_CHILD_RECORD = "LinkOrgForEippNS.insertChildTrans";
	
	/** The INSER t_ his t_ chil d_ record. */
	private static final String INSERT_HIST_CHILD_RECORD = "LinkOrgForEippNS.insertChildHist";
	
	/** The INSER t_ maste r_ chil d_ record. */
	private static final String INSERT_MASTER_CHILD_RECORD = "LinkOrgForEippNS.insertChildMaster";
	
	/** The DELET e_ maste r_ chil d_ record. */
	private static final String DELETE_MASTER_CHILD_RECORD = "LinkOrgForEippNS.deleteChildMaster";
	
	/** The DELET e_ tran s_ chil d_ record. */
	private static final String DELETE_TRANS_CHILD_RECORD = "LinkOrgForEippNS.deleteChildTrans";
	
	/** The UPDAT e_ chil d_ statu s_ i n_ master. */
	private static final String UPDATE_CHILD_STATUS_IN_MASTER = "LinkOrgForEippNS.updateChildStatusInMaster";
	
	/** The UPDAT e_ chil d_ maste r_ recor d_ fo r_ delete. */
	private static final String UPDATE_CHILD_MASTER_RECORD_FOR_DELETE ="LinkOrgForEippNS.updateChildMasterRecordForDelete";
	
	/*QUERIES for MAKER CHECKER ENDS*/
	
	/** The Constant CHILD_PARAM1. */
	private static final String CHILD_PARAM1="CNTR_PARTY_ERP_ID";
	
	/** The Constant GET_LINK_PARAM_DETAILS. */
	private static final String GET_LINK_PARAM_DETAILS="getParamsForLinkOrgEipp";
	
	private static final String GET_DISP_RESOLUTION_DEPT = "getDispResolutionDept";
	
	private static final String GET_BILLTYPE_DEPT_DETAILS="getBillTypeDeptDetails";
	
	
	/** The Constant GET_COUNTER_PARTY_ORGLIST. */ 
	private static final String COUNTER_PARTY_ORGLIST_SUMMARY="getCounterOrgListSummary";
	private static final String MARKET_PLACE_ORGLIST="getMarketPlaceOrgList";
	private static final String GET_MP_COUNTER_PARTY_ORG="getCounterPartiesForMP";
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.dao.AbstractDAOImpl#getNameSpace()
	 */
	@Override
	public String getNameSpace() {	
		return NAMESPACE;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.admin.ILinkOrgForEippDAO#getLinkOrgEippDetails(com.bnp.eipp.services.vo.admin.LinkOrgForEippVO)
	 */
	@Override
	public List<LinkOrgForEippVO> getLinkOrgEippDetails(LinkOrgForEippVO searchVO) throws BNPApplicationException {
		List<LinkOrgForEippVO> linkOrgEippList=null;
		try{				
			linkOrgEippList=getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(SUMMARY_LINKORGEIPP),searchVO);
			// R7.0 Fortify issues
			//LOGGER.debug("dao-linkOrgEippList size: "+searchVO);
			
		}catch (DataAccessException ex) {
			LOGGER.error(ex.getMessage()); 
			throw new DBException(ErrorConstants.DATABASE_ERROR);		
		}
		
		return linkOrgEippList;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.admin.ILinkOrgForEippDAO#getCustomerOrgIdList(java.lang.String)
	 */
	@Override
	public List<NameValueVO> getCustomerOrgIdListBA(String currentUserId) throws BNPApplicationException {
		List<NameValueVO> custOrgList=null;
		try{
			custOrgList=getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_CUST_ORGLIST_FORBA),currentUserId);
		}
		catch(DataAccessException ex){
			LOGGER.error(ex.getMessage()); 
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		}
		return custOrgList;
	}

	@Override
	public List<NameValueVO> getCustomerOrgIdListOA(String currentUserId) throws BNPApplicationException {
		List<NameValueVO> custOrgList=null;
		try{
			custOrgList=getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_CUST_ORGLIST_FOROA),currentUserId);
		}
		catch(DataAccessException ex){
			LOGGER.error(ex.getMessage()); 
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		}
		return custOrgList;
	}
	
	@Override
	public List<NameValueVO> getCustomerOrgIdListMPOA(String currentUserId)throws BNPApplicationException {
		List<NameValueVO> custOrgList=null;
		try{
			custOrgList=getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_CUST_ORGLIST_FORMPOA),currentUserId);
		}
		catch(DataAccessException ex){
			LOGGER.error(ex.getMessage()); 
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		}
		return custOrgList;
	} 
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.admin.ILinkOrgForEippDAO#getCounterPartyOrgIdList(java.lang.String)
	 */
	@Override
	public List<NameValueVO> getCounterPartyOrgIdList(NameValueVO params)throws BNPApplicationException {
		List<NameValueVO> counterOrgList=null;
		try{
			counterOrgList=getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_COUNTER_PARTY_ORGLIST),params);
		}
		catch(DataAccessException ex){
			LOGGER.error(ex.getMessage()); 
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		}
		return counterOrgList;
	}

	@Override
	public List<NameValueVO> getMPCounterPartyOrgIdList(NameValueVO params)throws BNPApplicationException {
		List<NameValueVO> counterOrgList=null;
		try{
			counterOrgList=getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_MP_COUNTER_PARTY_ORG),params);
		}
		catch(DataAccessException ex){
			LOGGER.error(ex.getMessage()); 
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		}
		return counterOrgList;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.admin.ILinkOrgForEippDAO#getBillTypeList(java.lang.String)
	 */
	@Override
	public List<NameValueVO> getBillTypeList(String orgId)	throws BNPApplicationException {
		List<NameValueVO> billTypeList=null;
		try{
			billTypeList=getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_BILLTYPE_LIST),orgId);
		}
		catch(DataAccessException ex){
			LOGGER.error(ex.getMessage()); 
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		}
		return billTypeList;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.admin.ILinkOrgForEippDAO#getBillTypeRuleDetails(java.util.Map)
	 */
	@Override
	public LinkOrgForEippVO getBillTypeRuleDetails(Map<String, Object> orgBillDet) throws BNPApplicationException {
		LinkOrgForEippVO billTypeDetails=null;
		try{
			billTypeDetails=(LinkOrgForEippVO)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_BILLTYPE_DETAILS),orgBillDet);
		}
		catch(DataAccessException ex){
			LOGGER.error(ex.getMessage()); 
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		}
		
		return billTypeDetails;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.admin.ILinkOrgForEippDAO#getOrganizationRole(java.lang.String)
	 */
	@Override
	public NameValueVO getOrganizationRole(String orgId)throws BNPApplicationException {
		NameValueVO orgDet=null;
		try{
			orgDet=(NameValueVO)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_ORG_ROLE),orgId);
		}
		catch(DataAccessException ex){
			LOGGER.error(ex.getMessage()); 
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		}
		return orgDet;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.admin.ILinkOrgForEippDAO#getOrgDeparmentList(java.lang.String)
	 */
	@Override
	public List<NameValueVO> getOrgDeparmentList(String orgId)throws BNPApplicationException {
		List<NameValueVO> departmentList=null;
		try{
			departmentList=getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_DEPARTMENT_LIST),orgId);
		}
		catch(DataAccessException ex){
			LOGGER.error(ex.getMessage()); 
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		}
		return departmentList;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.admin.ILinkOrgForEippDAO#chkRecordAlreadyExists(com.bnp.eipp.services.vo.admin.LinkOrgForEippVO)
	 */
	@Override
	public int chkRecordAlreadyExists(LinkOrgForEippVO searchVO)throws BNPApplicationException {
		Integer count=null;
		try {
			count = (Integer) getSqlMapClientTemplate().queryForObject("LinkOrgForEippNS.chkRecordExists", searchVO);
			
		} catch (DataAccessException ex) {
			LOGGER.error(ex.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
				
		}	
		return count;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.admin.ILinkOrgForEippDAO#chkDependencyBeforDelete(com.bnp.eipp.services.vo.admin.LinkOrgForEippVO)
	 */
	@Override
	public int chkDependencyBeforDelete(LinkOrgForEippVO searchVO)throws BNPApplicationException {
		Integer count=null;
		try {
			count = (Integer) getSqlMapClientTemplate().queryForObject("LinkOrgForEippNS.chkDependencyB4Delete", searchVO);
			
		} catch (DataAccessException ex) {
			LOGGER.error(ex.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
				
		}	
		return count;
	} 
	
	
	
	
	
/* Overridden methods for Maker Checker - Starts*/ 
	
	/* (non-Javadoc)
 * @see com.bnp.scm.services.common.dao.AbstractCommonDaoImpl#saveReModifiedRecord(com.bnp.scm.services.common.vo.AbstractVO)
 */
@Override
	public void saveReModifiedRecord(LinkOrgForEippVO linkOrgForEippVO)
			throws BNPApplicationException {
		try {			
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(UPDATE_TRANS_RECORD), linkOrgForEippVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_HIST_TRANS_RECORD), linkOrgForEippVO);
			getSqlMapClientTemplate().delete(DELETE_TRANS_CHILD_RECORD, linkOrgForEippVO);
			
			insertChildTransAndHistRecords(linkOrgForEippVO);
			
		} catch (DataAccessException e) {
			LOGGER.error("Error while saving modified record " + e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.dao.AbstractCommonDaoImpl#saveNewRecord(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void saveNewRecord(LinkOrgForEippVO linkOrgForEippVO)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_NEW_TRANS_RECORD), linkOrgForEippVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_HIST_TRANS_RECORD), linkOrgForEippVO);
			
			insertChildTransAndHistRecords(linkOrgForEippVO);
			
		} catch (DataAccessException e) {
			LOGGER.error("Error while saving new record " + e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.dao.AbstractCommonDaoImpl#saveModifiedRecord(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void saveModifiedRecord(LinkOrgForEippVO linkOrgForEippVO)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_STATUS_IN_MASTER), linkOrgForEippVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_TRANS_RECORD), linkOrgForEippVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_HIST_TRANS_RECORD), linkOrgForEippVO);
			updateChildStatusInMaster(linkOrgForEippVO);
			
			insertChildTransAndHistRecords(linkOrgForEippVO);
			
		} catch (DataAccessException e) {
			LOGGER.error("Error while saving modified record " + e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.dao.AbstractCommonDaoImpl#approveNewRecord(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void approveNewRecord(LinkOrgForEippVO linkOrgForEippVO)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_MASTER_RECORD), linkOrgForEippVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_HIST_RECORD), linkOrgForEippVO);
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(DELETE_TRANS_RECORD), linkOrgForEippVO);
			insertChildMaster(linkOrgForEippVO);
			insertChildHistoryDeleteTrans(linkOrgForEippVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error while approving new record " + e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.dao.AbstractCommonDaoImpl#approveModifiedOrDeletedRecord(com.bnp.scm.services.common.vo.AbstractVO, boolean)
	 */
	@Override
	public void approveModifiedOrDeletedRecord(LinkOrgForEippVO linkOrgForEippVO,
			boolean isUpdateAllMasterCols) throws BNPApplicationException {
		try {
		if(isUpdateAllMasterCols){
				getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(UPDATE_MASTER_RECORD), linkOrgForEippVO);
				deleteMasterChild(linkOrgForEippVO);
				insertChildMaster(linkOrgForEippVO);
			}else{
				getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_MASTER_RECORD_FOR_DELETE), linkOrgForEippVO);
				getSqlMapClientTemplate().update(UPDATE_CHILD_MASTER_RECORD_FOR_DELETE,linkOrgForEippVO);
			}
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_HIST_RECORD), linkOrgForEippVO);
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(DELETE_TRANS_RECORD), linkOrgForEippVO);
			insertChildHistoryDeleteTrans(linkOrgForEippVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error while approving modified or deleted record " + e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.dao.AbstractCommonDaoImpl#undoNewRecord(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void undoNewRecord(LinkOrgForEippVO linkOrgForEippVO)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_HIST_RECORD), linkOrgForEippVO);
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(DELETE_TRANS_RECORD), linkOrgForEippVO);
			insertChildHistoryDeleteTrans(linkOrgForEippVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error while performing undo on new record " + e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.dao.AbstractCommonDaoImpl#undoModifiedRecord(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void undoModifiedRecord(LinkOrgForEippVO linkOrgForEippVO)
			throws BNPApplicationException {
		undoOrDeleteRecords(linkOrgForEippVO);
	}
	
	/**
	 * Undo or delete records.
	 *
	 * @param abstractVO the abstract vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void undoOrDeleteRecords(AbstractVO abstractVO) throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_STATUS_IN_MASTER), abstractVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_HIST_RECORD), abstractVO);
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(DELETE_TRANS_RECORD), abstractVO);
			updateChildStatusInMaster(abstractVO);
			insertChildHistoryDeleteTrans(abstractVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error while doing undo or delete record " + e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.dao.AbstractCommonDaoImpl#deleteApprovedRecord(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void deleteApprovedRecord(LinkOrgForEippVO linkOrgForEippVO) throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_STATUS_IN_MASTER), linkOrgForEippVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_TRANS_RECORD), linkOrgForEippVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_HIST_TRANS_RECORD), linkOrgForEippVO);
			updateChildStatusInMaster(linkOrgForEippVO);
			
			insertChildTransAndHistRecords(linkOrgForEippVO);
			
		} catch (DataAccessException e) {
			LOGGER.error("Error while deleting an approved record " + e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	
	/**
	 * Insert child trans and hist records.
	 *
	 * @param abstractVO the abstract vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void insertChildTransAndHistRecords(AbstractVO abstractVO) throws BNPApplicationException{
		LinkOrgForEippVO tempVO1 = null;
		if(abstractVO!=null && abstractVO instanceof LinkOrgForEippVO){
		tempVO1 = (LinkOrgForEippVO) abstractVO;
		}
		final LinkOrgForEippVO tempVO = tempVO1;
		
	
		try{
			 getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() { 
						@Override
						public List doInSqlMapClient(SqlMapExecutor executor)
								throws SQLException {
							List list = null;
							try {
								executor.startBatch();
								if(tempVO.getListOfErp()!=null && !tempVO.getListOfErp().isEmpty()){
									for (String cprtyErp : tempVO.getListOfErp()) {
										tempVO.setFieldName(CHILD_PARAM1);
										tempVO.setFieldValue(cprtyErp);
										executor.insert(INSERT_TRANS_CHILD_RECORD, tempVO);
										
									}
								}
								
								list = executor.executeBatchDetailed();
								// R7.0 Fortify issues
//								if (list != null) {
//									LOGGER.debug("Batch Result Size" + list.size());
//								}

							} catch (BatchException e) {
								LOGGER.error("Excecuting batch update in updateSettlement Failed "+ e.getMessage());
								throw new SQLException();
							}
							return list;
						}
					});
			 getSqlMapClientTemplate().insert(INSERT_HIST_CHILD_RECORD, abstractVO);
		}catch(Exception e){
			
		}
	}
	
	/**
	 * Update child status in master.
	 *
	 * @param abstractVO the abstract vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void updateChildStatusInMaster(AbstractVO abstractVO) throws BNPApplicationException{
		getSqlMapClientTemplate().update(UPDATE_CHILD_STATUS_IN_MASTER, abstractVO);
	}
	
	/**
	 * Insert child master.
	 *
	 * @param abstractVO the abstract vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void insertChildMaster(AbstractVO abstractVO) throws BNPApplicationException{
		getSqlMapClientTemplate().insert(INSERT_MASTER_CHILD_RECORD, abstractVO);
	}
	
	/**
	 * Delete master child.
	 *
	 * @param abstractVO the abstract vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void deleteMasterChild(AbstractVO abstractVO) throws BNPApplicationException{
		getSqlMapClientTemplate().delete(DELETE_MASTER_CHILD_RECORD,abstractVO);
	}
	
	/**
	 * Insert child history delete trans.
	 *
	 * @param abstractVO the abstract vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void insertChildHistoryDeleteTrans(AbstractVO abstractVO) throws BNPApplicationException{
		getSqlMapClientTemplate().insert(INSERT_HIST_CHILD_RECORD, abstractVO);
		getSqlMapClientTemplate().delete(DELETE_TRANS_CHILD_RECORD,abstractVO);
	}
	
	/* Overridden methods for Maker Checker - Ends*/



	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.admin.ILinkOrgForEippDAO#getChildDetails(com.bnp.eipp.services.vo.admin.LinkOrgForEippVO)
	 */
	@Override
	public List<String> getChildDetails(LinkOrgForEippVO fields)throws BNPApplicationException {
		List<String> fieldValueList=null;
		try {
			fieldValueList=getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_LINK_PARAM_DETAILS), fields);
			
		} catch (DataAccessException e) {
			LOGGER.error("Error while deleting an approved record " + e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return fieldValueList;
	}



	@Override
	public LinkOrgForEippVO viewAuditLinkOrgEipp(LinkOrgForEippVO linkOrgVO)throws BNPApplicationException {
		LinkOrgForEippVO auditRecord=null;
		try {			
			auditRecord=(LinkOrgForEippVO)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(VIEW_AUDIT_RECORD), linkOrgVO);
		} catch (DataAccessException ex) {			
			
			LOGGER.error(ex.getMessage());
			throw new DBException(ErrorConstants.ERROR_CONDITION_FETCH);
		}
		return auditRecord;
	}

	@Override
	public long getDepartmentForDisputeResolution(Map<String, Object> params)
			throws BNPApplicationException {
		Long deptId = null;
		try {			
			deptId = (Long) getSqlMapClientTemplate().queryForObject(
						getQueryNameWithNameSpace(GET_DISP_RESOLUTION_DEPT), params);
		} catch (DataAccessException ex) {			
			LOGGER.error(ex.getMessage());
			throw new DBException(ErrorConstants.ERROR_CONDITION_FETCH);
		}
		return deptId == null ? 0 : deptId;
	}

	@Override
	public LinkOrgForEippVO getBillTypeDeptDetails(Map<String, Object> orgBillDet) throws BNPApplicationException {
		LinkOrgForEippVO billTypeDetails=null;
		try{
			billTypeDetails=(LinkOrgForEippVO)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_BILLTYPE_DEPT_DETAILS),orgBillDet);
		}
		catch(DataAccessException ex){
			LOGGER.error(ex.getMessage()); 
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		}
		
		return billTypeDetails;
	}

	@Override
	public List<NameValueVO> getCounterPartyOrgIdListSummary(NameValueVO params) throws BNPApplicationException {
		List<NameValueVO> counterOrgList=null;
		try{
			counterOrgList=getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(COUNTER_PARTY_ORGLIST_SUMMARY),params);
		}
		catch(DataAccessException ex){
			LOGGER.error(ex.getMessage()); 
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		}
		return counterOrgList;
	}

	@Override
	public List<NameValueVO> getMarketPlaceOrgList(LinkOrgForEippVO searchVO)throws BNPApplicationException {
		List<NameValueVO> mrktPlaceOrgList=null;
		try{
			mrktPlaceOrgList=getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(MARKET_PLACE_ORGLIST),searchVO);
		}
		catch(DataAccessException ex){
			LOGGER.error(ex.getMessage()); 
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		}
		return mrktPlaceOrgList;
	}

	

	

}
