/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Jan 18, 201210:32:41 AM
 * 
 * Purpose:      Interface declaration for Bill Type Definition Service Layer
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Jan 18, 201210:32:41 AM        Oracle Financial Services Software Ltd                  Initial Version
 * 21 Mar 2012					  Oracle Financial Services Software Ltd				 Release 2.1 I1				ST fix 5615, 5652, 5603, 5452, 5636, 5593
 * 18 Jul 2012                    Reena 												 Release 3.0	            Changes for EIPP-Phase II
 * 20 June 2013                   Pratheep												 Release 6.0				For Toolkit changes of Manual work around moved from eipp to common and a method added 
 ************************************************************************************************************************************************************/
package com.bnp.eipp.services.admin;

import java.util.List;

import com.bnp.eipp.services.vo.admin.BillTypeDefinitionVO;
import com.bnp.eipp.services.vo.admin.BillTypeShortCutsVO;
import com.bnp.scm.services.common.IAbstractService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;



public interface IBillTypeDefinitionService extends IAbstractService<BillTypeDefinitionVO> { 
	
	/**
	 * @param searchVO
	 * @return BillTypeDetails
	 * @throws BNPApplicationException
	 */
	List<BillTypeDefinitionVO> getBillTypeDetails(BillTypeDefinitionVO searchVO)throws BNPApplicationException;
	
	/**
	 * @param orgDiscount
	 * @return ModifiedRecord
	 * @throws BNPApplicationException
	 */
	BillTypeDefinitionVO getModifiedRecord(BillTypeDefinitionVO orgDiscount) throws BNPApplicationException;
	
	/**
	 * @param searchVO
	 * @return number value
	 * @throws BNPApplicationException
	 */
	boolean chkDependencyBeforDelete(BillTypeDefinitionVO searchVO)throws BNPApplicationException;
	/**
	 * @param searchVO
	 * @return number value
	 * @throws BNPApplicationException
	 */
	boolean chkRecordNotExistsAlready(BillTypeDefinitionVO searchVO)throws BNPApplicationException;

	/**
	 * @param searchVO
	 * @return number value
	 * @throws BNPApplicationException
	 */
	List<NameValueVO> getOrganisationsListFromBilltype(NameValueVO inputVO)throws BNPApplicationException;
	/**
	 * @param orgId
	 * @return Buyer list
	 * @throws BNPApplicationException
	 */
	NameValueVO getCustomerRoleName(String orgId)throws BNPApplicationException;
	/**
	 * @param orgId
	 * @return Buyer list
	 * @throws BNPApplicationException
	 */
	List<NameValueVO> getDeptListForBuyer(String orgId)throws BNPApplicationException;
	/**
	 * @param orgId
	 * @return Supplier list
	 * @throws BNPApplicationException
	 */
	List<NameValueVO> getDeptListForSupplier(String orgId)throws BNPApplicationException;
	/**
	 * @param orgId
	 * @return BillTypeShortCutsVO
	 * @throws BNPApplicationException
	 */
	List<BillTypeShortCutsVO> getBillTypeLogoRecord(String orgId)throws BNPApplicationException;
	/**
	 * @param orgId
	 * @return BillTypeShortCutsVO
	 * @throws BNPApplicationException
	 */
	List<BillTypeShortCutsVO> getBillTypeStyleSheetRecord(String orgId)throws BNPApplicationException;
	/**
	 * @param orgId
	 * @return BillTypeShortCutsVO
	 * @throws BNPApplicationException
	 */
	List<BillTypeShortCutsVO> getBrandingDetailsRecord(String orgId)throws BNPApplicationException;
	/**
	 * @param orgId
	 * @return BillTypeShortCutsVO
	 * @throws BNPApplicationException
	 */
	List<BillTypeShortCutsVO> getDisputeCodeRecord(String orgId)throws BNPApplicationException;
	
	// FO R6.0 Added for Toolkit changes of Manual work around start
	/**
	 * This API returns the child details
	 * @param pkId
	 * @param masterStatus
	 * @return 
	 * @throws BNPApplicationException
	 */
	BillTypeDefinitionVO getChildDetails(long pkId,String masterStatus)throws BNPApplicationException;
	// FO R6.0 Added for Toolkit changes of Manual work around end
	
	/**
	 * This API returns the default department pk_id value
	 * for the given customer org id and bill type
	 * @param customerOrgId
	 * @param billType
	 * @return
	 * @throws BNPApplicationException
	 */
	long getDefaultDepartmentForDispute(
			String customerOrgId, String billType) throws BNPApplicationException;
	
	/**
	 * Gets List of Market Place Organizations based on CustomerOrg Type
	 *    if orgType= BCMB -- returns BCM Market Place Organizations available in custOrgId's branch 
	 *    if orgType= SCMS -- returns SCM Market Place Organizations available in custOrgId's branch 
	 *    if orgType=BCMMPB/SCMMPS -- returns the Parent Market Place Organization
	 * 
	 * @param custOrgId the CustomerOrganization Id	
	 * @return List of Market Place org with Short name
	 * @throws BNPApplicationException
	 */
	List<NameValueVO> getMarketPlaceOrgList(String custOrgId) throws BNPApplicationException;
}
