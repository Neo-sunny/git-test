/* *********************************************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 9, 20126:47:17 PM
 * 
 * Purpose:      IDepartmentApprovalService.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 * Feb 9, 20126:47:17 PM        Oracle Financial Services Software Ltd                  Initial Version  
 * 27/04/2012					Sandhya R												R2.1 SIT Defect #2142 - Added a boolean parameter for fetching record to diff from pending action access
 * 07/09/2012					Sandhya R												R3.0 Auto Payment Preparation Changes 
**************************************************************************************************************************************************************************************************/
package com.bnp.eipp.services.invoice;

import java.util.List;
import java.util.Map;

import com.bnp.eipp.services.invoice.vo.EippAuditVO;
import com.bnp.eipp.services.invoice.vo.EippCreditNoteUtilVO;
import com.bnp.eipp.services.invoice.vo.EippCustFieldsVO;
import com.bnp.eipp.services.invoice.vo.EippDeptDisplayVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.scm.services.common.vo.AttachmentVO;
import com.bnp.eipp.services.vo.dispute.DisputeVO;
import com.bnp.scm.services.common.ITransactionService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

/**
 * The Interface IDepartmentApprovalService.
 *
 * @author SandhyaRad
 */
public interface IDepartmentApprovalService extends ITransactionService {
	
	/**
	 * Fetch dept approval summary.
	 *
	 * @param invoiceVO the invoice vo
	 * @return the list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippInvoiceVO> fetchDeptApprovalSummary(EippInvoiceVO invoiceVO, boolean isPendingAction) throws BNPApplicationException;
	
	/**
	 * Gets the custom fields for invoice.
	 *
	 * @param invId the inv id
	 * @return the custom fields for invoice
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippCustFieldsVO> getCustomFieldsForInvoice(long invId) throws BNPApplicationException;
	
	/**
	 * Gets the cnt util list.
	 *
	 * @param invId the inv id
	 * @return the cnt util list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippCreditNoteUtilVO> getCntUtilList(long invId) throws BNPApplicationException;
	
	/**
	 * Gets the inv line items.
	 *
	 * @param inputVO the input vo
	 * @return the inv line items
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippInvCntLineItemVO> getInvLineItems(EippInvCntLineItemVO inputVO) throws BNPApplicationException;
	
	/**
	 * Gets the inv dispute list.
	 *
	 * @param invId the inv id
	 * @return the inv dispute list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<DisputeVO> getInvDisputeList(long invId) throws BNPApplicationException;
	
	/**
	 * Approve invoice.
	 *
	 * @param invoiceVOs the invoice v os
	 * @return the map
	 * @throws BNPApplicationException the bNP application exception
	 */
	Map<String, List<Integer>> approveInvoice(List<EippInvoiceVO> invoiceVOs) throws BNPApplicationException;
	
	/**
	 * Approve invoice line items.
	 *
	 * @param invoiceVO
	 * @return the map
	 * @throws BNPApplicationException the bNP application exception
	 */
	Map<String, List<Integer>> approveInvoiceLineItems(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException;
	
	/**
	 * Gets the department list for reassigning.
	 *
	 * @param invoiceVO the invoice vo
	 * @return the department list for reassigning
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippDeptDisplayVO> getDepartmentListForReassigning(EippInvoiceVO invoiceVO) throws BNPApplicationException;

	/**
	 * Gets the users list for reassigning.
	 *
	 * @param invoiceVO the invoice vo
	 * @return the users list for reassigning
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<String> getUsersListForReassigning(EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
	/**
	 * Gets the existing assignees.
	 *
	 * @param invoiceVO the invoice vo
	 * @return the existing assignees
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getExistingAssignees(EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
	/**
	 * Change status to pending.
	 *
	 * @param invoiceVO the invoice vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void changeStatusToPending(EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
	/**
	 * Reassign invoices.
	 *
	 * @param invoiceVO the invoice vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void reassignInvoices(EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
	/**
	 * Gets the line items for invoice.
	 *
	 * @param invoiceVO the invoice vo
	 * @return the line items for invoice
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippInvCntLineItemVO> getLineItemsForInvoice(EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
	/**
	 * Reject invoices.
	 *
	 * @param invoiceVOs the invoice v os
	 * @return the map
	 * @throws BNPApplicationException the bNP application exception
	 */
	Map<String, List<Integer>> rejectInvoices(List<EippInvoiceVO> invoiceVOs) throws BNPApplicationException;
	
	/**
	 * Gets the invoice audit details.
	 *
	 * @param invId the inv id
	 * @return the invoice audit details
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippAuditVO> getInvoiceAuditDetails(long invId) throws BNPApplicationException;

	/**
	 * Gets the invoice line item audit details.
	 *
	 * @param lineItemID the line item id
	 * @return the invoice line item audit details
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippAuditVO> getInvoiceLineItemAuditDetails(long lineItemID) throws BNPApplicationException;
	

	/**
	 * Reassign invoice line items.
	 *
	 * @param inputVO the input vo
	 * @return the map
	 * @throws BNPApplicationException the bNP application exception
	 */
	Map<String, List<Integer>> reassignInvoiceLineItems(List<EippInvCntLineItemVO> inputVO) throws BNPApplicationException;
	
	/**
	 * Upload invoice attachment.
	 *
	 * @param attachVO the attach vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void uploadInvoiceAttachment(AttachmentVO attachVO) throws BNPApplicationException;
	
	/**
	 * Gets the attachments.
	 *
	 * @param invId the inv id
	 * @return the attachments
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<AttachmentVO> getAttachments(long invId) throws BNPApplicationException;
	
	/**
	 * Gets the custom fields for line items.
	 *
	 * @param lineItemId the line item id
	 * @return the custom fields for line items
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippCustFieldsVO> getCustomFieldsForLineItems(long lineItemId) throws BNPApplicationException;
	
	/**
	 * Gets the dispute attachments.
	 *
	 * @param dispVO the disp vo
	 * @return the dispute attachments
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<AttachmentVO> getDisputeAttachments(DisputeVO dispVO) throws BNPApplicationException;
	
	/**
	 * Gets the buyer org list.
	 *
	 * @param input the input
	 * @return the buyer org list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getBuyerOrgList(NameValueVO input) throws BNPApplicationException;
	
	/**
	 * Gets the supplier org list.
	 *
	 * @param input the input
	 * @return the supplier org list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getSupplierOrgList(NameValueVO input) throws BNPApplicationException;
	
	

}
