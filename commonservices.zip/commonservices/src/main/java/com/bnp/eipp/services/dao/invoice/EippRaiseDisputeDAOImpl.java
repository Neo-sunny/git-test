/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  28 Aug 2012	   
 * 
 * Purpose:     Raise Dispute Dao Implementation
 * 
 * Change History: 
 * Date                                      	 Author                              Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 28 Aug 2012	       							Dinesh D                 		 Initial Version  
 * 25 Oct 2012	       							Ravishankar V                 	 ST Defects 7042 and 7050  
 *****************************************************************************************************************************************************************/


package com.bnp.eipp.services.dao.invoice;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.vo.dispute.DisputeCustFieldsVO;
import com.bnp.eipp.services.vo.dispute.DisputeVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.BNPRuntimeException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.ibatis.sqlmap.client.SqlMapExecutor;
import com.ibatis.sqlmap.engine.execution.BatchException;

@Component 
public class EippRaiseDisputeDAOImpl extends SqlMapClientWrapper implements IEippRaiseDisputeDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(EippRaiseDisputeDAOImpl.class);

	private static final String NAMESPACE="DisputeMgmtNS";
	private static final String GET_AVAILABLE_INV_COUNT_FOR_RAISE_DISPUTE="getAvailableInvCountForRaiseDispute";
	private static final String UPDATE_RECORD_STATUS_IN_TRANS = "updateRaiseDisputeStatusInTrans";

	private static final String INSERT_RAISE_DISPUTE_DETAILS = "insertRaiseDisputeDetails";
	private static final String INSERT_INTO_DISPUTE_AUDIT = "insertIntoDisputeAudit";
	private static final String INSERT_RAISE_DISPUTE_INTO_HISTORY_FROM_TRANS = "insertRaiseDisputeIntoHistoryFromTrans";
	private static final String INSERT_RAISE_DISPUTE_INTO_MASTER = "insertRaiseDisputeIntoMaster";
	private static final String INSERT_RAISE_DISPUTE_INTO_HISTORY_FROM_MASTER = "insertRaiseDisputeIntoHistoryFromMaster";
	private static final String DELETE_RAISE_DISPUTE_FROM_TRANS = "deleteRaiseDisputeFromTrans";
	private static final String GET_RAISE_DISPUTE_LIST = "getRaiseDisputeList";
	private static final String IS_VALID_RESOLUTION_CODE = "isValidResolutionCode";
	private static final String GET_DISPUTE_ID ="getDisputeID";
	private static final String GET_VALID_LINEITEM_NO_LIST="getValidLineItemNoList";
	private static final String GET_VALID_DEPT_USER_LIST="getValidDeptUserList"; 
	private static final String GET_VALID_ALLOC_TYPE = "getValidAllocType";
	private static final String INSERT_DISPUTE_ATTACHMENTS = "insertDispAttachments";
	private static final String GET_DISPUTE_ALLOC_LEVEL = "getDisputeAllocLevel";

	private static final String FOR_LI = "ForLI";

	public EippRaiseDisputeDAOImpl()
	{
		nameSpace=NAMESPACE;
	}
	@Override
	public List<DisputeVO> getRaiseDisputeList(long fileId){
		List<DisputeVO> invoiceList = null;
		invoiceList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_RAISE_DISPUTE_LIST),fileId);
		return invoiceList;
	}	

	@Override
	public List<DisputeCustFieldsVO> getRaiseDisputeListForLI(long invId){
		List<DisputeCustFieldsVO> invoiceList = null;
		invoiceList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_RAISE_DISPUTE_LIST.concat(FOR_LI)),invId);
		return invoiceList;
	}

	@Override
	public int isInvAvailableForRaiseDispute(EippInvoiceVO eippInvoiceVO)throws BNPApplicationException {
		int count = 0;
		try{
			count =  (Integer) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_AVAILABLE_INV_COUNT_FOR_RAISE_DISPUTE), eippInvoiceVO);
			return count;
		}catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	@Override
	public void insertFileDetailsIntoHistFromTrans(FileDetailsVO detailsVO)
			throws DBException {
		try {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("fileId", detailsVO.getFileId());
			paramMap.put("requestStatus", "WA");
			paramMap.put("fileStatus", StatusConstants.RELEASED);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_RAISE_DISPUTE_INTO_HISTORY_FROM_TRANS), 
					paramMap);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_RAISE_DISPUTE_INTO_HISTORY_FROM_TRANS.concat(FOR_LI)), 
					paramMap);			
		} catch (DataAccessException e) {
			LOGGER.error("Error while processing raise disputes : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}

	}
	@Override
	public void insertFileDetailsIntoMaster(FileDetailsVO detailsVO) throws DBException {
		try {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("fileId", detailsVO.getFileId());
			paramMap.put("requestStatus", "WA");
			paramMap.put("fileStatus", StatusConstants.RELEASED);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_RAISE_DISPUTE_INTO_MASTER), 
					paramMap);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_RAISE_DISPUTE_INTO_MASTER.concat(FOR_LI)), 
					paramMap);	
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_DISPUTE_ATTACHMENTS), 
					paramMap);
		} catch (DataAccessException e) {
			LOGGER.error("Error while releasing raise disputes : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public void insertFileDetailsIntoHistFromMaster(FileDetailsVO detailsVO) throws DBException {
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_RAISE_DISPUTE_INTO_HISTORY_FROM_MASTER), 
					detailsVO.getFileId());
		} catch (DataAccessException e) {
			LOGGER.error("Error while releasing raise disputes : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}

	}

	@Override
	public void deleteFileDetailsFromTrans(FileDetailsVO detailsVO) throws DBException {
		try {
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(DELETE_RAISE_DISPUTE_FROM_TRANS.concat(FOR_LI)), 
					detailsVO.getFileId());
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(DELETE_RAISE_DISPUTE_FROM_TRANS), 
					detailsVO.getFileId());

		} catch (DataAccessException e) {
			LOGGER.error("Error while deleting raise disputes : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}

	}

	@Override
	public void updateRecordStatusInTrans(long fileId, String status) throws BNPApplicationException {
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("fileId", fileId);
		params.put("status", status);

		try{
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_RECORD_STATUS_IN_TRANS), params);
		} catch (DataAccessException e) {
			LOGGER.error(e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}		
	}

	@Override
	public void insertRaiseDisputeList(final List<DisputeVO> raiseDisputeList,final FileDetailsVO fileVO) throws BNPRuntimeException{
		try {
			getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
				public List<Object> doInSqlMapClient(SqlMapExecutor executor)
						throws SQLException {
					List<Object> list = null;
					try {
						for (DisputeVO disputeVO : raiseDisputeList) {
							long dispId=(Long) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_DISPUTE_ID));
							// inserting raise dispute details
							executor.startBatch();
							disputeVO.setPkId(dispId);
							disputeVO.setFileId(fileVO.getFileId());
							disputeVO.setStatus(StatusConstants.PENDING_FOR_APPROVAL);
							disputeVO.setMakerId(fileVO.getUserId());
							disputeVO.setMakerDate(new Date(System.currentTimeMillis()));
							disputeVO.setRecordStatus(StatusConstants.WAITING_FOR_APPROVAL_REQUEST);
							executor.insert(getQueryNameWithNameSpace(INSERT_RAISE_DISPUTE_DETAILS), disputeVO);
							list = executor.executeBatchDetailed();

							if(StatusConstants.DISPUTED_AT_INVOICE_LEVEL.equalsIgnoreCase(disputeVO.getDisputedAt()))
							{
								DisputeCustFieldsVO custField=new DisputeCustFieldsVO();
								custField.setFieldName(BNPConstants.NET_AMOUNT);
								custField.setOldValue(disputeVO.getOldNetAmt());
								custField.setNewValue(disputeVO.getNewNetAmt());
								custField.setRefNo(disputeVO.getEippInvoice().getInvRefNo());
								List<DisputeCustFieldsVO> tempList =new ArrayList<DisputeCustFieldsVO>();
								tempList.add(custField);
								disputeVO.setCustFieldsList(tempList);
							}
							// inserting raise dispute line items details
							executor.startBatch();
							for (DisputeCustFieldsVO  custField : disputeVO.getCustFieldsList())
							{
								//custField.setRefNo(custField.getRefNo().trim());
								custField.setDispId(dispId);
								executor.insert(getQueryNameWithNameSpace(INSERT_RAISE_DISPUTE_DETAILS.concat(FOR_LI)),custField);
							}
							executor.executeBatchDetailed();
						}


					} catch (BatchException e) {							
						LOGGER.error("Uploading the raise dispute details in a batch failed");
						throw new SQLException(e);
					} 
					// R7.0 Fortify issues
					//LOGGER.debug("List :: " + list);
					return list;
				}
			});
		} catch (DataAccessException e) {
			throw new BNPRuntimeException(ErrorConstants.DATABASE_ERROR);
		}
	}
	@Override
	public int isValidResolutionCode(DisputeVO disputeVO)
			throws BNPApplicationException {
		int count = 0;
		try{
			disputeVO.setCodeType(StatusConstants.DISPUTE_CODE);
			
			count =  (Integer) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(IS_VALID_RESOLUTION_CODE), disputeVO);
			return count;
		}catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	@Override
	public List<DisputeCustFieldsVO> getValidLineItemNoList(DisputeVO disputeVO)
			throws BNPApplicationException {
		List<DisputeCustFieldsVO> custFieldsList=disputeVO.getCustFieldsList();
		Set<List<DisputeCustFieldsVO>> subListSet=getSubLists(custFieldsList);
		List<DisputeCustFieldsVO> validList=new ArrayList<DisputeCustFieldsVO>();
		Map<String, Object> params = null;
		for (List<DisputeCustFieldsVO> subList : subListSet) {
			params = new HashMap<String, Object>();
			params.put("dispLineItemList", subList);
			params.put("invId", disputeVO.getEippInvoice().getInvId());
			validList.addAll(getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_VALID_LINEITEM_NO_LIST),params));
		}
		return validList;
	}
	@Override
	public boolean isValidDeptUser(DisputeVO disputeVO)
			throws BNPApplicationException {
		List<String> deptUserList=getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_VALID_DEPT_USER_LIST),disputeVO);
		if(disputeVO.getRaisedBy()!=null && disputeVO.getDisputeApprovedBy()!=null)
		{
		return (deptUserList.contains(disputeVO.getCurrentUserId()) && deptUserList.contains(disputeVO.getRaisedBy())&& deptUserList.contains(disputeVO.getDisputeApprovedBy()));
		}else{
			return (deptUserList.contains(disputeVO.getCurrentUserId()));
		}
	}
	@Override
	public String getDisputeAllocType(DisputeVO disputeVO)
			throws BNPApplicationException {
		String allocType =  (String) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_VALID_ALLOC_TYPE), disputeVO);
		return allocType;
	}
	@Override
	public int getDisputeAllocLevel(DisputeVO disputeVO)
			throws BNPApplicationException {
		return (Integer) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_DISPUTE_ALLOC_LEVEL), disputeVO);
	}

}
