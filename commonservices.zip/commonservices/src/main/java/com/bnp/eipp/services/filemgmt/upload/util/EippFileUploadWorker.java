/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   07 Feb 12 
 * 
 * Purpose:      EIPP Invoice Upload Screen 
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 07 Feb 12                      Oracle Financial Services Software Ltd                                  Thread Pool changes for file upload
 * 
 *****************************************************************************************************************************************************************/

package com.bnp.eipp.services.filemgmt.upload.util;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnp.eipp.services.invoice.IEippInvcUploadService;
import com.bnp.eipp.services.invoice.vo.EippInvCntVO;
import com.bnp.scm.services.common.IBNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.filemgmt.vo.FileUploadVO;
import com.bnp.scm.services.invoice.IInvoiceUploadService;
import com.bnp.scm.services.txns.common.message.AbstractMessage;
import com.ibm.websphere.asynchbeans.Work;

public class EippFileUploadWorker implements Work, IEippFileUploadWorker {


	private AbstractMessage<?> invoiceMessage;
	
	FileDetailsVO detailsVO;
	
	FileUploadVO uploadVO;
	
	private static Logger LOGGER =LoggerFactory.getLogger(EippFileUploadWorker.class);
	
	private IEippInvcUploadService eippInvcUploadService;
	
	private	IBNPPropertyLoaderConfigurer propertyLoader;
	
	private IInvoiceUploadService invoiceUploadService;
	
	public AbstractMessage<?> getInvoiceMessage() {
		return invoiceMessage;
	}

	public void setInvoiceMessage(AbstractMessage<?> invoiceMessage) {
		this.invoiceMessage = invoiceMessage;
	}

	public FileDetailsVO getDetailsVO() {
		return detailsVO;
	}

	public void setDetailsVO(FileDetailsVO detailsVO) {
		this.detailsVO = detailsVO;
	}

	public FileUploadVO getUploadVO() {
		return uploadVO;
	}

	public void setUploadVO(FileUploadVO uploadVO) {
		this.uploadVO = uploadVO;
	}

	@Override
	public void run() {
		
		
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("Inside Run Method>>>>>>>>>>>>"+invoiceMessage+"  "+detailsVO+"  "+invoiceUploadService+"  "+propertyLoader);
		try {
			detailsVO.setFileUploadStatus(propertyLoader
					.getValue("file.status.processing"));
			invoiceUploadService.updateFileStatus(detailsVO);
			Map<String, List<EippInvCntVO>> eippInvCntMap=null;
	
			eippInvCntMap =eippInvcUploadService.processInvoiceDetails(invoiceMessage, detailsVO);
			
			//976332 CSCDEV-2683 20-NOV-2014:START
			//LOGGER.debug("Invoice Payamentmap....."+eippInvCntMap);
			LOGGER.debug("Invoice Payamentmap.....");
			//976332 CSCDEV-2683 20-NOV-2014:END
			eippInvcUploadService.releaseFile(invoiceMessage, detailsVO, eippInvCntMap);
			
			if (detailsVO.getFileStatus() != null) {
				uploadVO.getFileVO().setStatusMessage(
							detailsVO.getFileStatus());
			}
		}catch (BNPApplicationException exception) {
			LOGGER.debug("File Processing failed due to validation");
			detailsVO.setFileUploadStatus(propertyLoader
					.getValue("file.status.validation.fail"));
			detailsVO.setErrorCode(Integer.valueOf(exception.getErrorCode()).toString());
			detailsVO.setErrorDesc(exception.getErrorMessage());
			
			try {
				invoiceUploadService.triggerEventLog(detailsVO, "FAILURE");
				invoiceUploadService.updateFileStatus(detailsVO);
			} catch (BNPApplicationException e) {
					throw new RuntimeException(String.valueOf(e.getErrorCode()));
			}
			
		}
	}

	@Override
	public void release() {
				
	}

	@Override
	public void setPropertyLoader(IBNPPropertyLoaderConfigurer propertyLoader) {
		this.propertyLoader = propertyLoader;		
	}

	@Override
	public void setEippInvcUploadService(IEippInvcUploadService eippInvcUploadService) {
		this.eippInvcUploadService = eippInvcUploadService;
	}
	
	@Override
	public void setInvoiceUploadService(IInvoiceUploadService service) {
		this.invoiceUploadService = service;
		
	}



}
