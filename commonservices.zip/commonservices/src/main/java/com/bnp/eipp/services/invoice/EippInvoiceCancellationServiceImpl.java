/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  * 06 MARCH  2012 
 * 
 * Purpose:     Invoice Cancellation Services Implementation
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 *  * 06 MARCH  2012               	Oracle Financial Services Software Ltd            	Initial Version		Added for new screen invoice cancellation
 * 24/04/2012						Sandhya R										   	R2.1 Added event log
 * 12-July 2012                    	Oracle Financial Services Software Ltd            	EIPP Phase II - Cancel Invoice MFU
 *  13 Aug 2012						Arun G												Eipp Phase2 events
*  14 Sep 2012						Prabakaran S										Modified for EIPP Inv Attachments  
*   15 Oct 2012						Merdith S											ST 6894 - Fix for Invoice cancellation for payment prepared Invoice
*  22 OCT 2012					    Sadhana A V						                    Rel 3.0 - Message monitoring changes (Functional ack message type corrected)
*  30 Oct 2012 		 		 		Arun G													Events ST Issues
*  09 Nov 2012						 Raja S 											Change Done for Invoice Cancellation Check through screen  
*****************************************************************************************************************************************************************/

package com.bnp.eipp.services.invoice;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnp.eipp.services.dao.invoice.IEippInvoiceCancellationDAO;
import com.bnp.eipp.services.filemgmt.EippAbstractFileReleaseServiceImpl;
import com.bnp.eipp.services.interfaces.invoiceupload.EippInvoiceCancelMessage;
import com.bnp.eipp.services.invoice.cancelinvoice.bindingvo.Document;
import com.bnp.eipp.services.invoice.cancelinvoice.bindingvo.ErrorMessage;
import com.bnp.eipp.services.invoice.cancelinvoice.bindingvo.ErrorMessages;
import com.bnp.eipp.services.invoice.cancelinvoice.bindingvo.File;
import com.bnp.eipp.services.invoice.cancelinvoice.bindingvo.FinancialInvoice;
import com.bnp.eipp.services.invoice.cancelinvoice.bindingvo.Header;
import com.bnp.eipp.services.invoice.dao.IEippInvcUploadDAO;
import com.bnp.eipp.services.invoice.util.EippAuditConstants;
import com.bnp.eipp.services.invoice.vo.EippAuditVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceCancelVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.invoice.vo.EippTransactionVO;
import com.bnp.eipp.services.txns.util.file.EippFileUtil;
import com.bnp.eipp.services.vo.invoice.InvoiceCancellationVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.event.EventType;
import com.bnp.scm.services.common.event.IEventDelegate;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.common.vo.AttachmentVO;
import com.bnp.scm.services.common.vo.EventLogVO;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.invoice.IInvoiceUploadService;
import com.bnp.scm.services.invoice.vo.InvalidFileDataVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;
import com.bnp.scm.services.txns.util.PropertiesReader;
import com.bnp.scm.services.txns.util.xml.XmlBinding;

@Component
public class EippInvoiceCancellationServiceImpl extends EippAbstractFileReleaseServiceImpl implements IEippInvoiceCancelServices {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(EippInvoiceCancellationServiceImpl.class);
	
	@Autowired 
	private IEippInvoiceCancellationDAO invCancelDAO;
	
	@Autowired
	private IEippInvoiceService invoiceService;
	
	@Autowired
	private IEventDelegate eventDelegateImpl;
	
	@Autowired
	private IEippInvcUploadDAO eippInvcUploadDAO;
	
	@Autowired
	private IInvoiceUploadService uploadService;
	
	/**
	 * Method to fetch the invoice details 
	 * @param objInvVO : VO containing the invoice details 
	 * @return list : containing the invoice details 
	 * @throws BNPApplicationException : thrown when there is an exception 
	 */
	@Override
	public List<InvoiceCancellationVO> getInvoiceDetails(InvoiceCancellationVO searchVO) throws BNPApplicationException {
		return invCancelDAO.getInvoiceDetails(searchVO);
	}

	

	/**
	 * Method to get the invoice line item details 
	 * @param invoiceId: the invoice Identifier 
	 * @return list conatining the invoice line item details 
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	@Override
	public List<EippInvCntLineItemVO> getInvoiceLineItemDetails(long invoiceId)throws BNPApplicationException {
		return invCancelDAO.getInvoiceLineItemDetails(invoiceId);
	}
	/**
	 * Method To get the custom feild details
	 * @param invoiceId : the invoice identifier 
	 * @return list : containing teh custom feild details 
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	@Override
	public List<NameValueVO> getInvoiceCustomFields(long invoiceId)	throws BNPApplicationException {
		return invCancelDAO.getInvoiceCustomFields(invoiceId);
	}
	/**
	 * 	Method to the line item custom details 
	 * @param invcLineItemId : line item identifier  
	 * @return list : containing the invoice custom line item details 
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	@Override
	public List<NameValueVO> getInvcLineItemCustomFields(long invcLineItemId)throws BNPApplicationException {		
		return invCancelDAO.getInvcLineItemCustomFields(invcLineItemId);
	}
	/**
	 * Method To get the invoice details 
	 * @param invoiceId : invoice identifier 
	 * @return list containing the elements to be populated in Details page 
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	@Override
	public List<EippInvCntLineItemVO> getInvoiceDetailsFields(long invoiceId)
			throws BNPApplicationException {
		return invCancelDAO.getInvoiceDetailsFields(invoiceId);
	}
	/**
	 * Method to get the audit record details 
	 * @param invoiceId : invoice identifier 
	 * @return list : containing the audit record details 
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	@Override
	public List<InvoiceCancellationVO> getInvoiceAuditRecDetails(long linvoiceId)
			throws BNPApplicationException {
		return invCancelDAO.getInvoiceAuditRecDetails(linvoiceId);
	}
	/**
	 * To get the line item audit details 
	 * @param lineItemId : line item identifier 
	 * @return list : containing the line item audit details 
	 *@throws BNPApplicationException : thrown when there is an exception
	 */
	@Override
	public List<InvoiceCancellationVO> getLineItemAuditDetails(long lineItemId)
			throws BNPApplicationException {
		return invCancelDAO.getLineItemAuditDetails(lineItemId);
	}
	/**
	 * Method to cancel the record
	 * @param invoiceId : invoice identifier 
	 * @param status 
	 * @param string 
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	@Override
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	
	public int cancelRecord(long invoiceId, String strUser,
			String status) throws BNPApplicationException {
		int iCount = 0;
		try
		{
			iCount = invCancelDAO.cancelRecord(invoiceId,strUser,status);
			
			createInvoiceAudit(invoiceId, strUser, status, 
					EippAuditConstants.INV_PENDING_CANCELLATION);
			invCancelDAO.cancelAuditRecord(invoiceId);
		}
		catch (DBException e) {
			throw new BNPApplicationException("Exception in EippInvoiceCancellationServiceImpl :::: cancelRecord() " + e.getErrorMessage());
		}

		return iCount;
	}
	/**
	 * Method to approve the records 
	 * @param invoiceId : invoice identifier 
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	@Override
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	public int approveRecordDetails(InvoiceCancellationVO invCancellationVO, String strUserId, String strStatus)
			throws BNPApplicationException {
		int iCount = 0;
		try{
			iCount = invCancelDAO.approveRecord(invCancellationVO.getInvoiceId(),strUserId, strStatus);
			createInvoiceAudit(invCancellationVO.getInvoiceId(), strUserId, 
					strStatus, EippAuditConstants.INV_CANCELLED);
			invCancelDAO.approveAuditRecord(invCancellationVO.getInvoiceId());
			invCancellationVO.setCheckerId(strUserId);
			insertEventLog(invCancellationVO,EventType.EIPP_INV_CANCEL);
			
		}catch (DBException e) {
			throw new BNPApplicationException("Exception in EippInvoiceCancellationServiceImpl :::: approveRecordDetails() " + e.getErrorMessage());
		}
		return iCount;
	}
	/**
	 * Method to get the attachment details 
	 * @return list : containing the attachment details
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	@Override
	public List<AttachmentVO> getAttachmentDetails(long lInvoiceId)
			throws BNPApplicationException {
		return invCancelDAO.getAttachmentDetails(lInvoiceId);
	}
	
	/**
	 * Method to trigger Event Logger to insert into T_EVENT_LOG table
	 * @param detailsVO: VO containing the values to be inserted in DB
	 * @param releasedBy : the logged in user
	 */
	/*private void triggerEventLog(InvoiceCancellationVO detailsVO ,String strUserId){
		EventLogVO eventLogVO=new EventLogVO();
		eventLogVO.setEventName(BNPConstants.EVENT_TRANS_READY_FOR_DISC);
		eventLogVO.setOrgId(detailsVO.getOrgId());
		eventLogVO.setReferenceKey(String.valueOf(detailsVO.getInvoiceId()));
		eventLogVO.setEventInitiator(strUserId);
		eventLogService.triggerEventLog(eventLogVO);
	}*/

	/**
	 * to reset the processing flag after update operations
	 * 
	 */
	@Override
	public void resetProcessingFlag(Object txnObj)
			throws BNPApplicationException {
		getDao().resetProcessingFlag(txnObj);
	}
	/**
	 * to update the timestamp after update operations
	 * 
	 */
	@Override
	public void updateTxnTimestamp(Object txnObj) throws BNPApplicationException {
		 getDao().updateTxnTimestamp(txnObj);
	
	}

	@Override
	public SqlMapClientWrapper getDao() {
		return (SqlMapClientWrapper)invCancelDAO;
	}


	/**
	 * Method to get Supplier Org Id for Suggestion box
	 * @param userId: USER iD 
	 * @param userType: TYPE OF USER 
	 * @return List of Org Id 
	 * @throws BNPApplicationException : thrown in case of exceptions
	 */
	@Override
	public List<NameValueVO> getSupplierOrgList(String userId,String userType)
			throws BNPApplicationException {
		return invCancelDAO.fetchSupplierOgList(userId,userType);
	}

	/**
	 * Method to get Buyer Org Id for Suggestion box
	 * @param userId: USER iD 
	 * @param userType: TYPE OF USER 
	 * @return List of Org Id 
	 * @throws BNPApplicationException : thrown in case of exceptions
	 */

	@Override
	public List<NameValueVO> getBuyerOrgList(String userId,String userType)
			throws BNPApplicationException {
		return invCancelDAO.fetchBuyerOrgList(userId,userType);
	}
	
	/**
	 * Creates the invoice audit.
	 *
	 * @param invoiceId the invoice id
	 * @param userId the user id
	 * @param status the status
	 * @param action the action
	 */
	private void createInvoiceAudit(long invoiceId, 
			String userId, String status, String action) {
		try {
			EippAuditVO auditVO = new EippAuditVO();
			auditVO.setInvId(invoiceId);
			auditVO.setAuditUser(userId);
			auditVO.setStatus(status);
			auditVO.setAction(action);
			
			invoiceService.createInvoiceAudit(auditVO);
		} catch (BNPApplicationException e) {
			LOGGER.error("Error while creating invoice audit " + e.getErrorCode());			
		}
	}
	
	/**
	 * Insert event log.
	 *
	 * @param invCancelVO the inv cancel vo
	 * @param eventType the event type
	 */
	private void insertEventLog(InvoiceCancellationVO invCancelVO, EventType eventType) {
		EventLogVO eventVO = new EventLogVO();
		
		try {
			eventVO.setReferenceKey(String.valueOf(invCancelVO.getPkId()));
			eventVO.setEventType(eventType);
			eventVO.setEventInitiator(invCancelVO.getCheckerId());
			eventVO.setSellerOrgId(invCancelVO.getSupplierOrgId());
			eventVO.setBuyerOrgId(invCancelVO.getBuyerOrgId());
			eventVO.setMarketPlaceOrgID(invCancelVO.getMarketPlaceOrgID());

			eventDelegateImpl.initEvents(eventVO);
		} catch (BNPApplicationException e) {
			LOGGER.error("Error while inserting into event log" + e);
		}
	}

	public List<InvoiceCancellationVO> getCancelInvoiceDetails(
			long fileId, String status) throws BNPApplicationException{
		return invCancelDAO.getCancelInvoiceDetails(fileId, status);
	}

	@Override
	public int isInvoiceAvailableForCancel(EippInvoiceCancelVO eippInvoiceCancelVO) throws BNPApplicationException {
		Properties params= new Properties();
		params.put("invRefNo", eippInvoiceCancelVO.getInvRefNo());
		params.put("supplierOrgId", eippInvoiceCancelVO.getSupplierOrgId());
		params.put("buyerOrgId", eippInvoiceCancelVO.getBuyerOrgId());
		params.put("billType", eippInvoiceCancelVO.getBillType());
		params.put("issueDate", eippInvoiceCancelVO.getIssueDate());
		params.put("refDate", eippInvoiceCancelVO.getRefDate());
		
		return eippInvcUploadDAO.isInvoiceAvailableInSystem(params);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceCancelServices#insertFileDetailsIntoTrans(java.util.List, com.bnp.scm.services.filemgmt.vo.FileDetailsVO)
	 */
	/*@Override
	public void insertFileDetailsIntoTrans(
			List<T> validObjectList, FileDetailsVO detailsVO) throws BNPRuntimeException {
		eippInvcUploadDAO.insertCancelInvoiceList(validObjectList, detailsVO);
	}*/
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceCancelServices#insertFileDetailsIntoHistFromTrans(java.util.List, com.bnp.scm.services.filemgmt.vo.FileDetailsVO)
	 */
	@Override
	public void insertFileDetailsIntoHistFromTrans(FileDetailsVO detailsVO)
			throws BNPApplicationException {
		invCancelDAO.insertFileDetailsIntoHistFromTrans(detailsVO);
		
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceCancelServices#insertFileDetailsIntoHistFromMaster(java.util.List, com.bnp.scm.services.filemgmt.vo.FileDetailsVO)
	 */
	@Override
	public void insertFileDetailsIntoHistFromMaster(FileDetailsVO detailsVO)
			throws BNPApplicationException {
		invCancelDAO.insertFileDetailsIntoHistFromMaster(detailsVO);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceCancelServices#insertFileDetailsIntoMaster(com.bnp.scm.services.filemgmt.vo.FileDetailsVO)
	 */
	@Override
	public void insertFileDetailsIntoMaster(FileDetailsVO detailsVO) throws BNPApplicationException {
		invCancelDAO.insertFileDetailsIntoMaster(detailsVO);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceCancelServices#deleteFileDetailsFromTrans(com.bnp.scm.services.filemgmt.vo.FileDetailsVO)
	 */
	@Override
	public void deleteFileDetailsFromTrans(FileDetailsVO detailsVO) throws BNPApplicationException {
		invCancelDAO.deleteFileDetailsFromTrans(detailsVO);		
	}
	
	public void releaseFile(FileDetailsVO detailsVO, 
			boolean isAutoReleaseEnabled) throws BNPApplicationException {
		releaseFile(null, detailsVO, null, null, isAutoReleaseEnabled);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceCancelServices#releaseFile(com.bnp.scm.services.txns.common.message.AbstractMessage, com.bnp.scm.services.filemgmt.vo.FileDetailsVO, java.util.List, boolean)
	 */
	@Override
	public <T extends EippTransactionVO> void releaseFile(AbstractMessage<?> message,
			FileDetailsVO detailsVO, List<T> dataList,
			DozerBeanMapper beanMapper, boolean isAutoReleaseEnabled) throws BNPApplicationException {
		super.releaseFile(message, detailsVO, dataList, beanMapper, isAutoReleaseEnabled);
	}
	
	/**
	 * This API validates the Invoice before triggering Cancel action
	 * @param detailsVO
	 **/
	@Override
	public void postRelease(FileDetailsVO detailsVO) throws BNPApplicationException {
		List<InvoiceCancellationVO> cancellationVOs = invCancelDAO.getCancelInvoiceList(detailsVO.getFileId());
		processInvoiceCancellation(detailsVO, cancellationVOs);
	}
	
	/**
	 * This API validates the business condition and cancels the Invoice if validation passes  
	 * @param List<InvoiceCancellationVO> 
	 * @throws BNPApplicationException
	 */
	@Override
	public void processInvoiceCancellation(FileDetailsVO detailsVO, List<InvoiceCancellationVO> cancellationVOs) throws BNPApplicationException {

		for(InvoiceCancellationVO cancelInvoiceVO : cancellationVOs){

			InvoiceCancellationVO invoiceVO = (InvoiceCancellationVO) invCancelDAO.getInvoiceForBusinessValidation(cancelInvoiceVO.getInvoiceId());
			int errorCode = doBusinessValidation(invoiceVO);
			if( errorCode == 0){
				approveRecordDetails(invoiceVO, detailsVO.getReleasedBy(),StatusConstants.INVOICE_CANCELLED);
			}else{
				cancelInvoiceVO.setErrorCode(errorCode);
				cancelInvoiceVO.setCheckerId(detailsVO.getReleasedBy());
				//Update error code in cancel invoice table
				invCancelDAO.updateCancelInvoiceErrorCode(cancelInvoiceVO.getPkId(),errorCode);
				insertEventLog(cancelInvoiceVO,EventType.EIPP_INV_CANCEL_FAILED);
				createInvoiceAudit(invoiceVO.getInvoiceId(), detailsVO.getReleasedBy(), StatusConstants.INVOICE_CANCELLATION_FAILED, EippAuditConstants.INV_CANCELLED);
			}
		}
	}

	/**
	 * This API validates whether invoice is eligible for cancel and returns the error code of the failed validation     
	 * @param InvoiceCancellationVO invoiceVO
	 * @throws BNPApplicationException 
	 */
	public int doBusinessValidation(InvoiceCancellationVO invoiceVO) throws BNPApplicationException {
		
		if(invoiceVO.getInvStatus() != null && (invoiceVO.getInvStatus().equals(StatusConstants.INVOICE_CANCELLED) || invoiceVO.getInvStatus().equals(StatusConstants.CANCEL_PENDING_EIPP_APPROVAL))){
			return ErrorConstants.INVOICE_IS_CANCELLED; 
		} else if(invoiceVO.getInvStatus() != null && invoiceVO.getInvStatus().equals(StatusConstants.EIPP_INV_STATUS_CLOSED)){
			return ErrorConstants.INVOICE_IS_CLOSED; 
		}// else if(invoiceVO.getPymtStatus() != null && !invoiceVO.getPymtStatus().equals(StatusConstants.UNPAID)) {
		else if (BigDecimal.ZERO.compareTo(invoiceVO.getBlockedAmt())<0|| BigDecimal.ZERO.compareTo(invoiceVO.getPaidAmt())<0){// ST 6894
			return ErrorConstants.PAYMENT_CREATED_FOR_INVOICE; 
		} else if(invoiceVO.getUtilizedCNCount() > 0){
			return ErrorConstants.CREDIT_NOTE_UTILIZED_AGAINST_INVOICE; 
		}
		return 0;
	}
	
	/**
	 * This API generates the Functional acknowledgment message during file release
	 * @param message
	 * @param detailsVO
	 * @param dataList
	 * @param beanMapper
	 * @param isAutoReleaseEnabled
	 */
	@Override
	public <T extends EippTransactionVO> void generateFunctionalAck(AbstractMessage<?> message, FileDetailsVO detailsVO, List<T> dataList, DozerBeanMapper beanMapper, boolean isAutoReleaseEnabled) throws BNPApplicationException {
		
		if(message == null && !isAutoReleaseEnabled){
			message = prepareMessage(detailsVO);
		}
		else{ 
			if(dataList != null){
				( (File)message.getBody()).setDocument(mapVOToJAXB(dataList, beanMapper, isAutoReleaseEnabled ));
			}
		}
		
		if (message != null) {
			message.setHeader(getAckHeader((Header)message.getHeader(), detailsVO, "message.type.eipp.invCancel.funcack"));
			message.marshallMessage(message.getProperties());
			String xmlContent = message.getXmlMessage();
			XmlBinding.validate(xmlContent, PropertiesReader.getProperty("message.invCancel.xsd.path"));
			detailsVO.setFuncAckData(xmlContent.getBytes());
			detailsVO.setEippfuncAck(BNPConstants.EIPP_INV_CANCEL_FILE_FUNC_ACK);
		}
	}
	
	private <T extends EippTransactionVO> Document mapVOToJAXB(List<T> invoiceCancelList, DozerBeanMapper beanMapper, boolean isAutoReleaseEnabled) {
		Document document = new Document();
		document.getFinInvc().addAll(prepareJAXBObjects(invoiceCancelList, beanMapper, isAutoReleaseEnabled));
		return document;
	}
	
	/**
	 * This API returns the JAXB object with proper status & error messages
	 * @param invoiceCancelList
	 * @param beanMapper
	 * @param isAutoReleaseEnabled
	 * @throws BNPApplicationException 
	 */
	private <T extends EippTransactionVO> List<FinancialInvoice> prepareJAXBObjects(List<T> invoiceCancelList, DozerBeanMapper beanMapper, boolean isAutoReleaseEnabled){

		List<FinancialInvoice> invoices = new ArrayList<FinancialInvoice>();

		for(T eippInvoiceCancelVO : invoiceCancelList){
			FinancialInvoice invoice = beanMapper.map(eippInvoiceCancelVO, FinancialInvoice.class);	
			if (!EippFileUtil.isEmptyList(eippInvoiceCancelVO.getInvalidFileDataList())){
				invoice.setErrMsgs(getErrorMessages(eippInvoiceCancelVO.getInvalidFileDataList(), beanMapper));
				invoice.setStatus(BNPConstants.VALIDATION_FAILED);
			}
			else {
				invoice.setStatus((isAutoReleaseEnabled) ? BNPConstants.RELEASED : BNPConstants.VALIDATION_SUCCESS);
			}
			invoices.add(invoice);
		}
		return invoices;
	}
	
	/**
	 * This method prepares ErrorMessages list for Invalid data
	 * @param invalidDataList
	 * @param beanMapper
	 * @return
	 */
	private ErrorMessages getErrorMessages(List<InvalidFileDataVO> invalidDataList, DozerBeanMapper beanMapper){

		ErrorMessages ermsgs = new ErrorMessages();

		for (InvalidFileDataVO invalidFileDataVO : invalidDataList) {
			ErrorMessage errorMessage = beanMapper.map(invalidFileDataVO, ErrorMessage.class);
			ermsgs.getErrMsg().add(errorMessage);
		}
		
		return ermsgs;
	}
	
	/**
	 * This API returns the EippInvoiceCancelMessage during manual release
	 * @param detailsVO
	 * @throws BNPApplicationException 
	 */
	private AbstractMessage<?> prepareMessage(FileDetailsVO detailsVO) throws BNPApplicationException {
		String msgCancelInvoice = propertyLoader.getValue("message.type.eipp.invoiceCancellation");
		EippInvoiceCancelMessage cancelMessage = new EippInvoiceCancelMessage();
		
		cancelMessage.extractMessage(new String(eventLogDAO.getMsgData(detailsVO.getFileId()+"", msgCancelInvoice.trim())));
		List<InvalidFileDataVO> lstInvalidFileDataVO = uploadService.getRejectedRecords(detailsVO.getFileId());
		boolean bInvalid; 
		for(FinancialInvoice invoice : ((File)cancelMessage.getBody()).getDocument().getFinInvc()){
			bInvalid = false;
			invoice.setErrMsgs(getErrorMessages(lstInvalidFileDataVO, invoice.getInvcHdr().getId()));

			if(invoice.getErrMsgs() != null && invoice.getErrMsgs().getErrMsg() != null && invoice.getErrMsgs().getErrMsg().size() > 0) {
				bInvalid = true;
			} 				
			invoice.setStatus((bInvalid == true) ? BNPConstants.RELEASED : BNPConstants.VALIDATION_FAILED);
		}
		return cancelMessage;
	}


	/**
	 * This method sets the error code & description to the ErrorMessages list for Invalid data based on ref_no
	 * @param lstInvalidFileDataVO
	 * @param id
	 * @return
	 */
	private ErrorMessages getErrorMessages(List<InvalidFileDataVO> lstInvalidFileDataVO, String refNo) {
		ErrorMessages errmsgs = null;
		ErrorMessage errmsg = null;
		for(InvalidFileDataVO invalidFileDataVO :lstInvalidFileDataVO) {
			if(refNo.equals(invalidFileDataVO.getRefNo())){
				if(errmsgs == null) {
					errmsgs = new ErrorMessages();
				}

				errmsg = new ErrorMessage();
				errmsg.setErrorCode(invalidFileDataVO.getErrorMessage());
				errmsg.setErrorDesc(msgService.getMessage("en_US", Integer.parseInt(invalidFileDataVO.getErrorMessage())));
				errmsgs.getErrMsg().add(errmsg);
			}
		}
		return errmsgs;
	}

	/**
	 * This API updates the file status as deleted and 
	 * updates the trans record status as deleted, inserted into history from trans and
	 * deletes the record in cancel invoice trans table
	 * @param detailsVO
	 * @throws BNPApplicationException
	 */
	@Override
	public void deleteFile(FileDetailsVO detailsVO) throws BNPApplicationException {
		invCancelDAO.updateRecordStatusInTrans(detailsVO.getFileId(), StatusConstants.DELETE_RECORD);
		invCancelDAO.insertFileDetailsIntoHistFromTrans(detailsVO);
		invCancelDAO.deleteFileDetailsFromTrans(detailsVO);
	}
	
	/**
	 * This API gets the list of invoices in Ascending order based on File uploaded date/time
	 * @param invoiceVO
	 * @throws BNPApplicationException
	 */
	@Override
	public List<EippInvoiceVO> getInvoiceListForValidation(EippInvoiceCancelVO eippInvoiceCancelVO) throws BNPApplicationException{
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("invRefNo", eippInvoiceCancelVO.getRefNo());
		params.put("supplierOrgId", eippInvoiceCancelVO.getSupplierOrgId());
		params.put("buyerOrgId", eippInvoiceCancelVO.getBuyerOrgId());
		params.put("billType", eippInvoiceCancelVO.getBillType());
		params.put("issueDate", eippInvoiceCancelVO.getIssueDate());
		params.put("invRefDate", eippInvoiceCancelVO.getRefDate());
		
		return eippInvcUploadDAO.getInvoiceListForValidation(params);
	}
	
	/**
	 * This API validates the business condition and cancels the Invoice if validation passes
	 * @param FileDetailsVO
	 * @throws BNPApplicationException
	 */
	@Override
	public void cancelInvoiceForModify(FileDetailsVO detailsVO) throws BNPApplicationException{

		List<EippInvoiceVO> eippInvoiceList = invCancelDAO.getModifyInvoiceList(detailsVO.getFileId());

		for(EippInvoiceVO invoiceVO : eippInvoiceList){
			validateModifyInvoice(detailsVO, invoiceVO);
		}
	}
	
	/**
	 * This API validates the business condition and cancels the Invoice if validation passes
	 * In case of any validation failure the errorCode will be updated in Invoice trans table 
	 * @param FileDetailsVO
	 * @throws BNPApplicationException
	 */	
	private void validateModifyInvoice(FileDetailsVO detailsVO, EippInvoiceVO eippInvoiceVO) throws BNPApplicationException {
		InvoiceCancellationVO invoiceVO = (InvoiceCancellationVO) invCancelDAO.getInvoiceForBusinessValidation(eippInvoiceVO.getOriginalInvId());

		int errorCode = doBusinessValidation(invoiceVO);
		if(errorCode == 0){
			approveRecordDetails(invoiceVO, detailsVO.getReleasedBy(),StatusConstants.INVOICE_CANCELLED);
		}else{
			//Update error code in invoice trans table
			invCancelDAO.updateInvoiceErrorCode(eippInvoiceVO.getInvId(),errorCode);
		}
	}

	@Override
	public <T extends EippTransactionVO> void insertFileDetailsIntoTrans(
			List<T> valueObjectList, FileDetailsVO detailsVO)
			throws BNPApplicationException {
		eippInvcUploadDAO.insertCancelInvoiceList((
				List<EippInvoiceCancelVO>) valueObjectList, detailsVO);		
	}	
}
