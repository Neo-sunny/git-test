/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   17 Oct 2012
 * 
 * Purpose:      IEippZipFileProcessor
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 17 Oct 2012        Oracle Financial Services Software Ltd                  Initial Version    
************************************************************************************************************************************************************/
package com.bnp.eipp.services.filemgmt.processor;

import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.filemgmt.vo.FileUploadVO;

public interface IEippZipFileProcessor {
	
	void processFile(FileDetailsVO detailsVO) throws BNPApplicationException;
	
	long processFile(FileUploadVO uploadVO) throws BNPApplicationException;

}
