/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Jul 29, 201212:54:59 PM
 * 
 * Purpose:     EippAbstractFileReleaseDao
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 29 Jul 2012                      Oracle Financial Services Software Ltd                                    Initial Version 
 *****************************************************************************************************************************************************************/


package com.bnp.eipp.services.dao.filemgmt;

import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;

public interface IEippAbstractFileReleaseDAO{

	/**
	 * @param detailsVO
	 * @throws DBException 
	 */
	public void insertFileDetailsIntoMaster(FileDetailsVO detailsVO) throws DBException;

	/**
	 * @param detailsVO
	 * @throws DBException 
	 */
	public void insertFileDetailsIntoHistFromTrans(FileDetailsVO detailsVO) throws DBException;
	
	/**
	 * @param detailsVO
	 * @throws DBException 
	 */
	public void insertFileDetailsIntoHistFromMaster(FileDetailsVO detailsVO) throws DBException;

	/**
	 * @param detailsVO
	 * @throws DBException 
	 */
	public void deleteFileDetailsFromTrans(FileDetailsVO detailsVO) throws DBException;
}
