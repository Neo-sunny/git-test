/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14 Jan 2012
 * 
 * Purpose:     Link Organization for EIPP Service Interface
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 14 Jan 2012                      Oracle Financial Services Software Ltd             Initial Version
 * 09 Mar 2012		  Oracle Financial Services Software Ltd				 Release 2.1 I1				Changed for Auto Complete Text box Implementation
 * 26 Mar 2012		  Oracle Financial Services Software Ltd				 Release 2.1 I1				TD-5634
 * 05 Apr 2012		  Oracle Financial Services Software Ltd				 Release 2.1 I1				Fix for SIT TD-1866
 * 18 Jul 2012        Reena 												 Release 3.0	            Changes for EIPP-Phase II
 *****************************************************************************************************************************************************************/


package com.bnp.eipp.services.admin;

import java.util.List;
import java.util.Map;

import com.bnp.eipp.services.vo.admin.LinkOrgForEippVO;
import com.bnp.scm.services.common.IAbstractService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

// TODO: Auto-generated Javadoc
/**
 * The Interface ILinkOrgForEippServices.
 */
public interface ILinkOrgForEippServices extends IAbstractService<LinkOrgForEippVO> { 
	
	/**
	 * Gets the link org eipp details.
	 *
	 * @param searchVO the search vo
	 * @return the link org eipp details
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<LinkOrgForEippVO> getLinkOrgEippDetails(LinkOrgForEippVO searchVO)throws BNPApplicationException;
	
	/**
	 * Gets the customer org id list.
	 *
	 * @param userId the user id
	 * @return the customer org id list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getCustomerOrgIdList(String userId,String userType)throws BNPApplicationException;
	
	/**
	 * Gets the counter party org id list.
	 *
	 * @param primeOrgId the prime org id
	 * @return the counter party org id list
	 * @throws BNPApplicationException the bNP application exception
	 * Added additional input 'String userType' -TD:5634
	 */
	List<NameValueVO> getCounterPartyOrgIdList(String primeOrgId,String primeOrgType,String userId,String userType)throws BNPApplicationException;
	
	/**
	 * Gets the bill type list.
	 *
	 * @param orgId the org id
	 * @return the bill type list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getBillTypeList(String orgId)throws BNPApplicationException;
	
	/**
	 * Gets the bill type rule details.
	 *
	 * @param custOrgId the cust org id
	 * @param billType the bill type
	 * @return the bill type rule details
	 * @throws BNPApplicationException the bNP application exception
	 */
	LinkOrgForEippVO getBillTypeRuleDetails(String custOrgId,String billType)throws BNPApplicationException;
	
	/**
	 * Gets the organization role.
	 *
	 * @param orgId the org id
	 * @return the organization role
	 * @throws BNPApplicationException the bNP application exception
	 */
	NameValueVO getOrganizationRole(String orgId)throws BNPApplicationException;
	
	/**
	 * Gets the org deparment list.
	 *
	 * @param orgId the org id
	 * @return the org deparment list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getOrgDeparmentList(String orgId)throws BNPApplicationException;
	
	/**
	 * Chk dependency befor delete.
	 *
	 * @param searchVO the search vo
	 * @return true, if successful
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean chkDependencyBeforDelete(LinkOrgForEippVO searchVO)throws BNPApplicationException;
	/**
	 * Checks whether a record already available in History and Master(Including Deleted record).
	 *
	 * @param searchVO the search vo
	 * @return boolean-True if record exists
	 * @throws BNPApplicationException the bNP application exception
	 */
	public boolean chkRecordAlreadyExists(LinkOrgForEippVO searchVO)throws BNPApplicationException;
	
	/**
	 * Gets the child details.
	 *
	 * @param pkId the pk id
	 * @param masterStatus the master status
	 * @return the child details
	 * @throws BNPApplicationException the bNP application exception
	 */
	LinkOrgForEippVO getChildDetails(long pkId,String masterStatus)throws BNPApplicationException;
	
	/**
	 * View audit link org eipp.
	 *
	 * @param linkOrgVO the link org vo
	 * @return the link org for eipp vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	LinkOrgForEippVO viewAuditLinkOrgEipp(LinkOrgForEippVO linkOrgVO)throws BNPApplicationException;

	/**
	 * This API returns the department available for dispute resolution
	 * based on the customer org id, counter party and the bill type.
	 * @param params - Contains the customer org, counter party and bill type
	 * @return If available, the primary key id of the corresponding dept, else, zero.
	 * @throws BNPApplicationException
	 */
	long getDepartmentForDisputeResolution(Map<String, Object> params)
				throws BNPApplicationException;
	
	/**
	 * Gets the bill type rule details.
	 *
	 * @param custOrgId the cust org id
	 * @param billType the bill type
	 * @return the bill type details(Allow Non Financial processing,
	 *     Deflt Dept for invoice approval,Deflt Dept for dispute resolution, )
	 * @throws BNPApplicationException the bNP application exception
	 */
	LinkOrgForEippVO getBillTypeDeptDetails(String custOrgId,String billType)throws BNPApplicationException;
	
	/**
	 * Gets the counter party org id list.
	 * Added for SIT TD-1866
	 * @param primeOrgId the prime org id
	 * @return the counter party org id list
	 * @throws BNPApplicationException the bNP application exception
	 * Added additional input 'String userType' -TD:5634
	 */
	List<NameValueVO> getCounterPartyOrgIdListSummary(String userId,String userType)throws BNPApplicationException;
	
	/**
	 * Gets the Market Place Organization list.
	 *
	 * @param 
	 * @return the Market Place Organization list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getMarketPlaceOrgList(LinkOrgForEippVO searchVO)throws BNPApplicationException;
	
	
}
