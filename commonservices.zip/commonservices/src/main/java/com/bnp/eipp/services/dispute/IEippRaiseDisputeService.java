/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  * 28 Aug 2012	   
 * 
 * Purpose:     Raise Dispute Services Interface
 * 
 * Change History: 
 * Date                                      	 Author                              Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 28 Aug 2012	       							Dinesh D                 		 Initial Version  
 *****************************************************************************************************************************************************************/


package com.bnp.eipp.services.dispute;

import java.util.List;

import com.bnp.eipp.services.filemgmt.IEippFileReleaseService;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.vo.dispute.DisputeCustFieldsVO;
import com.bnp.eipp.services.vo.dispute.DisputeVO;
import com.bnp.scm.services.common.ITransactionService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;


public interface IEippRaiseDisputeService extends ITransactionService,IEippFileReleaseService {

	int isInvAvailableForRaiseDispute(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException;

	int isValidResolutionCode(DisputeVO disputeVO)throws BNPApplicationException;

	List<DisputeCustFieldsVO> getValidLineItemNoList(DisputeVO disputeVO)throws BNPApplicationException;

	List<Integer> doBusinessValidation(DisputeVO disputeVO)throws BNPApplicationException;

	void releaseFile(FileDetailsVO detailsVO, boolean autoAuthorization)throws BNPApplicationException;

}
