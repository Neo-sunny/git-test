/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 6, 20127:09:23 PM
 * 
 * Purpose:      IEippCNUtilDao.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 6, 20127:09:23 PM        Oracle Financial Services Software Ltd                  Initial Version  
************************************************************************************************************************************************************/

package com.bnp.eipp.services.dao.cnutil;

import java.util.List;

import com.bnp.eipp.services.invoice.vo.EippCreditNoteVO;
import com.bnp.eipp.services.vo.cnutil.EippCNUtilizationVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface IEippCNUtilDao {
	
	List<EippCreditNoteVO> getLinkedCreditNotes(long fileId) throws BNPApplicationException;
	
	void createCreditNoteUtilization(EippCNUtilizationVO cntUtilVO) throws BNPApplicationException;

}
