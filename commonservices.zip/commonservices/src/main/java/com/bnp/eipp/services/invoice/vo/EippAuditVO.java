/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 17, 201211:35:09 AM
 * 
 * Purpose:      EippAuditVO.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 17, 201211:35:09 AM        Oracle Financial Services Software Ltd                  Initial Version  
 * 19 Nov 2012						Gangadharan R										  Adhoc Fix - Adding remarks in invoice and payment audits
************************************************************************************************************************************************************/
package com.bnp.eipp.services.invoice.vo;

import java.util.Date;

/**
 * The Class EippAuditVO.
 *
 * @author SandhyaRad
 */
public class EippAuditVO {
	
	private long pkId;
	
	private long invId;
	
	private long lineItemId;
	
	private String orgId;
	
	private String orgName;
	
	private String orgRole;
	
	private String auditUser;
	
	private String dept;
	
	private String action;
	
	private Date auditDate;
	
	private String status;
	
	private String disputeStatus;
	
	private long deptPKId;

	private String remarks;
	
	/**
	 * Gets the inv id.
	 *
	 * @return the inv id
	 */
	public long getInvId() {
		return invId;
	}

	/**
	 * Sets the inv id.
	 *
	 * @param invId the new inv id
	 */
	public void setInvId(long invId) {
		this.invId = invId;
	}

	/**
	 * Gets the line item id.
	 *
	 * @return the line item id
	 */
	public long getLineItemId() {
		return lineItemId;
	}

	/**
	 * Sets the line item id.
	 *
	 * @param lineItemId the new line item id
	 */
	public void setLineItemId(long lineItemId) {
		this.lineItemId = lineItemId;
	}

	/**
	 * Gets the org id.
	 *
	 * @return the org id
	 */
	public String getOrgId() {
		return orgId;
	}

	/**
	 * Sets the org id.
	 *
	 * @param orgId the new org id
	 */
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	/**
	 * Gets the org name.
	 *
	 * @return the org name
	 */
	public String getOrgName() {
		return orgName;
	}

	/**
	 * Sets the org name.
	 *
	 * @param orgName the new org name
	 */
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	/**
	 * Gets the org role.
	 *
	 * @return the org role
	 */
	public String getOrgRole() {
		return orgRole;
	}

	/**
	 * Sets the org role.
	 *
	 * @param orgRole the new org role
	 */
	public void setOrgRole(String orgRole) {
		this.orgRole = orgRole;
	}

	/**
	 * Gets the audit user.
	 *
	 * @return the audit user
	 */
	public String getAuditUser() {
		return auditUser;
	}

	/**
	 * Sets the audit user.
	 *
	 * @param auditUser the new audit user
	 */
	public void setAuditUser(String auditUser) {
		this.auditUser = auditUser;
	}

	/**
	 * Gets the dept.
	 *
	 * @return the dept
	 */
	public String getDept() {
		return dept;
	}

	/**
	 * Sets the dept.
	 *
	 * @param dept the new dept
	 */
	public void setDept(String dept) {
		this.dept = dept;
	}

	/**
	 * Gets the action.
	 *
	 * @return the action
	 */
	public String getAction() {
		return action;
	}

	/**
	 * Sets the action.
	 *
	 * @param action the new action
	 */
	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * Gets the audit date.
	 *
	 * @return the audit date
	 */
	public Date getAuditDate() {
		return auditDate;
	}

	/**
	 * Sets the audit date.
	 *
	 * @param auditDate the new audit date
	 */
	public void setAuditDate(Date auditDate) {
		this.auditDate = auditDate;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the dispute status.
	 *
	 * @return the dispute status
	 */
	public String getDisputeStatus() {
		return disputeStatus;
	}

	/**
	 * Sets the dispute status.
	 *
	 * @param disputeStatus the new dispute status
	 */
	public void setDisputeStatus(String disputeStatus) {
		this.disputeStatus = disputeStatus;
	}

	/**
	 * @return the pkId
	 */
	public long getPkId() {
		return pkId;
	}

	/**
	 * @param pkId the pkId to set
	 */
	public void setPkId(long pkId) {
		this.pkId = pkId;
	}

	/**
	 * @return the deptPKId
	 */
	public long getDeptPKId() {
		return deptPKId;
	}

	/**
	 * @param deptPKId the deptPKId to set
	 */
	public void setDeptPKId(long deptPKId) {
		this.deptPKId = deptPKId;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
}
