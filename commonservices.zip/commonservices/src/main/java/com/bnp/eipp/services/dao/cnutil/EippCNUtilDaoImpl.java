/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 6, 20127:09:37 PM
 * 
 * Purpose:      EippCNUtilDaoImpl.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 6, 20127:09:37 PM        Oracle Financial Services Software Ltd                  Initial Version  
************************************************************************************************************************************************************/

package com.bnp.eipp.services.dao.cnutil;

import java.util.List;

import org.springframework.stereotype.Component;

import com.bnp.eipp.services.invoice.vo.EippCreditNoteVO;
import com.bnp.eipp.services.vo.cnutil.EippCNUtilizationVO;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@Component
@SuppressWarnings ("unchecked")
public class EippCNUtilDaoImpl extends SqlMapClientWrapper 
					implements IEippCNUtilDao {
	
	private static final String GET_LINKED_CREDIT_NOTES = "getLinkedCreditNotes";
	
	private static final String INSERT_EIPP_CN_UTIL = "insertEippCNUtilization";
	
	public EippCNUtilDaoImpl() {
		nameSpace = "EippCNUtilNS";
	}

	@Override
	public List<EippCreditNoteVO> getLinkedCreditNotes(long fileId)
			throws BNPApplicationException {
		return (List<EippCreditNoteVO>) getSqlMapClientTemplate().queryForList(
				getQueryNameWithNameSpace(GET_LINKED_CREDIT_NOTES), 
				fileId);
	}

	@Override
	public void createCreditNoteUtilization(EippCNUtilizationVO cntUtilVO)
			throws BNPApplicationException {
		getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_EIPP_CN_UTIL), cntUtilVO);
	}

}
