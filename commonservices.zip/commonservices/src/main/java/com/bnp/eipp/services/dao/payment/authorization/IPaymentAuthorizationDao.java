/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Aug 8, 20122:50:13 PM
 * 
 * Purpose:      IPaymentAuthorizationDao
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Aug 8, 20122:50:13 PM        Oracle Financial Services Software Ltd                  Initial Version
 * Oct 23 , 2012                 Raja S													Change Done for ST Defect 7008  
************************************************************************************************************************************************************/

package com.bnp.eipp.services.dao.payment.authorization;

import java.util.Date;

import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.vo.payment.EippPymtVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

/**
 * The Interface IPaymentAuthorizationDao.
 */
public interface IPaymentAuthorizationDao {

	/**
	 * Check dual ctl mandatory.
	 *
	 * @param orgId the org id
	 * @return true, if successful
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean checkDualCtlMandatory(String orgId) throws BNPApplicationException;
	
	/**
	 * Check pymt auth rule available.
	 *
	 * @param pymtVO the pymt vo
	 * @param invoiceVO the invoice vo
	 * @return the eipp pymt vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	EippPymtVO checkPymtAuthRuleAvailable(EippPymtVO pymtVO,EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
	/**
	 * Update pymt status.
	 *
	 * @param pymtVO the pymt vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void updatePymtStatus(EippPymtVO pymtVO) throws BNPApplicationException;
	
	/**
	 * Gets the before due date with lead days.
	 *
	 * @param currencyCode the currency code
	 * @param buyerOrgId the buyer org id
	 * @param invDueDate the inv due date
	 * @param days the days
	 * @return the before due date with lead days
	 * @throws BNPApplicationException the bNP application exception
	 */
	Date getBeforeDueDateWithLeadDays(String currencyCode ,String buyerOrgId, Date invDueDate , int days,String orgId ) throws BNPApplicationException;

	
}
