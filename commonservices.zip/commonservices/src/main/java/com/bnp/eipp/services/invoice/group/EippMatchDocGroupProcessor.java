package com.bnp.eipp.services.invoice.group;
/** ************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   
 * 
 * Purpose:      EippMatchDocGroupProcessor.java
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 12 Oct 2012						Merdith 														  		Method Parameter changed for validating line item
 ***************************************************************************************************************************************************/

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.invoice.vo.AddressVO;
import com.bnp.eipp.services.invoice.vo.ConsgnmtVO;
import com.bnp.eipp.services.invoice.vo.EippCustFieldsVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceBusinessRulesVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.invoice.vo.TaxDtlsVO;
import com.bnp.eipp.services.invoice.vo.TransportMeansVO;
import com.bnp.eipp.services.matching.document.bindingvo.AdditionalInformation6;
import com.bnp.eipp.services.matching.document.bindingvo.Consignment2;
import com.bnp.eipp.services.matching.document.bindingvo.FinancialInvoiceV01;
import com.bnp.eipp.services.matching.document.bindingvo.LineItem10;
import com.bnp.eipp.services.matching.document.bindingvo.PostalAddress6;
import com.bnp.eipp.services.matching.document.bindingvo.SettlementTax1;
import com.bnp.eipp.services.matching.document.bindingvo.TradeDelivery1;
import com.bnp.eipp.services.matching.document.bindingvo.TransportMeans3;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.StatusConstants;

@Component
@Scope ("prototype")
public class EippMatchDocGroupProcessor<T> extends EippGroupProcessor<EippInvoiceVO> {

	 @Autowired 
	 private BNPPropertyLoaderConfigurer propertyLoader;
	
	private List<FinancialInvoiceV01> objectList;
	
	
	public EippMatchDocGroupProcessor () {
		super();	
	}


	/**
	 * @return the objectList
	 */
	public List<FinancialInvoiceV01> getObjectList() {
		return objectList;
	}


	/**
	 * @param objectList the objectList to set
	 */
	public void setObjectList(List<FinancialInvoiceV01> objectList) {
		this.objectList = objectList;
	}
	
	private void populateMatchingMapFiles() {
		mappingFiles = new ArrayList<String>();
		//mappingFiles.add("mapper/MatchingCntMapper.xml");
		mappingFiles.add("mapper/MatchingDocMapper.xml");
		mappingFiles.add("mapper/MatchingLineItemMapper.xml");
		mappingFiles.add("mapper/MatchingCustFieldMapper.xml");
		mappingFiles.add("mapper/MatchingAddrMapper.xml"); 
		mappingFiles.add("mapper/MatchingTaxMapper.xml");
		beanMapper = new DozerBeanMapper(mappingFiles);
	}
	
	
	@Override
	public void processAndValidateData() throws BNPApplicationException {
		populateMatchingMapFiles();
		List<EippInvoiceVO> invList = new ArrayList<EippInvoiceVO>();
		if(objectList !=null)
		{
			for (FinancialInvoiceV01 invoiceObj : objectList) {
				EippInvoiceVO eippInvoiceVO = beanMapper.map(
						invoiceObj, EippInvoiceVO.class);
				if(invoiceObj.getTradDlvry() != null){
				List<Consignment2> consignmtLst = (List<Consignment2>) invoiceObj.getTradDlvry().getConsgnmt();
					for(Consignment2 consignmtObj : consignmtLst){
						ConsgnmtVO consgnMtVO = new ConsgnmtVO();
						List<TransportMeans3> tranptMnsLst = (List<TransportMeans3>) consignmtObj.getTrnsprtMeans();
						for(TransportMeans3 transpObj : tranptMnsLst){
							TransportMeansVO transportVO = new TransportMeansVO();
							transportVO.setShipMode(transpObj.getId());
						}
						eippInvoiceVO.getConsgnmtDtls().add(consgnMtVO);
					}
				}
				
				if(invoiceObj.getInvcHdr().getModInvc() != null){
					String modInv = invoiceObj.getInvcHdr().getModInvc().value();
					eippInvoiceVO.setModifiedInvoice((BNPConstants.MOD_INV_YES.equals(modInv)) ? true: false);
				}
				
				eippInvoiceVO.setPymtTerms(populatePaymentTerms(invoiceObj.getTradSttlm().getPmtTerms().getDesc()));
				
	//			if(eippInvoiceVO.getAttachmentCount() > 0 ){
	//				for (AttachmentData attachmentData : invoiceObj.getAttchmntDet().getAttachmentData()){
	//					AttachmentVO attachmentVO = beanMapper.map(
	//							attachmentData, AttachmentVO.class);
	//					attachmentVO.setFileId(detailsVO.getFileId());
	//					eippInvoiceVO.getAttachmentList().add(attachmentVO);
	//				}
	//			}
				if (invoiceObj.getTradDlvry() != null) {
					populateAddressDetails(invoiceObj.getTradDlvry(), eippInvoiceVO);
				}
				List<SettlementTax1> taxLst = (List<SettlementTax1>) invoiceObj.getTradSttlm().getTax();
				for(SettlementTax1 stlmtTaxObj : taxLst){
					TaxDtlsVO taxDtlsVO = beanMapper.map(stlmtTaxObj, TaxDtlsVO.class);
					eippInvoiceVO.getTaxDtls().add(taxDtlsVO);
				}
				
				for (AdditionalInformation6 customField : invoiceObj.getInvcHdr().getInclNote()) {
					EippCustFieldsVO custFieldVO = beanMapper.map(
							customField, EippCustFieldsVO.class);
					eippInvoiceVO.getCustFields().add(custFieldVO);
				}
				for (LineItem10 lineItem : invoiceObj.getLineItm()) {
					EippInvCntLineItemVO eippInvCntLineItemVO = beanMapper.map(
											lineItem, EippInvCntLineItemVO.class);
	//				for (AdditionalInformation1 customLtmField : lineItem.getInclNote()) {
	//					EippCustFieldsVO custItmFieldVO = beanMapper.map(
	//							customLtmField, EippCustFieldsVO.class);
	//					eippInvCntLineItemVO.getCustFields().add(custItmFieldVO);
	//				}
					eippInvoiceVO.getLineItemList().add(eippInvCntLineItemVO);
				}
				eippInvoiceVO.setMatchStatus(StatusConstants.PENDING_MATCH_STATUS);
				eippInvoiceVO.setIsManual("N");
				invList.add(eippInvoiceVO);
			}
	}
		validateInvoices(invList);
		
	}
	private String populatePaymentTerms(List<String> descList) {
		StringBuilder builder = new StringBuilder();
		
		for (String desc : descList) {
			builder.append(desc);
		}
		
		return builder.toString();
	}
	
	private void populateAddressDetails(TradeDelivery1 tradeDelivery,EippInvoiceVO eippInvoiceVO) {
		if (tradeDelivery.getBillTo() != null && tradeDelivery.getBillTo().getPstlAdr() != null) {
			eippInvoiceVO.setBillToAddr(getAddress(tradeDelivery.getBillTo().getPstlAdr()));
		}
		if (tradeDelivery.getShipTo() != null && tradeDelivery.getShipTo().getPstlAdr() != null) {
			eippInvoiceVO.setShipToAddr(getAddress(tradeDelivery.getShipTo().getPstlAdr()));
		}
		if (tradeDelivery.getRemitTo() != null && tradeDelivery.getRemitTo().getPstlAdr() != null) {
			eippInvoiceVO.setRemitToAddr(getAddress(tradeDelivery.getRemitTo().getPstlAdr()));
		}
	}
	
	/**
	 * Validate invoices.
	 *
	 * @param invList the inv list
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void validateInvoices(List<EippInvoiceVO> invList) throws BNPApplicationException {
		
		List<EippInvoiceVO> transList = new ArrayList<EippInvoiceVO>();
		
		Map<String, Integer> decimalMap = new HashMap<String, Integer>();
		for (EippInvoiceVO eippInvoiceVO : invList) {
			boolean isInvalid = false;
			
			if (eippInvoiceVO.getRefDate() == null) {
				eippInvoiceVO.setRefDate(eippInvoiceVO.getIssueDate());
			}
			
			isInvalid = validateOrgData(eippInvoiceVO);
			
			if (isInvalid) {
				validInvalidList.add(eippInvoiceVO);
				continue;
			}
			
			if(detailsVO.getSenderOrgType().equals(BNPConstants.MARKET_PLACE)){
				isInvalid = checkAllRecordHasSameCustomer(invList,eippInvoiceVO) || isInvalid ;
			}
			
			if(detailsVO.getFileFrmtType().equalsIgnoreCase(propertyLoader.getValue("message.type.matching.eipp.invoice"))){
				if(eippInvoiceVO.isModifiedInvoice()) {
					isInvalid = validateInvoiceAvailablity(eippInvoiceVO) || isInvalid;
				}
			}
			
			isInvalid = validateLineItemsData(eippInvoiceVO,null) || isInvalid; // Added parameter for validating line item amounts
			
			isInvalid = validateDepartments(eippInvoiceVO) || isInvalid;
			
			isInvalid = validateSupplierAccountIdentifier(eippInvoiceVO) || isInvalid;
			
			if(detailsVO.getFileFrmtType().equalsIgnoreCase(propertyLoader.getValue("message.type.matching.eipp.invoice"))){
				if (isSourceDateLesser(eippInvoiceVO.getInvDueDate(), eippInvoiceVO.getIssueDate())) {
					
					addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
							ErrorConstants.ISSUE_DATE_SHOULD_LESSTHAN_DUEDATE, eippInvoiceVO);
					isInvalid = true;
				}
				
				if (isIssueDateFutureDate(eippInvoiceVO.getIssueDate(), detailsVO.getTimeZoneTZ())) {
					
					addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
							ErrorConstants.ISSUE_DATE_SHOULD_NOT_FUTURE, eippInvoiceVO);
					isInvalid = true;
				}
				
				if (eippInvoiceVO.getDiscRuleId() != null && !isDiscountRuleIdValid(eippInvoiceVO)) {
					
					addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
							ErrorConstants.DISCOUNT_RULE_ID_NOT_LINKED_TO_REBATE, eippInvoiceVO);
					isInvalid = true;
				}
				
				isInvalid = validateInvoiceAmounts(eippInvoiceVO) || isInvalid;
				isInvalid =  validateUniqueReference(eippInvoiceVO, transList) || isInvalid;
			
			}
			if (!isInvalid) {
				int fractionalDigits = 0;
				String ccyCode = eippInvoiceVO.getCcyCode();
				
				// caching the data
				if (decimalMap.containsKey(ccyCode)) {
					fractionalDigits = decimalMap.get(eippInvoiceVO.getCcyCode());
				} else {
					fractionalDigits = invoiceUploadService.getCurrencyDecimals
															(eippInvoiceVO.getCcyCode());
					decimalMap.put(ccyCode, fractionalDigits);
				}
				eippInvoiceVO.setFractionalDigits(fractionalDigits);
				eippInvoiceVO.setBusinessRulesVO(getBusinessProcessingRules(eippInvoiceVO));
				
				if(detailsVO.getFileFrmtType().equalsIgnoreCase(propertyLoader.getValue("message.type.matching.eipp.invoice"))){
					if(eippInvoiceVO.isModifiedInvoice()){
						EippInvoiceVO invoice = getInvoiceForProcessing(eippInvoiceVO);
						
						int statusCode = checkForValidInvoice(invoice);
						
						if (statusCode == 0) {
							eippInvoiceVO.setOriginalInvId(invoice.getInvId());
							eippInvoiceVO.setRecordStatus("A");
							dataList.add(eippInvoiceVO);
						} else {
							isInvalid = true;
							addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
									statusCode, eippInvoiceVO);
						}
					} else {
						eippInvoiceVO.setRecordStatus("A");
						dataList.add(eippInvoiceVO);
					}
				}else{
					eippInvoiceVO.setRecordStatus("A");
					dataList.add(eippInvoiceVO);
				}
				validInvalidList.add(eippInvoiceVO);
			} else {
				validInvalidList.add(eippInvoiceVO);
			}
			
		}
	}
	
	private int checkForValidInvoice(EippInvoiceVO invoiceVO) {
		if (invoiceVO == null) {
			return ErrorConstants.INV_DETS_UNAVAILABLE_FOR_MODIFICATION;
		} else if (invoiceVO.getInvStatus().equals(StatusConstants.INVOICE_CANCELLED) ||
				 invoiceVO.getInvStatus().equals(StatusConstants.CANCEL_PENDING_EIPP_APPROVAL) ||
				 invoiceVO.getInvStatus().equals(StatusConstants.EIPP_INV_STATUS_CLOSED)) {
			return ErrorConstants.INVOICE_NOT_AVAILABLE_ALREADY_CLOSED_CANCELLED;
		} else if (BigDecimal.ZERO.compareTo(invoiceVO.getBlockedAmt()) < 0 || 
				   BigDecimal.ZERO.compareTo(invoiceVO.getPaidAmt()) < 0) {
			return ErrorConstants.INVOICE_NOT_AVAILABLE_PAYMENT_CREATED;
		} else if (invoiceVO.getUtilizedCNCount() > 0) {
			return ErrorConstants.INVOICE_NOT_AVAILABLE_CREDITNOTE_UTILIZED;
		}
		return 0;
	}
	
	private boolean validateUniqueReference(EippInvoiceVO eippInvoiceVO,List<EippInvoiceVO> transList)
	throws BNPApplicationException {
		boolean isInvalid = false;
		if (!eippInvoiceVO.isModifiedInvoice() && eippInvcUploadDAO.isUniqueCheckEnabled(getCustomerOrgId(eippInvoiceVO), 
				getCntpOrgId(eippInvoiceVO), eippInvoiceVO.getBillType())) {
			isInvalid = eippInvcUploadDAO.isInvoiceExists(eippInvoiceVO) ||
						checkUniqueReference(eippInvoiceVO, transList);
			if (isInvalid) {
				addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
						ErrorConstants.INVOICE_NOT_UNIQUE, eippInvoiceVO);
			} else {
				transList.add(eippInvoiceVO);
			}
		}
		return isInvalid;
	}
	
	private boolean checkUniqueReference(EippInvoiceVO eippInvoiceVO,List<EippInvoiceVO> transList) {
		boolean isInvalid = false;
		for (EippInvoiceVO transactionVO : transList) {
			if (eippInvoiceVO.getInvRefNo().equals(transactionVO.getInvRefNo()) &&
				isSameDates(eippInvoiceVO.getRefDate(), transactionVO.getRefDate()) &&
				eippInvoiceVO.getSupplierOrgId().equals(transactionVO.getSupplierOrgId())) {
				isInvalid = true;
				break;
			}
		}
		
		return isInvalid;
	}
	private boolean validateDepartments(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException {
		boolean isInvalid = false;
		
		if (!isNull(eippInvoiceVO.getInquiryDept()) && !eippInvcUploadDAO.isDepartmentAvailable(eippInvoiceVO.getBuyerOrgId(),
				eippInvoiceVO.getInquiryDept())) {
			addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
					ErrorConstants.INVALID_INQUIRY_DEPARTMENT, eippInvoiceVO);
			isInvalid = true;
		}
		
		if (!isNull(eippInvoiceVO.getDisputeDept()) && !eippInvcUploadDAO.isDepartmentAvailable(eippInvoiceVO.getSupplierOrgId(),
				eippInvoiceVO.getDisputeDept())) {
			addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
					ErrorConstants.INVALID_DISPUTE_DEPARTMENT, eippInvoiceVO);
			isInvalid = true;
		}
		return isInvalid;
	}
	private boolean validateInvoiceAmounts(EippInvoiceVO eippInvoiceVO) 
	throws BNPApplicationException {
		boolean isInvalid = false;
		
		if (eippInvoiceVO.getTotAmtPayable() !=null && eippInvoiceVO.getTotAmtPayable().compareTo
				(eippInvoiceVO.getGrossAmt().subtract(getBigDecimalValue(eippInvoiceVO.getTotDiscAmt()))) != 0) {
			addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
					ErrorConstants.EIPP_INVC_AMTS_MISMATCH, eippInvoiceVO);
			isInvalid = true;
		} else if(eippInvoiceVO.getTotAmtPayable() ==null) {
			eippInvoiceVO.setTotAmtPayable(
					eippInvoiceVO.getGrossAmt().subtract(getBigDecimalValue(eippInvoiceVO.getTotDiscAmt())));
			eippInvoiceVO.setTotAmtPayCcy(eippInvoiceVO.getCcyCode());
		}
		
		if (eippInvoiceVO.getNetAmt() != null && eippInvoiceVO.getTaxAmount() != null && (eippInvoiceVO.getNetAmt().compareTo
				(eippInvoiceVO.getGrossAmt().subtract(eippInvoiceVO.getTaxAmount())) != 0 ||
				eippInvoiceVO.getNetAmt().compareTo(eippInvoiceVO.getGrossAmt()) > 0)) {
			addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
					ErrorConstants.EIPP_INV_NET_AMT_MISMATCH, eippInvoiceVO);
			isInvalid = true;
		}else if(eippInvoiceVO.getNetAmt() == null && eippInvoiceVO.getTaxAmount() == null) {
			eippInvoiceVO.setNetAmt(eippInvoiceVO.getGrossAmt());
			eippInvoiceVO.setNetAmtCcy(eippInvoiceVO.getCcyCode());
		}else if(eippInvoiceVO.getTaxAmount() != null && eippInvoiceVO.getNetAmt() == null) {
			eippInvoiceVO.setNetAmt(eippInvoiceVO.getGrossAmt().subtract(eippInvoiceVO.getTaxAmount()));
			eippInvoiceVO.setNetAmtCcy(eippInvoiceVO.getCcyCode());
		}else if(eippInvoiceVO.getNetAmt() != null && eippInvoiceVO.getTaxAmount() == null &&
				eippInvoiceVO.getNetAmt().compareTo(eippInvoiceVO.getGrossAmt()) <=0) {
			eippInvoiceVO.setTaxAmount(eippInvoiceVO.getGrossAmt().subtract(eippInvoiceVO.getNetAmt()));
			eippInvoiceVO.setTaxAmtCcy(eippInvoiceVO.getCcyCode());
		}
		if ((eippInvoiceVO.getTotAmtPayCcy() !=null && !eippInvoiceVO.getCcyCode().equals(eippInvoiceVO.getTotAmtPayCcy())) || 
				(eippInvoiceVO.getTotDiscAmtCcy() != null && !eippInvoiceVO.getCcyCode().equals(eippInvoiceVO.getTotDiscAmtCcy()))) {
			addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
					ErrorConstants.EIPP_INVC_CCY_MISMATCH, eippInvoiceVO);
			isInvalid = true;
		}
		
		if ((eippInvoiceVO.getNetAmtCcy() !=null && !eippInvoiceVO.getCcyCode().equals(eippInvoiceVO.getNetAmtCcy())) || 
				(eippInvoiceVO.getTaxAmtCcy() != null && !eippInvoiceVO.getCcyCode().equals(eippInvoiceVO.getTaxAmtCcy()))) {
			addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
					ErrorConstants.EIPP_INV_NET_AMT_CCY_MISMATCH, eippInvoiceVO);
			isInvalid = true;
		}
		eippInvoiceVO.setInvRemAmt(eippInvoiceVO.getTotAmtPayable());
		return isInvalid;
	}
	private boolean validateSupplierAccountIdentifier(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException {
		boolean isInvalid = false;
		boolean acctIdRequired = eippInvcUploadDAO.isAccountIdentifierRequired(getCustomerOrgId(eippInvoiceVO), 
				getCntpOrgId(eippInvoiceVO), eippInvoiceVO.getBillType());
		if (acctIdRequired && isNull(eippInvoiceVO.getSupplierAcctNo())) {
			addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
					ErrorConstants.SUPPLIER_ACCT_IDNT_MANDATORY, eippInvoiceVO);
			isInvalid = true;
		} else if(acctIdRequired && !eippInvcUploadDAO.isAccountIdentifierExists(eippInvoiceVO.getSupplierOrgId(),
				eippInvoiceVO.getSupplierAcctNo())) {
			addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
					ErrorConstants.SUPPLIER_ACCT_IDNT_INVALID, eippInvoiceVO);
			isInvalid = true;
		}
		return isInvalid;
	}
	
	/**
	 * This method checks the discount rule is linked with rule type - Early payment rebate   
	 * @param discRuleId
	 * @return
	 * @throws BNPApplicationException 
	 */
	private boolean isDiscountRuleIdValid(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException {
		String ruleType = eippInvcUploadService.getRuleTypeForDiscountRuleId(eippInvoiceVO);
		if (ruleType != null && ruleType.equals("R")) {
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * Validates whether Invoice already exists in the system
	 * @param eippInvoiceCancelVO
	 * @throws BNPApplicationException 
	 */
	private boolean validateInvoiceAvailablity(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException {
		boolean isInvalid = false;
		int invoiceCount = eippInvcUploadService.isInvoiceAvailableInSystem(eippInvoiceVO);
		if(invoiceCount == 0 ){
			isInvalid = true;
			addToErrorDataList(eippInvoiceVO.getTransactionType(), eippInvoiceVO.toDataString(), 
					ErrorConstants.INVOICE_NOT_AVAILABLE_IN_SYSTEM, eippInvoiceVO);
		}
		return isInvalid;
	}
	
	/**
	 * Gets the Invoice ID for file processing  
	 * @param eippInvoiceVO
	 * @return
	 * @throws BNPApplicationException 
	 */
	private EippInvoiceVO getInvoiceForProcessing(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException {
		List<EippInvoiceVO> invoiceList = (List<EippInvoiceVO>) eippInvcUploadService.getInvoiceListForValidation(eippInvoiceVO);
		return eippInvcUploadService.getInvoiceForProcessing(invoiceList);
	}
	
	/**
	 * @param eippInvoiceVO
	 * @return
	 * @throws BNPApplicationException 
	 */
	private EippInvoiceBusinessRulesVO getBusinessProcessingRules(
			EippInvoiceVO eippInvoiceVO) throws BNPApplicationException {

		EippInvoiceBusinessRulesVO businessRulesVO = new EippInvoiceBusinessRulesVO();
		if (detailsVO.getModelType().equals(BNPConstants.MODEL_TYPE_SCM)) {
			businessRulesVO = eippInvcUploadService.getBusinessProcessingRules(eippInvoiceVO.getSupplierOrgId(), 
					eippInvoiceVO.getBuyerOrgId(), eippInvoiceVO.getBillType());
		} else if (detailsVO.getModelType().equals(BNPConstants.MODEL_TYPE_BCM)){
			businessRulesVO = eippInvcUploadService.getBusinessProcessingRules(eippInvoiceVO.getBuyerOrgId(), 
					eippInvoiceVO.getSupplierOrgId(), eippInvoiceVO.getBillType());
		}
		return businessRulesVO;
	}
	
	private AddressVO getAddress(PostalAddress6 postalAddress) {
		AddressVO addressVO = beanMapper.map(postalAddress, AddressVO.class);
		if (postalAddress.getAdrTp() != null) {
			addressVO.setAddrType(postalAddress.getAdrTp().value());
		}
		if (postalAddress.getAdrLine() != null && !postalAddress.getAdrLine().isEmpty()) {
			populateAddrLines(postalAddress.getAdrLine(), addressVO);
		}
		return addressVO;
	}
	
	private void populateAddrLines(List<String> addrLines,AddressVO addressVO) {
		if (addrLines.size() > 0 && !isNull(addrLines.get(0))) {
			addressVO.setAddress1(addrLines.get(0));
		}
		if (addrLines.size() > 1 && !isNull(addrLines.get(1))) {
			addressVO.setAddress2(addrLines.get(1));
		}
		if (addrLines.size() > 2 && !isNull(addrLines.get(2))) {
			addressVO.setAddress3(addrLines.get(2));
		}
	}


}
