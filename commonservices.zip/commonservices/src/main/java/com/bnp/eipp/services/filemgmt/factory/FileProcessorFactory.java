/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   18 July 2012
 * 
 * Purpose:      FileProcessorFactory
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 July 2012        Oracle Financial Services Software Ltd                  Initial Version  
 * 17 Oct 2012		   Prabakaran S							   				   Fix for ST Defect # 6793
************************************************************************************************************************************************************/

package com.bnp.eipp.services.filemgmt.factory;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.filemgmt.EippAbstractFileService;
import com.bnp.scm.services.common.BNPConstants;

@Component ("fileProcessorFactory")
public class FileProcessorFactory {

	@Autowired
	private BeanFactory beanFactory;

	public EippAbstractFileService getFileService(String fileType) {

		EippAbstractFileService fileService = null; 

		if (fileType.equalsIgnoreCase(BNPConstants.STANDARD_FILE_TYPE)) {
			fileService = getBean("eippStandardFileService");
		} else {
			fileService = getBean("eippCustomFileService");
		}
		return fileService;
	}
	
	private EippAbstractFileService getBean(String instanceName) {
		return beanFactory.getBean(instanceName, EippAbstractFileService.class);
	}

}
