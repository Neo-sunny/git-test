/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   02 Feb 2012
 * 
 * Purpose:      EIPP Invoice and credit note Upload Screen 
 * 
 * Change History: 
 * Date                                                  Author               Version                                    Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 02 Feb 2012                      Oracle Financial Services Software Ltd                                    Initial Version
 * 27 Apr 2012    				    Oracle Financial Services Software Ltd                                    QC # 131 - FO - MFU - Unique file check
 * 17 July 2012    				    Oracle Financial Services Software Ltd                                    MFU - Cancel Invoice
 * 20 Aug 2012					    Vignesh B																  Attachment Processing
 *  14 Sep 2012						Prabakaran S															  Modified for EIPP Inv Attachments 
 * 17 Oct 2012						Prabakaran S															Fix for ST Defect # 6793 ******************************************************************************************************************************************************************/


package com.bnp.eipp.services.filemgmt;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.common.services.filemgmt.factory.AbstractFileProcessorFactory;
import com.bnp.eipp.services.filemgmt.factory.FileProcessorFactory;
import com.bnp.eipp.services.filemgmt.processor.IEippZipFileProcessor;
import com.bnp.eipp.services.filemgmt.util.InstrumentTypeEnum;
import com.bnp.eipp.services.invoice.IEippInvcUploadService;
import com.bnp.eipp.services.invoice.vo.EippInvCntVO;
import com.bnp.scm.services.admin.dao.IorganizationDAO;
import com.bnp.scm.services.common.ApplicationBeanContextFactory;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.ILocaleMessageLoaderService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.util.CacheConstants;
import com.bnp.scm.services.filemgmt.upload.util.IFileUploadThreadManager;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.filemgmt.vo.FileUploadVO;
import com.bnp.scm.services.filemgmt.vo.FileVO;
import com.bnp.scm.services.interfaces.common.ICommonAccessService;
import com.bnp.scm.services.interfaces.common.vo.ConfVO;
import com.bnp.scm.services.invoice.IInvoiceUploadService;
import com.bnp.scm.services.txns.common.message.AbstractMessage;

@Component
public class EippFileMgmtServiceImpl implements IEippFileMgmtService {

	private static final Logger LOGGER = LoggerFactory.getLogger(EippFileMgmtServiceImpl.class);
	
	@Autowired
	private  IInvoiceUploadService invoiceUploadService;
	
	@Autowired
	private BNPPropertyLoaderConfigurer propertyLoader;
	
	@Autowired
	private IEippInvcUploadService eippInvcUploadSerice;
	
	@Autowired
	protected IFileProcessService fileProcessorService;
	
	@Autowired
	protected ILocaleMessageLoaderService msgService;
	
	@Autowired
	protected IorganizationDAO orgService;
	
	@Autowired
	private ICommonAccessService commonAccessService;
	
	@Autowired
	private IEippZipFileProcessor zipFileService;
	
	@Autowired
	private AbstractFileProcessorFactory fileFactory;
	
	/**
	 * @Name : uploadDataFile
	 * @Description : This method is used to parse & upload the data file
	 * @param dataFile
	 * @throws BNPApplicationException
	 * @see com.bnp.eipp.services.filemgmt.IEippFileMgmtService#uploadDataFile(com.bnp.scm.services.filemgmt.vo.FileUploadVO)
	 */
	@Override
	public long uploadDataFile(FileUploadVO uploadVO)
			throws BNPApplicationException {
			long fileId;
			if (BNPConstants.ZIP_FILE_TYPE.equals(uploadVO.getFileType())) {
				fileId = zipFileService.processFile(uploadVO);
			} else {
				FileProcessorFactory processorFactory = fileFactory.getEippFileProcessorFactory();
				EippAbstractFileService fileProcessor = processorFactory.getFileService(
						uploadVO.getFileType());
				FileDetailsVO detailsVO = createFileDetails(uploadVO);
				fileId = fileProcessor.processData(detailsVO);
			}
			return fileId;
	}
	
	public void processFile(AbstractMessage<?> invoiceMessage, 
			FileDetailsVO detailsVO, FileUploadVO uploadVO) throws BNPApplicationException {
			
		boolean isThreadProcessingEnabled = Boolean.valueOf(propertyLoader
				.getValue("filemgmt.enable.thread.processing"));
				
		if (!isThreadProcessingEnabled) {
			processAndReleaseFile(detailsVO, invoiceMessage, uploadVO);
		} else {
			try {
				IFileUploadThreadManager threadManager = (IFileUploadThreadManager)ApplicationBeanContextFactory.getBean("threadManager");
				threadManager.executeEippFile(detailsVO, invoiceMessage, uploadVO, invoiceUploadService, eippInvcUploadSerice, propertyLoader);
			} catch (Exception e) {
				LOGGER.error("Exception while processing file" + e);
				processAndReleaseFile(detailsVO, invoiceMessage, uploadVO);
			}
		}
	}
	
	private void processAndReleaseFile(FileDetailsVO detailsVO, 
			AbstractMessage<?> invoiceMessage,
			FileUploadVO uploadVO) throws BNPApplicationException {

		Map<String, List<EippInvCntVO>> eippInvCntMap = eippInvcUploadSerice.process(
					detailsVO, invoiceMessage);
		eippInvcUploadSerice.release(detailsVO, invoiceMessage, eippInvCntMap);
	}
	
	@Override
	public ConfVO getQueueNameForOrg(ConfVO confVO)
			throws BNPApplicationException {
		return commonAccessService.getQueueNameForOrg(confVO);
	}
	
	private FileDetailsVO createFileDetails(FileUploadVO uploadVO) throws BNPApplicationException {
	
		FileVO dataFile = uploadVO.getFileVO();
		FileDetailsVO detailsVO = new FileDetailsVO();
		detailsVO.setFileFrmtType(uploadVO.getFileFormatType());	
		detailsVO.setFileName(dataFile.getFileName());
		detailsVO.setUploadDate(new Date(System.currentTimeMillis()));
		detailsVO.setFileProcessedDate(new Date(System.currentTimeMillis()));
		detailsVO.setUserId(dataFile.getUserId());
		detailsVO.setFileType(dataFile.getFileType());
		detailsVO.setSenderOrgId(uploadVO.getSenderOrgId());
		detailsVO.setFileData(dataFile.getData());
		detailsVO.setInstrumentType(InstrumentTypeEnum.getInstrumentType(uploadVO.getFileFormatType()));
		detailsVO.setFileUploadType(uploadVO.getFileType());
		detailsVO.setMsgId(fileProcessorService.getMessageId());
		detailsVO.setSource(CacheConstants.MFU);
		detailsVO.setAttachmentId(uploadVO.getAttachmentId()); 
		detailsVO.setUserType(uploadVO.getLoginUserTypeId());
		detailsVO.setFileTypeId(uploadVO.getFileTypeId()); // Added for R3.0 Manual File Upload for matching and reconcilation
		detailsVO.setDocType(uploadVO.getDocType());
		detailsVO.setBranchId(uploadVO.getSupportBranchId());
		return detailsVO;
	}
}
