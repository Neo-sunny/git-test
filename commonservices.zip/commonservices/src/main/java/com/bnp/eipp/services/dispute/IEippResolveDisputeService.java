/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  18 Aug 2012	       
 * 
 * Purpose:     Resolve Dispute Services Interface
 * 
 * Change History: 
 * Date                                      	 Author                              Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 Aug 2012	       							Dinesh D                 		 Initial Version  
 * 25 Oct 2012	       							Ravishankar V                 	 ST Defects 7042 and 7050  
 *****************************************************************************************************************************************************************/

package com.bnp.eipp.services.dispute;

import java.util.List;

import com.bnp.eipp.services.filemgmt.IEippFileReleaseService;
import com.bnp.eipp.services.vo.dispute.DisputeVO;
import com.bnp.scm.services.common.ITransactionService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;


public interface IEippResolveDisputeService extends ITransactionService,IEippFileReleaseService {
	
	int isResolveDisputeAllowed(DisputeVO disputeVO,String status) throws BNPApplicationException;

	int isValidResolutionCode(DisputeVO disputeVO)throws BNPApplicationException;

	void releaseFile(FileDetailsVO detailsVO, boolean autoAuthorization)throws BNPApplicationException;

	List<Integer> doBusinessValidation(DisputeVO disputeVO)throws BNPApplicationException;
}
