/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   20 Sep 2012
 * 
 * Purpose:      EippZipFileServiceImpl
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 20 Sep 2012        Oracle Financial Services Software Ltd                  Initial Version   
 * 17 Oct 2012						Prabakaran S 							  Fix for ST Defect # 6793
************************************************************************************************************************************************************/
package com.bnp.eipp.services.filemgmt.zip;

import org.springframework.stereotype.Component;

import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.TransactionServiceImpl;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;

/**
 * @author prabakarans
 *
 */
@Component
public class EippZipFileServiceImpl extends TransactionServiceImpl 
						implements IEippZipFileService {
	
	@Override
	public SqlMapClientWrapper getDao() {
		return (SqlMapClientWrapper) transactionDAO;
	}

	@Override
	public void saveAttachments(long fileId, String fileType, String userId)
			throws BNPApplicationException {
		
		if (fileType.equals(BNPConstants.FILE_TYPE_INVOICE)) {
			super.saveAttachments(fileId, FILE_TYPE.INVOICE, userId);
		}
	}

}
