/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  *06-March 2012 
 * 
 * Purpose:     Invoice Cancellation DAO Implementation
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * *06-March 2012                    Oracle Financial Services Software Ltd            Initial Version		Added for new screen invoice cancellation
 * *12-July 2012                     Oracle Financial Services Software Ltd            EIPP Phase II - Cancel Invoice MFU
 *****************************************************************************************************************************************************************/


package com.bnp.eipp.services.dao.invoice;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.common.vo.AttachmentVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceCancelVO;
import com.bnp.eipp.services.vo.invoice.InvoiceCancellationVO;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;

@Component 
public class EippInvoiceCancellationDAOImpl extends SqlMapClientWrapper implements IEippInvoiceCancellationDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(EippInvoiceCancellationDAOImpl.class);
	
	private static final String CANCEL_NAMESPACE="InvoiceCancelNS";
	private static final String INVC_SUMMARY_DETAILS="getInvoiceDetails";
	private static final String GET_LINE_ITEM_DETAILS="getLineItemDetails"; 
	private static final String GET_INV_CUSTOM_FIELDS="getInvcCustomFields";
	private static final String GET_INV_LINEITEM_CUSTOM_FIELDS="getInvcLICustomFields";
	private static final String GET_DETAILS_PAGE_DETAILS="getInvoiceDetailsFeilds";
	private static final String GET_AUDIT_REC_DETAILS="getAuditRecordFeilds"; 
	private static final String GET_AUDIT_LINEITEM_DETAILS="getAuditLineItemFeilds"; 
	private static final String CANCEL_RECORDS="cancelMasterRecords"; 
	private static final String CANCEL_AUDIT_RECORDS="cancelAuditRecords"; 
	private static final String APPROVE_RECORDS="approveRecords"; 
	private static final String APPROVE_AUDIT_RECORDS="approveAuditRecords"; 
	private static final String  GET_ATTACHMENT = "getAttachmentDetails";
	private static final String  DUAL_MANDAT_CHECK = "getMandatCheck";
	private static final String FETCH_BUYER_ORGID="getBuyerOrgId";
	private static final String FETCH_SUPPLIER_ORGID="getSupplierOrgId"; 
	private static final String GET_CANCEL_INVOICE_DTLS = "getCancelInvoiceDtls";
	private static final String GET_CANCEL_INVOICE_LIST = "getCancelInvoiceList";
	private static final String GET_CREDIT_NOTE_UTIL_STATUS = "getCreditNoteUtilStatus";
	private static final String IS_INVOICE_EXISTS_FOR_CANCEL = "isInvoiceExistsForCancel";
	private static final String UPDATE_ERROR_CODE="updateCancelInvoiceErrorCode";
	private static final String INSERT_CANCEL_INVOICE_INTO_MASTER = "insertCancelInvoiceIntoMaster";
	private static final String INSERT_CANCEL_INVOICE_INTO_HISTORY_FROM_MASTER = "insertCancelInvoiceIntoHistoryFromMaster";
	private static final String INSERT_CANCEL_INVOICE_INTO_HISTORY_FROM_TRANS = "insertCancelInvoiceIntoHistoryFromTrans";
	private static final String DELETE_CANCEL_INVOICE_FROM_TRANS = "deleteCancelInvoiceFromTrans";
	private static final String GET_INVOICE_COUNT_AVAILABLE_FOR_CANCEL="EippFileUpload.getAvailableInvoiceCount";
	private static final String UPDATE_RECORD_STATUS_IN_TRANS = "updateRecordStatusInTrans";
	private static final String GET_INVOICE_FOR_BUSINESS_VALIDATION = "getInvoiceForBusinessValidation";
	private static final String GET_MODIFY_INVOICE_LIST = "getModifyInvoiceList";
	private static final String UPDATE_MODIFY_INV_ERROR_CODE="updateModifyInvoiceErrorCode";
	private static final String GET_DELETED_CANCEL_INVOICE_DTLS = "getDeletedCancelInvoiceDtls";
	
	public EippInvoiceCancellationDAOImpl()
	{
		nameSpace=CANCEL_NAMESPACE;
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<InvoiceCancellationVO> getInvoiceDetails(InvoiceCancellationVO searchVO) throws BNPApplicationException {
		List<InvoiceCancellationVO> invoiceList=null;
		try {
			LOGGER.debug("Entered getInvoiceDetails");
			invoiceList=getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(INVC_SUMMARY_DETAILS),searchVO);
		} catch (DataAccessException ex) {
			LOGGER.error(" Exception in getInvoiceDetails" +ex.getMessage()); 
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		} 
		LOGGER.debug("Exit getInvoiceDetails");
		return invoiceList;
	}

	

	@SuppressWarnings("unchecked")
	@Override
	public List<EippInvCntLineItemVO> getInvoiceLineItemDetails(long invoiceId)throws BNPApplicationException {
		List<EippInvCntLineItemVO> lineItemList=null;
		try {
			LOGGER.debug("Entered getInvoiceLineItemDetails");
			lineItemList=getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_LINE_ITEM_DETAILS),invoiceId);
		} catch (DataAccessException ex) {
			LOGGER.error(" Exception in getInvoiceLineItemDetails" +ex.getMessage()); 
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		}
		LOGGER.debug("Exit getInvoiceLineItemDetails");
		return lineItemList;
	}


	@SuppressWarnings("unchecked")
	@Override
	public List<NameValueVO> getInvoiceCustomFields(long invoiceId)throws BNPApplicationException {
		List<NameValueVO> customList=null;
		try {
			LOGGER.debug("Entered getInvoiceCustomFields");
			customList=getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_INV_CUSTOM_FIELDS),invoiceId);
		}
		catch (DataAccessException ex) {
			LOGGER.error(" Exception in getInvoiceCustomFields" +ex.getMessage()); 
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		}
		LOGGER.debug("Exit getInvoiceDetails");
		return customList; 
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<NameValueVO> getInvcLineItemCustomFields(long invcLineItemId)throws BNPApplicationException {
		List<NameValueVO> customList=null;
		try {
			LOGGER.debug("Entered getInvcLineItemCustomFields");
			customList=getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_INV_LINEITEM_CUSTOM_FIELDS),invcLineItemId);
		}
		catch (DataAccessException ex) {
			LOGGER.error(" Exception in getInvcLineItemCustomFields" +ex.getMessage()); 
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		}
		LOGGER.debug("Exit getInvcLineItemCustomFields");
		return customList; 
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EippInvCntLineItemVO> getInvoiceDetailsFields(long linvoiceId)
	throws BNPApplicationException {
		List<EippInvCntLineItemVO> listEippVO =null;
		try
		{LOGGER.debug("Entered getInvoiceDetailsFeilds");
		listEippVO = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_DETAILS_PAGE_DETAILS),linvoiceId);
		}
		catch (Exception e) {
			LOGGER.error(" Exception in getInvoiceDetailsFeilds" +e.getMessage()); 
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		}
		LOGGER.debug("Exit getInvoiceDetailsFeilds");
		return listEippVO;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<InvoiceCancellationVO> getInvoiceAuditRecDetails(long linvoiceId)
	throws BNPApplicationException {
		List<InvoiceCancellationVO> listAuditVO =null;
		try
		{
			LOGGER.debug("Entered getInvoiceAuditRecDetails");
			listAuditVO = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_AUDIT_REC_DETAILS),linvoiceId);
		}
		catch (Exception e) {
			LOGGER.error(" Exception in getInvoiceAuditRecDetails" + e.getMessage()); 
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		}
		LOGGER.debug("Exit getInvoiceAuditRecDetails");
		return listAuditVO;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<InvoiceCancellationVO> getLineItemAuditDetails(long lineItemId)
	throws BNPApplicationException {
		List<InvoiceCancellationVO> listAuditLineItemVO =null;
		try
		{
			LOGGER.debug("Entered getLineItemAuditDetails");
			listAuditLineItemVO = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_AUDIT_LINEITEM_DETAILS),lineItemId);
		}
		catch (Exception e) {
			LOGGER.error(" Exception in getLineItemAuditDetails" + e.getMessage()); 
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		}
		LOGGER.debug("Entered getLineItemAuditDetails");
		return listAuditLineItemVO;
	}

	

	@Override
	public int approveRecord(long lInvId,String strUserId, String strStatus) throws BNPApplicationException {
		int iCount =0;
		Properties params= new Properties();
		LOGGER.debug("Entered approveRecord");
		params.put("lInvId", lInvId);
		params.put("strUserId", strUserId);
		params.put("chkrdate", new Date());
		params.put("updateStatus", strStatus);
		iCount = (Integer)getSqlMapClientTemplate().update(getQueryNameWithNameSpace(APPROVE_RECORDS), params);
		LOGGER.debug("Exit approveRecord");
		return iCount;
		
	}

	@Override
	public void approveAuditRecord(long lInvId)
			throws BNPApplicationException {
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(APPROVE_AUDIT_RECORDS), lInvId);
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AttachmentVO> getAttachmentDetails(long lInvoiceId)
			throws BNPApplicationException {
		return getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_ATTACHMENT),lInvoiceId);
	}
	@Override
	public String getDualControlStatus(String strUserId) throws BNPApplicationException
	{
		String bStatusChecked = "";
		try{
			LOGGER.debug("Entered getDualControlStatus");
			bStatusChecked   =(String)getSqlMapClient().queryForObject(getQueryNameWithNameSpace(DUAL_MANDAT_CHECK),strUserId);
		}
		catch(Exception e) {
			LOGGER.error(" Exception in getDualControlStatus" + e.getMessage()); 
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		}
		LOGGER.debug("Exit getDualControlStatus");
		return bStatusChecked;
	}

	@Override
	public int cancelRecord(long invoiceId, String strUser,
			String discountRequestCancelled) throws BNPApplicationException {
		int iCount =0;
		LOGGER.debug("Entered cancelRecord");
		Properties params= new Properties();
		params.put("invcId", invoiceId);
		params.put("strUserId", strUser);
		params.put("mkrdate", new Date());
		params.put("updateStatus", discountRequestCancelled);
		iCount = (Integer)getSqlMapClientTemplate().update(getQueryNameWithNameSpace(CANCEL_RECORDS), params);
		LOGGER.debug("Exit cancelRecord");
		return iCount;
		
	}

	@Override
	public void cancelAuditRecord(long lInvId) throws BNPApplicationException {
		
		getSqlMapClientTemplate().update(getQueryNameWithNameSpace(CANCEL_AUDIT_RECORDS), lInvId);
		
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<NameValueVO> fetchBuyerOrgList(String userId,String userType)
			throws BNPApplicationException {
		Properties params= new Properties();
		params.put("userId", userId);
		params.put("userType", userType);
		return getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(FETCH_BUYER_ORGID), params);
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<NameValueVO> fetchSupplierOgList(String userId,String userType)
			throws BNPApplicationException {
		Properties params= new Properties();
		params.put("userId", userId);
		params.put("userType", userType);
	return getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(FETCH_SUPPLIER_ORGID), params);
	}

	@Override
	public List<InvoiceCancellationVO> getCancelInvoiceList(long fileId){
		List<InvoiceCancellationVO> invoiceList = null;
		invoiceList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_CANCEL_INVOICE_LIST),fileId);
		return invoiceList;
	}	
	
	@Override
	public InvoiceCancellationVO getInvoiceForBusinessValidation(long invoiceId) throws BNPApplicationException {
		InvoiceCancellationVO invoiceVO = null;
		try
		{
			LOGGER.debug("Entered getInvoiceForBusinessValidation");
			invoiceVO = (InvoiceCancellationVO) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_INVOICE_FOR_BUSINESS_VALIDATION),invoiceId);
		}
		catch (Exception e) {
			LOGGER.error(" Exception in getInvoiceForBusinessValidation" + e.getMessage()); 
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		}
		LOGGER.debug("Exit getInvoiceForBusinessValidation");
		return invoiceVO;
	}
	
	@Override
	public int isInvoiceExistsForCancel(Map<String, Object> params, String checkStatus) throws BNPApplicationException {
		int count = 0;
		try{
			params.put("checkStatus", checkStatus);
			count =  (Integer) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(IS_INVOICE_EXISTS_FOR_CANCEL), params);
			return count;
		}catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public String getCreditNoteUtilStatus(String invoiceId){
		return (String) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_CREDIT_NOTE_UTIL_STATUS),invoiceId);
	}
	
	@Override
	public List<InvoiceCancellationVO> getCancelInvoiceDetails(
			long fileId, String status) throws BNPApplicationException {
		List<InvoiceCancellationVO> invoiceList = null;
		
		try {
			Properties params= new Properties();
			params.put("fileId", fileId);
			if (StatusConstants.VALIDATION_FAILED.equalsIgnoreCase(status)) {
				invoiceList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_DELETED_CANCEL_INVOICE_DTLS),params);
			} else {
				invoiceList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_CANCEL_INVOICE_DTLS),params);
			}
		} catch (DataAccessException e) {
			LOGGER.error("Error while fetching cancel invoice details " + e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return invoiceList;
	}

	@Override
	public void updateCancelInvoiceErrorCode(long pkId, int errorCode) {
		Properties params= new Properties();
		params.put("pkId", pkId);
		params.put("errorCode", errorCode);
		getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_ERROR_CODE), params);
	}
	
	@Override
	public int isInvoiceAvailableForCancel(EippInvoiceCancelVO eippInvoiceCancelVO) throws BNPApplicationException {
		int count = 0;
		try{
			count =  (Integer) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_INVOICE_COUNT_AVAILABLE_FOR_CANCEL), eippInvoiceCancelVO);
			return count;
		}catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public void insertFileDetailsIntoMaster(FileDetailsVO detailsVO) throws DBException {
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_CANCEL_INVOICE_INTO_MASTER), 
					detailsVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error while releasing cancel invoices : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public void insertFileDetailsIntoHistFromTrans(FileDetailsVO detailsVO)
			throws DBException {
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_CANCEL_INVOICE_INTO_HISTORY_FROM_TRANS), 
					detailsVO.getFileId());
		} catch (DataAccessException e) {
			LOGGER.error("Error while processing cancel invoices : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		
	}
	
	@Override
	public void insertFileDetailsIntoHistFromMaster(FileDetailsVO detailsVO) throws DBException {
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_CANCEL_INVOICE_INTO_HISTORY_FROM_MASTER), 
					detailsVO.getFileId());
		} catch (DataAccessException e) {
			LOGGER.error("Error while releasing cancel invoices : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		
	}

	@Override
	public void deleteFileDetailsFromTrans(FileDetailsVO detailsVO) throws DBException {
		try {
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(DELETE_CANCEL_INVOICE_FROM_TRANS), 
					detailsVO.getFileId());

		} catch (DataAccessException e) {
			LOGGER.error("Error while deleting cancel invoices : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		
	}
	
	@Override
	public void updateRecordStatusInTrans(long fileId, String status) throws BNPApplicationException {
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("fileId", fileId);
		params.put("status", status);

		try{
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_RECORD_STATUS_IN_TRANS), params);
		} catch (DataAccessException e) {
			LOGGER.error(e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}		
	}
	
	@Override
	public List<EippInvoiceVO> getModifyInvoiceList(long fileId) throws BNPApplicationException {
		List<EippInvoiceVO> invoiceList = null;
		try {
			invoiceList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_MODIFY_INVOICE_LIST),fileId);
		} catch (DataAccessException e) {
			LOGGER.error("Error while getting modify invoice " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}		
		return invoiceList;
	}
	
	@Override
	public void updateInvoiceErrorCode(long invId, int errorCode) {
		Properties params= new Properties();
		params.put("invId", invId);
		params.put("errorCode", errorCode);
		getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_MODIFY_INV_ERROR_CODE), params);
	}

}
