/* ************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   23 August 2012 
 * 
 * Purpose:       This class is used to create EIPP Payment Status Update message
 * 
 * Change History: 
 * Date                                                  Author                                                    Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 23 Aug 2012                      Oracle Financial Services Software Ltd           							Initial version
 * 
 ***************************************************************************/
package com.bnp.eipp.services.interfaces.billing;

import java.util.GregorianCalendar;



import com.bnp.eipp.services.billing.count.bindingvo.Document;
import com.bnp.eipp.services.billing.count.bindingvo.File;
import com.bnp.eipp.services.billing.count.bindingvo.Header;
import com.bnp.eipp.services.billing.count.bindingvo.Message;
import com.bnp.eipp.services.billing.count.bindingvo.ObjectFactory;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.AbstractVO;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;
import com.bnp.scm.services.txns.common.message.bindingvo.BaseFile;
import com.bnp.scm.services.txns.common.message.bindingvo.BaseHeader;
import com.bnp.scm.services.txns.common.message.bindingvo.BaseMessage;
import com.bnp.scm.services.txns.util.PropertiesReader;
import com.bnp.scm.services.txns.util.xml.BindingProperties;
import com.bnp.scm.services.txns.util.xml.XmlBinding;
import com.bnp.scm.services.txns.util.xml.XmlValidationEventHandler;


public class EippBillingChargeCountMessage extends AbstractMessage<Message> {

	private ObjectFactory factory;
	
	private Document document;
	
	@Override
	public void createInstance() throws BNPApplicationException {
		this.factory = new ObjectFactory();
		this.message = new Message();
		this.body = new File();
		this.header = new Header(); 
		this.document = new Document();
	}

	/*
	 * (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.AbstractMessage#createHeader(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void createHeader(AbstractVO abstractVO) throws BNPApplicationException {
		if(abstractVO instanceof FileDetailsVO){
			FileDetailsVO detailsVO = (FileDetailsVO)abstractVO;
			try {
				GregorianCalendar greCal = new GregorianCalendar();
				header.setCountry(detailsVO.getCountryCode());
				header.setBankCode(detailsVO.getBankCode());
				header.setBranchCode(detailsVO.getBranchCode());
				header.setSCMOrgId(detailsVO.getSenderOrgId());
				header.setMsgFileType(PropertiesReader.getProperty("message.type.eipp.billingcount"));
				header.setCntType(PropertiesReader.getProperty("message.content.type.xml"));
				header.setMsgFileSts(PropertiesReader.getProperty("file.status.load"));
				header.setSrcRefId(detailsVO.getMsgId());
				header.setH2HTrfsId("");
				header.setDestRefId("");
				header.setCustFileName(detailsVO.getFileName());
				header.setOrgin(PropertiesReader.getProperty("txns.label.fo"));
				header.setDestination(PropertiesReader.getProperty("txns.label.fo"));
				header.setCustFileRecvTime(greCal);
				header.setSenderID("");
				header.setReceiverID("");
				header.setConvStartTime(null);
				header.setConvEndTime(null);
				header.setSendTime(greCal);
				this.setHeader(header);
			}
			catch (Exception exception) {
				throw new BNPApplicationException(exception.getMessage(), exception);
			}
		}
		
	}

	/*
	 * (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.AbstractMessage#createBody(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void createBody(AbstractVO abstractVO) throws BNPApplicationException {
		
		if(abstractVO instanceof FileDetailsVO){
			FileDetailsVO detailsVO = (FileDetailsVO)abstractVO;
			BindingProperties<Document> properties = new BindingProperties<Document>();
			properties.setXsdPath(PropertiesReader.getProperty("message.eippschema.billingCount.xsd.path"));
			properties.setBindingClass(Document.class);
			properties.setValidateXsd(true);
			properties.setEventHandler(new XmlValidationEventHandler());
			document = XmlBinding.unmarshallWithRootTypeElement(new String(detailsVO.getFileData()),properties);
			((File)body).setDocument(document); 
			this.setBody(body);
		}			
	} 

	/*
	 * (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.AbstractMessage#createMessage(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void createMessage() throws BNPApplicationException {
		if( factory==null){
			this.factory = new ObjectFactory();	
		}
		Message billCountMsg = (Message)this.getMessage();
		billCountMsg.setFile((File)this.getBody());
		billCountMsg.setHeader((Header)this.getHeader());
		this.setMessage(billCountMsg); 
		this.setJaxbElementObj(factory.createMsg(billCountMsg));
	}

	/* (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.IMessage#setBindingProperties()
	 */
	@Override
	public void setBindingProperties() {
		this.properties.setBindingClass(Message.class);
		this.properties.setValidateXsd(true);
		this.properties.setXsdPath(PropertiesReader.getProperty("message.billingCount.xsd.path"));
		this.properties.setEventHandler(new XmlValidationEventHandler());
		this.setProperties(properties);
	}
	
	/**
	 * @return the header
	 */
	public BaseHeader getHeader() {
		return header;
	}

	/**
	 * @param header the header to set
	 */
	public void setHeader(BaseHeader header) {
		this.header = header;
	}

	/**
	 * @return the body
	 */
	public BaseFile getBody() {
		return body;
	}

	/**
	 * @param body the body to set
	 */
	public void setBody(BaseFile body) {
		this.body = body;
	}

	/**
	 * @return the message
	 */
	public BaseMessage getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(BaseMessage message) {
		this.message = message;
	}
	
}
