/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 17, 201211:35:09 AM
 * 
 * Purpose:      DeptAllocMapVO.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 17, 201211:35:09 AM        Oracle Financial Services Software Ltd                  Initial Version
************************************************************************************************************************************************************/
package com.bnp.eipp.services.invoice.vo;

import java.math.BigDecimal;

/**
 * The Class EippDisputeVO.
 *
 * @author SandhyaRad
 */
public class EippDisputeVO {
	
	private long invId;
	
	private String invRefNo;
	
	private String disputeRefNo;
	
	private String disputeStatus;
	
	private String supplierRef;
	
	private String dispReasonCode;
	
	private String otherReasons;
	
	private String buyerMemo;
	
	private String supplierMemo;
	
	private BigDecimal oldNetValue;
	
	private BigDecimal newNetValue;

	/**
	 * Gets the inv id.
	 *
	 * @return the inv id
	 */
	public long getInvId() {
		return invId;
	}

	/**
	 * Sets the inv id.
	 *
	 * @param invId the new inv id
	 */
	public void setInvId(long invId) {
		this.invId = invId;
	}

	/**
	 * Gets the dispute ref no.
	 *
	 * @return the dispute ref no
	 */
	public String getDisputeRefNo() {
		return disputeRefNo;
	}

	/**
	 * Sets the dispute ref no.
	 *
	 * @param disputeRefNo the new dispute ref no
	 */
	public void setDisputeRefNo(String disputeRefNo) {
		this.disputeRefNo = disputeRefNo;
	}

	/**
	 * Gets the dispute status.
	 *
	 * @return the dispute status
	 */
	public String getDisputeStatus() {
		return disputeStatus;
	}

	/**
	 * Sets the dispute status.
	 *
	 * @param disputeStatus the new dispute status
	 */
	public void setDisputeStatus(String disputeStatus) {
		this.disputeStatus = disputeStatus;
	}

	/**
	 * Gets the inv ref no.
	 *
	 * @return the inv ref no
	 */
	public String getInvRefNo() {
		return invRefNo;
	}

	/**
	 * Sets the inv ref no.
	 *
	 * @param invRefNo the new inv ref no
	 */
	public void setInvRefNo(String invRefNo) {
		this.invRefNo = invRefNo;
	}

	/**
	 * Gets the supplier ref.
	 *
	 * @return the supplier ref
	 */
	public String getSupplierRef() {
		return supplierRef;
	}

	/**
	 * Sets the supplier ref.
	 *
	 * @param supplierRef the new supplier ref
	 */
	public void setSupplierRef(String supplierRef) {
		this.supplierRef = supplierRef;
	}

	/**
	 * Gets the disp reason code.
	 *
	 * @return the disp reason code
	 */
	public String getDispReasonCode() {
		return dispReasonCode;
	}

	/**
	 * Sets the disp reason code.
	 *
	 * @param dispReasonCode the new disp reason code
	 */
	public void setDispReasonCode(String dispReasonCode) {
		this.dispReasonCode = dispReasonCode;
	}

	/**
	 * Gets the other reasons.
	 *
	 * @return the other reasons
	 */
	public String getOtherReasons() {
		return otherReasons;
	}

	/**
	 * Sets the other reasons.
	 *
	 * @param otherReasons the new other reasons
	 */
	public void setOtherReasons(String otherReasons) {
		this.otherReasons = otherReasons;
	}

	/**
	 * Gets the buyer memo.
	 *
	 * @return the buyer memo
	 */
	public String getBuyerMemo() {
		return buyerMemo;
	}

	/**
	 * Sets the buyer memo.
	 *
	 * @param buyerMemo the new buyer memo
	 */
	public void setBuyerMemo(String buyerMemo) {
		this.buyerMemo = buyerMemo;
	}

	/**
	 * Gets the supplier memo.
	 *
	 * @return the supplier memo
	 */
	public String getSupplierMemo() {
		return supplierMemo;
	}

	/**
	 * Sets the supplier memo.
	 *
	 * @param supplierMemo the new supplier memo
	 */
	public void setSupplierMemo(String supplierMemo) {
		this.supplierMemo = supplierMemo;
	}

	/**
	 * Gets the old net value.
	 *
	 * @return the old net value
	 */
	public BigDecimal getOldNetValue() {
		return oldNetValue;
	}

	/**
	 * Sets the old net value.
	 *
	 * @param oldNetValue the new old net value
	 */
	public void setOldNetValue(BigDecimal oldNetValue) {
		this.oldNetValue = oldNetValue;
	}

	/**
	 * Gets the new net value.
	 *
	 * @return the new net value
	 */
	public BigDecimal getNewNetValue() {
		return newNetValue;
	}

	/**
	 * Sets the new net value.
	 *
	 * @param newNetValue the new new net value
	 */
	public void setNewNetValue(BigDecimal newNetValue) {
		this.newNetValue = newNetValue;
	}

}
