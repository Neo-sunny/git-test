package com.bnp.eipp.services.matching.invoice.bindingvo;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

/**
 * This object contains factory methods for each Java content interface and Java element interface generated in the com.bnp.eipp.services.matching.invoice.bindingvo package.
 * <p>
 * An ObjectFactory allows you to programatically construct new instances of the Java representation for XML content. The Java representation of XML content can consist of schema derived interfaces
 * and classes representing the binding of schema type definitions, element declarations and model groups. Factory methods for each of these are provided in this class.
 */
@XmlRegistry
public class ObjectFactory {

	private final static QName _ErrorDescription_QNAME = new QName("", "ErrorDescription");

	private final static QName _Msg_QNAME = new QName("", "Msg");

	/**
	 * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.bnp.eipp.services.matching.invoice.bindingvo
	 */
	public ObjectFactory() {
	}

	/**
	 * Create an instance of {@link Header }
	 */
	public Header createHeader() {
		return new Header();
	}

	/**
	 * Create an instance of {@link AdditionalInformation1 }
	 */
	public AdditionalInformation1 createAdditionalInformation1() {
		return new AdditionalInformation1();
	}

	/**
	 * Create an instance of {@link SourceAndMatchDtls01 }
	 */
	public SourceAndMatchDtls01 createSourceAndMatchDtls01() {
		return new SourceAndMatchDtls01();
	}

	/**
	 * Create an instance of {@link ReconciliationDetails01 }
	 */
	public ReconciliationDetails01 createReconciliationDetails01() {
		return new ReconciliationDetails01();
	}

	/**
	 * Create an instance of {@link CreditNoteDetails01 }
	 */
	public CreditNoteDetails01 createCreditNoteDetails01() {
		return new CreditNoteDetails01();
	}

	/**
	 * Create an instance of {@link Message }
	 */
	public Message createMessage() {
		return new Message();
	}

	/**
	 * Create an instance of {@link File }
	 */
	public File createFile() {
		return new File();
	}

	/**
	 * Create an instance of {@link ErrorDescription }
	 */
	public ErrorDescription createErrorDescription() {
		return new ErrorDescription();
	}

	/**
	 * Create an instance of {@link LineItems01 }
	 */
	public LineItems01 createLineItems01() {
		return new LineItems01();
	}

	/**
	 * Create an instance of {@link InvoiceAndPODetails01 }
	 */
	public InvoiceAndPODetails01 createInvoiceAndPODetails01() {
		return new InvoiceAndPODetails01();
	}

	/**
	 * Create an instance of {@link GeneralInfo01 }
	 */
	public GeneralInfo01 createGeneralInfo01() {
		return new GeneralInfo01();
	}

	/**
	 * Create an instance of {@link Document }
	 */
	public Document createDocument() {
		return new Document();
	}

	/**
	 * Create an instance of {@link Address01 }
	 */
	public Address01 createAddress01() {
		return new Address01();
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link ErrorDescription }{@code >}
	 */
	@XmlElementDecl(namespace = "", name = "ErrorDescription")
	public JAXBElement<ErrorDescription> createErrorDescription(ErrorDescription value) {
		return new JAXBElement<ErrorDescription>(_ErrorDescription_QNAME, ErrorDescription.class, null, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link Message }{@code >}
	 */
	@XmlElementDecl(namespace = "", name = "Msg")
	public JAXBElement<Message> createMsg(Message value) {
		return new JAXBElement<Message>(_Msg_QNAME, Message.class, null, value);
	}

}
