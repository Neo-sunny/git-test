/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 22, 201211:50:35 PM
 * 
 * Purpose:      IDisputeMgmtDao.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 22, 201211:50:35 PM        Oracle Financial Services Software Ltd                  Initial Version  
 * Mar 10 2012				      Oracle Financial Services Software Ltd                  UT Fixes
 * 14 May   2012		 		  Sandhya											      R2.1 UAT # 2240
 * 03 Aug 2012					  Reena S											      Rel 3.0 EIPP Phase II Release File Inq Changes
 * 06 Sep 2012                    Reena S												  Release 3.0  For getting Validation Failed Record details
 * 08 Nov 2012 					  Reena S												  Added getPrevInvcStatusForCancel	  
 * 09-Nov-2012					  Yashmika												UAT Bug Fix # 2916
 ************************************************************************************************************************************************************/

package com.bnp.eipp.services.dao.dispute;

import java.sql.Timestamp;
import java.util.List;

import com.bnp.eipp.services.invoice.vo.EippCustFieldsVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.scm.services.common.vo.AttachmentVO;
import com.bnp.eipp.services.vo.dispute.DisputeAllocationMappingVO;
import com.bnp.eipp.services.vo.dispute.DisputeAuditVO;
import com.bnp.eipp.services.vo.dispute.DisputeCustFieldsVO;
import com.bnp.eipp.services.vo.dispute.DisputeVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

/**
 * The Interface IDisputeMgmtDao.
 */
public interface IDisputeMgmtDao {

	String INSERT_INVOICE_DISPUTE = "insertInvoiceDispute";

	String INSERT_LN_ITM_DISPUTE = "insertInvDetDispute";

	String INSERT_DISP_ALLOC_MAPPING = "insertDispAllocMapping";

	String REASSIGN_DISPUTE = "reassignDispute";

	String ACCEPT_INV_DISPUTE = "acceptInvDispute";

	String REJECT_INV_DISPUTE = "rejectInvDispute";

	String ACCEPT_INV_DET_DISPUTE = "acceptInvDetDispute";

	String REJECT_INV_DET_DISPUTE = "rejectInvDetDispute";

	String APPROVE_INV_DISPUTE = "approveInvDispute";

	String APPROVE_INV_DET_DISPUTE = "approveInvDetDispute";

	String UPDATE_INV_DISPUTE_STATUS = "updateInvDisputeStatus";

	String UPDATE_INV_DET_DISPUTE_STATUS = "updateInvDetDisputeStatus";

	String GET_DISPUTE_SUMMARY_FOR_BUYER = "getDisputeSummaryDetailsForBuyer";

	String GET_DISPUTE_SUMMARY_FOR_SUPPLIER = "getDisputeSummaryDetailsForSupplier";

	String UPDATE_INV_STATUS = "updateInvoiceStatus";

	String CHECK_FOR_RESOLUTION_APPROVAL = "checkForResolutionApproval";

	String UPDATE_DET_DISP_TIMESTAMP = "updateDetDisputeTxnTimestamp";

	String RESET_DET_DISP_FLAG = "resetDetDisputeProcessingFlag";

	String CALL_DISP_ALLOC_PROC = "callDispAllocProc";

	String SAVE_INV_DET_DISP_ATTACHMENT = "saveInvDetDispAttachment";

	String SAVE_INV_DISP_ATTACHMENT = "saveInvDispAttachment";

	String APPROVE_INV_DISP_RESOLUTION = "approveInvDisputeResolution";

	String APPROVE_INV_DET_DISP_RESOLUTION = "approveInvDetDisputeResolution";

	String INSERT_INV_DISP_HIST = "insertInvDispHistory";

	String INSERT_INV_DET_DISP_HIST = "insertInvDetDispHistory";

	String IS_ALL0C_RULE_AVAILABLE = "isDispAllocRuleAvailable";

	String GET_INV_DET_DISPUTE_DETAILS = "getInvDetDisputeDetail";

	String GET_INV_DISPUTE_DETAILS = "getInvDisputeDetail";

	String GET_INV_DISP_ATTACH_DETAILS = "getInvDisputeAttachDetails";

	String GET_INV_DET_DISP_ATTACH_DETAILS = "getInvDetDisputeAttachDetails";

	String GET_LN_ITM_CUST_FIELDS = "getLineItmDisputeCustFields";

	String GET_INV_CUST_FIELDS = "getInvDisputeCustFields";

	String OVERRIDE_INV_DISPUTE = "overrideInvDispute";

	String OVERRIDE_INV_DET_DISPUTE = "overrideInvDetDispute";

	String UPDATE_DISP_ALLOC_MAPPING = "updateDispAllocMapping";

	String GET_EXISTING_ASSIGNEES = "getExistingAssignees";

	String GET_AVAILABLE_DEPTS = "getAvailableDepts";

	String GET_AVAILABLE_USERS = "getAvailableUsers";

	String INSERT_DISP_ALLOC_MAPPING_HIST = "insertAllocMapHist";

	String GET_DEPT_ID_LIST = "getDeptIdList";

	String INSERT_LINEITM_DISPUTE = "insertLineItmDispute";

	String INSERT_LINEITM_DISPUTE_HIST = "insertLineItmDisputeHist";

	String INSERT_INVOICE_DISPUTE_HIST = "insertInvDisputeHist";

	String GET_DISPUTE_CODES = "getDisputeCodes";

	String INSERT_DISPUTE_CUST_FIELDS = "insertDispCustFlds";

	String INSERT_DISP_LINEITM_MAPPING = "insertDispLineItmMapping";

	String GET_DISPUTE_REFERENCE = "getDisputeReference";

	String GET_EXISTING_DISPUTE = "getExistingDispute";

	String INSERT_INVOICE_DISPUTE_IN_ALLOC_MAP = "insertDisputeInAllocMap";
	
	String GET_DEPT_ID = "getDeptIds";
	
	String UPDATE_INV_LI_STATUS ="updateInvLIStatus";
	
	String GET_INV_DISPUTE_ATTACH_DETAILS = "getInvDispAttachments";
	
	String GET_INV_DET_DISPUTE_ATTACH_DETAILS = "getInvDetDispAttachments";
	
	String POPULATE_LN_ITEM_DETAILS = "populateLineItemDetailsForDispute";
	
	String GET_DISPUTE_DETAILS = "getDisputeDetailsForInvoice";
	
	String IS_BUYER_CENTRIC_MODEL = "checkForOrgModel";
	
	String CANCEL_INV_DISPUTE = "cancelInvDispute";
	
	String CANCEL_INV_DET_DISPUTE = "cancelInvDetDispute";
	
	String GET_DEPT_ID_FOR_LI  = "getDeptIdsForLI";
	
	String UPDATE_LI_STATUS_WITH_INVID = "updateLIStatus";
	
	String GET_DISPUTED_LN_ITEMS = "getDisputedLineItems";
	
	String GET_LN_ITM_DISP_FIELDS = "getLineItemDisputedFields";
	
	String INSERT_DISPUTE_AUDIT = "insertIntoDisputeAudit";
	
	String GET_TIME_STAMP = "getLastUpdatedTS";
	
	String  GET_DEPT_ID_FROM_DISP = "getDeptIdsFromDisputeAllocation";
	
	String GET_DISPUTE_COUNT_FORFILE="getDisputeRecordCount";
	
	String GET_DISPUTE_RESOLN_COUNT_FORFILE="getDisputeResolutionRecordCount";
	
	String GET_DISPUTE_RECORD_DETAILS="getDisputeFileDetails";	
	
	String GET_DISPUTE_RESOLN_RECORD_DETAILS="getDispResolutionFileDetails";
	
	String GET_PREV_INVC_STATUS_FOR_CANCEL="getPrevInvcStatusForCancel";
	
	String FETCH_CUSTOM_FIELDS_FOR_INV = "fetchCustomFieldsForInv";
	
	String GET_INVOICE_DETAILS = "fetchInvoiceDetails";
	
	/**
	 * Insert invoice dispute.
	 * 
	 * @param disputeVO
	 *            the dispute vo
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	void insertInvoiceDispute(DisputeVO disputeVO)
			throws BNPApplicationException;

	/**
	 * Insert invoice li dispute.
	 * 
	 * @param disputeVO
	 *            the dispute vo
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	List<Long> insertInvoiceLIDispute(DisputeVO disputeVO)
			throws BNPApplicationException;

	/**
	 * Insert invoice detail dispute.
	 * 
	 * @param disputeVO
	 *            the dispute vo
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	void insertInvoiceDetailDispute(DisputeVO disputeVO)
			throws BNPApplicationException;

	/**
	 * Gets the dispute codes.
	 * 
	 * @param eippInvoiceVO
	 *            the eipp invoice vo
	 * @return the dispute codes
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	List<NameValueVO> getDisputeCodes(EippInvoiceVO eippInvoiceVO)
			throws BNPApplicationException;

	/**
	 * Check existing dispute.
	 * 
	 * @param dispCode
	 *            the disp code
	 * @param invId
	 *            the inv id
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	void checkExistingDispute(long invId)
			throws BNPApplicationException;

	/**
	 * Insert inv disp attachment.
	 * 
	 * @param attachmentVO
	 *            the attachment vo
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	void insertInvDispAttachment(AttachmentVO attachmentVO)
			throws BNPApplicationException;

	/**
	 * Insert dispute allocation mapping.
	 * 
	 * @param mappingVO
	 *            the mapping vo
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	void insertDisputeAllocationMapping(DisputeAllocationMappingVO mappingVO)
			throws BNPApplicationException;

	/**
	 * Insert dispute allocation mapping.
	 * 
	 * @param mappingList
	 *            the mapping list
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	void insertDisputeAllocationMapping(
			List<DisputeAllocationMappingVO> mappingList)
			throws BNPApplicationException;

	/**
	 * Reassign dispute.
	 * 
	 * @param dispute
	 *            the dispute
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	void reassignDispute(DisputeVO dispute) throws BNPApplicationException;

	/**
	 * Update dispute resolution.
	 * 
	 * @param invDispute
	 *            the inv dispute
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	void updateDisputeResolution(DisputeVO invDispute)
			throws BNPApplicationException;

	/**
	 * Approve invoice dispute.
	 * 
	 * @param invDispute
	 *            the inv dispute
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	void approveInvoiceDispute(DisputeVO invDispute)
			throws BNPApplicationException;

	/**
	 * Approve inv det dispute.
	 * 
	 * @param detailDispute
	 *            the detail dispute
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	void approveInvDetDispute(DisputeVO detailDispute)
			throws BNPApplicationException;

	/**
	 * Gets the dispute details.
	 * 
	 * @param disputeVO
	 *            the dispute vo
	 * @return the dispute details
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	List<DisputeVO> getDisputeDetails(DisputeVO disputeVO)
			throws BNPApplicationException;

	/**
	 * Update invoice status.
	 * 
	 * @param status
	 *            the status
	 * @param invoiceId
	 *            the invoice id
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	Timestamp updateInvoiceStatus(String status, long invoiceId)
			throws BNPApplicationException;

	/**
	 * Update dispute status.
	 * 
	 * @param status
	 *            the status
	 * @param disputeVO
	 *            the dispute vo
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	void updateDisputeStatus(String status, DisputeVO disputeVO)
			throws BNPApplicationException;

	/**
	 * Check for resolution approval.
	 * 
	 * @param orgId
	 *            the org id
	 * @return true, if successful
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	boolean checkForResolutionApproval(String orgId)
			throws BNPApplicationException;

	/**
	 * Cancel dispute.
	 * 
	 * @param dispute
	 *            the dispute
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	void cancelDispute(DisputeVO dispute) throws BNPApplicationException;

	/**
	 * Populate dispute alloc mapping.
	 * 
	 * @param dispute
	 *            the dispute
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	void populateDisputeAllocMapping(DisputeVO dispute)
			throws BNPApplicationException;

	/**
	 * Accept dispute.
	 * 
	 * @param status
	 *            the status
	 * @param dispute
	 *            the dispute
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	void acceptDispute(String status, DisputeVO dispute)
			throws BNPApplicationException;

	/**
	 * Reject dispute.
	 * 
	 * @param status
	 *            the status
	 * @param dispute
	 *            the dispute
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	void rejectDispute(String status, DisputeVO dispute)
			throws BNPApplicationException;

	/**
	 * Insert invoice dispute history.
	 * 
	 * @param disputeId
	 *            the dispute id
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	void insertInvoiceDisputeHistory(long disputeId)
			throws BNPApplicationException;

	/**
	 * Insert invoice det dispute history.
	 * 
	 * @param disputeId
	 *            the dispute id
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	void insertInvoiceDetDisputeHistory(long disputeId)
			throws BNPApplicationException;

	/**
	 * Checks if is dispute alloc rule available.
	 * 
	 * @param dispute
	 *            the dispute
	 * @return true, if is dispute alloc rule available
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	boolean isDisputeAllocRuleAvailable(DisputeVO dispute)
			throws BNPApplicationException;

	/**
	 * Gets the dispute detail.
	 * 
	 * @param dispute
	 *            the dispute
	 * @return the dispute detail
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	DisputeVO getDisputeDetail(DisputeVO dispute)
			throws BNPApplicationException;

	/**
	 * Override inv dispute.
	 * 
	 * @param dispute
	 *            the dispute
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	void overrideInvDispute(DisputeVO dispute) throws BNPApplicationException;

	/**
	 * Override inv det dispute.
	 * 
	 * @param dispute
	 *            the dispute
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	void overrideInvDetDispute(DisputeVO dispute)
			throws BNPApplicationException;

	/**
	 * Update dispute alloc mapping.
	 * 
	 * @param dispute
	 *            the dispute
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	void updateDisputeAllocMapping(DisputeVO dispute)
			throws BNPApplicationException;

	/**
	 * Gets the existing assignees.
	 * 
	 * @param dispute
	 *            the dispute
	 * @return the existing assignees
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	List<DisputeAllocationMappingVO> getExistingAssignees(DisputeVO dispute)
			throws BNPApplicationException;

	/**
	 * Gets the available departments.
	 * 
	 * @param dispute
	 *            the dispute
	 * @return the available departments
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	List<String> getAvailableDepartments(DisputeVO dispute)
			throws BNPApplicationException;

	/**
	 * Gets the available users.
	 * 
	 * @param dispute
	 *            the dispute
	 * @return the available users
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	List<String> getAvailableUsers(DisputeVO dispute)
			throws BNPApplicationException;

	/**
	 * Gets the dept id list.
	 * 
	 * @param dispute
	 *            the dispute
	 * @return the dept id list
	 * @throws BNPApplicationException
	 *             the bNP application exception
	 */
	List<Integer> getDeptIdList(DisputeVO dispute)
			throws BNPApplicationException;
	
	/**
	 * Batch insert alloc map.
	 *
	 * @param disputeVO the dispute vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void batchInsertAllocMap(final DisputeVO disputeVO) throws BNPApplicationException;
	
	/**
	 * Insert disute in alloc map.
	 *
	 * @param disputeVO the dispute vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void insertDisuteInAllocMap(DisputeVO disputeVO) throws BNPApplicationException;
	
	/**
	 * This API returns the list of attachments available for that dispute
	 * @param dispute
	 * @return
	 * @throws BNPApplicationException
	 */
	List<AttachmentVO> getAttachmentDetails(
			DisputeVO dispute) throws BNPApplicationException;
	
	/**
	 * Gets the dispute detail summary.
	 *
	 * @param invId the inv id
	 * @return the dispute detail summary
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<DisputeVO> getDisputeDetailSummary(long invId)
		throws BNPApplicationException;
	
	boolean isBuyercentricModel(String orgId) throws BNPApplicationException;
	
	List<Long> getDisputedLineItems(
			String dispRefNo) throws BNPApplicationException;
	
	List<DisputeCustFieldsVO> getLineItemDispFields(
			String dispRefNo) throws BNPApplicationException;
	
	void insertDisputeAudit(DisputeAuditVO disputeAudit) 
			throws BNPApplicationException;
	
	List<Long> getDeptIdForSupplier(DisputeVO disputeVO) throws BNPApplicationException;
	
	int getDisputeRaisedCountForFile(NameValueVO params)throws BNPApplicationException;
	
	int getDisputeResolvedCountForFile(NameValueVO params)throws BNPApplicationException;

	List<DisputeVO> getRaiseDisputeRecordDetails(NameValueVO params) throws BNPApplicationException;
	
	List<DisputeVO> getDisputeResolvedRecordDetails(NameValueVO params) throws BNPApplicationException;
	
	String getPrevInvcStatusForCancel(long invoiceId)throws BNPApplicationException;
	
	List<EippCustFieldsVO> getInvoiceCustFields(long invoiceId)throws BNPApplicationException;
  
	EippInvoiceVO getInvoiceDetails(long invoiceId)throws BNPApplicationException;
}
