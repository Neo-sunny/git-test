/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   18 July 2012
 * 
 * Purpose:      FileProcessServiceImpl
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 July 2012        Oracle Financial Services Software Ltd                  Initial Version  
************************************************************************************************************************************************************/

package com.bnp.eipp.services.filemgmt;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.invoice.IEippInvcUploadService;
import com.bnp.eipp.services.invoice.IEippReleaseService;
import com.bnp.eipp.services.invoice.vo.EippInvCntVO;
import com.bnp.scm.services.admin.IOrganizationService;
import com.bnp.scm.services.common.ILocaleMessageLoaderService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.BNPRuntimeException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.discounting.IDiscountRequestService;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.interfaces.common.message.IMessageService;
import com.bnp.scm.services.invoice.IInvoiceUploadService;
import com.bnp.scm.services.invoice.vo.InvalidFileDataVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;

@Component
public class FileProcessServiceImpl implements IFileProcessService {
	
	@Autowired
	private IInvoiceUploadService invoiceUploadService;
	
	@Autowired
	private IDiscountRequestService discountRequestService;
	
	@Autowired 
	private IMessageService messageService;
	
	@Autowired
	private IEippInvcUploadService eippInvcUploadService;
	
	@Autowired
	protected ILocaleMessageLoaderService msgService;
	
	@Autowired 
	private IEippReleaseService eippReleaseService;
	
	@Autowired
	protected IOrganizationService orgService;
	
	@Override
	public void checkForDuplicateFile(FileDetailsVO detailsVO)
			throws BNPApplicationException {
		Integer dupCnt = null;
		try {
			dupCnt = invoiceUploadService.duplicateFileCheck(detailsVO);
			if(dupCnt != null && dupCnt > 0) {
				throw new BNPApplicationException(ErrorConstants.DUPLICATE_FILE_ERROR);
			}
		}
		catch(BNPApplicationException ex) {
			throw ex;
		}
	}
	
	public void saveFileDetails(FileDetailsVO detailsVO) throws BNPApplicationException {
		invoiceUploadService.saveFileDetails(detailsVO);
	}

	@Override
	public void triggerEventLog(FileDetailsVO detailsVO, String action)
			throws BNPApplicationException {
		invoiceUploadService.triggerEventLog(detailsVO,action);
	}

	@Override
	public FileDetailsVO getHeaderDetails(FileDetailsVO detailsVO)
			throws BNPApplicationException {
		return invoiceUploadService.getHeaderDetails(detailsVO);
	}

	@Override
	public void insertFileUploadMessageDetails(FileDetailsVO detailsVO)
			throws BNPApplicationException {
		invoiceUploadService.insertFileUploadMessageDetails(detailsVO);
	}

	@Override
	public String getMessageId() throws BNPApplicationException {
		return discountRequestService.getMessageId();
	}

	@Override
	public void updateFileStatus(FileDetailsVO detailsVO)
			throws BNPApplicationException {
		invoiceUploadService.updateFileStatus(detailsVO);		
	}

	@Override
	public void updateERPDownloadForCustomFile(FileDetailsVO detailsVO,
			String status) throws BNPApplicationException {
		invoiceUploadService.updateERPDownloadForCustomFile(detailsVO, status);
	}

	@Override
	public <T> void sendMessage(AbstractMessage<T> message, String queueName,
			Map<String, String> jmsProperties) throws BNPApplicationException {
		messageService.sendMessage(message, queueName, jmsProperties);		
	}

	@Override
	public boolean canUploadPartialFile(String senderOrgId)
			throws BNPApplicationException {
		return eippInvcUploadService.canUploadPartialFile(senderOrgId);
	}

	@Override
	public void insertInvalidRecords(List<InvalidFileDataVO> invalidList) throws BNPApplicationException {
		invoiceUploadService.insertInvalidDetails(invalidList);
	}
	
	@Override
	public List<String> getCustomerOrgId(String billType,String custERPId) throws BNPApplicationException {
		return eippInvcUploadService.getCustomerOrgId(billType, custERPId);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.filemgmt.IFileProcessService#processAndReleaseFile(com.bnp.scm.services.filemgmt.vo.FileDetailsVO, com.bnp.scm.services.txns.common.message.AbstractMessage, com.bnp.scm.services.filemgmt.vo.FileUploadVO)
	 */
	@Override
	public void processAndReleaseFile(FileDetailsVO detailsVO,
			AbstractMessage<?> invoiceMessage) throws BNPApplicationException {

		Map<String, List<EippInvCntVO>> eippInvCntMap = eippInvcUploadService.process(
				detailsVO, invoiceMessage);
		eippInvcUploadService.release(detailsVO, invoiceMessage, eippInvCntMap);
		
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.filemgmt.IFileProcessService#getModelTypeForOrganization(java.lang.String)
	 */
	@Override
	public String getModelTypeForOrganization(String senderOrgId) throws BNPApplicationException {
		return eippInvcUploadService.getModelTypeForOrganization(senderOrgId);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.filemgmt.IFileProcessService#getTimezoneForOrganization(java.lang.String)
	 */
	@Override
	public String getTimezoneForOrganization(String senderOrgId) throws BNPApplicationException {
		return eippInvcUploadService.getTimezoneForOrganization(senderOrgId);
	}
	
	public List<String> getCounterPartyOrgId(String orgId, String billType,String cntpERPId) throws BNPApplicationException{
		return eippInvcUploadService.getCounterPartyOrgId(orgId, billType, cntpERPId);
	}
	
	public boolean isBuyerSellerLinked(String custOrgId,String cntpOrgId,String billType) throws BNPApplicationException {
		return eippInvcUploadService.isBuyerSellerLinked(custOrgId, cntpOrgId, billType);
	}

	@Override
	public void deleteFile(FileDetailsVO detailsVO) throws BNPApplicationException{
		eippReleaseService.deleteFile(detailsVO);
	}
	
	@Override
	public void updateReprocessFlag(List<InvalidFileDataVO> invalidDataList,FileDetailsVO detailsVO) throws BNPApplicationException{
		eippInvcUploadService.updateReprocessFlag(invalidDataList, detailsVO);
	}

	@Override
	public boolean isAutoReleaseEnabled(String senderOrgId)
			throws BNPApplicationException {
		return orgService.isAutoAuthorizationEnabled(senderOrgId);
	}
	
	/**
	 * This method is used for getting orgnization's org_type  
	 * @param orgId
	 * @return
	 * @throws BNPApplicationException 
	 */
	@Override
	public String getOrganizationType(String orgId) throws BNPApplicationException{
		return eippInvcUploadService.getOrgTypeForOrganization(orgId);
	}
	
	/**
	 * @Description : this method is used for getting orgnization's org_type
	 * @param senderOrgId
	 * @return
	 */
	@Override
	public String getOrgTypeForOrganization(String senderOrgId) throws BNPApplicationException{
		return eippInvcUploadService.getOrgTypeForOrganization(senderOrgId);
	}
	
	/**
	 * This method validates whether BIll type, bill through is enabled with the given market place org id
	 */
	@Override
	public boolean isBillThroughMarketPlace(String billType, String marketPlaceOrgId) throws BNPApplicationException{
		return eippInvcUploadService.isBillThroughMarketPlace(billType, marketPlaceOrgId);
	}
	
	/**
	 * @Description : this method checks whether the buyer and seller linked to market place for that bill type
	 */
	@Override
	public boolean isBuyerSellerLinkedToMarketPlace(String custOrgId, String cntpOrgId,
			String billType, String marketPlaceOrgId) throws BNPApplicationException {
		return eippInvcUploadService.isBuyerSellerLinkedToMarketPlace(custOrgId, cntpOrgId, billType, marketPlaceOrgId);
	}
}
