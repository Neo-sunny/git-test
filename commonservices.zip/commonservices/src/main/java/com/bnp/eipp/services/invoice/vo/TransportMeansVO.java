package com.bnp.eipp.services.invoice.vo;

import java.io.Serializable;

public class TransportMeansVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String shipMode;

	public String getShipMode() {
		return shipMode;
	}

	public void setShipMode(String shipMode) {
		this.shipMode = shipMode;
	}
}
