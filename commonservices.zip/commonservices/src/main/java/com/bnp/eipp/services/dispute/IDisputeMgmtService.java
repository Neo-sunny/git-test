/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 22, 20121:11:33 PM
 * 
 * Purpose:      IDisputeMgmtService.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 22, 20121:11:33 PM        Oracle Financial Services Software Ltd                  Initial Version  
 * 14 May   2012		 		 Sandhya											    R2.1 UAT # 2240
 * 03 Aug 2012					 Reena S											    Rel 3.0 EIPP Phase II Release File Inq Changes
 * 06 Sep 2012          Reena S													Release 3.0             For getting Validation Failed Record details
 * 08-Nov-2012					Yashmika												UAT Bug Fix # 2916
 ************************************************************************************************************************************************************/

package com.bnp.eipp.services.dispute;

import java.util.List;

import com.bnp.eipp.services.invoice.vo.EippAuditVO;
import com.bnp.eipp.services.invoice.vo.EippCustFieldsVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.vo.admin.DisputeCodeVO;
import com.bnp.scm.services.common.vo.AttachmentVO;
import com.bnp.eipp.services.vo.dispute.DisputeAllocationMappingVO;
import com.bnp.eipp.services.vo.dispute.DisputeVO;
import com.bnp.scm.services.common.ITransactionService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

/**
 * The Interface IDisputeMgmtService.
 */
public interface IDisputeMgmtService extends ITransactionService {

	/**
	 * Insert invoice li dispute.
	 *
	 * @param disputeVO the dispute vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void insertInvoiceLIDispute(DisputeVO disputeVO)
			throws BNPApplicationException;

	/**
	 * Gets the dispute codes.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @return the dispute codes
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getDisputeCodes(EippInvoiceVO eippInvoiceVO)
			throws BNPApplicationException;

	/**
	 * Check existing dispute.
	 *
	 * @param dispCode the disp code
	 * @param invId the inv id
	 * @throws BNPApplicationException the bNP application exception
	 */
	void checkExistingDispute(long invId)
			throws BNPApplicationException;

	/**
	 * Insert inv disp attachment.
	 *
	 * @param attachmentVO the attachment vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void insertInvDispAttachment(AttachmentVO attachmentVO)
			throws BNPApplicationException;

	/**
	 * Insert invoice dispute.
	 *
	 * @param invDispute the inv dispute
	 * @throws BNPApplicationException the bNP application exception
	 */
	void insertInvoiceDispute(DisputeVO invDispute)
			throws BNPApplicationException;

	/**
	 * Insert invoice detail dispute.
	 *
	 * @param detailDispute the detail dispute
	 * @throws BNPApplicationException the bNP application exception
	 */
	void insertInvoiceDetailDispute(DisputeVO detailDispute)
			throws BNPApplicationException;

	/**
	 * Insert dispute allocation mapping.
	 *
	 * @param mappingVO the mapping vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void insertDisputeAllocationMapping(DisputeAllocationMappingVO mappingVO)
			throws BNPApplicationException;

	/**
	 * Reassign dispute.
	 *
	 * @param dispute the dispute
	 * @throws BNPApplicationException the bNP application exception
	 */
	void reassignDispute(DisputeVO dispute) throws BNPApplicationException;

	/**
	 * Accept disputes.
	 *
	 * @param invDispute the inv dispute
	 * @throws BNPApplicationException the bNP application exception
	 */
	void acceptDisputes(List<DisputeVO> invDispute)
			throws BNPApplicationException;

	/**
	 * Reject disputes.
	 *
	 * @param invDispute the inv dispute
	 * @throws BNPApplicationException the bNP application exception
	 */
	void rejectDisputes(List<DisputeVO> invDispute)
			throws BNPApplicationException;

	/**
	 * Approve dispute resolution.
	 *
	 * @param Dispute the dispute
	 * @throws BNPApplicationException the bNP application exception
	 */
	void approveDisputeResolution(List<DisputeVO> dispute)
			throws BNPApplicationException;

	/**
	 * Update dispute status.
	 *
	 * @param status the status
	 * @param disputeVO the dispute vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void updateDisputeStatus(String status, DisputeVO disputeVO)
			throws BNPApplicationException;

	/**
	 * Gets the dispute details.
	 *
	 * @param disputeVO the dispute vo
	 * @return the dispute details
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<DisputeVO> getDisputeDetails(DisputeVO disputeVO)
			throws BNPApplicationException;

	/**
	 * Update invoice status.
	 *
	 * @param status the status
	 * @param invoiceId the invoice id
	 * @throws BNPApplicationException the bNP application exception
	 */
	void updateInvoiceStatus(String status, long invoiceId)
			throws BNPApplicationException;

	/**
	 * Approve and send it to supplier.
	 *
	 * @param dispute the dispute
	 * @throws BNPApplicationException the bNP application exception
	 */
	void approveAndSendItToSupplier(List<DisputeVO> dispute)
			throws BNPApplicationException;

	/**
	 * This API checks whether approval is needed for providing resolution.
	 *
	 * @param orgId the org id
	 * @return true, if successful
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean checkForResolutionApproval(String orgId)
			throws BNPApplicationException;

	/**
	 * This API will be used for a buyer user to cancel the existing dispute.
	 *
	 * @param disputesList the disputes list
	 * @throws BNPApplicationException the bNP application exception
	 */
	void cancelDisputes(List<DisputeVO> disputesList)
			throws BNPApplicationException;

	/**
	 * This API checks whether a dispute allocation rule is available for the
	 * given buyer, supplier, dispute code and bill type.
	 *
	 * @param dispute the dispute
	 * @return true, if is dispute alloc rule available
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean isDisputeAllocRuleAvailable(DisputeVO dispute)
			throws BNPApplicationException;

	/**
	 * This API returns the details of the dispute.
	 *
	 * @param dispute the dispute
	 * @return the dispute detail
	 * @throws BNPApplicationException the bNP application exception
	 */
	DisputeVO getDisputeDetail(DisputeVO dispute)
			throws BNPApplicationException;

	/**
	 * This API Overrides the resolution provided for a dispute.
	 *
	 * @param disputeList the dispute list
	 * @throws BNPApplicationException the bNP application exception
	 */
	void overrideDisputes(List<DisputeVO> disputeList)
			throws BNPApplicationException;

	/**
	 * This API persists the reassigned dept or user details of a dispute.
	 *
	 * @param dispute the dispute
	 * @throws BNPApplicationException the bNP application exception
	 */
	void saveReassignmentDetails(DisputeVO dispute)
			throws BNPApplicationException;

	/**
	 * Returns the dispute resolution code available for the supplier org id.
	 *
	 * @param dispute the dispute
	 * @return the resolution code list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<DisputeCodeVO> getResolutionCodeList(DisputeVO dispute)
			throws BNPApplicationException;

	/**
	 * Returns the details of the invoice.
	 *
	 * @param invoiceId the invoice id
	 * @return the invoice detail
	 * @throws BNPApplicationException the bNP application exception
	 */
	EippInvoiceVO getInvoiceDetail(long invoiceId)
			throws BNPApplicationException;
	
	List<EippCustFieldsVO> getInvoiceCustFields(long invoiceId)
	throws BNPApplicationException;

	/**
	 * Gets the list of existing assignees for the dipute.
	 *
	 * @param dispute the dispute
	 * @return the existing assignees
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<DisputeAllocationMappingVO> getExistingAssignees(DisputeVO dispute)
			throws BNPApplicationException;

	/**
	 * Returns the list of buyer or supplier departments to whom the dispute can
	 * be reassigned.
	 *
	 * @param dispute the dispute
	 * @return the available departments
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<String> getAvailableDepartments(DisputeVO dispute)
			throws BNPApplicationException;

	/**
	 * Returns the available users to whom the dispute can be reassigned.
	 *
	 * @param dispute the dispute
	 * @return the available users
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<String> getAvailableUsers(DisputeVO dispute)
			throws BNPApplicationException;

	/**
	 * Returns the list of eipp suppliers available for the given user id.
	 *
	 * @param userId the user id
	 * @return the eipp supplier orgs
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getEippSupplierOrgs(String userId)
			throws BNPApplicationException;

	/**
	 * Returns List of EIPP buyers available for the user.
	 *
	 * @param userId the user id
	 * @return the eipp buyer orgs
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> getEippBuyerOrgs(String userId)
			throws BNPApplicationException;
	
	/**
	 * Gets the attachment details.
	 *
	 * @param dispute the dispute
	 * @return the attachment details
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<AttachmentVO> getAttachmentDetails(
			DisputeVO dispute) throws BNPApplicationException;
	
	/**
	 * Gets the invoice audit details.
	 *
	 * @param invId the inv id
	 * @return the invoice audit details
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippAuditVO> getInvoiceAuditDetails(
			long invId) throws BNPApplicationException;
	
	/**
	 * Gets the dispute status list.
	 *
	 * @return the dispute status list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<String> getDisputeStatusList() throws BNPApplicationException;
	
	/**
	 * Gets the dispute detail summary.
	 *
	 * @param invId the inv id
	 * @return the dispute detail summary
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<DisputeVO> getDisputeDetailSummary(long invId) throws BNPApplicationException;
	
	
	int getDisputeRaisedCountForFile(long fileId,String fileStatus)throws BNPApplicationException;
	
	int getDisputeResolvedCountForFile(long fileId,String fileStatus)throws BNPApplicationException;
	
	List<DisputeVO> getRaiseDisputeRecordDetails(long fileId,String fileStatus) throws BNPApplicationException;
	
	List<DisputeVO> getDisputeResolvedRecordDetails(long fileId,String fileStatus) throws BNPApplicationException;
	
}
