/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 22, 201211:50:13 PM
 * 
 * Purpose:      DisputeMgmtDaoImpl.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 22, 201211:50:13 PM        Oracle Financial Services Software Ltd                  Initial Version
 * 14 May   2012		 		  Sandhya											      R2.1 UAT # 2240
 * 03 Aug 2012					  Reena S								Release 3.0		  EIPP PhaseII-Release File Inq Changes
 * 06 Sep 2012                    Reena S								Release 3.0       For getting Validation Failed Record details	  
 * 08 Nov 2012 					  Reena S												  Added getPrevInvcStatusForCancel	  
 * 09-Nov-2012					  Yashmika												  UAT Bug Fix # 2916
************************************************************************************************************************************************************/

package com.bnp.eipp.services.dao.dispute;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.invoice.vo.EippCustFieldsVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.scm.services.common.vo.AttachmentVO;
import com.bnp.eipp.services.vo.dispute.DisputeAllocationMappingVO;
import com.bnp.eipp.services.vo.dispute.DisputeAuditVO;
import com.bnp.eipp.services.vo.dispute.DisputeCustFieldsVO;
import com.bnp.eipp.services.vo.dispute.DisputeVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.ibatis.sqlmap.client.SqlMapExecutor;
import com.ibatis.sqlmap.engine.execution.BatchException;

@Component
@SuppressWarnings("unchecked")
public class DisputeMgmtDaoImpl extends SqlMapClientWrapper implements IDisputeMgmtDao {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DisputeMgmtDaoImpl.class);
	
	public DisputeMgmtDaoImpl() {
		nameSpace = "DisputeMgmtNS";
	}

	@Override
	public void insertDisputeAllocationMapping(
			DisputeAllocationMappingVO mappingVO)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(
					getQueryNameWithNameSpace(INSERT_DISP_ALLOC_MAPPING), mappingVO);
			insertIntoAllocMappingHistory(mappingVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error while inserting dispute allocation mapping " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	private void insertIntoAllocMappingHistory(
			DisputeAllocationMappingVO mappingVO) throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(
					getQueryNameWithNameSpace(INSERT_DISP_ALLOC_MAPPING_HIST), mappingVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error while inserting dispute allocation mapping " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public void reassignDispute(DisputeVO dispute)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(
					getQueryNameWithNameSpace(REASSIGN_DISPUTE), dispute);
		} catch (DataAccessException e) {
			LOGGER.error("Error while reassigning invoice dispute " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		
	}

	@Override
	public void updateDisputeResolution(DisputeVO dispute)
			throws BNPApplicationException {
		String status = null;
		
		if (dispute.getDispStatus().equals(
				StatusConstants.DISPUTE_PENDING_ACCEPTANCE)) {
			status = StatusConstants.DISPUTE_ACCEPTED;
		} else {
			status = StatusConstants.DISPUTE_REJECTED;
		}
		
		if (isDisputeAtInvoiceLevel(dispute)) {
			approveDisputeResolution(dispute, status, APPROVE_INV_DISP_RESOLUTION);
			insertInvoiceDisputeHistory(dispute.getDisputeId());
		} else {
			approveDisputeResolution(dispute, status, APPROVE_INV_DET_DISP_RESOLUTION);
			insertInvoiceDetDisputeHistory(dispute.getDisputeId());
		}
	}
	
	private Map<String, Object> populateResolutionParams(
			DisputeVO dispute, String status) {
		Map<String, Object> params = new HashMap<String, Object>();
		
		params.put("dispute", dispute);
		params.put("status", status);
		
		return params;
	}
	
	private void approveDisputeResolution(
			DisputeVO dispute, String status, String queryName) throws BNPApplicationException {
		
		Map<String, Object> params = populateResolutionParams(dispute, status);
		
		try {
			getSqlMapClientTemplate().update(
					getQueryNameWithNameSpace(queryName), params);
		} catch (DataAccessException e) {
			LOGGER.error("Error while approving invoice dispute " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public void approveInvoiceDispute(DisputeVO invDispute)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().update(
					getQueryNameWithNameSpace(APPROVE_INV_DISPUTE), invDispute);
		} catch (DataAccessException e) {
			LOGGER.error("Error while approving invoice dispute " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public void approveInvDetDispute(DisputeVO detailDispute)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().update(
					getQueryNameWithNameSpace(APPROVE_INV_DET_DISPUTE), detailDispute);
		} catch (DataAccessException e) {
			LOGGER.error("Error while approving invoice detail dispute " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}		
	}

	private Map<String, Object> populateParams(String status, String dispRefNo) {
		Map<String, Object> params = new HashMap<String, Object>();
		
		params.put("status", status);
		params.put("dispRefNo", dispRefNo);
		
		return params;
	}
	
	public void updateDisputeStatus(String status, DisputeVO disputeVO)
		throws BNPApplicationException {
		if (isDisputeAtInvoiceLevel(disputeVO)) {
			updateDisputeStatus(status, 
					disputeVO.getDispRefNo(), UPDATE_INV_DISPUTE_STATUS);
			insertInvoiceDisputeHistory(disputeVO.getDisputeId());
		} else {
			updateDisputeStatus(status, 
					disputeVO.getDispRefNo(), UPDATE_INV_DET_DISPUTE_STATUS);
			insertInvoiceDetDisputeHistory(disputeVO.getDisputeId());
		}
	}
	

	private void updateDisputeStatus(String status, 
			String dispRefNo, String queryName)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().update(
					getQueryNameWithNameSpace(queryName), 
					populateParams(status, dispRefNo));
		} catch (DataAccessException e) {
			LOGGER.error("Error while updating invoice dispute status" + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}		
	}
	
	@Override
	public List<DisputeVO> getDisputeDetails(DisputeVO disputeVO)
			throws BNPApplicationException {
		List<DisputeVO> disputesList = null;
		
		if (isBuyerUser(disputeVO.getUserType())) {
			disputesList = getDisputeSummary(disputeVO, GET_DISPUTE_SUMMARY_FOR_BUYER);
		} else if (isSupplierUser(disputeVO.getUserType())) {
			disputesList = getDisputeSummary(disputeVO, GET_DISPUTE_SUMMARY_FOR_SUPPLIER);
		}
		return disputesList;
	}
	
	private List<DisputeVO> getDisputeSummary(DisputeVO disputeVO, String queryName) 
				throws BNPApplicationException {
		try {
			return getSqlMapClientTemplate().queryForList(
					getQueryNameWithNameSpace(queryName), 
					disputeVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error while updating invoice dispute status" + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	private Map<String, Object> getParams(String status, long invoiceId) {
		Map<String, Object> params = new HashMap<String, Object>();
		
		params.put("status", status);
		params.put("invoiceId", invoiceId);
		
		return params;
	}

	@Override
	public Timestamp updateInvoiceStatus(String status, long invoiceId)
			throws BNPApplicationException {
		Timestamp timeStamp = null;
		try {
			Map<String, Object> params = getParams(status, invoiceId);
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_INV_STATUS), params);
			timeStamp = (Timestamp)getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_TIME_STAMP), invoiceId);
		} catch (DataAccessException e) {
			LOGGER.error("Error while updating invoice status" + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		return timeStamp;
	}
	
	@Override
	public boolean checkForResolutionApproval (
			String orgId) throws BNPApplicationException {
		String approvalReqd = null;
		try {
			approvalReqd = (String) getSqlMapClientTemplate().queryForObject(
					getQueryNameWithNameSpace(CHECK_FOR_RESOLUTION_APPROVAL), orgId);
		} catch (DataAccessException e) {
			LOGGER.error("Error while checking resolution approval" + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		return approvalReqd == null ? true : approvalReqd.equalsIgnoreCase("Y"); 
	}
	
	public int updateTxnTimestamp(
			Object object) throws BNPApplicationException {
		
		List<DisputeVO> disputeList = null;
		int count = 0;
		if (object instanceof List) {
			disputeList = (List<DisputeVO>) object;
			
			try {
				for (DisputeVO disputeVO : disputeList) {
					if (disputeVO.getDisputedAt().equals(
							StatusConstants.DISPUTED_AT_INVOICE_LEVEL)) {
						count = super.updateTxnTimestamp(disputeVO);
					} else {
						count = getSqlMapClientTemplate().update(
								getQueryNameWithNameSpace(UPDATE_DET_DISP_TIMESTAMP), disputeVO);
					}
				}
			} catch (DataAccessException e) {
				LOGGER.error("Error while updating txn timestamp" + e);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
		}
		return count;
	}
	
	public void resetProcessingFlag(Object txnObj)
			throws BNPApplicationException {
		
		try {
			List<DisputeVO> disputeList = null;
			if (txnObj instanceof List) {
					disputeList = (List<DisputeVO>) txnObj;
					for (DisputeVO disputeVO : disputeList) {
						if (isDisputeAtInvoiceLevel(disputeVO)) {
							super.resetProcessingFlag(disputeVO);
						} else {
							getSqlMapClientTemplate().update(
									getQueryNameWithNameSpace(RESET_DET_DISP_FLAG), disputeVO);
						}
					}
				}
			} catch (DataAccessException e) {
				LOGGER.error("Error while resetting process flag" + e);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
		}

	@Override
	public void cancelDispute(DisputeVO disputeVO)
			throws BNPApplicationException {
		String status = StatusConstants.DISPUTE_CANCELLED;
		Map<String, Object> params = new HashMap<String, Object>();
		
		params.put("status", status);
		params.put("dispRefNo", disputeVO.getDispRefNo());
		params.put("userId", disputeVO.getCurrentUserId());
		
		try {
			if (isDisputeAtInvoiceLevel(disputeVO)) {
				getSqlMapClientTemplate().update(getQueryNameWithNameSpace(CANCEL_INV_DISPUTE), params);
				insertInvoiceDisputeHistory(disputeVO.getDisputeId());
			} else {
				getSqlMapClientTemplate().update(getQueryNameWithNameSpace(CANCEL_INV_DET_DISPUTE), params);
				insertInvoiceDetDisputeHistory(disputeVO.getDisputeId());
			}
		} catch (DataAccessException e) {
			LOGGER.error("Error while cancelling dispute" + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		}
	}
	
	private boolean isDisputeAtInvoiceLevel(DisputeVO dispute) {
		if (dispute.getDisputedAt().equals(
				StatusConstants.DISPUTED_AT_INVOICE_LEVEL)) {
			return true;
		}
		return false;
	}

	private Map<String, Object> getParams(DisputeVO dispute) {
		Map<String, Object> params = new HashMap<String, Object>();
		
		params.put("invoiceId", dispute.getEippInvoice().getInvId());
		params.put("dispRefNo", dispute.getDispRefNo());
		params.put("billType", dispute.getBillType());
		params.put("supplierOrgId", dispute.getEippInvoice().getSupplierOrgId());
		params.put("buyerOrgId", dispute.getEippInvoice().getBuyerOrgId());
		params.put("disputeCode", dispute.getDispReasonCode());
		
		return params;
	}

	@Override
	public void populateDisputeAllocMapping(DisputeVO dispute)
			throws BNPApplicationException {
		Map<String, Object> params = getParams(dispute);
		
		try {
			getSqlMapClientTemplate().update(
					getQueryNameWithNameSpace(CALL_DISP_ALLOC_PROC), params);
		} catch (DataAccessException e) {
			LOGGER.error("Error while populating alloc rule mapping " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);			
		}
	}

	@Override
	public void acceptDispute(String status, DisputeVO dispute)
			throws BNPApplicationException {
		Map<String, Object> params = new HashMap<String, Object>();
		
		params.put("status", status);
		params.put("dispute", dispute);
		
		try {
			if (isDisputeAtInvoiceLevel(dispute)) {
				getSqlMapClientTemplate().update(
						getQueryNameWithNameSpace(ACCEPT_INV_DISPUTE), params);
				insertInvoiceDisputeHistory(dispute.getDisputeId());
				saveInvoiceAttachment(dispute);
			} else {
				getSqlMapClientTemplate().update(
						getQueryNameWithNameSpace(ACCEPT_INV_DET_DISPUTE), params);
				insertInvoiceDetDisputeHistory(dispute.getDisputeId());
				saveInvoiceDetailAttachment(dispute);
			}
		} catch (DataAccessException e) {
			LOGGER.error("Error while accepting dispute " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);			
		}
	}
	
	private void saveInvoiceAttachment(DisputeVO dispute)
			throws BNPApplicationException {
		saveAttachments(SAVE_INV_DISP_ATTACHMENT, dispute);
	}
	
	private void saveAttachments(final String queryName, DisputeVO dispute) 
			throws BNPApplicationException {
		final List<AttachmentVO> attachments = dispute.getSupplierAttachments();
		
		try {
			if (!attachments.isEmpty()) {
				getSqlMapClientTemplate().execute(new SqlMapClientCallback<List<Object>>() {
					public List<Object> doInSqlMapClient(SqlMapExecutor executor)
							throws SQLException {
						List<Object> list = null;

						try {
							executor.startBatch();
							for (AttachmentVO attachmentVO : attachments) {
									getSqlMapClientTemplate().insert(
										getQueryNameWithNameSpace(queryName), attachmentVO);					
							}
							list = executor.executeBatchDetailed();
						} catch (BatchException e) {							
							LOGGER.error("Uploading the invoiceLineItem details in a batch failed");
							throw new SQLException(e.getMessage());
						}
						return list;
					}
				});
			}
		} catch (DataAccessException e) {
			LOGGER.error("Error while saving invoice attachment " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	private void saveInvoiceDetailAttachment(DisputeVO dispute)
			throws BNPApplicationException {
		saveAttachments(SAVE_INV_DET_DISP_ATTACHMENT, dispute);
	}
	
	public void rejectDispute(String status, DisputeVO dispute)
			throws BNPApplicationException {
		Map<String, Object> params = new HashMap<String, Object>();
		
		params.put("status", status);
		params.put("dispute", dispute);
		
		try {
			if (isDisputeAtInvoiceLevel(dispute)) {
				getSqlMapClientTemplate().update(
						getQueryNameWithNameSpace(REJECT_INV_DISPUTE), params);
				insertInvoiceDisputeHistory(dispute.getDisputeId());
				saveInvoiceAttachment(dispute);
			} else {
				getSqlMapClientTemplate().update(
						getQueryNameWithNameSpace(REJECT_INV_DET_DISPUTE), params);
				insertInvoiceDetDisputeHistory(dispute.getDisputeId());
				saveInvoiceDetailAttachment(dispute);
			}
		} catch (DataAccessException e) {
			LOGGER.error("Error while rejecting dispute" + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);			
		}
	}
	
	public void insertInvoiceDisputeHistory(long disputeId) 
					throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(
					getQueryNameWithNameSpace(INSERT_INV_DISP_HIST), disputeId);
		} catch (DataAccessException e) {
			LOGGER.error("Error while inserting invoice dispute hist" + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);			
		}
	}
	
	public void insertInvoiceDetDisputeHistory(long disputeId) 
					throws BNPApplicationException {
		try {
		getSqlMapClientTemplate().insert(
			getQueryNameWithNameSpace(INSERT_INV_DET_DISP_HIST), disputeId);
		} catch (DataAccessException e) {
			LOGGER.error("Error while inserting invoice det dispute hist" + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);			
		}
	}

	@Override
	public boolean isDisputeAllocRuleAvailable(DisputeVO dispute)
			throws BNPApplicationException {
		Integer count = null;
		try {
			count = (Integer) getSqlMapClientTemplate().queryForObject(
				getQueryNameWithNameSpace(IS_ALL0C_RULE_AVAILABLE), dispute);
		} catch (DataAccessException e) {
			LOGGER.error("Error while checking for alloc rule " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);			
		}
		return count == null ? false : count > 0;
	}

	@Override
	public DisputeVO getDisputeDetail(DisputeVO dispute)
			throws BNPApplicationException {
		try {
			if (isDisputeAtInvoiceLevel(dispute)) {
				dispute = (DisputeVO) getSqlMapClientTemplate().queryForObject(
						getQueryNameWithNameSpace(GET_INV_DISPUTE_DETAILS), dispute);
				populateCustFieldsForDispute(dispute, GET_INV_CUST_FIELDS);
			} else {
				dispute = (DisputeVO) getSqlMapClientTemplate().queryForObject(
						getQueryNameWithNameSpace(GET_INV_DET_DISPUTE_DETAILS), dispute);
				populateCustFieldsForDispute(dispute, GET_LN_ITM_CUST_FIELDS);
				populateLineItemDetails(dispute);
			}
			
			if (dispute.getAttachmentCount() > 0) {
				populateAttachmentDetailsForDispute(dispute);
			}
			
		} catch (DataAccessException e) {
			LOGGER.error("Error while getting dispute details : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);			
		}
		return dispute;
	}
	
	private void populateLineItemDetails(
			DisputeVO dispute) throws BNPApplicationException {
		List<EippInvCntLineItemVO> lineItemList = null;
		try {
			lineItemList = getSqlMapClientTemplate().queryForList(
					getQueryNameWithNameSpace(POPULATE_LN_ITEM_DETAILS), dispute.getDisputeId());
			dispute.getEippInvoice().setLineItemList(lineItemList);
		} catch (DataAccessException e) {
			LOGGER.error("Error while getting dispute details : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);			
		}
	}
	
	private void populateCustFieldsForDispute(
			DisputeVO dispute, String queryName) throws BNPApplicationException {
		List<DisputeCustFieldsVO> custFields = null;
		try {
			custFields = (List<DisputeCustFieldsVO>)getSqlMapClientTemplate().queryForList(
					getQueryNameWithNameSpace(queryName), dispute.getDisputeId());
			dispute.setCustFieldsList(custFields);
		} catch (DataAccessException e) {
			LOGGER.error("Error while populating custom fields " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);	
		}
	}
	
	private void populateAttachmentDetailsForDispute(
			DisputeVO dispute) throws BNPApplicationException {
		List<AttachmentVO> attachments = null;
		try {
			if (isDisputeAtInvoiceLevel(dispute)) {
				attachments = (List<AttachmentVO>)getSqlMapClientTemplate().queryForList(
						getQueryNameWithNameSpace(GET_INV_DISP_ATTACH_DETAILS), dispute.getDisputeId());
			} else {
				attachments = (List<AttachmentVO>) getSqlMapClientTemplate().queryForList(
						getQueryNameWithNameSpace(GET_INV_DET_DISP_ATTACH_DETAILS), dispute.getDisputeId());
			}
			dispute.setAttachments(attachments);
		} catch (DataAccessException e) {
			LOGGER.error("Error while populating attachments " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);			
		}
	}

	@Override
	public void overrideInvDispute(DisputeVO dispute)
			throws BNPApplicationException {
		try {
//			if (isDisputeAllocRuleAvailable(dispute)) {
				getSqlMapClientTemplate().update(
						getQueryNameWithNameSpace(OVERRIDE_INV_DISPUTE), dispute);
				saveAttachments(SAVE_INV_DISP_ATTACHMENT, dispute);
//			}
		} catch (DataAccessException e) {
			LOGGER.error("Error while override inv dispute " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);			
		}
	}

	@Override
	public void overrideInvDetDispute(DisputeVO dispute)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().update(
					getQueryNameWithNameSpace(OVERRIDE_INV_DET_DISPUTE), dispute);
			saveAttachments(SAVE_INV_DISP_ATTACHMENT, dispute);
		} catch (DataAccessException e) {
			LOGGER.error("Error while override inv detail dispute " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);			
		}
	}

	@Override
	public void updateDisputeAllocMapping(DisputeVO dispute)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().update(
					getQueryNameWithNameSpace(UPDATE_DISP_ALLOC_MAPPING), dispute);
		} catch (DataAccessException e) {
			LOGGER.error("Error while updating disp alloc mapping " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);			
		}
	}

	@Override
	public List<DisputeAllocationMappingVO> getExistingAssignees(
			DisputeVO dispute) throws BNPApplicationException {
		Map<String, Object> params = new HashMap<String, Object>();
		
		params.put("dispRefNo", dispute.getDispRefNo());
		
		if (isBuyerUser(dispute.getUserType())) {
			params.put("orgRole", StatusConstants.BUYER);
		} else if (isSupplierUser(dispute.getUserType())) {
			params.put("orgRole", StatusConstants.SELLER);
		}
		 
		try {
			return (List<DisputeAllocationMappingVO>)
				getSqlMapClientTemplate().queryForList(
					getQueryNameWithNameSpace(GET_EXISTING_ASSIGNEES), params);
		} catch (DataAccessException e) {
			LOGGER.error("Error while updating disp alloc mapping " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);			
		}
	}
	
	public List<String> getAvailableDepartments (
			DisputeVO dispute) throws BNPApplicationException {
		
		try {
			return (List<String>)
				getSqlMapClientTemplate().queryForList(
					getQueryNameWithNameSpace(GET_AVAILABLE_DEPTS), getDeptParams(dispute));
		} catch (DataAccessException e) {
			LOGGER.error("Error while getting available departments " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);			
		}
	}
	
	private Map<String, Object> getDeptParams(DisputeVO dispute) {
		Map<String, Object> params = new HashMap<String, Object>();
		
		String orgId = null;
		if (isBuyerUser(dispute.getUserType())) {
			orgId = dispute.getEippInvoice().getBuyerOrgId();
			params.put("orgRole", StatusConstants.BUYER);
		} else if (isSupplierUser(dispute.getUserType())) {
			orgId = dispute.getEippInvoice().getSupplierOrgId();
			params.put("orgRole", StatusConstants.SELLER);
		}
		
		params.put("orgId", orgId);
		params.put("currentUserId", dispute.getCurrentUserId());
		params.put("dispRefNo", dispute.getDispRefNo());
		
		return params;
	}
	
	public List<String> getAvailableUsers (
			DisputeVO dispute) throws BNPApplicationException {
		try {
			return (List<String>)
				getSqlMapClientTemplate().queryForList(
					getQueryNameWithNameSpace(GET_AVAILABLE_USERS), getDeptParams(dispute));
		} catch (DataAccessException e) {
			LOGGER.error("Error while getting available users " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);			
		}
	}

	@Override
	public void insertDisputeAllocationMapping(
			final List<DisputeAllocationMappingVO> mappingList)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().execute(new SqlMapClientCallback<List<Object>>() {
				public List<Object> doInSqlMapClient(SqlMapExecutor executor)
						throws SQLException {
					List<Object> list = null;

					try {
						executor.startBatch();
						for (DisputeAllocationMappingVO mappingVO : mappingList) {
							executor.insert(getQueryNameWithNameSpace(INSERT_DISP_ALLOC_MAPPING), mappingVO);
							executor.insert(getQueryNameWithNameSpace(INSERT_DISP_ALLOC_MAPPING_HIST), mappingVO);
						}
						list = executor.executeBatchDetailed();
					} catch (BatchException e) {							
						LOGGER.error("Uploading the invoiceLineItem details in a batch failed");
						throw new SQLException(e.getMessage());
					}
					return list;
				}
			});
	
		} catch (DataAccessException e) {
			LOGGER.error("Error while getting dept id list " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);			
		}
	}

	@Override
	public List<Integer> getDeptIdList(DisputeVO dispute)
				throws BNPApplicationException {
		Map<String, Object> params = new HashMap<String, Object>();
		try {
			params.put("deptIdList", dispute.getApproverDepts());
			
			if (isBuyerUser(dispute.getUserType())) {
				params.put("orgId", dispute.getEippInvoice().getBuyerOrgId());	
			} else if (isSupplierUser(dispute.getUserType())){
				params.put("orgId", dispute.getEippInvoice().getSupplierOrgId());
			}
			return getSqlMapClientTemplate().queryForList(
					getQueryNameWithNameSpace(GET_DEPT_ID_LIST), params);
		} catch (DataAccessException e) {
			LOGGER.error("Error while getting dept id list " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);			
		}
	}
	
	/*Raise Dispute - Department Approval Flow - Starts*/

		@Override
		public void insertInvoiceDispute(DisputeVO disputeVO)
				throws BNPApplicationException {
			try {
				disputeVO.setDispRefNo(getDisputeRefNumber());
				getSqlMapClientTemplate().insert(
					getQueryNameWithNameSpace(INSERT_INVOICE_DISPUTE), disputeVO);
				getSqlMapClientTemplate().insert(
						getQueryNameWithNameSpace(INSERT_INVOICE_DISPUTE_HIST), disputeVO);
				insertDispAttachments(disputeVO,true);
				updateInvoiceStatus(StatusConstants.DISPUTED,disputeVO.getEippInvoice().getInvId());
				updateInvoiceLIWithInvIDStatus(StatusConstants.DISPUTED,disputeVO.getEippInvoice().getInvId());
			} catch (DataAccessException e) {
				LOGGER.error("Error while inserting invoice dispute " + e);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
		}
		
		public void batchInsertAllocMap(final DisputeVO disputeVO) throws BNPApplicationException{
			List<String> _params = null;
			try{
				if(disputeVO.getEippInvoice().getDeptAllocMap().getApprovalLevel().equals(BNPConstants.DEPT_ALLOC_TYPE_INVOICE)){
					_params  = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_DEPT_ID),disputeVO);
				}else{
					_params = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_DEPT_ID_FOR_LI),disputeVO);
				}
			}catch(DataAccessException e){
				throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
			}
			final List<String> params = _params; 
			 getSqlMapClientTemplate().execute(
						new SqlMapClientCallback<List<Object>>() {
							@Override
							public List<Object> doInSqlMapClient(SqlMapExecutor executor)
									throws SQLException {
								List<Object> list =null;
								try {
									executor.startBatch();
									for (String deptId : params) {
										disputeVO.setDeptId(deptId);
										executor.insert(getQueryNameWithNameSpace(INSERT_INVOICE_DISPUTE_IN_ALLOC_MAP), disputeVO);
									}
									list = executor.executeBatchDetailed();
									// R7.0 Fortify issues
//									if (list != null) {
//										LOGGER.debug("Batch Result Size" + list.size());
//									}

								} catch (BatchException e) {
									LOGGER.error("Excecuting batch insert in invoice items mapping Failed "+ e.getMessage());
									throw new SQLException();
								}
								return list;
							}
						});
		}
		
		@Override
		public void insertDisuteInAllocMap(DisputeVO disputeVO)
				throws BNPApplicationException {
			try {
				getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_INVOICE_DISPUTE_IN_ALLOC_MAP), disputeVO);
			}catch (DataAccessException e) {
				LOGGER.error("Error while inserting invoice dispute in alloc table" + e);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
		}
		
		@Override
		public List<Long> insertInvoiceLIDispute(DisputeVO disputeVO)
				throws BNPApplicationException {
			Set<Long> lineItmList = null;
			try {
				disputeVO.setDispRefNo(getDisputeRefNumber());
				getSqlMapClientTemplate().insert(
					getQueryNameWithNameSpace(INSERT_LINEITM_DISPUTE), disputeVO);
				getSqlMapClientTemplate().insert(
						getQueryNameWithNameSpace(INSERT_LINEITM_DISPUTE_HIST), disputeVO);
				insertDispAttachments(disputeVO, false);
				lineItmList = insertDispCustomFields(disputeVO);
				insertDispLineItmMapping(lineItmList, disputeVO.getDisputeId());
				updateInvoiceStatus(StatusConstants.DISPUTED, disputeVO.getEippInvoice().getInvId());
				updateInvoiceLIStatus(lineItmList,StatusConstants.DISPUTED);
			} catch (DataAccessException e) {
				LOGGER.error("Error while inserting invoice line item dispute " + e);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
			return new ArrayList<Long>(lineItmList);
		}
		
		private void updateInvoiceLIStatus(Set<Long> lineItemIds, String status)
				throws BNPApplicationException {
			try {
				Map<String, Object> params = new HashMap<String, Object>();
				List<Long> _lineItemList = new ArrayList<Long>(lineItemIds);
				
				params.put("status", status);
				params.put("lineItemIds", _lineItemList);
				
				getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_INV_LI_STATUS), params);
			} catch (DataAccessException e) {
				LOGGER.error("Error while updating invoice status" + e);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
		}
		
		private void updateInvoiceLIWithInvIDStatus(String status, long invoiceId)
		throws BNPApplicationException {
			try {
				Map<String, Object> params = getParams(status, invoiceId);
				getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_LI_STATUS_WITH_INVID), params);
			} catch (DataAccessException e) {
				LOGGER.error("Error while updating invoice status" + e);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
		}
		
		
		private void insertDispLineItmMapping(final Set<Long> lineItmList,final long dispId) {
			final Map<String,Long> params= new HashMap<String,Long>();
			params.put("dispId", dispId);
			 getSqlMapClientTemplate().execute(
						new SqlMapClientCallback<List<Object>>() {
							@Override
							public List<Object> doInSqlMapClient(SqlMapExecutor executor)
									throws SQLException {
								List<Object> list =null;
								try {
									executor.startBatch();
									for (Long lineItmId : lineItmList) {
										params.put("lineItmId", lineItmId);
										executor.insert(getQueryNameWithNameSpace(INSERT_DISP_LINEITM_MAPPING), params);
									}
									list = executor.executeBatchDetailed();
									// R7.0 Fortify issues
//									if (list != null) {
//										LOGGER.debug("Batch Result Size" + list.size());
//									}

								} catch (BatchException e) {
									LOGGER.error("Excecuting batch insert in invoice items mapping Failed "+ e.getMessage());
									throw new SQLException();
								}
								return list;
							}
						});
		}
		
		private Set<Long> insertDispCustomFields(final DisputeVO disputeVO) 
		throws BNPApplicationException {
			final Set<Long> lineItmSet = new HashSet<Long>();
			 getSqlMapClientTemplate().execute(
						new SqlMapClientCallback<List<Object>>() {
							@Override
							public List<Object> doInSqlMapClient(SqlMapExecutor executor)
									throws SQLException {
								List<Object> list =null;
								try {
									executor.startBatch();
									for (DisputeCustFieldsVO disputeCustFieldsVO : disputeVO.getCustFieldsList()) {
										disputeCustFieldsVO.setDispId(disputeVO.getDisputeId());
										executor.insert(getQueryNameWithNameSpace(INSERT_DISPUTE_CUST_FIELDS), disputeCustFieldsVO);
										lineItmSet.add(disputeCustFieldsVO.getFkId());
									}
									list = executor.executeBatchDetailed();
									// R7.0 Fortify issues
//									if (list != null) {
//										LOGGER.debug("Batch Result Size" + list.size());
//									}

								} catch (BatchException e) {
									LOGGER.error("Excecuting batch insert in invoice dispute custom fields Failed "+ e.getMessage());
									throw new SQLException();
								}
								return list;
							}
						});
			return lineItmSet;
		}
		private String getDisputeRefNumber() throws BNPApplicationException {
			try {
				return (String) getSqlMapClientTemplate().queryForObject(
					getQueryNameWithNameSpace(GET_DISPUTE_REFERENCE));
			} catch (DataAccessException e) {
				LOGGER.error("Error while getting dispute reference number " + e);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
		}

		private void insertDispAttachments(final DisputeVO disputeVO,final boolean isInvoice)
				throws BNPApplicationException {
			 getSqlMapClientTemplate().execute(
						new SqlMapClientCallback<List<Object>>() {
							@Override
							public List<Object> doInSqlMapClient(SqlMapExecutor executor)
									throws SQLException {
								List<Object> list =null;
								try {
									executor.startBatch();
									for (AttachmentVO dispAttachmentVO : disputeVO.getAttachments()) {
										dispAttachmentVO.setRefId(disputeVO.getDisputeId());
										dispAttachmentVO.setUploadedBy(disputeVO.getRaisedBy());
										dispAttachmentVO.setUploadedDate(disputeVO.getRaisedDate());
										if (isInvoice) {
											executor.insert(getQueryNameWithNameSpace(SAVE_INV_DISP_ATTACHMENT), dispAttachmentVO);
										} else {
											executor.insert(getQueryNameWithNameSpace(SAVE_INV_DET_DISP_ATTACHMENT), dispAttachmentVO);
										}
									}
									list = executor.executeBatchDetailed();
									// R7.0 Fortify issues
//									if (list != null) {
//										LOGGER.debug("Batch Result Size" + list.size());
//									}

								} catch (BatchException e) {
									LOGGER.error("Excecuting batch insert in invoice dispute attachment Failed "+ e.getMessage());
									throw new SQLException();
								}
								return list;
							}
						});
		}
		@Override
		public void insertInvoiceDetailDispute(DisputeVO disputeVO)
				throws BNPApplicationException {
			try {
				getSqlMapClientTemplate().insert(
						getQueryNameWithNameSpace(INSERT_LN_ITM_DISPUTE), disputeVO);
			} catch (DataAccessException e) {
				LOGGER.error("Error while inserting invoice detail dispute " + e);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
		}
		
		@Override
		public List<NameValueVO> getDisputeCodes(EippInvoiceVO eippInvoiceVO)
		throws BNPApplicationException {
			try {
				return getSqlMapClientTemplate().queryForList(
					getQueryNameWithNameSpace(GET_DISPUTE_CODES), eippInvoiceVO);
			} catch (DataAccessException e) {
				LOGGER.error("Error while getting dispute codes " + e);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
		}
		
		@Override
		public void checkExistingDispute(long invId)
		throws BNPApplicationException {
			int count =0;
			Map<String,Object> params = new HashMap<String,Object>();
			params.put("invId", invId);
			try {
				count = (Integer) getSqlMapClientTemplate().queryForObject(
					getQueryNameWithNameSpace(GET_EXISTING_DISPUTE), params);
				if (count > 0) {
					throw new DBException(ErrorConstants.DISPUTE_ALREADY_RAISED);
				}
			} catch (DataAccessException e) {
				LOGGER.error("Error while checking dispute code " + e);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
		}
		
		@Override
		public void insertInvDispAttachment(AttachmentVO attachmentVO)
		throws BNPApplicationException {
			try {
				getSqlMapClientTemplate().insert(
						getQueryNameWithNameSpace(SAVE_INV_DISP_ATTACHMENT), attachmentVO);

			} catch (DataAccessException e) {
				LOGGER.error("Error while inserting invoice dispute attachment" + e);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}

		}
		/*Raise Dispute - Department Approval Flow - Ends*/

		@Override
		public List<AttachmentVO> getAttachmentDetails(DisputeVO dispute)
				throws BNPApplicationException {
			
			String queryName = null;
			
			try {
				if (isDisputeAtInvoiceLevel(dispute)) {
					queryName = GET_INV_DISPUTE_ATTACH_DETAILS;
				} else {
					queryName = GET_INV_DET_DISPUTE_ATTACH_DETAILS;
				}
				return getSqlMapClientTemplate().queryForList(
						getQueryNameWithNameSpace(queryName), dispute);
			} catch (DataAccessException e) {
				LOGGER.error("Error while fetching attachment details " + e);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
		}

		@Override
		public List<DisputeVO> getDisputeDetailSummary(long invId)
				throws BNPApplicationException {
			List<DisputeVO> result= null;
			try{
				result = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_DISPUTE_DETAILS), invId);
			}catch(DataAccessException e){
				LOGGER.error("Exception while getting new deptIds-- DepartmentApprovalDao---------------",e);
				throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
			}
			return result;
		}
		
		@Override
		public boolean isBuyercentricModel(String orgId)
				throws BNPApplicationException {
			String model = null;
			try {
				model = (String) getSqlMapClientTemplate().queryForObject(
						getQueryNameWithNameSpace(IS_BUYER_CENTRIC_MODEL), orgId);
			} catch (DataAccessException e) {
				LOGGER.error("Error while checking for org model " + e);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
			
			if (model == null) {
				throw new BNPApplicationException(ErrorConstants.INVALID_ORG_MODEL);
			}
			
			return model.equals(StatusConstants.BUYER); 
		}

		@Override
		public List<Long> getDisputedLineItems(String dispRefNo)
				throws BNPApplicationException {
			try {
				return (List<Long>) getSqlMapClientTemplate().queryForList(
						getQueryNameWithNameSpace(GET_DISPUTED_LN_ITEMS), dispRefNo);
			} catch (DataAccessException e) {
				LOGGER.error("Error while getting line items for dispute" + e);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
		}

		@Override
		public List<DisputeCustFieldsVO> getLineItemDispFields(String dispRefNo)
				throws BNPApplicationException {
			try {
				return (List<DisputeCustFieldsVO>) getSqlMapClientTemplate().queryForList(
						getQueryNameWithNameSpace(GET_LN_ITM_DISP_FIELDS), dispRefNo);
			} catch (DataAccessException e) {
				LOGGER.error("Error while getting line item dispute fields " + e);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
		}
		
		
		public void insertDisputeAudit(DisputeAuditVO disputeAudit) 
			throws BNPApplicationException {
			try {
				getSqlMapClientTemplate().insert(
						getQueryNameWithNameSpace(INSERT_DISPUTE_AUDIT), disputeAudit);
			} catch (DataAccessException e) {
				LOGGER.error("Error while inserting dispute audit : " + e);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
		}

		@Override
		public List<Long> getDeptIdForSupplier(DisputeVO disputeVO)
				throws BNPApplicationException {
			try {
				return getSqlMapClientTemplate().queryForList(
						getQueryNameWithNameSpace(GET_DEPT_ID_FROM_DISP), disputeVO);
			} catch (DataAccessException e) {
				LOGGER.error("Error while getting dept ids from dispute department allocation " + e);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
		}

		@Override
		public int getDisputeRaisedCountForFile(NameValueVO params)throws BNPApplicationException {
			try {
				if (StatusConstants.VALIDATION_FAILED.equalsIgnoreCase(params.getParam1())) {
					params.setParam1(StatusConstants.DELETE);
				}	
				return (Integer) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_DISPUTE_COUNT_FORFILE), params);
			} catch (DataAccessException ex) {
				LOGGER.error("Error while getting Dispute count " + ex);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
			
		}

		@Override
		public int getDisputeResolvedCountForFile(NameValueVO params)throws BNPApplicationException {
			try {
				if (StatusConstants.VALIDATION_FAILED.equalsIgnoreCase(params.getParam1())) {
					params.setParam1(StatusConstants.DELETE);
				}	
				return (Integer) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_DISPUTE_RESOLN_COUNT_FORFILE), params);
			} catch (DataAccessException ex) {
				LOGGER.error("Error while getting Dispute Resolution count " + ex);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
		}

		@Override
		public List<DisputeVO> getRaiseDisputeRecordDetails(NameValueVO params)throws BNPApplicationException {
			List<DisputeVO> dispList=null;
			try {
				if (StatusConstants.VALIDATION_FAILED.equalsIgnoreCase(params.getParam1())) {
					params.setParam1(StatusConstants.DELETE);
				}			
				dispList=getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_DISPUTE_RECORD_DETAILS), params);
			
			} catch (DataAccessException ex) {
				LOGGER.error("Error while getting RaiseDisputeRecordDetails " + ex);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
			
			return dispList; 
		}
		
		public List<EippCustFieldsVO> getInvoiceCustFields(long invId) throws BNPApplicationException {
			List<EippCustFieldsVO> resultList= null;
			try{
				resultList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(FETCH_CUSTOM_FIELDS_FOR_INV), invId);
			}catch(DataAccessException e){
				LOGGER.error("Exception while fetching the custom fields in dept approval",e);
				throw new BNPApplicationException(ErrorConstants.PROCESSING_ERROR);
			}
			return resultList;
		}

		@Override
		public List<DisputeVO> getDisputeResolvedRecordDetails(NameValueVO params)throws BNPApplicationException {
			List<DisputeVO> dispList=null;
			try {
				if (StatusConstants.VALIDATION_FAILED.equalsIgnoreCase(params.getParam1())) {
					params.setParam1(StatusConstants.DELETE);
				}	
				dispList=getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_DISPUTE_RESOLN_RECORD_DETAILS), params);
				
			} catch (DataAccessException ex) {
				LOGGER.error("Error while getting DisputeResolutionRecordDetails " + ex);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}			
			return dispList;
		} 
		
		@Override
		public String getPrevInvcStatusForCancel(long invoiceId)throws BNPApplicationException {
			try {
				return (String) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(
						GET_PREV_INVC_STATUS_FOR_CANCEL), invoiceId);
			} catch (DataAccessException ex) {
				LOGGER.error("Exception while fetching previous inv status for Dispute cancel scenario",ex);
				throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
			}
		}

		@Override
		public EippInvoiceVO getInvoiceDetails(long invoiceId)throws BNPApplicationException {
			try {
				return (EippInvoiceVO) getSqlMapClientTemplate().queryForObject(
						getQueryNameWithNameSpace(GET_INVOICE_DETAILS), invoiceId); 
			} catch (DataAccessException e) {
				LOGGER.error("Error while fetching Dispute Invoice details : " + e);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
		} 
} 
