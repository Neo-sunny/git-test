/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 6, 20128:14:49 PM
 * 
 * Purpose:      EippInvoiceServiceImpl.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 6, 20128:14:49 PM        	Oracle Financial Services Software Ltd                  Initial Version
 * Apr 3,  2012      				Oracle Financial Services Software Ltd                  ST Defect #5812 and #5813  
 * Apr 10, 2012      				Sandhya R								                ST Defect #5813
 * Apr 21, 2012      				Sandhya R								                ST Defect #2020 and #1997
 * Apr 23, 2012      				Sandhya R								                ST Defect #1997
 * May 14, 2012      				Sandhya R								                UAT #2240
 * 24 Aug 2012    					Gangadharan R						                	MFU - Payment Preparation
 * 06 Sep 2012 			            Reena S													Release 3.0		Release File Inq:Pymt preparation & Pymt status update
 * 13 Sep 2012						Sandhya R												R3.0 Eipp Ph 2 : Auto payment preparation and Dispute line item changes
 * 24 Sep 2012						Aarthi T											    Release File Inq - Rel 3.0 Matching and Reconcilation
 * 30 Oct 2012 			            Arun G													Events ST fix
************************************************************************************************************************************************************/

package com.bnp.eipp.services.invoice;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao;
import com.bnp.eipp.services.dao.invoice.IEippInvoiceDao;
import com.bnp.eipp.services.invoice.vo.DeptAllocMapVO;
import com.bnp.eipp.services.invoice.vo.EippAuditVO;
import com.bnp.eipp.services.invoice.vo.EippCreditNoteVO;
import com.bnp.eipp.services.invoice.vo.EippCustFieldsVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.invoice.vo.EippPymtStatusUpdateVO;
import com.bnp.eipp.services.payment.preparation.IPymtPreparationService;
import com.bnp.eipp.services.vo.admin.DeptAllocRuleVO;
import com.bnp.eipp.services.vo.admin.DeptRuleCriteriaVO;
import com.bnp.eipp.services.vo.dispute.DisputeVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.TransactionServiceImpl;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.event.EventType;
import com.bnp.scm.services.common.event.IEventDelegate;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.common.vo.EventLogVO;
import com.bnp.scm.services.common.vo.NameValueVO;

/**
 * The Class EippInvoiceServiceImpl.
 */
@Component
public class EippInvoiceServiceImpl extends TransactionServiceImpl implements IEippInvoiceService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(EippInvoiceServiceImpl.class);
	
	/** The invoice dao. */
	@Autowired
	private IEippInvoiceDao invoiceDao;
	
	@Autowired
	private IDepartmentApprovalDao departmentApprovalDao;
	
	@Autowired
	private IEventDelegate eventDelegateImpl;
	
	@Autowired
	private IPymtPreparationService pymtPrepService;

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#getInvoices(long)
	 */
	@Override
	public List<EippInvoiceVO> getInvoices(long fileId)
			throws BNPApplicationException {
		return invoiceDao.getInvoices(fileId);
	}

	/**
	 * Checks if is null.
	 *
	 * @param userInput the user input
	 * @return true, if is null
	 */
	private boolean isNull(String userInput){
		if(userInput !=null && userInput.trim().length()>0){
			return false;	
		}else{
			return true;
		}
	}
	
	/**
	 * Process default department.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @param deptMapList the dept map list
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void processDefaultDepartment(EippInvoiceVO eippInvoiceVO,List<DeptAllocMapVO> deptMapList) 
	throws BNPApplicationException {
		String defaultDept = invoiceDao.getDefaultDepartment(eippInvoiceVO);
		if (!isNull(defaultDept)) {
			eippInvoiceVO.setInquiryDept(defaultDept);
			deptMapList.add(createMapFromInvoice(eippInvoiceVO, BNPConstants.DEPT_ALLOC_LEVEL_ONE));
		}
		
	}
	
	/**
	 * Process default department for line item.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @param deptMapList the dept map list
	 * @param defaultflag the defaultflag
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void processDefaultDepartmentForLineItems(EippInvoiceVO eippInvoiceVO,List<DeptAllocMapVO> deptMapList,boolean defaultflag) 
		throws BNPApplicationException{
		if(defaultflag){
			eippInvoiceVO.setInquiryDept(invoiceDao.getDefaultDepartment(eippInvoiceVO));
		}
		if(!isNull(eippInvoiceVO.getInquiryDept())){
			List<EippInvCntLineItemVO> lineItemList =  invoiceDao.getLineItemList(eippInvoiceVO.getInvId());
			for (EippInvCntLineItemVO eippInvCntLineItemVO : lineItemList) {
				eippInvCntLineItemVO.setBuyerOrgId(eippInvoiceVO.getBuyerOrgId());
				deptMapList.add(createMapFromLineItem(eippInvCntLineItemVO, BNPConstants.DEPT_ALLOC_LEVEL_ONE , eippInvoiceVO.getInquiryDept()));
			}
		}
	}
	
	/**
	 * Process default department for Line item when rule doesn't exists for any one of the line items.
	 *
	 * @param eippInvoiceVO 
	 * @param eippInvCntLineItemVO 
	 * @param deptMapList 
	 * @throws BNPApplicationException 
	 */
	private void processDefaultDeptForLI(EippInvoiceVO eippInvoiceVO,EippInvCntLineItemVO eippInvCntLineItemVO,
			List<DeptAllocMapVO> deptMapList, String defDept) throws BNPApplicationException{
		eippInvCntLineItemVO.setBuyerOrgId(eippInvoiceVO.getBuyerOrgId());
		deptMapList.add(createMapFromLineItem(eippInvCntLineItemVO, BNPConstants.DEPT_ALLOC_LEVEL_ONE , defDept));
	}
	
	/**
	 * Process invoice depatment.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @param deptMapList the dept map list
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void processInvoiceDepatment(EippInvoiceVO eippInvoiceVO,List<DeptAllocMapVO> deptMapList) 
		throws BNPApplicationException{
		String allocType = invoiceDao.getDeptAllocationType(eippInvoiceVO);
		if(allocType ==null || allocType.equals(BNPConstants.DEPT_ALLOC_TYPE_INVOICE)){
			deptMapList.add(createMapFromInvoice(eippInvoiceVO, BNPConstants.DEPT_ALLOC_LEVEL_ONE));
		}else{
			processDefaultDepartmentForLineItems(eippInvoiceVO, deptMapList, false);
		}
	}
	
	/**
	 * Creates the map from invoice.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @param level the level
	 * @return the dept alloc map vo
	 */
	private DeptAllocMapVO createMapFromInvoice(EippInvoiceVO eippInvoiceVO,int level) {
		DeptAllocMapVO deptAllocMapVO = new DeptAllocMapVO();
		deptAllocMapVO.setInvId(eippInvoiceVO.getInvId());
		deptAllocMapVO.setAllocLevel(level);
		deptAllocMapVO.setDeptId(eippInvoiceVO.getInquiryDept());
		populateConstantValues(deptAllocMapVO);
		deptAllocMapVO.setApprovalLevel(BNPConstants.DEPT_ALLOC_TYPE_INVOICE);
		return deptAllocMapVO;
	}
	
	/**
	 * Populate constant values.
	 *
	 * @param deptAllocMapVO the dept alloc map vo
	 */
	private void populateConstantValues(DeptAllocMapVO deptAllocMapVO) {
		deptAllocMapVO.setActive(BNPConstants.YES);
		deptAllocMapVO.setUserId(BNPConstants.DEPT_ALLOC_CONSTANT);
		deptAllocMapVO.setStatus(BNPConstants.DEPT_ALLOC_STATUS_PENDING);
		deptAllocMapVO.setAllocType(BNPConstants.DEPT_ALLOC_TYPE_DEFAULT);
	}
	
	/**
	 * Creates the map from line item.
	 *
	 * @param eippInvCntLineItemVO the eipp inv cnt line item vo
	 * @param level the level
	 * @param dept the dept
	 * @return the dept alloc map vo
	 */
	private DeptAllocMapVO createMapFromLineItem(EippInvCntLineItemVO eippInvCntLineItemVO,int level,String dept) {
		DeptAllocMapVO deptAllocMapVO = new DeptAllocMapVO();
		deptAllocMapVO.setInvId(eippInvCntLineItemVO.getFkId());
		deptAllocMapVO.setLineItemId(eippInvCntLineItemVO.getLineItemId());
		deptAllocMapVO.setAllocLevel(level);
		deptAllocMapVO.setDeptId(dept);
		populateConstantValues(deptAllocMapVO);
		deptAllocMapVO.setApprovalLevel(BNPConstants.DEPT_ALLOC_TYPE_LINEITEM);
		return deptAllocMapVO;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#processDepartmentApproval(long)
	 */
	@Override
	public void processDepartmentApproval(long fileId) throws BNPApplicationException {
		List<EippInvoiceVO> invoiceList = getInvoices(fileId);
		List<DeptAllocMapVO> deptMapList = new ArrayList<DeptAllocMapVO>();
		
		for (EippInvoiceVO eippInvoiceVO : invoiceList) {
			
			if (!invoiceDao.checkAllowNonFinProcess(eippInvoiceVO)) {
				eippInvoiceVO.setInvStatus(StatusConstants.APPROVED);
				departmentApprovalDao.approveInvoiceForLinetItem(eippInvoiceVO);
				insertEventLog(eippInvoiceVO,EventType.INVOICE_FULLY_APPROVED);
				pymtPrepService.autoPaymentPreparation(eippInvoiceVO);
				continue;
			}
		
			if (!isNull(eippInvoiceVO.getInquiryDept())) {
				processInvoiceDepatment(eippInvoiceVO, deptMapList);
			} else {
				String allocType = processDeptAllocRules(eippInvoiceVO, deptMapList);
				if (deptMapList == null || deptMapList.isEmpty()) {
					if(!isNull(allocType) && allocType.equals(BNPConstants.DEPT_ALLOC_TYPE_INVOICE)){
						processDefaultDepartment(eippInvoiceVO, deptMapList);
					}else if(!isNull(allocType) && allocType.equals(BNPConstants.DEPT_ALLOC_TYPE_LINEITEM)){
						processDefaultDepartmentForLineItems(eippInvoiceVO, deptMapList, true);
					}
				}
			}
			insertEventLog(eippInvoiceVO,EventType.INVOICE_FOR_APPROVAL);
			invoiceDao.insertDeptAllocationMap(deptMapList);
			deptMapList.clear();
		}
	}
	
	/**
	 * Process dept alloc rules.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @param deptMapList the dept map list
	 * @throws BNPApplicationException the bNP application exception
	 */
	private String processDeptAllocRules(EippInvoiceVO eippInvoiceVO,List<DeptAllocMapVO> deptMapList) 
	throws BNPApplicationException {
		String allocType = invoiceDao.getDeptAllocationType(eippInvoiceVO);
		eippInvoiceVO.setAllocType(allocType);
		List<DeptAllocRuleVO> rulesList = invoiceDao.getExistingDeptRules(eippInvoiceVO);
		if (rulesList !=null && rulesList.size() > 0 &&
				!isNull(allocType) &&
				allocType.equals(BNPConstants.DEPT_ALLOC_TYPE_INVOICE)) {
			processInvoiceRules(eippInvoiceVO, deptMapList, rulesList);
		} else if (rulesList !=null && rulesList.size() > 0 &&
				!isNull(allocType) &&
				allocType.equals(BNPConstants.DEPT_ALLOC_TYPE_LINEITEM)) {
			processLineItemRules(eippInvoiceVO, deptMapList, rulesList);
		}
		return allocType;
	}
	
	/**
	 * Process invoice rule for approval.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @param ruleId the rule id
	 * @param level the level
	 * @param deptMapList the dept map list
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void processInvoiceRuleForApproval(EippInvoiceVO eippInvoiceVO,long ruleId,int level,List<DeptAllocMapVO> deptMapList) 
	throws BNPApplicationException {
		
		List<String> deptList = invoiceDao.getDepartmentList(ruleId,eippInvoiceVO.getBuyerOrgId());
		for (String dept : deptList) {
			eippInvoiceVO.setInquiryDept(dept);
			deptMapList.add(createMapFromInvoice(eippInvoiceVO, level));
		}
	}
	
	/**
	 * Process line item rule for approval.
	 *
	 * @param eippInvCntLineItemVO the eipp inv cnt line item vo
	 * @param ruleId the rule id
	 * @param level the level
	 * @param deptMapList the dept map list
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void processLineItemRuleForApproval(EippInvCntLineItemVO eippInvCntLineItemVO,long ruleId,int level,List<DeptAllocMapVO> deptMapList) 
	throws BNPApplicationException {
		
		List<String> deptList = invoiceDao.getDepartmentList(ruleId,eippInvCntLineItemVO.getBuyerOrgId());
		for (String dept : deptList) {
			deptMapList.add(createMapFromLineItem(eippInvCntLineItemVO, level, dept));
		}
	}
	
	/**
	 * Process invoice rules.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @param deptMapList the dept map list
	 * @param rulesList the rules list
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void processInvoiceRules(EippInvoiceVO eippInvoiceVO,List<DeptAllocMapVO> deptMapList,List<DeptAllocRuleVO> rulesList)
	throws BNPApplicationException {
		int level = 0;
		boolean isRuleExists = false;
		for (DeptAllocRuleVO deptAllocRuleVO : rulesList) {
			if (isValidInvoiceRule(eippInvoiceVO, deptAllocRuleVO)) {
				isRuleExists = true;
				processInvoiceRuleForApproval(eippInvoiceVO, deptAllocRuleVO.getPkId(), ++level, deptMapList);
			}
		}
		if(!isRuleExists){
			processDefaultDepartment(eippInvoiceVO , deptMapList);
		}
	}
	
	/**
	 * Process line item rules.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @param deptMapList the dept map list
	 * @param rulesList the rules list
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void processLineItemRules(EippInvoiceVO eippInvoiceVO,List<DeptAllocMapVO> deptMapList,List<DeptAllocRuleVO> rulesList)
	throws BNPApplicationException {
		List<EippInvCntLineItemVO> lineItemList = 
			invoiceDao.getLineItemList(eippInvoiceVO.getInvId());
		String defDept = invoiceDao.getDefaultDepartment(eippInvoiceVO);
		boolean isRuleExists;
		for (EippInvCntLineItemVO eippInvCntLineItemVO : lineItemList) {
			isRuleExists = false;
			int level = 0;
			for (DeptAllocRuleVO deptAllocRuleVO : rulesList) {
				if (isValidLineItemRule(eippInvCntLineItemVO, deptAllocRuleVO)) {
					isRuleExists = true;
					eippInvCntLineItemVO.setBuyerOrgId(eippInvoiceVO.getBuyerOrgId());
					processLineItemRuleForApproval(eippInvCntLineItemVO, deptAllocRuleVO.getPkId(), ++level, deptMapList);
				}
			}
			if(!isRuleExists && !isNull(defDept)){
				processDefaultDeptForLI(eippInvoiceVO,eippInvCntLineItemVO,deptMapList,defDept);
			}
		}
		
	}
	
	/**
	 * Checks if is valid invoice rule.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @param deptAllocRuleVO the dept alloc rule vo
	 * @return true, if is valid invoice rule
	 * @throws BNPApplicationException the bNP application exception
	 */
	private boolean isValidInvoiceRule(EippInvoiceVO eippInvoiceVO,DeptAllocRuleVO deptAllocRuleVO) 
	throws BNPApplicationException {
		boolean isValid= false;
		for (DeptRuleCriteriaVO deptRuleCriteriaVO : deptAllocRuleVO.getDeptRuleCriterias()) {
			if (validateInvoiceWithCriteria(eippInvoiceVO, deptRuleCriteriaVO)) {
				isValid = true;
				break;
			}
		}
		return isValid;
	}
	
	/**
	 * Checks if is valid line item rule.
	 *
	 * @param eippInvCntLineItemVO the eipp inv cnt line item vo
	 * @param deptAllocRuleVO the dept alloc rule vo
	 * @return true, if is valid line item rule
	 * @throws BNPApplicationException the bNP application exception
	 */
	private boolean isValidLineItemRule(EippInvCntLineItemVO eippInvCntLineItemVO,DeptAllocRuleVO deptAllocRuleVO) 
	throws BNPApplicationException {
		boolean isValid= false;
		for (DeptRuleCriteriaVO deptRuleCriteriaVO : deptAllocRuleVO.getDeptRuleCriterias()) {
			if (validateLineItemWithCriteria(eippInvCntLineItemVO, deptRuleCriteriaVO)) {
				isValid = true;
				break;
			}
		}
		return isValid;
	}
	
	/**
	 * Checks if is valid amount.
	 *
	 * @param amount the amount
	 * @param deptRuleCriteriaVO the dept rule criteria vo
	 * @return true, if is valid amount
	 */
	private boolean isValidAmount(BigDecimal amount,DeptRuleCriteriaVO deptRuleCriteriaVO) {
		if (((deptRuleCriteriaVO.getLowerLimitAmt() == null &&
				deptRuleCriteriaVO.getUpperLimitAmt() == null) || 
			 (BigDecimal.ZERO.compareTo(deptRuleCriteriaVO.getLowerLimitAmt()) == 0 &&
			  BigDecimal.ZERO.compareTo(deptRuleCriteriaVO.getUpperLimitAmt()) == 0)) ||
				(amount != null && 
				deptRuleCriteriaVO.getLowerLimitAmt() != null &&
				deptRuleCriteriaVO.getUpperLimitAmt() != null && 
				amount.compareTo(
				deptRuleCriteriaVO.getLowerLimitAmt()) >= 0 &&
				amount.compareTo(deptRuleCriteriaVO.getUpperLimitAmt()) <= 0)) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Checks if is valid currency.
	 *
	 * @param currency the currency
	 * @param deptRuleCriteriaVO the dept rule criteria vo
	 * @return true, if is valid currency
	 */
	private boolean isValidCurrency(String currency,DeptRuleCriteriaVO deptRuleCriteriaVO) {
		
		if (isNull(deptRuleCriteriaVO.getCcy()) || (!isNull(currency) && 
				currency.equals(deptRuleCriteriaVO.getCcy()))) {
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * Checks if is valid purchage order number.
	 *
	 * @param poNumber the po number
	 * @param deptRuleCriteriaVO the dept rule criteria vo
	 * @return true, if is valid purchage order number
	 */
	private boolean isValidPurchaseOrderNumber(String poNumber,DeptRuleCriteriaVO deptRuleCriteriaVO) {
		
		if (isNull(deptRuleCriteriaVO.getPurchaseOrder())) {
			return true;
		}else if (!isNull(poNumber) && 
				!isNull(deptRuleCriteriaVO.getPurchaseOrder()) &&
				poNumber.equals(deptRuleCriteriaVO.getPurchaseOrder())) {
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * Validate invoice with criteria.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @param deptRuleCriteriaVO the dept rule criteria vo
	 * @return true, if successful
	 * @throws BNPApplicationException the bNP application exception
	 */
	private boolean validateInvoiceWithCriteria(EippInvoiceVO eippInvoiceVO,DeptRuleCriteriaVO deptRuleCriteriaVO) 
	throws BNPApplicationException {
		
		if (isValidAmount(eippInvoiceVO.getGrossAmt(), deptRuleCriteriaVO) &&
				isValidCurrency(eippInvoiceVO.getCcyCode(), deptRuleCriteriaVO) &&
				isValidPurchaseOrderNumber(eippInvoiceVO.getPoNumber(), deptRuleCriteriaVO) &&
				validateCustomFields(deptRuleCriteriaVO.getCriteriaId(), eippInvoiceVO.getInvId(), 
						BNPConstants.DEPT_ALLOC_TYPE_INVOICE)) {
			return true;
		} else {
			return false;
		}
		
	}
	
	/**
	 * Validate line item with criteria.
	 *
	 * @param eippInvCntLineItemVO the eipp inv cnt line item vo
	 * @param deptRuleCriteriaVO the dept rule criteria vo
	 * @return true, if successful
	 * @throws BNPApplicationException the bNP application exception
	 */
	private boolean validateLineItemWithCriteria(EippInvCntLineItemVO eippInvCntLineItemVO,DeptRuleCriteriaVO deptRuleCriteriaVO) 
	throws BNPApplicationException {
		
		if (isValidAmount(eippInvCntLineItemVO.getItemTotalPrice(), deptRuleCriteriaVO) &&
				isValidCurrency(eippInvCntLineItemVO.getItemTotalPriceCcy(), deptRuleCriteriaVO) &&
				isValidPurchaseOrderNumber(eippInvCntLineItemVO.getPoNumber(), deptRuleCriteriaVO) &&
				validateCustomFields(deptRuleCriteriaVO.getCriteriaId(), 
				eippInvCntLineItemVO.getLineItemId(), BNPConstants.DEPT_ALLOC_TYPE_LINEITEM)) {
			return true;
		} else {
			return false;
		}
		
	}
	
	/**
	 * Checks if is valid custom field.
	 *
	 * @param custField the cust field
	 * @param custFieldsMap the cust fields map
	 * @return true, if is valid custom field
	 */
	private boolean isValidCustomField(NameValueVO custField,Map<String,String> custFieldsMap) {
		if (isNull(custField.getName())) {
			return true;
		} else if(!isNull(custField.getName()) &&
				custFieldsMap.containsKey(custField.getName()) &&
				custField.getValue().equals(custFieldsMap.get(custField.getName()))) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Validate custom fields.
	 *
	 * @param criteriaId the criteria id
	 * @param pkId the pk id
	 * @param type the type
	 * @return true, if successful
	 * @throws BNPApplicationException the bNP application exception
	 */
	private boolean validateCustomFields(long criteriaId,long pkId,String type) 
	throws BNPApplicationException {
		DeptRuleCriteriaVO deptRuleCriteriaVO = invoiceDao.getCriteriaCustomFields(criteriaId);
		Map<String,String> custFieldsMap = invoiceDao.getCustomFields(pkId, type); 
		if (deptRuleCriteriaVO == null || (custFieldsMap != null && 
				isValidCustomField(deptRuleCriteriaVO.getCustomField1(), custFieldsMap) &&
				isValidCustomField(deptRuleCriteriaVO.getCustomField2(), custFieldsMap) &&
				isValidCustomField(deptRuleCriteriaVO.getCustomField3(), custFieldsMap))) {
			return true;
		} else {
			return false;
		}
				
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#getInvoice(com.bnp.eipp.services.invoice.vo.EippCreditNoteVO)
	 */
	@Override
	public EippInvoiceVO getInvoice(EippCreditNoteVO creditNoteVO)
			throws BNPApplicationException {
		return invoiceDao.getInvoice(creditNoteVO);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#updateEippInvoice(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public void updateEippInvoice(EippInvoiceVO invoiceVO)
			throws BNPApplicationException {
		invoiceDao.updateEippInvoice(invoiceVO);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#updateEippCreditNote(com.bnp.eipp.services.invoice.vo.EippCreditNoteVO)
	 */
	@Override
	public void updateEippCreditNote(EippCreditNoteVO creditNoteVO)
			throws BNPApplicationException {
		invoiceDao.updateEippCreditNote(creditNoteVO);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#insertInvoiceIntoHistory(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public void insertInvoiceIntoHistory(EippInvoiceVO invoice)
			throws BNPApplicationException {
		invoiceDao.insertInvoiceIntoHistory(invoice);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#insertCreditNoteIntoHistory(com.bnp.eipp.services.invoice.vo.EippCreditNoteVO)
	 */
	@Override
	public void insertCreditNoteIntoHistory(EippCreditNoteVO creditNote)
			throws BNPApplicationException {
		invoiceDao.insertCreditNoteIntoHistory(creditNote);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#getInvoicesForFile(long, java.lang.String)
	 */
	@Override
	public List<EippInvoiceVO> getInvoicesForFile(long fileId, String status)
			throws BNPApplicationException {
		return invoiceDao.getInvoicesForFile(fileId, status);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#getCreditNotesForFile(long, java.lang.String)
	 */
	@Override
	public List<EippCreditNoteVO> getCreditNotesForFile(long fileId,
			String status) throws BNPApplicationException {
		return invoiceDao.getCreditNotesForFile(fileId, status);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#getInvoiceLineItems(long, java.lang.String)
	 */
	@Override
	public List<EippInvCntLineItemVO> getInvoiceLineItems(long invoiceId,
			String status) throws BNPApplicationException {
		return invoiceDao.getInvoiceLineItems(invoiceId, status);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#getCreditNoteLineItems(long, java.lang.String)
	 */
	@Override
	public List<EippInvCntLineItemVO> getCreditNoteLineItems(long creditNoteId,
			String status) throws BNPApplicationException {
		return invoiceDao.getCreditNoteLineItems(creditNoteId, status);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#getCreditNoteCustomFields(long, java.lang.String)
	 */
	@Override
	public List<EippCustFieldsVO> getCreditNoteCustomFields(long creditNoteId,
			String status) throws BNPApplicationException {
		return invoiceDao.getCreditNoteCustomFields(creditNoteId, status);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#getInvoiceCustomFields(long, java.lang.String)
	 */
	@Override
	public List<EippCustFieldsVO> getInvoiceCustomFields(long invoiceId,
			String status) throws BNPApplicationException {
		return invoiceDao.getInvoiceCustomFields(invoiceId, status);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#getInvoiceLineItemCustomFields(long, java.lang.String)
	 */
	@Override
	public List<EippCustFieldsVO> getInvoiceLineItemCustomFields(
			long lineItemId, String status) throws BNPApplicationException {
		return invoiceDao.getInvoiceLineItemCustomFields(lineItemId, status);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#getCNLineItemCustomFields(long, java.lang.String)
	 */
	@Override
	public List<EippCustFieldsVO> getCNLineItemCustomFields(long lineItemId,
			String status) throws BNPApplicationException {
		return invoiceDao.getCNLineItemCustomFields(lineItemId, status);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#getOrgConfigForCNUtilization(java.lang.String)
	 */
	@Override
	public Properties getOrgConfigForCNUtilization(String supplierOrgId)
			throws BNPApplicationException {
		return invoiceDao.getOrgConfigForCNUtilization(supplierOrgId);
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#getInvoiceDetails(long)
	 */
	@Override
	public EippInvoiceVO getInvoiceDetails(long invoiceId) 
			throws BNPApplicationException {
		return invoiceDao.getInvoiceDetails(invoiceId);
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#getInvoiceDetails(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public List<EippInvoiceVO> getInvoiceDetails(EippInvoiceVO invoiceVO)throws BNPApplicationException 
	{
		return invoiceDao.getInvoiceDetails(invoiceVO);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#getCreditNoteDetails(com.bnp.eipp.services.invoice.vo.EippCreditNoteVO)
	 */
	@Override
	public List<EippCreditNoteVO> getCreditNoteDetails(EippCreditNoteVO creditNoteVO) throws BNPApplicationException 
	{
		return invoiceDao.getCreditNoteDetails(creditNoteVO);
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#getInvLineItemDetails(long, java.lang.String)
	 */
	@Override
	public List<EippInvCntLineItemVO> getInvLineItemDetails(long invId, String status)throws BNPApplicationException 
	{
		return invoiceDao.getInvLineItemDetails(invId,status);
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#getCrnLineItemDetails(java.lang.String, long, long, java.lang.String)
	 */
	@Override
	public List<EippInvCntLineItemVO> getCrnLineItemDetails(String orgId, long fileId, long cntId,String status)throws BNPApplicationException
	{
		return invoiceDao.getCrnLineItemDetails(orgId,fileId,cntId,status);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#getInvoiceAuditDetails(long)
	 */
	@Override
	public List<EippAuditVO> getInvoiceAuditDetails(long invId)
			throws BNPApplicationException {
		return invoiceDao.getInvoiceAuditDetails(invId);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#updateInvStatusAndRemAmt(com.bnp.eipp.services.vo.dispute.DisputeVO)
	 */
	@Override
	public void updateInvStatusAndRemAmt(DisputeVO dispute)
			throws BNPApplicationException {
		invoiceDao.updateInvStatusAndRemAmt(dispute);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#updateInvLnItmStatusAndRemAmt(com.bnp.eipp.services.vo.dispute.DisputeVO)
	 */
	@Override
	public String updateInvLnItmStatusAndRemAmt(DisputeVO dispute)
			throws BNPApplicationException {
		return invoiceDao.updateInvLnItmStatusAndRemAmt(dispute);
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#getPrevInvoiceStatus(long)
	 */
	public String getPrevInvoiceStatus(
			long invoiceId) throws BNPApplicationException {
		return invoiceDao.getPrevInvoiceStatus(invoiceId);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#updateLineItemStatus(java.util.List, java.lang.String)
	 */
	@Override
	public void updateLineItemStatus(List<Long> lineItemIds, String status)
			throws BNPApplicationException {
		invoiceDao.updateLineItemStatus(lineItemIds, status);
	}
	
	/**
	 * Insert event log.
	 *
	 * @param invoiceVO the invoice vo
	 * @param eventType the event type
	 */
	private void insertEventLog(EippInvoiceVO invoiceVO, 
			EventType eventType) {
		EventLogVO eventVO = new EventLogVO();
		 
		try {
			eventVO.setReferenceKey(String.valueOf(invoiceVO.getInvId()));
			eventVO.setEventType(eventType);		
			eventVO.setBuyerOrgId(invoiceVO.getBuyerOrgId());
			if(eventType.equals(EventType.INVOICE_FULLY_APPROVED)){
				eventVO.setSellerOrgId(invoiceVO.getSupplierOrgId());	
			}
			eventDelegateImpl.initEvents(eventVO);
		} catch (BNPApplicationException e) {
			LOGGER.error("Error while raising event log : " + e );
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#createInvoiceAudit(com.bnp.eipp.services.invoice.vo.EippAuditVO)
	 */
	@Override
	public void createInvoiceAudit(EippAuditVO auditVO)
			throws BNPApplicationException {
		invoiceDao.createInvoiceAudit(auditVO);
	}

	@Override
	public void updateInvStatusAndRemAmtWithTimeStamp(DisputeVO dispute)
			throws BNPApplicationException {
		invoiceDao.updateInvStatusAndRemAmtWithTimeStamp(dispute);
	}

	@Override
	public void createInvLineItemAudit(EippAuditVO auditVO)
			throws BNPApplicationException {
		invoiceDao.createInvLineItemAudit(auditVO);
	}

	@Override
	public String getPrevInvoiceStatusForCancel(long invoiceId)
			throws BNPApplicationException {
		return invoiceDao.getPrevInvoiceStatusForCancel(invoiceId);
	}

	@Override
	public List<Long> getDeptIds(EippInvoiceVO invoiceVO)
			throws BNPApplicationException {
		return invoiceDao.getDeptIds(invoiceVO);
	}

	/**
	 * It returns a single invoice from the list of invoices with the same data
	 */
	@Override
	public EippInvoiceVO getInvoiceFromInvoiceList(EippInvoiceVO eippInvoiceVO)
			throws BNPApplicationException {
		return invoiceDao.getInvoiceFromInvoiceList(eippInvoiceVO);
	}
	
	@Override 
	public int getPymtPreparationCountForFile(long fileId,String fileStatus)throws BNPApplicationException {
		NameValueVO params=new NameValueVO();
		params.setPkId(fileId);
		params.setParam1(fileStatus);
		return invoiceDao.getPymtPreparationCountForFile(params); 
	}

	@Override
	public List<EippInvoiceVO> getPymtPrepRecordDetails(long fileId,String fileStatus)throws BNPApplicationException {
		NameValueVO params=new NameValueVO();
		params.setPkId(fileId);
		params.setParam1(fileStatus);
		return invoiceDao.getPymtPrepRecordDetails(params);
	}

	@Override
	public int getPymtStatusCountForFile(long fileId)throws BNPApplicationException {
		return invoiceDao.getPymtStatusCountForFile(fileId);
	}

	@Override
	public List<EippPymtStatusUpdateVO> getPymtStatusFileDetails(long fileId)throws BNPApplicationException {
		return invoiceDao.getPymtStatusFileDetails(fileId); 
	}

	@Override
	public List<NameValueVO> getCustomFieldsForEippPymt(long pymtId,String fileStatus)throws BNPApplicationException {
		NameValueVO params=new NameValueVO();
		params.setPkId(pymtId);
		params.setParam1(fileStatus);
		return invoiceDao.getCustomFieldsForEippPymt(params); 
	}
	
	/**
	 * It returns the complete invoice details including the configuration level flags
	 */
	@Override
	public EippInvoiceVO getInvoiceFullDetails(EippInvoiceVO eippInvoiceVO)
			throws BNPApplicationException {
		return invoiceDao.getInvoiceFullDetails(eippInvoiceVO);
	}
	
	// Start : Added for Rel 3.0 Matching and Reconcilation
	@Override
	public List<EippInvoiceVO> getMatchReconPymtDetails(long fileId,String fileStatus)throws BNPApplicationException {
		NameValueVO params=new NameValueVO();
		params.setPkId(fileId);
		params.setParam1(fileStatus);
		return invoiceDao.getMatchReconPymtDetails(params);
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#getMatchReconInvoiceDetails(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public List<EippInvoiceVO> getMatchReconInvoiceDetails(EippInvoiceVO invoiceVO)throws BNPApplicationException 
	{
		return invoiceDao.getMatchReconInvoiceDetails(invoiceVO);
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#getMatchReconCreditNoteDetails(com.bnp.eipp.services.invoice.vo.EippCreditNoteVO)
	 */
	@Override
	public List<EippCreditNoteVO> getMatchReconCreditNoteDetails(EippCreditNoteVO creditNoteVO) throws BNPApplicationException 
	{
		return invoiceDao.getMatchReconCreditNoteDetails(creditNoteVO);
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#getMatchReconInvLineItemDetails(long, java.lang.String)
	 */
	@Override
	public List<EippInvCntLineItemVO> getMatchReconInvLineItemDetails(long invId)throws BNPApplicationException 
	{
		return invoiceDao.getMatchReconInvLineItemDetails(invId);
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#getMatchReconCrnLineItemDetails(java.lang.String, long, long, java.lang.String)
	 */
	@Override
	public List<EippInvCntLineItemVO> getMatchReconCrnLineItemDetails(String orgId, long fileId, long cntId)throws BNPApplicationException
	{
		return invoiceDao.getMatchReconCrnLineItemDetails(orgId,fileId,cntId);
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvoiceService#getMatchReconInvoiceCustomFields(long, java.lang.String)
	 */
	@Override
	public List<EippCustFieldsVO> getMatchReconInvoiceCustomFields(long invoiceId, String status) throws BNPApplicationException {
		return invoiceDao.getMatchReconInvoiceCustomFields(invoiceId, status);
	}
	// Ends : Added for Rel 3.0 Matching and Reconcilation

	@Override
	public SqlMapClientWrapper getDao() {
		return (SqlMapClientWrapper) invoiceDao;
	}
	
}
