/* *******************************************************************************************************************************************************  
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 15, 201210:52:26 AM
 * 
 * Purpose:      DepartmentApprovalDaoImpl.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 15, 201210:52:26 AM        Oracle Financial Services Software Ltd                  Initial Version
 * Apr 3,2012      		          Oracle Financial Services Software Ltd                  ST Defect #5812 and #5813
 * Apr 21,2012      		      Sandhya R								                  SIT #1997
 * 27/04/2012					  Sandhya R												  R2.1 SIT Defect #2142 - Added a boolean parameter for fetching record to diff from pending action access  
************************************************************************************************************************************************************/

package com.bnp.eipp.services.dao.invoice;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.invoice.vo.EippAuditVO;
import com.bnp.eipp.services.invoice.vo.EippCreditNoteUtilVO;
import com.bnp.eipp.services.invoice.vo.EippCustFieldsVO;
import com.bnp.eipp.services.invoice.vo.EippDeptDisplayVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.scm.services.common.vo.AttachmentVO;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.ibatis.sqlmap.client.SqlMapExecutor;
import com.ibatis.sqlmap.engine.execution.BatchException;

/**
 * The Class DepartmentApprovalDaoImpl.
 */
@Component
@SuppressWarnings("unchecked")
public class DepartmentApprovalDaoImpl extends SqlMapClientWrapper implements IDepartmentApprovalDao {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(DepartmentApprovalDaoImpl.class);
	
	/** The Constant FETCH_DEPT_APPROVAL_RECORDS. */
	private static final String FETCH_DEPT_APPROVAL_RECORDS = "DeptApprovalNS.searchDepartmentApproval";
	
	/** The Constant FETCH_CUSTOM_FIELDS_FOR_INV. */
	private static final String FETCH_CUSTOM_FIELDS_FOR_INV = "DeptApprovalNS.fetchCustomFieldsForInv";
	
	/** The Constant FETCH_CNT_UTILIZED_FOR_INV. */
	private static final String FETCH_CNT_UTILIZED_FOR_INV = "DeptApprovalNS.fetchCntUtilizedForInv";
	
	/** The Constant FETCH_LINE_ITEMS_FOR_INV. */
	private static final String  FETCH_LINE_ITEMS_FOR_INV = "DeptApprovalNS.fetchLineItemsForInv";
	
	/** The Constant UPDATE_DEPT_ALLOC. */
	private static final String UPDATE_DEPT_ALLOC = "DeptApprovalNS.updateDeptAllocMap";
	
	/** The Constant INSERT_DEPT_ALLOC_HISTORY. */
	private static final String INSERT_DEPT_ALLOC_HISTORY = "DeptApprovalNS.insertDeptAllocMap";
	
	/** The Constant GET_INV_REM_COUNT. */
	private static final String  GET_INV_REM_COUNT ="DeptApprovalNS.getInvoiceCountRemForApproval";
	
	/** The Constant GET_INV_LN_ITM_REM_COUNT. */
	private static final String  GET_INV_LN_ITM_REM_COUNT ="DeptApprovalNS.getInvoiceLnItmCountRemForApproval";
	
	/** The Constant GET_INV_REM_COUNT_FOR_LINE_ITEM. */
	private static final String  GET_INV_REM_COUNT_FOR_LINE_ITEM ="DeptApprovalNS.getInvoiceCountForLineItem";
	
	/** The Constant UPDATE_INV. */
	private static final String  UPDATE_INV ="DeptApprovalNS.updateInvoiceInMaster";
	
	/** The Constant INSERT_INV_HIST. */
	private static final String  INSERT_INV_HIST ="DeptApprovalNS.insertInvoiceInHistory";
	
	/** The Constant UPDATE_LN_ITM. */
	private static final String  UPDATE_LN_ITM ="DeptApprovalNS.updateLineItemInMaster";
	
	/** The Constant INSERT_LN_ITM_HIST. */
	private static final String  INSERT_LN_ITM_HIST ="DeptApprovalNS.insertLineItemInHistory";	
	
	/** The Constant FETCH_DEPTS_LIST. */
	private static final String  FETCH_DEPTS_LIST = "DeptApprovalNS.getDepartmentListForReassigning";
	
	/** The Constant FETCH_USERS_LIST. */
	private static final String  FETCH_USERS_LIST= "DeptApprovalNS.getUsersListForReassigning";
	
	/** The Constant FETCH_EXISTING_ASSIGNEES. */
	private static final String FETCH_EXISTING_ASSIGNEES="DeptApprovalNS.getExistingAssigneesForInv";
	
	/** The Constant INSERT_DEPT_ALLOC_MASTER. */
	private static final String INSERT_DEPT_ALLOC_MASTER = "DeptApprovalNS.insertInDeptAllocMapMaster";
	
	/** The Constant INSERT_DEPT_ALLOC_HIST. */
	private static final String INSERT_DEPT_ALLOC_HIST = "DeptApprovalNS.insertInDeptAllocMapHist";
	
	/** The Constant UPDATE_DEPT_ALLOC_MASTER. */
	private static final String UPDATE_DEPT_ALLOC_MASTER = "DeptApprovalNS.updateDeptAllocMaster";
	
	/** The Constant FETCH_LINE_ITEM_IDS. */
	private static final String FETCH_LINE_ITEM_IDS = "DeptApprovalNS.fetchLineItemIds";
	
	/** The Constant FETCH_LINE_ITEM_FOR_INVOICE. */
	private static final String FETCH_LINE_ITEM_FOR_INVOICE = "DeptApprovalNS.fetchLineItemIdForInvoice";
	
	/** The Constant UPDATE_INVOICE_MASTER. */
	private static final String UPDATE_INVOICE_MASTER = "DeptApprovalNS.updateInvoiceMasterForReject";
	
	/** The Constant UPDATE_INVOICE_LN_ITM_MASTER. */
	private static final String UPDATE_INVOICE_LN_ITM_MASTER = 	"DeptApprovalNS.updateInvoiceLnItemMasterForReject";

	/** The Constant INSERT_INVOICE_HIST. */
	private static final String INSERT_INVOICE_HIST = "DeptApprovalNS.insertInvoiceLnInHistForReject";

	/** The Constant UPDATE_DEPT_ALLOC_MASTER_REJECT. */
	private static final String UPDATE_DEPT_ALLOC_MASTER_REJECT = "DeptApprovalNS.updateDeptAllocMapMasterForReject";

	/** The Constant INSERT_DEPT_ALLOC_HIST_REJECT. */
	private static final String INSERT_DEPT_ALLOC_HIST_REJECT = "DeptApprovalNS.insertDeptAllocMapInHist";
	
	/** The Constant FETCH_INVOICE_AUDIT. */
	private static final String  FETCH_INVOICE_AUDIT = "DeptApprovalNS.fetchInvoiceAudit";
	
	/** The Constant FETCH_INV_LN_ITM_AUDIT. */
	private static final String  FETCH_INV_LN_ITM_AUDIT = "DeptApprovalNS.fetchInvoiceLineItemAudit"; 
	
	/** The Constant UPDATE_INV_LN_ITM_DEPT_ALLOC. */
	private static final String UPDATE_INV_LN_ITM_DEPT_ALLOC = "DeptApprovalNS.updateInvLineItemDeptAlloc";
	
	/** The Constant INSERT_INV_LN_ITM_DEPT_ALLOC_HISTORY. */
	private static final String INSERT_INV_LN_ITM_DEPT_ALLOC_HISTORY = "DeptApprovalNS.insertInvLineIremDeptAllocHist";
	
	/** The Constant UPDATE_INV_LN_ITM. */
	private static final String  UPDATE_INV_LN_ITM = "DeptApprovalNS.updateInvLineItemInMaster";

	/** The Constant INSERT_INV_LN_ITM_HIST. */
	private static final String INSERT_INV_LN_ITM_HIST = "DeptApprovalNS.insertInvLineItemInHistory";
	
	/** The Constant INSERT_LN_ITMS_DEPT_ALLOC_HIST. */
	private static final String INSERT_LN_ITMS_DEPT_ALLOC_HIST = "DeptApprovalNS.insertLineItemInDeptAllocMapHist";
	
	/** The Constant UPDATE_LN_ITMS_DEPT_ALLOC_MASTER. */
	private static final String UPDATE_LN_ITMS_DEPT_ALLOC_MASTER = "DeptApprovalNS.updateLineItemDeptAllocMaster";
	
	/** The Constant INSERT_LN_ITM_DEPT_ALLOC_MASTER. */
	private static final String INSERT_LN_ITM_DEPT_ALLOC_MASTER = "DeptApprovalNS.insertLineItemInDeptAllocMapMaster";
	
	/** The Constant INSERT_INV_ATTACHMENTS. */
	private static final String INSERT_INV_ATTACHMENTS = "DeptApprovalNS.insertInvoiceAttachment";
	
	/** The Constant GET_INV_ATTACHMENTS. */
	private static final String GET_INV_ATTACHMENTS  = "DeptApprovalNS.getInvoiceAttachment";
	
	/** The Constant GET_LN_ITM_CUST. */
	private static final String GET_LN_ITM_CUST = "DeptApprovalNS.getLnItemCustFields";
	
	/** The Constant GET_NEW_DEPT_IDS. */
	private static final String GET_NEW_DEPT_IDS = "DeptApprovalNS.getNewDeptsForLIReassign"; 

	/** The Constant GET_OLD_DEPT_IDS. */
	private static final String	GET_OLD_DEPT_IDS = "DeptApprovalNS.getOldDeptsForLIReassign"; 
	
	/** The Constant GET_BUYER_ORG. */
	private static final String GET_BUYER_ORG = "DeptApprovalNS.getBuyerOrgList"; 

	/** The Constant GET_SUPPLIER_ORG. */
	private static final String	GET_SUPPLIER_ORG = "DeptApprovalNS.getSupplierOrgList";
	
	private static final String GET_LAST_UPDATED_TS = "DeptApprovalNS.getLastUpdatedTS";
	
	/** The Constant GET_INV_STATUS_FRM_LI. */
	private static final String GET_INV_STATUS_FRM_LI = "DeptApprovalNS.getInvStatusFromLI";
	
	private static final String GET_DEPT_IDS = "DeptApprovalNS.getDeptIds";
	
	private static final String FETCH_DEPT_APPROVAL_RECORDS_FOR_PENDING_ACTION = "DeptApprovalNS.searchDepartmentApprovalForPendingAction";
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#fetchDeptApprovalSummary(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public List<EippInvoiceVO> fetchDeptApprovalSummary(EippInvoiceVO invoiceVO, boolean isPendingAction) throws BNPApplicationException {
		List<EippInvoiceVO> resultList= null;
		try{
			if(isPendingAction){
				resultList = getSqlMapClientTemplate().queryForList(FETCH_DEPT_APPROVAL_RECORDS_FOR_PENDING_ACTION, invoiceVO);
			}else{
				resultList = getSqlMapClientTemplate().queryForList(FETCH_DEPT_APPROVAL_RECORDS, invoiceVO);
			}
		}catch(DataAccessException e){
			LOGGER.error("Exception while fetching the records for EIPP departmentapproval",e);
			throw new BNPApplicationException(ErrorConstants.ERROR_IN_SEARCH);
		}
		return resultList;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#getCustomFieldsForInvoice(java.lang.String)
	 */
	@Override
	public List<EippCustFieldsVO> getCustomFieldsForInvoice(long invId) throws BNPApplicationException {
		List<EippCustFieldsVO> resultList= null;
		try{
			resultList = getSqlMapClientTemplate().queryForList(FETCH_CUSTOM_FIELDS_FOR_INV, invId);
		}catch(DataAccessException e){
			LOGGER.error("Exception while fetching the custom fields in dept approval",e);
			throw new BNPApplicationException(ErrorConstants.PROCESSING_ERROR);
		}
		return resultList;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#getCntUtilList(long)
	 */
	@Override
	public List<EippCreditNoteUtilVO> getCntUtilList(long invId)
			throws BNPApplicationException {
		List<EippCreditNoteUtilVO> resultList= null;
		try{
			resultList = getSqlMapClientTemplate().queryForList(FETCH_CNT_UTILIZED_FOR_INV, invId);
		}catch(DataAccessException e){
			LOGGER.error("Exception while fetching the credit notes utilized in dept approval",e);
			throw new BNPApplicationException(ErrorConstants.PROCESSING_ERROR);
		}
		return resultList;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#getInvLineItems(com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO)
	 */
	@Override
	public List<EippInvCntLineItemVO> getInvLineItems(
			EippInvCntLineItemVO inputVO) throws BNPApplicationException {
		List<EippInvCntLineItemVO> resultList= null;
		try{
			resultList = getSqlMapClientTemplate().queryForList(FETCH_LINE_ITEMS_FOR_INV, inputVO);
		}catch(DataAccessException e){
			LOGGER.error("Exception while fetching the inv line items in dept approval",e);
			throw new BNPApplicationException(ErrorConstants.ERROR_IN_SEARCH);
		}
		return resultList;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#approveInvoice(java.util.List)
	 */
	@Override
	public void approveInvoiceInDeptAllocMap(EippInvoiceVO invoiceVO)
			throws BNPApplicationException {
		try{
			getSqlMapClientTemplate().update(UPDATE_DEPT_ALLOC, invoiceVO);
			getSqlMapClientTemplate().insert(INSERT_DEPT_ALLOC_HISTORY, invoiceVO);
		}catch(Exception e){
			LOGGER.error("exception in department approval dao--approveInvoiceInDeptAllocMap "+ e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#getPendingInvForApprovalCount(long)
	 */
	@Override
	public List<Integer> getPendingInvForApprovalCount(EippInvoiceVO invId)
			throws BNPApplicationException {
		List<Integer> result= null;
		try{
			result = getSqlMapClientTemplate().queryForList(GET_INV_REM_COUNT, invId);
		}catch(DataAccessException e){
			LOGGER.error("exception in department approval dao--getPendingInvForApprovalCount",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return result;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#approveInvoice()
	 */
	@Override
	public void approveInvoice(EippInvoiceVO invoiceVO) throws BNPApplicationException {
		try{
			approveInvoiceForLinetItem(invoiceVO);
			approveLineItem(invoiceVO);
		}catch(Exception e){
			LOGGER.error("exception in department approval dao --approveInvoice"+ e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#approveInvoiceForLinetItem(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public void approveInvoiceForLinetItem(EippInvoiceVO invoiceVO) throws BNPApplicationException {
		try{
			getSqlMapClientTemplate().update(UPDATE_INV, invoiceVO);
			getSqlMapClientTemplate().insert(INSERT_INV_HIST, invoiceVO);
		}catch(Exception e){
			LOGGER.error("exception in department approval dao --approveInvoiceForLinetItem"+ e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#approveLineItem()
	 */
	@Override
	public void approveLineItem(EippInvoiceVO invoiceVO) throws BNPApplicationException {
		try{
			getSqlMapClientTemplate().update(UPDATE_LN_ITM, invoiceVO);
			getSqlMapClientTemplate().insert(INSERT_LN_ITM_HIST, invoiceVO);
		}catch(Exception e){
			LOGGER.error("exception in department approval dao--approveLineItem "+ e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#checkInvCountForLineItems(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public int checkInvCountForLineItems(EippInvoiceVO invoiceVO)
			throws BNPApplicationException {
		int result= 0;
		try{
			result = (Integer)getSqlMapClientTemplate().queryForObject(GET_INV_REM_COUNT_FOR_LINE_ITEM, invoiceVO);
		}catch(DataAccessException e){
			LOGGER.error("exception in department approval dao--checkInvCountForLineItems",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return result;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#getUsersListForReassigning(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public List<String> getUsersListForReassigning(EippInvoiceVO invoiceVO)
			throws BNPApplicationException {
		List<String> resultList= null;
		try{
			resultList = getSqlMapClientTemplate().queryForList(FETCH_USERS_LIST, invoiceVO);
		}catch(DataAccessException e){
			LOGGER.error("exception in department approval dao--getUsersListForReassigning",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return resultList;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#getDepartmentListForReassigning(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public List<EippDeptDisplayVO> getDepartmentListForReassigning(EippInvoiceVO invoiceVO)
			throws BNPApplicationException {
		List<EippDeptDisplayVO> resultList= null;
		try{
			resultList = getSqlMapClientTemplate().queryForList(FETCH_DEPTS_LIST, invoiceVO);
		}catch(DataAccessException e){
			LOGGER.error("exception in department approval dao--getDepartmentListForReassigning",e);
			throw new BNPApplicationException(ErrorConstants.ERROR_IN_SEARCH);
		}
		return resultList;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#getExistingAssignees(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public List<NameValueVO> getExistingAssignees(EippInvoiceVO invoiceVO)
			throws BNPApplicationException {
		List<NameValueVO> resultList= null;
		try{
			resultList = getSqlMapClientTemplate().queryForList(FETCH_EXISTING_ASSIGNEES, invoiceVO);
		}catch(DataAccessException e){
			LOGGER.error("exception in department approval dao--getExistingAssignees",e);
			throw new BNPApplicationException(ErrorConstants.ERROR_IN_SEARCH);
		}
		return resultList;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#changeStatusToPending(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public void changeStatusToPending(EippInvoiceVO invoiceVO) throws BNPApplicationException {
		approveInvoiceForLinetItem(invoiceVO);
		approveLineItem(invoiceVO);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#reassignToDepartments(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public void reassignToDepartments(final EippInvoiceVO invoiceVO)
			throws BNPApplicationException {
		try{
		approveInvoiceForLinetItem(invoiceVO);			
		final List<String> listIn = invoiceVO.getDeptAllocMap().getReassignDeptList();
		invoiceVO.getDeptAllocMap().setActive("N");
		getSqlMapClientTemplate().update(UPDATE_DEPT_ALLOC_MASTER, invoiceVO);
		getSqlMapClientTemplate().insert(INSERT_DEPT_ALLOC_HIST, invoiceVO);
		invoiceVO.getDeptAllocMap().setActive("Y");
		try{
			 getSqlMapClientTemplate().execute(new SqlMapClientCallback<List<Object>>() {
						@Override
						public List<Object> doInSqlMapClient(SqlMapExecutor executor)
								throws SQLException {
							List<Object> list = null;
							try {
								executor.startBatch();
								for (String dept : listIn) {
									invoiceVO.getDeptAllocMap().setDeptPkId(Long.parseLong(dept));
									executor.insert(INSERT_DEPT_ALLOC_MASTER, invoiceVO);
								}
								
								list = executor.executeBatchDetailed();
								// R7.0 Fortify issues
//								if (list != null) {
//									LOGGER.debug("Batch Result Size" + list.size());
//								}

							} catch (BatchException e) {
								LOGGER.error("Excecuting batch update in dept approval Failed "+ e.getMessage());
								throw new SQLException();
							}
							return list;
						}
					});
			 getSqlMapClientTemplate().insert(INSERT_DEPT_ALLOC_HIST, invoiceVO);
		}catch(Exception e){
			LOGGER.error("exception in department approval dao reassignToDepartments"+ e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		}
		catch(DataAccessException e){
			LOGGER.error("exception in department approval dao--reassignToDepartments");
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#reassignToUsers(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public void reassignToUsers(final EippInvoiceVO invoiceVO)
			throws BNPApplicationException {
		try{
			approveInvoiceForLinetItem(invoiceVO);
			final List<String> listIn = invoiceVO.getDeptAllocMap().getReassignUserList();
			invoiceVO.getDeptAllocMap().setActive("N");
			getSqlMapClientTemplate().update(UPDATE_DEPT_ALLOC_MASTER, invoiceVO);
			getSqlMapClientTemplate().insert(INSERT_DEPT_ALLOC_HIST, invoiceVO);
			invoiceVO.getDeptAllocMap().setActive("Y");
			try{
				getSqlMapClientTemplate().execute(new SqlMapClientCallback<List<Object>>() {
						@Override
						public List<Object> doInSqlMapClient(SqlMapExecutor executor)
								throws SQLException {
							List<Object> list = null;
							try {
								executor.startBatch();
								for (String user : listIn) {
									invoiceVO.getDeptAllocMap().setUserId(user);
									executor.insert(INSERT_DEPT_ALLOC_MASTER, invoiceVO);
								}
								
								list = executor.executeBatchDetailed();
								// R7.0 Fortify issues
//								if (list != null) {
//									LOGGER.debug("Batch Result Size" + list.size());
//								}

							} catch (BatchException e) {
								LOGGER.error("Excecuting batch update in dept approval  "+ e.getMessage());
								throw new SQLException();
							}
							return list;
						}
					});
				getSqlMapClientTemplate().insert(INSERT_DEPT_ALLOC_HIST, invoiceVO);
			}catch(Exception e){
				LOGGER.error("exception in department approval dao "+ e.getMessage());
				throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
			}
		}catch(DataAccessException e){
			LOGGER.error("exception in department approval dao--reassignToUsers");
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#getLineItemsIds(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public List<Long> getLineItemsIds(EippInvoiceVO invoiceVO)
			throws BNPApplicationException {
		List<Long> resultList= null;
		try{
			resultList = getSqlMapClientTemplate().queryForList(FETCH_LINE_ITEM_IDS, invoiceVO);
		}catch(DataAccessException e){
			LOGGER.error("Exception in getting invoice line item ids - DepartmentApprovalDao-----------",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return resultList;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#getLineItemsForInvoice(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public List<EippInvCntLineItemVO> getLineItemsForInvoice(
			EippInvoiceVO invoiceVO) throws BNPApplicationException {
		List<EippInvCntLineItemVO> resultList= null;
		try{
			resultList = getSqlMapClientTemplate().queryForList(FETCH_LINE_ITEM_FOR_INVOICE, invoiceVO);
		}catch(DataAccessException e){
			LOGGER.error("Exception while fetching line items for invoice -- DepartmentApprovalDao----------",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return resultList;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#rejectInvoice(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public void rejectInvoice(EippInvoiceVO invoiceVO) throws BNPApplicationException{
		try{
			getSqlMapClientTemplate().update(UPDATE_INVOICE_MASTER, invoiceVO);
			getSqlMapClientTemplate().insert(INSERT_INV_HIST, invoiceVO);
			getSqlMapClientTemplate().update(UPDATE_INVOICE_LN_ITM_MASTER, invoiceVO);
			getSqlMapClientTemplate().insert(INSERT_INVOICE_HIST, invoiceVO);
			getSqlMapClientTemplate().update(UPDATE_DEPT_ALLOC_MASTER_REJECT, invoiceVO);
			getSqlMapClientTemplate().insert(INSERT_DEPT_ALLOC_HIST_REJECT, invoiceVO);
		}catch(Exception e){
			LOGGER.error("Error in rejecting invoice - DepartmentApprovalDao ------------"+ e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#getInvoiceAuditDetails(long)
	 */
	@Override
	public List<EippAuditVO> getInvoiceAuditDetails(long invID)
			throws BNPApplicationException {
		List<EippAuditVO> resultList= null;
		try{
			resultList = getSqlMapClientTemplate().queryForList(FETCH_INVOICE_AUDIT, invID);
		}catch(DataAccessException e){
			LOGGER.error("Exception while fetching inv line audit details - DepartmentApprovalDao------------",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return resultList;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#getInvoiceLineItemAuditDetails(long)
	 */
	@Override
	public List<EippAuditVO> getInvoiceLineItemAuditDetails(long lineItemID)
			throws BNPApplicationException {
		List<EippAuditVO> resultList= null;
		try{
			resultList = getSqlMapClientTemplate().queryForList(FETCH_INV_LN_ITM_AUDIT, lineItemID);
		}catch(DataAccessException e){
			LOGGER.error("Expception while getting invoice line tiem audit details - DepartmentApprovalDao-----------",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return resultList;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#approveInvoiceLineItemInDeptAllocMap(com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO)
	 */
	@Override
	public void approveInvoiceLineItemInDeptAllocMap(EippInvCntLineItemVO input)
			throws BNPApplicationException {
		try{
			getSqlMapClientTemplate().update(UPDATE_INV_LN_ITM_DEPT_ALLOC, input);
			getSqlMapClientTemplate().insert(INSERT_INV_LN_ITM_DEPT_ALLOC_HISTORY, input);
		}catch(Exception e){
			LOGGER.error("Exception while approving invoice line item in dept alloc map table - DepartmentApprovalDao ----------"+ e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#getPendingInvLnItmForApprovalCount(com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO)
	 */
	@Override
	public List<Integer> getPendingInvLnItmForApprovalCount(EippInvCntLineItemVO input)
			throws BNPApplicationException {
		List<Integer> result= null;
		try{
			result = getSqlMapClientTemplate().queryForList(GET_INV_LN_ITM_REM_COUNT, input);
		}catch(DataAccessException e){
			LOGGER.error("Exception while getting pending invoice line items count -- DepartmentApprovalDao---------------",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return result;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#approveLineItemLevel(com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO)
	 */
	@Override
	public void approveLineItemLevel(EippInvCntLineItemVO input)
			throws BNPApplicationException {
		try{
			getSqlMapClientTemplate().update(UPDATE_INV_LN_ITM, input);
			getSqlMapClientTemplate().insert(INSERT_INV_LN_ITM_HIST, input);
		}catch(Exception e){
			LOGGER.error("Exception while approving invoice in line item level -- DepartmentApprovalDao--------------"+ e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#reassignInvoiceLineItems(com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO)
	 */
	@Override
	public void reassignInvoiceLineItems(EippInvCntLineItemVO input)
			throws BNPApplicationException {
		try{
			input.setActive("N");
			getSqlMapClientTemplate().update(UPDATE_LN_ITMS_DEPT_ALLOC_MASTER, input);
			getSqlMapClientTemplate().insert(INSERT_LN_ITMS_DEPT_ALLOC_HIST, input);
			input.setActive("Y");
			getSqlMapClientTemplate().insert(INSERT_LN_ITM_DEPT_ALLOC_MASTER, input);
			getSqlMapClientTemplate().insert(INSERT_LN_ITMS_DEPT_ALLOC_HIST, input);
		}catch(Exception e){
			LOGGER.error("Exception while reassigning invoice line items- DepartmentApprovalDao------------"+ e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#uploadInvoiceAttachment(com.bnp.eipp.services.vo.dispute.AttachmentVO)
	 */
	@Override
	public void uploadInvoiceAttachment(AttachmentVO attachVO)
			throws BNPApplicationException {
		try{
			getSqlMapClientTemplate().insert(INSERT_INV_ATTACHMENTS, attachVO);
		}catch(Exception e){
			LOGGER.error("Exception while inserting attachement for invoice - DepartmentApprovalDao--------"+ e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#getAttachments(long)
	 */
	@Override
	public List<AttachmentVO> getAttachments(long invId)
			throws BNPApplicationException {
		List<AttachmentVO> result= null;
		try{
			result = getSqlMapClientTemplate().queryForList(GET_INV_ATTACHMENTS, invId);
		}catch(DataAccessException e){
			LOGGER.error("Exception while getting pending invoice attachments -- DepartmentApprovalDao---------------",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return result;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#getCustomFieldsForLineItems(long)
	 */
	@Override
	public List<EippCustFieldsVO> getCustomFieldsForLineItems(long lineItemId)
			throws BNPApplicationException {
		List<EippCustFieldsVO> result= null;
		try{
			result = getSqlMapClientTemplate().queryForList(GET_LN_ITM_CUST, lineItemId);
		}catch(DataAccessException e){
			LOGGER.error("Exception while getting custom fields for line item -- DepartmentApprovalDao---------------",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return result;
	}
	
	
	/*Concurrency*/
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.dao.SqlMapClientWrapper#updateTxnTimestamp(java.lang.Object)
	 */
	public int updateTxnTimestamp(
			Object object) throws BNPApplicationException {
		
		List<EippInvoiceVO> invoiceList = null;
		int count = 0;
		if (object instanceof List) {
			invoiceList = (List<EippInvoiceVO>) object;
			
			try {
				for (EippInvoiceVO invVO : invoiceList) {
						count = super.updateTxnTimestamp(invVO);
				}
			} catch (DataAccessException e) {
				LOGGER.error("Error while updating txn timestamp" + e);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
		}
		return count;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.dao.SqlMapClientWrapper#resetProcessingFlag(java.lang.Object)
	 */
	public void resetProcessingFlag(Object txnObj)
			throws BNPApplicationException {
		
		try {
			List<EippInvoiceVO> invList = null;
			if (txnObj instanceof List) {
				invList = (List<EippInvoiceVO>) txnObj;
					for (EippInvoiceVO invVO : invList) {
							super.resetProcessingFlag(invVO);
					}
				}
			} catch (DataAccessException e) {
				LOGGER.error("Error while resetting process flag" + e);
				throw new DBException(ErrorConstants.DATABASE_ERROR);
			}
		}
	
	/**
	 * Instantiates a new department approval dao impl.
	 */
	public DepartmentApprovalDaoImpl() {
		nameSpace = "DeptApprovalNS";
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#getOldDeptIds(com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO)
	 */
	@Override
	public List<String> getOldDeptIds(EippInvCntLineItemVO tmpVO)
			throws BNPApplicationException {
		List<String> result= null;
		try{
			result = getSqlMapClientTemplate().queryForList(GET_OLD_DEPT_IDS, tmpVO);
		}catch(DataAccessException e){
			LOGGER.error("Exception while getting old dept ids -- DepartmentApprovalDao---------------",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return result;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#getNewDeptIds(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public List<EippDeptDisplayVO> getNewDeptIds(EippInvoiceVO invoiceVO)
			throws BNPApplicationException {
		List<EippDeptDisplayVO> result= null;
		try{
			result = getSqlMapClientTemplate().queryForList(GET_NEW_DEPT_IDS, invoiceVO);
		}catch(DataAccessException e){
			LOGGER.error("Exception while getting new deptIds-- DepartmentApprovalDao---------------",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return result;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#getBuyerOrgList(com.bnp.scm.services.common.vo.NameValueVO)
	 */
	@Override
	public List<NameValueVO> getBuyerOrgList(NameValueVO input)
			throws BNPApplicationException {
		List<NameValueVO> result= null;
		try{
			result = getSqlMapClientTemplate().queryForList(GET_BUYER_ORG, input);
		}catch(DataAccessException e){
			LOGGER.error("Exception while getting buyer list-- DepartmentApprovalDao---------------",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return result;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#getSupplierOrgList(com.bnp.scm.services.common.vo.NameValueVO)
	 */
	@Override
	public List<NameValueVO> getSupplierOrgList(NameValueVO input)
			throws BNPApplicationException {
		List<NameValueVO> result= null;
		try{
			result = getSqlMapClientTemplate().queryForList(GET_SUPPLIER_ORG, input);
		}catch(DataAccessException e){
			LOGGER.error("Exception while getting supplier list-- DepartmentApprovalDao---------------",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return result;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#getLastUpdatedTS(long)
	 */
	@Override
	public Timestamp getLastUpdatedTS(long invId)
			throws BNPApplicationException {
		Timestamp time = null;
		try{
			time = (Timestamp) getSqlMapClientTemplate().queryForObject(GET_LAST_UPDATED_TS, invId);
		}catch(DataAccessException e){
			LOGGER.error("Exception while getting last updated timestamp",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return time;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#getInvStatusFromLineItem(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public String getInvStatusFromLineItem(EippInvoiceVO invoiceVO)
			throws BNPApplicationException {
		String status = null;
		try{
			status = (String) getSqlMapClientTemplate().queryForObject(GET_INV_STATUS_FRM_LI, invoiceVO);
		}catch(DataAccessException e){
			LOGGER.error("Exception while getting last updated timestamp",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return status;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao#getDeptIds(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public List<Long> getDeptIds(EippInvoiceVO invoiceVO)
			throws BNPApplicationException {
		List<Long> deptIds = null;
		try{
			deptIds = getSqlMapClientTemplate().queryForList(GET_DEPT_IDS, invoiceVO);
		}catch(DataAccessException e){
			LOGGER.error("Exception while getting dept ids",e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return deptIds;
	}
	
}
 
