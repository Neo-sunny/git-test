/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14 Jan 2012
 * 
 * Purpose:     Link Organization for EIPP Service Implementation
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 14 Jan 2012                      Oracle Financial Services Software Ltd             Initial Version
 * 09 Mar 2012		  Oracle Financial Services Software Ltd				 Release 2.1 I1				Changed for Auto Complete Text box Implementation
 * 26 Mar 2012		  Oracle Financial Services Software Ltd				 Release 2.1 I1				TD-5634
 * 05 Apr 2012		  Oracle Financial Services Software Ltd				 Release 2.1 I1				Fix for SIT TD-1866
 * 18 Jul 2012        Reena 												 Release 3.0	            Changes for EIPP-Phase II
 *****************************************************************************************************************************************************************/

package com.bnp.eipp.services.admin;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.dao.admin.ILinkOrgForEippDAO;
import com.bnp.eipp.services.vo.admin.LinkOrgForEippVO;
import com.bnp.scm.services.common.AbstractServiceImpl;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.dao.IAbstractDAO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

// TODO: Auto-generated Javadoc
/** 
 * The Class LinkOrgForEippServiceImpl.
 */
@Component
public class LinkOrgForEippServiceImpl extends AbstractServiceImpl<LinkOrgForEippVO> implements ILinkOrgForEippServices { 

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(LinkOrgForEippServiceImpl.class); 
	
	/** The Constant CHILD_PARAM1. */
	private static final String CHILD_PARAM1="CNTR_PARTY_ERP_ID";
	
	
	/** The link org eipp dao. */
	@Autowired
	private ILinkOrgForEippDAO linkOrgEippDAO; 
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.AbstractServiceImpl#getDAO()
	 */
	@Override
	public IAbstractDAO<LinkOrgForEippVO> getDAO() {	 
		return linkOrgEippDAO;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.admin.ILinkOrgForEippServices#getLinkOrgEippDetails(com.bnp.eipp.services.vo.admin.LinkOrgForEippVO)
	 */
	@Override
	public List<LinkOrgForEippVO> getLinkOrgEippDetails(LinkOrgForEippVO searchVO) throws BNPApplicationException {		
		return linkOrgEippDAO.getLinkOrgEippDetails(searchVO);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.admin.ILinkOrgForEippServices#getCustomerOrgIdList(java.lang.String)
	 */
	@Override
	public List<NameValueVO> getCustomerOrgIdList(String userId,String userType)throws BNPApplicationException {
		List<NameValueVO> custOrgList=null;
		if(BNPConstants.BANKADMIN.equalsIgnoreCase(userType)){
			custOrgList=linkOrgEippDAO.getCustomerOrgIdListBA(userId); 
		}
		else if(BNPConstants.BCMMPOA.equalsIgnoreCase(userType)||BNPConstants.BCMMPALL.equalsIgnoreCase(userType)
				|| BNPConstants.SCMMPOA.equalsIgnoreCase(userType)|| BNPConstants.SCMMPALL.equalsIgnoreCase(userType)){
			custOrgList=linkOrgEippDAO.getCustomerOrgIdListMPOA(userId); 
		}
		else{
			custOrgList=linkOrgEippDAO.getCustomerOrgIdListOA(userId);
		}		
		return custOrgList;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.admin.ILinkOrgForEippServices#getCounterPartyOrgIdList(java.lang.String)
	 * Added additional input 'String userType' -TD:5634
	 */
	@Override
	public List<NameValueVO> getCounterPartyOrgIdList(String primeOrgId,String primeOrgType,String userId,String userType)throws BNPApplicationException {
		NameValueVO inDet=new NameValueVO();
		inDet.setValue(primeOrgId);
		inDet.setName(userId);
		inDet.setType(userType);
		
		if(BNPConstants.BCMMPB.equalsIgnoreCase(primeOrgType) ||BNPConstants.SCMMPS.equalsIgnoreCase(primeOrgType)){
			return linkOrgEippDAO.getMPCounterPartyOrgIdList(inDet);
		}
		else{
			return linkOrgEippDAO.getCounterPartyOrgIdList(inDet);
		}		
		
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.admin.ILinkOrgForEippServices#getBillTypeList(java.lang.String)
	 */
	@Override
	public List<NameValueVO> getBillTypeList(String orgId)throws BNPApplicationException {
		return linkOrgEippDAO.getBillTypeList(orgId);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.admin.ILinkOrgForEippServices#getBillTypeRuleDetails(java.lang.String, java.lang.String)
	 */
	@Override
	public LinkOrgForEippVO getBillTypeRuleDetails(String custOrgId,String billType) throws BNPApplicationException {
		if(custOrgId!=null && billType!=null){
			Map<String, Object> detMap=new HashMap<String, Object>();
			detMap.put("custOrgId", custOrgId);
			detMap.put("billType", billType);
			return linkOrgEippDAO.getBillTypeRuleDetails(detMap);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.admin.ILinkOrgForEippServices#getOrganizationRole(java.lang.String)
	 */
	@Override 
	public NameValueVO getOrganizationRole(String orgId)throws BNPApplicationException { 
		return linkOrgEippDAO.getOrganizationRole(orgId);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.admin.ILinkOrgForEippServices#getOrgDeparmentList(java.lang.String)
	 */
	@Override
	public List<NameValueVO> getOrgDeparmentList(String orgId)throws BNPApplicationException {
		return linkOrgEippDAO.getOrgDeparmentList(orgId);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.admin.ILinkOrgForEippServices#chkDependencyBeforDelete(com.bnp.eipp.services.vo.admin.LinkOrgForEippVO)
	 */
	@Override
	public boolean chkDependencyBeforDelete(LinkOrgForEippVO searchVO)throws BNPApplicationException {
		boolean flag=true;
		
		int count=linkOrgEippDAO.chkDependencyBeforDelete(searchVO);
		if(count==0){
			flag=false;
		}
		else if(count>0){
			flag=true;
		}		
		return flag;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.admin.ILinkOrgForEippServices#chkRecordAlreadyExists(com.bnp.eipp.services.vo.admin.LinkOrgForEippVO)
	 */
	@Override
	public boolean chkRecordAlreadyExists(LinkOrgForEippVO searchVO)throws BNPApplicationException {
		boolean flag=true;
		
		int count=linkOrgEippDAO.chkRecordAlreadyExists(searchVO);
		if(count==0){
			flag=false;
		}
		else if(count>0){
			flag=true;
		}		
		return flag;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.admin.ILinkOrgForEippServices#getChildDetails(long, java.lang.String)
	 */
	@Override
	public LinkOrgForEippVO getChildDetails(long pkId, String masterStatus)throws BNPApplicationException {

		LinkOrgForEippVO detailVO=new LinkOrgForEippVO();
		detailVO.setPkId(pkId);
		detailVO.setMasterRecordStatus(masterStatus);
		detailVO.setFieldName(CHILD_PARAM1);
		detailVO.setListOfErp(linkOrgEippDAO.getChildDetails(detailVO));

		return detailVO;
	
	}

	@Override
	public LinkOrgForEippVO viewAuditLinkOrgEipp(LinkOrgForEippVO linkOrgVO)throws BNPApplicationException {
		LinkOrgForEippVO modifiedRecord=linkOrgEippDAO.viewAuditLinkOrgEipp(linkOrgVO);	
		if(modifiedRecord!=null){
			linkOrgVO = modifiedRecord;
		}
	return linkOrgVO;
	}

	@Override
	public long getDepartmentForDisputeResolution(Map<String, Object> params)
			throws BNPApplicationException {
		return linkOrgEippDAO.getDepartmentForDisputeResolution(params);
	}

	@Override
	public LinkOrgForEippVO getBillTypeDeptDetails(String custOrgId,String billType) throws BNPApplicationException {
		if(custOrgId!=null && billType!=null){
			Map<String, Object> detMap=new HashMap<String, Object>();
			detMap.put("custOrgId", custOrgId);
			detMap.put("billType", billType);
			return linkOrgEippDAO.getBillTypeDeptDetails(detMap);
		}
		return null;
	}

	@Override
	public List<NameValueVO> getCounterPartyOrgIdListSummary(String userId, String userType) throws BNPApplicationException {
		NameValueVO inDet=new NameValueVO();			
		inDet.setName(userId);
		inDet.setType(userType);
	
		return linkOrgEippDAO.getCounterPartyOrgIdListSummary(inDet);
	}

	@Override
	public List<NameValueVO> getMarketPlaceOrgList(LinkOrgForEippVO searchVO)throws BNPApplicationException {
	
		return linkOrgEippDAO.getMarketPlaceOrgList(searchVO);
	}

	
}
