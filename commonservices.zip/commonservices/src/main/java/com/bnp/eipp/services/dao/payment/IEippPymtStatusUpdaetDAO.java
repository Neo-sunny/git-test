/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   24 August 2012 
 * 
 * Purpose:     EIPP Payment Status Update DAO Interface
 * 
 * Change History: 
 * Date                        Author                    Version							 Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 *  24 Aug  2012             Reena S               Initial Version		

 *****************************************************************************************************************************************************************/


package com.bnp.eipp.services.dao.payment;

import java.util.List;

import com.bnp.eipp.services.dao.filemgmt.IEippAbstractFileReleaseDAO;
import com.bnp.eipp.services.invoice.vo.EippPymtStatusUpdateVO;
import com.bnp.eipp.services.vo.payment.EippPaymentMsgDetailVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.BNPRuntimeException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;

// TODO: Auto-generated Javadoc
/**
 * The Interface IEippPymtStatusUpdaetDAO.
 */
public interface IEippPymtStatusUpdaetDAO extends IEippAbstractFileReleaseDAO {
	
	/**
	 * Insert Valid Payment Status update file Records into the table
	 *
	 * @param statusUpdateList the status update list
	 * @param fileVO the file vo
	 * @throws BNPRuntimeException the bNP runtime exception
	 */
	void insertStatusUpdateList(List<EippPymtStatusUpdateVO> statusUpdateList,FileDetailsVO fileVO) throws BNPRuntimeException;
	
	/**
	 * Gets the payment details for the Payment Ref No.
	 *
	 * @param pymtRefNo the pymt ref no
	 * @return the payment details
	 * @throws BNPApplicationException the bNP application exception
	 */
	EippPymtStatusUpdateVO getPaymentDetails(String pymtRefNo)throws BNPApplicationException;
	
	/**
	 * Gets the billing details for the Ref No.
	 *
	 * @param billRefNo the bill ref no
	 * @return the billing details
	 * @throws BNPApplicationException the bNP application exception
	 */
	EippPymtStatusUpdateVO getBillingDetails(String billRefNo)throws BNPApplicationException;
	
	/**
	 * Gets the split payment details.
	 *
	 * @param statusVO the status vo
	 * @return the split payment details
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippPymtStatusUpdateVO> getSplitPaymentDetails(EippPymtStatusUpdateVO statusVO)throws BNPApplicationException;
	
	/**
	 * Gets the valid Payment Status update file Records.
	 *
	 * @param fileId the file id
	 * @return the valid pymt status records
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippPymtStatusUpdateVO> getValidPymtStatusRecords(Long fileId)throws BNPApplicationException;
	
	EippPaymentMsgDetailVO getAllPaymentDetForUpdate(String pymtRefNo) throws BNPApplicationException;
	
	void updatePaymentStatusInSplit(EippPaymentMsgDetailVO allDet, EippPymtStatusUpdateVO stsUpdVo) throws BNPApplicationException;
	
	void updatePaymentStatusInMaster(EippPaymentMsgDetailVO allDet) throws BNPApplicationException;
	
	int getAllSplitSuccess(EippPaymentMsgDetailVO allDet) throws BNPApplicationException;
	
	int getAnySplitFail(EippPaymentMsgDetailVO allDet) throws BNPApplicationException;

	EippPaymentMsgDetailVO getAllBillingDetForUpdate(String refNo) throws BNPApplicationException;

	void updateBillingStatusInMaster(EippPaymentMsgDetailVO allDet) throws BNPApplicationException;
	
}
