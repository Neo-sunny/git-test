/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   * 06 MARCH  2012 
 * 
 * Purpose:     Invoice Cancellation DAO Interface
 * 
 * Change History: 
 * Date                                                  Author                         Version							 Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 *  * 06 MARCH  2012                     Oracle Financial Services Software Ltd            Initial Version		Added for new screen invoice cancellation
 * 12-July 2012                    		 Oracle Financial Services Software Ltd            EIPP Phase II - Cancel Invoice MFU
 *****************************************************************************************************************************************************************/


package com.bnp.eipp.services.dao.invoice;

import java.util.List;
import java.util.Map;

import com.bnp.eipp.services.dao.filemgmt.IEippAbstractFileReleaseDAO;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.scm.services.common.vo.AttachmentVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceCancelVO;
import com.bnp.eipp.services.vo.invoice.InvoiceCancellationVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.BNPRuntimeException;
import com.bnp.scm.services.common.vo.NameValueVO;

public interface IEippInvoiceCancellationDAO extends IEippAbstractFileReleaseDAO {

	/**
	 * API to fetch the invoice details 
	 * @param objInvVO : VO containing the invoice details 
	 * @return list : containing the invoice details 
	 * @throws BNPApplicationException : thrown when there is an exception 
	 */
	List<InvoiceCancellationVO> getInvoiceDetails(InvoiceCancellationVO objInvVO)throws BNPApplicationException;

	
	/**
	 * API to get the invoice line item details 
	 * @param invoiceId: the invoice Identifier 
	 * @return list conatining the invoice line item details 
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	List<EippInvCntLineItemVO> getInvoiceLineItemDetails(long invoiceId)throws BNPApplicationException;

	
	/**
	 * API To get the custom feild details
	 * @param invoiceId : the invoice identifier 
	 * @return list : containing teh custom feild details 
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	List<NameValueVO> getInvoiceCustomFields(long invoiceId)throws BNPApplicationException;
	
	/**
	 * 	API to the line item custom details 
	 * @param invcLineItemId : line item identifier  
	 * @return list : containing the invoice custom line item details 
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	List<NameValueVO> getInvcLineItemCustomFields(long invcLineItemId)throws BNPApplicationException;

	/**
	 * API To get the invoice details 
	 * @param invoiceId : invoice identifier 
	 * @return list containing the elements to be populated in Details page 
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	List<EippInvCntLineItemVO> getInvoiceDetailsFields(long invoiceId)throws BNPApplicationException;

	/**
	 * API to get the audit record details 
	 * @param invoiceId : invoice identifier 
	 * @return list : containing the audit record details 
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	List<InvoiceCancellationVO> getInvoiceAuditRecDetails(long invoiceId)throws BNPApplicationException;

	/**
	 * To get the line item audit details 
	 * @param lineItemId : line item identifier 
	 * @return list : containing the line item audit details 
	 *@throws BNPApplicationException : thrown when there is an exception
	 */
	List<InvoiceCancellationVO> getLineItemAuditDetails(long lineItemId)throws BNPApplicationException;

	/**
	 * API to cancel the record
	 * @param invoiceId : invoice identifier 
	 * @param discountRequestCancelled 
	 * @param strUser 
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	int cancelRecord(long invoiceId, String strUser, String discountRequestCancelled)throws BNPApplicationException;

	/**
	 * API to cancel the audit records 
	 * @param invoiceId : invoice identifer 
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	void cancelAuditRecord(long invoiceId)throws BNPApplicationException;

	/**
	 * API to approve the record 
	 * @param lInvId : invoice id 
	 * @param strUserId : the logged in user id 
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	int approveRecord(long lInvId, String strUserId, String strStatus)throws BNPApplicationException;

	/**
	 * API to approve the audit records 
	 * @param lInvId : invoice identifier 
	 * @param strUserId : user ID 
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	void approveAuditRecord(long lInvId)throws BNPApplicationException;

	/**
	 * API to get the attachment details 
	 * @return
	 * @throws BNPApplicationException : thrown when there is an exception
	 */
	List<AttachmentVO> getAttachmentDetails(long lInvoiceId)throws BNPApplicationException;

	/**
	 * TO fetch the dual control status of the organization Id for the user
	 * @param strUserId: logged in user Id
	 * @return String : status of the control status
	 * @throws BNPApplicationException
	 */
	String getDualControlStatus( String strUserId)
			throws BNPApplicationException;


	/**
	 * API to get Buyer Org Id for Suggestion box
	 * @param userId: USER iD 
	 * @param userType: TYPE OF USER 
	 * @return List of Org Id 
	 * @throws BNPApplicationException : thrown in case of exceptions
	 */
	List<NameValueVO> fetchBuyerOrgList(String userId, String userType)	throws BNPApplicationException;


	/**
	 * API to get Supplier Org Id for Suggestion box
	 * @param userId: USER iD 
	 * @param userType: TYPE OF USER 
	 * @return List of Org Id 
	 * @throws BNPApplicationException : thrown in case of exceptions
	 */
	List<NameValueVO> fetchSupplierOgList(String userId, String userType)throws BNPApplicationException;


	/**
	 * @param cancelInvoiceVO
	 * @return
	 */
	List<InvoiceCancellationVO> getCancelInvoiceDetails(long fileId, String status) throws BNPApplicationException;;


	/**
	 * @param fileId
	 * @return
	 */
	List<InvoiceCancellationVO> getCancelInvoiceList(long fileId);


	/**
	 * @param invoiceId
	 * @return
	 * @throws BNPApplicationException
	 */
	InvoiceCancellationVO getInvoiceForBusinessValidation(long invoiceId) throws BNPApplicationException;


	/**
	 * @param long pkId
	 * @param int errorCode
	 */
	void updateCancelInvoiceErrorCode(long pkId, int errorCode);


	/**
	 * @param string 
	 * @return
	 */
	String getCreditNoteUtilStatus(String string);


	/**
	 * @param params 
	 * @param checkStatus
	 * @return
	 * @throws BNPApplicationException
	 */
	int isInvoiceExistsForCancel(Map<String, Object> params, String checkStatus)
			throws BNPApplicationException;


	/**
	 * checks the EIPP invoice table whether invoices are available & eligible for cancellation
	 * @param EippInvoiceCancelVO
	 * @return int count of invoices
	 * @throws BNPRuntimeException the bNP runtime exception
	 */
	int isInvoiceAvailableForCancel(EippInvoiceCancelVO eippInvoiceCancelVO)
			throws BNPApplicationException;


	/**
	 * @param fileId
	 * @param deleteRecord
	 * @throws BNPApplicationException 
	 */
	void updateRecordStatusInTrans(long fileId, String deleteRecord) throws BNPApplicationException;


	/**
	 * @param fileId
	 * @return
	 */
	List<EippInvoiceVO> getModifyInvoiceList(long fileId) throws BNPApplicationException;


	/**
	 * @param invId
	 * @param errorCode
	 */
	void updateInvoiceErrorCode(long invId, int errorCode);

}
