/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 9, 20126:50:27 PM
 * 
 * Purpose:      DepartmentApprovalServiceImpl.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 9, 20126:50:27 PM        Oracle Financial Services Software Ltd                  Initial Version
 * Mar 10 2012 			        Oracle Financial Services Software Ltd                  UT Fixes  
 * Apr 3,2012       			Oracle Financial Services Software Ltd                  ST Defect #5812 and #5813
 * 18 April 2012				Sandhya R				  								SIT #2020 and #2017
 * 21 April 2012				Sandhya R				  								SIT #1997
 * 21 April 2012				Sandhya R				  								SIT #1997
 * 27/04/2012					Sandhya R												R2.1 SIT Defect #2142 - Added a boolean parameter for fetching record to diff from pending action access
 * 07/09/2012					Sandhya R												R3.0 Auto Payment Preparation Changes
 * 30 Oct 2012 		 			Arun G													Events ST Issues
************************************************************************************************************************************************************/
package com.bnp.eipp.services.invoice;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnp.eipp.services.dao.invoice.IDepartmentApprovalDao;
import com.bnp.eipp.services.dispute.IDisputeMgmtService;
import com.bnp.eipp.services.invoice.util.EippAuditConstants;
import com.bnp.eipp.services.invoice.vo.EippAuditVO;
import com.bnp.eipp.services.invoice.vo.EippCreditNoteUtilVO;
import com.bnp.eipp.services.invoice.vo.EippCustFieldsVO;
import com.bnp.eipp.services.invoice.vo.EippDeptDisplayVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.payment.preparation.IPymtPreparationService;
import com.bnp.eipp.services.vo.dispute.DisputeVO;
import com.bnp.scm.services.common.TransactionServiceImpl;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.event.EventType;
import com.bnp.scm.services.common.event.IEventDelegate;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.common.vo.AttachmentVO;
import com.bnp.scm.services.common.vo.EventLogVO;
import com.bnp.scm.services.common.vo.NameValueVO;

/**
 * The Class DepartmentApprovalServiceImpl.
 *
 * @author SandhyaRad
 */
@Component
public class DepartmentApprovalServiceImpl extends TransactionServiceImpl implements IDepartmentApprovalService {
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(DepartmentApprovalServiceImpl.class);
	
	/** The dept approve dao. */
	@Autowired
	private IDepartmentApprovalDao deptApproveDao;
	
	/** The dispute service. */
	@Autowired
	private IDisputeMgmtService disputeService;
	
	/** The event delegate impl. */
	@Autowired
	private IEventDelegate eventDelegateImpl;
	
	/** The eipp inv service. */
	@Autowired
	private IEippInvoiceService eippInvService;
	
	@Autowired
	private IPymtPreparationService pymtPrepService;

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IDepartmentApprovalService#fetchDeptApprovalSummary(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public List<EippInvoiceVO> fetchDeptApprovalSummary(EippInvoiceVO invoiceVO , boolean isPendingAction)
			throws BNPApplicationException {
		return deptApproveDao.fetchDeptApprovalSummary(invoiceVO, isPendingAction);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IDepartmentApprovalService#getCustomFieldsForInvoice(java.lang.String)
	 */
	@Override
	public List<EippCustFieldsVO> getCustomFieldsForInvoice(long invId) throws BNPApplicationException {
		return deptApproveDao.getCustomFieldsForInvoice(invId);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IDepartmentApprovalService#getCntUtilList(long)
	 */
	@Override
	public List<EippCreditNoteUtilVO> getCntUtilList(long invId)
			throws BNPApplicationException {
		return deptApproveDao.getCntUtilList(invId);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IDepartmentApprovalService#getInvLineItems(com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO)
	 */
	@Override
	public List<EippInvCntLineItemVO> getInvLineItems(
			EippInvCntLineItemVO inputVO) throws BNPApplicationException {
		return deptApproveDao.getInvLineItems(inputVO);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IDepartmentApprovalService#getInvDisputeList(long)
	 */
	@Override
	public List<DisputeVO> getInvDisputeList(long invId)
			throws BNPApplicationException {
		return disputeService.getDisputeDetailSummary(invId);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IDepartmentApprovalService#approveInvoice(java.util.List)
	 */
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public Map<String,List<Integer>> approveInvoice(List<EippInvoiceVO> invoiceVOs)
			throws BNPApplicationException {
		
		Map<String,List<Integer>> result= new HashMap<String,List<Integer>> ();
		
		List<Integer> successList = null;
		
			successList =  new ArrayList<Integer>();
			
			for(EippInvoiceVO invoiceVO : invoiceVOs){
				invoiceVO.setChangedStatus(StatusConstants.APPROVED);
				deptApproveDao.approveInvoiceInDeptAllocMap(invoiceVO);
				successList.add(ErrorConstants.DATA_COMMON_APPROVE);
				checkForApproval(invoiceVO);
			}
			
		result.put("Success", successList);
		
		return result;
	}
	
	
	/**
	 * Check for approval.
	 *
	 * @param invoiceVO the invoice vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void checkForApproval(EippInvoiceVO invoiceVO) throws BNPApplicationException{
		List<Integer> _temp = deptApproveDao.getPendingInvForApprovalCount(invoiceVO);
		if( _temp!=null && _temp.size()>0){
			if(_temp.contains(invoiceVO.getDeptAllocMap().getAllocLevel())){
				invoiceVO.setInvStatus(StatusConstants.EIPP_DEPT_APPR_APPROVAL_IN_PROGRESS);
				deptApproveDao.approveInvoice(invoiceVO);
				createInvoiceAudit(invoiceVO,EippAuditConstants.INV_APPROVAL_IN_PROGRESS);
			}else{
				invoiceVO.setInvStatus(StatusConstants.EIPP_DEPT_APPR_PARTIALLY_APPROVED);
				deptApproveDao.approveInvoice(invoiceVO);
				insertEventLog(invoiceVO , EventType.INVOICE_PARTIALLY_APPROVED );
				createInvoiceAudit(invoiceVO,EippAuditConstants.INV_PARTIALLY_APPROVED);
			}
			
		}else{
			invoiceVO.setInvStatus(StatusConstants.APPROVED);
			deptApproveDao.approveInvoice(invoiceVO);
			pymtPrepService.autoPaymentPreparation(invoiceVO);
			insertEventLog(invoiceVO , EventType.INVOICE_FULLY_APPROVED );
			createInvoiceAudit(invoiceVO,EippAuditConstants.INV_APPROVED);
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IDepartmentApprovalService#getUsersListForReassigning(java.util.List)
	 */
	@Override
	public List<String> getUsersListForReassigning(
			EippInvoiceVO invoiceVO) throws BNPApplicationException {
		return deptApproveDao.getUsersListForReassigning(invoiceVO);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IDepartmentApprovalService#getDepartmentListForReassigning(java.util.List)
	 */
	@Override
	public List<EippDeptDisplayVO> getDepartmentListForReassigning(
			EippInvoiceVO invoiceVO) throws BNPApplicationException {
		return deptApproveDao.getDepartmentListForReassigning(invoiceVO);
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IDepartmentApprovalService#getExistingAssignees(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	public List<NameValueVO> getExistingAssignees(EippInvoiceVO invoiceVO) throws BNPApplicationException{
		return deptApproveDao.getExistingAssignees(invoiceVO);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IDepartmentApprovalService#changeStatusToPending(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public void changeStatusToPending(EippInvoiceVO invoiceVO)
			throws BNPApplicationException {
		invoiceVO.setInvStatus(StatusConstants.EIPP_DEPT_APPR_PENDING);
		deptApproveDao.changeStatusToPending(invoiceVO);
		invoiceVO.setLastUpdatedTimestamp(deptApproveDao.getLastUpdatedTS(invoiceVO.getInvId()));
		createInvoiceAudit(invoiceVO,EippAuditConstants.INV_PENDING);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IDepartmentApprovalService#reassignInvoices(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public void reassignInvoices(EippInvoiceVO invoiceVO) throws BNPApplicationException {
		invoiceVO.getDeptAllocMap().setAllocType(StatusConstants.REASSIGNED);
		if(invoiceVO.getDeptAllocMap().getReassignDeptList()!=null && !invoiceVO.getDeptAllocMap().getReassignDeptList().isEmpty()){
			invoiceVO.getDeptAllocMap().setUserId("*");
			deptApproveDao.reassignToDepartments(invoiceVO);
		}if(invoiceVO.getDeptAllocMap().getReassignUserList()!=null && !invoiceVO.getDeptAllocMap().getReassignUserList().isEmpty()){
			deptApproveDao.reassignToUsers(invoiceVO);
		}
		createInvoiceAudit(invoiceVO,EippAuditConstants.INV_REASSIGNED);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IDepartmentApprovalService#getLineItemsForInvoice(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public List<EippInvCntLineItemVO> getLineItemsForInvoice(EippInvoiceVO invoiceVO)
			throws BNPApplicationException {
		List<EippInvCntLineItemVO> _tmpList = null;
		_tmpList =  deptApproveDao.getLineItemsForInvoice(invoiceVO);
		if(_tmpList!=null && _tmpList.size()>0){
			for(EippInvCntLineItemVO _tmpVO: _tmpList){
				_tmpVO.setOldDeptIds(deptApproveDao.getOldDeptIds(_tmpVO));
				_tmpVO.setNewDeptIds(deptApproveDao.getNewDeptIds(invoiceVO));
			}
		}
		return _tmpList;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IDepartmentApprovalService#rejectInvoices(java.util.List)
	 */
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public Map<String, List<Integer>> rejectInvoices(
			List<EippInvoiceVO> invoiceVOs) throws BNPApplicationException {
		
		Map<String,List<Integer>> result= new HashMap<String,List<Integer>> ();
		
		List<Integer> successList = null;
		
			successList = new ArrayList<Integer>();
			for(EippInvoiceVO invoiceVO : invoiceVOs){
				invoiceVO.setInvStatus(StatusConstants.NEW_STATUS);
				deptApproveDao.rejectInvoice(invoiceVO);
				createInvoiceAudit(invoiceVO,EippAuditConstants.INV_REJECTED);
				successList.add(ErrorConstants.DEPT_APPR_REJECT_SUCCESS);
			}
		
		result.put("Success", successList);
		
		return result;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IDepartmentApprovalService#getInvoiceAuditDetails(long)
	 */
	@Override
	public List<EippAuditVO> getInvoiceAuditDetails(long invId)
			throws BNPApplicationException {
		return deptApproveDao.getInvoiceAuditDetails(invId);
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IDepartmentApprovalService#getInvoiceLineItemAuditDetails(long)
	 */
	@Override
	public List<EippAuditVO> getInvoiceLineItemAuditDetails(long lineItemId)
			throws BNPApplicationException {
		return deptApproveDao.getInvoiceLineItemAuditDetails(lineItemId);
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IDepartmentApprovalService#approveInvoiceLineItems(java.util.List)
	 */
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public Map<String, List<Integer>> approveInvoiceLineItems(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException {
		List<EippInvCntLineItemVO> lintItems = eippInvoiceVO.getLineItemList();
		Map<String,List<Integer>> result= new HashMap<String,List<Integer>> ();
		List<Integer> successList = null;
		successList = new ArrayList<Integer>();
		
		for(EippInvCntLineItemVO invoiceVO : lintItems){
			
			invoiceVO.setChangedStatus(StatusConstants.APPROVED);
			deptApproveDao.approveInvoiceLineItemInDeptAllocMap(invoiceVO);
			successList.add(ErrorConstants.DATA_COMMON_APPROVE);
			checkForLineItemApproval(invoiceVO);
		}
		
		EippInvoiceVO _temp = new EippInvoiceVO();
		_temp.setInvId(lintItems.get(0).getFkId());
		_temp.setCurrentUserId(lintItems.get(0).getCurrentUserId());
		_temp.setBuyerOrgId(lintItems.get(0).getBuyerOrgId());
		_temp.getDeptAllocMap().setAllocLevel(lintItems.get(0).getAllocLevel());
		_temp.setInvStatus(deptApproveDao.getInvStatusFromLineItem(_temp));
		deptApproveDao.approveInvoiceForLinetItem(_temp);
		if(_temp.getInvStatus()!=null && _temp.getInvStatus().equals(StatusConstants.EIPP_DEPT_APPR_PARTIALLY_APPROVED)){
			insertEventLog(_temp , EventType.INVOICE_PARTIALLY_APPROVED );
			createInvoiceAudit(_temp,EippAuditConstants.INV_PARTIALLY_APPROVED);
		}else if(_temp.getInvStatus()!=null && _temp.getInvStatus().equals(StatusConstants.APPROVED)){
			insertEventLog(_temp , EventType.INVOICE_FULLY_APPROVED );
			pymtPrepService.autoPaymentPreparation(eippInvoiceVO);
			createInvoiceAudit(_temp,EippAuditConstants.INV_APPROVED);
		}else if(_temp.getInvStatus()!=null && _temp.getInvStatus().equals(StatusConstants.EIPP_DEPT_APPR_APPROVAL_IN_PROGRESS)){
			createInvoiceAudit(_temp,EippAuditConstants.INV_APPROVAL_IN_PROGRESS);
		}
		result.put("Success", successList);
		return result;
	}
	
	/**
	 * Check for line item approval.
	 *
	 * @param invLineItemVO the inv line item vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void checkForLineItemApproval(EippInvCntLineItemVO invLineItemVO) throws BNPApplicationException{

		List<Integer> _tmp = deptApproveDao.getPendingInvLnItmForApprovalCount(invLineItemVO);

		if( _tmp!= null && _tmp.size()>0){
			if(_tmp.contains(invLineItemVO.getAllocLevel())){
				invLineItemVO.setLineItemStatus(StatusConstants.EIPP_DEPT_APPR_APPROVAL_IN_PROGRESS);
				deptApproveDao.approveLineItemLevel(invLineItemVO);
				createInvLineItemAudit(invLineItemVO,EippAuditConstants.INV_APPROVAL_IN_PROGRESS);
			}else{
				invLineItemVO.setLineItemStatus(StatusConstants.EIPP_DEPT_APPR_PARTIALLY_APPROVED);
				deptApproveDao.approveLineItemLevel(invLineItemVO);
				createInvLineItemAudit(invLineItemVO,EippAuditConstants.INV_PARTIALLY_APPROVED);
			}
		}else {
			invLineItemVO.setLineItemStatus(StatusConstants.APPROVED);
			deptApproveDao.approveLineItemLevel(invLineItemVO);
			createInvLineItemAudit(invLineItemVO,EippAuditConstants.INV_APPROVED);
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.fb.cioservices.invoice.IDepartmentApprovalService#reassignInvoiceLineItems(com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO)
	 */
	@Override
	public Map<String, List<Integer>> reassignInvoiceLineItems(List<EippInvCntLineItemVO> inputVO)
			throws BNPApplicationException {
		Map<String,List<Integer>> result= new HashMap<String,List<Integer>> ();
		
		List<Integer> successList = new ArrayList<Integer>();
		for(EippInvCntLineItemVO _tmp: inputVO){
			
				EippInvoiceVO _temp = new EippInvoiceVO();
				_temp.setInvId(_tmp.getFkId());
				_temp.setCurrentUserId(_tmp.getCurrentUserId());
				_temp.getDeptAllocMap().setAllocLevel(_tmp.getAllocLevel());
				_temp.setInvStatus(_tmp.getLineItemStatus());
				deptApproveDao.approveInvoiceForLinetItem(_temp);
				
				deptApproveDao.reassignInvoiceLineItems(_tmp);
				successList.add(ErrorConstants.REASSIGNED_INVOICE_LN_ITMS);
				
				createInvLineItemAudit(_tmp,EippAuditConstants.INV_REASSIGNED);
				
		}
		result.put("Success", successList);
		
		return result;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IDepartmentApprovalService#uploadInvoiceAttachment(com.bnp.eipp.services.vo.dispute.AttachmentVO)
	 */
	@Override
	public void uploadInvoiceAttachment(AttachmentVO attachVO)
			throws BNPApplicationException {
		deptApproveDao.uploadInvoiceAttachment(attachVO);
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IDepartmentApprovalService#getAttachments(long)
	 */
	@Override
	public List<AttachmentVO> getAttachments(long invId)
			throws BNPApplicationException {
		return deptApproveDao.getAttachments(invId);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IDepartmentApprovalService#getCustomFieldsForLineItems(long)
	 */
	@Override
	public List<EippCustFieldsVO> getCustomFieldsForLineItems(long lineItemId)
			throws BNPApplicationException {
		return deptApproveDao.getCustomFieldsForLineItems(lineItemId);
	}

	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.TransactionServiceImpl#getDao()
	 */
	@Override
	public SqlMapClientWrapper getDao() {
		return (SqlMapClientWrapper) deptApproveDao;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IDepartmentApprovalService#getDisputeAttachments(com.bnp.eipp.services.vo.dispute.DisputeVO)
	 */
	@Override
	public List<AttachmentVO> getDisputeAttachments(DisputeVO dispVO)
			throws BNPApplicationException {
		return disputeService.getAttachmentDetails(dispVO);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IDepartmentApprovalService#getBuyerOrgList(com.bnp.scm.services.common.vo.NameValueVO)
	 */
	@Override
	public List<NameValueVO> getBuyerOrgList(NameValueVO input)
			throws BNPApplicationException {
		return deptApproveDao.getBuyerOrgList(input);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IDepartmentApprovalService#getSupplierOrgList(com.bnp.scm.services.common.vo.NameValueVO)
	 */
	@Override
	public List<NameValueVO> getSupplierOrgList(NameValueVO input)
			throws BNPApplicationException {
		return deptApproveDao.getSupplierOrgList(input);
		
	}
	
	/**
	 * Insert event log.
	 *
	 * @param invoiceVO the invoice vo
	 * @param eventType the event type
	 */
	private void insertEventLog(EippInvoiceVO invoiceVO, 
			EventType eventType) {
		EventLogVO eventVO = new EventLogVO();
		 
		try {
			eventVO.setReferenceKey(String.valueOf(invoiceVO.getInvId()));
			eventVO.setEventType(eventType);		
			eventVO.setBuyerOrgId(invoiceVO.getBuyerOrgId());
			if(eventType.equals(EventType.INVOICE_FULLY_APPROVED)){
				eventVO.setSellerOrgId(invoiceVO.getSupplierOrgId());	
			}
			eventDelegateImpl.initEvents(eventVO);
		} catch (BNPApplicationException e) {
			LOGGER.error("Error while raising event log : " + e );
		}
	}

	
	/**
	 * Create invoice audit.
	 *
	 * @param invoiceVO the invoice vo
	 * @param action the action
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void createInvoiceAudit(EippInvoiceVO invoiceVO, String action) throws BNPApplicationException{
		
		EippAuditVO auditVO = new EippAuditVO();
		invoiceVO.setStatus(action);
		if(EippAuditConstants.INV_REASSIGNED.equals(action) || 
				EippAuditConstants.INV_PENDING.equals(action) ){
			invoiceVO.setChangedStatus(StatusConstants.EIPP_DEPT_APPR_PENDING);
		}else{
			invoiceVO.setChangedStatus(StatusConstants.APPROVED);
		}
		List<Long> deptIds =  deptApproveDao.getDeptIds(invoiceVO);
		if(deptIds!=null && !deptIds.isEmpty()){
			auditVO.setDeptPKId(deptIds.get(0));
		}
		auditVO.setAction(action);
		auditVO.setAuditUser(invoiceVO.getCurrentUserId());
		auditVO.setInvId(invoiceVO.getInvId());
		auditVO.setStatus(invoiceVO.getInvStatus());
		
		eippInvService.createInvoiceAudit(auditVO);
	}
	
	/**
	 * Creates the inv line item audit.
	 *
	 * @param invLineIemVO the inv line iem vo
	 * @param action the action
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void createInvLineItemAudit(EippInvCntLineItemVO invLineIemVO, String action) throws BNPApplicationException{
		
		EippAuditVO auditVO = new EippAuditVO();
		
		EippInvoiceVO _temp = new EippInvoiceVO();
		_temp.setStatus(action);
		_temp.setInvId(invLineIemVO.getFkId());
		_temp.setPkId(invLineIemVO.getLineItemId());
		_temp.setCurrentUserId(invLineIemVO.getCurrentUserId());
		_temp.getDeptAllocMap().setAllocLevel(invLineIemVO.getAllocLevel());
		if(EippAuditConstants.INV_REASSIGNED.equals(action)){
			_temp.setChangedStatus(StatusConstants.EIPP_DEPT_APPR_PENDING);
		}else{
			_temp.setChangedStatus(StatusConstants.APPROVED);
		}
		
		List<Long> deptIds =  deptApproveDao.getDeptIds(_temp);
		if(deptIds!=null && !deptIds.isEmpty()){
			auditVO.setDeptPKId(deptIds.get(0));
		}
		auditVO.setAction(action);
		auditVO.setAuditUser(invLineIemVO.getCurrentUserId());
		auditVO.setInvId(invLineIemVO.getFkId());
		auditVO.setLineItemId(invLineIemVO.getLineItemId());
		auditVO.setStatus(invLineIemVO.getLineItemStatus());
		
		eippInvService.createInvLineItemAudit(auditVO);
	}

}
