/****************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14 Oct 2012
 * 
 * Purpose: Eipp Matching Invoice Message Service Impl
 * 
 * Change History: 
 * Date                       	Author                                  Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 14 Oct 2012              	Prabu P                      			Initial Version
 ********************************************************************************************************************************/

package com.bnp.eipp.services.matching.invoice;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.invoice.vo.EippCreditNoteVO;
import com.bnp.eipp.services.invoice.vo.EippCustFieldsVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.matching.dao.IEippMatchingMessageDAO;
import com.bnp.eipp.services.vo.common.EippMessageVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.dao.IEventLogDAO;
import com.bnp.scm.services.common.event.EventType;
import com.bnp.scm.services.common.event.IEventDelegate;
import com.bnp.scm.services.common.event.IEventFactory;
import com.bnp.scm.services.common.event.IEventService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.mail.BNPEmailSender;
import com.bnp.scm.services.common.vo.EventDetailsVO;
import com.bnp.scm.services.common.vo.EventLogVO;
import com.bnp.scm.services.txns.common.message.MessageSender;
import com.bnp.scm.services.txns.common.message.dao.IMessageDAO;
import com.bnp.scm.services.txns.common.message.vo.QueueConfVO;
import com.bnp.scm.services.txns.common.vo.MessageVO;
import com.bnp.scm.services.txns.util.PropertiesReader;

@Component
public class EippMatchingInvoiceMsgServiceImpl implements IEippMatchingInvoiceMsgService {

	private static final Logger LOGGER = LoggerFactory.getLogger(EippMatchingInvoiceMsgServiceImpl.class);

	@Autowired
	private IEippMatchingMessageDAO matchingMessageDAO;

	@Autowired
	private IMessageDAO messageDAO;

	@Autowired
	private IEventDelegate eventDelegate;

	@Autowired
	private IEventFactory eventFactory;

	@Autowired
	protected BNPPropertyLoaderConfigurer propertyLoader;

	@Autowired
	private BNPEmailSender emailSender;

	@Autowired
	private IEventLogDAO eventLogDAO;

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.matching.invoice.IEippMatchingInvoiceMsgService#createMessage(com.bnp.eipp.services.vo.common.EippMessageVO)
	 */
	@Override
	public void createMessage(EippMessageVO matchInvMsgVO) throws BNPApplicationException {

		Map<String, String> headerMap = matchingMessageDAO.getHeaderDetails(matchInvMsgVO.getOrgId());
		matchInvMsgVO.setHeaderMap(headerMap);

		// Get the message Id from sequence
		matchInvMsgVO.setMsgId(messageDAO.getMessageId());

		List<EippInvCntVO> invoiceGroupList = matchingMessageDAO.getMatchRecGroupList(matchInvMsgVO);

		if (invoiceGroupList != null && !invoiceGroupList.isEmpty()) {
			List<EippInvCntVO> invcCNList = new ArrayList<EippInvCntVO>(invoiceGroupList.size());

			for (EippInvCntVO invcCreditNote : invoiceGroupList) {
				invcCreditNote.setRefList(matchInvMsgVO.getRefList());
				invcCreditNote.setMatchRefNo(matchInvMsgVO.getMatchRefNo());
				List<EippInvoiceVO> invoiceList = matchingMessageDAO.getMatchingInvoiceList(invcCreditNote);
				invcCreditNote.setInvoiceList(invoiceList);
				
				if(invoiceList != null && !invoiceList.isEmpty()) {
					for (EippInvoiceVO eippInvoiceVO : invoiceList) {
						List<EippCustFieldsVO> custFieldList = matchingMessageDAO.getCustomFieldList(eippInvoiceVO);
						eippInvoiceVO.setCustFields(custFieldList);
					}
				}

				List<EippCreditNoteVO> creditNoteList = null;
				if (invoiceList != null && !invoiceList.isEmpty()) {
					creditNoteList = matchingMessageDAO.getMatchingCreditNoteList(invoiceList);
				}
				invcCreditNote.setCntList(creditNoteList);
				invcCNList.add(invcCreditNote);
			}
			matchInvMsgVO.setDataList(invcCNList);
			EippMatchingInvoiceMessage message = new EippMatchingInvoiceMessage();
			message.constructMessage(matchInvMsgVO);
			LOGGER.debug("EippMatchingInvoiceMessage :: Message created successfully");
			matchInvMsgVO.setXmlMessage(message.getXmlMessage());

			if (message.getXmlMessage() != null) {
				matchInvMsgVO.getMessageVO().setData(message.getXmlMessage().getBytes());
			}
		}
		else {
			throw new BNPApplicationException("No records found :: " + matchInvMsgVO.getOrgId());
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.matching.invoice.IEippMatchingInvoiceMsgService#saveMessage(com.bnp.scm.services.txns.common.vo.MessageVO)
	 */
	@Override
	public void saveMessage(MessageVO messageVO) throws BNPApplicationException {
		messageVO.setSource(BNPConstants.FO);
		messageVO.setStatus(BNPConstants.EVENT_INITIATED);
		if (messageVO.getCreatedBy() == null) {
			messageVO.setCreatedBy(BNPConstants.SYSTEM);
		}
		messageDAO.saveMessage(messageVO);
		LOGGER.debug("EippMatchingInvoiceMessage :: Message saved successfully");
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.matching.invoice.IEippMatchingInvoiceMsgService#sendEmailAndH2HMessage(com.bnp.eipp.services.vo.common.EippMessageVO)
	 */
	@Override
	public void sendEmailAndH2HMessage(EippMessageVO matchInvMsgVO) throws BNPApplicationException {

		if(matchInvMsgVO.getFileRefId() != null) {		
			List<String> fileIdList = matchingMessageDAO.getFileIdList(matchInvMsgVO.getFileRefId());
			matchInvMsgVO.setRefList(fileIdList);
		}

		EventLogVO eventLogVO = new EventLogVO();
		eventLogVO.setEventType(EventType.EIPP_MATCHING_AUTO_MATCH);
		eventLogVO.setEventNameId(EventType.EIPP_MATCHING_AUTO_MATCH.value());
		eventLogVO.setBranchId(matchInvMsgVO.getBranchId());
		eventLogVO.setEventInitiator(matchInvMsgVO.getCurrentUserId());
		eventLogVO.setSellerOrgId(matchInvMsgVO.getOrgId());

		// prepare and send message to org user as email
		List<EventDetailsVO> eventDetailsList = eventDelegate.getEventDetails(eventLogVO);
		if (eventDetailsList != null) {
			for (EventDetailsVO eventDetailsVO : eventDetailsList) {
				if (BNPConstants.YES.equals(eventDetailsVO.getEmailOpted())) {
					generateEmailMessage(matchInvMsgVO, eventLogVO, eventDetailsVO);
				}
			}
		}

		// prepare and send message to H2H
		generateH2HMessage(matchInvMsgVO);
	}

	/**
	 * Generate Message
	 * @param matchInvMsgVO
	 * @throws BNPApplicationException
	 */
	public void generateH2HMessage(EippMessageVO matchInvMsgVO) throws BNPApplicationException {
		try {
			matchInvMsgVO.setMode(BNPConstants.H2H);
			createMessage(matchInvMsgVO);
			MessageVO messageVO = matchInvMsgVO.getMessageVO();
			setBatchRefId(matchInvMsgVO);

			saveMessage(messageVO);
			matchInvMsgVO.setStatusCode(messageVO.getStatus());
			sendH2HMessage(messageVO);
			updateMsgDeliveryStatus(matchInvMsgVO);
		}
		catch (Exception e) {
			//FO 7.0 Fortify Issue Fix
			//LOGGER.error("Error while generating H2H message :: " + e);
		}
	}

	/**
	 * Generate email message
	 * @param matchInvMsgVO
	 * @param eventLogVO
	 * @param eventDetailsVO
	 */
	public void generateEmailMessage(EippMessageVO matchInvMsgVO, EventLogVO eventLogVO, EventDetailsVO eventDetailsVO) {
		try {
			matchInvMsgVO.setMode(BNPConstants.EMAIL);
			createMessage(matchInvMsgVO);
			updateEventLogVO(eventLogVO, eventDetailsVO);

			IEventService emailEventService = eventFactory.getEmailInstance(null);
			setBatchRefId(matchInvMsgVO);
			MessageVO messageVO = matchInvMsgVO.getMessageVO();
			eventLogVO.setFileData(messageVO.getData());
			eventLogVO.setReferenceKey(messageVO.getMsgRef());
			sendEmailMessage(eventDetailsVO, eventLogVO);
			emailEventService.saveEvent(eventLogVO);

			matchInvMsgVO.setStatusCode(eventLogVO.getEventDeliveryStatus());
			updateMsgDeliveryStatus(matchInvMsgVO);
		}
		catch (Exception e) {
			//FO 7.0 Fortify Issue Fix
			LOGGER.error("Error while generating email message :: " + e);
		}
	}

	/**
	 * Set message batch reference id
	 * @param matchInvMsgVO
	 */
	public void setBatchRefId(EippMessageVO matchInvMsgVO) {
		try {
			String batchRefId = matchingMessageDAO.getMatchingMsgBatchRefId();
			String msgType = "";
			if (BNPConstants.H2H.equals(matchInvMsgVO.getMode())) {
				msgType = "MTH2H";
			}
			else if (BNPConstants.ERP.equals(matchInvMsgVO.getMode())) {
				msgType = "MSERP";
			}			
			batchRefId = msgType + batchRefId;
			MessageVO messageVO = matchInvMsgVO.getMessageVO();
			if (messageVO != null) {
				messageVO.setMsgRef(batchRefId);
			}
		}
		catch (BNPApplicationException e) {
			//FO 7.0 Fortify Issue Fix
			LOGGER.error("Error while updating the invoice message delivery status :: " + e);
		}
	}

	/**
	 * Update Event Logger details
	 * @param eventLogVO
	 * @param eventDetailsVO
	 */
	private void updateEventLogVO(EventLogVO eventLogVO, EventDetailsVO eventDetailsVO) {
		eventLogVO.setEventId(new Long(eventDetailsVO.getEventId()));
		eventLogVO.setOrgId(eventDetailsVO.getOrgId());
		eventLogVO.setRole(eventDetailsVO.getOrgRole());
		eventLogVO.setChannel(BNPConstants.EMAIL);
		eventLogVO.setEventDeliveryStatus(BNPConstants.SENT);
		eventLogVO.setEventInitiator(BNPConstants.SYSTEM);
	}

	/**
	 * Update Message Delivery Status
	 * @param matchInvMsgVO
	 */
	public void updateMsgDeliveryStatus(EippMessageVO matchInvMsgVO) {
		try {
			if (BNPConstants.SENT.equalsIgnoreCase(matchInvMsgVO.getStatusCode())) {
				matchInvMsgVO.setStatusCode(BNPConstants.Y);
				matchingMessageDAO.updateMsgDeliveryStatus(matchInvMsgVO);
			}
		}
		catch (BNPApplicationException e) {
			//FO 7.0 Fortify Issue Fix
			LOGGER.error("Error while updating the invoice message delivery status :: " + e);
		}
	}

	public void sendH2HMessage(MessageVO messageVO) {
		try {
			QueueConfVO queueConfVO = new QueueConfVO();
			queueConfVO.setBranchId(messageVO.getSupportBranchId());
			queueConfVO.setMsgType(messageVO.getMsgType());
			queueConfVO.setMsgId(messageVO.getMsgId());
			queueConfVO = messageDAO.getQueueConfig(queueConfVO);
			Map<String, String> jmsProperties = getMessageProperties(queueConfVO);
			MessageSender.sendMessage(messageVO.getData(), queueConfVO.getInternalQueue(), jmsProperties);
			messageVO.setStatus(PropertiesReader.getProperty("txns.status.message.sent"));
		}
		catch (BNPApplicationException e) {
			//FO 7.0 Fortify Issue Fix
			LOGGER.error("Error while sending message :: " + e.getErrorMessage());
			String errorDesc = null;
			if (e.getErrorCode() != 0) {
				errorDesc = Integer.toString(e.getErrorCode());
			}
			else {
				errorDesc = e.getMessage();
			}
			messageVO.setStatus(PropertiesReader.getProperty("txns.status.message.failed"));
			messageVO.setErrorMessage(errorDesc);
		}
		catch (Exception e) {
			//FO 7.0 Fortify Issue Fix
			LOGGER.error("Error while sending message :: " + e);
			messageVO.setStatus(PropertiesReader.getProperty("txns.status.message.failed"));
			messageVO.setErrorMessage("Error while sending message");
		}
		finally {
			try {
				messageDAO.updateMessageStatus(messageVO);
			}
			catch (Exception e) {
				//FO 7.0 Fortify Issue Fix
				LOGGER.error("Error while updating message status :: " + e);
			}
		}
	}

	public Map<String, String> getMessageProperties(QueueConfVO queueConfVO) throws BNPApplicationException {
		Map<String, String> jmsProperties = new HashMap<String, String>();
		if (queueConfVO != null) {
			jmsProperties.put(PropertiesReader.getProperty("message.jms.header.extqueue"),
					queueConfVO.getExternalQueue());
			jmsProperties.put(PropertiesReader.getProperty("message.jms.header.bnppmsgid"), queueConfVO.getMsgId());
		}
		return jmsProperties;
	}

	protected boolean checkNull(String userInput) {
		boolean isValid = false;
		if (userInput != null && userInput.trim().length() > 0) {
			isValid = true;
		}
		return isValid;
	}

	private void sendEmailMessage(EventDetailsVO eventDetailsVO, EventLogVO eventLogVO) {

		Map<Object, Object> mailMap = new HashMap<Object, Object>();
		String toList = null;
		String ccList = null;

		try {
			Locale orgLocale = eventLogDAO.getLocale(eventDetailsVO.getOrgId());

			if (checkNull(eventDetailsVO.getIndividuals())) {
				toList = eventDetailsVO.getIndividuals();
			}
			else if (checkNull(eventDetailsVO.getToGroup())) {
				toList = eventLogDAO.getEmailIdsForGroup(eventDetailsVO.getToGroup());
			}

			if (checkNull(eventDetailsVO.getCcGroup())) {
				ccList = eventLogDAO.getEmailIdsForGroup(eventDetailsVO.getCcGroup());
			}

			mailMap.put("locale", orgLocale);
			mailMap.put("toList", toList);
			mailMap.put("ccList", ccList);
			mailMap.put("subject", eventDetailsVO.getEmailSubject());
			mailMap.put("isAttach", true);
			byte[] attachment = eventLogVO.getFileData();
			if (attachment != null) {
				mailMap.put("attachmentBytes", attachment);
			}
			String template = propertyLoader.getValue("scheduler.template.autoMatch");
			emailSender.sendMail(mailMap, template, false);
		}
		catch (Exception e) {
			eventLogVO.setEventDeliveryStatus(BNPConstants.FAILED);
			//FO 7.0 Fortify Issue Fix
			LOGGER.error("Exception while writing a XML file :: ", e);
		}
	}
}
