/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   July 11, 2012
 * 
 * Purpose:      EippInvoiceCancelVO
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Jul 18, 2012      Oracle Financial Services Software Ltd                  Initial Version  
************************************************************************************************************************************************************/

package com.bnp.eipp.services.invoice.vo;

import java.util.Calendar;

import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.txns.util.calendar.DateAdapter;

/**
 * The Class EippInvoiceCancelVO.
 */
public class EippInvoiceCancelVO extends EippTransactionVO {

	private static final long serialVersionUID = 3292189657660408988L;

	private long invId;
	
	private String invRefNo;
	
	private String invStatus;
	
	private String pymtStatus;
	
	private String errorCode;
	private String errorDescription;
	
	/**
	 * Gets the inv id.
	 *
	 * @return the invId
	 */
	public long getInvId() {
		return invId;
	}

	/**
	 * Sets the inv id.
	 *
	 * @param invId the invId to set
	 */
	public void setInvId(long invId) {
		this.invId = invId;
	}

	/**
	 * Gets the inv ref no.
	 *
	 * @return the invRefNo
	 */
	public String getInvRefNo() {
		return invRefNo;
	}

	/**
	 * Sets the inv ref no.
	 *
	 * @param invRefNo the invRefNo to set
	 */
	public void setInvRefNo(String invRefNo) {
		this.invRefNo = invRefNo;
	}

	/**
	 * Gets the inv status.
	 *
	 * @return the invStatus
	 */
	public String getInvStatus() {
		return invStatus;
	}

	/**
	 * Sets the inv status.
	 *
	 * @param invStatus the invStatus to set
	 */
	public void setInvStatus(String invStatus) {
		this.invStatus = invStatus;
	}

	/**
	 * Sets the pymt status.
	 *
	 * @param pymtStatus the pymtStatus to set
	 */
	public void setPymtStatus(String pymtStatus) {
		this.pymtStatus = pymtStatus;
	}

	/**
	 * Gets the pymt status.
	 *
	 * @return the pymtStatus
	 */
	public String getPymtStatus() {
		return pymtStatus;
	}
	
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	/**
	 * @return the errorDescription
	 */
	public String getErrorDescription() {
		return errorDescription;
	}
	/**
	 * @param errorDescription the errorDescription to set
	 */
	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.vo.EippTransactionVO#getTransactionType()
	 */
	public String getTransactionType() {
		return "INVCANCEL";
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.vo.EippTransactionVO#getRefNo()
	 */
	public String getRefNo(){
		return invRefNo;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.vo.EippTransactionVO#toDataString()
	 */
	public String toDataString() {
		DateAdapter adapter = new DateAdapter();
		Calendar calendar = Calendar.getInstance();
		StringBuilder builder = new StringBuilder();
		builder.append( getTransactionType() + ",");
		builder.append( getRefNo() + ",");
		builder.append( getSupplierOrgId() + ",");
		builder.append( getBuyerOrgId() + ",");
		if(getIssueDate() != null) {
			calendar.setTime(getIssueDate());
			builder.append( adapter.marshal(calendar)+ ",");
		} else {
			builder.append(",");
		}
		builder.append( getBillType() + ",");
		if(getRefDate() != null) {
			calendar.setTime(getRefDate());
			builder.append( adapter.marshal(calendar)+ ",");
		} else {
			builder.append(",");
		}
		return builder.toString();
	}

	public boolean isCancelled() {
		return (StatusConstants.CANCEL_PENDING_EIPP_APPROVAL.equals(invStatus) || 
				StatusConstants.INVOICE_CANCELLED.equals(invStatus));
	}
	
}
