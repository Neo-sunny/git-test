/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   18 March 2013
 * 
 * Purpose:      StandardFileService
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 March 2013        Oracle Financial Services Software Ltd                  Initial Version
************************************************************************************************************************************************************/
package com.bnp.common.services.filemgmt.filetype;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.common.services.filemgmt.processor.IAbstractDataFileProcessor;
import com.bnp.common.services.filemgmt.vo.BaseFileUploadVO;
import com.bnp.eipp.services.txns.util.file.FileProcessorEnum;
import com.bnp.scm.scheduler.service.AbstractSchedulerService;
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.scheduler.vo.ScheduleVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;
import com.bnp.scm.services.txns.common.message.bindingvo.RootXmlElement;

/**
 * @author prabakarans
 *
 */
@Component ("standardFileService")
public class StandardFileService extends AbstractFileService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(StandardFileService.class);
	
	@Autowired
	private AbstractSchedulerService schedulerService;
	
	@Autowired
	private BeanFactory beanFactory;

	@Override
	protected void processFile(FileDetailsVO detailsVO)
			throws BNPApplicationException {
		try {
			// Making sure not to create the file entry again if received from H2H
			if (detailsVO.getFileId() == 0) {
				fileProcessorService.saveFileDetails(detailsVO);
			}
		
			AbstractMessage<?> invoiceMessage = msgBuilder.prepareStandardMessage(detailsVO);
			
			if (invoiceMessage != null) { 
				processFile(invoiceMessage, detailsVO);
			}
		} catch (BNPApplicationException exception) {
			throw exception;
		}
	
	}
	
	@SuppressWarnings("unchecked")
	private void processFile(AbstractMessage<?> invoiceMessage, 
			FileDetailsVO detailsVO) throws BNPApplicationException {

		boolean isSchedulerProcessingEnabled = Boolean.valueOf(propertyLoader.getValue(
				"filemgmt.enable.thread.processing"));

		if (!isSchedulerProcessingEnabled) {
			String processorClass = FileProcessorEnum.getProcessorName(detailsVO.getFileFrmtType());

			if (processorClass != null) {
				IAbstractDataFileProcessor<? extends RootXmlElement, ? extends BaseFileUploadVO>
				processor = beanFactory.getBean(processorClass, IAbstractDataFileProcessor.class);
				processor.processFile(invoiceMessage, detailsVO);
			}
		} else {
			ScheduleVO scheduleVO = new ScheduleVO();
			Map<String,String> input = new HashMap<String, String>();
			input.put(BNPConstants.FILE_ID, String.valueOf(detailsVO.getFileId()));
			input.put(BNPConstants.MSG_TYPE, String.valueOf(detailsVO.getFileFrmtType()));
			scheduleVO.setInput(input);
			scheduleVO.setJobType(SchedulerConstants.JOB_TYPE_ADHOC);
			scheduleVO.setEventName(propertyLoader.getValue("scheduler.fileProcess.job"));
			scheduleVO.setStartDate(new Date());
			scheduleVO.setEndDate(new Date());
			schedulerService.scheduleAdhocJobs(scheduleVO);
			//Fixed for Fortify issue Log Forging debug
			//LOGGER.debug("Adhoc job inserted for File Processing for File ID - "+detailsVO.getFileId());
		}
	}

}
