/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   18 March 2013
 * 
 * Purpose:      SCFFileProcessorFactory
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 March 2013        Oracle Financial Services Software Ltd                  Initial Version
************************************************************************************************************************************************************/
package com.bnp.common.services.filemgmt.factory;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.common.services.filemgmt.filetype.AbstractFileService;
import com.bnp.scm.services.common.BNPConstants;

/**
 * @author prabakarans
 *
 */
@Component ("scfFileProcessorFactory")
public class SCFFileProcessorFactory {
	
	@Autowired
	private BeanFactory beanFactory;
	
	public AbstractFileService getFileService(String fileType) {
		AbstractFileService fileService = null;
		
		if (fileType.equalsIgnoreCase(BNPConstants.STANDARD_FILE_TYPE)) {
			fileService = getBean("standardFileService");
		} else {
			fileService = getBean("customFileService");
		}
		return fileService;
	}
	
	private AbstractFileService getBean(String instanceName) {
		return beanFactory.getBean(instanceName, AbstractFileService.class);
	}

}
