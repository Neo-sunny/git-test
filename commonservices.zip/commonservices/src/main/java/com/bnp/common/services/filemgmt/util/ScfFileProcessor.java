/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   24 Apr 2013
 * 
 * Purpose:      For SCF File Processing
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 24 Apr 2013                Arun G                 						 Initial Version  
 ******************************************************************************************************************************************************/
package com.bnp.common.services.filemgmt.util;

import java.io.UnsupportedEncodingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.bnp.common.services.filemgmt.processor.IAbstractDataFileProcessor;
import com.bnp.common.services.filemgmt.vo.BaseFileUploadVO;
import com.bnp.eipp.services.txns.util.file.FileProcessorEnum;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.interfaces.common.message.MessageFactory;
import com.bnp.scm.services.txns.common.message.AbstractMessage;
import com.bnp.scm.services.txns.common.message.bindingvo.RootXmlElement;

@Component
public class ScfFileProcessor {

	private static final Logger LOGGER = LoggerFactory.getLogger(ScfFileProcessor.class);
	
	@Autowired 
	@Qualifier("bnpMessageFactory")
	private MessageFactory messageFactory;
	
	@Autowired
	private BeanFactory beanFactory;
	
	@Autowired
	protected BNPPropertyLoaderConfigurer propertyLoader;
	
	@SuppressWarnings("unchecked")
	public void processFileData(FileDetailsVO fileDetailsVO) throws BNPApplicationException {
		try{
			String fileFormatType=fileDetailsVO.getFileFrmtType();
			fileDetailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.processing"));
			String processorClass = FileProcessorEnum.getProcessorName(fileFormatType);
			//Fixed for Fortify issue Log Forging debug
			//LOGGER.debug("File Format - "+fileDetailsVO.getFileFrmtType()+" processorClass -  "+processorClass);
			AbstractMessage<?> message=messageFactory.getMessageInstance(fileFormatType);
			if(message!=null){
				message.extractMessage(new String (fileDetailsVO.getFileData(),BNPConstants.UTF8_ENCODING));
			}else{
				//Fixed for Fortify issue Log Forging debug
				//LOGGER.debug("No Valid Message or Invalid Msg Type for the file ID - "+fileDetailsVO.getFileId()+". Process Terminates.");
				return;
			}
			if (processorClass != null) {
				IAbstractDataFileProcessor<? extends RootXmlElement, ? extends BaseFileUploadVO>
				processor = beanFactory.getBean(processorClass, IAbstractDataFileProcessor.class);
				processor.processFile(message, fileDetailsVO);
			}
		}
		catch(BNPApplicationException exception){
			LOGGER.error("Exception while Procesing File",exception);
			throw exception;
		} catch (UnsupportedEncodingException exception) {
			LOGGER.error("Exception while Procesing File",exception);
			throw new BNPApplicationException("Exception while Procesing File - ",exception);
		}

	}
}
