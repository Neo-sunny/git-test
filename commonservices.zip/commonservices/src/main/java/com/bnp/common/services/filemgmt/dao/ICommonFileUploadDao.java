/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   18 March 2013
 * 
 * Purpose:      ICommonFileUploadDao
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 March 2013        Oracle Financial Services Software Ltd                  Initial Version
************************************************************************************************************************************************************/
package com.bnp.common.services.filemgmt.dao;

import java.util.List;

import com.bnp.common.services.filemgmt.vo.BaseFileUploadVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;

public interface ICommonFileUploadDao<V extends BaseFileUploadVO> {
	
	String INSERT_INTO_TRANS = "insertIntoTrans";
	
	String INSERT_INTO_HIST_FRM_TRANS = "insertIntoHistFromTrans";
	
	String INSERT_INTO_MASTER_FRM_TRANS = "insertIntoMasterFromTrans";
	
	String DELETE_FRM_TRANS = "deleteFromTrans";
	
	String INSERT_INTO_HIST_FRM_MASTER = "insertIntoHistFromMaster";
	
	String UPDATE_STATUS_IN_TRANS = "updateStatusInTrans";
	
	String UPDATE_ERRORCODE_IN_MASTER = "updateErrcodeInMaster";
	
	void insertFileDetailsIntoTrans(
			List<V> valueObjectList) throws BNPApplicationException;
	
	void insertFileDetailsIntoHistFromTrans(
			FileDetailsVO detailsVO) throws BNPApplicationException;
	
	void releaseFile(FileDetailsVO detailsVO) throws BNPApplicationException;
	
	void deleteFile(
			FileDetailsVO detailsVO) throws BNPApplicationException;

	void updateErrorCodeForInvalidRecords(List<V> valueObjectList) throws BNPApplicationException;
}
