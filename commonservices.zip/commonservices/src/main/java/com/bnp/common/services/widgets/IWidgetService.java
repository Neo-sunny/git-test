/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Jul 2014
 * 
 * Purpose:      IWidgetService
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 01 Jul 2014        Oracle Financial Services Software Ltd                  Initial Version   
************************************************************************************************************************************************************/
package com.bnp.common.services.widgets;

import com.bnp.common.services.widgets.pendingdiscounts.bindingvo.WidgetRequest;
import com.bnp.common.services.widgets.pendingdiscounts.bindingvo.WidgetResponse;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface IWidgetService{
	
	/**
	 * @param request
	 * @return the response object 
	 * @throws BNPApplicationException
	 */
	WidgetResponse getPendingDiscountDetails(WidgetRequest request) throws BNPApplicationException;
	
	/**
	 * @param request
	 * @return the response object
	 * @throws BNPApplicationException
	 */
	com.bnp.common.services.widgets.outstandingsett.bindingvo.WidgetResponse getOutstandingSettDetails
	(com.bnp.common.services.widgets.outstandingsett.bindingvo.WidgetRequest request) throws BNPApplicationException;
	
	/**
	 * @param request
	 * @return the response object
	 * @throws BNPApplicationException
	 */
	com.bnp.common.services.widgets.facilityutil.bindingvo.WidgetResponse getFacilityUtilizationDetails
	(com.bnp.common.services.widgets.facilityutil.bindingvo.WidgetRequest request)
			throws BNPApplicationException;
}
