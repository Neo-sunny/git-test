/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   18 March 2013
 * 
 * Purpose:      InstrumentTypeProvider
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 March 2013        Oracle Financial Services Software Ltd                  Initial Version
************************************************************************************************************************************************************/
package com.bnp.common.services.filemgmt.util;

import java.util.HashMap;
import java.util.Map;

/**
 * @author prabakarans
 *
 */
public enum InstrumentTypeProvider {
	
	RATE_REFRESH("20", "SCM-RefreshRate"),
	DISC_CONF_MFU("21", "DiscountConfirmation"),
	TP_DISC_CONFIRM("22","TPParticipationConfirmation"),
	UPD_SETTLEMENTS("23","UpdateSettlements");
	
	private InstrumentTypeProvider(String instrumentType, 
			String fileFormatType) {
		this.instrumentType = instrumentType;
		this.fileFormatType = fileFormatType;
	}
	
	private static Map<String, InstrumentTypeProvider> instrTypeMap = 
			new HashMap<String, InstrumentTypeProvider>();
	
	static {
		for (InstrumentTypeProvider instrument : InstrumentTypeProvider.values()) {
			instrTypeMap.put(instrument.getFileFormatType(), instrument);
		}
	}
	
	
	private String instrumentType;
	
	private String fileFormatType;

	/**
	 * @return the instrumentType
	 */
	public String getInstrumentType() {
		return instrumentType;
	}

	/**
	 * @return the fileFormatType
	 */
	public String getFileFormatType() {
		return fileFormatType;
	}

	public static String getInstrumentType(String fileFormatType) {
		String instrumentType = null;
		
		InstrumentTypeProvider instrument = instrTypeMap.get(fileFormatType);
		
		if (instrument != null) {
			instrumentType = instrument.getInstrumentType();
		}
		return instrumentType;
	}

}
