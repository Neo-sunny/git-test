@javax.xml.bind.annotation.XmlSchema(namespace = "http://supplychain.bnpparibas.com/PendingDiscService/schema", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.bnp.common.services.widgets.pendingdiscounts.bindingvo;
