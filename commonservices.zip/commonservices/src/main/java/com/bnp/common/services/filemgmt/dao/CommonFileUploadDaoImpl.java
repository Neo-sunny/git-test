/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   18 March 2013
 * 
 * Purpose:      CommonFileUploadDaoImpl
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 March 2013        Oracle Financial Services Software Ltd                  Initial Version
************************************************************************************************************************************************************/
package com.bnp.common.services.filemgmt.dao;

import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.SqlMapClientCallback;

import com.bnp.common.services.filemgmt.vo.BaseFileUploadVO;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.ibatis.sqlmap.client.SqlMapExecutor;
import com.ibatis.sqlmap.engine.execution.BatchException;

/**
 * @author prabakarans
 *
 */
public class CommonFileUploadDaoImpl<V extends BaseFileUploadVO> extends SqlMapClientWrapper 
				implements ICommonFileUploadDao<V> {
	
	protected static final Logger LOGGER = LoggerFactory.getLogger(CommonFileUploadDaoImpl.class);
	
	@Override
	public void insertFileDetailsIntoTrans(final List<V> valueObjectList)
			throws BNPApplicationException {
		
		try {
			getSqlMapClientTemplate().execute(new SqlMapClientCallback<List<Object>>() {
				@SuppressWarnings ("unchecked")
				public List<Object> doInSqlMapClient(SqlMapExecutor executor)
						throws SQLException {
					List<Object> list = null;
	
					try {
						executor.startBatch();
						
						int batchCommitCounter = 0;
						for (V valueObj : valueObjectList) {
							executor.insert(getQueryNameWithNameSpace(
									INSERT_INTO_TRANS), valueObj);
							
							batchCommitCounter ++;
							if (batchCommitCounter % batchCommitSize == 0) {
								executor.executeBatchDetailed();
								executor.startBatch();
							}	
						}
						list = executor.executeBatchDetailed();
					} catch (BatchException e) {
						throw new SQLException(e.toString());
					}
					return list;
				}
			});
		} catch (DataAccessException exception) {
			LOGGER.error("Exception occured while executing  insertFileDetailsIntoTrans : {} ",exception);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
		

	@Override
	public void insertFileDetailsIntoHistFromTrans(FileDetailsVO detailsVO)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(
					INSERT_INTO_HIST_FRM_TRANS), detailsVO.getFileId());
		} catch (DataAccessException exception) {
			LOGGER.error("Exception occured while executing  insertFileDetailsIntoHistFromTrans() ",exception);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public void releaseFile(FileDetailsVO detailsVO) throws BNPApplicationException {
		try {
			detailsVO.setFileStatus(StatusConstants.RELEASED);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(
					INSERT_INTO_MASTER_FRM_TRANS), detailsVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(
					INSERT_INTO_HIST_FRM_MASTER), detailsVO.getFileId());
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(
					DELETE_FRM_TRANS), detailsVO.getFileId());
		} catch (DataAccessException exception) {
			LOGGER.error("Error while releasing a file : {} ",exception);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public void deleteFile(FileDetailsVO detailsVO)
			throws BNPApplicationException {
		try {
			detailsVO.setFileStatus(StatusConstants.DELETE);
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(
					UPDATE_STATUS_IN_TRANS), detailsVO);
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(
					INSERT_INTO_HIST_FRM_TRANS), detailsVO.getFileId());
			getSqlMapClientTemplate().delete(getQueryNameWithNameSpace(
					DELETE_FRM_TRANS), detailsVO.getFileId());
		} catch (DataAccessException exception) {
			LOGGER.error("Error while inserting into rate refresh hist from trans : {} ",exception);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}


	@Override
	public void updateErrorCodeForInvalidRecords(final List<V> valueObjectList)throws BNPApplicationException {
		
		try {
			getSqlMapClientTemplate().execute(new SqlMapClientCallback<List<Object>>() {
				@SuppressWarnings ("unchecked")
				public List<Object> doInSqlMapClient(SqlMapExecutor executor)
						throws SQLException {
					List<Object> list = null;
	
					try {
						executor.startBatch();
						
						int batchCommitCounter = 0;
						for (V valueObj : valueObjectList) {
							executor.insert(getQueryNameWithNameSpace(
									UPDATE_ERRORCODE_IN_MASTER), valueObj);
							
							batchCommitCounter ++;
							if (batchCommitCounter % batchCommitSize == 0) {
								executor.executeBatchDetailed();
								executor.startBatch();
							}	
						}
						list = executor.executeBatchDetailed();
					} catch (BatchException e) {
						throw new SQLException(e.toString());
					}
					return list;
				}
			});
		} catch (DataAccessException exception) {
			LOGGER.error("Error while updating Error code in staging table : {} ",exception);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
}
