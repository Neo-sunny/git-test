/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   18 March 2013
 * 
 * Purpose:      IAbstractDataFileProcessor
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 March 2013        Oracle Financial Services Software Ltd                  Initial Version
************************************************************************************************************************************************************/
package com.bnp.common.services.filemgmt.processor;

import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;
import com.bnp.scm.services.txns.common.message.bindingvo.RootXmlElement;

public interface IAbstractDataFileProcessor<R extends RootXmlElement, T> {
	
	void processFile(AbstractMessage<?> msg, FileDetailsVO detailsVO) 
						throws BNPApplicationException;

}
