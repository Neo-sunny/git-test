/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   18 March 2013
 * 
 * Purpose:      ICommonFileUploadService
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 March 2013        Oracle Financial Services Software Ltd                  Initial Version   
************************************************************************************************************************************************************/
package com.bnp.common.services.filemgmt;

import java.util.List;

import com.bnp.common.services.filemgmt.dao.ICommonFileUploadDao;
import com.bnp.common.services.filemgmt.vo.BaseFileUploadVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;

/**
 * @author prabakarans
 *
 */
public interface ICommonFileUploadService<V extends BaseFileUploadVO> {
	
	void insertFileDetailsIntoTrans(
			List<V> valueObjectList) throws BNPApplicationException;
	
	void insertFileDetailsIntoHistFromTrans(
			FileDetailsVO detailsVO) throws BNPApplicationException;
	
	void releaseFile(
			AbstractMessage<?> msg, FileDetailsVO detailsVO) throws BNPApplicationException;
	
	void deleteFile(
			FileDetailsVO detailsVO) throws BNPApplicationException;
	
	ICommonFileUploadDao<V> getFileUploadDao();
	
	void postRelease(AbstractMessage<?> msg, 
			FileDetailsVO detailsVO) throws BNPApplicationException;

}
