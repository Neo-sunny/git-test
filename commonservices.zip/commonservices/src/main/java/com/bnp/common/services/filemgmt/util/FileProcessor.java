/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   23 Nov 2012
 * 
 * Purpose:      For File Processing
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 23 Nov 2012                Arun G                 						 Initial Version  
 ******************************************************************************************************************************************************/
package com.bnp.common.services.filemgmt.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.filemgmt.util.InstrumentTypeEnum;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.util.CacheConstants;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.invoice.IInvoiceUploadService;

@Component
@Scope("prototype")
public class FileProcessor {

	@Autowired
	private IInvoiceUploadService invoiceUploadService;
	
	@Autowired
	private EippFileProcessor eippFileProcessor;
	
	@Autowired
	private ScfFileProcessor scfFileProcessor;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FileProcessor.class);
	//FO 8.0 Sonar Fix -Starts
	private void loggerMsg(String msg){
		LOGGER.debug(msg);
	}
	//FO 8.0 Sonar Fix -Ends

	public void processFileData(String fileID,String msgType) throws BNPApplicationException {
		try{
			FileDetailsVO fileDetailsVO=invoiceUploadService.getFileDetails(fileID,msgType);
			if(fileDetailsVO!=null){
				//Fixed for Fortify issue Log Forging debug
				//LOGGER.debug("DocType - "+fileDetailsVO.getDocType());
				if(CacheConstants.REFRESH_BASE_RATE_VAL.equals(fileDetailsVO.getDocType())
				||CacheConstants.DISC_CONFIRMATION_VAL.equals(fileDetailsVO.getDocType())
				||CacheConstants.TP_DISC_CONFIRM_VAL.equals(fileDetailsVO.getDocType())
				||CacheConstants.UPDATE_SETTLEMENTS_VAL.equals(fileDetailsVO.getDocType())) {
					
					fileDetailsVO.setFileFrmtType(fileDetailsVO.getDocType());
					//Fixed for Fortify issue Log Forging debug
					//LOGGER.debug("FileFormatType - "+fileDetailsVO.getFileFrmtType());
					fileDetailsVO.setInstrumentType(InstrumentTypeProvider.getInstrumentType(fileDetailsVO.getFileFrmtType()));
					//Fixed for Fortify issue Log Forging debug
					//LOGGER.debug("InstrumentType - "+fileDetailsVO.getInstrumentType());
					scfFileProcessor.processFileData(fileDetailsVO);
				} else {
				fileDetailsVO.setFileFrmtType(InstrumentTypeEnum.getFileFormatTypeForMsgType(fileDetailsVO.getDocType()));
				fileDetailsVO.setInstrumentType(InstrumentTypeEnum.getInstrumentType(fileDetailsVO.getFileFrmtType()));
				if(BNPConstants.EIPP.equals(fileDetailsVO.getFileFrmtType())||InstrumentTypeEnum.isEippFile(fileDetailsVO.getFileFrmtType())){
					eippFileProcessor.processFileData(fileDetailsVO);
				       }
				}
			}else{
				//Fixed for Fortify issue Log Forging debug
				//FO 8.0 Sonar Fix
				loggerMsg("Invalid FileID - "+fileID);
			}
		}catch(BNPApplicationException exception){
			LOGGER.error("Exception while Procesing File",exception);
			throw exception;
		} 
	}
	}
