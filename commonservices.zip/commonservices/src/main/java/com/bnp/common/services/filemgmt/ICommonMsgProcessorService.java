package com.bnp.common.services.filemgmt;
/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   18 March 2013
 * 
 * Purpose:      ICommonMsgProcessorService
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 Mar 2013        Oracle Financial Services Software Ltd                  Initial Version   
************************************************************************************************************************************************************/


import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;

public interface ICommonMsgProcessorService {
	
	AbstractMessage<?> prepareStandardMessage(
			FileDetailsVO detailsVO) throws BNPApplicationException;
	
	
	AbstractMessage<?> prepareCustomMessage(
			FileDetailsVO detailsVO) throws BNPApplicationException;
	
	void sendMessage(FileDetailsVO detailsVO, 
			AbstractMessage<?> invoiceMessage) throws BNPApplicationException;

}
