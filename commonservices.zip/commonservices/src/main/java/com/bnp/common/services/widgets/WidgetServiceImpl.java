/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Jul 2014
 * 
 * Purpose:      WidgetServiceImpl
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 01  Jul 2014        Oracle Financial Services Software Ltd                  Initial Version  
 * 05 AUG 2015          Saranya.M                                              R7.1  Widget Changes CSCDEV-5365  
 * 18 AUG 2015          Saranya.M                                              CSC Centirc  Widget Changes CSCDEV-5365   
 * 03 SEP 2015          saranya.M                                              CSC Centirc Widget Time Zone Enhancement   CSCDEV-5682
 * 07 SEP 2015          Saranya.M                                              CSC Centric Widget Ccy Validation  CSCDEV-5813
 
 * 06 OCT 2015          Saranya.M                                              CSC  Centirc  Widget PayableBuyer Validation CSCDEV-6212 
 * 08 OCT 2015          Saranya.M                                              CSC  Centirc  Widget FacilUtil OrgId  changes  CSCDEV-6359
 * 19 OCT 2015          Raja.S                                                 CSC Centric Widget Effective  Available Changes CSCDEV-6361
 * 06 Nov 2015          Raja.S                                                 CSC Centric SSO User ID Changes CSCDEV-6818
 * 11 Nov 2015          Raja.S                                                 CSC Centric Changes CSCDEV-6298
 * 11 Dec 2015          Raja.S                                                 CSC Centric Changes CSCDEV-6947
  ************************************************************************************************************************************************************/

package com.bnp.common.services.widgets;

import java.util.List;
import java.io.*;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Set;

import com.bnp.common.services.widgets.dao.IWidgetDAO;
import com.bnp.common.services.widgets.facilityutil.bindingvo.FacilityUtilization;
import com.bnp.common.services.widgets.facilityutil.bindingvo.GroupElements;
import com.bnp.common.services.widgets.outstandingsett.bindingvo.OutstandingSettlement;
import com.bnp.common.services.widgets.outstandingsett.bindingvo.OutstandingSettlements;
import com.bnp.common.services.widgets.pendingdiscounts.bindingvo.Group;
import com.bnp.common.services.widgets.pendingdiscounts.bindingvo.OutstandingDisocunts;
import com.bnp.common.services.widgets.pendingdiscounts.bindingvo.RequestInfo;
import com.bnp.common.services.widgets.pendingdiscounts.bindingvo.SubGroup;
import com.bnp.common.services.widgets.pendingdiscounts.bindingvo.WidgetRequest;
import com.bnp.common.services.widgets.pendingdiscounts.bindingvo.WidgetResponse;
import com.bnp.common.services.widgets.vo.MainGroupVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.txns.util.XMLGregorianCalendarConverter;


import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.bnp.scm.services.discounting.util.BNPDiscountUtil;
import java.util.TimeZone;


@Component
public class WidgetServiceImpl implements IWidgetService {

	@Autowired
	private IWidgetDAO widgetDAO;

	protected static final Logger logger = LoggerFactory
			.getLogger(WidgetServiceImpl.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bnp.common.services.widgets.IWidgetService#getPendingDiscountDetails
	 * (com
	 * .bnp.common.services.widgets.pendingdiscounts.bindingvo.WidgetRequest)
	 * this method will fetch all the pending discounts based on the request
	 * parameters passed and builds the corresponding response object
	 */
	@Override
	public WidgetResponse getPendingDiscountDetails(WidgetRequest request)
			throws BNPApplicationException {
		WidgetResponse response = new WidgetResponse();
		RequestInfo reqInfo = new RequestInfo();
		OutstandingDisocunts outStndDisc = new OutstandingDisocunts();
		// a40488 changes done for CSCDEV-5365 starts
		NameValueVO userVO = null;
		boolean isFuncAvlble = false;

		try {

			logger.debug("User ID "+ request.getUserID());
			String ssoUserId = request.getUserID();
            userVO = widgetDAO.getUserType(ssoUserId);
			
		    if (userVO != null) {
		    	logger.debug("User ID in userVO is  "+ userVO.getName());
				// 933039 Change done for CSCDEV-6818 starts
				 isFuncAvlble = widgetDAO.getUserRoles(userVO.getName(),"CENTRICPENDINGDISCOUNT");
				 // 933039 Change done for CSCDEV-6818 ends
				if (isFuncAvlble) {
			// a40488  changes done for CSCDEV-6212   Starts		
		     if (userVO.getValue() != null && !userVO.getValue().equalsIgnoreCase("B"))
			    {	
			// a40488  changes done for CSCDEV-6212 Ends
			  
		// a40488 changes done for CSCDEV-5365 ends
		List<MainGroupVO> pendDisclist = widgetDAO.getPendingDiscountDetails(request);
		if (pendDisclist != null && !pendDisclist.isEmpty()) {
			  for (MainGroupVO mainGrpList : pendDisclist) {
				Group group = new Group();
				group.setCount(mainGrpList.getParentCount());
				group.setAmt(mainGrpList.getParentLevelSum());
				if (request.getGroupBy().getName().equalsIgnoreCase(BNPConstants.WS_CCY)) {
					group.setName(mainGrpList.getCcyCode());
					for (MainGroupVO subGrpList : mainGrpList.getChildList()) {
						SubGroup subGrp = new SubGroup();
						subGrp.setName(subGrpList.getOrgId());
						subGrp.setCount(subGrpList.getChildCount());
						subGrp.setAmt(subGrpList.getChildLevelSum());
						group.getSubGroup().add(subGrp);
					}
				} else if (request.getGroupBy().getName()
						.equalsIgnoreCase(BNPConstants.WS_ENTITY)) {
					group.setName(mainGrpList.getOrgId());
					for (MainGroupVO subGrpList : mainGrpList.getChildList()) {
						SubGroup subGrp = new SubGroup();
						subGrp.setName(subGrpList.getCcyCode());
						subGrp.setCount(subGrpList.getChildCount());
						subGrp.setAmt(subGrpList.getChildLevelSum());
						group.getSubGroup().add(subGrp);
					}
				}
				outStndDisc.getGroup().add(group);
			}
			response.setOutstandingDisocunts(outStndDisc);
			reqInfo.setUserID(request.getUserID());
			reqInfo.setServiceName(request.getServiceName());
			reqInfo.setGroupBy(request.getGroupBy());
			response.setRequestInfo(reqInfo);
           }
					// a40488 changes done for CSCDEV-5365 starts
					else {
						 logger.debug("Pending Discount No data available");
                         response.setErrorMessage(BNPConstants.NO_DATA_AVAILABLE);
					}
				}
		  
		     //a40488   Changes done for  CSCDEV-6212 starts 
		    else {
       	         logger.debug("No Roles for Payable Buyer User to Access Pending Discounts");
       	        response.setErrorMessage(BNPConstants.WIDGET_PENDING_ROLES);
               }
		     //a40488   Changes done for  CSCDEV-6212 Ends 
		    }   
				
			else {
            	   logger.debug("Pending Discount No roles for User to Access");
            	   response.setErrorMessage(BNPConstants.WIDGET_PENDING_ROLES);
                     }

			} else {
				 logger.debug("Pending Discount  Invalid_User");
                 response.setErrorMessage(BNPConstants.INVALID_WIDUSERIDMSG);
                  	}
			reqInfo.setUserID(request.getUserID());
			reqInfo.setServiceName(request.getServiceName());
			reqInfo.setGroupBy(request.getGroupBy());
			response.setRequestInfo(reqInfo);
			
		} catch (BNPApplicationException e) {
			logger.error("Error while mapping getPendingDiscountDetails to pendDisclist  in WidgetServiceImpl "
					+ e.getErrorCode());
			response.setErrorMessage(e.getMessage());
			reqInfo.setUserID(request.getUserID());
			reqInfo.setServiceName(request.getServiceName());
			reqInfo.setGroupBy(request.getGroupBy());
			response.setRequestInfo(reqInfo);
		}
		return response;
	}

	/* (non-Javadoc)
	 * @see com.bnp.common.services.widgets.IWidgetService#getOutstandingSettDetails(com.bnp.common.services.widgets.outstandingsett.bindingvo.WidgetRequest)
	 * this method will fetch all the settlements that are due based on the request parameters passed and builds the  corresponding response object
	 */
	@Override
	public com.bnp.common.services.widgets.outstandingsett.bindingvo.WidgetResponse getOutstandingSettDetails(
			com.bnp.common.services.widgets.outstandingsett.bindingvo.WidgetRequest request)
			throws BNPApplicationException {
		 logger.debug("getOutstandingSettDetails request  starts for "+ request.getUserID());
		com.bnp.common.services.widgets.outstandingsett.bindingvo.WidgetResponse response = new com.bnp.common.services.widgets.outstandingsett.bindingvo.WidgetResponse();
		com.bnp.common.services.widgets.outstandingsett.bindingvo.RequestInfo reqInfo = new com.bnp.common.services.widgets.outstandingsett.bindingvo.RequestInfo();
		OutstandingSettlements outSettlements = new OutstandingSettlements();
		// a40488 changes done for CSCDEV-5365 starts

		NameValueVO userVO = null;
		boolean isFuncAvlble = false;

		try {
			logger.debug("User ID "+ request.getUserID());
			String ssoUserId = request.getUserID();
			userVO = widgetDAO.getUserType(ssoUserId);
			if (userVO != null) {
				logger.debug("User ID in userVO in getOutstandingSettDetails is   "+ userVO.getName());
				
				// 933039 Change done for CSCDEV-6818 starts
				isFuncAvlble = widgetDAO.getUserRoles(userVO.getName(),"CENTRICSETTLEMENTDUE");
				// 933039 Change done for CSCDEV-6818 ends
				     if (isFuncAvlble) {
                    // a40488 changes done for CSCDEV-5365 ends
				   	 
				List<MainGroupVO> outSettList = widgetDAO.getOutstandingSettDetails(request);
		//933039 Change done for CSCDEV-6298 starts 		
		Map<String, String> orgTimeZone = new HashMap<String, String>();
		//933039 Change done for CSCDEV-6298 ends
		if (outSettList != null && !outSettList.isEmpty()) {
			 for (MainGroupVO mainGrp : outSettList) {
				 //a40488   added  for Time Zone Enhancement  CSCDEV-5682 Starts 
				OutstandingSettlement outSett = new OutstandingSettlement();
				
				for (MainGroupVO subGrp : mainGrp.getMainGrpList()) {
					com.bnp.common.services.widgets.outstandingsett.bindingvo.Group group = new com.bnp.common.services.widgets.outstandingsett.bindingvo.Group();
					group.setCount(subGrp.getParentCount());
					group.setAmt(subGrp.getParentLevelSum());
					if (request.getGroupBy().getName().equalsIgnoreCase(BNPConstants.WS_CCY)) {
						group.setName(subGrp.getCcyCode());
						for (MainGroupVO subGrpList : subGrp.getChildList()) {
							com.bnp.common.services.widgets.outstandingsett.bindingvo.SubGroup childGrp = new com.bnp.common.services.widgets.outstandingsett.bindingvo.SubGroup();
							childGrp.setName(subGrpList.getOrgId());
							childGrp.setCount(subGrpList.getChildCount());
							childGrp.setAmt(subGrpList.getChildLevelSum());
							group.getSubGroup().add(childGrp);
							
							 // 933039 Change done for performance issue starts
							 setTimeZoneForSettlementDate(subGrpList.getOrgId() ,mainGrp.getSettlementDate(), outSett, orgTimeZone);
							 // 933039 Change done for performance issue ends
							
					}
					} else if (request.getGroupBy().getName()
							.equalsIgnoreCase(BNPConstants.WS_ENTITY)) {
						group.setName(subGrp.getOrgId());
						for (MainGroupVO subGrpList : subGrp.getChildList()) {
							com.bnp.common.services.widgets.outstandingsett.bindingvo.SubGroup childGrp = new com.bnp.common.services.widgets.outstandingsett.bindingvo.SubGroup();
							childGrp.setName(subGrpList.getCcyCode());
							childGrp.setCount(subGrpList.getChildCount());
							childGrp.setAmt(subGrpList.getChildLevelSum());
							group.getSubGroup().add(childGrp);
							// 933039 Change done for performance issue starts
							setTimeZoneForSettlementDate(subGrp.getOrgId() ,mainGrp.getSettlementDate(), outSett, orgTimeZone);
							// 933039 Change done for performance issue ends
							}
					}
					outSett.getGroup().add(group);
				}
                
				outSettlements.getOutstandingSettlement().add(outSett);
			}
			
			outSettlements.getLabelToDisplay().add(outSettList.get(0).getLabelToDisplay());
			response.setOutstandingSettlements(outSettlements);
			reqInfo.setUserID(request.getUserID());
			reqInfo.setServiceName(request.getServiceName());
			reqInfo.setGroupBy(request.getGroupBy());
			response.setRequestInfo(reqInfo);
		        }else{
		        	    logger.debug("Settlement Due No Data Available ");
			            response.setErrorMessage(BNPConstants.NO_DATA_AVAILABLE);
					}

				} else {
					logger.debug(" SettlementDue No roles for User to Access ");
					response.setErrorMessage(BNPConstants.WIDGET_SETTLEMENT_DUE);
				}
			}
           else {
        	    logger.debug("SettlementDue Invalid_User ");
                response.setErrorMessage(BNPConstants.INVALID_WIDUSERIDMSG);

			}
			reqInfo.setUserID(request.getUserID());
			reqInfo.setServiceName(request.getServiceName());
			reqInfo.setGroupBy(request.getGroupBy());
			response.setRequestInfo(reqInfo);
		 }
		catch (BNPApplicationException e) {
			logger.error("Error while mapping getOutstandingSettDetails to outSettList in WidgetServiceImpl "
					+ e.getErrorCode());
			response.setErrorMessage(e.getMessage());
			reqInfo.setUserID(request.getUserID());
			reqInfo.setServiceName(request.getServiceName());
			reqInfo.setGroupBy(request.getGroupBy());
			response.setRequestInfo(reqInfo);
		}
		logger.debug("getOutstandingSettDetails request  ends for "+ request.getUserID());
		return response;
	}
	
	
	// 933039 Change done for performance tuning  starts
	
	private void setTimeZoneForSettlementDate(String orgId , Date settlementDate , OutstandingSettlement outSett ,Map<String, String> orgTimeZone ) throws BNPApplicationException{
		String branchTimeZone =orgTimeZone.get(orgId);
		if(branchTimeZone ==null){
			logger.debug("DB Hit started for TZ ");
			branchTimeZone  = widgetDAO.getSupportBranchTimeZone(orgId);
			orgTimeZone.put(orgId,branchTimeZone);
			
		}
		
		 
		 logger.debug("Branch time zone "+ branchTimeZone );
		
		TimeZone timeZone =  branchTimeZone != null ? TimeZone.getTimeZone(branchTimeZone) : TimeZone.getDefault();
		outSett.setSettlementDate(XMLGregorianCalendarConverter.asXMLGregCalWithTimeZone(settlementDate, timeZone));
		//Changes done for  CSCDEV-6947 starts
		outSett.setTimeZoneToDisplay(branchTimeZone);
		// Changed fone for CSCDEV-6947 ends
	}
	// 933039 Change done for performance tuning  ends
	
		/* (non-Javadoc)
		 * @see com.bnp.common.services.widgets.IWidgetService#getFacilityUtilizationDetails(com.bnp.common.services.widgets.facilityutil.bindingvo.WidgetRequest)
		 * this method will fetch facility utilization details based on the request parameters passed and builds the  corresponding response object
		 * 
		 */
		public com.bnp.common.services.widgets.facilityutil.bindingvo.WidgetResponse getFacilityUtilizationDetails(com.bnp.common.services.widgets.facilityutil.bindingvo.WidgetRequest request)
			throws BNPApplicationException {
			logger.debug("getFacilityUtilizationDetails request  started for "+request.getUserID());
		com.bnp.common.services.widgets.facilityutil.bindingvo.WidgetResponse response = new com.bnp.common.services.widgets.facilityutil.bindingvo.WidgetResponse();
		com.bnp.common.services.widgets.facilityutil.bindingvo.RequestInfo reqInfo = new com.bnp.common.services.widgets.facilityutil.bindingvo.RequestInfo();
		FacilityUtilization facilUtil = new FacilityUtilization();
		// a40488 changes done for CSCDEV-5365 starts

		NameValueVO userVO = null;
		boolean isFuncAvlble = false;
		boolean isValidCcy= true;
		
       try {
    	   logger.debug("User ID "+ request.getUserID());
			String ssoUserId = request.getUserID();
			userVO = widgetDAO.getUserType(ssoUserId);

			if (userVO != null) {
				logger.debug("User ID in userVO is  "+ userVO.getName());
				
				// 933039 Change done for CSCDEV-6818 starts
                isFuncAvlble = widgetDAO.getUserRoles(userVO.getName(),"CENTRICFACILITYUTILIZATION");
				// 933039 Change done for CSCDEV-6818 ends
				 if (isFuncAvlble) {
					 
				// a40488 changes done for CSCDEV-5365 ends
					 
					 //a40488 changes done for CSCDEV-5813 starts
					 
					 if(!(BNPConstants.WS_DEFAULT.equalsIgnoreCase(request.getGroupBy().getValue()))){
						 isValidCcy =widgetDAO.checkIsValidCurrency(request.getGroupBy().getValue());
						
					 }
					 if (isValidCcy){
			       //a40488 changes done for CSCDEV-5813 Ends
						 
				   // a40488 changes done for CSCDEV-5365 Starts
					List<MainGroupVO> facilUtilList = widgetDAO.getFacilityUtilizationDetails(request);
					if (facilUtilList != null && !facilUtilList.isEmpty()) {
					List<String> ccyList = widgetDAO.getAvlbleCcyFromDiscDefinition(facilUtilList.get(0).getOrgId());
					 facilUtil.setAvailableCcy(new com.bnp.common.services.widgets.facilityutil.bindingvo.AvailableCcy());
					 if  (ccyList !=null) {
			                for(String ccy : ccyList) {
						    facilUtil.getAvailableCcy().getCcy().add(ccy);
						    	  
								    }
					 }
			// a40488 changes done for CSCDEV-5365 ends
	            for (MainGroupVO fGroupList : facilUtilList){
				com.bnp.common.services.widgets.facilityutil.bindingvo.Group group = new com.bnp.common.services.widgets.facilityutil.bindingvo.Group();
				GroupElements groupElements = new GroupElements();
				//a40488 Changes done for CSCDEV-6359 Starts 
				groupElements.setName(fGroupList.getOrgId());
				//a40488 Changes done for CSCDEV-6359  Ends 
				groupElements.setCcy(fGroupList.getCcyCode());
				groupElements.setConvertedCcy(fGroupList.getConvertedCcyCode());
				groupElements.setGrantedAmt(fGroupList.getGrantedAmt());
				groupElements.setConvertedGrantedAmt(fGroupList.getConvertGrantedAmt());
				groupElements.setUtilizedAmt(fGroupList.getUtilizedAmt());
				groupElements.setConvertedUtilizedAmt(fGroupList.getConvertedUtilizedAmt());
				groupElements.setAvailableAmt(fGroupList.getAvailableAmt());
				groupElements.setConvertedAvailableAmt(fGroupList.getConvertedAvailableAmt());
				groupElements.setInitiatedAmt(fGroupList.getInitiatedAmt());
				groupElements.setConvertedInitiatedAmt(fGroupList.getConvertedInitiatedAmt());
				//933039 Change done for CSCDEV-6361 Starts
				groupElements.setEffectiveAvailable(fGroupList.getEffectiveAvailable());
				//933039 Change done for CSCDEV-6361 Ends
				group.setGroupElements(groupElements);
				for(MainGroupVO fSubGroupList : fGroupList.getChildList()){
					com.bnp.common.services.widgets.facilityutil.bindingvo.SubGroup subGrp = new com.bnp.common.services.widgets.facilityutil.bindingvo.SubGroup();
					GroupElements subGroupElement = new GroupElements();
					subGroupElement.setName(fSubGroupList.getGroupName());
					subGroupElement.setCcy(fSubGroupList.getCcyCode());
					subGroupElement.setConvertedCcy(fSubGroupList.getConvertedCcyCode());
					subGroupElement.setGrantedAmt(fSubGroupList.getGrantedAmt());
					subGroupElement.setConvertedGrantedAmt(fSubGroupList.getConvertGrantedAmt());
					subGroupElement.setUtilizedAmt(fSubGroupList.getUtilizedAmt());
					subGroupElement.setConvertedUtilizedAmt(fSubGroupList.getConvertedUtilizedAmt());
					subGroupElement.setAvailableAmt(fSubGroupList.getAvailableAmt());
					subGroupElement.setConvertedAvailableAmt(fSubGroupList.getConvertedAvailableAmt());
					subGroupElement.setInitiatedAmt(fSubGroupList.getInitiatedAmt());
					subGroupElement.setConvertedInitiatedAmt(fSubGroupList.getConvertedInitiatedAmt());
					//933039 Change done for CSCDEV-6361 Starts
					subGroupElement.setEffectiveAvailable(fSubGroupList.getEffectiveAvailable());
					//933039 Change done for CSCDEV-6361 ends
				    subGrp.setGroupElements(subGroupElement);
					group.getSubGroup().add(subGrp);
					
					}
				facilUtil.getGroup().add(group);
			   }
			response.setFacilityUtilization(facilUtil);
		            } // a40488 changes done for CSCDEV-5365 starts
					else {
						 logger.debug("FacilUtil No Data Available");
                        response.setErrorMessage(BNPConstants.NO_DATA_AVAILABLE);
                        }
					
					 }
					 //a40488 changes done for CSCDEV-5813 starts
					 else 
					 {
						   logger.debug("FacilUtil  Invalid Currency");
						   response.setErrorMessage(BNPConstants.WIDGET_FACILTIY_UTIL_CCY);
					 }  //a40488 changes done for CSCDEV-5813 Ends
					}
                else {
                	 logger.debug("FacilUtil No roles for User to Access");
					response.setErrorMessage(BNPConstants.WIDGET_FACILTIY_UTIL);
				}
			} else {
				 logger.debug("FacilUtil  Invalid_User ");
				response.setErrorMessage(BNPConstants.INVALID_WIDUSERIDMSG);
			}
			reqInfo.setUserID(request.getUserID());
			reqInfo.setServiceName(request.getServiceName());
			reqInfo.setGroupBy(request.getGroupBy());
			response.setRequestInfo(reqInfo);
			}
		
		catch (BNPApplicationException e) {
			logger.error("Error while mapping getFacilityUtilizationDetails to facilUtilList  in  WidgetServiceImpl"
					+ e.getErrorCode());
			response.setErrorMessage(e.getMessage());
			reqInfo.setUserID(request.getUserID());
			reqInfo.setServiceName(request.getServiceName());
			reqInfo.setGroupBy(request.getGroupBy());
			response.setRequestInfo(reqInfo);
		}
       logger.debug("getFacilityUtilizationDetails response completed for "+ request.getUserID());
		return response;
	}
		
}
