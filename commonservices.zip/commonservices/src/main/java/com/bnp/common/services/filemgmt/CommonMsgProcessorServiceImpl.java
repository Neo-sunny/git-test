/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   18 March 2013
 * 
 * Purpose:      CommonMsgProcessorServiceImpl
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 March 2013        Oracle Financial Services Software Ltd                  Initial Version   
 * 12 FEB 2018     		Divyashri S                  							R11.0 S2018X0102 - Updated Error Code
************************************************************************************************************************************************************/
package com.bnp.common.services.filemgmt;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.interfaces.common.ICommonAccessService;
import com.bnp.scm.services.interfaces.common.message.MessageFactory;
import com.bnp.scm.services.interfaces.common.vo.ConfVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;
import com.bnp.scm.services.txns.util.PropertiesReader;

/**
 * @author prabakarans
 *
 */
@Component
public class CommonMsgProcessorServiceImpl implements ICommonMsgProcessorService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CommonMsgProcessorServiceImpl.class);
	
	@Autowired
	private ICommonFileProcessService fileProcessorService;
	
	@Autowired 
	@Qualifier("bnpMessageFactory")
	protected MessageFactory messageFactory;
	
	@Autowired
	protected BNPPropertyLoaderConfigurer propertyLoader;
	
	@Autowired
	private ICommonAccessService commonAccessService;
	
	public AbstractMessage<?> prepareStandardMessage(FileDetailsVO detailsVO) throws BNPApplicationException {
		
		AbstractMessage<?> message = null;
		
		String fileFormatType = detailsVO.getFileFrmtType();
		message = messageFactory.getMessageInstance(fileFormatType);
		
		String fileData = null;
		
		if (message != null) {
			try {
				message.constructMessage(detailsVO);
				fileData = message.getXmlMessage();
				detailsVO.setFileData(fileData.getBytes());
				detailsVO.setReceivedData(detailsVO.getFileData());
			} catch (BNPApplicationException exception) {
				exception.setErrorCode(ErrorConstants.INVALID_FILE_FORMAT);
				detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.load.fail"));
				detailsVO.setErrorCode(Integer.toString(exception.getErrorCode()));
				detailsVO.setErrorDesc(exception.getErrorMessage());
				fileProcessorService.updateFileStatus(detailsVO);
				detailsVO.setReceivedData(detailsVO.getFileData());
				fileProcessorService.insertFileUploadMessageDetails(detailsVO);
				fileProcessorService.triggerEventLog(detailsVO, "FUNC_ERROR");
				throw exception;
			}

			try {
				fileProcessorService.insertFileUploadMessageDetails(detailsVO);
				detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.load"));
			} catch (BNPApplicationException exception) {
				detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.load.fail"));
				detailsVO.setErrorCode(Integer.toString(exception.getErrorCode()));
				detailsVO.setErrorDesc(exception.getErrorMessage());
				fileProcessorService.updateFileStatus(detailsVO);
				throw exception;
			}
				fileProcessorService.updateFileStatus(detailsVO);
			try {
				message.extractMessage(fileData);
			} catch (BNPApplicationException exception) {
				detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.validation.fail"));
				detailsVO.setErrorCode(Integer.toString(exception.getErrorCode()));
				detailsVO.setErrorDesc(exception.getErrorMessage());
				fileProcessorService.updateFileStatus(detailsVO);
				fileProcessorService.triggerEventLog(detailsVO, "FUNC_ERROR");
				throw exception;
			}
		}
		return message;
	}

	@Override
	public AbstractMessage<?> prepareCustomMessage(FileDetailsVO detailsVO)
			throws BNPApplicationException {
		
		AbstractMessage<?> message = null;
		
		try {
			detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.processing"));
			
			message = messageFactory
					.getMessageInstance(propertyLoader.getValue("message.type.invoiceupload"));
			message.constructMessage(detailsVO);
			detailsVO.setReceivedData(message.getXmlMessage()
					.getBytes());
			fileProcessorService.insertFileUploadMessageDetails(detailsVO);
			fileProcessorService.updateFileStatus(detailsVO);
		} catch (BNPApplicationException exception) {
			throw exception;
		}
		return message;
	}
	
	public void sendMessage(FileDetailsVO detailsVO, 
			AbstractMessage<?> invoiceMessage) throws BNPApplicationException {

		try {
			ConfVO confVO = new ConfVO();
			confVO.setBranchId(detailsVO.getBranchId());
			confVO.setMsgType(invoiceMessage.getHeader().getMsgFileType());
			
			confVO = commonAccessService.getQueueNameForBranch(confVO);

			if(confVO!=null && confVO.getInternalQueue()!=null){
			//FO 7.0 Fortify Issue Fix
			//	LOGGER.info("Internal Queue Name is   "+confVO.getInternalQueue());
				Map<String,String> jmsProperties = new HashMap<String, String>();
				jmsProperties.put(PropertiesReader.getProperty("message.jms.header.extqueue"),confVO.getExternalQueue());
				jmsProperties.put(PropertiesReader.getProperty("message.jms.header.bnppmsgid"),detailsVO.getMsgId());
				fileProcessorService.sendMessage(invoiceMessage,confVO.getInternalQueue(),jmsProperties);
				fileProcessorService.updateERPDownloadForCustomFile(detailsVO,StatusConstants.SENT);
			} else {
				LOGGER.error("::::::::::QUEUE NAME NOT AVAILABLE:::::::::");
				throw new BNPApplicationException(ErrorConstants.QUEUE_NAME_NOT_AVAILABLE);
			}
		} catch (BNPApplicationException e) {
			if(e.getMessage() != null && e.getMessage().contains("Connection refused")){
				e.setErrorCode(ErrorConstants.CONNECTION_REFUSED);
			}
			if(e.getMessage() != null && e.getMessage().contains("Connection timed out")) {
				e.setErrorCode(ErrorConstants.CONNECTION_TIMED_OUT);
			}
			String errorDesc= null;
			if(e.getErrorCode() != 0 ){
				errorDesc=Integer.toString(e.getErrorCode());
			}
			else{
				errorDesc=e.getMessage();
			}	
			detailsVO.setErrorDescForMsg(errorDesc);
			fileProcessorService.updateERPDownloadForCustomFile(detailsVO,StatusConstants.SENTFAILED);
		}

	}


}
