/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Jul 2014
 * 
 * Purpose:      OutstandingSettServiceEndPoint
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 01 Jul 2014        Oracle Financial Services Software Ltd                  Initial Version
************************************************************************************************************************************************************/

package com.bnp.common.services.widgets.endpoint;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;

import com.bnp.common.services.widgets.IWidgetService;
import com.bnp.common.services.widgets.outstandingsett.bindingvo.WidgetRequest;
import com.bnp.common.services.widgets.outstandingsett.bindingvo.WidgetResponse;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@Endpoint
public class OutstandingSettServiceEndPoint {

	private static final Logger LOGGER = LoggerFactory.getLogger(
			OutstandingSettServiceEndPoint.class);
	
	@Autowired
	private IWidgetService widgetService;
	
	@PayloadRoot (
			localPart="WidgetRequest", 
			namespace="http://supplychain.bnpparibas.com/OutstandingSettService/schema")
		public JAXBElement<WidgetResponse> getOutstandingSettDetails(WidgetRequest request) {
		//Fixed for Fortify issue Log Forging debug
		//LOGGER.debug("Inside getOutstandingSettDetails -" + " Service Name :" + request.getServiceName() + " - Group By :" + request.getGroupBy().getName());
			WidgetResponse response = null;
			try {
				response = widgetService.getOutstandingSettDetails(request);
			} catch (BNPApplicationException e) {
				LOGGER.debug("Error while generating response");
				response = new WidgetResponse();
				response.setErrorMessage(BNPConstants.ERROR_IN_FETCHING_DATA);
			}
			return new JAXBElement<WidgetResponse>(
					new QName(
					"http://supplychain.bnpparibas.com/OutstandingSettService/schema", 
					"WidgetResponse"), WidgetResponse.class, response);
		}

}
