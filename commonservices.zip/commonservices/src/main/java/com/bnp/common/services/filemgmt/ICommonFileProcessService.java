/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   18 March 2013
 * 
 * Purpose:      ICommonFileProcessService
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 March 2013        Oracle Financial Services Software Ltd                  Initial Version   
************************************************************************************************************************************************************/
package com.bnp.common.services.filemgmt;

import java.util.List;
import java.util.Map;

import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.invoice.vo.InvalidFileDataVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;

/**
 * @author prabakarans
 *
 */
public interface ICommonFileProcessService {
	
	void checkForDuplicateFile(FileDetailsVO detailsVO)
			throws BNPApplicationException;
	
	void saveFileDetails(FileDetailsVO detailsVO) throws BNPApplicationException;
	
	void triggerEventLog(FileDetailsVO detailsVO, String action)
			throws BNPApplicationException;
	
	FileDetailsVO getHeaderDetails(FileDetailsVO detailsVO)
			throws BNPApplicationException;
	
	void insertFileUploadMessageDetails(FileDetailsVO detailsVO)
			throws BNPApplicationException;
	
	String getMessageId() throws BNPApplicationException;
	
	void updateFileStatus(FileDetailsVO detailsVO)
			throws BNPApplicationException;
	
	void updateERPDownloadForCustomFile(FileDetailsVO detailsVO,
			String status) throws BNPApplicationException;
	
	<T> void sendMessage(AbstractMessage<T> message, String queueName,
			Map<String, String> jmsProperties) throws BNPApplicationException;
			
	boolean canUploadPartialFile(String senderOrgId)
			throws BNPApplicationException;
	
	void insertInvalidRecords(
			List<InvalidFileDataVO> invalidList) throws BNPApplicationException;
	
	boolean isAutoReleaseEnabled(String senderOrgId)
			throws BNPApplicationException;
	
	void updateReprocessFlag(List<InvalidFileDataVO> invalidDataList, 
			FileDetailsVO detailsVO) throws BNPApplicationException;

}
