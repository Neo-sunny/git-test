/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   18 March 2013
 * 
 * Purpose:      CommonFileProcessDaoImpl
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 March 2013        Oracle Financial Services Software Ltd                  Initial Version
************************************************************************************************************************************************************/
package com.bnp.common.services.filemgmt.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;

/**
 * @author prabakarans
 *
 */
@Component
public class CommonFileProcessDaoImpl extends SqlMapClientWrapper
				implements ICommonFileProcessDao {
	
	private static Logger LOGGER = LoggerFactory.getLogger(CommonFileProcessDaoImpl.class);
	
	public CommonFileProcessDaoImpl() {
		nameSpace = "CommonFileOperations";
	}

	@Override
	public String getMessageId() throws BNPApplicationException {
		return (String) getSqlMapClientTemplate().queryForObject(
				getQueryNameWithNameSpace(GET_MSG_ID));
	}
	
	public boolean isAutoReleaseEnabled(String orgId) throws BNPApplicationException {
		Object returnObj = getSqlMapClientTemplate().queryForObject(
				getQueryNameWithNameSpace(CHECK_FOR_AUTO_RELEASE), orgId);
		
		if (returnObj != null && returnObj.toString().equalsIgnoreCase("A")) {
			return true; 
		}
		return false;
	}

	@Override
	public boolean canUploadPartialFile(String senderOrgId)
			throws BNPApplicationException {
		Object returnObj = getSqlMapClientTemplate().queryForObject(
				getQueryNameWithNameSpace(CHECK_FOR_PARTIAL_UPLOAD), senderOrgId);
		
		if (returnObj != null && returnObj.toString().equalsIgnoreCase("Y")) {
			return true; 
		}
		return false;
	}
	
	public void updateReprocessFlagForOldRejectedRecords(
			FileDetailsVO detailsVO)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(
					UPDATE_REPROCESS_FLAG), detailsVO);
		} catch (DataAccessException exception) {
			LOGGER.error("DataAccessException occured whil executing the method updateReprocessFlagForOldRejectedRecords : {} ",exception);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR,
					exception.getMessage());
		}
	}


}
