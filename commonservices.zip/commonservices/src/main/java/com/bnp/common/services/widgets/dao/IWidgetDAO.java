/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Jul 2014
 * 
 * Purpose:      IWidgetDAO
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 01 Jul 2014        Oracle Financial Services Software Ltd                  Initial Version 
 * 05 AUG  2015       Saranya M                                               R 7.1  added getUserRoles  for CSCDEV-5365
 * 18 AUG  2015       Saranya.M                                               CSC Centirc  added getAvlbleCcyFromDiscDefinition for CSCDEV-5365
 * 03 SEP  2015       Saranya.M                                               CSC  Centirc  added  getSupportBranchTimeZone for CSCDEV-5682
 * 07 SEP  2015       Saranya.M                                               CSC Centirc  added Ccy validation for CSCDEV-5813
************************************************************************************************************************************************************/
package com.bnp.common.services.widgets.dao;

import java.util.List;

import com.bnp.common.services.widgets.pendingdiscounts.bindingvo.WidgetRequest;
import com.bnp.common.services.widgets.vo.MainGroupVO;
import com.bnp.scm.services.common.exception.DBException;

import com.bnp.scm.services.common.vo.NameValueVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface IWidgetDAO{

	/**
	 * @param request
	 * @return the list of pending discounts records
	 * @throws DBException
	 */
	List<MainGroupVO> getPendingDiscountDetails(WidgetRequest request) throws DBException;

	/**
	 * @param request
	 * @return the list of settlements that are due
	 * @throws DBException
	 */
	List<MainGroupVO> getOutstandingSettDetails(
			com.bnp.common.services.widgets.outstandingsett.bindingvo.WidgetRequest request) throws DBException;
			
	/**
	 * @param request
	 * @return the list of facility utilization details
	 * @throws DBException
	 */
	List<MainGroupVO> getFacilityUtilizationDetails(com.bnp.common.services.widgets.facilityutil.bindingvo.WidgetRequest request) throws DBException;		
    // a40488   added for  CSCDEV-5365 starts 
	/**
	 * @param request
	 * @return   name  and value 
	 * @throws DBException
	 */
      public  NameValueVO  getUserType  (String ssoUserId)  throws  DBException; 
      
  	/**
  	 * @param request
  	 * @return   roles  for the user 
  	 * @throws DBException
  	 */
      
      boolean getUserRoles (String ssoUserId , String funcId) throws  BNPApplicationException; 
      
      /**
    	 * @param request
    	 * @return  List of CCY from disc_definition 
    	 * @throws BNPApplicationException
    	 */
      
     List <String> getAvlbleCcyFromDiscDefinition(String orgId) throws BNPApplicationException;
      
      // a40488   added for  CSCDEV-5365 ends 
     
	   
     
	  //a40488  Added for  time zone CSCDEV-5682   Starts 
      
     String getSupportBranchTimeZone(String orgId) throws BNPApplicationException;
     
     //a40488  Added for  timezone CSCDEV-5682   Ends 
     
    
     
     //a40488  added for facilutil ccy  CSCDEV-5813  Starts  
     boolean checkIsValidCurrency(String ccyCode) throws BNPApplicationException;
     //a40488  added for  facilutil ccy  CSCDEV-5813  Ends 
     
     
     
     
	
}
