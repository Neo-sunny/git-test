/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   18 March 2013
 * 
 * Purpose:      CommonFileProcessServiceImpl
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 March 2013        Oracle Financial Services Software Ltd                  Initial Version  
************************************************************************************************************************************************************/

package com.bnp.common.services.filemgmt;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.common.services.filemgmt.dao.ICommonFileProcessDao;
import com.bnp.scm.services.common.ILocaleMessageLoaderService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.interfaces.common.message.IMessageService;
import com.bnp.scm.services.invoice.IInvoiceUploadService;
import com.bnp.scm.services.invoice.vo.InvalidFileDataVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;

@Component
public class CommonFileProcessServiceImpl 
					implements ICommonFileProcessService {
	
	@Autowired
	private IInvoiceUploadService invoiceUploadService;
	
	@Autowired 
	private IMessageService messageService;
	
	@Autowired
	protected ILocaleMessageLoaderService msgService;
	
	@Autowired
	protected ICommonFileProcessDao commonFileDao;
	
	@Override
	public void checkForDuplicateFile(FileDetailsVO detailsVO)
			throws BNPApplicationException {
		Integer dupCnt = null;
		try {
			dupCnt = invoiceUploadService.duplicateFileCheck(detailsVO);
			if(dupCnt != null && dupCnt > 0) {
				throw new BNPApplicationException(ErrorConstants.DUPLICATE_FILE_ERROR);
			}
		} catch(BNPApplicationException ex) {
			throw ex;
		}
	}
	
	public void saveFileDetails(FileDetailsVO detailsVO) throws BNPApplicationException {
		invoiceUploadService.saveFileDetails(detailsVO);
	}

	@Override
	public void triggerEventLog(FileDetailsVO detailsVO, String action)
			throws BNPApplicationException {
		invoiceUploadService.triggerEventLog(detailsVO,action);
	}

	@Override
	public FileDetailsVO getHeaderDetails(FileDetailsVO detailsVO)
			throws BNPApplicationException {
		return invoiceUploadService.getHeaderDetails(detailsVO);
	}

	@Override
	public void insertFileUploadMessageDetails(FileDetailsVO detailsVO)
			throws BNPApplicationException {
		invoiceUploadService.insertFileUploadMessageDetails(detailsVO);
	}

	@Override
	public String getMessageId() throws BNPApplicationException {
		return commonFileDao.getMessageId();
	}

	@Override
	public void updateFileStatus(FileDetailsVO detailsVO)
			throws BNPApplicationException {
		invoiceUploadService.updateFileStatus(detailsVO);		
	}

	@Override
	public void updateERPDownloadForCustomFile(FileDetailsVO detailsVO,
			String status) throws BNPApplicationException {
		invoiceUploadService.updateERPDownloadForCustomFile(detailsVO, status);
	}

	@Override
	public <T> void sendMessage(AbstractMessage<T> message, String queueName,
			Map<String, String> jmsProperties) throws BNPApplicationException {
		messageService.sendMessage(message, queueName, jmsProperties);		
	}

	@Override
	public boolean canUploadPartialFile(String senderOrgId)
			throws BNPApplicationException {
		return commonFileDao.canUploadPartialFile(senderOrgId);
	}

	@Override
	public void insertInvalidRecords(
			List<InvalidFileDataVO> invalidList) throws BNPApplicationException {
		invoiceUploadService.insertInvalidDetails(invalidList);
	}
	
	@Override
	public boolean isAutoReleaseEnabled(String senderOrgId)
			throws BNPApplicationException {
		return commonFileDao.isAutoReleaseEnabled(senderOrgId);
	}

	@Override
	public void updateReprocessFlag(List<InvalidFileDataVO> invalidDataList,
			FileDetailsVO detailsVO) throws BNPApplicationException {
		commonFileDao.updateReprocessFlagForOldRejectedRecords(detailsVO);
	}
}
