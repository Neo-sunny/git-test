/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Jul 2014
 * 
 * Purpose:      WidgetDaoImpl
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 01 Jul 2014        Oracle Financial Services Software Ltd                  Initial Version
 * 05 AUG 2015         Saranya.M                                                R7.1   Widget Changes CSCDEV-5365
 * 18 AUG 2015         Saranya.M                                                CSC Centirc  Widget Changes CSCDEV-5365
 * 03 SEP 2015         Saranya.M                                                 CSC Centirc  TimeZone Enhancement  for CSCDEV-5682
 * 07 SEP 2015         Saranya.M                                                 CSC Centirc Ccy Validation  for CSCDEV-5813
 * 06 Nov 2015          Raja.S                                                 CSC Centric SSO User ID Changes CSCDEV-6818
************************************************************************************************************************************************************/
package com.bnp.common.services.widgets.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.common.services.widgets.pendingdiscounts.bindingvo.WidgetRequest;
import com.bnp.common.services.widgets.vo.MainGroupVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.util.BNPCommonUtil;


@Component
public class WidgetDaoImpl extends SqlMapClientWrapper implements IWidgetDAO {
	
	protected static final Logger logger = LoggerFactory.getLogger(WidgetDaoImpl.class);
	
	private static final String GET_PEND_DISC_DET_GRP_BY_CCY = "WidgetDetailsNS.getPendDiscDtlsGrpByCcy";
	private static final String GET_PEND_DISC_DET_GRP_BY_ORG = "WidgetDetailsNS.getPendDiscDtlsGrpByOrg";
	private static final String GET_OUT_SETT_DET_GRP_BY_CCY = "WidgetDetailsNS.getOutSetttDatesGrpByCcy";
	private static final String GET_OUT_SETT_DET_GRP_BY_ORG = "WidgetDetailsNS.getOutSetttDatesGrpByOrg";
	private static final String GET_FACILITY_UTILIZATION = "WidgetDetailsNS.getFacilityUtilization";
	private static final String GET_USER_TYPE ="WidgetDetailsNS.getUserType";
	
	
	// a40488 changes done for CSCDEV-5365 Starts
	private static final String GET_USER_ROLE = "WidgetDetailsNS.getUserRoles";
	private static final String GET_AVLBLE_CCY_CODE="WidgetDetailsNS.getAvaIlableCcyFromDiscDefinition";
	// a40488 changes done for CSCDEV-5365 Ends
	
	
	//a40488  Added for TimeZone enhancement  CSCDEV-5682 Starts	
	private static final String GET_TIME_ZONE="WidgetDetailsNS.getTimzoneforBranch";
	//a40488  Added for TimeZone enhancement  CSCDEV-5682  Ends
	
	
	//a40488  Added for ccy validation  CSCDEV-5813 Starts	
	 private static final String CHECK_IS_VALID_CCY="WidgetDetailsNS.checkIsValidCcy";
	 //a40488  Added for ccy validation  CSCDEV-5813  Ends
	
	
	
	
	/* (non-Javadoc)
	 * @see com.bnp.common.services.widgets.dao.IWidgetDAO#getPendingDiscountDetails(com.bnp.common.services.widgets.pendingdiscounts.bindingvo.WidgetRequest)
	 */
	@Override
	public List<MainGroupVO> getPendingDiscountDetails(WidgetRequest request)
			throws DBException {
		List<MainGroupVO> pendDisclist = new ArrayList<MainGroupVO>();
		NameValueVO userVO = null;
      // a40488 changes done for CSCDEV-5365 Starts
      boolean isFuncAvlble = false;
     try{
		String ssoUserId=request.getUserID();
		userVO = getUserType(ssoUserId);
		if (userVO != null) {
		//933039 Change done for CSCDEV-6818 Starts
        isFuncAvlble = getUserRoles(userVO.getName(), "CENTRICPENDINGDISCOUNT");
		//933039 Change done for CSCDEV-6818 ends
		if (isFuncAvlble) {
          //a40488 changes done for CSCDEV-5365 ends
		String userType = userVO.getValue();
		String userId = userVO.getName();
	
		Map<String, String> params = new HashMap<String, String>();	
		params.put("userId", userId);
		params.put("userType",userType);
		if(request.getGroupBy().getName().equalsIgnoreCase(BNPConstants.WS_CCY)) {
			if(!request.getGroupBy().getValue().equalsIgnoreCase(BNPConstants.WS_ALL)){
				params.put("ccyCode", request.getGroupBy().getValue());
			}	
				pendDisclist = getSqlMapClientTemplate().queryForList(GET_PEND_DISC_DET_GRP_BY_CCY,params);
			}
		else if(request.getGroupBy().getName().equalsIgnoreCase(BNPConstants.WS_ENTITY)){
			if(!request.getGroupBy().getValue().equalsIgnoreCase(BNPConstants.WS_ALL)){
				params.put("orgId", request.getGroupBy().getValue());
			}
				pendDisclist = getSqlMapClientTemplate().queryForList(GET_PEND_DISC_DET_GRP_BY_ORG,params);
			  }
	    }	
    // a40488 changes done for CSCDEV-5365 Starts
				else {
					throw new DBException(ErrorConstants.WIDGET_PENDING_ROLES);
                     }
			    }
		else {
				throw new DBException(ErrorConstants.INVALID_WIDUSERID);

			}
			// a40488 changes done for CSCDEV-5365 ends

		} catch (DataAccessException e) {
			logger.error("Error while retrieving pending discount details from  WidgetDaoImpl "
					+ e.getMessage());
			// throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		return pendDisclist;
	}

	/* (non-Javadoc)
	 * @see com.bnp.common.services.widgets.dao.IWidgetDAO#getOutstandingSettDetails(com.bnp.common.services.widgets.outstandingsett.bindingvo.WidgetRequest)
	 */
	@Override
	public List<MainGroupVO> getOutstandingSettDetails(
			com.bnp.common.services.widgets.outstandingsett.bindingvo.WidgetRequest request) throws DBException {
		List<MainGroupVO> outSettList = new ArrayList<MainGroupVO>();
		NameValueVO userVO = null;
      // a40488 changes done for CSCDEV-5365 starts
		boolean isFuncAvlble = false;
	try{
		String ssoUserId=request.getUserID();
		userVO = getUserType(ssoUserId);
     if (userVO != null) {
			 //933039 Change done for CSCDEV-6818 Starts
             isFuncAvlble = getUserRoles(userVO.getName(), "CENTRICSETTLEMENTDUE");
			//933039 Change done for CSCDEV-6818 ends	 
		if (isFuncAvlble) {
					// a40488 changes done for CSCDEV-5365 ends
		String userType = userVO.getValue();
		String userId = userVO.getName();
	    Map<String, String> params = new HashMap<String, String>();	
		params.put("userId", userId);
		params.put("userType",userType);
		if(request.getGroupBy().getName().equalsIgnoreCase(BNPConstants.WS_CCY)) {
			if(!request.getGroupBy().getValue().equalsIgnoreCase(BNPConstants.WS_ALL)){
				params.put("ccyCode", request.getGroupBy().getValue());
			}	
				outSettList = getSqlMapClientTemplate().queryForList(GET_OUT_SETT_DET_GRP_BY_CCY,params);
			}
		else if(request.getGroupBy().getName().equalsIgnoreCase(BNPConstants.WS_ENTITY)){
			if(!request.getGroupBy().getValue().equalsIgnoreCase(BNPConstants.WS_ALL)){
				params.put("orgId", request.getGroupBy().getValue());
			}
			outSettList = getSqlMapClientTemplate().queryForList(GET_OUT_SETT_DET_GRP_BY_ORG,params);
			}
		  }
		// a40488 changes done for CSCDEV-5365 starts

		else {
			throw new DBException(ErrorConstants.WIDGET_SETTLEMENT_ROLES);

		}
	}

		else {
				throw new DBException(ErrorConstants.INVALID_WIDUSERID);
			} // a40488 changes done for CSCDEV-5365 ends

		} catch (DataAccessException e) {
			logger.error("Error while retrieving outstanding settlement details from WidgetDaoImpl "
					+ e.getMessage());
			// throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		return outSettList;
	}
	
		/* (non-Javadoc)
		 * @see com.bnp.common.services.widgets.dao.IWidgetDAO#getFacilityUtilizationDetails(com.bnp.common.services.widgets.facilityutil.bindingvo.WidgetRequest)
		 */
		public List<MainGroupVO> getFacilityUtilizationDetails(
				com.bnp.common.services.widgets.facilityutil.bindingvo.WidgetRequest request) throws DBException {
		List<MainGroupVO> facilityUtilList = null;
		NameValueVO userVO = null;
		
		// a40488 changes done for CSCDEV-5365 starts
        boolean isFuncAvlble = false;
		try {		
		String ssoUserId=request.getUserID();
		userVO = getUserType(ssoUserId);
		
		if (userVO != null) {
				
				//933039 Change done for CSCDEV-6818 Starts
		isFuncAvlble = getUserRoles(userVO.getName(),
						"CENTRICFACILITYUTILIZATION");
				//933039 Change done for CSCDEV-6818 ends
				if (isFuncAvlble) {
		String userType = userVO.getValue();
		String userId = userVO.getName();
		
			Map<String, String> params = new HashMap<String, String>();
			params.put("userId", userId);
			params.put("userType",userType);
			if(!request.getGroupBy().getValue().equalsIgnoreCase(BNPConstants.WS_DEFAULT)){
				params.put("ccyCode", request.getGroupBy().getValue());
			}
			facilityUtilList = getSqlMapClientTemplate().queryForList(GET_FACILITY_UTILIZATION, params);
			 } // a40488 changes done for CSCDEV-5365 starts
				else {
					throw new DBException(ErrorConstants.WIDGET_FACILITY_ROLES);
				}
			}
		else {
				throw new DBException(ErrorConstants.INVALID_WIDUSERID);
			}
		} // a40488 changes done for CSCDEV-5365 ends

		catch (DataAccessException e) {
			logger.error("Error while retrieving facility utilization details from WidgetDaoImpl" 
					+ e.getMessage());
			// throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		return facilityUtilList;
	}
	
		public NameValueVO getUserType(String ssoUserId) throws DBException{
			NameValueVO userVO = null;
		try {
			userVO = (NameValueVO) getSqlMapClient().queryForObject(
					GET_USER_TYPE, ssoUserId);
			// a40488 changes done for widget starts
			if (userVO == null) {
				throw new DBException(ErrorConstants.INVALID_WIDUSERID);
			}
			// a40488 changes done for widget ends
		} catch (Exception e) {
			// 976332 CSCDEV-2683 17-NOV-2014:START
			// e.printStackTrace();
			logger.error("Error while retrieving getUserType details"
					+ e.getMessage());
			// 976332 CSCDEV-2683 17-NOV-2014:END

		}
		return userVO;
		}
// a40488 changes done for CSCDEV-5365 starts
			
	
		
	public boolean getUserRoles(String ssoUserId, String funcId)
			throws DBException {

		boolean isFuncAvailable = false;
		int count = 0;

		try {
			Map<String, String> params = new HashMap<String, String>();

			params.put("ssoUserId", ssoUserId);
			params.put("funcId", funcId);

			count = (Integer) getSqlMapClientTemplate().queryForObject(
					GET_USER_ROLE, params);
			if (count > 0) {
				isFuncAvailable = true;
			}
		} catch (Exception e) {
			logger.error("Error while retrieving Get_USER_ROLE details from WidgetDaoImpl "
					+ e.getMessage());

		}
		return isFuncAvailable;
	}
 	
	@Override
	public List<String> getAvlbleCcyFromDiscDefinition(String orgId) throws BNPApplicationException{
		List<String> ccyList = null;
		try{
			ccyList=  getSqlMapClientTemplate().queryForList(GET_AVLBLE_CCY_CODE, orgId);
		}catch(Exception e){
			logger.error("DataAccessException in getAvlbleCcyFromDiscDefinition:",e);
			throw new BNPApplicationException(ErrorConstants.ERROR_CONDITION_FETCH);
		}
		return ccyList;
	}
	 // a40488 changes done for CSCDEV-5365 ends
	
	
    //a40488  Added for Time Zone Enhancement  CSCDEV-5682   Starts	
	@Override
	public String getSupportBranchTimeZone(String orgId) throws BNPApplicationException {
		 String timeZone = null;
		 try {
			 timeZone = (String)getSqlMapClientTemplate().queryForObject(GET_TIME_ZONE, orgId);
			 timeZone = BNPCommonUtil.getTimeZoneID(timeZone);
			} catch (DataAccessException e) {
			 logger.error("Error while retrieving support branch time zone " + e.getMessage());
			 throw new DBException(ErrorConstants.DATABASE_ERROR);
		 }
		 return timeZone;
	 }
	 //a40488  Added for Time Zone enhancement  CSCDEV-5682   Ends	
	
	
	// a40488 added for ccy validation for CSCDEV-5813 Starts	
	
	@Override
	public boolean  checkIsValidCurrency(String ccyCode) throws BNPApplicationException{
		
		
		boolean isValidCcy = true;
		int count = 0;
		
		try{
			count = (Integer) getSqlMapClientTemplate().queryForObject(CHECK_IS_VALID_CCY, ccyCode);
			if (count == 0) {
				isValidCcy = false;
			}
			
			
			
		} catch (DataAccessException e) {
			logger.error("Error while checking the CCY in checkIsValidCurrency from WidgetDaoImpl "
					+ e.getMessage());
			 throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		
		return isValidCcy;
	}
	
	
   // a40488 added for ccy validation for CSCDEV-5813 ends		
	
}
