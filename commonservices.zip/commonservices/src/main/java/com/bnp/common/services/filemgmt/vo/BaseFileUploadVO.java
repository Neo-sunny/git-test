/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   18 March 2013
 * 
 * Purpose:      BaseFileUploadVO
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 March 2013        Oracle Financial Services Software Ltd                  Initial Version
************************************************************************************************************************************************************/
package com.bnp.common.services.filemgmt.vo;

import com.bnp.scm.services.common.vo.AbstractVO;

/**
 * @author prabakarans
 *
 */
public abstract class BaseFileUploadVO extends AbstractVO{ 
	
	private String branchShortName;
	
	private String branchCode;
	
	private long fileId;
	
	private String status;
	
	private long pkId;
	
	private String refNo;

	private int errorCode;
	
	private String errorMsg;
	/**
	 * @return the branchShortName
	 */
	public String getBranchShortName() {
		return branchShortName;
	}

	/**
	 * @param branchShortName the branchShortName to set
	 */
	public void setBranchShortName(String branchShortName) {
		this.branchShortName = branchShortName;
	}

	/**
	 * @return the branchCode
	 */
	public String getBranchCode() {
		return branchCode;
	}

	/**
	 * @param branchCode the branchCode to set
	 */
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	/**
	 * @return the fileId
	 */
	public long getFileId() {
		return fileId;
	}

	/**
	 * @param fileId the fileId to set
	 */
	public void setFileId(long fileId) {
		this.fileId = fileId;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the pkId
	 */
	public long getPkId() {
		return pkId;
	}

	/**
	 * @param pkId the pkId to set
	 */
	public void setPkId(long pkId) {
		this.pkId = pkId;
	}
	
	/**
	 * @return the refNo
	 */
	public String getRefNo() {
		return refNo;
	}

	/**
	 * @param refNo the refNo to set
	 */
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	
	public abstract String toDataString(); 		
	
	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	} 		
}
