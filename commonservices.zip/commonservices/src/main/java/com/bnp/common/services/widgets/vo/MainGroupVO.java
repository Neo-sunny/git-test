/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   04 Jul 2014
 * 
 * Purpose:      MainGroupVO 
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ------------------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 04 Jul 2014                      Oracle Financial Services Software Ltd                                 Initial Version  created for Widgets
 *05 AUG 2015                       Raja S 						                                           R7.1  Widget Changes CSCDEV-5365
 *18  AUG 2015                      Saranya .M                                                             CSC Centirc Widget Changes-5365  
 *03  SEP 2015                      Saranya.M                                                              CSC Centric  TimeZone Enhancement for CSCDEV-5682                           
 *****************************************************************************************************************************************************************/
package com.bnp.common.services.widgets.vo;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class MainGroupVO {
	
	private static final long serialVersionUID = 1L;
	
	private String ccyCode;
	
	private String orgId;
	

	private int parentCount;
	
	private BigDecimal parentLevelSum;
	
	private int childCount;
	
	private BigDecimal childLevelSum;
	
	private String ssoUserId;

	private String groupName;

	private String convertedCcyCode;

	private BigDecimal grantedAmt;

	private BigDecimal convertGrantedAmt;

	private BigDecimal utilizedAmt;

	private BigDecimal convertedUtilizedAmt;

	private BigDecimal availableAmt;

	private BigDecimal convertedAvailableAmt;

	private BigDecimal initiatedAmt;
	
	private BigDecimal convertedInitiatedAmt;
	
	private Date settlementDate;
	
	private List<MainGroupVO> mainGrpList;
	
	private List<MainGroupVO> childList;
	
	private String userType;
	
	private String labelToDisplay;
	
	private BigDecimal effectiveAvailable;
	
   //a40488   added for widgets  CSCDEV-5365 starts 
	
    private List<String> ccyList;

	public List<String> getCcyList() {
		return ccyList;
	}

	public void setCcyList(List<String> ccyList) {
		this.ccyList = ccyList;
	}
	
	
	private String tOrgId;

	public String gettOrgId() {
		return tOrgId;
	}

	public void settOrgId(String tOrgId) {
		this.tOrgId = tOrgId;
	}
	
    //a40488   added for widgets CSCDEV-5365 Ends 
	
	
	//a40488   added for widgets CSCDEV-5682 Ends 
	private String  zoneId;

	public String getZoneId() {
		return zoneId;
	}

	public void setZoneId(String zoneId) {
		this.zoneId = zoneId;
	 }
	
	 //a40488 added for widgets CSCDEV-5682 Ends 


	public String getLabelToDisplay() {
		return labelToDisplay;
	}

	public void setLabelToDisplay(String labelToDisplay) {
		this.labelToDisplay = labelToDisplay;
	}

	public BigDecimal getEffectiveAvailable() {
		return effectiveAvailable;
	}

	public void setEffectiveAvailable(BigDecimal effectiveAvailable) {
		this.effectiveAvailable = effectiveAvailable;
	}
	
	public String getCcyCode() {
		return ccyCode;
	}

	public void setCcyCode(String ccyCode) {
		this.ccyCode = ccyCode;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public int getParentCount() {
		return parentCount;
	}

	public void setParentCount(int parentCount) {
		this.parentCount = parentCount;
	}

	public BigDecimal getParentLevelSum() {
		return parentLevelSum;
	}

	public void setParentLevelSum(BigDecimal parentLevelSum) {
		this.parentLevelSum = parentLevelSum;
	}

	public List<MainGroupVO> getChildList() {
		return childList;
	}

	public void setChildList(List<MainGroupVO> childList) {
		this.childList = childList;
	}

	public String getSsoUserId() {
		return ssoUserId;
	}

	public void setSsoUserId(String ssoUserId) {
		this.ssoUserId = ssoUserId;
	}

	public Date getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(Date settlementDate) {
		this.settlementDate = settlementDate;
	}

	public List<MainGroupVO> getMainGrpList() {
		return mainGrpList;
	}

	public void setMainGrpList(List<MainGroupVO> mainGrpList) {
		this.mainGrpList = mainGrpList;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getConvertedCcyCode() {
		return convertedCcyCode;
	}

	public void setConvertedCcyCode(String convertedCcyCode) {
		this.convertedCcyCode = convertedCcyCode;
	}

	
	public BigDecimal getGrantedAmt() {
		return grantedAmt;
	}

	public void setGrantedAmt(BigDecimal grantedAmt) {
		this.grantedAmt = grantedAmt;
	}

	public BigDecimal getConvertGrantedAmt() {
		return convertGrantedAmt;
	}

	public void setConvertGrantedAmt(BigDecimal convertGrantedAmt) {
		this.convertGrantedAmt = convertGrantedAmt;
	}

	public BigDecimal getUtilizedAmt() {
		return utilizedAmt;
	}

	public void setUtilizedAmt(BigDecimal utilizedAmt) {
		this.utilizedAmt = utilizedAmt;
	}

	public BigDecimal getConvertedUtilizedAmt() {
		return convertedUtilizedAmt;
	}

	public void setConvertedUtilizedAmt(BigDecimal convertedUtilizedAmt) {
		this.convertedUtilizedAmt = convertedUtilizedAmt;
	}

	public BigDecimal getAvailableAmt() {
		return availableAmt;
	}

	public void setAvailableAmt(BigDecimal availableAmt) {
		this.availableAmt = availableAmt;
	}

	public BigDecimal getConvertedAvailableAmt() {
		return convertedAvailableAmt;
	}

	public void setConvertedAvailableAmt(BigDecimal convertedAvailableAmt) {
		this.convertedAvailableAmt = convertedAvailableAmt;
	}

	public BigDecimal getInitiatedAmt() {
		return initiatedAmt;
	}

	public void setInitiatedAmt(BigDecimal initiatedAmt) {
		this.initiatedAmt = initiatedAmt;
	}

	public BigDecimal getConvertedInitiatedAmt() {
		return convertedInitiatedAmt;
	}

	public void setConvertedInitiatedAmt(BigDecimal convertedInitiatedAmt) {
		this.convertedInitiatedAmt = convertedInitiatedAmt;
	}

	public int getChildCount() {
		return childCount;
	}

	public void setChildCount(int childCount) {
		this.childCount = childCount;
	}

	public BigDecimal getChildLevelSum() {
		return childLevelSum;
	}

	public void setChildLevelSum(BigDecimal childLevelSum) {
		this.childLevelSum = childLevelSum;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}
	
}
