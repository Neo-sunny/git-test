/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   18 March 2013
 * 
 * Purpose:      AbstractFileProcessorFactory
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 March 2013        Oracle Financial Services Software Ltd                  Initial Version
************************************************************************************************************************************************************/
package com.bnp.common.services.filemgmt.factory;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.filemgmt.factory.FileProcessorFactory;

/**
 * @author prabakarans
 *
 */
@Component
public class AbstractFileProcessorFactory {
	
	@Autowired
	private BeanFactory beanFactory;
	
	public SCFFileProcessorFactory getScfFileProcessorFactory() {
		return (SCFFileProcessorFactory) beanFactory.getBean(
				"scfFileProcessorFactory");		
	}
	
	public FileProcessorFactory getEippFileProcessorFactory() {
		return (FileProcessorFactory) beanFactory.getBean(
				"fileProcessorFactory");
	}

}
