/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   18 March 2013
 * 
 * Purpose:      AbstractDataFileProcessor
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 March 2013        Oracle Financial Services Software Ltd                  Initial Version
************************************************************************************************************************************************************/

package com.bnp.common.services.filemgmt.processor;

import java.util.ArrayList;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnp.common.services.filemgmt.ICommonFileProcessService;
import com.bnp.common.services.filemgmt.ICommonFileUploadService;
import com.bnp.common.services.filemgmt.vo.BaseFileUploadVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.ILocaleMessageLoaderService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.invoice.vo.InvalidFileDataVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;
import com.bnp.scm.services.txns.common.message.bindingvo.RootXmlElement;

/**
 * This class serves as a base class for all file upload functionality.
 *  
 * @author prabakarans
 *
 * @param <X> - The JAXB class name of the root element of the corresponding XML. 
 * @param <V> - The value object used for the corresponding file upload
 */
public abstract class AbstractDataFileProcessor<X extends RootXmlElement, V extends BaseFileUploadVO> 
						implements IAbstractDataFileProcessor<X , V> {
	
	protected static final Logger LOGGER = LoggerFactory.getLogger(AbstractDataFileProcessor.class);
	
	@Autowired
	protected ICommonFileProcessService fileProcessService;
	
	@Autowired
	protected BNPPropertyLoaderConfigurer propertyLoader;
	
	@Autowired
	protected ILocaleMessageLoaderService localeMsgService;
	
	/**
	 * Holds the data objects from the XML
	 */
	protected List<X> xmlDataList;
	
	/**
	 * Holds the valid business value objects
	 */
	protected List<V> validDataList;
	
	/**
	 * Holds the invalid data
	 */
	protected List<InvalidFileDataVO> invalidDataList;
	
	/**
	 * Holds all the business value objects which will be used for generating functional ack
	 */
	protected List<V> dataList;

	/**
	 * Mapper class to map the values from JAXB object to Business value object
	 */
	protected DozerBeanMapper beanMapper;
	
	/**
	 * Holds the file details
	 */
	protected FileDetailsVO detailsVO;

	/**
	 * Default constructor
	 */
	protected AbstractDataFileProcessor() {
		invalidDataList = new ArrayList<InvalidFileDataVO>();
		validDataList = new ArrayList<V>();
		dataList = new ArrayList<V>();
		beanMapper = new DozerBeanMapper(getMappingFiles());
	}
	
	/**
	 * This API will return the list of mapping files that will be used to copy the 
	 * values from the JAXB objects to the business value objects
	 * @return a list of mapping files
	 */
	protected abstract List<String> getMappingFiles();
	
	/**
	 * This API processes the JAXB object and copies all the values from the JAXB to the corresponding
	 * business value object.
	 * @param xmlData - JAXB object
	 * @return the business value object with all the values copied
	 */
	protected abstract V getValueObject(X xmlData); 
	
	/**
	 * This API will be used to perform functional validations
	 * @param valueObj - Business value object on which the functional validations will be applied
	 * @return returns whether the value object is a valid oen or not
	 * @throws BNPApplicationException
	 */
	protected abstract boolean isValidData(V valueObj) throws BNPApplicationException;
	
	/**
	 * This API returns the list of JAXB objects extracted from the XML
	 * @param msg - the message object of the corresponding XML
	 * @return the list of JAXB objects
	 */
	protected abstract List<X> getXmlDataList(AbstractMessage<?> msg);
	
	/**
	 * Abstract API to return the service instance of the corresponding file processor
	 * @return the service instance of the processor class
	 */
	protected abstract ICommonFileUploadService<V> getFileUploadService();
	
	/**
	 * This API inserts the details of the business value objects into their corresponding trans table
	 * @param valueObjectList
	 * @throws BNPApplicationException
	 */
	protected void insertFileDetailsIntoTrans(
			List<V> valueObjectList) throws BNPApplicationException {
		getFileUploadService().insertFileDetailsIntoTrans(valueObjectList);
	}
	
	/**
	 * This API inserts the details of the business value objects from trans into history
	 * @param detailsVO
	 * @throws BNPApplicationException
	 */
	protected void insertFileDetailsIntoHistFromTrans(
				FileDetailsVO detailsVO) throws BNPApplicationException {
		getFileUploadService().insertFileDetailsIntoHistFromTrans(detailsVO);
	}
	
	/**
	 * This API releases the file based on the load type flag
	 * @param msg - the Message object of the corresponding XML
	 * @param detailsVO - the details of the file
	 * @throws BNPApplicationException
	 */
	protected void releaseFile(
			AbstractMessage<?> msg, FileDetailsVO detailsVO) throws BNPApplicationException {
		getFileUploadService().releaseFile(msg, detailsVO);
	}
	
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	protected void deleteFile(
			FileDetailsVO detailsVO) throws BNPApplicationException {
		getFileUploadService().deleteFile(detailsVO);
	}
	
	protected boolean isAutoReleaseEnabled(
			FileDetailsVO detailsVO) throws BNPApplicationException {
		return fileProcessService.isAutoReleaseEnabled(detailsVO.getSenderOrgId());
	}
	
	protected boolean isPartialUploadEnabled(
			FileDetailsVO detailsVO) throws BNPApplicationException {
		return fileProcessService.canUploadPartialFile(
								detailsVO.getSenderOrgId());
	}
	
	/**
	 * This API processes the input file
	 * @param msg - the message object of the corresponding XML
	 * @param detailsVO
	 * @throws BNPApplicationException
	 */
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	public void processFile(AbstractMessage<?> msg, FileDetailsVO detailsVO) 
							throws BNPApplicationException {
		
		this.xmlDataList = getXmlDataList(msg);
		this.detailsVO = detailsVO;
		
		V valueObj = null;
		for (X xmlData : xmlDataList) {
			valueObj = getValueObject(xmlData);
			
			if (isValidData(valueObj)) {
				validDataList.add(valueObj);
			}
			dataList.add(valueObj);
		}
		
		if (validDataList == null || validDataList.isEmpty()) {
			detailsVO.setFileUploadStatus(StatusConstants.VALIDATION_FAILED);
			detailsVO.setFileStatus(StatusConstants.VALIDATION_FAILED);
			detailsVO.setErrorCode(Integer.toString(ErrorConstants.NO_VALID_RECORDS_FOUND));
			detailsVO.setErrorDesc("No valid records found");
			fileProcessService.updateFileStatus(detailsVO);
			if(!(detailsVO.getInstrumentType().equals("20") ||
			   detailsVO.getInstrumentType().equals("21") ||
			  detailsVO.getInstrumentType().equals("22") || 
			  detailsVO.getInstrumentType().equals("23"))){
			fileProcessService.triggerEventLog(detailsVO,"FAILURE");
			}
		} else {
			
			boolean canUploadPartialFile = isPartialUploadEnabled(detailsVO);
			
			insertFileDetailsIntoTrans(validDataList);
			insertFileDetailsIntoHistFromTrans(detailsVO);
			fileProcessService.updateReprocessFlag(invalidDataList, detailsVO);
			
			if (!canUploadPartialFile && !invalidDataList.isEmpty()) {
				detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.validation.fail"));
				detailsVO.setFileStatus(StatusConstants.VALIDATION_FAILED);
				detailsVO.setErrorDesc("Business validation failed for few records and " +
						"partial upload is not supported for the Organization " + detailsVO.getSenderOrgId());
				detailsVO.setCurrentUserId(BNPConstants.SYSTEM);				
				deleteFile(detailsVO);
				validDataList.clear();
				if(!(detailsVO.getInstrumentType().equals("20") ||
						   detailsVO.getInstrumentType().equals("21") ||
						  detailsVO.getInstrumentType().equals("22") || 
						  detailsVO.getInstrumentType().equals("23"))){
				fileProcessService.triggerEventLog(detailsVO,"FAILURE");
			} 
		}
		}
		
		if (!invalidDataList.isEmpty()) {
			fileProcessService.insertInvalidRecords(invalidDataList);
		}
		
		boolean isAutoRelease = isAutoReleaseEnabled(detailsVO);
		
		if (isAutoRelease && !validDataList.isEmpty()) {
			detailsVO.setReleasedBy(BNPConstants.SYSTEM);
			releaseFile(msg, detailsVO);
		}
		else {
			if (validDataList != null && !validDataList.isEmpty()) {
				detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.release.pending"));
				fileProcessService.updateFileStatus(detailsVO);
				if(!(detailsVO.getInstrumentType().equals("20") ||
						   detailsVO.getInstrumentType().equals("21") ||
						  detailsVO.getInstrumentType().equals("22") || 
						  detailsVO.getInstrumentType().equals("23"))){
				fileProcessService.triggerEventLog(detailsVO,"SUCCESS");
			}
		}
	}
	}

	protected boolean isNull(String userInput){
		if (userInput != null && userInput.trim().length() > 0) {
			return false;	
		} else {
			return true;
		}
	}
	
	protected void addToErrorDataList (String transactionType , 
			int errorCode, BaseFileUploadVO fileUploadVO) {
		InvalidFileDataVO invalidData = createInvalidFileDataVO(transactionType, 
				fileUploadVO.toDataString(), errorCode, fileUploadVO.getRefNo());
		invalidDataList.add(invalidData);
	}
	
	protected InvalidFileDataVO createInvalidFileDataVO(String transactionType,String errorData, 
			int errorCode, String refNo) {
		InvalidFileDataVO invalidData = new InvalidFileDataVO();
		invalidData.setFileID(detailsVO.getFileId());
		invalidData.setErrorMessage(String.valueOf(errorCode));
		invalidData.setErrorData(errorData);
		invalidData.setPaymentType(transactionType);
		invalidData.setErrorDescription(localeMsgService.getMessage("en_US", errorCode));
		invalidData.setRefNo(refNo);
		return invalidData;
	}
	
	/**
	 * Checks if is string empty.
	 *
	 * @param input the input
	 * @return true, if is string empty
	 */
	protected boolean isStringEmpty(String input){
		if(input == null || input.trim().length() == 0){
			return true;
		}
		return false;
	}
}
