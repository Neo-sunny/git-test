/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   18 March 2013
 * 
 * Purpose:      CustomFileService
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 March 2013        Oracle Financial Services Software Ltd                  Initial Version
************************************************************************************************************************************************************/
package com.bnp.common.services.filemgmt.filetype;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;

/**
 * @author prabakarans
 *
 */
@Component ("customFileService")
public class CustomFileService extends AbstractFileService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CustomFileService.class);

	@Override
	protected void processFile(FileDetailsVO detailsVO)
			throws BNPApplicationException {

		detailsVO.setTransmissionId(detailsVO.getMsgId());
		fileProcessorService.saveFileDetails(detailsVO);
		
		try {
			AbstractMessage<?> message = msgBuilder.prepareCustomMessage(detailsVO);
			msgBuilder.sendMessage(detailsVO, message);
		} catch (BNPApplicationException exception) {
			LOGGER.error("Error while processing custom file :: {} ",exception);
			detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.load.not"));
			detailsVO.setErrorCode(Integer.toString(exception.getErrorCode()));
			detailsVO.setErrorDesc(exception.getErrorMessage());
			fileProcessorService.updateFileStatus(detailsVO);
			fileProcessorService.triggerEventLog(detailsVO, "FAILURE");
			throw exception;
		}
	
	}

}
