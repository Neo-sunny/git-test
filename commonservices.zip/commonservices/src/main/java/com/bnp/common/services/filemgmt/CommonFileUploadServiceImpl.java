/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   18 March 2013
 * 
 * Purpose:      CommonFileUploadServiceImpl
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 March 2013        Oracle Financial Services Software Ltd                  Initial Version  
************************************************************************************************************************************************************/
package com.bnp.common.services.filemgmt;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnp.common.services.filemgmt.vo.BaseFileUploadVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.invoice.IReleaseFileService;
import com.bnp.scm.services.txns.common.message.AbstractMessage;

/**
 * @author prabakarans
 *
 */
public abstract class CommonFileUploadServiceImpl<V extends BaseFileUploadVO> 
				implements ICommonFileUploadService<V> {
	
	@Autowired 
	 private IReleaseFileService releaseFileService;
	
	@Override
	public void insertFileDetailsIntoTrans(List<V> valueObjectList)
			throws BNPApplicationException {
		getFileUploadDao().insertFileDetailsIntoTrans(valueObjectList);
	}

	@Override
	public void insertFileDetailsIntoHistFromTrans(FileDetailsVO detailsVO)
			throws BNPApplicationException {
		getFileUploadDao().insertFileDetailsIntoHistFromTrans(detailsVO);
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	public void releaseFile(AbstractMessage<?> msg, FileDetailsVO detailsVO)
			throws BNPApplicationException {
		releaseFileService.updateFileStatusForRelease(detailsVO.getFileId(), detailsVO.getReleasedBy());
		getFileUploadDao().releaseFile(detailsVO);
		postRelease(msg, detailsVO);
	}

	@Override
	public void deleteFile(FileDetailsVO detailsVO)
			throws BNPApplicationException {
		releaseFileService.updateFileStatusForDelete(detailsVO.getFileId(),detailsVO.getCurrentUserId());
		getFileUploadDao().deleteFile(detailsVO);
	}

}
