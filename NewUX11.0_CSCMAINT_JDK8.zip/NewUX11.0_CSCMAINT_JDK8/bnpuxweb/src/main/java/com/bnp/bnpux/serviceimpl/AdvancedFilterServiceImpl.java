/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   02-Mar-2017
 * 
 * Purpose:      Advanced Filter Service Implementation
 * 
 * Change History:
 *  
 * Date                       Author                                            Reason
 * 02-Mar-2017			Bala Murugan Elangovan					Base version for Advanced filter Service implementation 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.serviceimpl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.common.vo.AdvancedFilterVO;
import com.bnp.bnpux.constants.PaymentOrderConstants;
import com.bnp.bnpux.dao.IAdvancedFilterDAO;
import com.bnp.bnpux.service.IAdvancedFilterService;
import com.bnp.bnpux.vo.requestVO.AdvancedFilterRequestVO;
import com.bnp.bnpux.vo.responseVO.AdvancedFilterResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@Component
public class AdvancedFilterServiceImpl implements IAdvancedFilterService {

	
	@Autowired
	/**
	 * IAdvancedFilterDAO advancedFilterDAO
	 */
	private IAdvancedFilterDAO advancedFilterDAO;
	
	/**
	 * Logger log for AdvancedFilterServiceImpl class
	 */
	private static final Logger log = LoggerFactory.getLogger(AdvancedFilterServiceImpl.class);
	
	/**
	 * Constant for Exception message
	 */
	public static final String EXCEPTION_UNABLE_TO_PROCESS = "Unable to process action - Database Exception";

	
	@Override
	/**
	 * This method is used to get configurable Advanced Filters elements
	 * 
	 * @param advanceFiterRequsetVO 
	 * @return advanceFiterRequsetVO
	 */
	public AdvancedFilterVO getAdvancedFiltersList(AdvancedFilterVO advanceFiterRequsetVO) throws BNPApplicationException{
		try{
			List<AdvancedFilterVO> advancedFilterList = new ArrayList<AdvancedFilterVO>(); 
			AdvancedFilterVO periodFilterVO = new AdvancedFilterVO();			
			advancedFilterDAO.getAdvancedFiltersList(advanceFiterRequsetVO);		
			advancedFilterList.add(periodFilterVO);
			advancedFilterList.addAll(advanceFiterRequsetVO.getAdvancedFilterList());			
			advanceFiterRequsetVO.setAdvancedFilterList(advancedFilterList);		
			advancedFilterDAO.getPeriodFilterDate(advanceFiterRequsetVO);			
			advanceFiterRequsetVO.setPeriodFromDate(advanceFiterRequsetVO.getPeriodFromDate());
			advanceFiterRequsetVO.setPeriodToDate(advanceFiterRequsetVO.getPeriodToDate());			
			List<AdvancedFilterVO> userFiterList = advancedFilterDAO.getUserPreferenceFilterList(advanceFiterRequsetVO);
			advanceFiterRequsetVO.setUserFilterObject(userFiterList);
		}catch(DataAccessException exception){
			log.error(EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(EXCEPTION_UNABLE_TO_PROCESS);	
		}		
		return advanceFiterRequsetVO;
	}

	//Added for S038
	/**
	 * This method is used for converting the string date of dd-MMM-YYYY format to Date
	 * @param String Date
	 * @return Date
	 */
	private Date converToDate(String dateStr){
		Date convertedDate;
		 SimpleDateFormat formatter = new SimpleDateFormat(PaymentOrderConstants.DATE_FORMAT_DD_MMM_YYY);
	        try {
	        	convertedDate = formatter.parse(dateStr);
	        } catch (ParseException e) {
	        	convertedDate =null;
	        	log.error(EXCEPTION_UNABLE_TO_PROCESS, e);
	        }
	        
	 return convertedDate ;    
	}
	

	@Override
	/**
	 * This method is perform actions like save,edit,remove,fetch in advanced filter
	 * 
	 * @param advanceFiterRequsetVO 
	 * @return advanceFiterRequsetVO
	 */
	public AdvancedFilterResponseVO doAdvancedFilterAction(AdvancedFilterRequestVO advanceFiterRequsetVO) throws BNPApplicationException {
		AdvancedFilterResponseVO responseVO = new AdvancedFilterResponseVO();		
		try{
			if(advanceFiterRequsetVO != null){
				if(advanceFiterRequsetVO.getGetWhat() != null && (advanceFiterRequsetVO.getGetWhat().equals(PaymentOrderConstants.ADV_FLTR_GET) || advanceFiterRequsetVO.getGetWhat().equals(PaymentOrderConstants.ADV_FLTR_DELETE))){
					responseVO = advancedFilterDAO.fetchAdvancedFilterAction(advanceFiterRequsetVO);
					//Added for S038 :added for converting string date to date :starts
					List<AdvancedFilterVO> advancedFilterList =advanceFiterRequsetVO.getAdvancedFilterList();
					for(AdvancedFilterVO advVo : advancedFilterList){
						if(advVo != null && ("DATE".equals(advVo.getDataType()) || "periodFilter".equals(advVo.getScreenRefFieldId()))){
							if(advVo.getFromValue() != null && advVo.getFromValue()!=""){
								advVo.setPeriodFromDate(converToDate(advVo.getFromValue()));
							}
							if(advVo.getToValue() != null && advVo.getToValue()!=""){
								advVo.setPeriodToDate(converToDate(advVo.getToValue()));
							}
						}
					}
					//Added for S038 :added for converting string date to date :ends					
				}
				else {					
					advancedFilterDAO.doAdvancedFilterAction(advanceFiterRequsetVO);					
					responseVO.setErrorMsg(advanceFiterRequsetVO.getErrorFlag());
				}
			}
		}catch(DataAccessException exception){			
			log.debug(EXCEPTION_UNABLE_TO_PROCESS + exception.getMessage());
			log.error(EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(EXCEPTION_UNABLE_TO_PROCESS);
		}
		return responseVO;
	}
	
	
	
}
