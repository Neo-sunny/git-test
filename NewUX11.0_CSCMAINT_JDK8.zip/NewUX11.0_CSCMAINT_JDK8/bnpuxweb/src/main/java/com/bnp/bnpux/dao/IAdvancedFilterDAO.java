/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   02-Mar-2017
 * 
 * Purpose:      Advanced Filter DAO
 * 
 * Change History:
 *  
 * Date                       Author                                            Reason
 * 02-Mar-2017			Bala Murugan Elangovan					Base version for Advanced filter DAO
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.dao;

import java.util.List;

import com.bnp.bnpux.common.vo.AdvancedFilterVO;
import com.bnp.bnpux.vo.requestVO.AdvancedFilterRequestVO;
import com.bnp.bnpux.vo.responseVO.AdvancedFilterResponseVO;

public interface IAdvancedFilterDAO {

	/**
	 * Method is used to get Advanced Filters List
	 * @param advanceFiterRequsetVO
	 * @return
	 */
	List<AdvancedFilterVO> getAdvancedFiltersList(AdvancedFilterVO advanceFiterRequsetVO);	

	/**
	 * Method is used to get Period Filters Date
	 * @param advanceFiterRequsetVO
	 * @return
	 */
	List<AdvancedFilterVO> getPeriodFilterDate(AdvancedFilterVO advanceFiterRequsetVO);

	/**
	 * getUserPreferenceFilterList
	 * @param advanceFiterRequsetVO
	 * @return
	 */
	List<AdvancedFilterVO> getUserPreferenceFilterList(AdvancedFilterVO advanceFiterRequsetVO);

	/**
	 * doAdvancedFilterAction
	 * @param advanceFiterRequsetVO
	 * @return
	 */
	AdvancedFilterResponseVO  doAdvancedFilterAction(AdvancedFilterRequestVO advanceFiterRequsetVO);
	
	/**
	 * fetchAdvancedFilterAction
	 * @param advanceFiterRequsetVO
	 * @return
	 */
	AdvancedFilterResponseVO  fetchAdvancedFilterAction(AdvancedFilterRequestVO advanceFiterRequsetVO);

	
}
