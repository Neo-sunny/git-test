/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:      Branch Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
************************************************************************************************************************************************************/

package com.bnp.csc.services.common.vo;

import java.io.Serializable;
import java.util.Date;

public class BranchVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6553792643306749201L;

	private String id;
	
	private String branchId;
	private String branchName;
	private String branchCode;
	private String shortName;
	private String country;
	private String telephone;
	private String address;
	private String state;
	private String twofactor;
	private String language;
	private String postalCode;
	private String city;
	private String fax;
	private String timeZone;
	private String mailerLanguage;
	private String rateType;
	private String discountingSystem;
	private String createdId;
	private String currency;
	
	private Date createdDate;
	
	private String masterRecordStatus="NEW";
	private String currentRecordStatus="";
	private String requestStatus="";
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getBranchId() {
		return branchId;
	}
	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getTwofactor() {
		return twofactor;
	}
	public void setTwofactor(String twofactor) {
		this.twofactor = twofactor;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getTimeZone() {
		return timeZone;
	}
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}
	public String getMailerLanguage() {
		return mailerLanguage;
	}
	public void setMailerLanguage(String mailerLanguage) {
		this.mailerLanguage = mailerLanguage;
	}
	public String getRateType() {
		return rateType;
	}
	public void setRateType(String rateType) {
		this.rateType = rateType;
	}
	public String getDiscountingSystem() {
		return discountingSystem;
	}
	public void setDiscountingSystem(String discountingSystem) {
		this.discountingSystem = discountingSystem;
	}
	public String getCreatedId() {
		return createdId;
	}
	public void setCreatedId(String createdId) {
		this.createdId = createdId;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getMasterRecordStatus() {
		return masterRecordStatus;
	}
	public void setMasterRecordStatus(String masterRecordStatus) {
		this.masterRecordStatus = masterRecordStatus;
	}
	public String getCurrentRecordStatus() {
		return currentRecordStatus;
	}
	public void setCurrentRecordStatus(String currentRecordStatus) {
		this.currentRecordStatus = currentRecordStatus;
	}
	public String getRequestStatus() {
		return requestStatus;
	}
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}
	
}
