/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   21 June 2017
 * 
 * Purpose:     Credit Note Inquiry Report Service Interface
 * 
 * Change History: 
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 21 June 2017       Ratna Gokhale, Oracle Financial Services Software Ltd     Initial Version
 * 
 *****************************************************************************************************************************************************************/
package com.bnp.bnpux.service;

import java.util.List;

import com.bnp.bnpux.vo.requestVO.CreditNoteInqRequestVO;
import com.bnp.bnpux.vo.requestVO.ReportsCreditNoteLineItemRequestVO;
import com.bnp.bnpux.vo.responseVO.CreditNoteInqResponseVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.bnpux.vo.responseVO.ReportsCreditNoteLineItemResponseVO;

public interface ICreditNoteInqReportService {

	/**
	 * This method is for getting Credit Note Inquiry Report details
	 * 
	 * @param CreditNoteInqRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	CreditNoteInqResponseVO getReportDetails(CreditNoteInqRequestVO CreditNoteInqRequestVO) throws BNPApplicationException;

	/**
	 * This method is for getting Credit Note Inquiry Report list
	 * 
	 * @param CreditNoteInqRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	CreditNoteInqResponseVO getReportList(CreditNoteInqRequestVO CreditNoteInqRequestVO)	throws BNPApplicationException;

	/**
	 * This method is for getting report chart axis 
	 * 
	 * @param requestVo
	 * @return
	 * @throws BNPApplicationException
	 */
	List<ReportChartResponseVO> getReportChartAxis (CreditNoteInqRequestVO requestVo)throws BNPApplicationException;

/**
	 * This method is for getting Credit Note Line Item details
	 * 
	 * @param paymentOrderCreditNoteLineItemRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	ReportsCreditNoteLineItemResponseVO getReportsCreditNoteLineItemDetails(ReportsCreditNoteLineItemRequestVO reportsCreditNoteLineItemRequestVO) throws BNPApplicationException;
	
}
