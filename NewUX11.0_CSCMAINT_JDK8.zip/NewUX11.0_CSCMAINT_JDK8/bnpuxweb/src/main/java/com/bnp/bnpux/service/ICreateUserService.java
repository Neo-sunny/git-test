/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas.
 * 
 * Created on:   25 APR 2016
 * 
 * Purpose:      Create User Service Interface
 * 
 * Change History: 
 * Date                                    Author                                                                               Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 25 APR 2016						    Bala Murugan Elangovan														 	 Recall Implementation 
 * *****************************************************************************************************************************************************************/


package com.bnp.bnpux.service;

import java.util.List;



import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

/**
 * The Interface ICreateUserService.
 */
public interface ICreateUserService 
{	
	/**
	 * Populate language list.
	 *
	 * @return NameValueVO list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> populateLanguageList() throws BNPApplicationException;

	
	/**
	 * Populate country list.
	 *
	 * @return NameValueVO list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<NameValueVO> populateCountryList() throws BNPApplicationException;
	
}
