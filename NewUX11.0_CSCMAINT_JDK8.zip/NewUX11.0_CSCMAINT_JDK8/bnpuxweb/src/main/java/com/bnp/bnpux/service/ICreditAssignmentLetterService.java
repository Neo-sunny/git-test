/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     CreditAssignmentLetter Service Interface
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 
 *****************************************************************************************************************************************************************/
package com.bnp.bnpux.service;

import java.util.List;

import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.discounting.vo.CreditAssignmentVO;

public interface ICreditAssignmentLetterService {
	
	/**
	 * This method for getting Credit Assignment Letters
	 * 
	 * @param pymtId
	 * @return
	 * @throws BNPApplicationException
	 */
	public List<CreditAssignmentVO> getCreditAssgntLetters(long pymtId) throws BNPApplicationException;

}
