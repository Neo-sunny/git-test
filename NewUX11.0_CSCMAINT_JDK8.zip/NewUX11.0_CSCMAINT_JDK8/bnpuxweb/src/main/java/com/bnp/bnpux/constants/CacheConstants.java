/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Cache Constants
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.constants;


public interface CacheConstants {	
		
	    /** * User Preference Date Formats */
		String DD_MM_YYYY="DD/MM/YYYY";
		String DEFAULT_DATE_FORMAT="dd/MM/yyyy";
		String DEFAULT_DATE_FORMAT_WITH_24TIME="dd/MM/yyyy HH:mm:ss";
		String MM_DD_YY="MM/DD/YYYY";
		String YY_MM_DD="YYYY/MM/DD";
		String DD_MM_YY_DOT="DD.MM.YY";
		String MM_DD_YY_DOT="MM.DD.YY";
		String YY_MM_DD_DOT="YY.MM.DD";
		String DD_MON_YYYY="DD-MON-YYYY";
		String DD_MON_YY="DD-MON-YY";
		String DD_MM_YYY1="DD-MM-YYYY";
		String MM_DD_YYYY2="MM-DD-YYYY";
		String YYYY_MM_DD3="YYYY-MM-DD";
		String YYYYMMDD1="YYYYMMDD";
		String MMDDYYYY="MMDDYYYY";
		String DDMMYYYY="DDMMYYYY";
		String AMT_US_FMT="US FORMAT";
		String AMT_ITLY_FMT="ITALY FORMAT";
		
		/** * User Preference Amount Format */
        String AMT_NEW_FMT_1 = "ROOT_1";
        String AMT_NEW_FMT_2 = "ROOT_2";        
		String US_LOCALE="US";
		String ITALY_LOCALE="ITALY";
		String US_LOCALE_FRMT="USLOCFORMAT";
		String ITALY_LOCALE_FRMT="ITALYLOCFORMAT";
		String ROOT_1_LOCALE_FRMT="ROOT1_LOCFORMAT";
		String ROOT_2_LOCALE_FRMT="ROOT2_LOCFORMAT";

}