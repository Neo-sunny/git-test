/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Settlement List Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;
import java.util.Date;

public class SettlementListVO {
	
	
	private String paymntRefNo;
	
	private String paymntRefNoUnique;
	private String paymntInvStatus;
	private String currencyCode;
	private Date dueDate;
	
	private String extnRolvrFlag;
	
	private int remainingDays;
	
	private String leadingOrgId;
	
	private BigDecimal intrestAmount;
	
	private BigDecimal dueAmount;
	
	private BigDecimal orgAmount;
	
	private BigDecimal inProcessAmount;
	
	private BigDecimal alreadyPaidAmount;
	
	private String recordCount;
	
	private String recordNumber;
	
	private int decimalPoint;
	
	private int roundingMode;
    private BigDecimal totOrgAmt;
	
	private BigDecimal cnUtilizedAmt; 
	
	private BigDecimal grp_one_cr_amt;
	
	private String extnRolvrDtList;

private boolean attachmentIconInd;

	private boolean creditAssignIconInd;
	
	private String buyerOrgName;
	
	private String supplierOrgName;
    
	private String pymtId;
	
	// Added for PopUp in settlement screen functionality
	private String buyerOrgId;
	private String sellerOrgId;
	private String maturity_pymt_disabled;
	private BigDecimal tot_disc_amt;
	
	public String getMaturity_pymt_disabled() {
		return maturity_pymt_disabled;
	}

	public void setMaturity_pymt_disabled(String maturity_pymt_disabled) {
		this.maturity_pymt_disabled = maturity_pymt_disabled;
	}

	public BigDecimal getTot_disc_amt() {
		return tot_disc_amt;
	}

	public void setTot_disc_amt(BigDecimal tot_disc_amt) {
		this.tot_disc_amt = tot_disc_amt;
	}

	public String getBuyerOrgId() {
		return buyerOrgId;
	}

	public void setBuyerOrgId(String buyerOrgId) {
		this.buyerOrgId = buyerOrgId;
	}

	public String getSellerOrgId() {
		return sellerOrgId;
	}

	public void setSellerOrgId(String sellerOrgId) {
		this.sellerOrgId = sellerOrgId;
	}

	private String expandFlag;
	
	private String settlementStatusDisplay;
	
	private String settlementStatusStyle;

	public String getExpandFlag() {
		return expandFlag;
	}

	public void setExpandFlag(String expandFlag) {
		this.expandFlag = expandFlag;
	}
	
	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public BigDecimal getTotOrgAmt() {
		return totOrgAmt;
	}

	public void setTotOrgAmt(BigDecimal totOrgAmt) {
		this.totOrgAmt = totOrgAmt;
	}

	public BigDecimal getCnUtilizedAmt() {
		return cnUtilizedAmt;
	}

	public void setCnUtilizedAmt(BigDecimal cnUtilizedAmt) {
		this.cnUtilizedAmt = cnUtilizedAmt;
	}

	public int getDecimalPoint() {
		return decimalPoint;
	}

	public void setDecimalPoint(int decimalPoint) {
		this.decimalPoint = decimalPoint;
	}



	public int getRemainingDays() {
		return remainingDays;
	}

	public void setRemainingDays(int remainingDays) {
		this.remainingDays = remainingDays;
	}

	

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}


	public BigDecimal getAlreadyPaidAmount() {
		return alreadyPaidAmount;
	}

	public void setAlreadyPaidAmount(BigDecimal alreadyPaidAmount) {
		this.alreadyPaidAmount = alreadyPaidAmount;
	}

	

	public String getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(String recordCount) {
		this.recordCount = recordCount;
	}

	public String getRecordNumber() {
		return recordNumber;
	}

	public void setRecordNumber(String recordNumber) {
		this.recordNumber = recordNumber;
	}

	public String getPaymntRefNo() {
		return paymntRefNo;
	}

	public void setPaymntRefNo(String paymntRefNo) {
		this.paymntRefNo = paymntRefNo;
	}

	public String getPaymntRefNoUnique() {
		return paymntRefNoUnique;
	}

	public void setPaymntRefNoUnique(String paymntRefNoUnique) {
		this.paymntRefNoUnique = paymntRefNoUnique;
	}

	public String getExtnRolvrFlag() {
		return extnRolvrFlag;
	}

	public void setExtnRolvrFlag(String extnRolvrFlag) {
		this.extnRolvrFlag = extnRolvrFlag;
	}

	public BigDecimal getIntrestAmount() {
		return intrestAmount;
	}

	public void setIntrestAmount(BigDecimal intrestAmount) {
		this.intrestAmount = intrestAmount;
	}

	public BigDecimal getDueAmount() {
		return dueAmount;
	}

	public void setDueAmount(BigDecimal dueAmount) {
		this.dueAmount = dueAmount;
	}

	public BigDecimal getOrgAmount() {
		return orgAmount;
	}

	public void setOrgAmount(BigDecimal orgAmount) {
		this.orgAmount = orgAmount;
	}

	public BigDecimal getInProcessAmount() {
		return inProcessAmount;
	}

	public void setInProcessAmount(BigDecimal inProcessAmount) {
		this.inProcessAmount = inProcessAmount;
	}

	public int getRoundingMode() {
		return roundingMode;
	}

	public void setRoundingMode(int roundingMode) {
		this.roundingMode = roundingMode;
	}

	public String getPaymntInvStatus() {
		return paymntInvStatus;
	}

	public void setPaymntInvStatus(String paymntInvStatus) {
		this.paymntInvStatus = paymntInvStatus;
	}

	public boolean isAttachmentIconInd() {
		return attachmentIconInd;
	}

	public void setAttachmentIconInd(boolean attachmentIconInd) {
		this.attachmentIconInd = attachmentIconInd;
	}

	public boolean isCreditAssignIconInd() {
		return creditAssignIconInd;
	}

	public void setCreditAssignIconInd(boolean creditAssignIconInd) {
		this.creditAssignIconInd = creditAssignIconInd;
	}

	public String getBuyerOrgName() {
		return buyerOrgName;
	}

	public void setBuyerOrgName(String buyerOrgName) {
		this.buyerOrgName = buyerOrgName;
	}

	public String getSupplierOrgName() {
		return supplierOrgName;
	}

	public void setSupplierOrgName(String supplierOrgName) {
		this.supplierOrgName = supplierOrgName;
	}

	public String getPymtId() {
		return pymtId;
	}

	public void setPymtId(String pymtId) {
		this.pymtId = pymtId;
	}

	public String getLeadingOrgId() {
		return leadingOrgId;
	}

	public void setLeadingOrgId(String leadingOrgId) {
		this.leadingOrgId = leadingOrgId;
	}

	public void setExtnRolvrDtList(String extnRolvrDtList) {
		this.extnRolvrDtList = extnRolvrDtList;
	}

	public String getExtnRolvrDtList() {
		return extnRolvrDtList;
	}

	public BigDecimal getGrp_one_cr_amt() {
		return grp_one_cr_amt;
	}

	public void setGrp_one_cr_amt(BigDecimal grp_one_cr_amt) {
		this.grp_one_cr_amt = grp_one_cr_amt;
	}

	/**
	 * @return the settlementStatusDisplay
	 */
	public String getSettlementStatusDisplay() {
		return settlementStatusDisplay;
	}

	/**
	 * @param settlementStatusDisplay the settlementStatusDisplay to set
	 */
	public void setSettlementStatusDisplay(String settlementStatusDisplay) {
		this.settlementStatusDisplay = settlementStatusDisplay;
	}

	/**
	 * @return the settlementStatusStyle
	 */
	public String getSettlementStatusStyle() {
		return settlementStatusStyle;
	}

	/**
	 * @param settlementStatusStyle the settlementStatusStyle to set
	 */
	public void setSettlementStatusStyle(String settlementStatusStyle) {
		this.settlementStatusStyle = settlementStatusStyle;
	}
	
	
	/**
	 * Getter methods introduced to send the amounts as
	 * String to avoid amount > 16 digits getting truncated
	 * Added as part of defect Fix CSC-7835
	 */
	
	public String getIntrestAmountStr()
	{
		return (intrestAmount != null)?intrestAmount.toPlainString():"";
	}
	
	public String getDueAmountStr()
	{
		return (dueAmount != null)?dueAmount.toPlainString():"";
	}
	
	public String getOrgAmountStr()
	{
		return (orgAmount != null)?orgAmount.toPlainString():"";
	}
	
	public String getInProcessAmountStr()
	{
		return (inProcessAmount != null)?inProcessAmount.toPlainString():"";
	}
	
	public String getAlreadyPaidAmountStr()
	{
		return (alreadyPaidAmount != null)?alreadyPaidAmount.toPlainString():"";
	}
	
	public String getTotOrgAmtStr()
	{
		return (totOrgAmt != null)?totOrgAmt.toPlainString():"";
	}
	
	public String getCnUtilizedAmtStr()
	{
		return (cnUtilizedAmt != null)?cnUtilizedAmt.toPlainString():"";
	}
	
	public String getGrp_one_cr_amtStr()
	{
		return (grp_one_cr_amt != null)?grp_one_cr_amt.toPlainString():"";
	}
	
	public String getTot_disc_amtStr()
	{
		return (tot_disc_amt != null)?tot_disc_amt.toPlainString():"";
	}
	
}
