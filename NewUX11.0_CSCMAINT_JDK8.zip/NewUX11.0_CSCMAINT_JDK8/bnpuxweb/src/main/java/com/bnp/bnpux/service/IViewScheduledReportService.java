package com.bnp.bnpux.service;

import java.util.List;

import com.bnp.bnpux.common.vo.ViewScheduledReportListVO;
import com.bnp.bnpux.vo.requestVO.ViewScheduledReportRequestVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface IViewScheduledReportService {

	/**
	 * This method fetches view scheduled reports records
	 * @param viewScheduleRptRequestVO
	 * @return ViewScheduledReportResponseVO
	 * @throws BNPApplicationException
	 */
	List<ViewScheduledReportListVO> getViewScheduleRptDetails(ViewScheduledReportRequestVO viewScheduleRptRequestVO) throws BNPApplicationException;
	/**
	 * update Last Viewed column
	 * @param viewScheduleRptRequestVO
	 * @throws BNPApplicationException
	 */
	void updateLastViewed(ViewScheduledReportRequestVO viewScheduleRptRequestVO) throws BNPApplicationException ;
	
	
}