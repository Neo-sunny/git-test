/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Holiday Interface for Data Access Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 08 Mar 2017                skbhaska                                    		FO 10.0 - S30 - Holiday Calendar
************************************************************************************************************************************************************/
package com.bnp.bnpux.dao;

import java.util.List;

import com.bnp.bnpux.common.vo.HolidayVO;
import com.bnp.bnpux.vo.requestVO.HolidayRequestVO;
import com.bnp.bnpux.vo.responseVO.HolidayResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface IHolidayDAO {
	
	/**
	 * This method is for getting Holiday list
	 * 
	 * @param holidayRequestVO
	 * @return
	 */
	public List<HolidayVO> getHolidayList(HolidayRequestVO holidayRequestVO);
	
	
	/**
	 * This method is used to get the list of holiday based on CYY List, Year, Org ID, Branch (For BA Users) 
	 * @param holidayRequestVO
	 * @return HolidayResponseVO
	 * @throws BNPApplicationException
	 */
	public List<HolidayVO> getHolidayListForCalendar(HolidayRequestVO holidayRequestVO);

}
