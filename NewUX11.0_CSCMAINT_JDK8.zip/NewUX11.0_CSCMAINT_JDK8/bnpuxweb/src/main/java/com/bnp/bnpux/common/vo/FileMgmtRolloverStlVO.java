package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;
import java.util.Date;


public class FileMgmtRolloverStlVO {
	private String invRefNo;
	private String sellerOrgId;
	private String buyerOrgId;
	private String settlCcy;
	private Date invIssueDate;
	private Date rollDueDate;
	private BigDecimal settlAmt;
	private int decimalPt;
	private BigDecimal rolloverAmt;
	private String rolloverCcy;
	private String recordStatus;
	private String recordCnt;
	
	public String getRecordCnt() {
		return recordCnt;
	}
	public void setRecordCnt(String recordCnt) {
		this.recordCnt = recordCnt;
	}
	public String getRecordStatus() {
		return recordStatus;
	}
	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}
	public String getInvRefNo() {
		return invRefNo;
	}
	public void setInvRefNo(String invRefNo) {
		this.invRefNo = invRefNo;
	}
	public String getSellerOrgId() {
		return sellerOrgId;
	}
	public void setSellerOrgId(String sellerOrgId) {
		this.sellerOrgId = sellerOrgId;
	}
	public String getBuyerOrgId() {
		return buyerOrgId;
	}
	public void setBuyerOrgId(String buyerOrgId) {
		this.buyerOrgId = buyerOrgId;
	}
	public String getSettlCcy() {
		return settlCcy;
	}
	public void setSettlCcy(String settlCcy) {
		this.settlCcy = settlCcy;
	}
	public Date getInvIssueDate() {
		return invIssueDate;
	}
	public void setInvIssueDate(Date invIssueDate) {
		this.invIssueDate = invIssueDate;
	}
	public Date getRollDueDate() {
		return rollDueDate;
	}
	public void setRollDueDate(Date rollDueDate) {
		this.rollDueDate = rollDueDate;
	}
	public BigDecimal getSettlAmt() {
		return settlAmt;
	}
	public void setSettlAmt(BigDecimal settlAmt) {
		this.settlAmt = settlAmt;
	}
	public int getDecimalPt() {
		return decimalPt;
	}
	public void setDecimalPt(int decimalPt) {
		this.decimalPt = decimalPt;
	}
	public BigDecimal getRolloverAmt() {
		return rolloverAmt;
	}
	public void setRolloverAmt(BigDecimal rolloverAmt) {
		this.rolloverAmt = rolloverAmt;
	}
	public String getRolloverCcy() {
		return rolloverCcy;
	}
	public void setRolloverCcy(String rolloverCcy) {
		this.rolloverCcy = rolloverCcy;
	}
	
	/**
	 * Getter methods introduced to send the amounts as
	 * String to avoid amount > 16 digits getting truncated
	 * Added as part of defect Fix CSC-7835
	 */
	
	public String getRolloverAmtStr() {
		return (rolloverAmt!=null)?rolloverAmt.toPlainString():"";
	}
	
	public String getSettlAmtStr() {
		return (settlAmt!=null)?settlAmt.toPlainString():"";
	}
	
}
