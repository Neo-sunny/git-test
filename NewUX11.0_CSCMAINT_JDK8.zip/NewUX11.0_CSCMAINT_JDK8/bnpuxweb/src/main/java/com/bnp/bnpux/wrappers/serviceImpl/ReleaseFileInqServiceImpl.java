/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 March 2017
 * 
 * Purpose:      Release File Functionality
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 March 2017         Oracle Financial Services Software Ltd                  Initial Version 
* 27 March 2017			Oracle Financial Services Software Ltd					Release 1.1 I2			Copied from Old UX	
* 27 March 2017			Oracle Financial Services Software Ltd					Release 1.1 I2			Updated deleteFile functionality for New UX
* 3  April 2017			Oracle Financial Services Software Ltd					Release 1.1 I2			Updated deleteFile functionality for New UX - addressed code review comment
**********************************************************************************************************************/
package com.bnp.bnpux.wrappers.serviceImpl;



import java.math.BigDecimal;
import java.net.NoRouteToHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.common.vo.ReleaseFileMgmtResponseVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.common.vo.UserVO;
import com.bnp.bnpux.util.CommonUtil;
import com.bnp.bnpux.vo.responseVO.FileMgmtResponseVO;
import com.bnp.bnpux.wrappers.service.IReleaseFileInqService;
import com.bnp.eipp.services.dispute.IDisputeMgmtService;
import com.bnp.eipp.services.invoice.IEippInvoiceService;
import com.bnp.eipp.services.invoice.IEippReleaseService;
import com.bnp.scm.common.IResourceManager;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.BNPReloadableResourceBundleMessageSource;
import com.bnp.scm.services.common.IAccessLogService;
import com.bnp.scm.services.common.cache.ICacheService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.CacheConstants;
import com.bnp.scm.services.common.util.ScreenConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.common.vo.AbstractVO;
import com.bnp.scm.services.common.vo.MrktgEmailVO;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.bnp.scm.services.discounting.IDiscountProcessService;
import com.bnp.scm.services.discounting.vo.DiscountRequestVO;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.filemgmt.vo.FileReleaseAuthProfileVO;
import com.bnp.scm.services.invoice.IInvoiceService;
import com.bnp.scm.services.invoice.IInvoiceUploadService;
import com.bnp.scm.services.invoice.IReleaseFileService;
import com.bnp.scm.services.limitmgmt.IForexRateService;
import com.bnp.scm.services.marketing.IMarketingMailService;
import com.bnp.scm.services.mrktng.IPreAprvdSuppplierReleaseService;
import com.bnp.scm.services.mrktng.vo.SupplierVO;


@Component
public class ReleaseFileInqServiceImpl  implements IReleaseFileInqService {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	private static final String RELEASE= "RELEASE";
	
	private static final String AUTHORIZE = "AUTHORIZE";
	
	private static final String REJECT = "REJECT";
	
	private static final String DELETE = "DELETE";
	

	private static final Logger logger =LoggerFactory.getLogger(ReleaseFileInqServiceImpl.class);
	
	@Autowired
	private IForexRateService forexRateService;
	
	/** The mrktg mail service. */
	@Autowired
	private IMarketingMailService mrktgMailService;

	@Autowired
	protected IResourceManager resourceManager;
	
	@Autowired
	protected BNPPropertyLoaderConfigurer propertyLoader;
	
	
	@Autowired
	protected BNPReloadableResourceBundleMessageSource resourceBundle;
	
		
	@Autowired
	private IReleaseFileService releaseFileServiceImpl;
	
	@Autowired
	private IInvoiceService invoiceService;
	
	@Autowired
	private IEippInvoiceService eippInvoiceService;
	
	@Autowired
	private  IInvoiceUploadService invoiceUploadService;
	
	@Autowired
	private IEippReleaseService eippReleaseService;
	
	@Autowired
	private IDisputeMgmtService disputeMgmtService;
	
	@Autowired 
	private CommonUtil commonUtil;
	
	@Autowired
	private ICacheService cacheService;

	@Autowired
	private IAccessLogService accessLogService;

	@Autowired
	private IDiscountProcessService discPymtService;
	
	@Autowired
	private IPreAprvdSuppplierReleaseService preAprvdSupplierReleaseService;
	

	
  public ReleaseFileMgmtResponseVO releaseFile(List<FileDetailsVO> fileDetailsVOList, UserInfoVO user)
	{ 
	  logger.debug("enter : releaseFile process = {}",System.currentTimeMillis()); 
	  ReleaseFileMgmtResponseVO releaseFileMgmtResponseVO = new ReleaseFileMgmtResponseVO();
		String fileInfo=null;
		List<String> errorList = null;

		boolean conCurrentAccess;
		boolean lockedFlag=false;
				
				for(FileDetailsVO fileDetailsVO : fileDetailsVOList){
					
				String uploadedBy = fileDetailsVO.getUserId();
				String uploadedUserType = fileDetailsVO.getUserType();
				String fileStatus = fileDetailsVO.getFileUploadStatus();
				if(validateRecordStatus(fileStatus ,fileDetailsVO.getFileName() , releaseFileMgmtResponseVO) && checkMaker(user.getUserId(), uploadedBy ,fileDetailsVO.getFileName() , RELEASE, releaseFileMgmtResponseVO)
						&& checkTPpartConfRelease(fileDetailsVO.getInstrumentType(),user.getUserTypeId(),uploadedUserType,fileDetailsVO.getFileName() , releaseFileMgmtResponseVO))
				{
					try {
						setAccessLogDetails(ScreenConstants.ACCESS_LOG_FILE_RELEASE , fileDetailsVO.getFileName(), user.getUserId(), user.getSessionId());
						fileDetailsVO.setReleasedBy(user.getUserId());						
						conCurrentAccess=releaseFileServiceImpl.checkConcurrentAccess(fileDetailsVO);
						if(conCurrentAccess){							
							commonUtil.addReleaseFileMgmtResponseVO(fileDetailsVO.getFileName() , resourceManager.getMessage(ErrorConstants.CONCURRENT_ACCESS) , true,releaseFileMgmtResponseVO);
							continue;
						}
						int errorCode=releaseFileServiceImpl.checkAndLockRecordForProcessing(fileDetailsVO.getFileId(),BNPConstants.MANUAL_RELEASE);
						if(errorCode>0)
						{
							fileInfo = resourceManager.getMessage(errorCode);
							commonUtil.addReleaseFileMgmtResponseVO(fileDetailsVO.getFileName() , fileInfo , true ,releaseFileMgmtResponseVO);
							continue;							
						}
						lockedFlag=true;
						
						if(BNPConstants.MRKTG_INSTRUMENT_TYPE.equals(fileDetailsVO.getInstrumentType())){
							preAprvdSupplierReleaseService.releaseFile(fileDetailsVO);
						
							sendEmailToBank(fileDetailsVO);
						
						}else {
							errorList = releaseFileServiceImpl.releaseFile(fileDetailsVO,user.getUserId(), false);
							Map<String,String> resultMap = cacheService.getAutoDiscParam();
							String autoDiscThrSch = (String)resultMap.get("RUN_AS_JOB");

							if(BNPConstants.YES.equals(autoDiscThrSch)){
								List<DiscountRequestVO> discReqLst = discPymtService.getOADRecords(fileDetailsVO.getSenderOrgId(), String.valueOf(fileDetailsVO.getFileId()));
								if(discReqLst != null && !discReqLst.isEmpty()){
									invoiceUploadService.scheduleAutoDiscounting(fileDetailsVO);
								}
							}else{
							discPymtService.raiseDiscount(fileDetailsVO);
							}
							
						}
						if(errorList != null && 	errorList.size() > 0) {
							fileDetailsVO.setErrorDesc(getErrorData(errorList));
							invoiceUploadService.updateFileStatus(fileDetailsVO);
							fileInfo = resourceManager.getMessage(ErrorConstants.FILE_RELEASE_FAILURE);
							commonUtil.addReleaseFileMgmtResponseVO(fileDetailsVO.getFileName() , fileInfo , true,releaseFileMgmtResponseVO);
						}else {
							fileInfo = resourceManager.getMessage(ErrorConstants.FILE_RELEASE_SUCCESS);
							commonUtil.addReleaseFileMgmtResponseVO(fileDetailsVO.getFileName() , fileInfo , false,releaseFileMgmtResponseVO);
							logger.debug("*****GOing to call checkForOfferLetterTrigger******** ");
						
							invoiceUploadService.checkForOfferLetterTrigger(fileDetailsVO);
						}
						
					} catch(BNPApplicationException e) {
						fileDetailsVO.setReleasedBy(null);
						
						logger.error("Release file Failed"+e.getErrorCode());
						fileInfo = resourceManager.getMessage(e.getErrorCode());
						commonUtil.addReleaseFileMgmtResponseVO(fileDetailsVO.getFileName() , fileInfo , true,releaseFileMgmtResponseVO);
						try {
							fileDetailsVO.setErrorCode(Integer.toString(e.getErrorCode()));
							invoiceUploadService.updateFileStatus(fileDetailsVO);
						}catch (BNPApplicationException e1) {
							logger.error("Update File status error"+e1.getErrorCode());
						}
					

					}
					
					
					finally{
						
						try{
							if(lockedFlag)
							{
							releaseFileServiceImpl.updateStatusForLocking(String.valueOf(fileDetailsVO.getFileId()),BNPConstants.NO,BNPConstants.MANUAL_RELEASE);		
							}
						}
						catch(BNPApplicationException e)
						{
							logger.error("Error in releaseFile ()-unlocking of record failed"+e.getErrorCode());
						}
						
					}
					
					}
				}
		return releaseFileMgmtResponseVO;
	}


public void sendEmailToBank(FileDetailsVO selectedData)
{
	MrktgEmailVO mrktgEmailVO = new MrktgEmailVO();	
	mrktgEmailVO.setSubject(resourceBundle.getMessage("mrktg.email.sub.pending.accept", null, null));
	mrktgEmailVO.setBankApprove(false);
	mrktgEmailVO.setChooseTemplt(propertyLoader.getValue("scheduler.template.mrktg.mrktgAcctPreAprdSupplrUpload"));
	try
	{
	mrktgEmailVO.setToList(releaseFileServiceImpl.getBankAdmEmailIds(selectedData));
	setAndSendEmail(selectedData,mrktgEmailVO);
	}
	catch(BNPApplicationException e)
	{
		logger.error("BNPApplicationException in gettingToList",e);
	}
	//mrktgEmailVO.setSupplrOrgId(newSupplrMgmtVO.getSupplierOrgId());
	
}

/**
 * Sets the email details.
 * @param mrktgEmailVO 
 *
 * @param emailDetailsVO the new email details
 * @throws BNPApplicationException the bNP application exception
 */


private void setAndSendEmail(FileDetailsVO selectedData, MrktgEmailVO mrktgEmailVO){
	Map<String, byte[]> attachFileMap =null;
	
	List<SupplierVO> releasingSupplierList = null;
	

	try {
		
		releasingSupplierList = preAprvdSupplierReleaseService.getSupplierDetails(selectedData);
		
		attachFileMap = new HashMap<String, byte[]>();
		mrktgEmailVO.setBuyerShortName(releaseFileServiceImpl.getBuyerDetail(selectedData));
		
		
		
		
		List<String> preAprvdSupplierAttachDet = new ArrayList<String>();
		preAprvdSupplierAttachDet.add(resourceBundle.getMessage("message.preaprvdsupplier.attach.supplier.org", null, null) + "," + 
				resourceBundle.getMessage("message.preaprvdsupplier.attach.supplier.addr1", null, null) + "," + 
				resourceBundle.getMessage("message.preaprvdsupplier.attach.supplier.addr2", null, null) + "," + 
				resourceBundle.getMessage("message.preaprvdsupplier.attach.supplier.addr3", null, null) + "," + 
				resourceBundle.getMessage("message.preaprvdsupplier.attach.supplier.city", null, null) + "," + 
				resourceBundle.getMessage("message.preaprvdsupplier.attach.supplier.country", null, null) + "," + 
				resourceBundle.getMessage("message.preaprvdsupplier.attach.supplier.postalcode", null, null) + "," + 
				resourceBundle.getMessage("message.preaprvdsupplier.attach.supplier.telephone", null, null) + "," + 
				resourceBundle.getMessage("message.preaprvdsupplier.attach.supplier.email", null, null) + "," + 
				resourceBundle.getMessage("message.preaprvdsupplier.attach.supplier.erpid1", null, null) + "," + 
				resourceBundle.getMessage("message.preaprvdsupplier.attach.supplier.erpid2", null, null) + "," + 
				resourceBundle.getMessage("message.preaprvdsupplier.attach.supplier.erpid3", null, null) + "," + 
				resourceBundle.getMessage("message.preaprvdsupplier.attach.supplier.templateId", null, null));
		for(SupplierVO suppDet : releasingSupplierList) {
			preAprvdSupplierAttachDet.add(suppDet.getName() + "," + 
					suppDet.getAddressLineOne() + "," + 
					((suppDet.getAddressLineTwo() == null)? "" : suppDet.getAddressLineTwo()) + "," +
					((suppDet.getAddressLineThree() == null)? "" : suppDet.getAddressLineThree()) + "," +
					suppDet.getCity() + "," + 
					suppDet.getCountry() + "," + 					 
					suppDet.getPostalCode() + "," + 
					suppDet.getTelephone() + "," + 
					suppDet.getEmail() + "," + 
					suppDet.getErpId1() + "," + 
					((suppDet.getErpId2() == null)? "" : suppDet.getErpId2()) + "," +
					((suppDet.getErpId3() == null)? "" : suppDet.getErpId3()) + "," +
					suppDet.getTemplateId());

		}
		attachFileMap.put("PreApprovedSuppliers"  + ".csv", convertToString(preAprvdSupplierAttachDet).getBytes());
		mrktgEmailVO.setPreApprovedSupplierDetailsAttach(attachFileMap);
		mrktgMailService.sendMail(mrktgEmailVO);
	}catch (BNPApplicationException e){
		logger.error("BNPApplicationException in setAndSendEmail",e);
	}catch (Exception e){
		logger.error("Exception in setAndSendEmail",e);
	}
}

/**
 * Convert list to string
 * @param records
 * @return
 */
private static String convertToString(List<String> records){          
	StringBuilder dataToFile = new StringBuilder();
	if(records != null) {
		for (String record: records) {          
			dataToFile.append(record);
			dataToFile.append("\n");
		}
		return dataToFile.toString();
	}
	return null;
}



private String getErrorData(List<String> erroList) {
	StringBuffer errorDesc = new StringBuffer();
	for(String error : erroList){
		errorDesc.append(error);
		errorDesc.append("  ");
	}
	return errorDesc.toString();
}



   /* (non-Javadoc)
 * @see com.bnp.bnpux.filemgmt.service.IReleaseFileInqService#deleteFile(java.util.List, java.lang.String)
 */
public ReleaseFileMgmtResponseVO deleteFile(List<FileDetailsVO> fileDetailsVOList, UserInfoVO user)
	{
	   
	   ReleaseFileMgmtResponseVO releaseFileMgmtResponseVO = new ReleaseFileMgmtResponseVO();
	   String fileInfo = null;
			if (fileDetailsVOList != null && fileDetailsVOList.size() >= 1) {
				for(FileDetailsVO  fileDetailsVO : fileDetailsVOList){				
				String uploadedBy = fileDetailsVO.getUserId();
				String fileStatus = fileDetailsVO.getFileUploadStatus();

				if (validateRecordStatusForDelete(fileStatus ,fileDetailsVO.getFileName() , releaseFileMgmtResponseVO)
						&& checkMaker(user.getUserId(), uploadedBy ,fileDetailsVO.getFileName() , DELETE, releaseFileMgmtResponseVO)) {
					try {
						setAccessLogDetails(ScreenConstants.ACCESS_LOG_FILE_UNDO, fileDetailsVO.getFileName() , user.getUserId() ,user.getSessionId());
						fileDetailsVO.setCurrentUserId(user.getUserId());
						if(BNPConstants.MRKTG_INSTRUMENT_TYPE.equals(fileDetailsVO.getInstrumentType())){
							preAprvdSupplierReleaseService.deleteFile(fileDetailsVO);
						}else
						{
							
							releaseFileServiceImpl.deleteFile(fileDetailsVO,
									user.getUserId());
						}
						fileInfo = resourceManager
								.getMessage(ErrorConstants.DELETE_FILE_SUCCESS);
						
						
						commonUtil.addReleaseFileMgmtResponseVO(fileDetailsVO.getFileName() , fileInfo , false,releaseFileMgmtResponseVO);
					} catch (BNPApplicationException e) {
						fileInfo = resourceManager
								.getMessage(ErrorConstants.DELETE_FILE_FAILURE);
						commonUtil.addReleaseFileMgmtResponseVO(fileDetailsVO.getFileName() , fileInfo , true,releaseFileMgmtResponseVO);
						
					}
				}
				
			}
										
		} 
			
				
				return releaseFileMgmtResponseVO;

	}
    



   private boolean validateRecordStatusForDelete(String fileStatus, String fileName, ReleaseFileMgmtResponseVO releaseFileMgmtResponseVO) {
		if(fileStatus.equalsIgnoreCase(StatusConstants.PENDING_FOR_APPROVAL)||(fileStatus.equalsIgnoreCase(StatusConstants.PENDING_AUTHORIZATION))){
			return true;
		}
		else{
			String fileInfo=resourceManager.getMessage(ErrorConstants.CANNOT_UNDO);
			commonUtil.addReleaseFileMgmtResponseVO(fileName, fileInfo, true, releaseFileMgmtResponseVO);
			return false;
		}
 }

	private boolean validateRecordStatus(String fileStatus, String fileName, ReleaseFileMgmtResponseVO releaseFileMgmtResponseVO) {
		if(fileStatus.equalsIgnoreCase(StatusConstants.PENDING_FOR_APPROVAL)){
			return true;
		}
		else{
			String fileInfo=resourceManager.getMessage(ErrorConstants.CANNOT_RELEASE_RECORD);
			commonUtil.addReleaseFileMgmtResponseVO(fileName, fileInfo, true, releaseFileMgmtResponseVO);
			return false;
		}
  }
	
	private boolean validateAuthRecordStatus(String fileStatus, String fileName, ReleaseFileMgmtResponseVO releaseFileMgmtResponseVO)
	{
		if(fileStatus.equalsIgnoreCase(StatusConstants.PENDING_AUTHORIZATION) || fileStatus.equalsIgnoreCase(StatusConstants.PARTIALLY_AUTHORIZED)){
			return true;
		}
		else{
			String fileInfo = resourceManager.getMessage(ErrorConstants.CANNOT_AUTHORIZE_RECORD);
			commonUtil.addReleaseFileMgmtResponseVO(fileName, fileInfo, true, releaseFileMgmtResponseVO);
			return false;
		}
	}
	
	private boolean validateRejectRecordStatus(String fileStatus, String fileName, ReleaseFileMgmtResponseVO releaseFileMgmtResponseVO)
	{
		if(fileStatus.equalsIgnoreCase(StatusConstants.PARTIALLY_AUTHORIZED)){
			return true;
		}
		else{
			String fileInfo = resourceManager.getMessage(ErrorConstants.REJECT_REC_STATUS_INVALID);
			commonUtil.addReleaseFileMgmtResponseVO(fileName, fileInfo, true, releaseFileMgmtResponseVO);
			return false;
		}
	}
	

	/**
	 * TP Bank user can not release the 'TP Participation confirmation' file uploaded by Bank Admin
	 * @param fileInsType
	 * @param loginUserType
	 * @param uploadedUserType
	 * @param releaseFileMgmtResponseVO 
	 * @param string 
	 * @return
	 */
	private boolean checkTPpartConfRelease(String fileInsType,String loginUserType,String uploadedUserType, String fileName, ReleaseFileMgmtResponseVO releaseFileMgmtResponseVO){
		if(CacheConstants.TP_DISC_CONF_INS_TYPE.equals(fileInsType) && 
				BNPConstants.BANKADMIN.equals(uploadedUserType) && !BNPConstants.BANKADMIN.equals(loginUserType)){
			String fileInfo = resourceManager.getMessage(ErrorConstants.MAKER_CHECK_DELETE);
			commonUtil.addReleaseFileMgmtResponseVO(fileName, fileInfo, true, releaseFileMgmtResponseVO);
			
			return false;
		}
		return true;
	}
	
	private void setAccessLogDetails(String actionName , String fileName, String userId, String sessionId) throws BNPApplicationException
	{
		AbstractVO abstractVO=new AbstractVO();
		abstractVO.setCurrentUserId(userId);
		abstractVO.setSessionId(sessionId);
		abstractVO.setCheckPoint(actionName);
		abstractVO.setAccessLogRefNo(fileName);
		abstractVO.setScreenId(ScreenConstants.RELEASEFILEINQ);
		accessLogService.insertAccessLog(abstractVO);
	}
	
	/**
	 * @param fileDetailsVOList
	 * @param user
	 * @return
	 */
	public ReleaseFileMgmtResponseVO authorizeFile(List<FileDetailsVO> fileDetailsVOList, UserInfoVO user) throws BNPApplicationException
	{
		int tempCount = 0;
		boolean conCurrentAccess;		
		boolean lockedFlag=false;
		String branchCode;
		String branchCcy;
		
		String fileStatus;
		String supBranchId;
		String uploadedBy;
		String fileName;
		
		String fileInfo;
		
		FileDetailsVO fileDetailsVO = null;
		FileReleaseAuthProfileVO tempAuthVO = new FileReleaseAuthProfileVO();
		NameValueVO authProfileDetails;
		ReleaseFileMgmtResponseVO releaseFileMgmtResponseVO = new ReleaseFileMgmtResponseVO();
		
		List<FileReleaseAuthProfileVO> fileAuthProfileList = null;
		List<String> authApprHighAmtList = null;
		List<String> errorList = new ArrayList<String>();
		
		
		
		try 
		{
			if(null != fileDetailsVOList && fileDetailsVOList.size() > 0)
			{
				for(int i=0;i<fileDetailsVOList.size();i++) 
				{
					tempCount = 0;
					fileDetailsVO = fileDetailsVOList.get(i);
					
					fileStatus = fileDetailsVO.getFileUploadStatus();
					supBranchId = fileDetailsVO.getBranchCode();
					uploadedBy = fileDetailsVO.getUserId();
					fileName = fileDetailsVO.getFileName();
					
					branchCode = releaseFileServiceImpl.getBranchCode(supBranchId);
					branchCcy = releaseFileServiceImpl.getBranchCcy(branchCode);
					
					if(validateAuthRecordStatus(fileStatus, fileName, releaseFileMgmtResponseVO) &&
							checkMaker(user.getUserId(), uploadedBy,fileDetailsVO.getFileName(), AUTHORIZE, releaseFileMgmtResponseVO))
					{
						setAccessLogDetails(ScreenConstants.ACCESS_LOG_FILE_PENDING_FOR_AUTHORIZATION, fileName, user.getUserId(), user.getSessionId());
						conCurrentAccess=releaseFileServiceImpl.checkConcurrentAccess(fileDetailsVO);
						if(conCurrentAccess){
							commonUtil.addReleaseFileMgmtResponseVO(fileName, resourceManager.getMessage(ErrorConstants.CONCURRENT_ACCESS), true, releaseFileMgmtResponseVO);
							return releaseFileMgmtResponseVO;
						}
						
						
						fileAuthProfileList = releaseFileServiceImpl.getAuthMatrix(user.getUserId(),fileDetailsVO.getSenderOrgId());	
						if(fileAuthProfileList != null && !fileAuthProfileList.isEmpty())
						{
							for(FileReleaseAuthProfileVO authVO : fileAuthProfileList)
							{
								tempCount++;
								String authCcy = authVO.getAuthCcy();
								BigDecimal maxAmountFromFile = getMaximumAmount(fileDetailsVO,authCcy, branchCcy, branchCode);
								if(maxAmountFromFile.compareTo(authVO.getAuthLimitAmount()) <= 0)
								{
									try 
										{
										int errorCode=releaseFileServiceImpl.checkAndLockRecordForProcessing(fileDetailsVO.getFileId(),BNPConstants.AUTH);
										if(errorCode>0)
										{
											commonUtil.addReleaseFileMgmtResponseVO(fileName, resourceManager.getMessage(errorCode), true, releaseFileMgmtResponseVO);
											return releaseFileMgmtResponseVO;
										}
										lockedFlag=true;
										
										if(authVO.getAuthProfileType().equalsIgnoreCase("SINGLE")){
											logger.warn("Enter : releaseFile process = {}",System.currentTimeMillis()); 
											errorList = releaseFileServiceImpl.releaseFile(fileDetailsVO,user.getUserId(), false);	
											
											logger.info("Calling raise discount method in discount payment service");
											Map<String,String> resultMap = cacheService.getAutoDiscParam();
										String autoDiscThrSch = (String)resultMap.get("RUN_AS_JOB");
					
											if(BNPConstants.YES.equals(autoDiscThrSch)){
												List<DiscountRequestVO> discReqLst = discPymtService.getOADRecords(fileDetailsVO.getSenderOrgId(), String.valueOf(fileDetailsVO.getFileId()));
												if(discReqLst != null && !discReqLst.isEmpty()){
													invoiceUploadService.scheduleAutoDiscounting(fileDetailsVO);
												}
											}else{
												discPymtService.raiseDiscount(fileDetailsVO);
											}
												
											if(errorList != null && errorList.size() > 0) {
												fileDetailsVO.setErrorDesc(getErrorData(errorList));
												invoiceUploadService.updateFileStatus(fileDetailsVO);
												fileInfo = resourceManager.getMessage(ErrorConstants.FILE_RELEASE_FAILURE);
												commonUtil.addReleaseFileMgmtResponseVO(fileName, fileInfo, true, releaseFileMgmtResponseVO);
											}else {
												fileInfo = resourceManager.getMessage(ErrorConstants.FILE_RELEASE_SUCCESS);
												logger.debug("*****GOing to call checkForOfferLetterTrigger******** ");
												commonUtil.addReleaseFileMgmtResponseVO(fileName, fileInfo, false, releaseFileMgmtResponseVO);
												invoiceUploadService.checkForOfferLetterTrigger(fileDetailsVO);
											}
											break;
										}
										else if(authVO.getAuthProfileType().equalsIgnoreCase("JOINT"))
										{
											authVO.setSenderOrgId(fileDetailsVO.getSenderOrgId());
											authVO.setAuthCcy(authCcy);
											
											//First-level-approval
											if(fileStatus.equalsIgnoreCase(propertyLoader.getValue("file.status.pending.approval"))){
												fileDetailsVO.setUserId(user.getUserId());
												fileDetailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.partial.authorize"));
												logger.debug("This is the First-Level approvals :: ");
												logger.debug("User is elligible for First-Level approval :: staring the approval");
												//setting the Auth-Profile-id and Auth-level of the Logged-in user so that the same can be updated in Database									
												fileDetailsVO.setAuthProfileId(authVO.getAuthProfileId());
												fileDetailsVO.setAuthLevel(authVO.getAuthLevel());
												
												logger.debug("Updating the T_file_Upload with Aut-profile-id and auth-level of the first-approver logged-in user");
												invoiceUploadService.updateFileStatus(fileDetailsVO);
												try
												{
													releaseFileServiceImpl.sendMailToAuthorizers(fileDetailsVO, authVO.getAuthLimitAmount(), authVO.getAuthLevel(),authVO.getAuthLevelOrd());
												}
												catch(BNPApplicationException e)
												{
													logger.error("Mail not sent. Please check mail configuration" + e);
												}
												fileInfo = resourceManager.getMessage(ErrorConstants.FILE_PARTIALLY_AUTHORIZED);
												commonUtil.addReleaseFileMgmtResponseVO(fileName, fileInfo, false, releaseFileMgmtResponseVO);
												break;
											}
											
											//Second-level-approval
											if(fileStatus.equalsIgnoreCase(propertyLoader.getValue("file.status.partial.authorize")))
											{
												if(fileDetailsVO.getUserId().equalsIgnoreCase(user.getUserId()))
												{
													commonUtil.addReleaseFileMgmtResponseVO(fileName, resourceManager.getMessage(ErrorConstants.FILE_RELEASE_CANNOT_AUTHORIZE), true, releaseFileMgmtResponseVO);
												} 
												else
												{
													logger.debug("This is Second-Level approvals :: Further checks");
													//Check Same-Profile as Level-1 approver and auth level should not be same as the first authorizer
													if(fileDetailsVO.getAuthProfileId().equalsIgnoreCase(authVO.getAuthProfileId()) && !fileDetailsVO.getAuthLevel().equalsIgnoreCase(authVO.getAuthLevel()))
													{
														logger.debug("The Logged-in Second-Level approver user's Profile-Id is same as First-Level approver ");
														logger.debug("This is Second-Level approvals :: The Logged-in user's Auth-Level is same as expected Auth-Level<Level 2>.");
			
														//Calling to update the auth-profile-id and auth-level of second level approver to T_file_upload
														logger.debug("Updating the selected data to second-approver logged-in user");
														fileDetailsVO.setAuthProfileId(authVO.getAuthProfileId());
														fileDetailsVO.setAuthLevel(authVO.getAuthLevel());
			
														//Calling to update the auth-profile-id and auth-level of second level approver to T_file_upload
														logger.debug("Updating the T_file_Upload with Aut-profile-id and auth-level of the second-approver logged-in user");
														invoiceUploadService.updateFileStatus(fileDetailsVO);
														
														logger.warn("Enter : releaseFile = {}",System.currentTimeMillis()); 
														releaseFileServiceImpl.releaseFile(fileDetailsVO,user.getUserId(), false);
														
														
														
														logger.info("Calling raise discount method in discount payment service");
														Map<String,String> resultMap = cacheService.getAutoDiscParam();
														String autoDiscThrSch = (String)resultMap.get("RUN_AS_JOB");
														if(BNPConstants.YES.equals(autoDiscThrSch)){
															List<DiscountRequestVO> discReqLst = discPymtService.getOADRecords(fileDetailsVO.getSenderOrgId(), String.valueOf(fileDetailsVO.getFileId()));
															if(discReqLst != null && !discReqLst.isEmpty()){
																invoiceUploadService.scheduleAutoDiscounting(fileDetailsVO);
															}
														}else{
															discPymtService.raiseDiscount(fileDetailsVO);
														}
													    
														logger.warn("Exit : releaseFile = {}",System.currentTimeMillis()); 
														
														if(errorList != null && errorList.size() > 0) {
															fileDetailsVO.setErrorDesc(getErrorData(errorList));
															invoiceUploadService.updateFileStatus(fileDetailsVO);
															fileInfo = resourceManager.getMessage(ErrorConstants.FILE_RELEASE_FAILURE);
															commonUtil.addReleaseFileMgmtResponseVO(fileName, fileInfo, true, releaseFileMgmtResponseVO);
														}else {
															fileInfo = resourceManager.getMessage(ErrorConstants.FILE_RELEASE_SUCCESS);
															commonUtil.addReleaseFileMgmtResponseVO(fileName, fileInfo, false, releaseFileMgmtResponseVO);
															logger.debug("*****GOing to call checkForOfferLetterTrigger******** ");
															invoiceUploadService.checkForOfferLetterTrigger(fileDetailsVO);
														}
													}
													else
													{
														//Check if the there is any other profile for the second-approver user with Limit-amt > profile of First-Approver where the second-approver is at higer level in this new profile 
														tempAuthVO.setSenderOrgId(fileDetailsVO.getSenderOrgId());
														tempAuthVO.setAuthCcy(authCcy);
														tempAuthVO.setAuthProfileId(fileDetailsVO.getAuthProfileId());
														tempAuthVO.setAuthLevel(fileDetailsVO.getAuthLevel());
														tempAuthVO.setAuthUserId(user.getUserId());
														tempAuthVO.setAuthLimitAmount(authVO.getAuthLimitAmount());
														tempAuthVO.setPrevAuthUserId(uploadedBy);
														
														boolean flag=true;	
					
														authApprHighAmtList = releaseFileServiceImpl.chkOtherProfileHighLimit(tempAuthVO);	
														if(authApprHighAmtList.size() > 0)
														{
															tempAuthVO.setDiffProfHighAmtList(authApprHighAmtList);
															//914727 return type changed for CSCDEV-1488-start
															authProfileDetails = releaseFileServiceImpl.chkTermsOtherProfileLimit(tempAuthVO);	
														
															if(authProfileDetails!=null){
																logger.debug("User is elligible for First-Level approval :: staring the approval");
																//Calling to update the auth-profile-id and auth-level of second level approver to T_file_upload
																logger.debug("Updating the selected data to second-approver logged-in user");
																fileDetailsVO.setAuthProfileId(authProfileDetails.getName());
																fileDetailsVO.setAuthLevel(authProfileDetails.getValue());
																 //914727 return type changed for CSCDEV-1488-end
			
																//Calling to update the auth-profile-id and auth-level of second level approver to T_file_upload
																logger.debug("Updating the T_file_Upload with Aut-profile-id and auth-level of the second-approver logged-in user");
																invoiceUploadService.updateFileStatus(fileDetailsVO);
																
																logger.warn("Enter : releaseFile = {}",System.currentTimeMillis()); 
																releaseFileServiceImpl.releaseFile(fileDetailsVO,user.getUserId(), false);
																//914727 CSCDEV-3632 19-MAY-2015 :Start
																/*logger.info("Calling raise discount method in discount payment service");
																discPymtService.raiseDiscount(selectedData);*/
																
																
																logger.info("Calling raise discount method in discount payment service");
																Map<String,String> resultMap = cacheService.getAutoDiscParam();
																String autoDiscThrSch = (String)resultMap.get("RUN_AS_JOB");
			
																if(BNPConstants.YES.equals(autoDiscThrSch)){
																	List<DiscountRequestVO> discReqLst = discPymtService.getOADRecords(fileDetailsVO.getSenderOrgId(), String.valueOf(fileDetailsVO.getFileId()));
																	if(discReqLst != null && !discReqLst.isEmpty()){
																		invoiceUploadService.scheduleAutoDiscounting(fileDetailsVO);
																	}
																}else{
																	discPymtService.raiseDiscount(fileDetailsVO);
																}
																logger.warn("Exit : releaseFile = {}",System.currentTimeMillis()); 
																//914727 CSCDEV-3632 19-MAY-2015 :End
																if(errorList != null && errorList.size() > 0) {
																	fileDetailsVO.setErrorDesc(getErrorData(errorList));
																	invoiceUploadService.updateFileStatus(fileDetailsVO);
																	fileInfo = resourceManager.getMessage(ErrorConstants.FILE_RELEASE_FAILURE);
																	commonUtil.addReleaseFileMgmtResponseVO(fileName, fileInfo, true, releaseFileMgmtResponseVO);
																}else {
																	fileInfo = resourceManager.getMessage(ErrorConstants.FILE_RELEASE_SUCCESS);
																	commonUtil.addReleaseFileMgmtResponseVO(fileName, fileInfo, false, releaseFileMgmtResponseVO);
																	logger.debug("*****GOing to call checkForOfferLetterTrigger******** ");
																	invoiceUploadService.checkForOfferLetterTrigger(fileDetailsVO);
																}
																break;
															}
															else
															{
																logger.debug("This is Second-Level approvals :: The Logged-in user is not elligible for secod-level authorizaton");
																commonUtil.addReleaseFileMgmtResponseVO(fileName, resourceManager.getMessage(ErrorConstants.FILE_RELEASE_NOT_ELIGIBLE), true, releaseFileMgmtResponseVO);
																break;
															}
														}
														else
														{
															logger.debug("This is Second-Level approvals :: The Logged-in user is not elligible for secod-level authorizaton");
															commonUtil.addReleaseFileMgmtResponseVO(fileName, resourceManager.getMessage(ErrorConstants.FILE_RELEASE_NOT_ELIGIBLE), true, releaseFileMgmtResponseVO);
															break;
														}
			
													}
													invoiceUploadService.checkForOfferLetterTrigger(fileDetailsVO);
												}
												break;
											}
										}
									}
									catch (BNPApplicationException e) {
										logger.error("Error "+e.getErrorCode());
									}
									
									//914727 CSCDEV-6014 1-Dec-2016 :Start
									finally{
										
										try{
											if(lockedFlag)
											{
												releaseFileServiceImpl.updateStatusForLocking(String.valueOf(fileDetailsVO.getFileId()),BNPConstants.NO,BNPConstants.AUTH);		
											}
										}
										catch(BNPApplicationException e)
										{
											logger.error("Error in authorize file()-unlocking of record failed"+e.getErrorCode());
										}
										
									}
									//	914727 CSCDEV-6014 1-Dec-2016 :End
								}
								if(!(maxAmountFromFile.compareTo(authVO.getAuthLimitAmount()) == -1) && !fileAuthProfileList.isEmpty() && fileAuthProfileList.size()==tempCount
										&& (fileStatus.equalsIgnoreCase(propertyLoader.getValue("file.status.pending.approval"))
										|| fileStatus.equalsIgnoreCase(propertyLoader.getValue("file.status.partial.authorize")))){
									commonUtil.addReleaseFileMgmtResponseVO(fileName, resourceManager.getMessage(ErrorConstants.FILE_RELEASE_NOT_ELIGIBLE), true, releaseFileMgmtResponseVO);
								}
							}
						}
						else{
							commonUtil.addReleaseFileMgmtResponseVO(fileName, resourceManager.getMessage(ErrorConstants.FILE_RELEASE_NOT_ELIGIBLE), true, releaseFileMgmtResponseVO);
						}
					}
				}
			}
		}
		catch(Exception e)
		{
			logger.error("Caught Exception in authorizeFile process.");
		}
		return releaseFileMgmtResponseVO;
	}
	
	
	/**
	 * @param fileDetailsVOList
	 * @param user
	 * @return
	 * @throws BNPApplicationException
	 */
	public ReleaseFileMgmtResponseVO rejectFile(List<FileDetailsVO> fileDetailsVOList, UserInfoVO user) throws BNPApplicationException {
		FileDetailsVO selectedData;
		ReleaseFileMgmtResponseVO releaseFileMgmtResponseVO = new ReleaseFileMgmtResponseVO();
		String fileName;
		String fileInfo;
		String uploadedBy;
		String fileStatus;
		List<FileReleaseAuthProfileVO> authProfileList;
		for(int i=0;i< fileDetailsVOList.size();i++)
		{
			selectedData = fileDetailsVOList.get(i);
			fileName = selectedData.getFileName();
			uploadedBy = selectedData.getUserId();
			fileStatus = selectedData.getFileUploadStatus();
			if(validateRejectRecordStatus(fileStatus, fileName, releaseFileMgmtResponseVO) && checkMaker(user.getUserId(), uploadedBy, fileName, REJECT, releaseFileMgmtResponseVO))
			{
				authProfileList = releaseFileServiceImpl.getAuthMatrix(user.getUserId(),selectedData.getSenderOrgId());
				if(authProfileList!=null && !authProfileList.isEmpty())
				{
					try {
						selectedData.setCurrentUserId(user.getUserId());
						releaseFileServiceImpl.rejectFile(selectedData, user.getUserId());
						fileInfo = resourceManager.getMessage(ErrorConstants.REJECT_FILE_SUCCESS);
						commonUtil.addReleaseFileMgmtResponseVO(fileName, fileInfo, false, releaseFileMgmtResponseVO);
					} catch (BNPApplicationException e) {
						fileInfo = resourceManager.getMessage(ErrorConstants.REJECT_FILE_FAILURE);
						commonUtil.addReleaseFileMgmtResponseVO(fileName, fileInfo, true, releaseFileMgmtResponseVO);
					}
				}
				else
				{
					fileInfo = resourceManager.getMessage(ErrorConstants.CANNOT_REJECT_RECORD);
					commonUtil.addReleaseFileMgmtResponseVO(fileName, fileInfo, true, releaseFileMgmtResponseVO);;
				}
			}
			
		} 
		return releaseFileMgmtResponseVO;
	}
	
	private boolean checkMaker(String loginUserId, String uploadedBy, String fileName, String userAction, ReleaseFileMgmtResponseVO releaseFileMgmtResponseVO) {
		String fileInfo = "";
		if( !DELETE.equals(userAction) && uploadedBy != null && !loginUserId.equals(uploadedBy)){  //Release , authorize, Reject Maker cannot modify the record
			return true;
		}else if(DELETE.equals(userAction) && (uploadedBy != null && loginUserId.equals(uploadedBy))){  //only maker can Undo
			return true;
		}
		else{
			if(userAction.equals(RELEASE))
			{
				fileInfo = resourceManager.getMessage(ErrorConstants.MAKER_CHECK_RELEASE);
			}
			else if(userAction.equals(DELETE))
			{
				fileInfo = resourceManager.getMessage(ErrorConstants.MAKER_CHECK_DELETE);
			}
			else if(userAction.equals(AUTHORIZE))
			{
				fileInfo = resourceManager.getMessage(ErrorConstants.MAKER_CHECK_AUTHORIZE);
			}
			else if(userAction.equals(REJECT))
			{
				fileInfo = resourceManager.getMessage(ErrorConstants.MAKER_CHECKER_REJECT);
			}
			commonUtil.addReleaseFileMgmtResponseVO(fileName, fileInfo, true, releaseFileMgmtResponseVO);
			return false;
			
		}
	}
	
	private BigDecimal getMaximumAmount(FileDetailsVO selectedData, String authCcy, String branchCcy, String branchCode) {
		BigDecimal maxAmountFromFile = null;
		Map<String,BigDecimal> params = null;
		try{
			if (selectedData.getInvoiceGroup() == 1) {
				params= invoiceService.getMaxPymtAmount(selectedData.getFileId());
				//NameValueVO payableVO= invoiceService.getMaxPymtAmount(selectedData.getFileId());
				maxAmountFromFile = calcMaximumAmount(params, authCcy, branchCcy, branchCode);
			} else if (selectedData.getInvoiceGroup() == 2) {
				params = invoiceService.getMaxInvAmount(selectedData.getFileId());
				maxAmountFromFile = calcMaximumAmount(params, authCcy, branchCcy, branchCode);
			}
			}
			catch  (BNPApplicationException e) {
				logger.debug("Exception occured in getMaximumAmount. Cannot get max amount");
			}
		return maxAmountFromFile;
	}
	private BigDecimal calcMaximumAmount(Map<String, BigDecimal> params, String authCcy, String branchCcy, String branchCode) {
		BigDecimal maxAmount = null;
		BigDecimal availableAmt;
		String txnCcy;
		BigDecimal maxAmountTemp;
		for(Map.Entry<String, BigDecimal> entry : params.entrySet()) {
			txnCcy = entry.getKey();
			availableAmt = entry.getValue();
			try {
				maxAmountTemp = releaseFileServiceImpl.getConvertedAmt(availableAmt, txnCcy, authCcy, branchCcy, branchCode);
				if(maxAmount != null){
                    if(maxAmountTemp.compareTo(maxAmount)== 1){
                        maxAmount = maxAmountTemp;
                    }
                } else {
					maxAmount = maxAmountTemp;
				}
			} catch  (BNPApplicationException e) {
				logger.debug("Exception occured in getMaximumAmount. Cannot calculate max amount");
			}
		}
		return maxAmount;
	}
	

}