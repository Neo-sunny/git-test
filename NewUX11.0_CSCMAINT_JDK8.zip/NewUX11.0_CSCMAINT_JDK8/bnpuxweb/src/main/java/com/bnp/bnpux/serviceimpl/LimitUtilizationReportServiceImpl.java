/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   21 June 2017
 * 
 * Purpose:      Limit Utilization Report Service Implementation
 * 
 * Change History:
 *  
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 21 June 2017       Ratna Gokhale, Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.common.vo.LimitUtilizationReportDetailsVO;
import com.bnp.bnpux.constants.LimitUtilizationConstants;
import com.bnp.bnpux.constants.ReportsConstant;
import com.bnp.bnpux.dao.ILimitUtilizationReportDAO;
import com.bnp.bnpux.service.ILimitUtilizationReportService;
import com.bnp.bnpux.vo.requestVO.LimitUtilizationRequestVO;
import com.bnp.bnpux.vo.responseVO.LimitUtilizationResponseVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@Component
public class LimitUtilizationReportServiceImpl implements ILimitUtilizationReportService{

	@Autowired
	private ILimitUtilizationReportDAO limitUtilizationReportDAO;
	
	/**
	 * Logger log for LimitUtilizationReportServiceImpl class
	 */
	private static final Logger log = LoggerFactory.getLogger(LimitUtilizationReportServiceImpl.class);
	
	/**
	 * Constant for Exception message
	 */
	public static final String EXCEPTION_UNABLE_TO_PROCESS = "Unable to process action - Database Exception";
	
	/**
	 * This service implementation method is used to fetch latest Limit Utilization Report list
	 * 
	 * @param LimitUtilizationRequestVO 
	 * @return LimitUtilizationResponseVO
	 */
	@Override
	public LimitUtilizationResponseVO getReportList(LimitUtilizationRequestVO limitUtilizationRequestVO) throws BNPApplicationException {
		LimitUtilizationResponseVO limitUtilizationResponseVO = null; 
		try{
			limitUtilizationResponseVO = new LimitUtilizationResponseVO();
			
			if(LimitUtilizationConstants.LIMIT_UTILIZATION_LIST.equalsIgnoreCase(limitUtilizationRequestVO.getViewType())) {
				limitUtilizationReportDAO.getReportList(limitUtilizationRequestVO);
				if(limitUtilizationRequestVO.getLimitUtilizationReportList() != null) {
					limitUtilizationResponseVO.setLimitUtilizationReportList(limitUtilizationRequestVO.getLimitUtilizationReportList());
				}
			} else if(LimitUtilizationConstants.LIMIT_UTILIZATION_DETAILS.equalsIgnoreCase(limitUtilizationRequestVO.getViewType())) {
				limitUtilizationReportDAO.getReportListDetails(limitUtilizationRequestVO);
				if(limitUtilizationRequestVO.getLimitUtilizationReportDetails() != null) {
					limitUtilizationResponseVO.setLimitUtilizationReportDetails(limitUtilizationRequestVO.getLimitUtilizationReportDetails());
					
					
					List<LimitUtilizationReportDetailsVO> limitUtilizationReportDetails = limitUtilizationRequestVO.getLimitUtilizationReportDetails();
					
					List<LimitUtilizationReportDetailsVO> entityLimitDetails = new ArrayList<LimitUtilizationReportDetailsVO>();
					
					List<LimitUtilizationReportDetailsVO> groupEntityLimitDetails = new ArrayList<LimitUtilizationReportDetailsVO>();
					
					List<LimitUtilizationReportDetailsVO> groupThirdPartyLimitDetails = new ArrayList<LimitUtilizationReportDetailsVO>();
					
					List<LimitUtilizationReportDetailsVO> thirdPartyLimitDetails = new ArrayList<LimitUtilizationReportDetailsVO>();
					
					List<LimitUtilizationReportDetailsVO> counterpartyLimitDetails = new ArrayList<LimitUtilizationReportDetailsVO>();
					
					List<LimitUtilizationReportDetailsVO> groupCounterpartyLimitDetails = new ArrayList<LimitUtilizationReportDetailsVO>();
					
					List<LimitUtilizationReportDetailsVO> groupCounterpartyThirdPartyLimitDetails = new ArrayList<LimitUtilizationReportDetailsVO>();
					
					List<LimitUtilizationReportDetailsVO> counterpartyThirdPartyLimitDetails = new ArrayList<LimitUtilizationReportDetailsVO>();
					
					for(LimitUtilizationReportDetailsVO reportDetails : limitUtilizationReportDetails){
						
						if(reportDetails.getLimitType().equalsIgnoreCase("Entity Limit")){
							entityLimitDetails.add(reportDetails);
						}
						if(reportDetails.getLimitType().equalsIgnoreCase("Group Entity Limit")){
							groupEntityLimitDetails.add(reportDetails);
						}
						if(reportDetails.getLimitType().equalsIgnoreCase("Group Third party Limit")){
							groupThirdPartyLimitDetails.add(reportDetails);
						}
						if(reportDetails.getLimitType().equalsIgnoreCase("Third party Limit")){
							thirdPartyLimitDetails.add(reportDetails);
						}
						if(reportDetails.getLimitType().equalsIgnoreCase("Counterparty Limit")){
							counterpartyLimitDetails.add(reportDetails);
						}
						if(reportDetails.getLimitType().equalsIgnoreCase("Group Counterparty Limit")){
							groupCounterpartyLimitDetails.add(reportDetails);
						}
						if(reportDetails.getLimitType().equalsIgnoreCase("Counterparty Third party Limit")){
							counterpartyThirdPartyLimitDetails.add(reportDetails);
						}
						if(reportDetails.getLimitType().equalsIgnoreCase("Group Counterparty Third party Limit")){
							groupCounterpartyThirdPartyLimitDetails.add(reportDetails);
						}
						
					}
					
					limitUtilizationResponseVO.setEntityLimitDetails(entityLimitDetails);
					limitUtilizationResponseVO.setGroupEntityLimitDetails(groupEntityLimitDetails);
					limitUtilizationResponseVO.setGroupThirdPartyLimitDetails(groupThirdPartyLimitDetails);
					limitUtilizationResponseVO.setThirdPartyLimitDetails(thirdPartyLimitDetails);
					limitUtilizationResponseVO.setCounterpartyLimitDetails(counterpartyLimitDetails);
					limitUtilizationResponseVO.setGroupCounterpartyLimitDetails(groupCounterpartyLimitDetails);
					limitUtilizationResponseVO.setGroupCounterpartyThirdPartyLimitDetails(groupCounterpartyThirdPartyLimitDetails);
					limitUtilizationResponseVO.setCounterpartyThirdPartyLimitDetails(counterpartyThirdPartyLimitDetails);
					
				}
			} 
			
			if(limitUtilizationRequestVO.getErrorMsg() != null){				
				log.error(EXCEPTION_UNABLE_TO_PROCESS + limitUtilizationRequestVO.getErrorMsg());
				//throw new BNPApplicationException(EXCEPTION_UNABLE_TO_PROCESS);	
			}
			
			
		} catch(DataAccessException exception) {
			log.error(EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(EXCEPTION_UNABLE_TO_PROCESS);	
		}
		return limitUtilizationResponseVO;
	}


	/**
	 * This method is for getting Limit Utilization Report details
	 * 
	 * @param LimitUtilizationRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public LimitUtilizationResponseVO getReportDetails(LimitUtilizationRequestVO limitUtilizationRequestVO)
			throws BNPApplicationException {
		// TODO Auto-generated method stub
		String errorFlag = null;	
		LimitUtilizationResponseVO limitUtilizationResponseVO = new LimitUtilizationResponseVO();
		try{
			
		}catch(Exception exception){
			log.error(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS);
		}
		return limitUtilizationResponseVO;
	}
	
	/**
	 * This method is for getting report chart axis 
	 * 
	 * @param requestVo
	 * @return
	 * @throws BNPApplicationException
	 */
	public List<ReportChartResponseVO> getReportChartAxis (LimitUtilizationRequestVO limitUtilizationRequestVO)throws BNPApplicationException {
		List<ReportChartResponseVO> reportVOList = new ArrayList<ReportChartResponseVO>();
		try{
			
			limitUtilizationReportDAO.getChartAxis(limitUtilizationRequestVO);
		reportVOList = (List<ReportChartResponseVO>) limitUtilizationRequestVO.getReportChartList();
		
		
		}catch(Exception exception){
			log.error(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS);
		}
		return reportVOList;
	}
	



}
