/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   15-JUL-2017
 * 
 * Purpose:      SCF Attach Upload Controller
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 15-JUL-2017				Divyashri Subramaniam						To Handle service calls related to SCF Attachment Upload
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.service.IAuditService;
import com.bnp.bnpux.service.IPaymentOrderService;
import com.bnp.bnpux.util.RequestIdentityValidator;
import com.bnp.bnpux.vo.requestVO.AuditRequestVO;
import com.bnp.bnpux.vo.requestVO.FileUploadRequestVO;
import com.bnp.bnpux.vo.requestVO.SCFAttachUploadRequestVO;
import com.bnp.bnpux.vo.responseVO.AttachmentResponseVO;
import com.bnp.bnpux.vo.responseVO.FileUploadResponseVO;
import com.bnp.bnpux.wrappers.service.ISCFAttachFileUploadWrapperService;
import com.bnp.scm.services.attachment.vo.SCFAttachmentUploadVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.util.ScreenConstants;
import com.bnp.scm.services.filemgmt.vo.FileVO;

@RestController
@RequestMapping("/scfattachUploadCtrl")
public class SCFAttachUploadController {

	public static final Logger log = LoggerFactory.getLogger(SCFAttachUploadController.class);

	@Autowired
	private ISCFAttachFileUploadWrapperService scfAttachFileUploadWrapperService;

    @Autowired
	private IAuditService auditService;
    
    @Autowired
	RequestIdentityValidator validateRequest;
	
    @Autowired
	private IPaymentOrderService paymentOrderService;

	
    @RequestMapping(value = "populateSelectedData.rest", method = RequestMethod.POST)
	public void populateSelectedData(@RequestBody SCFAttachUploadRequestVO scfAttachUploadRequestVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		FileUploadResponseVO fileUploadResponseVO = new FileUploadResponseVO();
		try {
			boolean requestValidatedFlag = validateRequest.validate(scfAttachUploadRequestVO.getUserId(), httpServletRequest.getSession());					
			String sessionId = httpServletRequest.getSession(false).getId();
			if(requestValidatedFlag){				    									
				scfAttachFileUploadWrapperService.populateSelectedData(scfAttachUploadRequestVO);
			}else{
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} 
		catch (Exception exception) {
			fileUploadResponseVO.setErrorMsg(exception.getMessage());
			log.error(exception.getMessage(), exception);
		}
	}
    
    @RequestMapping(value = "attachFileUpload.rest", method = RequestMethod.POST, consumes = {"multipart/form-data"})
    public SCFAttachUploadRequestVO onAttachFileUpload( @RequestPart("data") SCFAttachUploadRequestVO scfAttachUploadRequestVO, @RequestPart("file") MultipartFile file,HttpServletRequest request, HttpServletResponse response) {
    	try {
			boolean requestValidatedFlag = validateRequest.validate(scfAttachUploadRequestVO.getUserId(), request.getSession());					
			String sessionId = request.getSession(false).getId();
			if(requestValidatedFlag){				    									
				scfAttachFileUploadWrapperService.uploadAttachmentUpload(scfAttachUploadRequestVO,file);
				AuditRequestVO auditVo = new AuditRequestVO();
				auditVo.setUserId(scfAttachUploadRequestVO.getUserId());
				auditVo.setSessionId(sessionId);
				auditVo.setFuncId(ScreenConstants.ACCESS_LOG_FILE_UPLOAD);
				auditVo.setOrgId(scfAttachUploadRequestVO.getOrgId());								
				auditService.insertAuditLog(auditVo);
			}else{
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
    	}catch (IOException exception) {
    		log.error(exception.getMessage(), exception);
    	}
    	return scfAttachUploadRequestVO;
    }
    
    @RequestMapping(value = "saveAttachments.rest", method = RequestMethod.POST)
	public SCFAttachUploadRequestVO getUpdatedFileUploadStatus(@RequestBody SCFAttachUploadRequestVO scfAttachUploadRequestVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		try {
			boolean requestValidatedFlag = validateRequest.validate(scfAttachUploadRequestVO.getUserId(), httpServletRequest.getSession());
			if (requestValidatedFlag) {		
				scfAttachFileUploadWrapperService.saveAttachmentUpload(scfAttachUploadRequestVO);
			} else {
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} 
		catch (Exception exception) {
			log.error(exception.getMessage(), exception);

		}
		return scfAttachUploadRequestVO;
	}
    
    @RequestMapping(value = "approveAttachments.rest", method = RequestMethod.POST)
   	public SCFAttachUploadRequestVO approveAttachments(@RequestBody SCFAttachUploadRequestVO scfAttachUploadRequestVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
   		try {
   			boolean requestValidatedFlag = validateRequest.validate(scfAttachUploadRequestVO.getUserId(), httpServletRequest.getSession());
   			if (requestValidatedFlag) {		
   				scfAttachFileUploadWrapperService.approveAttachmentUpload(scfAttachUploadRequestVO);
   			} else {
   				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
   				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
   			}
   		} 
   		catch (Exception exception) {
   			log.error(exception.getMessage(), exception);
   		}
   		return scfAttachUploadRequestVO;
   	}
    
    @RequestMapping(value = "undoAttachments.rest", method = RequestMethod.POST)
   	public SCFAttachUploadRequestVO undoAttachments(@RequestBody SCFAttachUploadRequestVO scfAttachUploadRequestVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
   		try {
   			boolean requestValidatedFlag = validateRequest.validate(scfAttachUploadRequestVO.getUserId(), httpServletRequest.getSession());
   			if (requestValidatedFlag) {		
   				scfAttachFileUploadWrapperService.undoAttachmentUpload(scfAttachUploadRequestVO);
   			} else {
   				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
   				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
   			}
   		} 
   		catch (Exception exception) {
   			log.error(exception.getMessage(), exception);
   		}
   		return scfAttachUploadRequestVO;
   	}
    @RequestMapping(value = "deleteAttachments.rest", method = RequestMethod.POST)
   	public SCFAttachUploadRequestVO deleteAttachments(@RequestBody SCFAttachUploadRequestVO scfAttachUploadRequestVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
   		try {
   			boolean requestValidatedFlag = validateRequest.validate(scfAttachUploadRequestVO.getUserId(), httpServletRequest.getSession());
   			if (requestValidatedFlag) {		
   				scfAttachFileUploadWrapperService.deleteAttachmentUpload(scfAttachUploadRequestVO);
   			} else {
   				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
   				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
   			}
   		} 
   		catch (Exception exception) {
   			log.error(exception.getMessage(), exception);
   		}
   		return scfAttachUploadRequestVO;
   	}
 // US S51200 
 	/**
 	 * This method is for getting Payment Order Attachment details
 	 * 
 	 * @param attachmentRequestVO
 	 * @return
 	 */
 	@RequestMapping(value = "populateAttachmentList.rest", method = RequestMethod.POST)
 	public AttachmentResponseVO populateAttachmentList(@RequestBody  SCFAttachUploadRequestVO attachmentRequestVO , HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
 		AttachmentResponseVO attachmentResponseVO = new AttachmentResponseVO();
 		try {
 			boolean requestValidatedFlag = validateRequest.validate(attachmentRequestVO.getUserId(), httpServletRequest.getSession());
   			if (requestValidatedFlag) {		
   				attachmentResponseVO.setAttachmentList(scfAttachFileUploadWrapperService.getAttachmentList(attachmentRequestVO));
   			} else {
   				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
   				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
   			}
 		} catch (Exception exception) {
 			attachmentResponseVO.setErrorMsg(exception.getMessage());
 			log.error(exception.getMessage(),exception);
 		}
 		return attachmentResponseVO;
 	}
 	
 	@RequestMapping(value = "getInvoiceCredNoteList.rest", method = RequestMethod.POST)
 	public SCFAttachUploadRequestVO getInvoiceCredNoteList(@RequestBody  SCFAttachUploadRequestVO scfAttachUploadRequestVO , HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
 		try {
 			boolean requestValidatedFlag = validateRequest.validate(scfAttachUploadRequestVO.getUserId(), httpServletRequest.getSession());
   			if (requestValidatedFlag) {		
   				if(scfAttachUploadRequestVO.getPymtID() != null){
   					scfAttachFileUploadWrapperService.getInvoiceCredNoteList(scfAttachUploadRequestVO);
   				}
   				else if(scfAttachUploadRequestVO.getPymtID() == null && scfAttachUploadRequestVO.getInvID() != null){
   					scfAttachFileUploadWrapperService.getCredNoteList(scfAttachUploadRequestVO);
   				}
   			} else {
   				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
   				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
   			}
 		} catch (Exception exception) {
 			log.error(exception.getMessage(),exception);
 		}
 		return scfAttachUploadRequestVO;
 	}
 	
 	@RequestMapping(value = "closeAttachmentPopup.rest", method = RequestMethod.POST)
 	public SCFAttachUploadRequestVO closeAttachmentPopup(@RequestBody  SCFAttachUploadRequestVO scfAttachUploadRequestVO , HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
 		try {
 			boolean requestValidatedFlag = validateRequest.validate(scfAttachUploadRequestVO.getUserId(), httpServletRequest.getSession());
   			if (requestValidatedFlag) {		
   					scfAttachFileUploadWrapperService.closeAttachmentPopup(scfAttachUploadRequestVO);
   			} else {
   				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
   				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
   			}
 		} catch (Exception exception) {
 			log.error(exception.getMessage(),exception);
 		}finally{
 			String cntFlg = "N"; 
 			try {
 				int cnt = paymentOrderService.getPendAppovalCntService(scfAttachUploadRequestVO.getAttachPmtId());
 				if(cnt>0){
 					cntFlg = "Y";
 				}
 				scfAttachUploadRequestVO.setAttchPendAppFlg(cntFlg);
 			}catch (BNPApplicationException exception) {
 				log.error(exception.getMessage(),exception);
 			}
 			
 		}
 		return scfAttachUploadRequestVO;
 	}
    
}