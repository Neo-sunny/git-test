package com.bnp.bnpux.common.vo;

import java.util.Date;
import java.util.List;

public class EmailNotificationsVO{
	
	private List<EmailAttachmentVO> attachmentContents;
	
	private byte[] attachmentData;
	
	private String userId;

	private String alertId;
	
	private String eventListId;
	
	private String eventName;
	
	private String emailCategory;
	
	private String orgId;
	
	private Date disburseTime;
	
	private String refKeyId;
	
	private String eventDeliveryStatus;
	
	private String attachementCount;
	
	private String attachmentName;
	
	private String rowNo;
	
	private String totalRecordCount;
	
	private String subject;
	private String toEmailIds;
	private String ccEmailIds;
	private String bccEmailIds;
	private String supportBranchId;
	
	private int emailOrder;
	
	private int readFlag;
	
	private int readSequence;
	
	
	
	private String errorMessage;
	
	private boolean allFlag;
	
	public boolean isAllFlag() {
		return allFlag;
	}

	public void setAllFlag(boolean allFlag) {
		this.allFlag = allFlag;
	}

	public String getEmailAttachList() {
		return emailAttachList;
	}

	public void setEmailAttachList(String emailAttachList) {
		this.emailAttachList = emailAttachList;
	}

	private String emailAttachList;
	
	
	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public int getEmailOrder() {
		return emailOrder;
	}

	public void setEmailOrder(int emailOrder) {
		this.emailOrder = emailOrder;
	}

	public int getReadFlag() {
		return readFlag;
	}

	public void setReadFlag(int readFlag) {
		this.readFlag = readFlag;
	}

	public int getReadSequence() {
		return readSequence;
	}

	public void setReadSequence(int readSequence) {
		this.readSequence = readSequence;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getToEmailIds() {
		return toEmailIds;
	}

	public void setToEmailIds(String toEmailIds) {
		this.toEmailIds = toEmailIds;
	}

	public String getCcEmailIds() {
		return ccEmailIds;
	}

	public void setCcEmailIds(String ccEmailIds) {
		this.ccEmailIds = ccEmailIds;
	}

	public String getBccEmailIds() {
		return bccEmailIds;
	}

	public void setBccEmailIds(String bccEmailIds) {
		this.bccEmailIds = bccEmailIds;
	}

	public String getSupportBranchId() {
		return supportBranchId;
	}

	public void setSupportBranchId(String supportBranchId) {
		this.supportBranchId = supportBranchId;
	}

	public String getEmailContent() {
		return emailContent;
	}

	public void setEmailContent(String emailContent) {
		this.emailContent = emailContent;
	}

	private String emailContent;

	public String getAlertId() {
		return alertId;
	}

	public void setAlertId(String alertId) {
		this.alertId = alertId;
	}

	public String getEventListId() {
		return eventListId;
	}

	public void setEventListId(String eventListId) {
		this.eventListId = eventListId;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getEmailCategory() {
		return emailCategory;
	}

	public void setEmailCategory(String emailCategory) {
		this.emailCategory = emailCategory;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	
	public Date getDisburseTime() {
		return disburseTime;
	}

	public void setDisburseTime(Date disburseTime) {
		this.disburseTime = disburseTime;
	}

	public String getRefKeyId() {
		return refKeyId;
	}

	public void setRefKeyId(String refKeyId) {
		this.refKeyId = refKeyId;
	}

	public String getEventDeliveryStatus() {
		return eventDeliveryStatus;
	}

	public void setEventDeliveryStatus(String eventDeliveryStatus) {
		this.eventDeliveryStatus = eventDeliveryStatus;
	}

	public String getAttachementCount() {
		return attachementCount;
	}

	public void setAttachementCount(String attachementCount) {
		this.attachementCount = attachementCount;
	}

	public String getRowNo() {
		return rowNo;
	}

	public void setRowNo(String rowNo) {
		this.rowNo = rowNo;
	}

	public String getAttachmentName() {
		return attachmentName;
	}

	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}

	public List<EmailAttachmentVO> getAttachmentContents() {
		return attachmentContents;
	}

	public void setAttachmentContents(List<EmailAttachmentVO> attachmentContents) {
		this.attachmentContents = attachmentContents;
	}
	
	public byte[] getAttachmentData() {
		return attachmentData;
	}

	public void setAttachmentData(byte[] attachmentData) {
		this.attachmentData = attachmentData;
	}

	public String getTotalRecordCount() {
		return totalRecordCount;
	}

	public void setTotalRecordCount(String totalRecordCount) {
		this.totalRecordCount = totalRecordCount;
	}

}
