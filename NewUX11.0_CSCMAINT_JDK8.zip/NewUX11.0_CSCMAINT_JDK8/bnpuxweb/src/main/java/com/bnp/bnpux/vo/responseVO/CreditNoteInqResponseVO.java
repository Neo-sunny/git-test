/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  21 June 2017
 * 
 * Purpose:      Credit Note Inquiry Report Response VO
 * 
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 21 June 2017       Ratna Gokhale, Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/

package com.bnp.bnpux.vo.responseVO;

import java.util.List;

import com.bnp.bnpux.common.vo.CreditNoteInqDetailsVO;
import com.bnp.bnpux.common.vo.CreditNoteInqVO;
import com.bnp.bnpux.common.vo.CreditNoteUtilizationVO;

public class CreditNoteInqResponseVO{

	
	private String errorMessage;
	
	private List<CreditNoteInqVO> creditNoteInqList;
	
	private List<CreditNoteInqDetailsVO> creditNoteInqDetails;
	
	private List<CreditNoteUtilizationVO> creditNoteInqUtilization;
	
	private List<ReportChartResponseVO> reportChartList;
	
	public List<ReportChartResponseVO> getReportChartList() {
		return reportChartList;
	}

	public void setReportChartList(List<ReportChartResponseVO> reportChartList) {
		this.reportChartList = reportChartList;
	}

	public List<CreditNoteUtilizationVO> getCreditNoteInqUtilization() {
		return creditNoteInqUtilization;
	}

	public void setCreditNoteInqUtilization(List<CreditNoteUtilizationVO> creditNoteInqUtilization) {
		this.creditNoteInqUtilization = creditNoteInqUtilization;
	}

	public List<CreditNoteInqDetailsVO> getCreditNoteInqDetails() {
		return creditNoteInqDetails;
	}

	public void setCreditNoteInqDetails(List<CreditNoteInqDetailsVO> creditNoteInqDetails) {
		this.creditNoteInqDetails = creditNoteInqDetails;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public List<CreditNoteInqVO> getCreditNoteInqList() {
		return creditNoteInqList;
	}

	public void setCreditNoteInqList(List<CreditNoteInqVO> creditNoteInqList) {
		this.creditNoteInqList = creditNoteInqList;
	}


}
