/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   15-JUL-2017
 * 
 * Purpose:      SCF Attach Upload Wrapper Service to connect to Common Service
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 15-JUL-2017				Divyashri Subramaniam						Interface Service as intermediate for Common Services
************************************************************************************************************************************************************/
package com.bnp.bnpux.wrappers.service;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;
import com.bnp.bnpux.vo.requestVO.SCFAttachUploadRequestVO;
import com.bnp.scm.services.attachment.vo.SCFAttachmentUploadVO;
import com.bnp.scm.services.common.vo.AttachmentVO;

public interface ISCFAttachFileUploadWrapperService {
	
	public void populateSelectedData(SCFAttachUploadRequestVO scfAttachUploadRequestVO) throws IOException;
	
	public void uploadAttachmentUpload(SCFAttachUploadRequestVO scfAttachUploadRequestVO, MultipartFile file) throws IOException;
	
	public void saveAttachmentUpload(SCFAttachUploadRequestVO scfAttachUploadRequestVO) throws IOException;
	
	public void deleteAttachmentUpload(SCFAttachUploadRequestVO scfAttachUploadRequestVO) throws IOException;
	
	public void undoAttachmentUpload(SCFAttachUploadRequestVO scfAttachUploadRequestVO) throws IOException;
	
	public void closeAttachmentUpload() throws IOException;
	
	public void downloadAttachmentUpload() throws IOException;
	
	public void approveAttachmentUpload(SCFAttachUploadRequestVO scfAttachUploadRequestVO) throws IOException;

	public List<AttachmentVO> getAttachmentList(SCFAttachUploadRequestVO attachmentRequestVO) throws Exception;
	
	public void getInvoiceCredNoteList(SCFAttachUploadRequestVO scfAttachUploadRequestVO) throws IOException;
	
	public void getCredNoteList(SCFAttachUploadRequestVO scfAttachUploadRequestVO) throws IOException;
	
	public void closeAttachmentPopup(SCFAttachUploadRequestVO scfAttachUploadRequestVO) throws Exception;

}
