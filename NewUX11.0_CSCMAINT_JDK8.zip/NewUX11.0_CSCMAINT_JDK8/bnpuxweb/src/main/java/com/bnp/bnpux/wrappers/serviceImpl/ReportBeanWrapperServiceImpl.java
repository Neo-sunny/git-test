package com.bnp.bnpux.wrappers.serviceImpl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.common.vo.ViewScheduledReportListVO;
import com.bnp.bnpux.constants.AttachmentConstants;
import com.bnp.bnpux.constants.ErrorConstants;
import com.bnp.bnpux.constants.ReportsConstant;
import com.bnp.bnpux.service.IViewScheduledReportService;
import com.bnp.bnpux.vo.requestVO.ViewScheduledReportRequestVO;
import com.bnp.bnpux.vo.responseVO.ViewScheduledReportResponseVO;
import com.bnp.bnpux.wrappers.service.ReportBeanWrapperService;
import com.bnp.scm.services.common.exception.BNPApplicationException;

/**
 * Class Name: ReportBeanWrapperServiceImpl Class Description: This class has
 * been imported from old UX. Business logic for View scheduled reports is
 * present in this class.
 */
@Component
@Scope("request")
public class ReportBeanWrapperServiceImpl implements ReportBeanWrapperService {

	/** The log. */
	public final Logger log = LoggerFactory.getLogger(ReportBeanWrapperServiceImpl.class);

	@Autowired
	private IViewScheduledReportService viewScheduledReportService;
	
	private List<ViewScheduledReportListVO> tableDataList = new ArrayList<ViewScheduledReportListVO>();

	/**
	 * This method sets value in data model VO and fetches the view schedule report table
	 * 
	 * @param requestVO
	 * @return ViewScheduledReportResponseVO
	 * @throws BNPApplicationException
	 */
	@Override
	public ViewScheduledReportResponseVO getInitReport(ViewScheduledReportRequestVO viewScheduleRptRequestVO)
			throws BNPApplicationException {
		log.debug("class:ReportBeanWrapperServiceImpl,   method:getInitReport  - Start");
		ViewScheduledReportResponseVO responseVO = new ViewScheduledReportResponseVO();
		String message = null;
		try {
			if (viewScheduleRptRequestVO.getViewType().equalsIgnoreCase("RPT_VIEW_SCHEDULE")) {
				populateScheduleRptTableData(viewScheduleRptRequestVO);
				responseVO.setViewScheduledResponseList(tableDataList);
			}
		} catch (BNPApplicationException e) {
			responseVO.setErrorMessage(e.getMessage());
			log.error("BNPApplicationException in ReportBeanWrapperServiceImpl : " + message);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		log.debug("class:ReportBeanWrapperServiceImpl,   method:getInitReport  - End");
		return responseVO;
	}
	
	/**
	 * Populate the data in schedule report table
	 * 
	 * @param viewScheduleRptRequestVO
	 * @return ViewScheduledReportResponseVO
	 * @throws BNPApplicationException
	 */
	public void populateScheduleRptTableData(ViewScheduledReportRequestVO viewScheduleRptRequestVO) throws BNPApplicationException {
		if (viewScheduleRptRequestVO.getUserTypeId() != null) {
			tableDataList = viewScheduledReportService.getViewScheduleRptDetails(viewScheduleRptRequestVO);
		}
	}
	
	/**
	 * update Last Viewed column
	 * @param viewScheduleRptRequestVO
	 * @throws BNPApplicationException
	 */
	public void updateLastViewed(ViewScheduledReportRequestVO viewScheduleRptRequestVO) throws BNPApplicationException {
		log.debug("class:ReportBeanWrapperServiceImpl,  updateLastViewed  - Start");
		try {
			viewScheduledReportService.updateLastViewed(viewScheduleRptRequestVO);
		} catch (DataAccessException exception) {
			log.error(ReportsConstant.EXCEPTION_UNABLE_TO_PROCES, exception);
			throw new BNPApplicationException(ReportsConstant.EXCEPTION_UNABLE_TO_PROCES);
		}
		log.debug("class:ReportBeanWrapperServiceImpl,  updateLastViewed  - End");
	}

	
	/**
	 * download Zip Attachment
	 * @param selectedFileList
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public ViewScheduledReportResponseVO downloadZipAttachment(List<ViewScheduledReportListVO> selectedFileList)throws BNPApplicationException
	{
		ViewScheduledReportResponseVO viewScheduledReportResponseVO;
		try
		{
			viewScheduledReportResponseVO = downLoadAll(selectedFileList);
		}
		catch (Exception e) {	
			log.error(e.getMessage(),e);
			throw new BNPApplicationException(e.getMessage());
		}
		return viewScheduledReportResponseVO;
	}
	
	/**
	 * This method is for downloading all
	 * 
	 * @param listAttachmentDetails
	 * @return AttachmentResponseVO
	 * @throws BNPApplicationException 
	 * @Description downLoad All Attachment
	 */
	public ViewScheduledReportResponseVO downLoadAll(List<ViewScheduledReportListVO> listAttachmentDetails)throws BNPApplicationException
	{
		ViewScheduledReportResponseVO viewScheduledReportResponseVO = new ViewScheduledReportResponseVO();
		try
		{
			log.debug("Entered downLoadAttachment");
			byte[] readBuff;	
			readBuff = compressFiles(listAttachmentDetails);
			viewScheduledReportResponseVO.setData(readBuff);
			//viewScheduledReportResponseVO.setFileName("ScheduledReports-123"/*AttachmentConstants.SCF_FILE_NAME*/);
		}catch (Exception e) {
			log.error(e.getMessage(),e);
			throw new BNPApplicationException(e.getMessage());
		}
		return viewScheduledReportResponseVO;
	}
	
	/**
	 * This method is for compressing files
	 * 
	 * @param listdownLoadAll
	 * @return byte[]
	 * @throws Exception 
	 * @Description Compress List of Attachment
	 */
	public byte[] compressFiles(List<ViewScheduledReportListVO> listdownLoadAll) 
	throws Exception{

		ByteArrayOutputStream objbyteArrayStream = null;
		ZipOutputStream outputStream = null;
		byte[] objByteoutput = null;
		
		try{
			if(listdownLoadAll!=null && listdownLoadAll.size()>0){
				objbyteArrayStream = new ByteArrayOutputStream();
				outputStream = new ZipOutputStream(objbyteArrayStream);
				for ( int i = 0; i<listdownLoadAll.size();i++)
				{
					ViewScheduledReportListVO objFileVO = listdownLoadAll.get(i);
					
					String fileName = objFileVO.getReportFileName();
					String fileFormat = objFileVO.getReportFormat();
					String lastGenerated = objFileVO.getLastGenerated();
					try{
					outputStream.putNextEntry(new ZipEntry(getFileName(fileName,fileFormat)));
					}catch( java.util.zip.ZipException z){
						if(z.getMessage().contains("duplicate entry")){
							outputStream.putNextEntry(new ZipEntry(getFileNameTimestamp(fileName,fileFormat,lastGenerated)));
						}
					}
					outputStream.write(objFileVO.getReportData());
					outputStream.closeEntry();
					objFileVO = null;
				}
				outputStream.finish();
				outputStream.flush();
				objByteoutput = objbyteArrayStream.toByteArray();

			}
		}
		catch (IOException ioe) {
			String errorMsg = null;
			if(ioe.getMessage().contains("duplicate entry")){
				errorMsg = Integer.toString(ErrorConstants.DUPLICATE_ENTRY);
			}else{
				errorMsg = AttachmentConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL;
			}
			log.error(errorMsg,ioe);
			throw new BNPApplicationException(errorMsg);
		}
		finally
		{
			try{
				if(objbyteArrayStream!=null){
					objbyteArrayStream.close();
				}
				if(outputStream!=null)
				{
				outputStream.finish();
				outputStream.flush();
				outputStream.close();
				}
			}
			catch (IOException ioe) {
				log.error(AttachmentConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL,ioe);
			}
		}
		log.debug(" Exit compressFiles() ::::::::: ");
		return objByteoutput;
	}
	
	/**
	 * @param fileName
	 * @param num
	 * @return String
	 * @Description Get File Name
	 */
	private String getFileName(String fileName, String fileFormat){
		String temp = null;
		StringBuilder fileNameTemp = new StringBuilder(fileName);
		fileNameTemp.append(".").append(fileFormat);
		temp = fileNameTemp.toString();
		return temp;
	}
	private String getFileNameTimestamp(String fileName, String fileFormat, String lastGenerated ){
		String temp = null;
		lastGenerated = lastGenerated.replaceAll("[^a-zA-Z0-9]", "");
		StringBuilder fileNameTemp = new StringBuilder(fileName);
		fileNameTemp.append("_").append(lastGenerated).append(".").append(fileFormat);
		temp = fileNameTemp.toString();
		return temp;
	}
}