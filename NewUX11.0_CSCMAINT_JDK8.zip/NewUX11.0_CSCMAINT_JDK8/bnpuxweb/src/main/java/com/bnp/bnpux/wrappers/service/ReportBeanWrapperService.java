package com.bnp.bnpux.wrappers.service;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.bnp.bnpux.common.vo.ViewScheduledReportListVO;
import com.bnp.bnpux.vo.requestVO.ViewScheduledReportRequestVO;
import com.bnp.bnpux.vo.responseVO.ViewScheduledReportResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface ReportBeanWrapperService {
	/**
	 * This method sets value in data model VO and fetches the view schedule report table
	 * @param requestVO
	 * @return ViewScheduledReportResponseVO
	 * @throws BNPApplicationException
	 */
	ViewScheduledReportResponseVO  getInitReport(ViewScheduledReportRequestVO requestVO) throws BNPApplicationException;
	/**
	 * update Last Viewed column
	 * @param viewScheduleRptRequestVO
	 * @throws BNPApplicationException
	 */
	void updateLastViewed(ViewScheduledReportRequestVO viewScheduleRptRequestVO) throws BNPApplicationException;
	/**
	 * download Zip Attachment
	 * @param selectedFileList
	 * @return
	 * @throws BNPApplicationException
	 */
	ViewScheduledReportResponseVO downloadZipAttachment(List<ViewScheduledReportListVO> selectedFileList)throws BNPApplicationException;
}
