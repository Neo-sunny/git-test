/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Transaction Charge Amount Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.io.Serializable;
import java.math.BigDecimal;

public class TransactionChargeAmtVO implements Serializable{ // Modified for Sonar Fix to make the VO Serializable
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String discRefNumber;
	
	private String chargeCode;
	
	private String chargeDesc;
	
	private String currencycode;
	
	private BigDecimal chargeAmount;
	
	private BigDecimal amountToBeDisc;
	
	private String chargeType;
	
	public String getDiscRefNumber() {
		return discRefNumber;
	}

	public void setDiscRefNumber(String discRefNumber) {
		this.discRefNumber = discRefNumber;
	}

	public String getChargeCode() {
		return chargeCode;
	}

	public void setChargeCode(String chargeCode) {
		this.chargeCode = chargeCode;
	}

	public String getChargeDesc() {
		return chargeDesc;
	}

	public void setChargeDesc(String chargeDesc) {
		this.chargeDesc = chargeDesc;
	}

	public String getCurrencycode() {
		return currencycode;
	}

	public void setCurrencycode(String currencycode) {
		this.currencycode = currencycode;
	}

	public BigDecimal getChargeAmount() {
		return chargeAmount;
	}

	public void setChargeAmount(BigDecimal chargeAmount) {
		this.chargeAmount = chargeAmount;
	}

	public BigDecimal getAmountToBeDisc() {
		return amountToBeDisc;
	}

	public void setAmountToBeDisc(BigDecimal amountToBeDisc) {
		this.amountToBeDisc = amountToBeDisc;
	}

	public String getChargeType() {
		return chargeType;
	}

	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}
	
	/**
	 * Getter methods introduced to send the amounts as
	 * String to avoid amount > 16 digits getting truncated
	 * Added as part of defect Fix CSC-7835
	 */
	
	public String getChargeAmountStr() {
		return (chargeAmount!=null)?chargeAmount.toPlainString():"";
	}
	
	public String getAmountToBeDiscStr() {
		return (amountToBeDisc!=null)?amountToBeDisc.toPlainString():"";
	}

}
