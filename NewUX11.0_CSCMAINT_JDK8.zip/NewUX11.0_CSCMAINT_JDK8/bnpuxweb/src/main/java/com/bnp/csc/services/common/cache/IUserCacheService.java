/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:      Cache Service Interface
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
************************************************************************************************************************************************************/
package com.bnp.csc.services.common.cache;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.bnp.csc.services.common.vo.BranchVO;

public interface IUserCacheService {

	/**
	 * @param userId
	 * @return List<BranchVO>
	 * @Description Service Method for getting Branch List for Org User
	 */
	public List<BranchVO> getBranchListForOrgUser(String userId);
	/**
	 * @param params
	 * @return List<BranchVO>
	 * @Description Service Method for getting Holiday Adjusted Date
	 */
	public Date getHolidayAdjustedDate(Map<String,Object> params);
	/**
	 * @param params 
	 * @Description Service Method for getting Next Business Day
	 */
	public void getNextBusinessDay(Map<String,Object> params);
}
