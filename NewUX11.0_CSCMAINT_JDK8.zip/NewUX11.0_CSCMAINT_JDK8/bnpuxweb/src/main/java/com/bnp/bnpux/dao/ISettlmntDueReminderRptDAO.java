package com.bnp.bnpux.dao;

import java.util.List;

import com.bnp.bnpux.common.vo.SettlmntDueReminderDetailsVO;
import com.bnp.bnpux.common.vo.SettlmntDueReminderVO;
import com.bnp.bnpux.vo.requestVO.SettlmntDueReminderRptRequestVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;

public interface ISettlmntDueReminderRptDAO {
	
	/**
	 * This method is for getting Credit Note Inquiry Report List
	 * 
	 * @param SettlmntDueReminderRptRequestVO
	 * @return SettlmntDueReminderVO List
	 */
	List<SettlmntDueReminderVO> getSettlmntDueReminder(SettlmntDueReminderRptRequestVO settlmntDueReminderRptRequestVO);
	
	/**
	 * This method is for getting Credit Note Inquiry Report List Details
	 * 
	 * @param SettlmntDueReminderRptRequestVO
	 * @return SettlmntDueReminderDetailsVO List
	 */
	List<SettlmntDueReminderDetailsVO> getSettlmntDueReminderDetails(SettlmntDueReminderRptRequestVO settlmntDueReminderRptRequestVO);
	
	/**
	 * This method is for getting Chart Axis
	 * 
	 * @param SettlmntDueReminderRptRequestVO
	 * @return ReportChartResponseVO List
	 */
	List<ReportChartResponseVO> getChartAxis(SettlmntDueReminderRptRequestVO settlmntDueReminderRptRequestVO);

	
}
