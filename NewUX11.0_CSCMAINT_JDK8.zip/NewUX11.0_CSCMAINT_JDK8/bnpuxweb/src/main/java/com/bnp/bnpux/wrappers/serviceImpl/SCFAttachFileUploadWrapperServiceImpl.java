/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   15-JUL-2017
 * 
 * Purpose:      SCF Attach Upload Service Implementation
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 15-JUL-2017				Divyashri Subramaniam						SCF Attach Upload Service Implementation
************************************************************************************************************************************************************/
package com.bnp.bnpux.wrappers.serviceImpl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import com.bnp.bnpux.dao.ISCFAttachUploadDAO;
import com.bnp.bnpux.vo.requestVO.SCFAttachUploadRequestVO;
import com.bnp.bnpux.wrappers.service.ISCFAttachFileUploadWrapperService;
import com.bnp.scm.common.IResourceManager;
import com.bnp.scm.services.attachment.vo.SCFAttachmentUploadVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.cache.ICacheService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.ScreenConstants;
import com.bnp.scm.services.common.vo.AttachmentVO;
import com.bnp.scm.services.discounting.vo.CreditNoteUtilizationVO;
import com.bnp.scm.services.invoice.ISCFAttachmentService;
import com.bnp.scm.services.invoice.vo.InvoicePaymentVO;
import com.bnp.scm.services.invoice.vo.InvoiceVO;

@Component
@Scope("session")
public class SCFAttachFileUploadWrapperServiceImpl implements ISCFAttachFileUploadWrapperService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SCFAttachFileUploadWrapperServiceImpl.class);
	
	@Autowired
	private ISCFAttachmentService attachService;
	
	@Autowired
	private ICacheService cacheService;
	
	@Autowired
	protected IResourceManager resourceManager;
	
	@Autowired
	protected ISCFAttachUploadDAO scfAttachUploadDAO;

	private SCFAttachmentUploadVO selectedData = new SCFAttachmentUploadVO();
	
	private String duplicateCheckFlag;
	
	public SCFAttachmentUploadVO getSelectedData() {
		return selectedData;
	}

	public void setSelectedData(SCFAttachmentUploadVO selectedData) {
		this.selectedData = selectedData;
	}

	public String getDuplicateCheckFlag() {
		return duplicateCheckFlag;
	}

	public void setDuplicateCheckFlag(String duplicateCheckFlag) {
		this.duplicateCheckFlag = duplicateCheckFlag;
	}

	@Override
	public void uploadAttachmentUpload(SCFAttachUploadRequestVO scfAttachUploadRequestVO, MultipartFile file) throws IOException{
		try{
			if(scfAttachUploadRequestVO.getUploadCode().equals(ScreenConstants.PAYMENT_TYPE)){
				onPymtAttachmentUpload(scfAttachUploadRequestVO, file);
			}
			else if(scfAttachUploadRequestVO.getUploadCode().equals(ScreenConstants.CREDIT_TYPE)){
				onCNAttachmentUpload(scfAttachUploadRequestVO, file);
			}
			else if(scfAttachUploadRequestVO.getUploadCode().equals(ScreenConstants.INVOICE_TYPE)){
				onInvoiceAttachmentUpload(scfAttachUploadRequestVO, file);
			}
		}catch(Exception e){
			LOGGER.error("Exception in uploadAttachmentUpload:" + e.getMessage());
		}
	}
	
	@Override
	public void populateSelectedData(SCFAttachUploadRequestVO scfAttachUploadRequestVO) throws IOException{
		List<SCFAttachmentUploadVO> scfAttachmentUploadVOList= scfAttachUploadDAO.getAttachUploadPOData(scfAttachUploadRequestVO);
		if(scfAttachmentUploadVOList != null && scfAttachmentUploadVOList.size() != 0){
			this.selectedData = scfAttachmentUploadVOList.get(0);
		}
		getPaymentDetailsList(this.selectedData);
	}
	
	
	@Override
	public void saveAttachmentUpload(SCFAttachUploadRequestVO scfAttachUploadRequestVO) throws IOException{
		try {
			if(!selectedData.getSaveAttachmentsList().isEmpty() && selectedData.getSaveAttachmentsList()!=null) {
			int count = 0;
			selectedData.setCurrentUserId(scfAttachUploadRequestVO.getUserId());
			if (!attachDualCheck()) {
				attachService.saveApproveRecord(selectedData);
				selectedData.getSaveAttachmentsList().clear();
				scfAttachUploadRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.SAVED_SUCCESSFULLY));
			} else {
				count = attachService.saveRecord(selectedData);
				if(count > 0) {
					selectedData.getSaveAttachmentsList().clear();
					scfAttachUploadRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.SAVED_SUCCESSFULLY));
				} else {
					scfAttachUploadRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.TXN_CONCURRENCY_ERROR));
				}
			}
			selectedData.setRecModified(false);
			}
			else {
				scfAttachUploadRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.NO_CHAGES_TO_SAVE));
			}
		} catch (BNPApplicationException e) {
			LOGGER.error("Exception in saveAttachmentUpload() : " + e.getMessage());
		}
	}
	
	@Override
	public void deleteAttachmentUpload(SCFAttachUploadRequestVO scfAttachUploadRequestVO) throws IOException{
		try {
			AttachmentVO selectedRow = null;
			if(scfAttachUploadRequestVO.getRemoveAttachVO() != null){
				selectedRow = scfAttachUploadRequestVO.getRemoveAttachVO();
				if(selectedRow.getAttSeqNo()!= 0){
					selectedRow.setAttachOper(ScreenConstants.ATTACH_DEL);
					selectedData.getAttachmentVOList().remove(selectedRow);
					if(ScreenConstants.REC_STATUS_APPROVE.equalsIgnoreCase(selectedRow.getCtrlStatus())){
						selectedRow.setCtrlStatus(ScreenConstants.REC_STATUS_DELETE);
						selectedRow.setLastUpdatedBy(scfAttachUploadRequestVO.getUserId());
					}
					selectedData.getSaveAttachmentsList().add(selectedRow);
				}else {
					selectedData.getSaveAttachmentsList().remove(selectedRow);
					selectedData.getAttachmentVOList().remove(selectedRow);
				}
				selectedData.setRecModified(true);
				selectedData.setAttachmentCnt(selectedData.getAttachmentCnt() - 1);
				scfAttachUploadRequestVO.setErrCode(ErrorConstants.DATA_COMMON_DELETE);
			}
		} catch (Exception e) {
			LOGGER.error("Exception in deleteAttachmentUpload() : ", e.getMessage());
			scfAttachUploadRequestVO.setErrCode(ErrorConstants.PROCESSING_ERROR);
		}
	}
	
	@Override
	public void undoAttachmentUpload(SCFAttachUploadRequestVO scfAttachUploadRequestVO) throws IOException{
		try {
			int count = 0;
			List<AttachmentVO> attachmentVOList = null;
			String uploadedBy= null;
			if (selectedData.getAttachmentId() != null) {
				attachmentVOList = attachService.getAttachmentList(selectedData);
				if(attachmentVOList != null && !attachmentVOList.isEmpty()) {
					selectedData.setApproveUndoList(attachmentVOList); 
					uploadedBy = selectedData.getAttachmentVOList().get(0).getLastUpdatedBy();
				if(uploadedBy == null || uploadedBy.equals(scfAttachUploadRequestVO.getUserId())) {
					count = attachService.undoRecord(selectedData);
					if(count > 0){
						scfAttachUploadRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.UNDO_DONE_SUCCESSFULLY));
					} else {
						scfAttachUploadRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.TXN_CONCURRENCY_ERROR));
					}
				} else {
					scfAttachUploadRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.SAME_USER_ERROR));
				}
				}
			}else {
				scfAttachUploadRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.CANNOT_UNDO_APPROVED_RECORD));
			}
		} catch (Exception e) {
			LOGGER.error("BNPApplicationException in undoRecordFromDetail() : "+ e.getMessage());
			scfAttachUploadRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.ERROR_WHILE_SAVING_RECORD));
		} finally {
			try {
				attachService.resetProcessingFlag(selectedData);
			} catch (BNPApplicationException e) {
				LOGGER.error("BNPApplicationException in undoAttachmentUpload() : "+ e.getMessage());
			}
		}
	}
	
	@Override
	public void closeAttachmentUpload() throws IOException{
		
	}
	@Override
	public void downloadAttachmentUpload() throws IOException{
		
	}
	@Override
	public void approveAttachmentUpload(SCFAttachUploadRequestVO scfAttachUploadRequestVO) throws IOException{
		try {
			List<AttachmentVO> attachmentVOList = null;
			int count = 0;
			if (selectedData.getAttachmentId() != null) {
				attachmentVOList = attachService.getAttachmentList(selectedData);
				if (attachmentVOList != null && !attachmentVOList.isEmpty()) {
					selectedData.setApproveUndoList(attachmentVOList); 
					AttachmentVO attachVO = selectedData.getApproveUndoList().get(0);
					String uploadedBy = attachVO.getLastUpdatedBy();
					if (uploadedBy == null || uploadedBy.equals(scfAttachUploadRequestVO.getUserId())) {
						scfAttachUploadRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.MAKER_CANNOT_APPROVE));
					} else {
						count = attachService.approveRecord(selectedData,scfAttachUploadRequestVO.getUserId());
						if (count > 0) {
							scfAttachUploadRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.DATA_COMMON_APPROVE));
						} else {
							scfAttachUploadRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.TXN_CONCURRENCY_ERROR));
						}
					}
				}
			} else {
				scfAttachUploadRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.ALREADY_APPROVED));
			}
		} catch (BNPApplicationException bae) {
			LOGGER.error("BNPApplicationException in approveAttachmentUpload() : "+ bae.getMessage());
		} catch (Exception e) {
			LOGGER.error("BNPApplicationException in approveAttachmentUpload() : "+ e.getMessage());
			scfAttachUploadRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.ERROR_WHILE_SAVING_RECORD));
		}
	}
	
	public void onPymtAttachmentUpload(SCFAttachUploadRequestVO scfAttachUploadRequestVO, MultipartFile file) throws Exception {
		try{
			AttachmentVO pymtAttachmentVO = new AttachmentVO();
			getPaymentDetailsList(selectedData);
			if (selectedData.getAttachmentVOList()== null ||  selectedData.getAttachmentVOList().size() < cacheService.getScfAttachmentMaxFileCount()) {
			pymtAttachmentVO.setTitle(scfAttachUploadRequestVO.getTitle());
			String fileName = file.getOriginalFilename();
			String attDuplicateChk = attachDuplicateCheck(fileName, selectedData.getAttachmentVOList(), selectedData);
			if(!BNPConstants.REJECT_ATTACHMENT.equalsIgnoreCase(attDuplicateChk)) {
			if(isValidScfAttachmentFile(fileName) && validateScfAttachmentFileSize(file)) {
			int index = fileName.lastIndexOf("\\");
			if (index > -1) {
				fileName = fileName.substring((index + 1), fileName.length());
			}
			if(BNPConstants.REPLACE_ATTACHMENT.equalsIgnoreCase(attDuplicateChk)){
				pymtAttachmentVO.setAttReplaceChk(BNPConstants.REPLACE_ATTACHMENT);
			}
			pymtAttachmentVO.setData(file.getBytes());
			pymtAttachmentVO.setUploadedDate(new Date());
			pymtAttachmentVO.setFileName(fileName);
			pymtAttachmentVO.setPaymentId(selectedData.getPaymentId());
			pymtAttachmentVO.setCtrlStatus(selectedData.getCtrlStatus());
			pymtAttachmentVO.setUploadedBy(scfAttachUploadRequestVO.getUserId());
			pymtAttachmentVO.setLastUpdatedBy(scfAttachUploadRequestVO.getUserId());
			pymtAttachmentVO.setBranchName(selectedData.getBranchName());
			pymtAttachmentVO.setSuppOrgId(selectedData.getSupplierOrgId());
			pymtAttachmentVO.setBuyerOrgId(selectedData.getBuyerOrgId());
			pymtAttachmentVO.setPymtRefNo(selectedData.getRefNo());
			pymtAttachmentVO.setPymtRefNoUnq(selectedData.getRefNoUnq());
			pymtAttachmentVO.setOrgId(selectedData.getOrgId());
			pymtAttachmentVO.setSupBranchId(selectedData.getSupBranchId());
			pymtAttachmentVO.setAttType(ScreenConstants.PAYMENT_TYPE);
			pymtAttachmentVO.setAttachOper(ScreenConstants.ATTACH_ADD);
			pymtAttachmentVO.setFileId(selectedData.getFileId());
			if(selectedData.getAttachmentId()!=null){
				pymtAttachmentVO.setAttachmentId(selectedData.getAttachmentId());
			}
			selectedData.getSaveAttachmentsList().add(pymtAttachmentVO);
			selectedData.getAttachmentVOList().add(pymtAttachmentVO);
			if (selectedData.getAttachmentCnt() == null) {
				selectedData.setAttachmentCnt(1);
			}  else {
				selectedData.setAttachmentCnt(selectedData.getAttachmentCnt() + 1);
			}
			selectedData.setRecModified(true);
			List<AttachmentVO> attachmentVOs = new ArrayList<AttachmentVO>();
			attachmentVOs.add(pymtAttachmentVO);
			scfAttachUploadRequestVO.setAttachmentVOList(attachmentVOs);
			} else {
				scfAttachUploadRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.INVALID_ATTACHMENT_SIZE));
			}
			
			} else {
				scfAttachUploadRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.DUPLICATE_ATTACHMENT));
			}
			}
			else{
				scfAttachUploadRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.INVALID_ATTACHMENT_COUNT));
			}
		}catch(BNPApplicationException applicationException){
			LOGGER.error("Exception in uploadAtachment() : " + applicationException.getMessage());
		}
	}
	
	public void onInvoiceAttachmentUpload(SCFAttachUploadRequestVO scfAttachUploadRequestVO, MultipartFile file) throws Exception {
		addInvoiceAttachments(scfAttachUploadRequestVO);
		if (selectedData.getAttachmentVOList()== null ||  selectedData.getAttachmentVOList().size() < cacheService.getScfAttachmentMaxFileCount()) {
			AttachmentVO invAttachmentVO = new AttachmentVO();
			invAttachmentVO.setTitle(scfAttachUploadRequestVO.getTitle());
			String fileName = file.getOriginalFilename();
			String attDuplicateChk = attachDuplicateCheck(fileName, selectedData.getAttachmentVOList(), selectedData);
			if(!BNPConstants.REJECT_ATTACHMENT.equalsIgnoreCase(attDuplicateChk)) {
			if (isValidScfAttachmentFile(fileName) && validateScfAttachmentFileSize(file)) {
				int index = fileName.lastIndexOf("\\");
				if (index > -1) {
					fileName = fileName.substring((index + 1),
							fileName.length());
				}
				if(BNPConstants.REPLACE_ATTACHMENT.equalsIgnoreCase(attDuplicateChk)){
					invAttachmentVO.setAttReplaceChk(BNPConstants.REPLACE_ATTACHMENT);
				}
				invAttachmentVO.setData(file.getBytes());
				invAttachmentVO.setUploadedDate(new Date());
				invAttachmentVO.setFileName(fileName);
				invAttachmentVO.setInvId(scfAttachUploadRequestVO.getInvID());
				invAttachmentVO.setInvRefNo(scfAttachUploadRequestVO.getInvRefNo());
				invAttachmentVO.setPaymentId(selectedData.getPaymentId());
				invAttachmentVO.setCtrlStatus(selectedData.getCtrlStatus());
				invAttachmentVO.setUploadedBy(scfAttachUploadRequestVO.getUserId());
				invAttachmentVO.setLastUpdatedBy(scfAttachUploadRequestVO.getUserId());
				invAttachmentVO.setBranchName(selectedData.getSupBranchId());
				invAttachmentVO.setSupBranchId(selectedData.getSupBranchId());
				invAttachmentVO.setOrgId(selectedData.getOrgId());
				invAttachmentVO.setSuppOrgId(selectedData.getSuppOrgId());
				invAttachmentVO.setBuyerOrgId(selectedData.getBuyerOrgId());
				invAttachmentVO.setPaymentId(selectedData.getPaymentId());
				invAttachmentVO.setPymtRefNo(selectedData.getRefNo());
				invAttachmentVO.setAttType(ScreenConstants.INVOICE_TYPE);
				invAttachmentVO.setAttachOper(ScreenConstants.ATTACH_ADD);
				invAttachmentVO.setFileId(selectedData.getFileId());
				invAttachmentVO.setInvRefNoUnq(scfAttachUploadRequestVO.getInvRefUniqNo());
				invAttachmentVO.setPymtRefNoUnq(selectedData.getRefNoUnq());
				if (selectedData.getAttachmentId() != null) {
					invAttachmentVO.setAttachmentId(selectedData.getAttachmentId());
				}
				selectedData.getSaveAttachmentsList().add(invAttachmentVO);
				selectedData.getAttachmentVOList().add(invAttachmentVO);
				if (selectedData.getAttachmentCnt() == null) {
					selectedData.setAttachmentCnt(1);
				} else {
					selectedData.setAttachmentCnt(selectedData.getAttachmentCnt() + 1);
				}
				List<AttachmentVO> attachmentVOs = new ArrayList<AttachmentVO>();
				attachmentVOs.add(invAttachmentVO);
				scfAttachUploadRequestVO.setAttachmentVOList(attachmentVOs);
				selectedData.setRecModified(true);
			} else{
				scfAttachUploadRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.INVALID_ATTACHMENT_SIZE));
			}
		}else {
			scfAttachUploadRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.DUPLICATE_ATTACHMENT));
		}
		}else {
			scfAttachUploadRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.INVALID_ATTACHMENT_COUNT));
		}
	}
	
	public void onCNAttachmentUpload(SCFAttachUploadRequestVO scfAttachUploadRequestVO, MultipartFile file) throws Exception {
		addCNAttachments(scfAttachUploadRequestVO);
		if (selectedData.getAttachmentVOList()== null ||  selectedData.getAttachmentVOList().size() < cacheService.getScfAttachmentMaxFileCount()) {
		AttachmentVO cnAttachmentVO = new AttachmentVO();
		cnAttachmentVO.setTitle(scfAttachUploadRequestVO.getTitle());
		String fileName = file.getOriginalFilename();
		String attDuplicateChk = attachDuplicateCheck(fileName, selectedData.getAttachmentVOList(), selectedData);
		if(!BNPConstants.REJECT_ATTACHMENT.equalsIgnoreCase(attDuplicateChk)) {
		if(isValidScfAttachmentFile(fileName) && validateScfAttachmentFileSize(file)) {
		int index = fileName.lastIndexOf("\\");
		if (index > -1) {
			fileName = fileName.substring((index + 1), fileName.length());
		}
		if(BNPConstants.REPLACE_ATTACHMENT.equalsIgnoreCase(attDuplicateChk)){
			cnAttachmentVO.setAttReplaceChk(BNPConstants.REPLACE_ATTACHMENT);
		}
		cnAttachmentVO.setData(file.getBytes());
		cnAttachmentVO.setUploadedDate(new Date());
 		cnAttachmentVO.setFileName(fileName);
 		cnAttachmentVO.setInvId(scfAttachUploadRequestVO.getInvID());
 		cnAttachmentVO.setCntId(scfAttachUploadRequestVO.getCredNoID());
 		cnAttachmentVO.setCntRefNo(scfAttachUploadRequestVO.getCnRefNo());
 		cnAttachmentVO.setInvRefNo(scfAttachUploadRequestVO.getInvRefNo());
		cnAttachmentVO.setPaymentId(selectedData.getPaymentId());
		cnAttachmentVO.setCtrlStatus(selectedData.getCtrlStatus());
		cnAttachmentVO.setUploadedBy(scfAttachUploadRequestVO.getUserId());
		cnAttachmentVO.setLastUpdatedBy(scfAttachUploadRequestVO.getUserId());
		cnAttachmentVO.setBranchName(selectedData.getBranchName());
		cnAttachmentVO.setSupBranchId(selectedData.getSupBranchId());
		cnAttachmentVO.setOrgId(selectedData.getOrgId());
		cnAttachmentVO.setSuppOrgId(selectedData.getSupplierOrgId());
		cnAttachmentVO.setBuyerOrgId(selectedData.getBuyerOrgId());
		cnAttachmentVO.setPaymentId(selectedData.getPaymentId());
		cnAttachmentVO.setPymtRefNo(selectedData.getRefNo());
		cnAttachmentVO.setAttType(ScreenConstants.CREDIT_TYPE);
		cnAttachmentVO.setAttachOper(ScreenConstants.ATTACH_ADD);
		cnAttachmentVO.setFileId(selectedData.getFileId());
		cnAttachmentVO.setPymtRefNoUnq(selectedData.getRefNoUnq());
		cnAttachmentVO.setInvRefNoUnq(scfAttachUploadRequestVO.getInvRefUniqNo());
		cnAttachmentVO.setCntRefNoUnq(scfAttachUploadRequestVO.getCnRefUniqNo());
		if(selectedData.getAttachmentId()!=null){
			cnAttachmentVO.setAttachmentId(selectedData.getAttachmentId());
		}
		selectedData.getSaveAttachmentsList().add(cnAttachmentVO);
		selectedData.getAttachmentVOList().add(cnAttachmentVO);
		if(selectedData.getAttachmentCnt() == null){
			selectedData.setAttachmentCnt(1);
		}
		else{
			selectedData.setAttachmentCnt(selectedData.getAttachmentCnt() + 1);
		}	
		List<AttachmentVO> attachmentVOs = new ArrayList<AttachmentVO>();
		attachmentVOs.add(cnAttachmentVO);
		scfAttachUploadRequestVO.setAttachmentVOList(attachmentVOs);
		selectedData.setRecModified(true);
		}else{
			scfAttachUploadRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.INVALID_ATTACHMENT_SIZE));
		}
		}
		else {
			scfAttachUploadRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.DUPLICATE_ATTACHMENT));
		}
		}
		else{
			scfAttachUploadRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.INVALID_ATTACHMENT_COUNT));
		}
	}
	
	public void addInvoiceAttachments(SCFAttachUploadRequestVO scfAttachUploadRequestVO){
		List<AttachmentVO> attachList;
		try {
			attachList = attachService.getInvoiceAttachmentList(scfAttachUploadRequestVO.getInvRefUniqNo(), selectedData.getOrgId(), selectedData.getAttachmentId());
			if((selectedData.getSaveAttachmentsList()!=null && !selectedData.getSaveAttachmentsList().isEmpty())){
				for(AttachmentVO saveVo : selectedData.getSaveAttachmentsList()){
					if((scfAttachUploadRequestVO.getInvID() == saveVo.getInvId()) && ScreenConstants.INVOICE_TYPE.equalsIgnoreCase(saveVo.getAttType())){
						if(ScreenConstants.ATTACH_ADD.equalsIgnoreCase(saveVo.getAttachOper())){
							attachList.add(saveVo);
						}
						else if(ScreenConstants.ATTACH_DEL.equalsIgnoreCase(saveVo.getAttachOper())){
							attachList.remove(saveVo);
						}
					}
				}
			}
			selectedData.setAttachmentVOList(attachList);
		} catch (BNPApplicationException e) {
			LOGGER.error("BNPApplicationException in addInvoiceAttachments:" + e.getMessage());
		}	
	}
	
	public void addCNAttachments(SCFAttachUploadRequestVO scfAttachUploadRequestVO){
		List<AttachmentVO> attachList;
		try {
			attachList = attachService.getCNAttachmentList(scfAttachUploadRequestVO.getCnRefUniqNo(), selectedData.getOrgId(), selectedData.getAttachmentId());
			if((selectedData.getSaveAttachmentsList()!=null && !selectedData.getSaveAttachmentsList().isEmpty())){
				for(AttachmentVO saveVo : selectedData.getSaveAttachmentsList()){
					if((scfAttachUploadRequestVO.getCredNoID() == saveVo.getCntId()) && ScreenConstants.CREDIT_TYPE.equalsIgnoreCase(saveVo.getAttType())){
						if(ScreenConstants.ATTACH_ADD.equalsIgnoreCase(saveVo.getAttachOper())){
							attachList.add(saveVo);
						}
						else if(ScreenConstants.ATTACH_DEL.equalsIgnoreCase(saveVo.getAttachOper())){
							attachList.remove(saveVo);
						}
					}
				}
			}
			selectedData.setAttachmentVOList(attachList);
		} catch (BNPApplicationException e) {
			LOGGER.error("BNPApplicationException in addCNAttachments:" + e.getMessage());
		}	
	}
	
	@Override
	public List<AttachmentVO> getAttachmentList(SCFAttachUploadRequestVO attachmentRequestVO) throws Exception{
		List<AttachmentVO> attachList = new ArrayList<AttachmentVO>();
				if(ScreenConstants.PAYMENT_TYPE.equals(attachmentRequestVO.getType())){
					 		getPaymentDetailsList(this.selectedData);
				}else if (ScreenConstants.INVOICE_TYPE.equals(attachmentRequestVO.getType())){
					getInvoiceDetailsList(attachmentRequestVO);
				}else if(ScreenConstants.CREDIT_TYPE.equals(attachmentRequestVO.getType())){
					getcnDetailsList(attachmentRequestVO);
				}
				attachList =selectedData.getAttachmentVOList();
		return attachList;
	}
	
	public void getPaymentDetailsList(SCFAttachmentUploadVO selectedData){
		List<InvoicePaymentVO> paymentDetailsList;
		List<AttachmentVO> attachList;
		duplicateCheckFlag = null;
		String pymtRefNoUnq = selectedData.getRefNoUnq();
		selectedData.setRecModified(false);
		try{
			duplicateCheckFlag = attachService.getAttachDuplicateFlag(selectedData);
			paymentDetailsList = attachService.getPaymentDetailsList(selectedData);
			attachList = attachService.getPaymentAttachmentList(pymtRefNoUnq,selectedData.getOrgId(), selectedData.getAttachmentId());
			if((selectedData.getSaveAttachmentsList()!=null && !selectedData.getSaveAttachmentsList().isEmpty())){
				for(AttachmentVO saveVo : selectedData.getSaveAttachmentsList()){
					if(selectedData.getPaymentId() == saveVo.getPaymentId() && ScreenConstants.PAYMENT_TYPE.equalsIgnoreCase(saveVo.getAttType())){
						if(ScreenConstants.ATTACH_ADD.equalsIgnoreCase(saveVo.getAttachOper())){
							attachList.add(saveVo);
						}
						else if(ScreenConstants.ATTACH_DEL.equalsIgnoreCase(saveVo.getAttachOper())){
							attachList.remove(saveVo);
						}
					}
				}
			}
			selectedData.setAttachmentVOList(attachList);
		} catch (BNPApplicationException e) {
			LOGGER.error("BNPApplicationException in getInvoiceDetailsList:" + e.getMessage());
		}
	}
	
	public void getInvoiceDetailsList( SCFAttachUploadRequestVO attachResponse){
		String invRefNoUnq = null;
		List<AttachmentVO> attachList;
			try {
				attachList = attachService.getInvoiceAttachmentList(attachResponse.getInvRefUniqNo(), selectedData.getOrgId(), selectedData.getAttachmentId());
				if((selectedData.getSaveAttachmentsList()!=null && !selectedData.getSaveAttachmentsList().isEmpty())){
					for(AttachmentVO saveVo : selectedData.getSaveAttachmentsList()){
						if((attachResponse.getPymtID() == saveVo.getInvId()) && ScreenConstants.INVOICE_TYPE.equalsIgnoreCase(saveVo.getAttType())){
							if(ScreenConstants.ATTACH_ADD.equalsIgnoreCase(saveVo.getAttachOper())){
								attachList.add(saveVo);
							}
							else if(ScreenConstants.ATTACH_DEL.equalsIgnoreCase(saveVo.getAttachOper())){
								attachList.remove(saveVo);
							}
						}
					}
				}
				selectedData.setAttachmentVOList(attachList);
			} catch (BNPApplicationException e) {
				LOGGER.error("BNPApplicationException in getInvoiceDetailsList:" + e.getMessage());
			}	
	}
	
	public void getcnDetailsList( SCFAttachUploadRequestVO attachResponse){
		List<AttachmentVO> attachList;
		try {
			if(attachResponse.getCnRefUniqNo() != null) {
					attachList = attachService.getCNAttachmentList(attachResponse.getCnRefUniqNo(), selectedData.getOrgId(), selectedData.getAttachmentId());
				if((selectedData.getSaveAttachmentsList()!=null && !selectedData.getSaveAttachmentsList().isEmpty())){
					for(AttachmentVO saveVo : selectedData.getSaveAttachmentsList()){
						if((attachResponse.getPymtID() == saveVo.getCntId()) && ScreenConstants.CREDIT_TYPE.equalsIgnoreCase(saveVo.getAttType())){
							if(ScreenConstants.ATTACH_ADD.equalsIgnoreCase(saveVo.getAttachOper())){
								attachList.add(saveVo);
							}
							else if(ScreenConstants.ATTACH_DEL.equalsIgnoreCase(saveVo.getAttachOper())){
								attachList.remove(saveVo);
							}
						}
					}
				}
				selectedData.setAttachmentVOList(attachList);
			} else{
				attachList = null;
				selectedData.setAttachmentVOList(attachList);
			}
		} catch (BNPApplicationException e) {
			LOGGER.error("BNPApplicationException in getcnDetailsList:" + e.getMessage());
		}
	}
	
	public void getInvoiceCredNoteList(SCFAttachUploadRequestVO scfAttachUploadRequestVO){
		List<InvoiceVO> invDetailsList;
		List<CreditNoteUtilizationVO> cnDetailsList;
		try {
			scfAttachUploadRequestVO.setMaxFileCount(cacheService.getScfAttachmentMaxFileCount());
			scfAttachUploadRequestVO.setMaxFileSize(cacheService.getScfAttachmentMaxFileSize());
			scfAttachUploadRequestVO.setCreditNoteList(new ArrayList<CreditNoteUtilizationVO>());
			long paymentId = scfAttachUploadRequestVO.getPymtID();
			invDetailsList = attachService.getInvoiceDetailsList(paymentId);
			if(invDetailsList!=null && !invDetailsList.isEmpty()){
				scfAttachUploadRequestVO.setInvoiceList(invDetailsList);
				for(InvoiceVO invoiceVO : invDetailsList){
					cnDetailsList = attachService.getcnDetailsList(invoiceVO.getInvoiceRefNoUnq(), selectedData.getOrgId());
					for(CreditNoteUtilizationVO crdVo:cnDetailsList){
						crdVo.setInvId(invoiceVO.getInvoiceId());
					}//CSC 7776 
					if(cnDetailsList!=null && !cnDetailsList.isEmpty()){
						scfAttachUploadRequestVO.getCreditNoteList().addAll(cnDetailsList);
					}
				}
			}
		} catch (BNPApplicationException e) {
			LOGGER.error("BNPApplicationException in getcnDetailsList:" + e.getMessage());
		}
	}
	
	public void getCredNoteList(SCFAttachUploadRequestVO scfAttachUploadRequestVO){
		List<CreditNoteUtilizationVO> cnDetailsList;
		try {
			cnDetailsList = attachService.getcnDetailsList(scfAttachUploadRequestVO.getInvRefUniqNo(), selectedData.getOrgId());
			if(cnDetailsList!=null && !cnDetailsList.isEmpty()){
				scfAttachUploadRequestVO.setCreditNoteList(cnDetailsList);
				for(CreditNoteUtilizationVO creditNoteUtilizationVO : cnDetailsList){
					creditNoteUtilizationVO.setInvId(scfAttachUploadRequestVO.getInvID());
				}
			}
		} catch (BNPApplicationException e) {
			LOGGER.error("BNPApplicationException in getcnDetailsList:" + e.getMessage());
		}
	}
	
	public void closeAttachmentPopup(SCFAttachUploadRequestVO scfAttachUploadRequestVO){
		try {
			this.selectedData =  new SCFAttachmentUploadVO();
		} catch (Exception e) {
			LOGGER.error("BNPApplicationException in closeAttachmentPopup:" + e.getMessage());
		}
	}
	
	private String attachDuplicateCheck(String fileName, List<AttachmentVO> attachList, SCFAttachmentUploadVO selectedData) {
		String duplicateChk = null;
		int index = fileName.lastIndexOf("\\");
			if (index > -1) {
				fileName = fileName.substring((index + 1), fileName.length());
			}
			for (AttachmentVO attachVO: attachList) {
				if(attachVO.getFileName().equalsIgnoreCase(fileName)) {
					duplicateChk = duplicateCheckFlag;
					break;
				}
			}
			return duplicateChk;
	}
	
	 public boolean validateScfAttachmentFileSize(MultipartFile file) throws BNPApplicationException {
		 boolean ValidFile;
		 if((file.getSize()/BNPConstants.BYTES_IN_ONE_MB) > cacheService.getScfAttachmentMaxFileSize()){
			 ValidFile = false;
		 } else {
			 ValidFile = true;
		 }
		 return ValidFile;
	 }
	 
	 public boolean isValidScfAttachmentFile(String fileName) throws BNPApplicationException {
		 boolean ValidFile;
		 int index = fileName.lastIndexOf(BNPConstants.FILE_EXT_SEPARATOR);
		 int index1 = fileName.lastIndexOf("\\"); 
		 String fileType = fileName.substring((index + 1), fileName.length());
		 String tempFileName = fileName.substring((index1 + 1),fileName.length());
		 if(BNPConstants.EXE_TYPE.equalsIgnoreCase(fileType)){
			 ValidFile = false;
		 } else{
			 ValidFile = true;
		 }
		 if(ValidFile){
			 if(tempFileName.length() > 100) {
				 ValidFile = false;
			 }
		 }
		 return ValidFile;
	 }
	 
	 private boolean attachDualCheck() {
		String attDualCheck = null;
		Boolean dualCheck = false;
		try {
			attDualCheck = attachService.attachdualctrlCheck(selectedData.getOrgId());
			if(ScreenConstants.Y.equalsIgnoreCase(attDualCheck)){
				dualCheck = true;
			} else{
				dualCheck = false;
			}
		} catch (BNPApplicationException e) {
			LOGGER.error("Exception in attachDualCheck() : " + e.getMessage());
		}
		return dualCheck;
	}
}
