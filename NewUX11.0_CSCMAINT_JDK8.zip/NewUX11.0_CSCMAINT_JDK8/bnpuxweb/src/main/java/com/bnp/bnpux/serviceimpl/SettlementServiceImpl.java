/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas.
 * 
 * Created on:   02 Aug 2016	
 * 
 * Purpose:      Payment Order Service Implementation
 * 
 * Change History: 
 * Date                                    Author                                                                               Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 06 June 2016						   OFSS														 	 Service Implementation 
 * 14-MAR-2017                         Divyashri Subramaniam                                        Changed method getSettlementDetails() for advanced Filter Apply Functionality 
 * *****************************************************************************************************************************************************************/
package com.bnp.bnpux.serviceimpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.common.vo.InProcessAlreadySettCalloutVO;
import com.bnp.bnpux.common.vo.SettlementCreditNoteLineItemVO;
import com.bnp.bnpux.common.vo.SettlementInvoiceDetailsCallOutVO;
import com.bnp.bnpux.common.vo.SettlementListDetailsVO;
import com.bnp.bnpux.common.vo.SettlementListVO;
import com.bnp.bnpux.common.vo.SettlementSummaryVO;
import com.bnp.bnpux.constants.SettlementConstants;
import com.bnp.bnpux.dao.ISettlementDAO;
import com.bnp.bnpux.service.ISettlementService;
import com.bnp.bnpux.vo.requestVO.InProcessAlreadySettDetailsRequestVO;
import com.bnp.bnpux.vo.requestVO.InProcessAmtDetailsRequestVO;
import com.bnp.bnpux.vo.requestVO.SettlementCreditNoteLineItemRequestVO;
import com.bnp.bnpux.vo.requestVO.SettlementInvoiceDetailsRequestVO;
import com.bnp.bnpux.vo.requestVO.SettlementRequestVO;
import com.bnp.bnpux.vo.responseVO.InProcessAlreadySettDetailsResponseVO;
import com.bnp.bnpux.vo.responseVO.SettlementCreditNoteLineItemResponseVO;
import com.bnp.bnpux.vo.responseVO.SettlementInvoiceLineItemResponseVO;
import com.bnp.bnpux.vo.responseVO.SettlementResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@Component
public class SettlementServiceImpl implements ISettlementService{
	
	/**
	 * Logger log for SettlementServiceImpl class
	 */
	public static final Logger log = LoggerFactory.getLogger(SettlementServiceImpl.class);
	
	/**
	 * ISettlementDAO settlemntDAO;
	 */
	@Autowired
	private ISettlementDAO settlementDAO;
	
	/**
	 * This method is for getting Settlement Details
	 * 
	 * @param settlementRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	public SettlementResponseVO getSettlementDetails(SettlementRequestVO settlementRequestVO) throws BNPApplicationException{
		SettlementResponseVO settlementResponseVO = new SettlementResponseVO();
		String errorFlag = null;	
		try{
			if(SettlementConstants.VIEW_TYPE_SETTLEMENT.equalsIgnoreCase(settlementRequestVO.getViewType())
					|| SettlementConstants.VIEW_TYPE_MATURITY.equalsIgnoreCase(settlementRequestVO.getViewType())){
				List<SettlementSummaryVO> settlementSummaryVOList = new ArrayList<SettlementSummaryVO>();
				/*Commented below Hashmap Implementation for code review comments(HashMap to RequestVO  in service layer)*/
				/*Map<String,Object> summaryMap = new HashMap<String, Object>();						
				summaryMap.put(SettlementConstants.SETTLEMENT_ORDER_USER_ID, settlementRequestVO.getUserId());
				summaryMap.put(SettlementConstants.SETTLEMENT_ORDER_USER_TYPE_ID, settlementRequestVO.getUserType());
				summaryMap.put(SettlementConstants.RECORD_FROM,  settlementRequestVO.getRecordFrom());
				summaryMap.put(SettlementConstants.RECORD_TO,  settlementRequestVO.getRecordTo());				
				summaryMap.put(SettlementConstants.GROUP_INT,  settlementRequestVO.getGroupIndicator());
				summaryMap.put(SettlementConstants.DUE_DATE, settlementRequestVO.getMaturityDate());			
				summaryMap.put(SettlementConstants.FILTER_STATUS, settlementRequestVO.getStatusFilter());
				summaryMap.put(SettlementConstants.FILTER_PERIOD, settlementRequestVO.getPeriodFilter());
				if(settlementRequestVO.getBranchFilter()==null || settlementRequestVO.getBranchFilter().trim()==""){
					summaryMap.put(SettlementConstants.FILTER_BRANCH, "null");	
				}else{
					summaryMap.put(SettlementConstants.FILTER_BRANCH, settlementRequestVO.getBranchFilter());
				}
				summaryMap.put(SettlementConstants.QUICK_SEARCH, settlementRequestVO.getQuickSearchText());				
				settlementDAO.getSettlementSummary(summaryMap);
				settlementSummaryVOList = (List<SettlementSummaryVO>) summaryMap.get(SettlementConstants.SETTLEMENT_ORDER_SUMMARY);*/
				if(settlementRequestVO.getBranchFilter()==null || settlementRequestVO.getBranchFilter().trim()==""){
					settlementRequestVO.setBranchFilter(null);	
				}
				if(settlementRequestVO.getAdvancedFilterListVO() != null && !settlementRequestVO.getAdvancedFilterListVO().isEmpty()){
					settlementRequestVO.setQuickSearchText("");
					settlementDAO.getSettlementSummaryWithAdvFilter(settlementRequestVO);
				}else{
					settlementDAO.getSettlementSummary(settlementRequestVO);
				}
				settlementSummaryVOList = (List<SettlementSummaryVO>) settlementRequestVO.getSettlementdetails();
				if(settlementSummaryVOList != null){
					settlementResponseVO.setSettlementSummaryList(settlementSummaryVOList);
				}else{
					errorFlag = (String) settlementRequestVO.getErrorFlag();
					if(errorFlag != null){				
						log.error(SettlementConstants.SETTLEMENT_ORDER_ERROR_DETAILS + errorFlag);
					}
				}			
			}else if(SettlementConstants.VIEW_TYPE_SETTLEMENT_LIST.equalsIgnoreCase(settlementRequestVO.getViewType())){
				List<SettlementListVO> settlementVOList = new ArrayList<SettlementListVO>();
				/*Commented below Hashmap Implementation for code review comments(HashMap to RequestVO  in service layer)*/
				/*Map<String,Object> settlementListMap = new HashMap<String, Object>();
				settlementListMap.put(SettlementConstants.SETTLEMENT_ORDER_USER_ID, settlementRequestVO.getUserId());
				settlementListMap.put(SettlementConstants.SETTLEMENT_ORDER_USER_TYPE_ID, settlementRequestVO.getUserType());
				settlementListMap.put(SettlementConstants.BUYER_ORG_ID, settlementRequestVO.getBuyerOrgId());
				settlementListMap.put(SettlementConstants.SUPPLIER_ORG_ID, settlementRequestVO.getSupplierOrgId());
				settlementListMap.put(SettlementConstants.LEAD_ORG_ID, settlementRequestVO.getLeadOrgId());
				settlementListMap.put(SettlementConstants.CURRENCY_CODE, settlementRequestVO.getCurrencyCode());
				settlementListMap.put(SettlementConstants.DUE_DATE, settlementRequestVO.getMaturityDate());
				settlementListMap.put(SettlementConstants.RECORD_FROM,  settlementRequestVO.getRecordFrom());
				settlementListMap.put(SettlementConstants.RECORD_TO,  settlementRequestVO.getRecordTo());	
				settlementListMap.put(SettlementConstants.FILTER_STATUS, settlementRequestVO.getStatusFilter());
				settlementListMap.put(SettlementConstants.FILTER_PERIOD, settlementRequestVO.getPeriodFilter());
				if(settlementRequestVO.getBranchFilter()==null || settlementRequestVO.getBranchFilter().trim()==""){
					settlementListMap.put(SettlementConstants.FILTER_BRANCH, "null");	
				}else{
					settlementListMap.put(SettlementConstants.FILTER_BRANCH, settlementRequestVO.getBranchFilter());
				}
				settlementListMap.put(SettlementConstants.QUICK_SEARCH, settlementRequestVO.getQuickSearchText());
				settlementDAO.getSettlementList(settlementListMap);
				settlementVOList = (List<SettlementListVO>) settlementListMap.get(SettlementConstants.SETTLEMENT_ORDER_LIST);*/
				if(settlementRequestVO.getBranchFilter()==null || settlementRequestVO.getBranchFilter().trim()==""){
					settlementRequestVO.setBranchFilter(null);	
				}
				if(settlementRequestVO.getAdvancedFilterListVO() != null && !settlementRequestVO.getAdvancedFilterListVO().isEmpty()){
					settlementRequestVO.setQuickSearchText("");
					settlementDAO.getSettlementListWithAdvFilter(settlementRequestVO);
				}else{
					settlementDAO.getSettlementList(settlementRequestVO);
				}
				settlementVOList = (List<SettlementListVO>) settlementRequestVO.getSettlementOrderList();
				if(settlementVOList != null){
					settlementResponseVO.setSettlementListVO(settlementVOList);
				}		
			}else if(SettlementConstants.VIEW_TYPE_SETTLEMENT_LIST_DETAILS.equalsIgnoreCase(settlementRequestVO.getViewType())){
				List<SettlementListDetailsVO> settlementVOListDetails = new ArrayList<SettlementListDetailsVO>();
				/*Commented below Hashmap Implementation for code review comments(HashMap to RequestVO  in service layer)*/
				/*Map<String,Object> settlementDetailsMap = new HashMap<String, Object>();
				settlementDetailsMap.put(SettlementConstants.SETTLEMENT_ORDER_USER_ID, settlementRequestVO.getUserId());	
				settlementDetailsMap.put(SettlementConstants.PAYMENT_UNIQUE_REFERNCE_ID, settlementRequestVO.getPaymentRefNumberUnique());
				settlementDetailsMap.put(SettlementConstants.ORG_ID, settlementRequestVO.getOrgId());
				settlementDAO.getSettlementListDetails(settlementDetailsMap);
				settlementVOListDetails = (List<SettlementListDetailsVO>) settlementDetailsMap.get(SettlementConstants.SETTLEMENT_ORDER_LIST_DETAILS);*/
				settlementDAO.getSettlementListDetails(settlementRequestVO);
				settlementVOListDetails = (List<SettlementListDetailsVO>) settlementRequestVO.getSettlementListDetails();		
				if(settlementVOListDetails != null){
					settlementResponseVO.setSettlementListDetailsVO(settlementVOListDetails);
				}			
			}
		}catch(DataAccessException exception){
			log.error(SettlementConstants.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(SettlementConstants.EXCEPTION_UNABLE_TO_PROCESS);
		}
				
		return settlementResponseVO;			
	}
	
	
	public SettlementResponseVO getAdvancedFilterCount(SettlementRequestVO settlementRequestVO) throws BNPApplicationException{
		SettlementResponseVO settlementResponseVO = new SettlementResponseVO();
		String errorFlag = null;	
		try{
				List<SettlementSummaryVO> settlementVOListDetails = new ArrayList<SettlementSummaryVO>();
				settlementDAO.getAdvFilterIndicatorCount(settlementRequestVO);
				settlementVOListDetails = (List<SettlementSummaryVO>) settlementRequestVO.getSettlementdetails();		
				if(settlementVOListDetails != null){
					settlementResponseVO.setSettlementSummaryList(settlementVOListDetails);
				}			
			}
		catch(DataAccessException exception){
			log.error(SettlementConstants.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(SettlementConstants.EXCEPTION_UNABLE_TO_PROCESS);
		}
				
		return settlementResponseVO;			
	}

//****************	in process callout entry*************************************

	/**
	 * This method is for getting InProcess Amount Details Callout
	 * 
	 * @param inProcessAmtDetailsRequestVO
	 * @return
	 * @throws BNPApplicationException
	 *//*
	 *Commented below method since it is merged with Already Paid amount callout
	@Override
	public AlreadySettledDetailsResponseVO getInProcessAmtDetailsCallout(InProcessAmtDetailsRequestVO inProcessAmtDetailsRequestVO) throws BNPApplicationException {
		
		String errorFlag;
		AlreadySettledDetailsResponseVO inProcessAmtDetailsResponseVO = new AlreadySettledDetailsResponseVO();
		try{
			List<SettlementAlreadySettlemntDetailsCalloutVO> settInProcessAmtDetailsCalloutVOList = new ArrayList<SettlementAlreadySettlemntDetailsCalloutVO>();			
			Map<String,Object> settInProcessDetailsMap = new HashMap<String, Object>();
			
			settInProcessDetailsMap.put(SettlementConstants.SETTLEMENT_ORDER_DISCOUNT_TYPE, inProcessAmtDetailsRequestVO.getDiscType());
			settInProcessDetailsMap.put(SettlementConstants.SETTLEMENT_ORDER_ORD_ID, inProcessAmtDetailsRequestVO.getSettLeadingorgId());
			settInProcessDetailsMap.put(SettlementConstants.SETTLEMENT_ORDER_PAYMENT_REF_UNIQUE, inProcessAmtDetailsRequestVO.getPaymntRefNoUnique());
			settInProcessDetailsMap.put(SettlementConstants.SETTLEMENT_ORDER_ALREADY_SETT_FLG, inProcessAmtDetailsRequestVO.getInProcessFlg());
			
			
			settlementDAO.getInProcessAmtDetailsCallout(settInProcessDetailsMap);			
			settInProcessAmtDetailsCalloutVOList = (List<SettlementAlreadySettlemntDetailsCalloutVO>) settInProcessDetailsMap.get(SettlementConstants.SETTLEMENT_ORDER_POPOVER_DETAILS);
			if(settInProcessAmtDetailsCalloutVOList!=null && settInProcessAmtDetailsCalloutVOList.size()>0){
				inProcessAmtDetailsResponseVO.setSettlementAlreadySettlemntDetailsCalloutVO(settInProcessAmtDetailsCalloutVOList);	
			}else{
				errorFlag = (String) settInProcessDetailsMap.get(SettlementConstants.SETTLEMENT_ORDER_ERROR_MSG);
				inProcessAmtDetailsResponseVO.setError_msg(errorFlag);	
			}		
			inProcessAmtDetailsResponseVO.setSettlementAlreadySettlemntDetailsCalloutVO(settInProcessAmtDetailsCalloutVOList);			
		}catch(DataAccessException exception){
			log.error(SettlementConstants.EXCEPTION_UNABLE_TO_PROCESS_REQUEST,exception);
			throw new BNPApplicationException(SettlementConstants.EXCEPTION_UNABLE_TO_PROCESS_REQUEST);
		}
			return inProcessAmtDetailsResponseVO;
		
		
	}
*/	//****************	in process callout exit*************************************
	
	//****************	already settled callout entry*******************************

	/**
	 * This method is for getting Already Paid Amount Details Callout
	 * 
	 * @param alreadySettledDetailsRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public InProcessAlreadySettDetailsResponseVO getInProcessAlreadySettDetailsCallout(InProcessAlreadySettDetailsRequestVO alreadySettledDetailsRequestVO) throws BNPApplicationException {
	
	
		String errorFlag;
		InProcessAlreadySettDetailsResponseVO alreadySettledDetailsResponseVO = new InProcessAlreadySettDetailsResponseVO();
		try{
			List<InProcessAlreadySettCalloutVO> settlementAlreadySettlemntDetailsCalloutVOList = new ArrayList<InProcessAlreadySettCalloutVO>();			
			Map<String,Object> settAlreadyPaidDetailsMap = new HashMap<String, Object>();
			
			settAlreadyPaidDetailsMap.put(SettlementConstants.SETTLEMENT_ORDER_DISCOUNT_TYPE, alreadySettledDetailsRequestVO.getDiscType());
			settAlreadyPaidDetailsMap.put(SettlementConstants.SETTLEMENT_ORDER_ORD_ID, alreadySettledDetailsRequestVO.getSettLeadorgId());
			settAlreadyPaidDetailsMap.put(SettlementConstants.SETTLEMENT_ORDER_PAYMENT_REF_UNIQUE, alreadySettledDetailsRequestVO.getPaymntRefNoUnique());
			/* Modified below value to differentiate InProcess and Already Paid Settlement Callout*/
			settAlreadyPaidDetailsMap.put(SettlementConstants.SETTLEMENT_ORDER_ALREADY_SETT_FLG, alreadySettledDetailsRequestVO.getCalloutFlag());
			
			if(SettlementConstants.SETTLEMENT_CALLOUT_FLAG_ALREADYSETTLED.equals(alreadySettledDetailsRequestVO.getCalloutFlag())){
				settlementDAO.getAlreadyPaidAmtDetailsCallout(settAlreadyPaidDetailsMap);
			}else if(SettlementConstants.SETTLEMENT_CALLOUT_FLAG_INPROCESS.equals(alreadySettledDetailsRequestVO.getCalloutFlag())){
				settlementDAO.getInProcessAmtDetailsCallout(settAlreadyPaidDetailsMap);
			}	
						
			settlementAlreadySettlemntDetailsCalloutVOList = (List<InProcessAlreadySettCalloutVO>) settAlreadyPaidDetailsMap.get(SettlementConstants.SETTLEMENT_ORDER_POPOVER_DETAILS);
			if(settlementAlreadySettlemntDetailsCalloutVOList!=null && settlementAlreadySettlemntDetailsCalloutVOList.size()>0){
				alreadySettledDetailsResponseVO.setSettlementInprocessAlreadySettlemntDetailsCalloutVO(settlementAlreadySettlemntDetailsCalloutVOList);	
			}else{
				errorFlag = (String) settAlreadyPaidDetailsMap.get(SettlementConstants.SETTLEMENT_ORDER_ERROR_MSG);
				alreadySettledDetailsResponseVO.setError_msg(errorFlag);	
			}		
			alreadySettledDetailsResponseVO.setSettlementInprocessAlreadySettlemntDetailsCalloutVO(settlementAlreadySettlemntDetailsCalloutVOList);			
		}catch(DataAccessException exception){
			log.error(SettlementConstants.EXCEPTION_UNABLE_TO_PROCESS_REQUEST,exception);
			throw new BNPApplicationException(SettlementConstants.EXCEPTION_UNABLE_TO_PROCESS_REQUEST);
		}
			return alreadySettledDetailsResponseVO;
		
		
	}
	//****************************already settled callout exit ******************************

	
	//**************************** credit note line item entry ******************************
	/**
	 * This method is for getting Credit Note Line Item details
	 * 
	 * @param settlementCreditNoteLineItemRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public SettlementCreditNoteLineItemResponseVO getSettlementCreditNoteLineItemdetails(
			SettlementCreditNoteLineItemRequestVO settlementCreditNoteLineItemRequestVO)
			throws BNPApplicationException {
		
		String errorFlag;
		SettlementCreditNoteLineItemResponseVO settlementCreditNoteLineItemResponseVO = new SettlementCreditNoteLineItemResponseVO();
		try{			
			List<SettlementCreditNoteLineItemVO> settlementCreditNoteLineItemVOList = new ArrayList<SettlementCreditNoteLineItemVO>();
			Map<String,Object> creditNoteLineItemMap = new HashMap<String, Object>();
			creditNoteLineItemMap.put(SettlementConstants.SETTLEMENT_ORDER_CREDIT_NOTE_LINE_ITEM_ID, settlementCreditNoteLineItemRequestVO.getCnt_id());
			settlementDAO.getSettlementCreditNoteLineItemdetails(creditNoteLineItemMap);			
			settlementCreditNoteLineItemVOList = (List<SettlementCreditNoteLineItemVO>) creditNoteLineItemMap.get(SettlementConstants.SETTLEMENT_ORDER_CREDIT_NOTE_LINE_ITEM_SUMMARY);
			if(settlementCreditNoteLineItemVOList!=null && settlementCreditNoteLineItemVOList.size()>0){
				settlementCreditNoteLineItemResponseVO.setSettlementCreditNoteLineItemVO(settlementCreditNoteLineItemVOList);	
			}else{
				errorFlag = (String) creditNoteLineItemMap.get(SettlementConstants.SETTLEMENT_ORDER_CREDIT_NOTE_LINE_ITEM_EROR_MSG);
				settlementCreditNoteLineItemResponseVO.setError_msg(errorFlag);	
			}
			settlementCreditNoteLineItemResponseVO.setSettlementCreditNoteLineItemVO(settlementCreditNoteLineItemVOList);			
		}catch(DataAccessException exception){
			log.error(SettlementConstants.EXCEPTION_UNABLE_TO_PROCESS,exception);
			throw new BNPApplicationException(SettlementConstants.EXCEPTION_UNABLE_TO_PROCESS);
		}
			return settlementCreditNoteLineItemResponseVO;		
			
	}
	
	//**************************** credit note line item exit ******************************
	
	
	//**************************** invoice line item entry ******************************
	
	/**
	 * This method is for getting Invoice Details
	 * 
	 * @param settlementInvoiceDetailsRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public SettlementInvoiceLineItemResponseVO getSettlementInvoiceDetails(
			SettlementInvoiceDetailsRequestVO settlementInvoiceDetailsRequestVO) throws BNPApplicationException {
		
		String errorFlag;
		SettlementInvoiceLineItemResponseVO settlementInvoiceLineItemResponseVO = new SettlementInvoiceLineItemResponseVO();
		try{			
			List<SettlementInvoiceDetailsCallOutVO> settlementInvoiceDetailsCallOutVOList = new ArrayList<SettlementInvoiceDetailsCallOutVO>();
			Map<String,Object> invoiceLineItemMap = new HashMap<String, Object>();
			invoiceLineItemMap.put(SettlementConstants.SETTLEMENT_ORDER_INVOICE_DETAILS_CALL_OUT_INV_ID, settlementInvoiceDetailsRequestVO.getInv_id());
			settlementDAO.getSettlementInvoiceDetails(invoiceLineItemMap);			
			settlementInvoiceDetailsCallOutVOList = (List<SettlementInvoiceDetailsCallOutVO>) invoiceLineItemMap.get(SettlementConstants.SETTLEMENT_ORDER_INVOICE_DETAILS_CALL_OUT_SUMMARY);
			if(settlementInvoiceDetailsCallOutVOList!=null && settlementInvoiceDetailsCallOutVOList.size()>0){
				settlementInvoiceLineItemResponseVO.setSettlementInvoiceDetailsCallOutVO(settlementInvoiceDetailsCallOutVOList);	
			}else{
				errorFlag = (String) invoiceLineItemMap.get(SettlementConstants.SETTLEMENT_ORDER_ERROR_MSG);
				settlementInvoiceLineItemResponseVO.setError_msg(errorFlag);	
			}
			settlementInvoiceLineItemResponseVO.setSettlementInvoiceDetailsCallOutVO(settlementInvoiceDetailsCallOutVOList);			
		}catch(DataAccessException exception){
			log.error(SettlementConstants.EXCEPTION_UNABLE_TO_PROCESS,exception);
			throw new BNPApplicationException(SettlementConstants.EXCEPTION_UNABLE_TO_PROCESS);
		}
			return settlementInvoiceLineItemResponseVO;		
	}
	
	//**************************** invoice line item exit******************************

}
	
