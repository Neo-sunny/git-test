/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Already Settlement Details Call out Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;
import java.util.Date;

public class InProcessAlreadySettCalloutVO {

	
	private Date settDate;
	private BigDecimal settAmt;
	private String boDiscountNo;
	private String beneRef;
	
	
	public Date getSettDate() {
		return settDate;
	}
	public void setSettDate(Date settDate) {
		this.settDate = settDate;
	}
	public BigDecimal getSettAmt() {
		return settAmt;
	}
	public void setSettAmt(BigDecimal settAmt) {
		this.settAmt = settAmt;
	}
	public String getBoDiscountNo() {
		return boDiscountNo;
	}
	public void setBoDiscountNo(String boDiscountNo) {
		this.boDiscountNo = boDiscountNo;
	}
	public String getBeneRef() {
		return beneRef;
	}
	public void setBeneRef(String beneRef) {
		this.beneRef = beneRef;
	}
	
	
	public String getSettAmtStr() {
		return (settAmt!=null)?settAmt.toPlainString():"";
	}
	
}







