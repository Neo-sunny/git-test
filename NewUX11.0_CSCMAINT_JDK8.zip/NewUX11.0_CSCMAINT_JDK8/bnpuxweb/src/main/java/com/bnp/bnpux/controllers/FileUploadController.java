/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   25-April-2017
 * 
 * Purpose:      File Upload Controller
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 25-April-2017			Anubha Jain						                  Initial Version
 * 1 MAY 2017            	Bhuvaneswari                                       File Upload 
 * 08-May-2017				Bala Murugan Elangovan							   File Upload - Polling Logic implementation
 ******************************************************************************************************************************************************************/


package com.bnp.bnpux.controllers;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.service.IAuditService;
import com.bnp.bnpux.service.IFileMgmtService;
import com.bnp.bnpux.util.RequestIdentityValidator;
import com.bnp.bnpux.vo.requestVO.AuditRequestVO;
import com.bnp.bnpux.vo.requestVO.FileUploadRequestVO;
import com.bnp.bnpux.vo.responseVO.FileMgmtResponseVO;
import com.bnp.bnpux.vo.responseVO.FileUploadResponseVO;
import com.bnp.bnpux.wrappers.service.IFileUploadWrapperService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.util.ScreenConstants;
import com.bnp.scm.services.filemgmt.vo.FileVO;


@RestController
@RequestMapping("/fileUpldCtrl")
public class FileUploadController {


		/**
		 * Logger for FileUploadController
		 */
		public static final Logger log = LoggerFactory.getLogger(FileUploadController.class);

		
		@Autowired
		RequestIdentityValidator validateRequest;
		
		@Autowired
		private IAuditService auditService;
		
		@Autowired
		private IFileUploadWrapperService fileUploadService;
		
		@Autowired
		private IFileMgmtService fileMgmtService;
			
	/**
		 * This method is for getting the File Management Details
		 * 
		 * @param fileMgmtRequestVO
		 * @return
		 */ @RequestMapping(value = "upldFile.rest", method = RequestMethod.POST, consumes = {"multipart/form-data"})
		    public FileVO onUpload( @RequestPart("data") FileUploadRequestVO fileUpldVO, @RequestPart("file") MultipartFile file,HttpServletRequest request, HttpServletResponse response) {
			 log.debug("In FileUploadController Controller - enters");
		    	FileVO fileObj = new FileVO();
		    	try {
					boolean requestValidatedFlag = validateRequest.validate(fileUpldVO.getUserId(), request.getSession());					
					String sessionId = request.getSession(false).getId();
		    	
						if(requestValidatedFlag){				    									
						
								fileObj = fileUploadService.onUpload(fileUpldVO , file , sessionId);
								
								AuditRequestVO auditVo = new AuditRequestVO();
								auditVo.setUserId(fileUpldVO.getUserId());
								auditVo.setSessionId(sessionId);
								auditVo.setFuncId(ScreenConstants.ACCESS_LOG_FILE_UPLOAD);
								auditVo.setOrgId(fileUpldVO.getSenderOrgId());								
								auditService.insertAuditLog(auditVo);
								
							}else{
							log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
							response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
						}
		    	}catch (IOException exception) {
		    		log.error(exception.getMessage(), exception);
		    	}
				log.debug("In FileUploadController Controller - exits");
		    	return fileObj;
		    }
		 
		 
		    /**
			 * This method is for getting the Updated File upload status 
			 * @param FileUploadRequestVO
			 * @return
			 */
			@RequestMapping(value = "getUpdatedFileUploadStatus.rest", method = RequestMethod.POST)
			public FileUploadResponseVO getUpdatedFileUploadStatus(@RequestBody FileUploadRequestVO fileUpldVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
				FileUploadResponseVO fileUploadResponseVO = new FileUploadResponseVO();
				try {
					boolean requestValidatedFlag = validateRequest.validate(fileUpldVO.getUserId(), httpServletRequest.getSession());
					if (requestValidatedFlag) {		
						fileUploadResponseVO = fileMgmtService.getUpdatedFileUploadStatus(fileUpldVO);
						fileUploadResponseVO.setFileStatusListVO(fileUpldVO.getFileStatusListVO());
					} else {
						log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
						httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
					}
				} catch (BNPApplicationException exception) {
					fileUploadResponseVO.setErrorMsg(exception.getMessage());
					log.error(exception.getMessage(), exception);
				}
				return fileUploadResponseVO;
			}

}
