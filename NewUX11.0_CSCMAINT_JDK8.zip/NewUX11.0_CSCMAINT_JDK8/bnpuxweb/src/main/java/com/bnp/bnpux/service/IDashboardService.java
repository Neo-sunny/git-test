/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   19-Aug-2017
 * 
 * Purpose:      Dashboard Service Interface
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 19-Aug-2017				Divyashri S								To hold the service methods for Dashboard
************************************************************************************************************************************************************/
package com.bnp.bnpux.service;

import com.bnp.bnpux.vo.requestVO.DashPendingActRequestVO;
import com.bnp.bnpux.vo.requestVO.LimitUtilReportRequestVO;
import com.bnp.bnpux.vo.requestVO.LimitUtilReportResponseVO;
import com.bnp.bnpux.vo.requestVO.RequestParamVO;

public interface IDashboardService {
	
	LimitUtilReportResponseVO getPendingActionDetails(DashPendingActRequestVO dashPendingActRequestVO);
	
	String getRequestedParamMapping(RequestParamVO requestParamVO); 
}
