/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Report Interface for Data Access Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.dao;

import java.util.List;
import java.util.Map;

import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;
import com.bnp.bnpux.vo.responseVO.ReportResponseVO;

public interface IReportDAO {
	
	/**
	 * This method is for getting Report Summary
	 * 
	 * @param paramMap
	 * @return
	 */
	List<ReportResponseVO> getReportSummary(Map<String, Object> paramMap);
	
	/**
	 * This method is for getting Repor List
	 * 
	 * @param paramMap
	 * @return
	 */
	List<ReportResponseVO> getReporList(Map<String, Object> paramMap);
	
	/**
	 * This method is for getting Chart Axis
	 * 
	 * @param paramMap
	 * @return
	 */
	List<ReportChartResponseVO> getChartAxis(Map<String, Object> paramMap);
}
