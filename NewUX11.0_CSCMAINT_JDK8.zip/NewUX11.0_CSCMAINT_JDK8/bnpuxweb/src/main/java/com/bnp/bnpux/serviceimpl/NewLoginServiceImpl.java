/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   07 Apr 2016
 * 
 * Purpose:     Login Service Impl
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 11 Apr 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 * 10 Jun 2016                      Oracle Financial Services Software Ltd                                                                 UAT defect 7956
 * 02 Mar 2017                      Purjayar                                                                  UX10.0 S021 - Display icon only on 2FA authentication- Added method getchk2FAUser
 * 14 Dec 2017			  	  		Rameshwar Khedekar							  							  FO 10.0.2- CSC 8692: Existing pin validation, disable certificate logic
 *****************************************************************************************************************************************************************/


package com.bnp.bnpux.serviceimpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnp.bnpux.common.vo.EntitlementVO;
import com.bnp.bnpux.common.vo.OrganizationVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.common.vo.UserVO;
import com.bnp.bnpux.common.vo.WhiteLabelVO;
import com.bnp.bnpux.dao.ILoginDAO;
import com.bnp.bnpux.service.INewLoginService;
import com.bnp.bnpux.vo.requestVO.LoginRequestVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.bnp.scm.services.discounting.IDiscountRequestService;

@Transactional
@Component
public class NewLoginServiceImpl implements INewLoginService{

	@Autowired
	private ILoginDAO loginDAO;
	
	@Autowired
	private IDiscountRequestService discountRequestService;
	
	public static final String CHANGE_CERTIFICATE_PIN_EXCEPTION = "Exception Occured in Change Certificate Pin";
	
	public static final String PARAM_KEY_USER_ID = "userId";
	
	public static final String PARAM_KEY_HASH_KEY = "userCertHashKey";
	
	private static final Logger log = LoggerFactory.getLogger(NewLoginServiceImpl.class);
	
	private static final String PIN_SUCCESS = "pinSuccess";
	
	private static final String RESULT_CODE = "resultCode";
	
	/**
	 * This method is for getting the User login status
	 * 
	 * @param userId
	 * @param sessionId
	 * @return UserVO
	 * @throws BNPApplicationException
	 * @see com.bnp.bnpux.service.INewLoginService#getUserLoginStatus(java.lang.String, java.lang.String)
	 * @Description Get User Login Status
	 */
	public UserVO getUserLoginStatus(String userId, String sessionId) throws BNPApplicationException {		
		Map<String, String> mapValues=new HashMap<String, String>();
		mapValues.put(PARAM_KEY_USER_ID, userId);
		mapValues.put("sessionId", sessionId);
		return loginDAO.getUserLoginStatus(mapValues);
	}
	
	
	/**
	 * This method is for getting the user UX info
	 * 
	 * @param userVO
	 * @return UserInfoVO List
	 * @throws BNPApplicationException
	 * @see com.bnp.bnpux.service.INewLoginService#getUserUXInfo(com.bnp.bnpux.common.vo.UserVO)
	 * @Description Get UserInfo
	 */
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	@Override
	public List<UserInfoVO> getUserUXInfo(UserVO userVO)throws BNPApplicationException  {
		return loginDAO.getUserUXInfo(userVO);
	}
	
	/**
	 * This method is for getting the Org logo
	 * 
	 * @param orgId
	 * @return OrganizationVO
	 * @see com.bnp.bnpux.service.INewLoginService#getOrgLogo(java.lang.String)
	 * @Description Get Organization
	 */
	@Override
	//@Cacheable(cacheName="orgLogoCache")
	public OrganizationVO getOrgLogo(String orgId) {
		return loginDAO.getOrgLogo(orgId);
	}
	
	/**
	 * This method is for getting the White label details
	 * 
	 * @param userId
	 * @return WhiteLabelVO List
	 * @throws BNPApplicationException
	 * @see com.bnp.bnpux.service.INewLoginService#getWhiteLabelDetails(java.lang.String)
	 * @Description get White Label Details for Style
	 */
	@Override
	public List<WhiteLabelVO> getWhiteLabelDetails(String userId) throws BNPApplicationException {	
		return loginDAO.getWhiteLabelDetails(userId);
	}
	
	/**
	 * This method is for getting the time interval
	 * 
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public  String getTimeInterval() throws BNPApplicationException {
		String intervalTime = null;
		List<NameValueVO> interValMap=null;
		interValMap = loginDAO.getTimeInterval();
		if(interValMap.size() > 0){
			intervalTime = interValMap.get(0).getValue();
		}
		return intervalTime;
	}

	/**
	 * This method is for getting the entitlement details
	 * 
	 * @param userId
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public List<EntitlementVO> getEntitlmntDet(String userId) throws BNPApplicationException {
		return loginDAO.getEntitlmntDet(userId);
	}
	
	/**
	 * This method is for updaing the new session details
	 * 
	 * @param userVO
	 * @return
	 */
	@Override
	public UserVO updateNewSessionDetails(UserVO userVO) {			
		loginDAO.updateNewSessionDetails(userVO);
		loginDAO.updateUserHistorySession(userVO);
		return userVO;
	}
	
	/**
	 * This method is for getting the User login status for new ux
	 * 
	 * @param userId
	 * @param sessionId
	 * @param authToken
	 * @return
	 * @throws BNPApplicationException
	 */
	public UserVO getUserLoginStatusForNewUX(String userId, String sessionId, String authToken) throws BNPApplicationException{
		Map<String, String> mapValues=new HashMap<String, String>();
		mapValues.put(PARAM_KEY_USER_ID, userId);
		mapValues.put("newUXSessionId", sessionId);
		mapValues.put("oldUXsessionId", authToken);
		return loginDAO.getUserLoginStatusForNewUX(mapValues);
	}
	
	/**
	 * This method is for getting the scroll info list
	 * 
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public List<NameValueVO> getScrollInfoList() throws BNPApplicationException{
		// TODO Auto-generated method stub
		return loginDAO.getScrollInfoList();
	}
	
	/**
	 * This method is for checking user is counter party
	 * 
	 * @param userId
	 * @return
	 */
	@Override
	public String getIsCounterpartyUser(String userId){
		// TODO Auto-generated method stub
		return loginDAO.getIsCounterpartyUser(userId);
	}
	
	
	/**
	 * This method is for checking user is authorized for 2FA login
	 * 
	 * @param userId
	 * @return String
	 */
	@Override
	public String getchk2FAUser(String userId)throws BNPApplicationException {
		return loginDAO.getchk2FAUser(userId);
	}
	
	/**
	 * This method is to get the session inactive time interval from the DB.
	 * For Bank user , query will fetch it from the PARAM_MASTER table and
	 * org user query will fetch it from the M_ORGANIZATION table.
	 * 
	 * @param userId
	 * @return String
	 */
	@Override
	public String getSessionInactiveInterval(String userId) throws BNPApplicationException {
		return loginDAO.getSessionInactiveInterval(userId);
	}
	
	/**
	 * Added for FO 10.0.2- CSC 8692: FO 10.0.2- CSC 8692: Existing pin validation, disable certificate logic
	 * @param pinInfo 
	 * @return Map
	 */
	@Override
	public String updateCertStatus(Map pinInfo) throws BNPApplicationException {
		String resultCode = null;
		try{
			String pinSuccess="N";
			boolean pinValid=(Boolean) pinInfo.get(PIN_SUCCESS);
			if(pinValid)
				pinSuccess="Y";
			
			pinInfo.remove(PIN_SUCCESS);
			pinInfo.put(PIN_SUCCESS, pinSuccess);
			pinInfo.put(RESULT_CODE, resultCode);
			loginDAO.updateCertStatus(pinInfo);
			if(null != pinInfo.get(RESULT_CODE)) {
				resultCode = (String)pinInfo.get(RESULT_CODE);
			}
			return resultCode;
		}
		catch(DataAccessException dataAccessException){
			log.error("Exception occured in updateCertStatus -->"+dataAccessException.getMessage());
			throw new BNPApplicationException(CHANGE_CERTIFICATE_PIN_EXCEPTION+dataAccessException);
		}
	}
	

	/**
	 * Added for FO 10.0.2- CSC 8692: This method is used to get current serialNo for certificate.
	 * @param userId 
	 * @return String
	 */
	@Override
	public String getSerialNoByUser(String userId) throws BNPApplicationException {
		String serialNo = null;
		try{
			serialNo =	loginDAO.getSerialNoByUser(userId);
			
			return serialNo;
		}catch(DataAccessException dataAccessException){
			log.error(CHANGE_CERTIFICATE_PIN_EXCEPTION+dataAccessException.getMessage());
			throw new BNPApplicationException(CHANGE_CERTIFICATE_PIN_EXCEPTION+dataAccessException);			
		}
		
	}
	
	/**
	 * This method is used to validate uploaded file hashkey with DB hashkey
	 * @param requestVO 
	 * @return
	 */
	@Override
	public boolean isCertificateHashKeyValid(LoginRequestVO requestVO) throws BNPApplicationException {
		int count = 0;
		try{
			Map<String, String> mapValues=new HashMap<String, String>();
			mapValues.put(PARAM_KEY_USER_ID, requestVO.getUserid());
			mapValues.put(PARAM_KEY_HASH_KEY, requestVO.getUserCertHashKey());
			count =	loginDAO.isCertificateHashKeyValid(mapValues);
			if(count == 1){
				return true;
			}
			return false;
		}catch(DataAccessException dataAccessException){
			log.error(CHANGE_CERTIFICATE_PIN_EXCEPTION+dataAccessException.getMessage());
			throw new BNPApplicationException(CHANGE_CERTIFICATE_PIN_EXCEPTION+dataAccessException);			
		}
		
	}

	
	/**
	 * This method is used to update newly generated Certificate hash key
	 * @param requestVO 
	 */
	@Override
	public void updateCertificateHashKey(LoginRequestVO requestVO) throws BNPApplicationException {
		try{
			Map<String, String> mapValues=new HashMap<String, String>();
			mapValues.put(PARAM_KEY_USER_ID, requestVO.getUserid());
			mapValues.put(PARAM_KEY_HASH_KEY, requestVO.getUserCertHashKey());
			loginDAO.updateCertificateHashKey(mapValues);
		}catch(DataAccessException dataAccessException){
			log.error(CHANGE_CERTIFICATE_PIN_EXCEPTION+dataAccessException.getMessage());
			throw new BNPApplicationException(CHANGE_CERTIFICATE_PIN_EXCEPTION+dataAccessException);			
		}
	}
	
	/**
	 * This method is used to get the value for User Certificate Hash Key
	 * @param userId 
	 * @return String
	 */
	@Override
	public String getUserCertHashkey(String userId) throws BNPApplicationException {
		String userCertHashKey = null;
		try{
			userCertHashKey = loginDAO.getUserCertHashkey(userId);
			return userCertHashKey;
			
		}catch(DataAccessException dataAccessException){
			log.error("Exception occured in accessing value -->"+dataAccessException.getMessage());
			throw new BNPApplicationException(CHANGE_CERTIFICATE_PIN_EXCEPTION+dataAccessException);
		}
	}

}
