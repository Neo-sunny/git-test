/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   21 June 2017
 * 
 * Purpose:      Credit Note Inquiry Report Service Implementation
 * 
 * Change History:
 *  
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 21 June 2017       Ratna Gokhale, Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.constants.DiscTransConstants;
import com.bnp.bnpux.constants.ReportsConstant;
import com.bnp.bnpux.dao.IDiscTransReportDAO;
import com.bnp.bnpux.service.IDiscTransReportService;
import com.bnp.bnpux.vo.requestVO.DiscTransRequestVO;
import com.bnp.bnpux.vo.responseVO.DiscTransResponseVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@Component
public class DiscTransServiceImpl implements IDiscTransReportService{

	@Autowired
	private IDiscTransReportDAO reportDAO;
	
	/**
	 * Logger log for DiscTransServiceImpl class
	 */
	private static final Logger log = LoggerFactory.getLogger(DiscTransServiceImpl.class);
	
	/**
	 * Constant for Exception message
	 */
	public static final String EXCEPTION_UNABLE_TO_PROCESS = "Unable to process action - Database Exception";
	
	/**
	 * This service implementation method is used to fetch latest Credit Note Inquiry Report list
	 * 
	 * @param DiscTransRequestVO 
	 * @return DiscTransResponseVO
	 */
	@Override
	public DiscTransResponseVO getReportList(DiscTransRequestVO requestVO) throws BNPApplicationException {
		DiscTransResponseVO responseVO = null; 
		try{
			responseVO = new DiscTransResponseVO();
			
			if(DiscTransConstants.DISC_TRANS_LIST.equalsIgnoreCase(requestVO.getViewType())) {
				reportDAO.getReportList(requestVO);
				if(requestVO.getDiscTransList() != null) {
					responseVO.setDiscTransList(requestVO.getDiscTransList());
				}
			} else if(DiscTransConstants.DISC_TRANS_LIST_DETAILS.equalsIgnoreCase(requestVO.getViewType())) {
				reportDAO.getReportListDetails(requestVO);
				if(requestVO.getDiscTransDetails() != null) {
					responseVO.setDiscTransDetails(requestVO.getDiscTransDetails());
				}
			}  
			
			if(requestVO.getErrorMsg() != null){				
				log.error(EXCEPTION_UNABLE_TO_PROCESS + requestVO.getErrorMsg());
				//throw new BNPApplicationException(EXCEPTION_UNABLE_TO_PROCESS);	
			}
			
			
		} catch(DataAccessException exception) {
			log.error(EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(EXCEPTION_UNABLE_TO_PROCESS);	
		}
		return responseVO;
	}


	/**
	 * This method is for getting Credit Note Inquiry Report details
	 * 
	 * @param DiscTransRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public DiscTransResponseVO getReportDetails(DiscTransRequestVO requestVO)
			throws BNPApplicationException {
		// TODO Auto-generated method stub
		String errorFlag = null;	
		DiscTransResponseVO responseVO = new DiscTransResponseVO();
		try{
			
		}catch(Exception exception){
			log.error(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS);
		}
		return responseVO;
	}
	
	/**
	 * This method is for getting report chart axis 
	 * 
	 * @param requestVo
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public List<ReportChartResponseVO> getReportChartAxis (DiscTransRequestVO requestVO)throws BNPApplicationException {
		List<ReportChartResponseVO> reportVOList = new ArrayList<ReportChartResponseVO>();
		try{
			
		reportDAO.getChartAxis(requestVO);
		reportVOList = (List<ReportChartResponseVO>) requestVO.getReportChartList();
		
		
		/*if(reportVOList != null){
			settlementResponseVO.setSettlementListVO(settlementVOList);
		}*/	
		}catch(Exception exception){
			log.error(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS);
		}
		return reportVOList;
   }


}