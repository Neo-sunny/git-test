/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   29 Mar 2017	
 * 
 * Purpose:       Buyer Acceptance screen
 * 
 * Change History: 
 * Date                       Author                                    Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 29 Mar 2017			      kmanimar					                Initial Version - FO 10.0 - S2098
 * 08 Apr 2017			      srreshmi					                FO 10.0 - S2066-added for attachment popup
************************************************************************************************************************************************************/
package com.bnp.bnpux.serviceimpl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.common.vo.BaAttachmentListVO;
import com.bnp.bnpux.common.vo.BuyerAcceptanceListVO;
import com.bnp.bnpux.common.vo.BuyerAcceptanceSummaryVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.constants.AttachmentConstants;
import com.bnp.bnpux.constants.BuyerAcceptanceConstants;
import com.bnp.bnpux.constants.ErrorConstants;
import com.bnp.bnpux.dao.IBuyerAcceptanceDAO;
import com.bnp.bnpux.service.IBuyerAcceptanceNewUXService;
import com.bnp.bnpux.util.CommonUtil;
import com.bnp.bnpux.vo.errorMessageVO.ErrorMessageVO;
import com.bnp.bnpux.vo.requestVO.BuyerAcceptanceRequestVO;
import com.bnp.bnpux.vo.responseVO.BuyerAcceptanceResponseVO;
import com.bnp.bnpux.wrappers.service.IBuyerAcceptanceWrapperService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.invoice.vo.BuyerAcceptanceVO;

@Component
public class BuyerAcceptanceNewUXServiceImpl implements IBuyerAcceptanceNewUXService{

	/**
	 * Logger log for BuyerAcceptanceServiceImpl class
	 */
	public static final Logger log = LoggerFactory.getLogger(BuyerAcceptanceNewUXServiceImpl.class);
	
	/**
	 * IBuyerAcceptanceDAO buyerAcceptanceDAO;
	 */
	@Autowired
	private IBuyerAcceptanceDAO buyerAcceptanceDAO;
	
	@Autowired
	private IBuyerAcceptanceWrapperService baWrapperService;

	@Autowired
	private CommonUtil commonUtil;
	
	@Override
	public BuyerAcceptanceResponseVO getBuyerAcceptanceDetails(BuyerAcceptanceRequestVO buyerAcceptanceRequestVO)
			throws BNPApplicationException {
		log.debug("Entry into the getBuyerAcceptanceDetails API " + System.currentTimeMillis());
		BuyerAcceptanceResponseVO buyerAcceptanceResponseVO = new BuyerAcceptanceResponseVO();
		String errorFlag = null;	
		try{
			if(null != buyerAcceptanceRequestVO.getGroupIndicator() && buyerAcceptanceRequestVO.getGroupIndicator().equalsIgnoreCase(BuyerAcceptanceConstants.GROUP_INDICATOR_DUE_DATE)){
				buyerAcceptanceRequestVO.setGroupValue(commonUtil.getSimpleFormattedDateString(buyerAcceptanceRequestVO.getDueDate()));
			}			
			if(BuyerAcceptanceConstants.VIEW_TYPE_BUYERACCEPT.equalsIgnoreCase(buyerAcceptanceRequestVO.getViewType())){
				List<BuyerAcceptanceSummaryVO> buyerAcceptanceSummaryVOVOList;
				if(buyerAcceptanceRequestVO.getAdvancedFilterListVO() != null && !buyerAcceptanceRequestVO.getAdvancedFilterListVO().isEmpty()){
					buyerAcceptanceRequestVO.setQuickSearchText("");
					buyerAcceptanceDAO.getBuyerAcceptanceSummaryWithAdvFilter(buyerAcceptanceRequestVO);
				}else{
					buyerAcceptanceDAO.getBuyerAcceptanceSummary(buyerAcceptanceRequestVO);
				}
				
				buyerAcceptanceSummaryVOVOList = buyerAcceptanceRequestVO.getBuyerAcceptanceSummaryVOList();
				if(buyerAcceptanceSummaryVOVOList != null){
					buyerAcceptanceResponseVO.setBuyerAcceptanceSummaryVOList(buyerAcceptanceSummaryVOVOList);
				}else{
					errorFlag = buyerAcceptanceRequestVO.getErrorFlag();
					log.error(BuyerAcceptanceConstants.BUYER_ACCEPTANCE_ERROR_DETAILS + errorFlag);
				}			
			}
			if(BuyerAcceptanceConstants.VIEW_TYPE_BUYERACCEPT_LIST.equalsIgnoreCase(buyerAcceptanceRequestVO.getViewType())){
				List<BuyerAcceptanceListVO> buyerAcceptanceListVOList;
				if(buyerAcceptanceRequestVO.getAdvancedFilterListVO() != null && !buyerAcceptanceRequestVO.getAdvancedFilterListVO().isEmpty()){
					buyerAcceptanceRequestVO.setQuickSearchText("");
					buyerAcceptanceDAO.getBuyerAcceptanceListWithAdvFilter(buyerAcceptanceRequestVO);
				}else{
					buyerAcceptanceDAO.getBuyerAcceptanceList(buyerAcceptanceRequestVO);
				}
				
				buyerAcceptanceListVOList = buyerAcceptanceRequestVO.getBuyerAcceptanceListVOList();
				if(buyerAcceptanceListVOList != null){
					buyerAcceptanceResponseVO.setBuyerAcceptanceListVOList(buyerAcceptanceListVOList);
				}else{
					errorFlag = buyerAcceptanceRequestVO.getErrorFlag();
					log.error(BuyerAcceptanceConstants.BUYER_ACCEPTANCE_ERROR_DETAILS + errorFlag);
				}			
			}
		}catch(DataAccessException exception){			
			log.error(BuyerAcceptanceConstants.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(BuyerAcceptanceConstants.EXCEPTION_UNABLE_TO_PROCESS);
		}
		
		log.debug("Exit into the getBuyerAcceptanceDetails API " + System.currentTimeMillis());
		return buyerAcceptanceResponseVO;	
	}

	
	/**
	 * This method is for getting  the file adv filter count
	 * 
	 * @param buyerAcceptanceRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public BuyerAcceptanceResponseVO getAdvancedFilterCount(BuyerAcceptanceRequestVO buyerAcceptanceRequestVO)
			throws BNPApplicationException {
		log.debug("Entry into the getBuyerAcceptanceDetails API " + System.currentTimeMillis());
		BuyerAcceptanceResponseVO buyerAcceptanceResponseVO = new BuyerAcceptanceResponseVO();
		String errorFlag = null;	
		try{
			
				List<BuyerAcceptanceSummaryVO> buyerAcceptanceSummaryVOList;
				if(buyerAcceptanceRequestVO.getAdvancedFilterListVO() != null && !buyerAcceptanceRequestVO.getAdvancedFilterListVO().isEmpty()){
					buyerAcceptanceDAO.getAdvFilterIndicatorCount(buyerAcceptanceRequestVO);
				}
				buyerAcceptanceSummaryVOList = buyerAcceptanceRequestVO.getBuyerAcceptanceSummaryVOList();
				if(buyerAcceptanceSummaryVOList != null){
					buyerAcceptanceResponseVO.setBuyerAcceptanceSummaryVOList(buyerAcceptanceSummaryVOList);
				}else{
					errorFlag = buyerAcceptanceRequestVO.getErrorFlag();
					log.error(BuyerAcceptanceConstants.BUYER_ACCEPTANCE_ERROR_DETAILS + errorFlag);
				}			
			
		}catch(DataAccessException exception){			
			log.error(BuyerAcceptanceConstants.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(BuyerAcceptanceConstants.EXCEPTION_UNABLE_TO_PROCESS);
		}
		
		log.debug("Exit into the getBuyerAcceptanceDetails API " + System.currentTimeMillis());
		return buyerAcceptanceResponseVO;	
	}
	
	/**
	 * This method is for getting attachment information for the file and Download operations
	 * 
	 * @param buyerAcceptanceRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public BuyerAcceptanceResponseVO getAttachmentList(BuyerAcceptanceRequestVO buyerAcceptanceRequestVO) throws BNPApplicationException {
		BuyerAcceptanceResponseVO buyerAcceptanceResponseVO = new BuyerAcceptanceResponseVO();
		try{			
			buyerAcceptanceDAO.getAttachmentList(buyerAcceptanceRequestVO);			
			buyerAcceptanceResponseVO.setBaAttachmentListVO(buyerAcceptanceRequestVO.getBaAttachmentListVO());	
			if(!BuyerAcceptanceConstants.BA_ATTACHEMENT_DTL.equals(buyerAcceptanceRequestVO.getGetWhat())){
				buyerAcceptanceResponseVO = downLoadAll(buyerAcceptanceRequestVO.getBaAttachmentListVO());
			}
		}catch(DataAccessException exception){
			log.error(BuyerAcceptanceConstants.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(BuyerAcceptanceConstants.EXCEPTION_UNABLE_TO_PROCESS);
		}
		return buyerAcceptanceResponseVO;
	}
	
	/**
	 * This method is for downloading all
	 * 
	 * @param listAttachmentDetails
	 * @return AttachmentResponseVO
	 * @throws BNPApplicationException 
	 * @Description downLoad All Attachment
	 */
	public BuyerAcceptanceResponseVO downLoadAll(List<BaAttachmentListVO> listAttachmentDetails)throws BNPApplicationException
	{
		BuyerAcceptanceResponseVO attachmentresponse = new BuyerAcceptanceResponseVO();
		try
		{
			byte[] readBuff;	
			readBuff =compressFiles(listAttachmentDetails);
			attachmentresponse.setData(readBuff);
			attachmentresponse.setFileName(BuyerAcceptanceConstants.SCF_FILE_NAME);
		}catch (Exception e) {
			log.error(BuyerAcceptanceConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL,e);
			throw new BNPApplicationException(BuyerAcceptanceConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL);
		}
		return attachmentresponse;
	}
	
	/**
	 * This method is for compressing files
	 * 
	 * @param listdownLoadAll
	 * @return byte[]
	 * @throws BNPApplicationException 
	 * @Description Compress List of Attachment
	 */
	public byte[] compressFiles(List<BaAttachmentListVO> listdownLoadAll) 
	throws BNPApplicationException{

		ByteArrayOutputStream objbyteArrayStream = null;
		ZipOutputStream outputStream = null;
		byte[] objByteoutput = null;
		
		try{
			if(!listdownLoadAll.isEmpty()){
				objbyteArrayStream = new ByteArrayOutputStream();
				outputStream = new ZipOutputStream(objbyteArrayStream);
				for ( int i = 0; i<listdownLoadAll.size();i++)
				{
					BaAttachmentListVO objFileVO = listdownLoadAll.get(i);
					String fileName = objFileVO.getFileName();
					outputStream.putNextEntry(new ZipEntry(getFileName(fileName,i)));
					outputStream.write(objFileVO.getData());
					outputStream.closeEntry();
					objFileVO = null;
				}
				outputStream.finish();
				outputStream.flush();
				objByteoutput = objbyteArrayStream.toByteArray();

			}
		}
		catch (IOException ioe) {
			log.error(BuyerAcceptanceConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL,ioe);
			throw new BNPApplicationException(BuyerAcceptanceConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL);
		}
		finally
		{
			try{
				if(objbyteArrayStream!=null){
					objbyteArrayStream.close();
				}
				if(outputStream!=null)
				{
				outputStream.finish();
				outputStream.flush();
				outputStream.close();
				}
			}
			catch (IOException ioe) {
				log.error(AttachmentConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL,ioe);
			}
		}
		return objByteoutput;
	}
	
	/**
	 * @param fileName
	 * @param num
	 * @return String
	 * @Description Get File Name
	 */
	private String getFileName(String fileName, int num){
		StringBuilder fileNameTemp = new StringBuilder(fileName);
		StringBuilder toAppend = new StringBuilder();
		toAppend.append("(").append(num+1).append(")");
		fileNameTemp.insert(fileName.length()-(fileName.length()-fileName.lastIndexOf(".")),toAppend);
		return fileNameTemp.toString();
	}
	
	/**
	 * @param objAttachVO
	 * @return byte[]
	 * @throws BNPApplicationException 
	 * @Description Compress Single File
	 */
	public byte[] compressSingleFile(BaAttachmentListVO objAttachVO)throws BNPApplicationException
	{
		List<BaAttachmentListVO> alSingleFileList;
		alSingleFileList =new ArrayList<BaAttachmentListVO>();
		alSingleFileList.add(objAttachVO);
		return compressFiles(alSingleFileList);
	}

	
	/**
	 * @param actionReqVO,user
	 * @return responseVO
	 * @throws BNPApplicationException 
	 * @Description Compress Single File
	 */
	@Override
	public BuyerAcceptanceResponseVO doBuyerAcceptanceAction(BuyerAcceptanceRequestVO actionReqVO ,UserInfoVO user) throws BNPApplicationException {
		BuyerAcceptanceResponseVO responseVO = new BuyerAcceptanceResponseVO();
		responseVO.setErrMessageVO(new ArrayList<ErrorMessageVO>());
		List<BuyerAcceptanceVO> detailsVOList = buyerAcceptanceDAO.getBuyerAcceptanceVO(actionReqVO);
		if(!detailsVOList.isEmpty()){			
			
			commonUtil.checkEligibleRecordsForBuyerAcceptanceAction(responseVO, actionReqVO.getBuyerAcceptanceListVOList(), detailsVOList, ErrorConstants.BA_RECORD_STATUS_NOT_MATCHING);			
			if(BuyerAcceptanceConstants.ACTION_ACCEPT.equals(actionReqVO.getAction())){
				responseVO = baWrapperService.acceptInvoice(detailsVOList,user,responseVO);
			}else if(BuyerAcceptanceConstants.ACTION_REJECT.equals(actionReqVO.getAction())){
				responseVO = baWrapperService.rejectInvoice(detailsVOList,user,responseVO);
			}else if(BuyerAcceptanceConstants.ACTION_APPROVE.equals(actionReqVO.getAction())){
				responseVO = baWrapperService.approveInvoice(detailsVOList,user,responseVO);
			}else if(BuyerAcceptanceConstants.ACTION_UNDO.equals(actionReqVO.getAction())){
				responseVO = baWrapperService.undoInvoice(detailsVOList,user,responseVO);
			}						
		}
		return responseVO;
	}




	

	
}
