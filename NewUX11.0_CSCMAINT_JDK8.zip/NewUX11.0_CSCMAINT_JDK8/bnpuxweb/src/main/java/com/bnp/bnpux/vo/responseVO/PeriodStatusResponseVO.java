/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:      Period Status Response Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.responseVO;

public class PeriodStatusResponseVO {
	
	@Override
	public String toString() {
		return "PeriodStatusResponseVO [key=" + key + ", name=" + name + ", value=" + value + "]";
	}
	private String key;
	private String name;
	private String value;
	private String flag;
	
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}

}
