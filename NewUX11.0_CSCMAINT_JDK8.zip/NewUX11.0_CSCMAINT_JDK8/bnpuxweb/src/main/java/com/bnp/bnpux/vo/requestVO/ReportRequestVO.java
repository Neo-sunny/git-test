package com.bnp.bnpux.vo.requestVO;

import java.io.Serializable;
import java.util.Date;


public class ReportRequestVO implements Serializable{

	private String userId;

	private String userType;

	private String orgId;
	
	private String counterPtyId;
	
	private String filePeriod;
	
	private Date uploadFromDate;
	
	private Date uploadToDate;
	
	private String currencyCode;

	private String status;
	
	private String fileStatus;
	
	private String getWhat;
	
	private String chartType;
	
	private String errorFlag;
	
	private String filterFileStatus;
	
	private String fileBranch;
	
	private String fileID;
	
	private String viewType;
	
	private String branch;
	
	public String getChartType() {
		return chartType;
	}

	public void setChartType(String chartType) {
		this.chartType = chartType;
	}
	
	public String getViewType() {
		return viewType;
	}

	public void setViewType(String viewType) {
		this.viewType = viewType;
	}

	public String getFileID() {
		return fileID;
	}

	public void setFileID(String fileID) {
		this.fileID = fileID;
	}

	public String getFilterFileStatus() {
		return filterFileStatus;
	}

	public void setFilterFileStatus(String filterFileStatus) {
		this.filterFileStatus = filterFileStatus;
	}

	public String getFileBranch() {
		return fileBranch;
	}

	public void setFileBranch(String fileBranch) {
		this.fileBranch = fileBranch;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public Date getUploadFromDate() {
		return uploadFromDate;
	}

	public void setUploadFromDate(Date uploadFromDate) {
		this.uploadFromDate = uploadFromDate;
	}

	public Date getUploadToDate() {
		return uploadToDate;
	}

	public void setUploadToDate(Date uploadToDate) {
		this.uploadToDate = uploadToDate;
	}

	public String getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	public String getFileStatus() {
		return fileStatus;
	}

	public void setFileStatus(String fileStatus) {
		this.fileStatus = fileStatus;
	}

	public String getFilePeriod() {
		return filePeriod;
	}

	public void setFilePeriod(String filePeriod) {
		this.filePeriod = filePeriod;
	}

	public String getGetWhat() {
		return getWhat;
	}

	public void setGetWhat(String getWhat) {
		this.getWhat = getWhat;
	}

	public String getCounterPtyId() {
		return counterPtyId;
	}

	public void setCounterPtyId(String counterPtyId) {
		this.counterPtyId = counterPtyId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}
	   
	
}
