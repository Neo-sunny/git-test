package com.bnp.bnpux.vo.requestVO;

import java.util.List;
import com.bnp.bnpux.common.vo.DashbrdPendingActionResultVO;

public class DashPendingActRequestVO {

	private String userId;

	private String userType;
	
	private String errMessage;
	
	private String selectedBranch;
	
	private String selectedOrgId;
	
	private String viewType;
	
	private Integer recordFrom;
	
	private Integer recordTo;
	
	private String groupIndicator;
	
	private List<DashbrdPendingActionResultVO> dashPendingActResultVOList;
	
	public String getGroupIndicator() {
		return groupIndicator;
	}

	public void setGroupIndicator(String groupIndicator) {
		this.groupIndicator = groupIndicator;
	}

	public Integer getRecordFrom() {
		return recordFrom;
	}

	public void setRecordFrom(Integer recordFrom) {
		this.recordFrom = recordFrom;
	}

	public Integer getRecordTo() {
		return recordTo;
	}

	public void setRecordTo(Integer recordTo) {
		this.recordTo = recordTo;
	}
	
	public String getViewType() {
		return viewType;
	}

	public void setViewType(String viewType) {
		this.viewType = viewType;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getErrMessage() {
		return errMessage;
	}

	public void setErrMessage(String errMessage) {
		this.errMessage = errMessage;
	}

	public String getSelectedBranch() {
		return selectedBranch;
	}

	public void setSelectedBranch(String selectedBranch) {
		this.selectedBranch = selectedBranch;
	}

	public String getSelectedOrgId() {
		return selectedOrgId;
	}

	public void setSelectedOrgId(String selectedOrgId) {
		this.selectedOrgId = selectedOrgId;
	}

	public List<DashbrdPendingActionResultVO> getDashPendingActResultVOList() {
		return dashPendingActResultVOList;
	}

	public void setDashPendingActResultVOList(List<DashbrdPendingActionResultVO> dashPendingActResultVOList) {
		this.dashPendingActResultVOList = dashPendingActResultVOList;
	}
	
}
