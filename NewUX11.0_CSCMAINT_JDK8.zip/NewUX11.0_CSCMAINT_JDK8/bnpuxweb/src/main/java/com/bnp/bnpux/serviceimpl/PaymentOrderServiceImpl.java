/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas.
 * 
 * Created on:   06 June 2016	
 * 
 * Purpose:      Payment Order Service Implementation
 * 
 * Change History: 
 * Date                                    Author                                                                               Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 06 June 2016						    Bala Murugan Elangovan														 	 Service Implementation 
 * 23-FEB-2017							Divyashri Subramaniam													Added new method getPDFpopupDetails for S001
 * 10 Mar 2017						    Bala Murugan Elangovan													Advanced Filter Apply functionality implementation
 * 01-JAN-2018				            Bala Murugan Elangovan						Added new method validateDiscDateWithHoliday for S101001 as part of FO10.1 Sprint 2 
 * *****************************************************************************************************************************************************************/
package com.bnp.bnpux.serviceimpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.common.vo.PaymentOrderAvailableamtCalloutVO;
import com.bnp.bnpux.common.vo.PaymentOrderCreditNoteLineItemVO;
import com.bnp.bnpux.common.vo.PaymentOrderDetailVO;
import com.bnp.bnpux.common.vo.PaymentOrderInvoiceDetailsCallOutVO;
import com.bnp.bnpux.common.vo.PaymentOrderListDetailsVO;
import com.bnp.bnpux.common.vo.PaymentOrderListVO;
import com.bnp.bnpux.common.vo.PaymentOrderSummaryVO;
import com.bnp.bnpux.common.vo.RecallResponseGridVO;
import com.bnp.bnpux.common.vo.RecallResponseVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.constants.PaymentOrderConstants;
import com.bnp.bnpux.dao.ILoginDAO;
import com.bnp.bnpux.dao.IPaymentOrderDAO;
import com.bnp.bnpux.discounting.service.IRecallInvoicesNexUXService;
import com.bnp.bnpux.service.IPaymentOrderService;
import com.bnp.bnpux.vo.errorMessageVO.ErrorMessageVO;
import com.bnp.bnpux.vo.requestVO.PaymentOrderCreditNoteLineItemRequestVO;
import com.bnp.bnpux.vo.requestVO.PaymentOrderInvoiceDetailsRequestVO;
import com.bnp.bnpux.vo.requestVO.PaymentOrderPopupRequestVO;
import com.bnp.bnpux.vo.requestVO.PaymentOrderRequestVO;
import com.bnp.bnpux.vo.responseVO.PaymentOrderCreditNoteLineItemResponseVO;
import com.bnp.bnpux.vo.responseVO.PaymentOrderInvoiceDetailsResponseVO;
import com.bnp.bnpux.vo.responseVO.PaymentOrderResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.invoice.vo.RecallInvoiceVO;

@Component
public class PaymentOrderServiceImpl implements IPaymentOrderService{
	
	/**
	 * Logger log for PaymentOrderServiceImpl class
	 */
	public static final Logger log = LoggerFactory.getLogger(PaymentOrderServiceImpl.class);
	
	/**
	 * IPaymentOrderDAO paymentOrderDAO;
	 */
	@Autowired
	private IPaymentOrderDAO paymentOrderDAO;
	
	@Autowired
	private ILoginDAO iLoginDAO;
	
	/**
	 * This method is for getting Payment Order Details
	 * 
	 * @param paymentOrderRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public PaymentOrderResponseVO getPaymentOrderDetails(PaymentOrderRequestVO paymentOrderRequestVO) throws BNPApplicationException{
		log.debug("Entry into the getPaymentOrderDetails API " + System.currentTimeMillis());
		PaymentOrderResponseVO paymentOrderResponseVO = new PaymentOrderResponseVO();
		String errorFlag = null;	
		try{
			if(PaymentOrderConstants.VIEW_TYPE_PAYMENT.equalsIgnoreCase(paymentOrderRequestVO.getViewType())
					|| PaymentOrderConstants.VIEW_TYPE_MATURITY.equalsIgnoreCase(paymentOrderRequestVO.getViewType())){
				List<PaymentOrderSummaryVO> paymentOrderSummaryVOList = new ArrayList<PaymentOrderSummaryVO>();
				/*Commented below Hashmap Implementation for code review comments(HashMap to RequestVO  in service layer)*/
				/*Map<String,Object> summaryMap = new HashMap<String, Object>();						
				summaryMap.put(PaymentOrderConstants.PAYMENT_ORDER_USER_ID, paymentOrderRequestVO.getUserId());
				summaryMap.put(PaymentOrderConstants.PAYMENT_ORDER_USER_TYPE_ID, paymentOrderRequestVO.getUserType());
				summaryMap.put(PaymentOrderConstants.RECORD_FROM,  paymentOrderRequestVO.getRecordFrom());
				summaryMap.put(PaymentOrderConstants.RECORD_TO,  paymentOrderRequestVO.getRecordTo());				
				summaryMap.put(PaymentOrderConstants.GROUP_INT,  paymentOrderRequestVO.getGroupIndicator());
				summaryMap.put(PaymentOrderConstants.MATURITY_DATE, paymentOrderRequestVO.getMaturityDate());			
				summaryMap.put(PaymentOrderConstants.DISC_REQ_NO, paymentOrderRequestVO.getDiscRefNo());
				summaryMap.put(PaymentOrderConstants.FILTER_STATUS, paymentOrderRequestVO.getStatusFilter());
				summaryMap.put(PaymentOrderConstants.FILTER_PERIOD, paymentOrderRequestVO.getPeriodFilter());
				if(paymentOrderRequestVO.getBranchFilter()==null || paymentOrderRequestVO.getBranchFilter().trim()==""){
					summaryMap.put(PaymentOrderConstants.FILTER_BRANCH, null);	
				}else{
					summaryMap.put(PaymentOrderConstants.FILTER_BRANCH, paymentOrderRequestVO.getBranchFilter());
				}
				summaryMap.put(PaymentOrderConstants.QUICK_SEARCH, paymentOrderRequestVO.getQuickSearchText());
				paymentOrderDAO.getPaymentOrderSummary(summaryMap);
				paymentOrderSummaryVOList = (List<PaymentOrderSummaryVO>) summaryMap.get(PaymentOrderConstants.PAYMENT_ORDER_SUMMARY);*/				
				if(paymentOrderRequestVO.getBranchFilter()==null || paymentOrderRequestVO.getBranchFilter().trim()==""){
					paymentOrderRequestVO.setBranchFilter(null);	
				}
				if(paymentOrderRequestVO.getAdvancedFilterListVO() != null && !paymentOrderRequestVO.getAdvancedFilterListVO().isEmpty()){
					paymentOrderRequestVO.setQuickSearchText("");
					paymentOrderDAO.getPaymentOrderSummaryWithAdvFilter(paymentOrderRequestVO);
				}else{
					paymentOrderDAO.getPaymentOrderSummary(paymentOrderRequestVO);
				}
				
				paymentOrderSummaryVOList = (List<PaymentOrderSummaryVO>) paymentOrderRequestVO.getPaymentdetails();
				if(paymentOrderSummaryVOList != null){
					paymentOrderResponseVO.setPaymentOrderSummaryList(paymentOrderSummaryVOList);
				}else{
					errorFlag = (String) paymentOrderRequestVO.getErrorFlag();
					if(errorFlag != null){				
						log.error(PaymentOrderConstants.PAYMENT_ORDER_ERROR_DETAILS + errorFlag);
					}
				}			
			}else if(PaymentOrderConstants.VIEW_TYPE_PAYMENT_LIST.equalsIgnoreCase(paymentOrderRequestVO.getViewType())){
				List<PaymentOrderListVO> paymentOrderVOList = new ArrayList<PaymentOrderListVO>();
				/*Commented below Hashmap Implementation for code review comments(HashMap to RequestVO  in service layer)*/
				/*Map<String,Object> poListMap = new HashMap<String, Object>();
				poListMap.put(PaymentOrderConstants.PAYMENT_ORDER_USER_ID, paymentOrderRequestVO.getUserId());
				poListMap.put(PaymentOrderConstants.PAYMENT_ORDER_USER_TYPE_ID, paymentOrderRequestVO.getUserType());
				poListMap.put(PaymentOrderConstants.BUYER_ORG_ID, paymentOrderRequestVO.getBuyerOrgId());
				poListMap.put(PaymentOrderConstants.SUPPLIER_ORG_ID, paymentOrderRequestVO.getSupplierOrgId());
				poListMap.put(PaymentOrderConstants.CURRENCY_CODE, paymentOrderRequestVO.getCurrencyCode());
				poListMap.put(PaymentOrderConstants.MATURITY_DATE, paymentOrderRequestVO.getMaturityDate());
				poListMap.put(PaymentOrderConstants.RECORD_FROM,  paymentOrderRequestVO.getRecordFrom());
				poListMap.put(PaymentOrderConstants.RECORD_TO,  paymentOrderRequestVO.getRecordTo());	
				poListMap.put(PaymentOrderConstants.DISC_REQ_NO, paymentOrderRequestVO.getDiscRefNo());
				poListMap.put(PaymentOrderConstants.FILTER_STATUS, paymentOrderRequestVO.getStatusFilter());
				poListMap.put(PaymentOrderConstants.FILTER_PERIOD, paymentOrderRequestVO.getPeriodFilter());
				if(paymentOrderRequestVO.getBranchFilter()==null || paymentOrderRequestVO.getBranchFilter().trim()==""){
					poListMap.put(PaymentOrderConstants.FILTER_BRANCH, null);	
				}else{
					poListMap.put(PaymentOrderConstants.FILTER_BRANCH, paymentOrderRequestVO.getBranchFilter());
				}
				poListMap.put(PaymentOrderConstants.QUICK_SEARCH, paymentOrderRequestVO.getQuickSearchText());
				paymentOrderDAO.getPaymentOrderList(poListMap);
				paymentOrderVOList = (List<PaymentOrderListVO>) poListMap.get(PaymentOrderConstants.PAYMENT_ORDER_LIST);*/
				if(paymentOrderRequestVO.getBranchFilter()==null || paymentOrderRequestVO.getBranchFilter().trim()==""){
					paymentOrderRequestVO.setBranchFilter(null);	
				}
				if(paymentOrderRequestVO.getAdvancedFilterListVO() != null && !paymentOrderRequestVO.getAdvancedFilterListVO().isEmpty()){
					paymentOrderRequestVO.setQuickSearchText("");
					paymentOrderDAO.getPaymentOrderListWithAdvFilter(paymentOrderRequestVO);
				}else{
					paymentOrderDAO.getPaymentOrderList(paymentOrderRequestVO);
				}
				
				paymentOrderVOList = (List<PaymentOrderListVO>) paymentOrderRequestVO.getPaymentOrderList();
				if(paymentOrderVOList != null){
					paymentOrderResponseVO.setPaymentOrderListVO(paymentOrderVOList);
				}		
			}else if(PaymentOrderConstants.VIEW_TYPE_PAYMENT_LIST_DETAILS.equalsIgnoreCase(paymentOrderRequestVO.getViewType())){
				List<PaymentOrderListDetailsVO> paymentOrderVOListDetails = new ArrayList<PaymentOrderListDetailsVO>();
				/*Commented below Hashmap Implementation for code review comments(HashMap to RequestVO  in service layer)*/
				/*Map<String,Object> poListDetailsMap = new HashMap<String, Object>();
				poListDetailsMap.put(PaymentOrderConstants.PAYMENT_ORDER_USER_ID, paymentOrderRequestVO.getUserId());*/	
//				poListDetailsMap.put(PaymentOrderConstants.BUYER_UNIQUE_REFERNCE_ID, paymentOrderRequestVO.getBuyerRefNumberUnique());
//				poListDetailsMap.put(PaymentOrderConstants.ORG_ID, paymentOrderRequestVO.getOrgId());
				
				/**#RecallDetails S242,S243**/
				/*poListDetailsMap.put(PaymentOrderConstants.PAYMENT_ORDER_PAYMENT_ID, paymentOrderRequestVO.getPymtId());*/
				/**#RecallDetails S242,S243**/
				
				/*paymentOrderDAO.getPaymentOrderListDetails(poListDetailsMap);
				paymentOrderVOListDetails = (List<PaymentOrderListDetailsVO>) poListDetailsMap.get(PaymentOrderConstants.PAYMENT_ORDER_LIST_DETAILS);*/
				paymentOrderDAO.getPaymentOrderListDetails(paymentOrderRequestVO);
				paymentOrderVOListDetails = (List<PaymentOrderListDetailsVO>) paymentOrderRequestVO.getPaymentOrderListDetails();
				if(paymentOrderVOListDetails != null){
					paymentOrderResponseVO.setPaymentOrderListDetailsVO(paymentOrderVOListDetails);
				}			
			}
		}catch(DataAccessException exception){			
			log.error(PaymentOrderConstants.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(PaymentOrderConstants.EXCEPTION_UNABLE_TO_PROCESS);
		}
		
		log.debug("Exit into the getPaymentOrderDetails API " + System.currentTimeMillis());
		return paymentOrderResponseVO;			
	}
	
	/**
	 * This method is for getting Adv filter count details
	 * 
	 * @param PaymentOrderRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public PaymentOrderResponseVO getAdvancedFilterCount(PaymentOrderRequestVO paymentOrderRequestVO) throws BNPApplicationException{
		log.debug("Entry into the getAdvancedFilterCount API " + System.currentTimeMillis());
		PaymentOrderResponseVO paymentOrderResponseVO = new PaymentOrderResponseVO();
		String errorFlag = null;	
		try{
			
				List<PaymentOrderSummaryVO> paymentOrderSummaryVOList = new ArrayList<PaymentOrderSummaryVO>();
							
				if(paymentOrderRequestVO.getBranchFilter()==null || paymentOrderRequestVO.getBranchFilter().trim()==""){
					paymentOrderRequestVO.setBranchFilter(null);	
				}
				if(paymentOrderRequestVO.getAdvancedFilterListVO() != null && !paymentOrderRequestVO.getAdvancedFilterListVO().isEmpty()){
					paymentOrderDAO.getAdvFilterIndicatorCount(paymentOrderRequestVO);
				}
				paymentOrderSummaryVOList = (List<PaymentOrderSummaryVO>) paymentOrderRequestVO.getPaymentdetails();
				if(paymentOrderSummaryVOList != null){
					paymentOrderResponseVO.setPaymentOrderSummaryList(paymentOrderSummaryVOList);
				}else{
					errorFlag = (String) paymentOrderRequestVO.getErrorFlag();
					if(errorFlag != null){				
						log.error(PaymentOrderConstants.PAYMENT_ORDER_ERROR_DETAILS + errorFlag);
					}
				}			
			
		}catch(DataAccessException exception){			
			log.error(PaymentOrderConstants.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(PaymentOrderConstants.EXCEPTION_UNABLE_TO_PROCESS);
		}
		
		log.debug("Exit into the getAdvancedFilterCount API " + System.currentTimeMillis());
		return paymentOrderResponseVO;			
	}
	
	/**
	 * This method is for getting Credit Note Line Item details
	 * 
	 * @param paymentOrderCreditNoteLineItemRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public PaymentOrderCreditNoteLineItemResponseVO getPaymentOrderCreditNoteLineItemdetails(PaymentOrderCreditNoteLineItemRequestVO paymentOrderCreditNoteLineItemRequestVO) throws BNPApplicationException{
		String errorFlag;
		PaymentOrderCreditNoteLineItemResponseVO paymentOrderCreditNoteLineItemResponseVO = new PaymentOrderCreditNoteLineItemResponseVO();
		try{			
			List<PaymentOrderCreditNoteLineItemVO> paymentOrderCreditNoteLineItemVOList = new ArrayList<PaymentOrderCreditNoteLineItemVO>();
			Map<String,Object> creditNoteLineItemMap = new HashMap<String, Object>();
			creditNoteLineItemMap.put(PaymentOrderConstants.PAYMENT_ORDER_CREDIT_NOTE_LINE_ITEM_ID, paymentOrderCreditNoteLineItemRequestVO.getCnt_id());
			paymentOrderDAO.getPaymentOrderCreditNoteLineItemdetails(creditNoteLineItemMap);			
			paymentOrderCreditNoteLineItemVOList = (List<PaymentOrderCreditNoteLineItemVO>) creditNoteLineItemMap.get(PaymentOrderConstants.PAYMENT_ORDER_CREDIT_NOTE_LINE_ITEM_SUMMARY);
			if(paymentOrderCreditNoteLineItemVOList!=null && paymentOrderCreditNoteLineItemVOList.size()>0){
				paymentOrderCreditNoteLineItemResponseVO.setPaymentOrderCreditNoteLineItemVO(paymentOrderCreditNoteLineItemVOList);	
			}else{
				errorFlag = (String) creditNoteLineItemMap.get(PaymentOrderConstants.PAYMENT_ORDER_CREDIT_NOTE_LINE_ITEM_EROR_MSG);
				paymentOrderCreditNoteLineItemResponseVO.setError_msg(errorFlag);	
			}
			paymentOrderCreditNoteLineItemResponseVO.setPaymentOrderCreditNoteLineItemVO(paymentOrderCreditNoteLineItemVOList);			
		}catch(DataAccessException exception){
			log.error(PaymentOrderConstants.EXCEPTION_UNABLE_TO_PROCESS,exception);
			throw new BNPApplicationException(PaymentOrderConstants.EXCEPTION_UNABLE_TO_PROCESS);
		}
			return paymentOrderCreditNoteLineItemResponseVO;		
	}
	
	/**
	 * This method is for getting Invoice Details Callout
	 * 
	 * @param paymentOrderInvoiceDetailsRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public
	PaymentOrderInvoiceDetailsResponseVO getPaymentOrderInvoiceDetailsCallout(PaymentOrderInvoiceDetailsRequestVO paymentOrderInvoiceDetailsRequestVO) throws BNPApplicationException{
		String errorFlag;
		PaymentOrderInvoiceDetailsResponseVO paymentOrderInvoiceDetailsResponseVO = new PaymentOrderInvoiceDetailsResponseVO();
		try{
			List<PaymentOrderInvoiceDetailsCallOutVO> paymentOrderInvoiceDetailsCallOutVOList = new ArrayList<PaymentOrderInvoiceDetailsCallOutVO>();			
			Map<String,Object> paymentOrderInvoiceDetailsMap = new HashMap<String, Object>();
			paymentOrderInvoiceDetailsMap.put(PaymentOrderConstants.PAYMENT_ORDER_INVOICE_DETAILS_CALL_OUT_INV_ID, paymentOrderInvoiceDetailsRequestVO.getInv_id());
			paymentOrderDAO.getPaymentOrderInvoiceDetailsCallout(paymentOrderInvoiceDetailsMap);			
			paymentOrderInvoiceDetailsCallOutVOList = (List<PaymentOrderInvoiceDetailsCallOutVO>) paymentOrderInvoiceDetailsMap.get(PaymentOrderConstants.PAYMENT_ORDER_INVOICE_DETAILS_CALL_OUT_SUMMARY);
			if(paymentOrderInvoiceDetailsCallOutVOList!=null && paymentOrderInvoiceDetailsCallOutVOList.size()>0){
				paymentOrderInvoiceDetailsResponseVO.setPaymentOrderInvoiceDetailsCallOutVO(paymentOrderInvoiceDetailsCallOutVOList);	
			}else{
				errorFlag = (String) paymentOrderInvoiceDetailsMap.get(PaymentOrderConstants.PAYMENT_ORDER_ERROR_MSG);
				paymentOrderInvoiceDetailsResponseVO.setError_msg(errorFlag);	
			}		
			paymentOrderInvoiceDetailsResponseVO.setPaymentOrderInvoiceDetailsCallOutVO(paymentOrderInvoiceDetailsCallOutVOList);			
		}catch(DataAccessException exception){
			log.error(PaymentOrderConstants.EXCEPTION_UNABLE_TO_PROCESS,exception);
			throw new BNPApplicationException(PaymentOrderConstants.EXCEPTION_UNABLE_TO_PROCESS);
		}
			return paymentOrderInvoiceDetailsResponseVO;
	}

	/**
	 * This method is for getting Available Amount Callout Details
	 * 
	 * @param paymentOrderAvailableamtCalloutVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public PaymentOrderAvailableamtCalloutVO getPaymentOrderAvailableAmtCalloutDetals(
		PaymentOrderAvailableamtCalloutVO paymentOrderAvailableamtCalloutVO) throws BNPApplicationException {
		paymentOrderDAO.getPaymentOrderAvailableAmtCalloutDetals(paymentOrderAvailableamtCalloutVO);	
		return paymentOrderAvailableamtCalloutVO;
	}
	
	// Added For User Stories - Recall - Starts
	
	/**
	 * IPaymentOrderDAO paymentOrderDAO;
	 */
	@Autowired
	private IRecallInvoicesNexUXService recallInvoicesNexUXService;	
	
	
	/**
	 * This method is for recall Payment Order Details 
	 * 
	 * @param paymentOrderListVO
	 * @param user
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public RecallResponseVO recallPaymentOrderDetails(List<PaymentOrderListVO> paymentOrderListtVO, UserInfoVO user) throws BNPApplicationException{
		List<RecallInvoiceVO> recallVOList = paymentOrderDAO.getRecallPaymentOrdersVO(paymentOrderListtVO);
		RecallResponseVO recallResponseVO = null;
		try {
			if(recallVOList!=null && !recallVOList.isEmpty()){
				recallResponseVO = recallInvoicesNexUXService.recallfromNewUX(recallVOList, user);
			}
			recallResponseVO = CheckEligibleRecordsForRecall(recallResponseVO, paymentOrderListtVO, recallVOList, "Please select the valid record for Recall");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.error(e.getMessage(),e);
		}
		return recallResponseVO;
	}
	
	/**
	 * This method is for approving Recall Payment Order Details 
	 * 
	 * @param paymentOrderListtVO
	 * @param user
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public RecallResponseVO approveRecallPaymentOrderDetails(List<PaymentOrderListVO> paymentOrderListtVO, UserInfoVO user) throws BNPApplicationException{
		List<RecallInvoiceVO> recallVOList = paymentOrderDAO.getRecallPaymentOrdersVO(paymentOrderListtVO);
		RecallResponseVO recallResponseVO = null;
		try {
			if(recallVOList!=null && !recallVOList.isEmpty()){
				recallResponseVO = recallInvoicesNexUXService.approvefromNewUX(recallVOList, user);
			}
			recallResponseVO = CheckEligibleRecordsForRecall(recallResponseVO, paymentOrderListtVO, recallVOList, "Please select the valid record for Recall Approval");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.error(e.getMessage(),e);
		}
		return recallResponseVO;
	}
	
	/**
	 * This method is for undo Recall Payment Order Details 
	 * 
	 * @param paymentOrderListtVO
	 * @param user
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public RecallResponseVO undoRecallPaymentOrderDetails(List<PaymentOrderListVO> paymentOrderListtVO, UserInfoVO user) throws BNPApplicationException{
		List<RecallInvoiceVO> recallVOList = paymentOrderDAO.getRecallPaymentOrdersVO(paymentOrderListtVO);
		RecallResponseVO recallResponseVO = null;
		try {
			if(recallVOList!=null && !recallVOList.isEmpty()){
				recallResponseVO = recallInvoicesNexUXService.undofromNewUX(recallVOList, user);
			}
			recallResponseVO = CheckEligibleRecordsForRecall(recallResponseVO, paymentOrderListtVO, recallVOList, "Please select the valid record for Recall Undo");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.error(e.getMessage(),e);
		}
		return recallResponseVO;
	}
	

	/**
	 * @param recallResponseVO
	 * @param paymentOrderListtVO1
	 * @param recallVOList1
	 * @param infoMessage
	 * @return RecallResponseVO
	 * @throws BNPApplicationException 
	 * @Description RecallResponseVO CheckEligibleRecordsForRecall;
	 * method to implement error data for the records not eligible for Recall
	 */
	private RecallResponseVO CheckEligibleRecordsForRecall(RecallResponseVO  recallResponseVO, List<PaymentOrderListVO> paymentOrderListtVO1, List<RecallInvoiceVO> recallVOList1, String infoMessage) throws BNPApplicationException{
		int diffcnt = 0;
		List<RecallResponseGridVO>  recallResGridListVO  = null;
		List<ErrorMessageVO> errMessageVOList = null;
		if(recallResponseVO!=null && recallResponseVO.getRecallResponseGridVO()!=null){
			recallResGridListVO = recallResponseVO.getRecallResponseGridVO();
		}else{
			recallResGridListVO  = new ArrayList<RecallResponseGridVO>();
		}
		if(recallResponseVO!=null && recallResponseVO.geterrMessageVO()!=null){
			errMessageVOList = recallResponseVO.geterrMessageVO();
		}else{
			errMessageVOList = new ArrayList<ErrorMessageVO>();
		}
		if(paymentOrderListtVO1!=null && recallVOList1!=null ){
			// Difference count to form the Error message
			diffcnt = paymentOrderListtVO1.size() - recallVOList1.size();
		}else if(paymentOrderListtVO1!=null && recallVOList1==null){
			// Difference count when the RecallVO conversion returns null
			diffcnt = paymentOrderListtVO1.size();
		}
		if(diffcnt>0){
			for(PaymentOrderListVO paymentOrderVO :paymentOrderListtVO1 ){
				//comparing the pymtId in RecallVO conversion list and forming the error message for the Ids that  are returned in Query i.e. Not eligible 
				int diffcnt1=0;
				boolean isAvailable = false;
				if(recallVOList1!=null){
					for(RecallInvoiceVO recallInvVo : recallVOList1){
						if(paymentOrderVO.getPymtId().equalsIgnoreCase(recallInvVo.getPymtId())){
							isAvailable = true;
							break;
							//breaks when the finds the match in list. This is to avoid unnecessary looping
						}						
					}
					
				}
				if(!isAvailable){
					diffcnt1++;	
					recallResGridListVO.add(addRecallResponseGridMessages(paymentOrderVO.getBuyerRefNo(), infoMessage,true));
					errMessageVOList.add(addActionPopupRecallMessages(paymentOrderVO.getBuyerRefNo(), infoMessage,true));
				}
				if(diffcnt==diffcnt1){
					if(recallResponseVO==null){
						recallResponseVO = new RecallResponseVO();
					}
					recallResponseVO.setRecallResponseGridVO(recallResGridListVO);
					recallResponseVO.seterrMessageVO(errMessageVOList);
					break;
					//breaks when all the unavailable Ids are found. This is to avoid unnecessary looping
				}
			}
		}
		return recallResponseVO;
	}
	
	/**
	 * @param paymntRefNumber
	 * @param message
	 * @param isError
	 * @return RecallResponseGridVO
	 * @Description Add Recall Responses Grid
	 */
	private RecallResponseGridVO addRecallResponseGridMessages(String paymntRefNumber, String message,boolean isError){
		 RecallResponseGridVO objRecallResponseGridVO = new RecallResponseGridVO();
		 objRecallResponseGridVO.setPaymntRefNumber(paymntRefNumber);
		 objRecallResponseGridVO.setMessage(message);
		 objRecallResponseGridVO.setError(isError);
		 return objRecallResponseGridVO;
		
	}
	
	/**
	 * @param uniqueID
	 * @param message
	 * @param error
	 * @return ErrorMessageVO
	 * @Description Add Action Pop-up Recall Messages
	 */
	private ErrorMessageVO addActionPopupRecallMessages(String uniqueID, String message, boolean error){
		 ErrorMessageVO objErrorMessageVO  = new ErrorMessageVO();
	     objErrorMessageVO.setUniqueID(uniqueID);
	     objErrorMessageVO.setMessage(message);
	     objErrorMessageVO.setError(error);
	     return objErrorMessageVO;
		
	}
	
	// Added For User Stories - Recall - Ends
	
	/**
	 * This method is for Payment Order Popup details - S001
	 * 
	 * @param PaymentOrderPopupRequestVO
	 * @return void
	 * @throws BNPApplicationException
	 */
	@Override
	public void getPDFpopupDetails(PaymentOrderPopupRequestVO paymentOrderPopupRequestVO) throws BNPApplicationException{
		List<PaymentOrderDetailVO> paymentOrderDetailVOs;
		String errorFlag;
		try {
			paymentOrderDAO.getPDFpopupDetails(paymentOrderPopupRequestVO);
			paymentOrderDetailVOs = paymentOrderPopupRequestVO.getPaymentOrderDetailVOs();
			if(paymentOrderDetailVOs == null || paymentOrderDetailVOs.isEmpty()){
				errorFlag = paymentOrderPopupRequestVO.getErrorFlag();
				if(errorFlag != null){				
					log.error(PaymentOrderConstants.PAYMENT_ORDER_UNABLE_TO_GET_DETAILS + errorFlag);
				}
			}
			else{
				paymentOrderPopupRequestVO.setBuyerOrgVO(iLoginDAO.getOrgLogo(paymentOrderPopupRequestVO.getBuyerOrgId()));
				paymentOrderPopupRequestVO.setSellerOrgVO(iLoginDAO.getOrgLogo(paymentOrderPopupRequestVO.getSellerOrgId()));
			}
		} catch (DataAccessException dataAccessException) {
			log.error(dataAccessException.getMessage(),dataAccessException);
		}
	}
	
	@Override
	public int getPendAppovalCntService(String pmtId) throws BNPApplicationException{
		int cnt = 0;
		try{
			cnt = paymentOrderDAO.getPendAppovalCnt(pmtId);
		}catch (DataAccessException dataAccessException) {
			log.error(dataAccessException.getMessage(),dataAccessException);
			throw new BNPApplicationException(PaymentOrderConstants.EXCEPTION_UNABLE_TO_PROCESS);
		}
		return cnt;
	}

	/**
	 * Method is used to validate discount date with corresponding holidays
	 * @param paymentOrderRequestVO
	 * @return isHoliday
	 */
	@Override
	public boolean validateDiscDateWithHoliday(PaymentOrderRequestVO paymentOrderRequestVO)	throws BNPApplicationException {
		boolean isHoliday = false;
		try{
			List<PaymentOrderResponseVO> paymentOrderResponseVO = paymentOrderDAO.checkCurrencyHolidayEnabled(paymentOrderRequestVO);
			if(!paymentOrderResponseVO.isEmpty() && paymentOrderResponseVO.get(0) != null){				
				paymentOrderRequestVO.setIgnCcyHoliday(paymentOrderResponseVO.get(0).getHolidayCheckFlag());
				paymentOrderRequestVO.setBranchId(paymentOrderResponseVO.get(0).getBranchId());
			}
			paymentOrderDAO.validateDiscDateWithHoliday(paymentOrderRequestVO);
			if(paymentOrderRequestVO.getNextDate() != null && paymentOrderRequestVO.getDiscountDate() != null && (paymentOrderRequestVO.getNextDate().compareTo(paymentOrderRequestVO.getModifiedDiscDate()) !=0 )){
				isHoliday = true;			
			}			
		}catch(DataAccessException dataAccessException){
			log.error(dataAccessException.getMessage(),dataAccessException);
			throw new BNPApplicationException(PaymentOrderConstants.EXCEPTION_UNABLE_TO_PROCESS);
		}
		return isHoliday;
	}	
	
}
