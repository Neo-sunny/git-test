/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  21 June 2017
 * 
 * Purpose:      Credit Note Inquiry Report Interface for Data Access Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 21 June 2017       Ratna Gokhale, Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.dao;

import java.util.List;

import com.bnp.bnpux.vo.requestVO.AgingRequestVO;

public interface IAgingReportDAO {
	

	/**
	 * This method is for getting Credit Note Inquiry Report List
	 * 
	 * @param CreditNoteInqRequestVO
	 * @return CreditNoteInqResponseVO List
	 */
	List<AgingRequestVO>  getReportList(AgingRequestVO agingReqVO);

	/**
	 * @param agingReqVO
	 */
	List<AgingRequestVO>  getReportSummary(AgingRequestVO agingReqVO);

	/**
	 * @param agingReqVO
	 */
	List<AgingRequestVO>  getReportListDetails(AgingRequestVO agingReqVO);
	
	
}
