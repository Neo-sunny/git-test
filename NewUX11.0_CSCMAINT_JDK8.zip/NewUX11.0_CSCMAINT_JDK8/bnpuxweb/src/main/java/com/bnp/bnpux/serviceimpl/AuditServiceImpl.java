/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   24 May 2016
 * 
 * Purpose:     Audit Service Impl
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 24 May 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 
 *****************************************************************************************************************************************************************/


package com.bnp.bnpux.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.dao.IAuditDAO;
import com.bnp.bnpux.service.IAuditService;
import com.bnp.bnpux.vo.requestVO.AuditRequestVO;

@Component
public class AuditServiceImpl implements IAuditService{
	
	@Autowired
	private IAuditDAO auditDao;
	
	/**
	 * This method is for inserting audit log
	 * 
	 * @param auditVo
	 * @see com.bnp.bnpux.service.IAuditService#insertAuditLog(com.bnp.bnpux.vo.requestVO.AuditRequestVO)
	 * @Description insert Audit Log
	 */
	@Override
	public void insertAuditLog(AuditRequestVO auditVo) {
		auditDao.insertAuditLog(auditVo);
	}
	
}
