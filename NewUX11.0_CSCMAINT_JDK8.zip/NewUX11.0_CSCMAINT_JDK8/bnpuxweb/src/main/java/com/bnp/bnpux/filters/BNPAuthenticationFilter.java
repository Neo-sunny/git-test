/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Servlet Request Filters
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 03Nov2017				  Sathishkumar B									CSC-8568 CentricIssue to set SSO timeout for SSO login
************************************************************************************************************************************************************/
package com.bnp.bnpux.filters;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.Date;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.common.vo.UserVO;
import com.bnp.bnpux.common.vo.WhiteLabelVO;
import com.bnp.bnpux.service.INewLoginService;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@Component("bnpAuthenticationFilter")
public class BNPAuthenticationFilter implements javax.servlet.Filter {
	public static final String UserID = "USER_AUTH_USERID";
	public static final String JSESSION = "USER_AUTH_TOKEN";
	public static final String SSO_TIMEOUT = "18000"; // Added for CSC-8568
	@Autowired
	private INewLoginService loginService;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(BNPAuthenticationFilter.class);
	
	/*
	 * This method for filter the HTTPServletRequest
	 *  (non-Javadoc)
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response,
		FilterChain filter) throws IOException, ServletException {	
		HttpServletResponse httpServletResponse = (HttpServletResponse) response;
		HttpServletRequest httpServletRequest = (HttpServletRequest) request;
		if (request instanceof HttpServletRequest) {			
			String userID = request.getParameter("USER_ID");
			String sessionID = request.getParameter("USER_AUTH_TOKEN");
			String isSSOLogin = request.getParameter("IS_SSO_LOGIN"); // Added for CSC-8568
			UserVO userVO=null;
			UserVO validateSession = null;
			if(httpServletRequest.getRequestURI().contains("/index.jsp")){
				
				HttpSession sessionCheck = ((HttpServletRequest) request).getSession(false);
								
				try {
					userVO = loginService.getUserLoginStatus(userID,sessionID);
					UUID uuid = UUID.randomUUID();
					if(userVO != null){
						/* Modified for  CSC-8568 */
						String inactiveIntervalTime;
						if("Y".equals(isSSOLogin)){
							inactiveIntervalTime = SSO_TIMEOUT;
						}else{
							inactiveIntervalTime = loginService.getSessionInactiveInterval(userID);
						}
						/* Modified for  CSC-8568 */
						boolean isRequestParameterValid = validateRequestParameter(httpServletRequest,inactiveIntervalTime);
						if(!isRequestParameterValid){
							LOGGER.warn(" WARNING : Request Parameter Validation Failed ");
							httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
							return;
						}
						if(userVO.getSessionId() != null && userVO.getSessionId().equals(sessionID)){
							
							if(sessionCheck == null)
							{
								LOGGER.warn("Inside index.jsp Session is null and creating new session");
								//((HttpServletRequest) request).getSession(false).invalidate();
								HttpSession newSession = httpServletRequest.getSession(true);
								
								LOGGER.warn("Inside index.jsp Session is null and creating new session...2");
								newSession.setAttribute("USER_ID",userVO.getUserId());
								newSession.setAttribute("USER_AUTH_TOKEN",sessionID);
								newSession.setAttribute("CSRF_SESSION_TOKEN", uuid);
								List<WhiteLabelVO> whiteLabelList = new ArrayList<WhiteLabelVO>();
								LOGGER.warn("Inside index.jsp Session is null and creating new session...3");
								whiteLabelList = loginService.getWhiteLabelDetails(userVO.getUserId());
								request.setAttribute("SESSION_WHITELABELLIST", whiteLabelList);
								String intervalTime = loginService.getTimeInterval();
								newSession.setAttribute("TIME_INTERVAL", intervalTime);
								userVO.setNewUXSessionId(newSession.getId());
								loginService.updateNewSessionDetails(userVO);
								LOGGER.warn("Inside index.jsp Session is null and creating new session...4");
								filter.doFilter(request, response);
								
							}
							else
							{
								LOGGER.warn("Inside index.jsp Session is not null and not creating new session");
								
								String userIdSession = (String) sessionCheck.getAttribute("USER_ID");
								String authToken = (String) sessionCheck.getAttribute("USER_AUTH_TOKEN");
								if(!sessionID.equals(authToken) || (sessionID.equals(authToken) && userVO.getNewUXSessionId() == null))
								{
									LOGGER.warn("Old Session are not equal and hence destroying session and creating new session");
									sessionCheck.invalidate();
									HttpSession newSession = httpServletRequest.getSession(true);
									LOGGER.warn("Inside Old Session are not equal...2");
									newSession.setAttribute("USER_ID",userVO.getUserId());
									newSession.setAttribute("USER_AUTH_TOKEN",sessionID);
									newSession.setAttribute("CSRF_SESSION_TOKEN", uuid);
									List<WhiteLabelVO> whiteLabelList = new ArrayList<WhiteLabelVO>();
									LOGGER.warn("Inside Old Session are not equal...3");
									whiteLabelList = loginService.getWhiteLabelDetails(userVO.getUserId());
									request.setAttribute("SESSION_WHITELABELLIST", whiteLabelList);
									String intervalTime = loginService.getTimeInterval();
									newSession.setAttribute("TIME_INTERVAL", intervalTime);
									userVO.setNewUXSessionId(newSession.getId());
									loginService.updateNewSessionDetails(userVO);
									
									LOGGER.warn("Inside Old Session are not equal...4");
									filter.doFilter(request, response);
								}
								else
								{
									validateSession = loginService.getUserLoginStatusForNewUX(userIdSession,sessionCheck.getId(), authToken);
									LOGGER.warn("Inside index.jsp validateSession:");
									if (validateSession == null) {
										httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
										return;
									} else {
										filter.doFilter(request, response);
									}
								}
							}
						}else{
							httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
						}
					}
				} catch (BNPApplicationException e) {
					LOGGER.error(e.getMessage(),e);
				}				
			} else if (httpServletRequest.getRequestURI().contains(".rest")) {
				/*
				 * code added to check weather old ux session id is available or
				 * not JIRA issue
				 */
				LOGGER.warn("Inside rest");
				HttpSession sessionCheck = ((HttpServletRequest) request).getSession(false);
				try {
					if(sessionCheck == null)
					{
						LOGGER.warn("Inside rest Session Check is null");
						httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
						return;
					}
					else
					{
						LOGGER.warn("Inside rest Session Check is not null");
						String userIdSession = (String) sessionCheck.getAttribute("USER_ID");
						String authToken = (String) sessionCheck.getAttribute("USER_AUTH_TOKEN");
						validateSession = loginService.getUserLoginStatusForNewUX(userIdSession,sessionCheck.getId(), authToken);
						LOGGER.warn("Inside rest validateSession:");
						if (validateSession == null) {
								httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
								return;
						} else {
							filter.doFilter(request, response);
						}
					}
				} catch (BNPApplicationException e) {
					LOGGER.error(e.getMessage(),e);
				}

			}else{
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		}		
	}
	
	
	/** This method is to validate the incoming Form Parameters to prevent XSS Reflection vulnerability.
	 *  
	 * @param request
	 * @param inactiveIntervalTime
	 * @return validFlag
	 */
	
	public boolean validateRequestParameter(HttpServletRequest request, String inactiveIntervalTime) {
		boolean validFlag = false;
		String isGoBackFlag = request.getParameter("IS_GOBACK_ENABLED");
		String sessionInterval = request.getParameter("SESSION_TIME_OUT_INTRVL");
		String lastLoginTime = request.getParameter("LAST_LOGIN_TIME");

		if (isGoBackFlag != null && (isGoBackFlag.equals("Y") || isGoBackFlag.equals("N"))) {
			validFlag = true;
			if (sessionInterval != null && inactiveIntervalTime != null
					&& sessionInterval.equals(inactiveIntervalTime)) {
				validFlag = true;
				if (lastLoginTime != null) {
					try {
						new Date(new Long(lastLoginTime));
						validFlag = true;
					} catch (Exception e) {
						validFlag = false;
					}
				} else {
					validFlag = false;
				}

			} else {
				validFlag = false;
			}

		}

		return validFlag;
	}
	
	
	public void destroy() {
	}

	public void init(FilterConfig filterConfig) throws ServletException {
		
	}
}
