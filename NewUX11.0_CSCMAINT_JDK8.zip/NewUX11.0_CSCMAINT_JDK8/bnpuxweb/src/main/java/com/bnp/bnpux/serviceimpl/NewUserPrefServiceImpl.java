/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas.
 * 
 * Created on:   25 APR 2016
 * 
 * Purpose:     User Preference Service Implementation
 * 
 * Change History: 
 * Date                                    Author                                                                               Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 25 APR 2016						    Bala Murugan Elangovan														 	 Recall Implementation 
 * ****************************************************************************************************************************************************************/


package com.bnp.bnpux.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.common.vo.UserPreferenceVO;
import com.bnp.bnpux.constants.ErrorConstants;
import com.bnp.bnpux.constants.ScreenConstants;
import com.bnp.bnpux.dao.IUserPrefDAO;
import com.bnp.bnpux.service.INewUserPrefService;
import com.bnp.scm.common.IResourceManager;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

@Component
public class NewUserPrefServiceImpl implements INewUserPrefService {
	
	/**
	 * Logger log for UserPrefServiceImpl class
	 */
	public static final Logger log = LoggerFactory.getLogger(NewUserPrefServiceImpl.class);
	
	/**
	 * IUserPrefDAO userPrefDAO;
	 */
	@Autowired
	private IUserPrefDAO userPrefDAO;
	
	@Autowired
	private IResourceManager resourceManager;
		
	
	/**
	 * This API is used to save the user preference info such as Date format and Currency Format
	 * @param userVO
	 * @return 
	 * @throws BNPApplicationException
	 */
	public UserPreferenceVO saveUserPreferenceInfo(UserPreferenceVO userPrefVO)
			throws BNPApplicationException {	
		try {
			userPrefDAO.saveUserPreference(userPrefVO);
			if (userPrefVO.getLanguage() != null) {
				String localeValue = getLocale(userPrefVO.getLanguage());
				
				String[] locale =localeValue.split("_");
				
				String sLanguage = "_"+locale[0]+"_"+locale[1];
				
				if(locale[0].equals("en"))
				{
					resourceManager.setResourceBundle("");
				}
				else
				{
					resourceManager.setResourceBundle(sLanguage);
				}
				userPrefVO.setLocale(localeValue);
			}
		} catch (DataAccessException e) {
			log.error(e.getMessage(),e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return userPrefVO;
	}	
	
	/**
	 * Get Time Zone List	
	 * @return List<NameValueVO>
	 * @throws BNPApplicationException
	 */
	@Override
	public List<NameValueVO> getTimeZoneList() throws BNPApplicationException {		
		return userPrefDAO.getTimeZoneList();
	}	

	/**
	 * Get Locale from language id
	 * @param langId
	 * @return Locale
	 * @throws BNPApplicationException
	 */	
	public String getLocale(String langId) throws BNPApplicationException {
		return userPrefDAO.getLocale(langId);
	}

	/**
	 * This API is used to get user preference details.
	 * @param userId
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public UserPreferenceVO getUserPreferenceInfo(String userId,String userType)
			throws BNPApplicationException {	
		UserPreferenceVO userPrefVO = new UserPreferenceVO();
		try {
			Object result = userPrefDAO.getUserPreferenceInfo(userId);
			NameValueVO timeZoneBA = null;
			NameValueVO supBranchTimeZone = null;
			if (result != null){
				userPrefVO = (UserPreferenceVO) result;
			if (userType != null && (userType.equals(ScreenConstants.BANK_ADMIN))) {
				timeZoneBA = userPrefDAO.getTimeZoneForBA(userId);
			} else if (userType != null	&& (userType.equals(ScreenConstants.BUYER) || userType.equals(ScreenConstants.SELLER))) {		
				supBranchTimeZone = userPrefDAO.getTimeZoneForBuyerSeller(userId);
				if (supBranchTimeZone != null) {
					userPrefVO.setSupBranchTZoneInGMT(supBranchTimeZone.getValue());
					userPrefVO.setSupportBranchTZID(supBranchTimeZone.getName());
				}
				String dealType = getDealType(userId);
				userPrefVO.setPrimaryOrgDealType(dealType);
			}
			if (timeZoneBA != null) {
				userPrefVO.setTimeZoneInGMT(timeZoneBA.getValue());
				userPrefVO.setSupBranchTZoneInGMT(timeZoneBA.getValue());
				userPrefVO.setSupportBranchTZID(timeZoneBA.getName());
			}
			
			if(userPrefVO.getLanguage() != null){
				String localeValue = getLocale(userPrefVO.getLanguage());
				userPrefVO.setLocale(localeValue);
			}
			List<NameValueVO> timeZoneList = new ArrayList<NameValueVO>(); 
			timeZoneList = userPrefDAO.getTimeZone();
			userPrefVO.setCountryZoneList(timeZoneList);
						
			}		

		} catch (DataAccessException e) {
			log.error(e.getMessage(),e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return userPrefVO;
	}	
	
	/**
	 * Get TimeZoneCode List
	 * @return
	 * @throws BNPApplicationException
	 */
	public List<NameValueVO> getTimeZoneCodeList() throws BNPApplicationException {
		return userPrefDAO.getCountryTimeZoneCode();
	}
	
	
	/**
	 * Get deal type
	 * @param userId
	 * @return String
	 */
	private String getDealType(String userId) {
		return userPrefDAO.getDealType(userId);
	}
	

	/**
	 * Get Locale from user id
	 * @param userId
	 * @return Locale
	 * @throws BNPApplicationException
	 */
	@Override
	public Locale getUserLocale(String userId) throws BNPApplicationException {
		String locale = userPrefDAO.getUserLocale(userId);
		return createLocale(locale);
	}
	
	
	/**
	 * GcreateLocale
	 * @param localeStr
	 * @return Locale
	 */
	public Locale createLocale(String localeStr) {		
		Locale locale = null;
		try {
			if(localeStr != null) {
				locale = new Locale(localeStr.substring(0, localeStr.indexOf('_')), localeStr.substring(localeStr.indexOf('_')+1, localeStr.length()));
			}
		}
		catch (Exception e) {
			log.error(e.getMessage(),e);
			locale = Locale.getDefault();
		}
		return locale;
	}
}
