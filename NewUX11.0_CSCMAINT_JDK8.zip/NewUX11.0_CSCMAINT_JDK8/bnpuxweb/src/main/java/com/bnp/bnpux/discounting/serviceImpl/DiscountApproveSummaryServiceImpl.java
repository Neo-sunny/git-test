/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Discount Request Approve Service Implementation
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.discounting.serviceImpl;

import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.IAccessLogService;
import com.bnp.scm.services.common.cache.ICacheService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.CacheConstants;
import com.bnp.scm.services.common.util.NumberFormatConversionUtil;
import com.bnp.scm.services.common.util.ScreenConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.common.vo.AbstractVO;
import com.bnp.scm.services.common.vo.EventLogVO;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.bnp.scm.services.discounting.DiscountRequestServiceImpl;
import com.bnp.scm.services.discounting.IDiscountRequestService;
import com.bnp.scm.services.discounting.IDiscountService;
import com.bnp.scm.services.discounting.dao.IDiscountRequestDAO;
import com.bnp.scm.services.discounting.mb.ITPDiscRequestService;
import com.bnp.scm.services.discounting.util.BNPDiscountUtil;
import com.bnp.scm.services.discounting.vo.DiscountRequestVO;
import com.bnp.scm.services.limitmgmt.ILimitCheckService;
import com.bnp.bnpux.common.vo.ApproveRequestVo;
import com.bnp.bnpux.common.vo.ApproveResponseGridVo;
import com.bnp.bnpux.common.vo.ApproveResponseVo;
import com.bnp.bnpux.common.vo.CutOffValidationVO;
import com.bnp.bnpux.common.vo.TransactionListVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.discounting.service.IDiscountApproveSummaryService;
import com.bnp.bnpux.serviceimpl.ErrorMessageHelper;
import com.bnp.bnpux.vo.errorMessageVO.ErrorMessageVO;

@Component
@Scope("request")
public class DiscountApproveSummaryServiceImpl extends AbstractServiceImpl<DiscountRequestVO> implements IDiscountApproveSummaryService  {
	
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(DiscountApproveSummaryServiceImpl.class);

	/** The status list. */
	private List<NameValueVO> statusList;
	
	/** The document type list. */
	private List<NameValueVO> documentTypeList;
	
	/** The dis req status. */
	private String disReqStatus;
	
	/** The cutt off passed. */
	private String cuttOffPassed;
	
	/** The cutt off previous day. */
	private String cuttOffPreviousDay="N";

	/** The discount request dao. */
	@Autowired
	private IDiscountRequestDAO discountRequestDAO;
	
	
	@Autowired
	private ErrorMessageHelper errorMessageHelper;

	/** The discount request service impl. */
/*	@Autowired
	private DiscountRequestServiceImpl discountRequestServiceImpl;*/

	/** The temp data discount request vo. */
	private DiscountRequestVO tempDataDiscountRequestVO=null; 
	
	/** The search type list. */
	private List<NameValueVO> searchTypeList;
	
    /** The supplier org ids. */
    private List<NameValueVO> supplierOrgIds;
    
    /** The currency list. */
    private List<NameValueVO> currencyList;
    
    /** The open multi select popup. */
    private boolean openMultiSelectPopup;
    
    /** The approval info. */
    private List<String> approvalInfo;
    
	/** The action popup meaasge. */
	private List<String> actionPopupMeaasge;
	
	/** The action error meaasge. */
	private List<String> actionErrorMeaasge;
	
	/** The cut off excedded disc ref no. */
	private List<String> cutOffExceddedDiscRefNo;
	
    //R8.0 Minimum Discount Fee Changes
	/** List to hold the miminum discount fee applied search list of values */
	private List<NameValueVO> minDiscFeeAppList;
	
	/**To check whether min disc fee field is visible for Supplier User*/
	private boolean isMinDiscFeeEnable;
    
 	/** The discount service. */
	 @Autowired
	private IDiscountService discountService;
 	
 	/** The effective discount date. */
	 private Date effectiveDiscountDate;
 	
 	/** The disc req vo. */
	 private DiscountRequestVO discReqVO = null;
	
 	/** The limit check service. */
	 @Autowired
	 private  ILimitCheckService limitCheckService;
	 
	 /** The buyer org ids. */
 	private List<NameValueVO> buyerOrgIds;
 	
 	/** The auto complete map. */
	 private Map<String,List<NameValueVO>> autoCompleteMap;
 	
/*	*//** The summary bean. *//*
	@Autowired
	private DiscountRequestSummaryBean summaryBean;*/
	
	/** The cache service. */
	@Autowired
	private ICacheService cacheService;
	
	/** The discount request service. */
	@Autowired
	private IDiscountRequestService discountRequestService;
	
	/** The access log service. */
	@Autowired
	private IAccessLogService accessLogService;
	
	/** The tp disc req service. */
	@Autowired
	private ITPDiscRequestService tpDiscReqService;
	
	
	/* Approved Response Vo */
	// private ApproveResponseVo apprvdResListVO; // Modified for CSC-5697 - message population error on concurrent usage
	
	/* Error Response Vo */
	private List<ErrorMessageVO> ErrorMsgVOList;
	
	/* Approved Response Grid Vo */
	private List<ApproveResponseGridVo> apprvdResGridListVO;
	
	/* CuttOff Valition Vo */
	private CutOffValidationVO cutOffValdVO;
	
	private UserInfoVO userInfoVO;
	
/*	@Autowired
	private ExportUtil exportUtil;*/
	/**
	 * Gets the auto complete map.
	 *
	 * @return the auto complete map
	 */
	public Map<String, List<NameValueVO>> getAutoCompleteMap() {
		return autoCompleteMap;
	}

	/**
	 * Sets the auto complete map.
	 *
	 * @param autoCompleteMap the auto complete map
	 */
	public void setAutoCompleteMap(Map<String, List<NameValueVO>> autoCompleteMap) {
		this.autoCompleteMap = autoCompleteMap;
	}
	
	/**
	 * _log time taken.
	 *
	 * @param startTime the start time
	 * @param endTime the end time
	 * @param method the method
	 */
	private void _logTimeTaken(long startTime,long endTime,String method){
	  _debugInformation("The Time taken to execute the method "+method+" is "+(endTime - startTime)/(1000000) +" Milli Seconds");
	}
 	
 	/**
	 * Gets the logger.
	 *
	 * @return the logger
	 */
	public Logger getLogger(){
	  return LOGGER;
	}
	
	@Override
	protected String getViewPage() {
	  return "/facelets/discount/DiscountRequestSummary.xhtml";
	}


	@Override
	protected String getScreenConstant() {
	  return ScreenConstants.DISCOUNTAPPROVESUMMARY;
	}
	
	/**
	 * _debug information.
	 *
	 * @param information the information
	 */
	public void _debugInformation(String information){
	  getLogger().debug(information);
	}
	
	/**
	 * Gets the currency list.
	 *
	 * @return the currency list
	 */
	public List<NameValueVO> getCurrencyList() {
		return currencyList;
	}

	/**
	 * Sets the currency list.
	 *
	 * @param currencyList the new currency list
	 */
	public void setCurrencyList(List<NameValueVO> currencyList) {
		this.currencyList = currencyList;
	}
	
	/**
	 * Gets the search type list.
	 *
	 * @return the search type list
	 */
	public List<NameValueVO> getSearchTypeList() {
		return searchTypeList;
	}

	/**
	 * Sets the search type list.
	 *
	 * @param searchTypeList the new search type list
	 */
	public void setSearchTypeList(List<NameValueVO> searchTypeList) {
		this.searchTypeList = searchTypeList;
	}
	
	
	/**
	 * @return the minDiscFeeAppList
	 */
	public List<NameValueVO> getMinDiscFeeAppList() {
		return minDiscFeeAppList;
	}
	
	/**
	 * @param minDiscFeeAppList the minDiscFeeAppList to set
	 */
	public void setMinDiscFeeAppList(List<NameValueVO> minDiscFeeAppList) {
		this.minDiscFeeAppList = minDiscFeeAppList;
	}
	
	/**
	 * @return the isMinDiscFeeEnable
	 */
	public boolean isMinDiscFeeEnable() {
		return isMinDiscFeeEnable;
	}
	
	/**
	 * @param isMinDiscFeeEnable the isMinDiscFeeEnable to set
	 */
	public void setMinDiscFeeEnable(boolean isMinDiscFeeEnable) {
		this.isMinDiscFeeEnable = isMinDiscFeeEnable;
	}
	
	/**
	 * Gets the status list.
	 *
	 * @return the status list
	 */
	public List<NameValueVO> getStatusList() {
		return statusList;
	}

	/**
	 * Sets the status list.
	 *
	 * @param statusList the new status list
	 */
	public void setStatusList(List<NameValueVO> statusList) {
		this.statusList = statusList;
	}

	/**
	 * Gets the document type list.
	 *
	 * @return the document type list
	 */
	public List<NameValueVO> getDocumentTypeList() {
		return documentTypeList;
	}

	/**
	 * Sets the document type list.
	 *
	 * @param documentTypeList the new document type list
	 */
	public void setDocumentTypeList(List<NameValueVO> documentTypeList) {
		this.documentTypeList = documentTypeList;
	}

	/**
	 * Gets the cache service.
	 *
	 * @return the cache service
	 */
	public ICacheService getCacheService() {
		return cacheService;
	}

	/**
	 * Sets the cache service.
	 *
	 * @param cacheService the new cache service
	 */
	public void setCacheService(ICacheService cacheService) {
		this.cacheService = cacheService;
	}

	/**
	 * Gets the dis req status.
	 *
	 * @return the dis req status
	 */
	public String getDisReqStatus() {
		return disReqStatus;
	}

	/**
	 * Sets the dis req status.
	 *
	 * @param disReqStatus the new dis req status
	 */
	public void setDisReqStatus(String disReqStatus) {
		this.disReqStatus = disReqStatus;
	}
	
	@Override
	protected String getSummaryPage() {
		return null;
	}

	/**
	 * Gets the approval info.
	 *
	 * @return the approval info
	 */
	public List<String> getApprovalInfo() {
		return approvalInfo;
	}

	/**
	 * Sets the approval info.
	 *
	 * @param approvalInfo the new approval info
	 */
	public void setApprovalInfo(List<String> approvalInfo) {
			this.approvalInfo = approvalInfo;
	}
	
	/**
	 * Gets the action popup meaasge.
	 *
	 * @return the action popup meaasge
	 */
	public List<String> getActionPopupMeaasge() {
		return actionPopupMeaasge;
	}

	/**
	 * Sets the action popup meaasge.
	 *
	 * @param actionPopupMeaasge the new action popup meaasge
	 */
	public void setActionPopupMeaasge(List<String> actionPopupMeaasge) {
		this.actionPopupMeaasge = actionPopupMeaasge;
	}

	/**
	 * Gets the action error meaasge.
	 *
	 * @return the action error meaasge
	 */
	public List<String> getActionErrorMeaasge() {
		return actionErrorMeaasge;
	}

	/**
	 * Sets the action error meaasge.
	 *
	 * @param actionErrorMeaasge the new action error meaasge
	 */
	public void setActionErrorMeaasge(List<String> actionErrorMeaasge) {
		this.actionErrorMeaasge = actionErrorMeaasge;
	}

	/**
	 * Gets the cut off excedded disc ref no.
	 *
	 * @return the cut off excedded disc ref no
	 */
	public List<String> getCutOffExceddedDiscRefNo() {
		return cutOffExceddedDiscRefNo;
	}

	/**
	 * Sets the cut off excedded disc ref no.
	 *
	 * @param cutOffExceddedDiscRefNo the new cut off excedded disc ref no
	 */
	public void setCutOffExceddedDiscRefNo(List<String> cutOffExceddedDiscRefNo) {
		this.cutOffExceddedDiscRefNo = cutOffExceddedDiscRefNo;
	}
	
	/**
	 * Checks if is open multi select popup.
	 *
	 * @return true, if is open multi select popup
	 */
	public boolean isOpenMultiSelectPopup() {
		return openMultiSelectPopup;
	}

	/**
	 * Sets the open multi select popup.
	 *
	 * @param openMultiSelectPopup the new open multi select popup
	 */
	public void setOpenMultiSelectPopup(boolean openMultiSelectPopup) {
		this.openMultiSelectPopup = openMultiSelectPopup;
	}
	
	/**
	 * @return the supplierOrgIds
	 */
	public List<NameValueVO> getSupplierOrgIds() {
		return supplierOrgIds;
	}

	/**
	 * @param supplierOrgIds the supplierOrgIds to set
	 */
	public void setSupplierOrgIds(List<NameValueVO> supplierOrgIds) {
		this.supplierOrgIds = supplierOrgIds;
	}

	/**
	 * @return the buyerOrgIds
	 */
	public List<NameValueVO> getBuyerOrgIds() {
		return buyerOrgIds;
	}

	/**
	 * @param buyerOrgIds the buyerOrgIds to set
	 */
	public void setBuyerOrgIds(List<NameValueVO> buyerOrgIds) {
		this.buyerOrgIds = buyerOrgIds;
	}
	
	/**
	 * Gets the buyer org list.
	 *
	 * @param event the event
	 * @return the buyer org list
	 */
/*	public void getBuyerOrgList(ValueChangeEvent event){
	  try {
	    if (event.getPhaseId() != PhaseId.INVOKE_APPLICATION){
		  event.setPhaseId(PhaseId.INVOKE_APPLICATION);
		  event.queue();
		}else if(event.getNewValue()!=null){
		  buyerOrgIds = discountRequestService.getBuyerOrgListForSupplier(event.getNewValue().toString());	
		  FacesContext.getCurrentInstance().renderResponse();
	    }			
	  } catch (BNPApplicationException exception) {
		displayErrorMessage(exception.getMessage());
	    getLogger().error("Exception Occured whil executing Method getBuyerOrgList() from DiscountApproveSummaryBean with exception :: {} ",exception);
	  }
	}*/
	
	/**
	 * Gets the buyer org list sug.
	 *
	 * @param event the event
	 * @return the buyer org list sug
	 */
/*	public void getBuyerOrgListSug(ActionEvent event){
	  try {
	    if(!StringUtils.isEmpty(dataVO.getSellerOrgId())){
		  buyerOrgIds = discountRequestService.getBuyerOrgListForSupplier(dataVO.getSellerOrgId());	
		}
	  } catch (BNPApplicationException exception) {
	    displayErrorMessage(exception.getMessage());
		getLogger().error("BNPApplicationException Occured whil executing Method getBuyerOrgListSug() from DiscountApproveSummaryBean with exception :: {} ",exception);
	  }
	}*/
	
	/**
	 * Approve.
	 */
	public ApproveResponseVo approve(List<DiscountRequestVO> discVOList, UserInfoVO user){
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering method approve() of DiscountApprovalSummaryBean");
	  // UX9.0 S144 - Starts
	  List<String> ErrorMsg= new ArrayList<String>();
	  ApproveResponseVo apprvdResListVO = new ApproveResponseVo(); //Added for CSC-5697 - message population error on concurrent usage
	  selectedList=discVOList;	  
	  setUserId(user.getUserId());
	  setUserTypeID(user.getUserTypeId());
	  String disRefNo = "";
	  tempDataDiscountRequestVO=null;
	  try{	  
		 
		  initializeMultiSelectVariables();
/*		if(checkRowSelected()){*/
		  if(selectedList.size() > 1){
		    openMultiSelectPopup = true;
		  }
		  Iterator<DiscountRequestVO> selectedListIterator = selectedList.iterator();
		  while(selectedListIterator.hasNext()){
		    DiscountRequestVO discountRequestVO = selectedListIterator.next();
		    disRefNo = discountRequestVO.getDiscountRefNo();
		    
		    getLogger().debug("Approving Discount request for the Selected Data "+discountRequestVO);
		    approveDiscountRequest(discountRequestVO,user);
		    if(openMultiSelectPopup && approvalInfo != null){
		      actionPopupMeaasge.addAll(approvalInfo);
		    }
		  }
		  addErrorAndWarnMsgToMultiselActionPopup();
		  if(!openMultiSelectPopup){
			  if(tempDataDiscountRequestVO!=null){
				  cutOffValdVO = new  CutOffValidationVO();
				  cutOffValdVO.setDiscBuyerAcceptReqd(tempDataDiscountRequestVO.getDiscBuyerAcceptReqd());
				  cutOffValdVO.setDiscountRefNo(tempDataDiscountRequestVO.getDiscountRefNo());
			  }else if(errorMessageHelper.getErrorMessageVOList().size()==0 && disReqStatus!=null && !disReqStatus.equalsIgnoreCase(resourceManager.getMessage(ErrorConstants.APPROVE_SUCCESS))){
				  addActionPopupMessages(disReqStatus, disRefNo,false);
			  }
		  }
		  refreshTableGrid();
/*	    }else{
 	      disReqStatus = null;
 	      cutOffValdVO = null;
 	    }*/
	  }catch(BNPApplicationException exception){
		getLogger().error("BNPApplicationException Occured whil executing Method getBuyerOrgListSug() from DiscountApproveSummaryBean with exception :: {} ",exception);
	    displayErrorMessage(resourceManager.getMessage(exception.getErrorCode()));
	    addActionPopupMessages(resourceManager.getMessage(exception.getErrorCode()), disRefNo,true);
	  }catch(Exception exception){
		getLogger().error("BNPApplicationException Occured whil executing Method getBuyerOrgListSug() from DiscountApproveSummaryBean with exception :: {} ",exception);
		disReqStatus = resourceManager.getMessage(ErrorConstants.ACCEPT_FAILURE);
	    addActionPopupMessages(disReqStatus, disRefNo,true);
	  }
	  _logTimeTaken(startTime,(System.nanoTime()),"approve()");
	  getLogger().debug("Exit of Method approve() of DiscountApprovalSummaryBean");
	  apprvdResListVO.setCutOffValidationVO(cutOffValdVO);
	  apprvdResListVO.setapproveGridListVO(apprvdResGridListVO);
	  apprvdResListVO.seterrMessageVO( errorMessageHelper.getErrorMessageVOList());
	  if(tempDataDiscountRequestVO!=null){
		  tempDataDiscountRequestVO.setEffectiveDiscountDate(effectiveDiscountDate);
		  apprvdResListVO.setTempDiscReqVO(tempDataDiscountRequestVO);
	  }
	  //return actionPopupMeaasge;
      return apprvdResListVO;
	}
	
	/**
	 * Approve discount request.
	 *
	 * @param discountRequestVO the discount request vo
	 */
	public void approveDiscountRequest(DiscountRequestVO discountRequestVO,UserInfoVO uservo) throws BNPApplicationException{
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering the method  approveDiscountRequest from DiscountApprovalSummaryBean");
	  try{
		if(approvalInfo != null) setApprovalInfo(null); // to avoid approval info message retaining in the instance
		getLogger().debug("Approving Discount request for the Selected Data in the meth0od approveDiscountRequest() "+discountRequestVO);
		if(checkMakerForApprove(getUserId(), discountRequestVO.getMakerId(), discountRequestVO.getDiscountRefNo())){
		  if(cutOffValidator(discountRequestVO) && isPendingApprovalRecord(discountRequestVO)) {
			//if(isPendingApprovalRecord(discountRequestVO)) {
		    cutOffExceddedDiscRefNo.add(discountRequestVO.getDiscountRefNo());
			tempDataDiscountRequestVO=discountRequestVO;
			getLogger().debug("Entering the loop Where the Cut Off Has Exceeded");
		  }else{
			if(discountRequestVO.getDiscountStatus().equals(StatusConstants.CANCEL_PENDING_FOR_APPROVAL)){
				if (checkMakerForApproveCancel(getUserId(),discountRequestVO.getMakerId())){
					discountRequestService.approveCancelPendingDiscountRequest(discountRequestVO,getUserId());
					disReqStatus = resourceManager.getMessage(ErrorConstants.CANCEL_SUCCESS);
					 ErrorMessageVO objErrorMessageVO  = new ErrorMessageVO();	  
				      objErrorMessageVO.setUniqueID(discountRequestVO.getDiscountRefNo());
					  objErrorMessageVO.setMessage(disReqStatus);
					  objErrorMessageVO.setError(false);
					  errorMessageHelper.getErrorMessageVOList().add(objErrorMessageVO);
				}

			} else if(isValidRecordToApprove(discountRequestVO)){
			  setAccessLogDetails(ScreenConstants.ACCESS_LOG_DISCOUNT_APPROVE ,discReqVO.getDiscountRefNo(),uservo);
			  //approveRecord(discReqVO);
		    	approveRecord(discountRequestVO);
			}
			discReqVO = null;
		  }
		}
	  }catch (BNPApplicationException exception) {
	    disReqStatus = resourceManager.getMessage(ErrorConstants.APPROVE_FAILURE);
	    getLogger().error("BNPApplicationException Occured whil executing Method approveDiscountRequest() from DiscountApproveSummaryBean with exception :: {} ",exception);
	    throw exception;
	  }
	  _logTimeTaken(startTime,(System.nanoTime()),"approveDiscountRequest()");
	  getLogger().debug("Exit of the method  approveDiscountRequest from DiscountApprovalSummaryBean");
	}

	/**
	 * Checks if is valid record to approve.
	 *
	 * @param discountRequestVO the discount request vo
	 * @return true, if is valid record to approve
	 */
	private boolean isValidRecordToApprove(DiscountRequestVO discountRequestVO) {
		getLogger().debug("Entering and Exit of the method  isValidRecordToApprove from DiscountApprovalSummaryBean");
		return validateRecordForApprove(discReqVO.getDiscountStatus(), discountRequestVO.getDiscountRefNo()) && checkMakerForApprove(getUserId(), discReqVO.getMakerId(), discountRequestVO.getDiscountRefNo())
				&& validateDueDateForApprove(discReqVO.getDueDate(), discountRequestVO.getDiscountRefNo()) && checkMakerTypeForSupplierApprove(discReqVO);
	}
	
	/**
	 * Approve record.
	 *
	 * @param discountVO the discount vo
	 * @throws BNPApplicationException the BNP application exception
	 */
	private void approveRecord(DiscountRequestVO discountVO) throws BNPApplicationException{
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering the method  approveRecord from DiscountApprovalSummaryBean with Discount request "+discountVO);
	  try {
	    if(StatusConstants.DISCOUNT_PENDING_APPROVAL.equals(discountVO.getDiscountStatus())){
	      approvePendingApprovalRecord(discountVO);
	    }else if (StatusConstants.PENDING_BUYER_ACCEPTANCE_APPROVAL.equals(discountVO.getDiscountStatus())){
	      approvePendingBuyerAcceptApprRecord(discountVO);
	    }else if(StatusConstants.PENDING_BUYER_REJECTION_APPROVAL.equals(discountVO.getDiscountStatus())){
	      approvePendingBuyerRejectApprRecord(discountVO);
	    }else if(StatusConstants.PENDING_BUYER_ACCEPTANCE.equals(discountVO.getDiscountStatus())){
	      discountService.approveDiscReqForBuyerAcceptance(discountVO, getUserId());
	    }
	  }catch(BNPApplicationException exception){
		getLogger().error("BNPApplicationException Occured whil executing Method approveRecord() from DiscountApproveSummaryBean with exception :: {} ",exception);
		throw exception;
	  }
	  getLogger().debug("Entering the method  approveRecord from DiscountApprovalSummaryBean");
	  _logTimeTaken(startTime,(System.nanoTime()),"approveRecord()");
	}
	
	/**
	 * Approve pending buyer reject appr record.
	 *
	 * @param discountVO the discount vo
	 * @throws BNPApplicationException the BNP application exception
	 */
	private void approvePendingBuyerRejectApprRecord(DiscountRequestVO discountVO) throws BNPApplicationException{
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering the method  approvePendingBuyerRejectApprRecord from DiscountApprovalSummaryBean with discount request object "+discountVO);
	  if(validateRecordForBuyerAcceptanceApproval(discountVO)){ // check this
	    discountService.rejectAndApproveBuyerAcceptanceRecord(discountVO, getUserId());
		disReqStatus = resourceManager.getMessage(ErrorConstants.APPROVE_SUCCESS);
          ErrorMessageVO objErrorMessageVO  = new ErrorMessageVO();	  
	      objErrorMessageVO.setUniqueID(discountVO.getDiscountRefNo());
		  objErrorMessageVO.setMessage(disReqStatus);
		  objErrorMessageVO.setError(false);
		  errorMessageHelper.getErrorMessageVOList().add(objErrorMessageVO);
	  }
	  getLogger().debug("Exit of the method  approvePendingBuyerRejectApprRecord from DiscountApprovalSummaryBean");
	  _logTimeTaken(startTime,(System.nanoTime()),"approvePendingBuyerRejectApprRecord()");
	}
	
	/**
	 * Approve pending buyer accept appr record.
	 *
	 * @param discountVO the discount vo
	 * @throws BNPApplicationException the BNP application exception
	 */
	private void approvePendingBuyerAcceptApprRecord(DiscountRequestVO discountVO) throws BNPApplicationException{
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering the method  approvePendingBuyerAcceptApprRecord from DiscountApprovalSummaryBean discount request object "+discountVO);
	  if(validateRecordForBuyerAcceptanceApproval(discountVO)){ //check this
	    discountService.approveDiscReqForBuyerAcceptance(discountVO, getUserId());
		disReqStatus = resourceManager.getMessage(ErrorConstants.APPROVE_SUCCESS);
		setApprovalInfo(getDiscountDetailsToDisplay(discountVO));
		getDiscountDetailsToDisplayNewUX(discountVO);
	  }
	  getLogger().debug("Exit of the method  approvePendingBuyerAcceptApprRecord from DiscountApprovalSummaryBean");
	  _logTimeTaken(startTime,(System.nanoTime()),"approvePendingBuyerAcceptApprRecord()");
	}
	
	/**
	 * Approve pending approval record.
	 *
	 * @param discountVO the discount vo
	 * @throws BNPApplicationException the BNP application exception
	 */
	private void approvePendingApprovalRecord(DiscountRequestVO discountVO) throws BNPApplicationException{
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering the method  approvePendingApprovalRecord from DiscountApprovalSummaryBean with discount request object "+discountVO);
	  if(!isBuyerAcceptReqd(discountVO)){
	    discountService.approveDiscountRequest(discountVO, getUserId());
	  }else{
	    discountService.approveDiscReqToBuyerAcceptance(discountVO, getUserId());
	  }
	  disReqStatus = resourceManager.getMessage(ErrorConstants.APPROVE_SUCCESS);
	  getLogger().debug("Exit of the method  approvePendingApprovalRecord from DiscountApprovalSummaryBean");
	  setApprovalInfo(getDiscountDetailsToDisplay(discountVO));
	  getDiscountDetailsToDisplayNewUX(discountVO);
	  _logTimeTaken(startTime,(System.nanoTime()),"approvePendingApprovalRecord()");
	}
	
	
	/**
	 * Trigger event log.
	 *
	 * @param discountRequestVO the discount request vo
	 * @param action the action
	 */
	private void triggerEventLog(DiscountRequestVO discountRequestVO,String action){
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering the method  triggerEventLog from DiscountApprovalSummaryBean discount request object "+discountRequestVO+" and action name "+action);
	  EventLogVO eventLogVO = new EventLogVO();		
	  if(action.equalsIgnoreCase(BNPConstants.REJECT)){
	    eventLogVO.setEventName(BNPConstants.EVENT_DISC_REQ_REJECT);
	  }else if(action.equalsIgnoreCase(BNPConstants.RELEASE)){
	    eventLogVO.setEventName(BNPConstants.EVENT_DISC_REQ_RELEASE);
	  }
	  eventLogVO.setEventInitiator(userId);
	  eventLogVO.setOrgId(discountRequestVO.getSellerOrgId());
	  eventLogVO.setReferenceKey(discountRequestVO.getDiscountRefNo());
	  getLogger().debug("the Object details from the method triggerEventLog() is :: "+eventLogVO);
	  eventLogService.triggerEventLog(eventLogVO);
	  getLogger().debug("Exit of the method  triggerEventLog from DiscountApprovalSummaryBean");
	  _logTimeTaken(startTime,(System.nanoTime()),"triggerEventLog()");
	}
	
	/**
	 * Gets the discount details to display.
	 *
	 * @param discountRequestVO the discount request vo
	 * @return the discount details to display
	 */
	private List<String> getDiscountDetailsToDisplay(DiscountRequestVO discountRequestVO) {
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering the method  getDiscountDetailsToDisplay from DiscountApprovalSummaryBean with discount request object "+discountRequestVO);
	  List<String> discInfo = new ArrayList<String>();
	  if(discountRequestVO != null) {			
	    discInfo.add(resourceManager.getMessage(ErrorConstants.DIS_REF_NO) +" = "+  discountRequestVO.getDiscountRefNo()) ;
		discInfo.add(resourceManager.getMessage(ErrorConstants.AVAIL_AMNT) +" = "+  formatAmount(discountRequestVO.getAvailableAmt(),discountRequestVO.getFractionalDigits(),discountRequestVO.getRoundingMode())) ;
		discInfo.add(resourceManager.getMessage(ErrorConstants.IND_DISC_RATE)+" = "+ formatRate(discountRequestVO.getIndicativeDiscountRate(),discountRequestVO.getRoundingMode()));
		discInfo.add(resourceManager.getMessage(ErrorConstants.IND_DISC_AMT) +" = "+ formatAmount(discountRequestVO.getIndicativeDiscountAmt(),discountRequestVO.getFractionalDigits(),discountRequestVO.getRoundingMode())) ;
		if(discountRequestVO.getIndicativeChargeAmt()!=null){
		  discInfo.add(resourceManager.getMessage(ErrorConstants.IND_CHRG_AMT) +" = "+  formatAmount(discountRequestVO.getIndicativeChargeAmt(),discountRequestVO.getFractionalDigits(),discountRequestVO.getRoundingMode())) ;
		}
		discInfo.add(resourceManager.getMessage(ErrorConstants.IND_NET_AMT) +" = "+  formatAmount(discountRequestVO.getIndicativeNetAmt(),discountRequestVO.getFractionalDigits(),discountRequestVO.getRoundingMode())) ;
	  }
	  getLogger().debug("Exit of the method  getDiscountDetailsToDisplay from DiscountApprovalSummaryBean");
	  _logTimeTaken(startTime,(System.nanoTime()),"getDiscountDetailsToDisplay()");
	  return discInfo;
	}
	
	/**
	 * Gets the discount details to display.
	 *
	 * @param discountRequestVO the discount request vo
	 * @return the discount details to display
	 */
	private List<ErrorMessageVO> getDiscountDetailsToDisplayNewUX(DiscountRequestVO discountRequestVO) {
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering the method  getDiscountDetailsToDisplayNewUX from DiscountApprovalSummaryBean with discount request object "+discountRequestVO);
	  List<String> discInfo = new ArrayList<String>();
	  StringBuilder finalString = new StringBuilder();
	  ApproveResponseGridVo apprResGridVO = new ApproveResponseGridVo();
	  //apprvdResGridListVO
	  if(discountRequestVO != null) {			
		  apprResGridVO.setDiscountRefNo(discountRequestVO.getDiscountRefNo());
		  apprResGridVO.setAvailableAmt(formatAmount(discountRequestVO.getAvailableAmt(),discountRequestVO.getFractionalDigits(),discountRequestVO.getRoundingMode()));
		  apprResGridVO.setIndicativeDiscountRate(formatAmount(discountRequestVO.getIndicativeDiscountRate(),discountRequestVO.getFractionalDigits(),discountRequestVO.getRoundingMode()));
		  apprResGridVO.setIndicativeDiscountAmt(formatAmount(discountRequestVO.getIndicativeDiscountAmt(),discountRequestVO.getFractionalDigits(),discountRequestVO.getRoundingMode()));
		if(discountRequestVO.getIndicativeChargeAmt()!=null){
			apprResGridVO.setIndicativeChargeAmt(formatAmount(discountRequestVO.getIndicativeChargeAmt(),discountRequestVO.getFractionalDigits(),discountRequestVO.getRoundingMode()));
		}
		apprResGridVO.setIndicativeNetAmt(formatAmount(discountRequestVO.getIndicativeNetAmt(),discountRequestVO.getFractionalDigits(),discountRequestVO.getRoundingMode()));
		apprResGridVO.setRemarks(resourceManager.getMessage(ErrorConstants.APPROVE_SUCCESS));
	  }
	  apprvdResGridListVO.add(apprResGridVO);
/*		  ErrorMessageVO objErrorMessageVO  = new ErrorMessageVO();	  
      objErrorMessageVO.setUniqueID(discountRequestVO.getDiscountRefNo());
	  objErrorMessageVO.setMessage(finalString.toString());
	  objErrorMessageVO.setError(false);
	  apprvdResGridListVO.add(apprResGridVO);
	  errorMessageHelper.getErrorMessageVOList().add(objErrorMessageVO);*/
	  getLogger().debug("Exit of the method  getDiscountDetailsToDisplayNewUX from DiscountApprovalSummaryBean");
	  _logTimeTaken(startTime,(System.nanoTime()),"getDiscountDetailsToDisplayNewUX()");
	  return errorMessageHelper.getErrorMessageVOList();
	}
	
	/**
	 * Format amount.
	 *
	 * @param value the value
	 * @param roundValue the round value
	 * @param roundingMode the rounding mode
	 * @return the big decimal
	 */
	private BigDecimal formatAmount(BigDecimal value,int roundValue, String roundingMode){
	  return NumberFormatConversionUtil.formatBigDecWithMode(value, roundValue, roundingMode);
	}
	
	/**
	 * Format rate.
	 *
	 * @param value the value
	 * @param roundingMode the rounding mode
	 * @return the big decimal
	 */
	private BigDecimal formatRate(BigDecimal value, String roundingMode){
	  return NumberFormatConversionUtil.formatBigDecWithMode(value, 6, roundingMode);
	}
	
	/**
	 * Creates the auto complete values.
	 *
	 * @return the map
	 * @throws BNPApplicationException the BNP application exception
	 */
	private Map<String,List<NameValueVO>> createAutoCompleteValues() throws BNPApplicationException{
	  Map<String,List<NameValueVO>> autoCompleteMap = new HashMap<String, List<NameValueVO>>();
	  if(getUserTypeID().equals(BNPConstants.BANKADMIN)){
	    autoCompleteMap.put("SUPPLIER_ORG_IDS", discountRequestService.getSupplierOrgListForBankAdmin(getUserId()));
	    autoCompleteMap.put("BUYER_ORG_IDS", discountRequestService.getBuyerOrgListForBankAdmin(getUserId()));
	    autoCompleteMap.put("CURRENCY_LIST", cacheService.getCurrencyList());
	  }
	  setAutoCompleteMap(autoCompleteMap);
	  return autoCompleteMap;
	}
	
	@PostConstruct
	public void getDiscountApproveSummary() throws BNPApplicationException{
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering the method  getDiscountApproveSummary from DiscountApprovalSummaryBean");
	  dataVO=new DiscountRequestVO();
	  try {
/*	    if(!isBuyerUser()){
		  statusList = cacheService.getDiscountStatusList();
		}else{
		  statusList = cacheService.getDiscountStatusListForBuyer();
		}
		statusList.add(new NameValueVO(StatusConstants.PENDING_MB_BATCHING,StatusConstants.PENDING_MB_BATCHING));
		documentTypeList = cacheService.getDocumentTypeList();
		minDiscFeeAppList = cacheService.getMinDiscFeeAppliedList(); //R8.0 Minimum Discount Fee Changes
		if(getUserTypeID().equalsIgnoreCase(BNPConstants.SUPPLIER)){
		  searchTypeList=cacheService.getSearchTypeListSupplier();
		}else if(isBuyerUser()){
		  searchTypeList=cacheService.getSearchTypeListForBuyer();
		}else{
		  searchTypeList=cacheService.getSearchTypeList();
		}			
		dataVO.setSearchType(CacheConstants.SEARCH_TYPE_DISCOUNT);
		Map<String, String> threshold =  cacheService.getThresholdCache();
		if(threshold.containsKey(getScreenConstant())){
		  pagThresholdValue = getSearchOrExportThresold(threshold,BNPConstants.SEARCH);
		  exportThreshold =getSearchOrExportThresold(threshold,BNPConstants.EXPORT);
		}
		if(getUserTypeID().equals(BNPConstants.SUPPLIER)){
		  Map<Object,Object> usrDtls = new HashMap<Object,Object>();
		  usrDtls.put("userId", getUserId());
		  usrDtls.put("userType", BNPConstants.SUPPLIER);
		  buyerOrgIds = discountRequestService.getBuyerOrgListForOrgUser(usrDtls);
		  usrDtls.put("supBranchId", loginBean.getUserVO().getSupportBranchId());
		  isMinDiscFeeEnable = discountRequestService.isMinDiscFeeAvailForSupplier(usrDtls);
		}
		if(isBuyerUser()){
		  supplierOrgIds = discountRequestService.getSupplierOrgListForBuyerUser(getUserId(),  BNPConstants.BUYER);
		  buyerOrgIds = discountRequestService.getBuyerOrgListForBuyer(getUserId()); // confirm this
		}
		getLogger().debug("The Discount request details from the method getDiscountApproveSummary() "+dataVO);
		if(!getUserTypeID().equals(BNPConstants.BANKADMIN)){
		  currencyList = cacheService.getCurrencyList();
		}
		populateTableData();
		populateEntitlementDetails();
		createAutoCompleteValues();*/
/*	  }catch (BNPApplicationException exception) {
		getLogger().error("Exception occured whil executing the method getDiscountApproveSummary : {} ",exception);
	    displayErrorMessage(exception.getErrorCode());*/
	  }finally{
	    clearVO();
		setDefaultSearchCriterias();
	  }
	  getLogger().debug("Exit of the method  getDiscountApproveSummary from DiscountApprovalSummaryBean");
	  _logTimeTaken(startTime,(System.nanoTime()),"getDiscountApproveSummary()");
	}
	
	/**
	 * Sets the default search criterias.
	 */
	private void setDefaultSearchCriterias(){
	  dataVO.setDiscountRefNo("%");
	  dataVO.setSellerRefNo("%");
	}	
	
	/**
	 * Sets the default status.
	 */
	private void setDefaultStatus() {
	  if(!isBuyerUser()){	
	    dataVO.setDiscountStatus(StatusConstants.DISCOUNT_PENDING_APPROVAL);
	  }
	}
	
	@Override
	public void searchData(){
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering  method  searchData() from DiscountApprovalSummaryBean");
	  try {
	    rowCount = null;			
		dataVO.setStartRow(0);
		dataVO.setEndRow(pagThresholdValue);
		setUserDetails();
		validateUserDetailsForBuyer();
		if (dataVO.getUserType() != null) {
		  dataVO.setSearchOrPopulate(BNPConstants.SEARCH);							
		  if(CacheConstants.SEARCH_TYPE_FUNDING.equalsIgnoreCase(dataVO.getSearchType())){
		    if(getEntitlementVO()!=null){
			  entitlementVO.setApproveDisabled(true);
			  entitlementVO.setRejectDisabled(true);
			}
		    rowCount = discountRequestService.searchFundReleaseDetailSummaryCount(dataVO);
			dataVO.setEndRow(pagThresholdValue);
			tableDataList = discountRequestService.searchFundReleaseDetailSummary(dataVO);
		    for(int index=0;index<tableDataList.size();index++) {
		 	  DiscountRequestVO reqVO=tableDataList.get(index);
			  int errorCode=Integer.parseInt(reqVO.getRemarks()); 
			  String errorMsg=resourceManager.getMessage(errorCode);
			  if(StatusConstants.DISC_INIT_FAILED.equalsIgnoreCase(reqVO.getDiscountStatus())){
			    tableDataList.get(index).setRemarks(errorMsg);
			  } else {
			    tableDataList.get(index).setRemarks("");
			  }
			}
		  }else{
		    //disableButtonsOnCancel();
			rowCount = discountRequestService.searchDiscountDetailSummaryCount(dataVO);
			dataVO.setEndRow(pagThresholdValue);
			tableDataList = discountRequestService.searchDiscountDetailSummary(dataVO);
		  }
		}
		getLogger().debug("The Discount request details from the method searchData() "+dataVO);
		validateSearchThreshold();
	  }catch (BNPApplicationException e) {
	    displayErrorMessage(e.getErrorCode(),e);
	  }finally{
	    clearDataList();
		setEndingRecord(10);
		setStartingRecord(1);
		//Pagination Issues [CSCDEV-7514 , CSCDEV-7513 , CSCDEV-7510]
		setSummaryDefaultPage(BNPConstants.DEFAULT_SUMMARYPAGE);
	  }
	  getLogger().debug("Exit of the method  searchData() from DiscountApprovalSummaryBean");
	  _logTimeTaken(startTime,(System.nanoTime()),"searchData()");
	}
	
	/**
	 * Validate user details for buyer.
	 *
	 * @throws BNPApplicationException the BNP application exception
	 */
	private void validateUserDetailsForBuyer() throws BNPApplicationException{
 	  if(isBuyerUser() && (dataVO.getOrgId() == null || dataVO.getUserType() == null) ){
	    throw new BNPApplicationException(ErrorConstants.INSUFFICIENT_DATA_ERROR_DISC_REQ_APPROVAL);
	  }
	}

	/**
	 * Sets the user details.
	 */
	private void setUserDetails() {
	  dataVO.setCurrentUserId(getUserId());
	  dataVO.setUserType(getUserTypeID());
	  dataVO.setOrgId(getOrgId());
	}
	
	/**
	 * Validate record for approve.
	 *
	 * @param discountStatus the discount status
	 * @param discRefNo the disc ref no
	 * @return true, if successful
	 */
	private boolean validateRecordForApprove(String discountStatus, String discRefNo) {
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering the method  validateRecordForApprove() from DiscountApprovalSummaryBean with the Discount Status "+discountStatus+" for the Discount reference Number "+discRefNo);
	  boolean isValid = true;
	  if(isSupplierUser()){
	    if(StatusConstants.PENDING_BUYER_ACCEPTANCE.equals(discountStatus) || StatusConstants.PENDING_BUYER_ACCEPTANCE_APPROVAL.equals(discountStatus) ||
		  StatusConstants.PENDING_BUYER_REJECTION_APPROVAL.equals(discountStatus)){
		  isValid = false;
		  disReqStatus = resourceManager.getMessage(ErrorConstants.BUYER_ACCEPT_UNDER_PROCESS_ERROR);
		  addToActionErrorMeaasge(disReqStatus, discRefNo);	 
		}else if(! StatusConstants.DISCOUNT_PENDING_APPROVAL.equals(discountStatus) ){
		  disReqStatus = resourceManager.getMessage(ErrorConstants.CANNOT_APPROVE_RECORD);
   		  addToActionErrorMeaasge(disReqStatus, discRefNo);	 
		  isValid = false;
		}
	  }else {
	    if(StatusConstants.PENDING_BUYER_ACCEPTANCE.equals(discountStatus)){
		  isValid = false;
		  disReqStatus = resourceManager.getMessage(ErrorConstants.BUYER_ACCEPT_NOT_PROCESSED_ERROR);
		  addToActionErrorMeaasge(disReqStatus, discRefNo);	 
		}else if(! StatusConstants.PENDING_BUYER_ACCEPTANCE_APPROVAL.equals(discountStatus) && ! StatusConstants.PENDING_BUYER_REJECTION_APPROVAL.equals(discountStatus)
		  && ! StatusConstants.DISCOUNT_PENDING_APPROVAL.equals(discountStatus)){ 
		  disReqStatus = resourceManager.getMessage(ErrorConstants.CANNOT_APPROVE_RECORD);
		  addToActionErrorMeaasge(disReqStatus, discRefNo);	 
		  isValid = false;
		}
	  }
	  getLogger().debug("Exit of the method  validateRecordForApprove() from DiscountApprovalSummaryBean with the Validation Status :isValid: "+isValid);
	  _logTimeTaken(startTime,(System.nanoTime()),"validateRecordForApprove()");
	  return isValid;
	}
	
	/**
	 * Validate record for reject.
	 *
	 * @param discountStatus the discount status
	 * @param discRefNo the disc ref no
	 * @return true, if successful
	 */
	private boolean validateRecordForReject(String discountStatus, String discRefNo) {
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering the method  validateRecordForReject() from DiscountApprovalSummaryBean with the Discount Status "+discountStatus+" for the Discount reference Number "+discRefNo);
	  boolean isValid =true;
	  if(isSupplierUser() && ! discountStatus.equals(StatusConstants.DISCOUNT_PENDING_APPROVAL)){
	    disReqStatus = resourceManager.getMessage(ErrorConstants.CANNOT_REJECT_RECORD_FOR_REQUEST);
		addToActionErrorMeaasge(disReqStatus, discRefNo);	 
		isValid = false;
	  }else if(isBuyerUser() && ! discountStatus.equals(StatusConstants.PENDING_BUYER_ACCEPTANCE)){
	    disReqStatus = resourceManager.getMessage(ErrorConstants.DISC_APPR_SUMMARY_CANNOT_ACCEPT_RECORD);
		addToActionErrorMeaasge(disReqStatus, discRefNo);
		isValid = false;
	  }else if(isBankUser() && ! discountStatus.equals(StatusConstants.PENDING_BUYER_ACCEPTANCE) &&
	    ! discountStatus.equals(StatusConstants.DISCOUNT_PENDING_APPROVAL)){
	    disReqStatus = resourceManager.getMessage(ErrorConstants.DISC_APPR_SUMMARY_CANNOT_ACCEPT_RECORD);
		addToActionErrorMeaasge(disReqStatus, discRefNo);
		isValid = false;
	  }
	  getLogger().debug("Exit of the method  validateRecordForReject() from DiscountApprovalSummaryBean with the Validation Status :isValid: "+isValid);
	  _logTimeTaken(startTime,(System.nanoTime()),"validateRecordForReject()");
	  return isValid;
	}

	
	/**
	 * Check maker for approve.
	 *
	 * @param loginUserId the login user id
	 * @param makerId the maker id
	 * @param discRefNo the disc ref no
	 * @return true, if successful
	 */
	private boolean checkMakerForApprove(String loginUserId, String makerId, String discRefNo) {
	  getLogger().debug("Entering the method  checkMakerForApprove() from DiscountApprovalSummaryBean with the Logged In user id "+loginUserId+" for the Discount reference Number "+discRefNo+" With Maker Id "+makerId);
	  if(makerId != null && !loginUserId.equals(makerId)){
		getLogger().debug("Exit of the method  checkMakerForApprove() from DiscountApprovalSummaryBean");
	    return true;
	  }else{
	    disReqStatus = resourceManager.getMessage(ErrorConstants.MAKER_CHECK_APPROVE);
		addToActionErrorMeaasge(disReqStatus, discRefNo);
		getLogger().debug("Exit of the method  checkMakerForApprove() from DiscountApprovalSummaryBean");
		return false;
	  }
	}


	/**
	 * Check maker for reject.
	 *
	 * @param loginUserId the login user id
	 * @param makerId the maker id
	 * @param discountStatus the discount status
	 * @param discRefNo the disc ref no
	 * @return true, if successful
	 */
	private boolean checkMakerForReject(String loginUserId, String makerId, String discountStatus, String discRefNo) {
	  getLogger().debug("Entering the method  checkMakerForReject() from checkMakerForReject with the Logged In user id "+loginUserId+" for the Discount reference Number "+discRefNo+" With Maker Id "+makerId);
	  if(discountStatus.equals(StatusConstants.DISCOUNT_PENDING_APPROVAL)){	
	    if(makerId != null && (makerId.equalsIgnoreCase(StatusConstants.SYSTEM) || loginUserId.equals(makerId))){
	      getLogger().debug("Exit of the method  checkMakerForReject() from DiscountApprovalSummaryBean");
		  return true;
	    }else{
	      disReqStatus = resourceManager.getMessage(ErrorConstants.MAKER_CHECK_REJECT);
		  addToActionErrorMeaasge(disReqStatus, discRefNo);
		  getLogger().debug("Exit of the method  checkMakerForReject() from DiscountApprovalSummaryBean");
		  return false;
	    }
	  }
	  getLogger().debug("Exit of the method  checkMakerForReject() from DiscountApprovalSummaryBean");
	  return true;
	}
	
	/**
	 * Reject.
	 */
	public List<ErrorMessageVO> reject(List<DiscountRequestVO> discVOList, UserInfoVO user){
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering the method reject() from DiscountApprovalSummaryBean");
	  DiscountRequestVO discountRequestVO = new DiscountRequestVO ();
	  try{
	    
	    selectedList=discVOList;	  
	    setUserId(user.getUserId());
	    setUserTypeID(user.getUserTypeId());  
	    initializeMultiSelectVariables();
/*		if(checkRowSelected() ){*/
		  if(selectedList.size() > 1){
		    openMultiSelectPopup = true;
		  }
		  Iterator<DiscountRequestVO> selectedListIterator = selectedList.iterator();
		  while(selectedListIterator.hasNext()){
		    discountRequestVO = selectedListIterator.next();
		    getLogger().debug("The Discount request details from the method reject() "+discountRequestVO);
			rejectDiscountRequest(discountRequestVO,user);
			if(openMultiSelectPopup && resourceManager.getMessage(ErrorConstants.REJECT_SUCCESS).equalsIgnoreCase(disReqStatus)){
			  actionPopupMeaasge.add(disReqStatus +BNPConstants.LINE_SEPARATOR +discountRequestVO.getDiscountRefNo());
			    ErrorMessageVO objErrorMessageVO  = new ErrorMessageVO();
			    objErrorMessageVO.setUniqueID(discountRequestVO.getDiscountRefNo());
			    objErrorMessageVO.setMessage(disReqStatus +BNPConstants.LINE_SEPARATOR +discountRequestVO.getDiscountRefNo());
			    objErrorMessageVO.setError(false);
			    errorMessageHelper.getErrorMessageVOList().add(objErrorMessageVO);
			}
		  }
		  addErrorAndWarnMsgToMultiselActionPopup();
	      if (errorMessageHelper.getErrorMessageVOList().size()==0){
				  addActionPopupMessages(disReqStatus, discountRequestVO.getDiscountRefNo(),false);
		  }

		  refreshTableGrid();
/*		}else{
		  disReqStatus = null;
		}*/
	  }catch (Exception exception) {
		getLogger().error("Exception occured whil executing method reject() in DiscountApprovalSummaryBean : {} "+exception);
	   // displayErrorMessage(exception.getErrorCode());
		disReqStatus = resourceManager.getMessage(ErrorConstants.REJECT_FAILURE);
	    addActionPopupMessages(disReqStatus +BNPConstants.LINE_SEPARATOR +discountRequestVO.getDiscountRefNo(), discountRequestVO.getDiscountRefNo(),true);
	  }
	  getLogger().debug("Exit of the method reject() from DiscountApprovalSummaryBean");
	  _logTimeTaken(startTime,(System.nanoTime()),"reject()");
	  //return actionPopupMeaasge;
	  return errorMessageHelper.getErrorMessageVOList();   

	}
	
	/**
	 * Reject discount request.
	 *
	 * @param discountRequestVO the discount request vo
	 */
	public void rejectDiscountRequest(DiscountRequestVO discountRequestVO,UserInfoVO user){
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering the method rejectDiscountRequest() from DiscountApprovalSummaryBean");
	  try{
	    if(approvalInfo != null) setApprovalInfo(null); // to avoid approval info message retaining in the instance
		  String discountStatus = discountRequestVO.getDiscountStatus();
		  //928747 Changes for CSCDEV-6169 Start
		  //Map<String, Object> resultMap = limitCheckService.processLMSConcurrencyRequest(null,discountRequestVO.getSenderOrgId(),null,BNPConstants.REJECT_DISCOUNT,false);
		  Map<String, Object> resultMap = limitCheckService.processLMSConcurrencyRequest(discountRequestVO.getSenderOrgId(),null,BNPConstants.REJECT_DISCOUNT);
		  String lkId = (String)resultMap.get("LK_ID");
		  //928747 Changes for CSCDEV-6169 End

		  boolean wasLocked = (Boolean)resultMap.get("IS_LOCKED");
		  getLogger().debug("The Discount request details from the method rejectDiscountRequest() "+discountRequestVO);
		  try {
		    if(!wasLocked) {
			  if(validateRecordForReject(discountStatus, discountRequestVO.getDiscountRefNo()) && checkMakerForReject(getUserId(), discountRequestVO.getMakerId(), discountStatus, discountRequestVO.getDiscountRefNo())){
			    if(StatusConstants.DISCOUNT_PENDING_APPROVAL.equals(discountStatus)){
				  rejectApprovePendingRequest(discountRequestVO,getUserId(),user);
				}else{
				  setAccessLogDetails(ScreenConstants.ACCESS_LOG_DISCOUNT_REJECT ,discountRequestVO.getDiscountRefNo(),user );
				  rejectBuyerAcceptanceRecord(discountRequestVO,getUserId());
				}
				triggerEventLog(discountRequestVO,"REJECT");
				disReqStatus = resourceManager.getMessage(ErrorConstants.REJECT_SUCCESS);
			  }
			}else{
			  disReqStatus = (String)resultMap.get("LOCKED_BY_PROCESS") + " " + resourceManager.getMessage(ErrorConstants.LMS_CONCURRENCY_ERROR);
			  addToActionErrorMeaasge(disReqStatus, discountRequestVO.getDiscountRefNo());	 
			}
		  }finally{
		    if(!wasLocked){
			  try {
				//928747 Changes for CSCDEV-6169 Start  
			    //limitCheckService.unlockLMSConcReq(null,discountRequestVO.getSenderOrgId(),false);
			    limitCheckService.unlockLMSConcReq(lkId);
			    //928747 Changes for CSCDEV-6169 End
			  }catch(BNPApplicationException exception){
				getLogger().error("Exception occured whil executing method rejectDiscountRequest() in DiscountApprovalSummaryBean : {} "+exception);
				disReqStatus = resourceManager.getMessage(ErrorConstants.REJECT_FAILURE);
				//addToActionErrorMeaasge(disReqStatus, discountRequestVO.getDiscountRefNo());
			    ErrorMessageVO objErrorMessageVO  = new ErrorMessageVO();
			    objErrorMessageVO.setUniqueID(discountRequestVO.getDiscountRefNo());
			    objErrorMessageVO.setMessage(disReqStatus);
			    objErrorMessageVO.setError(true);
			    errorMessageHelper.getErrorMessageVOList().add(objErrorMessageVO);
			  }
			}
		  }
	    }catch (BNPApplicationException exception) {
	      getLogger().error("BNPApplicationException occured whil executing method rejectDiscountRequest() in DiscountApprovalSummaryBean : {} "+exception);
		  disReqStatus = resourceManager.getMessage(ErrorConstants.REJECT_FAILURE);
		 // addToActionErrorMeaasge(disReqStatus, discountRequestVO.getDiscountRefNo());
		    ErrorMessageVO objErrorMessageVO  = new ErrorMessageVO();
		    objErrorMessageVO.setUniqueID(discountRequestVO.getDiscountRefNo());
		    objErrorMessageVO.setMessage(disReqStatus);
		    objErrorMessageVO.setError(true);
		    errorMessageHelper.getErrorMessageVOList().add(objErrorMessageVO);
		}
	    getLogger().debug("Exit the method rejectDiscountRequest() from DiscountApprovalSummaryBean");
	    _logTimeTaken(startTime,(System.nanoTime()),"rejectDiscountRequest()");
	  }

	/**
	 * Reject buyer acceptance record.
	 *
	 * @param discountRequestVO the discount request vo
	 * @param userId the user id
	 * @throws BNPApplicationException the BNP application exception
	 */
	private void rejectBuyerAcceptanceRecord(DiscountRequestVO discountRequestVO, String userId) throws BNPApplicationException{
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering the method rejectBuyerAcceptanceRecord() from DiscountApprovalSummaryBean");
	  getLogger().debug("The Discount request details from the method rejectBuyerAcceptanceRecord() "+discountRequestVO);
	  if(ScreenConstants.BUYER_ACCEPT_REQUIRED_WITHOUT_APPROVAL.equals(discountRequestVO.getDiscBuyerAcceptReqd())){
	    discountService.rejectAndApproveBuyerAcceptanceRecord(discountRequestVO, userId);
	  }else if(ScreenConstants.BUYER_ACCEPT_REQUIRED_WITH_APPROVAL.equals(discountRequestVO.getDiscBuyerAcceptReqd())){
	    discountService.rejectBuyerAcceptanceRecord(discountRequestVO, userId);
	  }
	  getLogger().debug("Exit of the method rejectBuyerAcceptanceRecord() from DiscountApprovalSummaryBean");
	  _logTimeTaken(startTime,(System.nanoTime()),"rejectBuyerAcceptanceRecord()");
	}

	/**
	 * Refresh table grid.
	 *
	 * @throws BNPApplicationException the BNP application exception
	 */
	private void refreshTableGrid() throws BNPApplicationException {
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering the method refreshTableGrid() from DiscountApprovalSummaryBean");
	  //populateTableData();
	  userInfoVO=null;
	  clearDataList();
	  clearVO();
	  getLogger().debug("Exit the method refreshTableGrid() from DiscountApprovalSummaryBean");
	  _logTimeTaken(startTime,(System.nanoTime()),"refreshTableGrid()");
	}

	
	/**
	 * Reject approve pending request.
	 *
	 * @param discountRequestVO the discount request vo
	 * @param makerId the maker id
	 * @throws BNPApplicationException the BNP application exception
	 */
	private void rejectApprovePendingRequest(DiscountRequestVO discountRequestVO, String makerId,UserInfoVO user) throws BNPApplicationException{
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering the method rejectApprovePendingRequest() from DiscountApprovalSummaryBean");
	  getLogger().debug("The Discount request details from the method rejectApprovePendingRequest() "+discountRequestVO);
	  setAccessLogDetails(ScreenConstants.ACCESS_LOG_DISCOUNT_REJECT, discountRequestVO.getDiscountRefNo(),user);
	  discountRequestService.rejectApprovePendingRequest(discountRequestVO, makerId);
	  getLogger().debug("Exit of the method rejectApprovePendingRequest() from DiscountApprovalSummaryBean");
	  _logTimeTaken(startTime,(System.nanoTime()),"rejectApprovePendingRequest()");
	}
	
/*	public String viewRecordDetails() {
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering the method viewRecordDetails() from DiscountApprovalSummaryBean");
	  super.populateNextRecord();
	  String toPage=null;
	  if(checkRowSelected()) {
	    if(null != dataVO.getDiscountRefNo() && !dataVO.getDiscountRefNo().isEmpty()){
		//a37126 - Added Fortify Issue - Portability Flaw: Locale Dependent Comparison
		  String discRefSearchType = dataVO.getDiscountRefNo().toUpperCase(Locale.getDefault()).startsWith(ScreenConstants.BATCHING_REFNO_INITIAL)?
				  ScreenConstants.BATCHING_REFNO_INITIAL : BNPConstants.DISCOUNT_REQUEST_STARTS_WITH_DP;
		  selectedData.setSearchType(discRefSearchType);
		}
	    if(selectedData.getCalcConfInterestAmt()!=null){
	    	selectedData.setCalcConfDiscAmtConverted(formatBigDecimal(selectedData.getCalcConfInterestAmt()));
	    }
	    if(selectedData.getIndicativeDiscountAmt()!=null){
	    	selectedData.setIndDiscAmtConverted(formatBigDecimal(selectedData.getIndicativeDiscountAmt()));
	    }
	    if(selectedData.getConfDiscAmt()!=null){
	    	selectedData.setConfDiscAmtConverted(formatBigDecimal(selectedData.getConfDiscAmt()));
	    }
	    summaryBean.getDiscountDetails(selectedData,getScreenConstant());
	    getLogger().debug("The Discount request details from the method viewRecordDetails() dataVO :: "+dataVO);
	    getLogger().debug("The Discount request details from the method viewRecordDetails() selectedData :: "+selectedData);
	    toPage = getViewPage();
	  }
	  getLogger().debug("Exit of method viewRecordDetails() from DiscountApprovalSummaryBean");
	  _logTimeTaken(startTime,(System.nanoTime()),"viewRecordDetails()");
	  return toPage;
	}*/
	
	@Override
	public void populateTableData() throws BNPApplicationException {
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering the method populateTableData() from DiscountApprovalSummaryBean");
	  setUserDetails();
	  setDefaultStatus();
	  rowCount = null;			
	  dataVO.setStartRow(0);
	  dataVO.setEndRow(null);
	  validateUserDetailsForBuyer();
	  if (dataVO.getUserType() != null) {
	    dataVO.setSearchOrPopulate(BNPConstants.LOADING);
		tableDataList = discountRequestService.getDiscountApproveSummary(dataVO);
	  }
	  getLogger().debug("The Discount request details from the method populateTableData() dataVO :: "+dataVO);
	  getLogger().debug("Exit of the method populateTableData() from DiscountApprovalSummaryBean");
	  _logTimeTaken(startTime,(System.nanoTime()),"populateTableData()");
	}	
	
/*    public void clearData(ActionEvent event) {
      getLogger().debug("Entering the method clearData() from DiscountApprovalSummaryBean");
	  try{
	    UIComponent component = event.getComponent();
		Iterator<UIComponent> children = component.getParent().getParent().getParent().getChildren().iterator();
		while (children.hasNext()) {
		  UIComponent child = children.next();
		  if (child != component) {
		    children.remove();
		  }
		}
		clearDataList();
		populateTableData();
		clearVO();
	  }catch(BNPApplicationException exception){
	    getLogger().error("BNPApplicationException Occured while executing the method clearData() in DiscountApprovalSummaryBean :: {} ",exception);
	    displayErrorMessage(exception.getErrorCode());
	  }
	  getLogger().debug("Exit of the method clearData() from DiscountApprovalSummaryBean");
	}*/
       
/*	public String getViewDetailsFromLink(){
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering the method getViewDetailsFromLink() from DiscountApprovalSummaryBean");
	  if(null != dataVO.getDiscountRefNo() && !dataVO.getDiscountRefNo().isEmpty()){
	  //a37126 - Added Fortify Issue - Portability Flaw: Locale Dependent Comparison
	    String discRefSearchType = dataVO.getDiscountRefNo().toUpperCase(Locale.getDefault()).startsWith(ScreenConstants.BATCHING_REFNO_INITIAL)?
	    		ScreenConstants.BATCHING_REFNO_INITIAL : BNPConstants.DISCOUNT_REQUEST_STARTS_WITH_DP;
		selectedData.setSearchType(discRefSearchType);
	  }
	  if(selectedData.getCalcConfInterestAmt()!=null){
	  selectedData.setCalcConfDiscAmtConverted(formatBigDecimal(selectedData.getCalcConfInterestAmt()));
	  }
	  if(selectedData.getIndicativeDiscountAmt()!=null){
	    	selectedData.setIndDiscAmtConverted(formatBigDecimal(selectedData.getIndicativeDiscountAmt()));
	  }
	  if(selectedData.getConfDiscAmt()!=null){
	    	selectedData.setConfDiscAmtConverted(formatBigDecimal(selectedData.getConfDiscAmt()));
	  }
	  getLogger().debug("The Discount request details from the method populateTableData() dataVO :: "+dataVO);
	  getLogger().debug("The Discount request details from the method populateTableData() selectedData :: "+selectedData);
	  summaryBean.getDiscountDetails(selectedData,getScreenConstant());
	  getLogger().debug("Exit of the method getViewDetailsFromLink() from DiscountApprovalSummaryBean");
	  _logTimeTaken(startTime,(System.nanoTime()),"getViewDetailsFromLink()");
	  return getDetailsPage();
	}*/
		
	/**
	 * Gets the details page.
	 *
	 * @return the details page
	 */
	private String getDetailsPage() {
	  return "/facelets/discount/DiscountRequestSummary.xhtml";
	}
	
	/**
	 * Validate due date.
	 *
	 * @param dueDate the due date
	 * @return true, if successful
	 */
	private boolean validateDueDate(Date dueDate){
	  getLogger().debug("Entering the method validateDueDate() from DiscountApprovalSummaryBean");
	  long currentDateMillis = BNPDiscountUtil.getDateWithoutTime(
	  Calendar.getInstance().getTime());
	  long dueDateInMillis=BNPDiscountUtil.getDateWithoutTime(dueDate);
	  if(dueDateInMillis<=currentDateMillis){
	    return false;
	  }
	  getLogger().debug("Exit of the method validateDueDate() from DiscountApprovalSummaryBean");
	  return true;
	}
	
	/**
	 * Validate due date for approve.
	 *
	 * @param dueDate the due date
	 * @param discRefNo the disc ref no
	 * @return true, if successful
	 */
	private boolean validateDueDateForApprove(Date dueDate, String discRefNo){
	  getLogger().debug("Entering the method validateDueDateForApprove() from DiscountApprovalSummaryBean with Due Date "+dueDate+" and reference Number "+discRefNo);
	  boolean isValid=validateDueDate(dueDate);
	  if(!isValid){
	    disReqStatus=resourceManager.getMessage(ErrorConstants.CANNOT_APPORVE_DUEDATE_INVALID);
		addToActionErrorMeaasge(disReqStatus, discRefNo);
	  }
	  getLogger().debug("Exit of the method validateDueDateForApprove() from DiscountApprovalSummaryBean");
	  return isValid;
	}


	/**
	 * Sets the access log details.
	 *
	 * @param actionName the action name
	 * @param discrefNo the discref no
	 * @throws BNPApplicationException the BNP application exception
	 */
	private void setAccessLogDetails(String actionName , String discrefNo,UserInfoVO uservo) throws BNPApplicationException {
	  getLogger().debug("Entering the method setAccessLogDetails() from DiscountApprovalSummaryBean");
	  //HttpServletRequest request= (HttpServletRequest)FacesContext.getCurrentInstance().getExternalContext().getRequest();
	  AbstractVO abstractVO=new AbstractVO();
	  abstractVO.setCurrentUserId(uservo.getUserId());
	  abstractVO.setSessionId(uservo.getSessionId());
	  abstractVO.setCheckPoint(propertyLoader.getValue(actionName));
	  //String screenId= loginBean.getUserVO().getSelectedLink();
	  //abstractVO.setCheckPoint("TRANSMENU");
	  abstractVO.setScreenId(getScreenConstant());
  	  if(selectedData != null){
  	    abstractVO.setModifiedData(selectedData.toString());  
  	  }
	  abstractVO.setAccessLogRefNo(discrefNo);
	  insertAccessLogDetails(abstractVO);
	  getLogger().debug("Exit of the method setAccessLogDetails() from DiscountApprovalSummaryBean");
	}
		
	/**
	 * Insert access log details.
	 *
	 * @param abstractVO the abstract vo
	 * @throws BNPApplicationException the BNP application exception
	 */
	private void insertAccessLogDetails(AbstractVO abstractVO)throws BNPApplicationException {
	  getLogger().debug("Entering and Exit of the method setAccessLogDetails() from DiscountApprovalSummaryBean");
	  accessLogService.insertAccessLog(abstractVO);
	}


	@Override
	public void addSelectedData() {
	  super.addSelectedData();
	  if(selectedList.size()==1){
	    selectedData = selectedList.get(0);
	  }
	}
	
	/**
	 * Checks if is valid contains.
	 *
	 * @param autoCompleteMap the auto complete map
	 * @param keyItem the key item
	 * @return true, if is valid contains
	 */
	private boolean isValidContains(Map<String, List<NameValueVO>> autoCompleteMap,String keyItem){
	  if(autoCompleteMap != null && autoCompleteMap.containsKey(keyItem)){
	    return true;
	  }else{
	    return false;
	  }
	}

	/* (non-Javadoc)
	 * @see com.bnp.bnpux.discounting.serviceImpl.AbstractServiceImpl#getAutoCompleteSearchData(java.lang.String)
	 */
	protected List<NameValueVO> getAutoCompleteSearchData(String attribute) {
	  getLogger().debug("Entering of the method getAutoCompleteSearchData() from DiscountApprovalSummaryBean");
	  List<NameValueVO> autoCompleteDataList = new ArrayList<NameValueVO>();
	  if ("currency".equals(attribute) && isValidContains(getAutoCompleteMap(),"CURRENCY_LIST")) {
	    autoCompleteDataList.addAll(getAutoCompleteMap().get("CURRENCY_LIST"));    
	  } else if ("supplierID".equals(attribute) && isValidContains(getAutoCompleteMap(),"SUPPLIER_ORG_IDS")) {
	    autoCompleteDataList.addAll(getAutoCompleteMap().get("SUPPLIER_ORG_IDS"));
	  } else if ("buyerID".equals(attribute) && isValidContains(getAutoCompleteMap(),"BUYER_ORG_IDS")) {
	    autoCompleteDataList.addAll(getAutoCompleteMap().get("BUYER_ORG_IDS"));
	  }
	  getLogger().debug("Exit of method getAutoCompleteSearchData() from DiscountApprovalSummaryBean");
	  return autoCompleteDataList;
	 }
			
	/**
	 * Proceed approve discount request.
	 */
	public ApproveResponseVo proceedApproveDiscountRequest(List<DiscountRequestVO> discVOList, UserInfoVO user, ApproveRequestVo apprvReqVo){
	  initializeMultiSelectVariables();
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering of the method proceedApproveDiscountRequest() from DiscountApprovalSummaryBean");
	  ApproveResponseVo apprvdResListVO = new ApproveResponseVo(); //Added for CSC-5697 - message population error on concurrent usage
	  selectedList=discVOList;	  
	  setUserId(user.getUserId());
	  setUserTypeID(user.getUserTypeId());
	  //Added below for fortify fix - Do not maintain sigleton object
	  tempDataDiscountRequestVO = apprvReqVo.getTempDiscReqVO();
	  if(tempDataDiscountRequestVO != null){
		effectiveDiscountDate =tempDataDiscountRequestVO.getEffectiveDiscountDate();
		getLogger().debug("The Discount request details from the method populateTableData() proceedApproveDiscountRequest :: "+tempDataDiscountRequestVO);
	    if(validateDiscountStatusForCutoff(tempDataDiscountRequestVO.getDiscountStatus()) && checkMakerForApprove(getUserId(), tempDataDiscountRequestVO.getMakerId(), tempDataDiscountRequestVO.getDiscountRefNo())
		  && validateDueDateForApprove(tempDataDiscountRequestVO.getDueDate(), tempDataDiscountRequestVO.getDiscountRefNo()) && checkMakerTypeForSupplierApprove(tempDataDiscountRequestVO)){
	      getLogger().debug("Discount Date  has been updated as the cutoff was passed :: start");
		  //Modifying the DiscountDate for since the cutoff is passed
		  try {
		    setProductType(tempDataDiscountRequestVO);
			tempDataDiscountRequestVO.setDiscountDate(effectiveDiscountDate);
			if(BNPDiscountUtil.isMultiBankingModel(tempDataDiscountRequestVO.getMbModel())){
			  tempDataDiscountRequestVO.setTpDiscounts(tpDiscReqService.getTPDiscountFromTransForDiscApproval(tempDataDiscountRequestVO.getDiscountRequestId()));// change Done on 11-Apr-2014
			}
			tempDataDiscountRequestVO.setRefreshRatesFromDiscReqScreen(true);
			discountRequestService.recalculateDiscountRequest(tempDataDiscountRequestVO);
			int validateError = discountRequestService.validateDiscountRequest(tempDataDiscountRequestVO, null);
			if(validateError==0){
			  getLogger().debug("Discount Date has been updated as the cutoff was passed");
			  getLogger().debug("Updating the Recalculated values to the T_DISC_REQUEST_TEMP_DETAILS since cutoff passed:: start");
			  discountRequestDAO.updateTempDetailsDiscountRequest(tempDataDiscountRequestVO);
			  getLogger().debug("Updating the Recalculated values to the T_DISC_REQUEST_TEMP_DETAILS since cutoff passed:: end");
			  getLogger().debug("Discount Date  has been updated as the cutoff was passed :: Now Approving the record :: start");
			  //setAccessLogDetails(ScreenConstants.ACCESS_LOG_DISCOUNT_APPROVE , tempDataDiscountRequestVO.getDiscountRefNo());
			  setAccessLogDetails(ScreenConstants.ACCESS_LOG_DISCOUNT_APPROVE ,tempDataDiscountRequestVO.getDiscountRefNo(),user);
			  approveRecord(tempDataDiscountRequestVO);
			  disReqStatus = resourceManager.getMessage(ErrorConstants.APPROVE_SUCCESS);
			  setApprovalInfo(getDiscountDetailsToDisplay(tempDataDiscountRequestVO));
			  //getDiscountDetailsToDisplayNewUX(tempDataDiscountRequestVO);
			  refreshTableGrid();
			  getLogger().debug("Discount Date  has been updated as the cutoff was passed :: Now Approving the record :: end");
			}
			LOGGER.debug("Discount Date  has been updated as the cutoff was passed :: Now Approving the record :: end");
		    tempDataDiscountRequestVO=null;
			if(validateError > 0){			
			  throw new BNPApplicationException(validateError);
			}
			getLogger().debug("Discount Date  has been updated as the cutoff was passed :: end");
		  }catch(Exception exception){
		    getLogger().error("Exception in :: Discount Date has been updated as the cutoff was passed :: {} ",exception);
		  }
		  }
	    }else{
		  disReqStatus=resourceManager.getMessage(ErrorConstants.SELECT_SINGLE_RECORD);
		}
	    getLogger().debug("Exit of the method proceedApproveDiscountRequest() from DiscountApprovalSummaryBean");
	    _logTimeTaken(startTime,(System.nanoTime()),"proceedApproveDiscountRequest()");
		  //apprvdResListVO.setCutOffValidationVO(cutOffValdVO);
	      apprvdResListVO.setapproveGridListVO(apprvdResGridListVO);
	      apprvdResListVO.seterrMessageVO( errorMessageHelper.getErrorMessageVOList());
	      return apprvdResListVO;
	  }
		
	  /**
  	 * Cut off validator.
  	 *
  	 * @param requestVO the request vo
  	 * @return true, if successful
  	 * @throws BNPApplicationException the BNP application exception
  	 */
  	private boolean cutOffValidator(DiscountRequestVO requestVO) throws BNPApplicationException{
  		getLogger().debug("Entering method cutOffValidator() from DiscountApprovalSummaryBean");
	    boolean isCutOffTimeOver = false;
		cuttOffPassed="N";
		cuttOffPreviousDay="N";
		getLogger().debug("cutOffValidator of DiscountApprovalSummaryBean :: start");
		Date origDiscDate = requestVO.getDiscountDate();
		discReqVO = new DiscountRequestVO();
		try {
		  getLogger().debug("Cloning DiscountRequestVO for redirection Approve or not");
		  Object discReqVOObj = BeanUtils.cloneBean((Object)requestVO);
		  discReqVO = (DiscountRequestVO)discReqVOObj;
		  getLogger().debug("The Discount request details from the method cutOffValidator() discReqVO :: "+discReqVO);
		}catch(IllegalAccessException exception){
		  getLogger().error("IllegalAccessException during Cloning DiscountRequestVO for redirection Approve or not :: {}",exception);
		  throw new BNPApplicationException(ErrorConstants.APPROVE_FAILURE);
		}catch(InstantiationException exception){
		  getLogger().error("InstantiationException during Cloning DiscountRequestVO for redirection Approve or not:: {}",exception);
		  throw new BNPApplicationException(ErrorConstants.APPROVE_FAILURE);
		}catch(InvocationTargetException exception)	{
		  getLogger().error("InvocationTargetException during Cloning DiscountRequestVO for redirection Approve or not:: {}",exception);
		  throw new BNPApplicationException(ErrorConstants.APPROVE_FAILURE);
		}catch(NoSuchMethodException exception){
		  getLogger().error("NoSuchMethodException during Cloning DiscountRequestVO for redirection Approve or not:: {}",exception);
		  throw new BNPApplicationException(ErrorConstants.APPROVE_FAILURE);
		}
		getLogger().debug("Cloning DiscountRequestVO success");
		//effectiveDiscountDate = discountRequestServiceImpl.getEffectiveDiscountDate(requestVO);
		effectiveDiscountDate = discountRequestService.getEffectiveDiscountDate(requestVO);
		getLogger().debug("Dates EffectiveDiscountDate="+effectiveDiscountDate+" and OriginalDiscountDate="+origDiscDate);
		long diffDays = BNPDiscountUtil.calculateTenure(origDiscDate,effectiveDiscountDate);
		if(diffDays != 0){
		  isCutOffTimeOver = true;
		  disReqStatus = "EXT_CUT_OFF_TIME_OVER";
		}else{
		  isCutOffTimeOver = false;
		}
		getLogger().debug("Exit method cutOffValidator() from DiscountApprovalSummaryBean");
		return isCutOffTimeOver;
	  }
			
	/**
	 * Refresh table grid cancel.
	 */
  	public void refreshTableGridCancel() {
  		getLogger().debug("Entering method refreshTableGridCancel() from DiscountApprovalSummaryBean");
	    try{
		  refreshTableGrid();
		}catch (BNPApplicationException exception) {
		  getLogger().error("Exception Occured whil executing method refreshTableGridCancel() in DiscountApprovalSummaryBean with exception :: {} ", exception);
		  disReqStatus = resourceManager.getMessage(ErrorConstants.CANCEL_FAILURE);
		}
	    getLogger().debug("Exit method refreshTableGridCancel() from DiscountApprovalSummaryBean");
	  }
			
		
	/**
	 * Return discount request.
	 */
  	public List<ErrorMessageVO> returnDiscountRequest(List<DiscountRequestVO> discVOList, UserInfoVO user, ApproveRequestVo apprvReqVo){
  	  long startTime = System.nanoTime();
  	  getLogger().debug("Entering method returnDiscountRequest() from DiscountApprovalSummaryBean"); 
	    selectedList=discVOList;	  
	    setUserId(user.getUserId());
	    setUserTypeID(user.getUserTypeId());  
		try{
		  disReqStatus=null;
		  //Added below session attributes for fortify fix - Do not maintain sigleton object
		  tempDataDiscountRequestVO = apprvReqVo.getTempDiscReqVO();
		  if(tempDataDiscountRequestVO != null) {
			getLogger().debug("The Discount request details from the method returnDiscountRequest() tempDataDiscountRequestVO :: "+tempDataDiscountRequestVO);
		    String discountStatus = tempDataDiscountRequestVO.getDiscountStatus();
			if(validateDiscountStatusForCutoff(discountStatus) && checkMakerForReturn(getUserId(), tempDataDiscountRequestVO.getMakerId(), discountStatus)){
			  //setAccessLogDetails(ScreenConstants.ACCESS_LOG_DISCOUNT_REJECT , tempDataDiscountRequestVO.getDiscountRefNo());
			  if(StatusConstants.DISCOUNT_PENDING_APPROVAL.equals(discountStatus)){ 
				  discountRequestService.returnApprovePendingRequest(tempDataDiscountRequestVO, tempDataDiscountRequestVO.getMakerId());
			  }else{ // For Buyer Acceptance Record Return
				  discountRequestService.returnApproveBuyerAcceptRecord(tempDataDiscountRequestVO, getUserId());
			  }
			  disReqStatus = resourceManager.getMessage(ErrorConstants.RETURN_SUCCESS);
		      ErrorMessageVO objErrorMessageVO  = new ErrorMessageVO();	  
		      objErrorMessageVO.setUniqueID(tempDataDiscountRequestVO.getDiscountRefNo());
			  objErrorMessageVO.setMessage(disReqStatus);
			  objErrorMessageVO.setError(false);
			  errorMessageHelper.getErrorMessageVOList().add(objErrorMessageVO);
			  //refreshTableGrid();
			  tempDataDiscountRequestVO=null;
			}
		  }else{
		    disReqStatus=resourceManager.getMessage(ErrorConstants.SELECT_SINGLE_RECORD);
		  }
		 }catch (BNPApplicationException exception) {
		  getLogger().error("BNPApplicationException Occured whil executing method returnDiscountRequest with exception : {} ", exception); 
		   disReqStatus = resourceManager.getMessage(ErrorConstants.REJECT_FAILURE);
			  disReqStatus = resourceManager.getMessage(ErrorConstants.RETURN_SUCCESS);
		      ErrorMessageVO objErrorMessageVO  = new ErrorMessageVO();	  
		      objErrorMessageVO.setUniqueID(tempDataDiscountRequestVO.getDiscountRefNo());
			  objErrorMessageVO.setMessage(disReqStatus);
			  objErrorMessageVO.setError(true);
			  errorMessageHelper.getErrorMessageVOList().add(objErrorMessageVO);
		 }
		getLogger().debug("Exit of method returnDiscountRequest() from DiscountApprovalSummaryBean"); 
		_logTimeTaken(startTime,(System.nanoTime()),"returnDiscountRequest()");
		  return errorMessageHelper.getErrorMessageVOList();   
	  }
			
	
  	/**
  	 * Sets the product type.
  	 *
  	 * @param discountRequestVO the new product type
  	 */
  	private void setProductType(DiscountRequestVO discountRequestVO){
	  if("Payments".equals(discountRequestVO.getDocType())){
	    discountRequestVO.setProductType(BNPConstants.PAYABLE);
	  }else {
	    discountRequestVO.setProductType(BNPConstants.RECEIVABLE);
	  }
	 }	

	/**
	 * Check maker for return.
	 *
	 * @param loginUserId the login user id
	 * @param makerId the maker id
	 * @param discountStatus the discount status
	 * @return true, if successful
	 */
	private boolean checkMakerForReturn(String loginUserId, String makerId, String discountStatus) {
	  boolean isValid = true;
	  if(! StatusConstants.PENDING_BUYER_ACCEPTANCE.equals(discountStatus)){	
	    if(makerId != null && !loginUserId.equals(makerId) ){
		  isValid = true;
		}else{
		  disReqStatus = resourceManager.getMessage(ErrorConstants.MAKER_CHECK_RETURN);
		  isValid = false;
		}
	  }	
	  return isValid;
	}
			
	/**
	 * Disable buttons on cancel.
	 */
/*	public void disableButtonsOnCancel() {
	  populateEntitlementDetails();
	}*/

	/**
	 * Validate record for buyer acceptance approval.
	 *
	 * @param discountRequestVO the discount request vo
	 * @return true, if successful
	 * @throws BNPApplicationException the BNP application exception
	 */
	private boolean validateRecordForBuyerAcceptanceApproval(DiscountRequestVO discountRequestVO) throws BNPApplicationException{
	  boolean isValid = true;
	  if(isSupplierUser()){
	    isValid = false;
		disReqStatus = resourceManager.getMessage(ErrorConstants.SUPPLIER_CANNOT_APPROVE_BUYER_ACCEPT);
	  }
	  if(isBuyerUser() && ScreenConstants.BANK_ADMIN.equals(getUserTypeForBuyerAccept(discountRequestVO.getAcceptOrRejectBy()))){
	    isValid = false;
		disReqStatus = resourceManager.getMessage(ErrorConstants.BUYER_CANNOT_APPROVE_BANK_ADMIN_RECORD);
	  }
	  return isValid;
	}
			
	/**
	 * Gets the user type for buyer accept.
	 *
	 * @param userId the user id
	 * @return the user type for buyer accept
	 * @throws BNPApplicationException the BNP application exception
	 */
	private String getUserTypeForBuyerAccept(String userId) throws BNPApplicationException {
	  return discountService.getUserTypeForBuyerAccept(userId);
	}
			
	/**
	 * Check maker type for supplier approve.
	 *
	 * @param discountRequestVO the discount request vo
	 * @return true, if successful
	 */
	private boolean checkMakerTypeForSupplierApprove(DiscountRequestVO discountRequestVO){
	  boolean isValid = true;
	  try {
	    if(isSupplierUser() && ScreenConstants.Y.equalsIgnoreCase(discountRequestVO.getAllowDiscRateNeg()) && discountRequestVO.getNegotiatedRate() != null 
		  && ScreenConstants.BANK_ADMIN.equals(getUserTypeForBuyerAccept(discountRequestVO.getMakerId()))){
		    isValid = false;
			disReqStatus = resourceManager.getMessage(ErrorConstants.SUPPLIER_CANNOT_APPROVE_NEG_RATE_RECORD);
			addToActionErrorMeaasge(disReqStatus, discountRequestVO.getDiscountRefNo());						
		}
	  } catch (BNPApplicationException exception) {
		getLogger().error("Exception Occured while Executing the method checkMakerTypeForSupplierApprove :: {} ",exception);
	    disReqStatus = resourceManager.getMessage(ErrorConstants.APPROVE_FAILURE);
		addToActionErrorMeaasge(disReqStatus, discountRequestVO.getDiscountRefNo());				
	  }
	  return isValid;
	}
			
	/**
	 * Accepts the selected list of buyer acceptance required discounts 
	 */
public ApproveResponseVo accept(List<DiscountRequestVO> discVOList, UserInfoVO user){
	  long startTime = System.nanoTime();
	  getLogger().debug("Extering method accept() from DiscountApprovalSummaryBean"); 
	  ErrorMessageVO errorVO=new ErrorMessageVO();
	  ApproveResponseVo apprvdResListVO = new ApproveResponseVo(); //Added for CSC-5697 - message population error on concurrent usage
	  selectedList=discVOList;	  
	  userInfoVO=user;
	  setUserId(user.getUserId());
	  setUserTypeID(user.getUserTypeId());
	  String disRefNo = null;
	  tempDataDiscountRequestVO=null;  
	  
	  try{
		  initializeMultiSelectVariables();				
		//if(checkRowSelected() ){
		  if(selectedList.size() > 1){	
			  openMultiSelectPopup = true;
		  }
		  //Iterator<DiscountRequestVO> selectedListIterator = selectedList.iterator();
		  ListIterator<DiscountRequestVO> selectedListIterator = selectedList.listIterator();
		  synchronized (this) {
		  while(selectedListIterator.hasNext()){
			 DiscountRequestVO discountReqVO = selectedListIterator.next();
			 DiscountRequestVO discountRequestVO =null;
			 discountRequestVO=discountReqVO;
		     disRefNo=discountRequestVO.getDiscountRefNo();
		    getLogger().debug("The Discount request details from the method accept() discountRequestVO :: "+discountRequestVO);
			 //acceptDiscountRequest(discountRequestVO);
		    if(approvalInfo != null){ 
				  setApprovalInfo(null); 
				}
				if(validateRecordForAccept(discountRequestVO)){
				  getLogger().debug("The Discount request details from the method acceptDiscountRequest() discountRequestVO :: "+discountRequestVO);
				  //setAccessLogDetails(ScreenConstants.ACCESS_LOG_DISCOUNT_ACCEPT,discountRequestVO.getDiscountRefNo());
				  setAccessLogDetails(ScreenConstants.ACCESS_LOG_DISCOUNT_ACCEPT ,discountRequestVO.getDiscountRefNo(),userInfoVO );
				  acceptBuyerAcceptanceRecord(discountRequestVO);
				}
			if(openMultiSelectPopup && resourceManager.getMessage(ErrorConstants.ACCEPT_SUCCESS).equalsIgnoreCase(disReqStatus)){ 
			  actionPopupMeaasge.add(disReqStatus +BNPConstants.LINE_SEPARATOR +discountRequestVO.getDiscountRefNo());
			  addActionPopupMessages(discountRequestVO.getDiscountRefNo(), disReqStatus/* +BNPConstants.LINE_SEPARATOR +discountRequestVO.getDiscountRefNo()*/, false);
			}
			//setAccessLogDetails("ACCEPT",discountRequestVO.getDiscountRefNo());
			setAccessLogDetails("ACCEPT" ,discountRequestVO.getDiscountRefNo(),user );
		  }
		  }
		 addErrorAndWarnMsgToMultiselActionPopup();
		  if(!openMultiSelectPopup){
			  if(tempDataDiscountRequestVO!=null){
				  cutOffValdVO = new  CutOffValidationVO();
				  cutOffValdVO.setDiscBuyerAcceptReqd(tempDataDiscountRequestVO.getDiscBuyerAcceptReqd());
				  cutOffValdVO.setDiscountRefNo(tempDataDiscountRequestVO.getDiscountRefNo());
			  }else if(errorMessageHelper.getErrorMessageVOList().size()==0){
				  addActionPopupMessages(disReqStatus, disRefNo,false);
			  }
		  }
		  refreshTableGrid();
	  }catch (BNPApplicationException exception) {
		getLogger().error("Exception Occured while Ececuting the method accept :: {} ",exception);
	    disReqStatus = resourceManager.getMessage(ErrorConstants.ACCEPT_FAILURE);
	    addActionPopupMessages(disRefNo, disReqStatus, true);
	  }catch (Exception exception) {
		getLogger().error("Exception Occured while Ececuting the method accept :: {} ",exception);
	    disReqStatus = resourceManager.getMessage(ErrorConstants.ACCEPT_FAILURE);
	    addActionPopupMessages(disRefNo, disReqStatus, true);
	  }
	  getLogger().debug("Exiting method accept() from DiscountApprovalSummaryBean");
	  _logTimeTaken(startTime,(System.nanoTime()),"accept()");
	  apprvdResListVO.setCutOffValidationVO(cutOffValdVO);
      apprvdResListVO.setapproveGridListVO(apprvdResGridListVO);
      apprvdResListVO.seterrMessageVO( errorMessageHelper.getErrorMessageVOList());
      return apprvdResListVO;
	}
	
	/**
	 * Accept discount request.
	 *
	 * @param discountRequestVO the discount request vo
	 */
	public void acceptDiscountRequest(DiscountRequestVO discountRequestVO){
	  long startTime = System.nanoTime();
	  getLogger().debug("Extreing method acceptDiscountRequest() from DiscountApprovalSummaryBean");
	  try{
	    if(approvalInfo != null){ 
		  setApprovalInfo(null); 
		}
		if(validateRecordForAccept(discountRequestVO)){
		  getLogger().debug("The Discount request details from the method acceptDiscountRequest() discountRequestVO :: "+discountRequestVO);
		  //setAccessLogDetails(ScreenConstants.ACCESS_LOG_DISCOUNT_ACCEPT,discountRequestVO.getDiscountRefNo());
		  setAccessLogDetails(ScreenConstants.ACCESS_LOG_DISCOUNT_ACCEPT ,discountRequestVO.getDiscountRefNo(),userInfoVO );
		  acceptBuyerAcceptanceRecord(discountRequestVO);
		}
	  }catch (BNPApplicationException e) {
	    disReqStatus = resourceManager.getMessage(ErrorConstants.ACCEPT_FAILURE);
		LOGGER.error(e.getMessage(),e);
		addToActionErrorMeaasge(disReqStatus, discountRequestVO.getDiscountRefNo());
		addActionPopupMessages(discountRequestVO.getDiscountRefNo(), disReqStatus, true);
	  }
	  getLogger().debug("Exiting method acceptDiscountRequest() from DiscountApprovalSummaryBean");
	  _logTimeTaken(startTime,(System.nanoTime()),"acceptDiscountRequest()");
	}

	/**
	 * Accept buyer acceptance record.
	 *
	 * @param discountRequestVO the discount request vo
	 * @throws BNPApplicationException the BNP application exception
	 */
  public void acceptBuyerAcceptanceRecord(DiscountRequestVO discountRequestVO) throws BNPApplicationException {
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering method acceptBuyerAcceptanceRecord() from DiscountApprovalSummaryBean");
	  getLogger().debug("The Discount request details from the method acceptBuyerAcceptanceRecord() discountRequestVO :: "+discountRequestVO);
	  if(ScreenConstants.BUYER_ACCEPT_REQUIRED_WITHOUT_APPROVAL.equals(discountRequestVO.getDiscBuyerAcceptReqd())){
	    if(isBankUser() && cutOffValidator(discountRequestVO)) {
		  cutOffExceddedDiscRefNo.add(discountRequestVO.getDiscountRefNo());
		  tempDataDiscountRequestVO=discountRequestVO;
		  LOGGER.debug("Cutoff exceeded");
		}else{
		  discountService.approveDiscReqForBuyerAcceptance(discountRequestVO, getUserId());
		  disReqStatus = resourceManager.getMessage(ErrorConstants.ACCEPT_SUCCESS);
		  //getDiscountDetailsToDisplayNewUX(discountRequestVO);
		}
	  }else if(ScreenConstants.BUYER_ACCEPT_REQUIRED_WITH_APPROVAL.equals(discountRequestVO.getDiscBuyerAcceptReqd())){
	    discountService.acceptBuyerAcceptanceRecord(discountRequestVO,getUserId());
		disReqStatus = resourceManager.getMessage(ErrorConstants.ACCEPT_SUCCESS);
	  }
	  getLogger().debug("Exit of method acceptBuyerAcceptanceRecord() from DiscountApprovalSummaryBean");
	  _logTimeTaken(startTime,(System.nanoTime()),"acceptBuyerAcceptanceRecord()");
	}

	/**
	 * Validate record for accept.
	 *
	 * @param discountRequestVO the discount request vo
	 * @return true, if successful
	 * @throws BNPApplicationException the BNP application exception
	 */
	private boolean validateRecordForAccept(DiscountRequestVO discountRequestVO) throws BNPApplicationException{
	  boolean isValid =true;
	
	  if(!StatusConstants.PENDING_BUYER_ACCEPTANCE.equals(discountRequestVO.getDiscountStatus())){  
	    disReqStatus = resourceManager.getMessage(ErrorConstants.DISC_APPR_SUMMARY_CANNOT_ACCEPT_RECORD);
		addToActionErrorMeaasge(disReqStatus, discountRequestVO.getDiscountRefNo());
		
		isValid = false;
	  }else if(isBuyerUser() && cutOffValidator(discountRequestVO)){
	    disReqStatus = resourceManager.getMessage(ErrorConstants.DISC_APPR_SUMMARY_BUYER_ACCEPT_CUTOFF_ERROR);
	    addToActionErrorMeaasge(disReqStatus, discountRequestVO.getDiscountRefNo());
		cutOffExceddedDiscRefNo.add(discountRequestVO.getDiscountRefNo());
		refreshTableGrid();
		isValid = false;
	  }
	 
	  return isValid;
	}

	/**
	 * Checks if is pending approval record.
	 *
	 * @param discountRequestVO the discount request vo
	 * @return true, if is pending approval record
	 */
	private boolean isPendingApprovalRecord(DiscountRequestVO discountRequestVO) {
	  boolean isValid =false;
	  if(isSupplierUser() && StatusConstants.DISCOUNT_PENDING_APPROVAL.equals(discountRequestVO.getDiscountStatus()) &&	!isBuyerAcceptReqd(discountRequestVO)){
	    isValid = true;
	  }else if(isBankUser() && (StatusConstants.DISCOUNT_PENDING_APPROVAL.equals(discountRequestVO.getDiscountStatus()) ||
	    StatusConstants.PENDING_BUYER_ACCEPTANCE_APPROVAL.equals(discountRequestVO.getDiscountStatus()) )){
		isValid = true;
	  }
	  return isValid;
	}
		
	/**
	 * Validate discount status for cutoff.
	 *
	 * @param discountStatus the discount status
	 * @return true, if successful
	 */
	private boolean validateDiscountStatusForCutoff(String discountStatus) {
	  boolean isValid = true;
	  if(isSupplierUser()){
	    if(! StatusConstants.DISCOUNT_PENDING_APPROVAL.equals(discountStatus) ){
		  disReqStatus = resourceManager.getMessage(ErrorConstants.CANNOT_APPROVE_RECORD);
		  isValid = false;
		}
	  }else if(isBuyerUser()){
	    if(! StatusConstants.PENDING_BUYER_ACCEPTANCE.equals(discountStatus) 
	      &&  ! StatusConstants.PENDING_BUYER_ACCEPTANCE_APPROVAL.equals(discountStatus)){
		  isValid = false;
		  disReqStatus = resourceManager.getMessage(ErrorConstants.CANNOT_APPROVE_RECORD);
		 }
	  }else if(isBankUser()){
	    if(! StatusConstants.PENDING_BUYER_ACCEPTANCE_APPROVAL.equals(discountStatus) && ! StatusConstants.PENDING_BUYER_ACCEPTANCE.equals(discountStatus)
		  && ! StatusConstants.DISCOUNT_PENDING_APPROVAL.equals(discountStatus)){ 
		  disReqStatus = resourceManager.getMessage(ErrorConstants.CANNOT_APPROVE_RECORD);
		  isValid = false;
		}
	  }
	  return isValid;
	}
		
	/**
	 * Checks if is buyer accept reqd.
	 *
	 * @param disocuntRequestVO the disocunt request vo
	 * @return true, if is buyer accept reqd
	 */
	private boolean isBuyerAcceptReqd(DiscountRequestVO disocuntRequestVO){
	  if(disocuntRequestVO.getDiscBuyerAcceptReqd() == null || ScreenConstants.BUYER_ACCEPT_NOT_REQUIRED.equals(disocuntRequestVO.getDiscBuyerAcceptReqd())){
	    return false;
	  }
	  return true;
	}
		
	/**
	 * Checks if is buyer user.
	 *
	 * @return true, if is buyer user
	 */
	private boolean isBuyerUser(){
	  return BNPConstants.BUYER.equals(getUserTypeID());
	}
		
	/**
	 * Checks if is supplier user.
	 *
	 * @return true, if is supplier user
	 */
	private boolean isSupplierUser(){
	  return BNPConstants.SUPPLIER.equals(getUserTypeID());
	}
		
	/**
	 * Checks if is bank user.
	 *
	 * @return true, if is bank user
	 */
	private boolean isBankUser(){
	  return BNPConstants.BANKADMIN.equals(getUserTypeID());
	}

	/**
	 * Undo The Specific Record.
	 */
	public void undo(){
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering method undo() from DiscountApprovalSummaryBean");
	  try{
	    initializeMultiSelectVariables();				
		if(checkRowSelected() ){
		  if(selectedList.size() > 1){	
		    openMultiSelectPopup = true;
		  }
		  Iterator<DiscountRequestVO> selectedListIterator = selectedList.iterator();
		  while(selectedListIterator.hasNext()){
		    DiscountRequestVO discountRequestVO = selectedListIterator.next();
		    getLogger().debug("The Discount request details from the method undo() discountRequestVO :: "+discountRequestVO);
			undoRecord(discountRequestVO);	
			if(openMultiSelectPopup && resourceManager.getMessage(ErrorConstants.UNDO_SUCCESS).equalsIgnoreCase(disReqStatus)){ 
			  actionPopupMeaasge.add(disReqStatus +BNPConstants.LINE_SEPARATOR +discountRequestVO.getDiscountRefNo());
			}
		  }
		  addErrorAndWarnMsgToMultiselActionPopup();
		  refreshTableGrid();
		}else{
		  disReqStatus = null;
		}
	  }catch (BNPApplicationException exception) {
		getLogger().error("Exception Occured whil executing method undo in DiscountApprovalSummaryBean with exception :: {} ", exception);
	    disReqStatus = resourceManager.getMessage(ErrorConstants.ACCEPT_FAILURE);
	  }
	  getLogger().debug("Exit of method undo() from DiscountApprovalSummaryBean");
	  _logTimeTaken(startTime,(System.nanoTime()),"undo()");
	}
		
	/**
	 * Undo record.
	 *
	 * @param discountRequestVO the discount request vo
	 */
	public void undoRecord(DiscountRequestVO discountRequestVO){
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering method undoRecord() from DiscountApprovalSummaryBean");
	  try{
		if(approvalInfo != null) setApprovalInfo(null);
		if(validateRecordForUndo(discountRequestVO)){
		  getLogger().debug("The Discount request details from the method undoRecord() discountRequestVO :: "+discountRequestVO);
		  //setAccessLogDetails(ScreenConstants.ACCESS_LOG_DISCOUNT_REQUEST_UNDO ,discountRequestVO.getDiscountRefNo());
		  undoBuyerAcceptanceRecord(discountRequestVO,getUserId());
		  disReqStatus = resourceManager.getMessage(ErrorConstants.UNDO_SUCCESS);
		 }
	   }catch (BNPApplicationException exception) {
		 getLogger().error("Exception Occured whil executing method undoRecord in DiscountApprovalSummaryBean with exception :: {} ", exception);
	     disReqStatus = resourceManager.getMessage(ErrorConstants.REJECT_FAILURE);
	   }
	   getLogger().debug("Exit of method undoRecord() from DiscountApprovalSummaryBean");
	   _logTimeTaken(startTime,(System.nanoTime()),"undoRecord()");
	  }

	/**
  	 * Undo buyer acceptance record.
  	 *
  	 * @param discountRequestVO the discount request vo
  	 * @param userId the user id
  	 * @throws BNPApplicationException the BNP application exception
  	 */
  	private void undoBuyerAcceptanceRecord(DiscountRequestVO discountRequestVO, String userId) throws BNPApplicationException{
	  discountService.undoBuyerAcceptanceRecord(discountRequestVO, userId);
	}

	/**
	 * Validate record for undo.
	 *
	 * @param discountRequestVO the discount request vo
	 * @return true, if successful
	 */
	private boolean validateRecordForUndo(DiscountRequestVO discountRequestVO) {
	  getLogger().debug("Entering  method validateRecordForUndo() from DiscountApprovalSummaryBean witn status :: "+discountRequestVO.getDiscountStatus());
	  String discountStatus = discountRequestVO.getDiscountStatus();
	  getLogger().debug("The Discount request details from the method undoRecord() validateRecordForUndo :: "+discountRequestVO);
	  boolean isvalid = true;
	  if(! StatusConstants.PENDING_BUYER_ACCEPTANCE_APPROVAL.equals(discountStatus) && ! StatusConstants.PENDING_BUYER_REJECTION_APPROVAL.equals(discountStatus)){
	    disReqStatus = resourceManager.getMessage(ErrorConstants.DISC_STATUS_ERROR_FOR_BUYER_ACCEPT_UNDO);
		addToActionErrorMeaasge(disReqStatus, discountRequestVO.getDiscountRefNo());
		isvalid = false;
	  }else if(!getUserId().equals(discountRequestVO.getMakerId())){
	    disReqStatus = resourceManager.getMessage(ErrorConstants.MAKER_CHECK_UNDO);
		addToActionErrorMeaasge(disReqStatus, discountRequestVO.getDiscountRefNo());
		isvalid = false;
	  }
	  getLogger().debug("Exit of method validateRecordForUndo() from DiscountApprovalSummaryBean");
	  return isvalid;
	}

	public int getSearchDataCount(){
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering method getSearchDataCount() from DiscountApprovalSummaryBean");
	  Integer count=0;
	  try{
		setUserDetails();
	    validateUserDetailsForBuyer();
	    if (dataVO.getUserType() != null) {
		  dataVO.setStartRow(null);
		  dataVO.setEndRow(null);
		  dataVO.setSearchOrPopulate(BNPConstants.SEARCH);
		  getLogger().debug("The Discount request details from the method getSearchDataCount() dataVO :: "+dataVO);
		  count = discountRequestService.getSearchDataCountForDiscApprSumm(dataVO);
	    }
	  }catch(BNPApplicationException exception){
	    LOGGER.error("Exception occured whil executing the method getSearchDataCount() :: {} ",exception);
		displayErrorMessage(exception.getErrorCode());
	  }
	  getLogger().debug("Exit of method getSearchDataCount() from DiscountApprovalSummaryBean wth count "+count);
	  _logTimeTaken(startTime,(System.nanoTime()),"getSummarySearchData()");
	  return count;
	}
					
	/* (non-Javadoc)
	 * @see com.bnp.bnpux.discounting.serviceImpl.AbstractServiceImpl#getSummarySearchData()
	 */
	public void getSummarySearchData(){
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering method getSummarySearchData() from DiscountApprovalSummaryBean");
	  try{
	    dataVO.setSearchOrPopulate(BNPConstants.SEARCH);
	    getLogger().debug("The Discount request details from the method getSummarySearchData() dataVO :: "+dataVO);
		if(CacheConstants.SEARCH_TYPE_FUNDING.equalsIgnoreCase(dataVO.getSearchType())){
		  exportList = discountRequestService.searchFundReleaseDetailSummary(dataVO);
		}else{
		  exportList = discountRequestService.searchDiscountDetailSummary(dataVO);				
		}
	  }catch(BNPApplicationException exception){
	    getLogger().error("Exception occured whil executing the method getSummarySearchData() :: {} ",exception);
		displayErrorMessage(exception.getErrorCode());
	  }
	  getLogger().debug("Exit of method getSummarySearchData() from DiscountApprovalSummaryBean");
	  _logTimeTaken(startTime,(System.nanoTime()),"getSummarySearchData()");
	}
			
	/*public List<String> getListToExport() {
	  long startTime = System.nanoTime();
	  getLogger().debug("Entering method getListToExport() from DiscountApprovalSummaryBean");
	  List<String> listToExport = new ArrayList<String>();
	  listToExport.add(getTableHeader(ScreenConstants.EXPORT_SUMMARY_TABLE_ID));
	  for(DiscountRequestVO discountRequestVO : exportList){
	    StringBuilder builder = new StringBuilder();
		builder.append(getStringValue(discountRequestVO.getSellerOrgId()));
		builder.append(getStringValue(discountRequestVO.getBuyerOrgId()));
		builder.append(getStringValue(discountRequestVO.getDiscountStatus()));
		builder.append(getStringValue(discountRequestVO.getDocType()));
		if(CacheConstants.SEARCH_TYPE_FUNDING.equalsIgnoreCase(dataVO.getSearchType())){
		  builder.append(getStringValue(discountRequestVO.getExtndDiscountRefNo()));
		  builder.append(getStringValue(discountRequestVO.getBuyerRefNo()));
		}else{
		  builder.append(getStringValue(discountRequestVO.getDiscountRefNo()));
		  builder.append(getStringValue(discountRequestVO.getSellerRefNo()));
		}
		builder.append(getStringValue(discountRequestVO.getPaymentCurrencyCode()));
		builder.append(getStringValue(discountRequestVO.getDueDate()));
		builder.append(getStringValue(discountRequestVO.getDiscountDate()));
		builder.append(getStringValue(discountRequestVO.getDiscountTenure()));
		builder.append(getStringValue(discountRequestVO.getOriginalAmt().toPlainString()));
//		if(discountRequestVO.getOriginalAmt()!=null){
//			builder.append(getStringValue(discountRequestVO.getOriginalAmt().toPlainString()));
//		}else{
//			builder.append(getStringValue(discountRequestVO.getOriginalAmt().toPlainString()));
//		}
		if(discountRequestVO.getAvailableAmt()!=null){
			builder.append(getStringValue(discountRequestVO.getAvailableAmt().toPlainString()));
		}else{
			builder.append(getStringValue(discountRequestVO.getAvailableAmt()));
		}
		if(BNPConstants.BANKADMIN.equals(getUserTypeID()) && BNPConstants.Y.equals(discountRequestVO.getAllowDiscRateNeg()) && discountRequestVO.getNegotiatedRate() != null){
		  builder.append(getStringValue(discountRequestVO.getIndicativeDiscountRate() + resourceManager.getMessageValue("bnp.discount.common.neg.indicative.discountrate")));
		}else{
		  builder.append(getStringValue(discountRequestVO.getIndicativeDiscountRate()));
		}
		if(discountRequestVO.getIndicativeDiscountAmt()!=null){
			builder.append(getStringValue(discountRequestVO.getIndicativeDiscountAmt().toPlainString()));
		}else{
			builder.append(getStringValue(discountRequestVO.getIndicativeDiscountAmt()));
		}
		if(BNPConstants.BANKADMIN.equals(getUserTypeID())){
		  builder.append(getStringValue(discountRequestVO.getMinDiscFeeApplied()));
		}else if(BNPConstants.SUPPLIER.equals(getUserTypeID()) && isMinDiscFeeEnable()){ 
		  builder.append(getStringValue(discountRequestVO.getMinDiscFeeApplied()));
		}
		if(discountRequestVO.getIndicativeChargeAmt()!=null)
		{
			builder.append(getStringValue(discountRequestVO.getIndicativeChargeAmt().toPlainString()));
		}else{
			builder.append(getStringValue(discountRequestVO.getIndicativeChargeAmt()));
		}
		if(discountRequestVO.getIndicativeNetAmt()!=null){
			builder.append(getStringValue(discountRequestVO.getIndicativeNetAmt().toPlainString()));
		}else{
			builder.append(getStringValue(discountRequestVO.getIndicativeNetAmt()));
		}
		builder.append(getStringValue(discountRequestVO.getFinancingBank()));
		if(CacheConstants.SEARCH_TYPE_FUNDING.equalsIgnoreCase(dataVO.getSearchType())){
		  builder.append(getStringValue(discountRequestVO.getRemarks()));
		}
		builder.append(getStringValue(discountRequestVO.getConfDiscRate()));
		if(discountRequestVO.getConfDiscAmt()!=null){
			builder.append(getStringValue(discountRequestVO.getConfDiscAmt().toPlainString()));
		}else{
			builder.append(getStringValue(discountRequestVO.getConfDiscAmt()));
		}
		if(discountRequestVO.getConfirmedChargeAmt()!=null){
			builder.append(getStringValue(discountRequestVO.getConfirmedChargeAmt().toPlainString()));
		}else{
			builder.append(getStringValue(discountRequestVO.getConfirmedChargeAmt()));
		}
		if(discountRequestVO.getConfNetAmount()!=null){
			builder.append(getStringValue(discountRequestVO.getConfNetAmount().toPlainString()));
		}else{
			builder.append(getStringValue(discountRequestVO.getConfNetAmount()));
		}
		listToExport.add(builder.toString());
		}
	    getLogger().debug("Exit of method getListToExport() from DiscountApprovalSummaryBean");
	    _logTimeTaken(startTime,(System.nanoTime()),"getListToExport()");
	    return listToExport;
	  }*/
	
		/**
		 * Adds the error message to multi select popup error message list
		 * 
		 * @param message
		 * @param discRefNo
		 */
		private void addToActionErrorMeaasge(String message, String discRefNo){
		  if(openMultiSelectPopup){
		    actionErrorMeaasge.add(message +BNPConstants.LINE_SEPARATOR +discRefNo);
		    ErrorMessageVO objErrorMessageVO  = new ErrorMessageVO();
		    objErrorMessageVO.setUniqueID(discRefNo);
		    objErrorMessageVO.setMessage(message +BNPConstants.LINE_SEPARATOR +discRefNo);
		    objErrorMessageVO.setError(false);
		    errorMessageHelper.getErrorMessageVOList().add(objErrorMessageVO);
		  }
		}
		
		/**
		 *Initialize the multiselect variables 
		 */
		private void initializeMultiSelectVariables(){
		  openMultiSelectPopup = false;
		  actionPopupMeaasge = new ArrayList<String>();
		  actionErrorMeaasge = new ArrayList<String>();
		  cutOffExceddedDiscRefNo = new ArrayList<String>();
		  //apprvdResListVO = new ApproveResponseVo(); //Modified for CSC-5697 - message population error on concurrent usage 
  		  ErrorMsgVOList = new ArrayList<ErrorMessageVO>();
		  apprvdResGridListVO  = new ArrayList<ApproveResponseGridVo>();;
		  errorMessageHelper.setErrorMessageVOList(new ArrayList<ErrorMessageVO>());
		  cutOffValdVO = null;
		}
		
		/**
		 * Adds the error message and warning to multi select popup message
		 */
		private void addErrorAndWarnMsgToMultiselActionPopup() {
		  if(openMultiSelectPopup){
		    actionPopupMeaasge.addAll(actionErrorMeaasge);
			if(cutOffExceddedDiscRefNo != null && cutOffExceddedDiscRefNo.size() > 0){
			  actionPopupMeaasge.add(resourceManager.getMessage(ErrorConstants.DISC_APPR_MULTISEL_CUTOFF_MSG) + BNPConstants.LINE_SEPARATOR +cutOffExceddedDiscRefNo.toString());
			  addActionPopupMessages(cutOffExceddedDiscRefNo.toString(), resourceManager.getMessage(ErrorConstants.DISC_APPR_MULTISEL_CUTOFF_MSG) /*+ BNPConstants.LINE_SEPARATOR +cutOffExceddedDiscRefNo.toString()*/, false);
			}
		  }
		}
		
		public void getConfDiscMinFeeDetails(){
			if(selectedData != null && selectedData.getCalcConfDiscAmtConverted() == null && selectedData.getCalcConfInterestAmt() != null){ 
				selectedData.setCalcConfDiscAmtConverted(formatBigDecimal(selectedData.getCalcConfInterestAmt()));
			}
			
		}
		
		private String formatBigDecimal(BigDecimal Value) {
			String str;
			int decimalCount = selectedData.getFractionalDigits();	
			DecimalFormat df = new DecimalFormat("#,###,###,##0.###"); 
			df.setMinimumFractionDigits(decimalCount); 
			df.setMaximumFractionDigits(decimalCount);
			str=df.format(Value);
			return str; 

		}
		
		/**
		 * Export summary data.
		 */
	/*	public void exportSummaryData(){
		  showExportThresholdPopup = false;	
		  List<String> listToExport=null;
		  try{
			dataVO.setStartRow(0);
			dataVO.setEndRow(exportThreshold);
			getSummarySearchData();
			setExportDelimiter();
			listToExport = getListToExport();
			if(BNPConstants.XLS_FORMAT.equalsIgnoreCase(getExportButtonValue())){
			  exportSummaryDataToXLS(listToExport);
			}else if (BNPConstants.CSV_FORMAT.equalsIgnoreCase(getExportButtonValue())){
			  exportSummaryDataToCSV(listToExport);
			}else if(BNPConstants.PDF_FORMAT.equalsIgnoreCase(getExportButtonValue())){
			  String docHeader =  ReportConstants.DISC_APPROVE_SUMMARY_EXPORT;
			  List<Object> objectInstance = new ArrayList<Object>();
			  objectInstance.addAll(exportList);
			  byte[] fileContends = exportUtil.getExportDataUsingJRXML(objectInstance, docHeader, getUserId());
			  FacesContext context = getFacesContext().getCurrentInstance();
			  HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();
			  HttpSession session = request.getSession();
			  session.setAttribute(BNPConstants.ZIP_FILE_ATTRIBUTE,fileContends);
			  session.setAttribute(BNPConstants.FILE_TYPE,exportButtonValue);
			  session.setAttribute(BNPConstants.FILE_NAME,getExportFileName());
			  session.setAttribute(BNPConstants.DOWNLOAD_STREAM, BNPConstants.ATTACHMENT);
			}
			dataVO.setOpenFile(true);
		  }catch (BNPApplicationException exception) {
		    LOGGER.error("Exception Occured while executing exportSummaryData() Method in AbstractBean :: {} ",exception);
			displayErrorMessage(ErrorConstants.EXPORT_EXCEPTOPN_OCCURED);
		  }
		  finally{
			  listToExport=null;
		  }
		}*/
		
		private void setExportDelimiter() {
			if (BNPConstants.CSV_FORMAT.equalsIgnoreCase(getExportButtonValue())){
				setExportDelimiter(BNPConstants.COMMA_DELIMITER);
			}else {
				setExportDelimiter(BNPConstants.SEMI_COLON);
			}
	    }
		
		private boolean validateRecordForApproveCancel(String discountStatus) {
			if(discountStatus.equals(StatusConstants.CANCEL_PENDING_FOR_APPROVAL)){
				return true;
			}
			else{
				disReqStatus = resourceManager.getMessage(ErrorConstants.CANNOT_APPROVE_CANCEL_RECORD);
				return false;
			}
	  }
		
		private boolean checkMakerForApproveCancel(String loginUserId, String makerId) {
			if(makerId != null && !loginUserId.equals(makerId)){
				return true;
			}
			else{
				disReqStatus = resourceManager.getMessage(ErrorConstants.MAKER_CHECK_APPROVE_CANCEL);
				return false;
			}
		}
		

	
	
	}