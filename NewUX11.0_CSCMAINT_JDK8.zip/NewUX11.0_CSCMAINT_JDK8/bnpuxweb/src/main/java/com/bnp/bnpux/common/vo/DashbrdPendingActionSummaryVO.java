/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   19-Aug-2017
 * 
 * Purpose:      Dashboard Pending Action Summary Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 19-Aug-2017				Divyashri S								To hold the summary data for Pending Action section
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.util.List;

public class DashbrdPendingActionSummaryVO {
	
	private String action;
	
	private String actionDisplay;
	
	private String screen;
	
	private String colorCode;
	
	private String actionDisplayKey;
	
	private List<DashbrdPendingActionListVO> dashbrdPendingActionListVOs;

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getActionDisplay() {
		return actionDisplay;
	}

	public void setActionDisplay(String actionDisplay) {
		this.actionDisplay = actionDisplay;
	}

	public String getScreen() {
		return screen;
	}

	public void setScreen(String screen) {
		this.screen = screen;
	}

	public String getColorCode() {
		return colorCode;
	}

	public void setColorCode(String colorCode) {
		this.colorCode = colorCode;
	}

	public List<DashbrdPendingActionListVO> getDashbrdPendingActionListVOs() {
		return dashbrdPendingActionListVOs;
	}

	public void setDashbrdPendingActionListVOs(List<DashbrdPendingActionListVO> dashbrdPendingActionListVOs) {
		this.dashbrdPendingActionListVOs = dashbrdPendingActionListVOs;
	}
	
	
	
	public String getActionDisplayKey() {
		return actionDisplayKey;
	}

	public void setActionDisplayKey(String actionDisplayKey) {
		this.actionDisplayKey = actionDisplayKey;
	}

	@Override
	public int hashCode() {
        int hashcode = 0;
        hashcode = 31*actionDisplay.hashCode();
        return hashcode;
	}
	
	@Override
	public boolean equals(Object obj) {
		boolean flag = false;
		if (obj instanceof DashbrdPendingActionSummaryVO) {
			DashbrdPendingActionSummaryVO actionSummaryVO = (DashbrdPendingActionSummaryVO) obj;
			flag = actionSummaryVO.getActionDisplay().equals(this.actionDisplay);
        }
		return flag;
	}
	
}
