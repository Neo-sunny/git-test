/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      New UX to Old UX traversal Controller
 * 
 * Change History: 
 * Date                       	Author                     	Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 31 Mar 2017					skbhaska					FO 10.0 - Fortify Fix
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.ServletConfig;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.exception.BNPAuthorizationException;
import com.bnp.bnpux.service.IAuditService;
import com.bnp.bnpux.vo.requestVO.AuditRequestVO;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;

/**
 * Servlet implementation class NewApplicationServlet
 */
public class NewtoOldController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String LOGOUT_PARAMETER = "logout";
	private static final String LANDING_PARAMETER = "landing";
	private static final String INDEX_PARAMETER = "index";
	private static String LOGOUT_URL = null;	
	private static String LANDINGPAGE_URL  = null;
	private static String INDEX_URL  = null;
	private static final String ERROR_PAGE_500 = "/error500.jsp";
	private static final String PARAMETER_PAGE = "page";
	private static final String PARAMETER_USER_ID = "USER_ID";
	private static final String PARAMETER_HEADER_USER_ID = "user_Id";
	private static final String PARAMETER_HEADER_SESSION_ID = "session_Id";
	private static final String LOG_EXCEPTION_UNABLE_TO_PROCESS = "Unable to process redirection";
	private static final String LAST_LOGIN_TIME = "LAST_LOGIN_TIME";
	private static final String PARAMETER_HEADER_LOGIN_DATE = "login_date";
	
		
	@Autowired
	private IAuditService auditService;

    /**
	 * Logger for NewtoOldController
	 */
	private static final Logger log = LoggerFactory.getLogger(NewtoOldController.class);
	
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public NewtoOldController() {
		super();
	}
	
	@Override
	public void init(ServletConfig config){
		 try {
			 super.init(config);		 
		     SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this,config.getServletContext());
		 }catch(Exception e){
			 System.out.println("Initializing servlet in NewtoOldController "+e.getMessage());
	    	 log.error("Initializing servlet in NewtoOldController "+e.getMessage());
		 }
	}
	
	/*
	 * This method is for handling get requests
	 *  
	 *  (non-Javadoc)
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		loadPropertyBean();
		HttpSession session = request.getSession();
		System.out.println("Audit Service Object is "+auditService);
		UserInfoVO userInfo  = (UserInfoVO)session.getAttribute("userInfo");
		AuditRequestVO auditVo = new AuditRequestVO();
		auditVo.setUserId(request.getParameter(PARAMETER_USER_ID));
		auditVo.setSessionId(session.getId());
		System.out.println("Org id is "+userInfo.getOrgId());
		if(userInfo!=null){
			auditVo.setOrgId(userInfo.getOrgId());
		}
		
	 	try{
	 		if(request.getParameter(PARAMETER_PAGE).equalsIgnoreCase(INDEX_PARAMETER)){
				String urlEncoded = response.encodeRedirectURL(INDEX_URL);
				response.sendRedirect(urlEncoded);
	 		}else{
			byte[] encodeUserId = Base64.encodeBase64(((String) request.getParameter(PARAMETER_USER_ID)).getBytes());
			byte[] encodeSessionId = Base64.encodeBase64(session.getId().getBytes());
			byte[] encodeDate = null;
			String lastLogin = request.getParameter(LAST_LOGIN_TIME);
			response.setHeader(PARAMETER_HEADER_USER_ID, new String(encodeUserId));
			response.setHeader(PARAMETER_HEADER_SESSION_ID, new String(encodeSessionId));
			
			if(lastLogin!=null){
				encodeDate = Base64.encodeBase64(((String) request.getParameter(LAST_LOGIN_TIME)).getBytes());
				response.setHeader(PARAMETER_HEADER_LOGIN_DATE, new String(encodeDate));
			}
			if(LOGOUT_PARAMETER.equals(request.getParameter(PARAMETER_PAGE))){
				/*if(session != null){
					session.invalidate();
				}*/
				auditVo.setFuncId("LOGOUT");
				auditService.insertAuditLog(auditVo);
			String urlEncoded = response.encodeRedirectURL(encodeURL(new String(encodeUserId),new String(encodeSessionId),LOGOUT_URL,null));
				response.sendRedirect(urlEncoded);			
			}else if(LANDING_PARAMETER.equals(request.getParameter(PARAMETER_PAGE))){
				/*if(session != null){
					session.invalidate();
				}*/
				
				auditVo.setFuncId("NEWTOOLDUX");
				auditService.insertAuditLog(auditVo);
				String urlEncoded = response.encodeRedirectURL(encodeURL(new String(encodeUserId),new String(encodeSessionId),LANDINGPAGE_URL,lastLogin));
				response.sendRedirect(urlEncoded);
			}
			}
		}catch(Exception exception){
			log.error(LOG_EXCEPTION_UNABLE_TO_PROCESS,exception);
			log.error(exception.getMessage(),exception);
			/**FO 10.0 - Fortify Fix**/
			throw new BNPAuthorizationException();
		}
	}

	/* 
	 * This method is for handling post requests
	 * 
	 * (non-Javadoc)
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try{
			doGet(request, response);
		}catch(ServletException exp){
			log.error(LOG_EXCEPTION_UNABLE_TO_PROCESS,exp);
			log.error(exp.getMessage(),exp);
		}catch(IOException exp){
			log.error(LOG_EXCEPTION_UNABLE_TO_PROCESS,exp);
			log.error(exp.getMessage(),exp);
		}
	}
	
	/**
	 * This method is for encoding urls
	 * 
	 * @param userId
	 * @param sessionId
	 * @param URL
	 * @param lastLogin
	 * @return
	 */
	private String encodeURL(String userId, String sessionId,String URL,String lastLogin ){	
		String url = null;
		if(lastLogin!=null){
		StringBuffer sb = new StringBuffer("");
		sb.append(URL);
		sb.append("?user_Id=" + userId);
		sb.append("&session_Id=" + sessionId);
		sb.append("&login_date=" + lastLogin);
		url = sb.toString();
		
		}else{
			StringBuffer sb = new StringBuffer("");
			sb.append(URL);
			sb.append("?user_Id=" + userId);
			sb.append("&session_Id=" + sessionId);
			url = sb.toString();
		}
		return url;
	}
	
	/**
	 * To load BNPPropertyLoaderConfigurer class from Spring context and set values for LOGOUT_URL and LANDINGPAGE_URL.
	 */
	private void loadPropertyBean(){
		WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(getServletContext());
		BNPPropertyLoaderConfigurer property = (BNPPropertyLoaderConfigurer)context.getBean(BNPPropertyLoaderConfigurer.class);
		NewtoOldController.parameters(property);
	}
	
	/**
	 * This method is for getting parameter values
	 *  
	 * @param property
	 */
	private static void parameters(BNPPropertyLoaderConfigurer property){
		LOGOUT_URL = property.getValue("LOGOUT_URL");	
		LANDINGPAGE_URL  = property.getValue("LANDINGPAGE_URL");
		INDEX_URL = property.getValue("INDEX_URL");
	}
}
