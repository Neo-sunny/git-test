/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  21 June 2017
 * 
 * Purpose:      Limit Utilization Request VO
 * 
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 21 June 2017       Ratna Gokhale, Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.requestVO;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.bnp.bnpux.common.vo.LimitUtilizationReportDetailsVO;
import com.bnp.bnpux.common.vo.LimitUtilizationReportVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;

public class LimitUtilizationRequestVO{
	
	private String userId;
	
	private String userType;
	
	private String branch;
	
	private String clientOrgId;
	
	private String cptyOrgId;
	
	private String limitType;
	
	private String currencyCode;

	private String getWhat;
	
	private String exportType;
	
	private String plottingParam;

	private String xAxisValue;

	private String yAxisValue;
	
	private String interactive;
	
	private List<LimitUtilizationReportVO> limitUtilizationReportList;

	private String errorMsg;
	
	private String viewType;
	
	private String recordFrom;
	
	private String recordTo;
	
	private List<LimitUtilizationReportDetailsVO> limitUtilizationReportDetails;
	
	
	private List<LimitUtilizationReportDetailsVO> entityLimitDetails;
	
	private List<LimitUtilizationReportDetailsVO> groupEntityLimitDetails;
	
	private List<LimitUtilizationReportDetailsVO> groupThirdPartyLimitDetails;
	
	private List<LimitUtilizationReportDetailsVO> thirdPartyLimitDetails;
	
	private List<LimitUtilizationReportDetailsVO> counterpartyLimitDetails;
	
	private List<LimitUtilizationReportDetailsVO> groupCounterpartyLimitDetails;
	
	private List<LimitUtilizationReportDetailsVO> groupCounterpartyThirdPartyLimitDetails;
	
	private List<LimitUtilizationReportDetailsVO> counterpartyThirdPartyLimitDetails;
	
	
	
	
	
	public List<LimitUtilizationReportDetailsVO> getEntityLimitDetails() {
		return entityLimitDetails;
	}

	public void setEntityLimitDetails(List<LimitUtilizationReportDetailsVO> entityLimitDetails) {
		this.entityLimitDetails = entityLimitDetails;
	}

	public List<LimitUtilizationReportDetailsVO> getGroupEntityLimitDetails() {
		return groupEntityLimitDetails;
	}

	public void setGroupEntityLimitDetails(List<LimitUtilizationReportDetailsVO> groupEntityLimitDetails) {
		this.groupEntityLimitDetails = groupEntityLimitDetails;
	}

	public List<LimitUtilizationReportDetailsVO> getGroupThirdPartyLimitDetails() {
		return groupThirdPartyLimitDetails;
	}

	public void setGroupThirdPartyLimitDetails(List<LimitUtilizationReportDetailsVO> groupThirdPartyLimitDetails) {
		this.groupThirdPartyLimitDetails = groupThirdPartyLimitDetails;
	}

	public List<LimitUtilizationReportDetailsVO> getThirdPartyLimitDetails() {
		return thirdPartyLimitDetails;
	}

	public void setThirdPartyLimitDetails(List<LimitUtilizationReportDetailsVO> thirdPartyLimitDetails) {
		this.thirdPartyLimitDetails = thirdPartyLimitDetails;
	}

	public List<LimitUtilizationReportDetailsVO> getCounterpartyLimitDetails() {
		return counterpartyLimitDetails;
	}

	public void setCounterpartyLimitDetails(List<LimitUtilizationReportDetailsVO> counterpartyLimitDetails) {
		this.counterpartyLimitDetails = counterpartyLimitDetails;
	}

	public List<LimitUtilizationReportDetailsVO> getGroupCounterpartyLimitDetails() {
		return groupCounterpartyLimitDetails;
	}

	public void setGroupCounterpartyLimitDetails(List<LimitUtilizationReportDetailsVO> groupCounterpartyLimitDetails) {
		this.groupCounterpartyLimitDetails = groupCounterpartyLimitDetails;
	}

	public List<LimitUtilizationReportDetailsVO> getGroupCounterpartyThirdPartyLimitDetails() {
		return groupCounterpartyThirdPartyLimitDetails;
	}

	public void setGroupCounterpartyThirdPartyLimitDetails(
			List<LimitUtilizationReportDetailsVO> groupCounterpartyThirdPartyLimitDetails) {
		this.groupCounterpartyThirdPartyLimitDetails = groupCounterpartyThirdPartyLimitDetails;
	}

	public List<LimitUtilizationReportDetailsVO> getCounterpartyThirdPartyLimitDetails() {
		return counterpartyThirdPartyLimitDetails;
	}

	public void setCounterpartyThirdPartyLimitDetails(
			List<LimitUtilizationReportDetailsVO> counterpartyThirdPartyLimitDetails) {
		this.counterpartyThirdPartyLimitDetails = counterpartyThirdPartyLimitDetails;
	}

	private List<ReportChartResponseVO> reportChartList;
	
	private String errorResult;

	public List<LimitUtilizationReportVO> getLimitUtilizationReportList() {
		return limitUtilizationReportList;
	}

	public void setLimitUtilizationReportList(List<LimitUtilizationReportVO> limitUtilizationReportList) {
		this.limitUtilizationReportList = limitUtilizationReportList;
	}

	public List<LimitUtilizationReportDetailsVO> getLimitUtilizationReportDetails() {
		return limitUtilizationReportDetails;
	}

	public void setLimitUtilizationReportDetails(List<LimitUtilizationReportDetailsVO> limitUtilizationReportDetails) {
		this.limitUtilizationReportDetails = limitUtilizationReportDetails;
	}

	public List<ReportChartResponseVO> getReportChartList() {
		return reportChartList;
	}

	public void setReportChartList(List<ReportChartResponseVO> reportChartList) {
		this.reportChartList = reportChartList;
	}

	public String getErrorResult() {
		return errorResult;
	}

	public void setErrorResult(String errorResult) {
		this.errorResult = errorResult;
	}

	public String getViewType() {
		return viewType;
	}

	public void setViewType(String viewType) {
		this.viewType = viewType;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getGetWhat() {
		return getWhat;
	}

	public void setGetWhat(String getWhat) {
		this.getWhat = getWhat;
	}

	public String getExportType() {
		return exportType;
	}

	public void setExportType(String exportType) {
		this.exportType = exportType;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public String getRecordFrom() {
		return recordFrom;
	}

	public void setRecordFrom(String recordFrom) {
		this.recordFrom = recordFrom;
	}

	public String getRecordTo() {
		return recordTo;
	}

	public void setRecordTo(String recordTo) {
		this.recordTo = recordTo;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getClientOrgId() {
		return clientOrgId;
	}

	public void setClientOrgId(String clientOrgId) {
		this.clientOrgId = clientOrgId;
	}

	public String getCptyOrgId() {
		return cptyOrgId;
	}

	public void setCptyOrgId(String cptyOrgId) {
		this.cptyOrgId = cptyOrgId;
	}

	public String getLimitType() {
		return limitType;
	}

	public void setLimitType(String limitType) {
		this.limitType = limitType;
	}

	public String getPlottingParam() {
		return plottingParam;
	}

	public void setPlottingParam(String plottingParam) {
		this.plottingParam = plottingParam;
	}

	public String getxAxisValue() {
		return xAxisValue;
	}

	public void setxAxisValue(String xAxisValue) {
		this.xAxisValue = xAxisValue;
	}

	public String getyAxisValue() {
		return yAxisValue;
	}

	public void setyAxisValue(String yAxisValue) {
		this.yAxisValue = yAxisValue;
	}

	public String getInteractive() {
		return interactive;
	}

	public void setInteractive(String interactive) {
		this.interactive = interactive;
	}
	
	
	
}
