package com.bnp.bnpux.wrappers.serviceImpl;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.common.IResourceManager;
import com.bnp.scm.services.common.ChangePasswordRequestVO;
import com.bnp.scm.services.common.IChangePasswordService;
import com.bnp.scm.services.common.IChangePasswordWrapperService;
import com.bnp.scm.services.common.SSMAuthService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.vo.UserVO;

@Component
public class ChangePasswordWrapperServiceImpl implements IChangePasswordWrapperService {
	
	public static final Logger log = LoggerFactory.getLogger(ChangePasswordWrapperServiceImpl.class);
	
	@Autowired
	private  IResourceManager resourceManager;
	
	private UserVO userVO = new UserVO();
	/*@Autowired
	private UserVO userVO;*/
	
	@Autowired
	private SSMAuthService ssmAuthService;
	
	@Autowired
	private IChangePasswordService changepasswordserviceoldUX;
	
	private String modulus;

	private String publicExponent;

	private String sessionID;
	
	/**
	 * @return the modulus
	 */
	public String getModulus() {
		return modulus;
	}
	
	/**
	 * @param modulus the modulus to set
	 */
	public void setModulus(String modulus) {
		this.modulus = modulus;
	}


	/**
	 * @return the publicExponent
	 */
	public String getPublicExponent() {
		return publicExponent;
	}

	/**
	 * @param publicExponent the publicExponent to set
	 */
	public void setPublicExponent(String publicExponent) {
		this.publicExponent = publicExponent;
	}

	/**
	 * @return the sessionID
	 */
	public String getSessionID() {
		return sessionID;
	}

	/**
	 * @param sessionID the sessionID to set
	 */
	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}
	
	//@Autowired
	//private IChangePasswordWrapperService changePasswordWrapperService;
	
	@Override
	public boolean  UpdateRecords(ChangePasswordRequestVO changePasswordRequestVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws IOException{
		
		boolean passSuccess = false;
		 try
		 {
			 String userId = changePasswordRequestVO.getUserId();
			 String userType = changePasswordRequestVO.getUserType();
			 HttpSession session = httpServletRequest.getSession(false);
			 if (session != null) {
					this.setSessionID(session.getId());
				}
			 ssmAuthService.initialize();
			 this.setPublicExponent(ssmAuthService.getPublicExponent());
			 this.setModulus(ssmAuthService.getModulus());
			 
			 String passwordArray[] = ssmAuthService.authChangePassword(userId, session.getId(), changePasswordRequestVO.getOldPassword(), changePasswordRequestVO.getNewPassword());
			 
			 if(passwordArray == null || passwordArray[0] == null)  {
				 throw new BNPApplicationException(ErrorConstants.CHNG_PWD_ENCRYPT_DECRYPT_ERROR);
			 }
			 
			 
			 if(String.valueOf(ErrorConstants.USER_LOCKED).equals(passwordArray[0])) {
				 
					 changePasswordRequestVO.setResultCode(String.valueOf(ErrorConstants.USER_LOCKED));
					 changePasswordRequestVO.setSuccessflag(true);
					 return false;
			 }

			 if(userType.equals("BA") || userType.equals("RA")){
				 changePasswordRequestVO.setUserType("Y");
			 }else{
				 changePasswordRequestVO.setUserType("N");
			 }
			 changePasswordRequestVO.setUserId(userId);
			 changePasswordRequestVO.setNewPassword(passwordArray[0]);
			 changePasswordRequestVO.setOldPassword(passwordArray[1]);
			 boolean success=changepasswordserviceoldUX.updateRecords(changePasswordRequestVO);
			 if(success){
				// UserVO userVO = new UserVO();
				 //userVO.setChangePassWordFlag(true);
				 passSuccess = true;
				 changePasswordRequestVO.setSuccessflag(true);
				 //changePasswordRequestVO.setErrMessage(resourceManager.getMessage(ErrorConstants.CHNG_PWD_SUCCESS));	
				 
			 }else{
				 changePasswordRequestVO.setSuccessflag(false);
			 }
			 //return passSuccess;
			 	
		 }
		 catch(BNPApplicationException ex)
		 {
			 log.error("Exception:" + resourceManager.getMessage(ex.errorCode));
			 changePasswordRequestVO.setSuccessflag(false);
			 changePasswordRequestVO.setErrMessage(resourceManager.getMessage(ex.errorCode));
		 }
		return passSuccess;
	}

	
}
