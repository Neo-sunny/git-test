/*****************************************************************************************************************************************************************

 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     Period Status Filter Implementation
 * 
 * Change History: 
 * Date                                                  Author                                                 Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    	Initial Version 
 * 08 Mar 2017                		skbhaska                                    								FO 10.0 - S30 - Holiday Calendar
 * 05 Jun 2017                      Bhuvaneswari Anandhan                                                       FO 10.0 -Email Inquiry Search Filter Data Population
 * 30 Jan 2018						Venkata Krishnan N J														FO 10.1 - S103002 - Period Filter Sync issue
 *****************************************************************************************************************************************************************/
package com.bnp.bnpux.serviceimpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.common.vo.AdvancedFilterVO;
import com.bnp.bnpux.constants.PaymentOrderConstants;
import com.bnp.bnpux.dao.IAdvancedFilterDAO;
import com.bnp.bnpux.dao.IPeriodStatusFilterDAO;
import com.bnp.bnpux.service.IPeriodStatusFilterService;
import com.bnp.bnpux.vo.requestVO.PaymentOrderRequestVO;
import com.bnp.bnpux.vo.requestVO.ReportRequestVO;
import com.bnp.bnpux.vo.responseVO.PeriodStatusResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
@Component
public class PeriodSatusFilterImpl implements IPeriodStatusFilterService{
	
	private static final String VIEW_TYPE = "viewType";
	/**
	 * Constant for Exception message
	 */
	public static final String EXCEPTION_UNABLE_TO_PROCESS = "Unable to process action - Database Exception";

	/**
	 * Logger log for PeriodSatusFilterImpl class
	 */
	private static final Logger log = LoggerFactory.getLogger(PeriodSatusFilterImpl.class);
	
	@Autowired
	private IPeriodStatusFilterDAO periodStatusDAO;
	
	@Autowired
	private IAdvancedFilterDAO advancedFilterDAO;
	
	/**
	 * This method is for getting Period Status Filter
	 * 
	 * @param requsetVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public List<PeriodStatusResponseVO> getPeriodStatusFilter(PaymentOrderRequestVO requsetVO) throws BNPApplicationException {
		Map<String,Object> filterMap = new HashMap<String, Object>();
		filterMap.put(PaymentOrderConstants.PAYMENT_ORDER_USER_ID, requsetVO.getUserId());
		filterMap.put(PaymentOrderConstants.PAYMENT_ORDER_USER_TYPE_ID, requsetVO.getUserType());
		filterMap.put(PaymentOrderConstants.VIEW_TYPE, requsetVO.getViewType());
		periodStatusDAO.getPeriodStatusFilter(filterMap);
		List<PeriodStatusResponseVO> filterVO = (List<PeriodStatusResponseVO>) filterMap.get("periodStatusRespone");		
		return filterVO;
	}

	/**
	 * This method is for getting Org For Branch Report
	 * 
	 * @param requsetVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public List<PeriodStatusResponseVO> getOrgForBranchReport(ReportRequestVO requsetVO)
			throws BNPApplicationException {
		Map<String,Object> filterMap = new HashMap<String, Object>();
		filterMap.put(PaymentOrderConstants.PAYMENT_ORDER_USER_ID, requsetVO.getUserId());
		filterMap.put(PaymentOrderConstants.BRANCH_ID, requsetVO.getBranch());		
		filterMap.put(PaymentOrderConstants.VIEW_TYPE, requsetVO.getViewType());
		
		
		periodStatusDAO.getOrgIdForBranchReport(filterMap);
		List<PeriodStatusResponseVO> filterVO = (List<PeriodStatusResponseVO>) filterMap.get("periodStatusRespone");		
		return filterVO;
	}
	
	/**
	 * This method is for getting Buyer Supplier Org ID For Aging Report when brach changed.
	 * 
	 * @param requsetVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public List<PeriodStatusResponseVO> getBuyerSupplierOrgIDForBranchAgingReport(ReportRequestVO requsetVO)
			throws BNPApplicationException {
		Map<String,Object> filterMap = new HashMap<String, Object>();
		filterMap.put(PaymentOrderConstants.PAYMENT_ORDER_USER_ID, requsetVO.getUserId());
		filterMap.put(PaymentOrderConstants.BRANCH_ID, requsetVO.getBranch());		
		filterMap.put(PaymentOrderConstants.VIEW_TYPE, "RPT_AGING");
		
		
		periodStatusDAO.getBuyerSupplierOrgIDForBranchAgingReport(filterMap);
		List<PeriodStatusResponseVO> filterVO = (List<PeriodStatusResponseVO>) filterMap.get("periodStatusRespone");		
		return filterVO;
	}
	
	/**
	 * This method is for getting the filter values for Holiday Calendar - FO 10.0 - S30 - Holiday Calendar
	 * 
	 * @param requsetVO
	 * @return List<PeriodStatusResponseVO>
	 * @throws BNPApplicationException
	 */
	@Override
	public List<PeriodStatusResponseVO> getPeriodStatusFilterHolidayCal(PaymentOrderRequestVO requestVO) throws BNPApplicationException {
		
		periodStatusDAO.getPeriodStatusFilterHolidayCal(requestVO);
		return requestVO.getPeriodStatusRespone();
		
	}

	@Override
	public List<PeriodStatusResponseVO> getEmailEventForBranchReport(
			ReportRequestVO requsetVO) throws BNPApplicationException {
		Map<String,Object> filterMap = new HashMap<String, Object>();

		filterMap.put(PaymentOrderConstants.PAYMENT_ORDER_USER_ID, requsetVO.getUserId());
		filterMap.put(PaymentOrderConstants.BRANCH_ID, requsetVO.getBranch());
		filterMap.put(PaymentOrderConstants.ORG_ID, requsetVO.getOrgId());
		filterMap.put(PaymentOrderConstants.PAYMENT_ORDER_USER_TYPE_ID, requsetVO.getUserType());
		periodStatusDAO.getEmailEventForBranchReport(filterMap);
		List<PeriodStatusResponseVO> filterVO = (List<PeriodStatusResponseVO>) filterMap.get("periodStatusRespone");		
		return filterVO;
	}

	@Override
	/**
	 * This method is used to get Issue Date from Period Filter selection
	 * 
	 * @param advanceFiterRequsetVO 
	 * @return advanceFiterRequsetVO
	 */
	public AdvancedFilterVO getPeriodFilterDate(AdvancedFilterVO advanceFiterRequsetVO) throws BNPApplicationException{
		try{
			//advanceFiterRequsetVO.setAdvancedFilterList(advancedFilterList);
			//Modified for S103002 - FO 10.1- Upload Invoice & Credit Notes Report screename added.
			if(!("VIEW_SCHEDULED_REPORT".equalsIgnoreCase(advanceFiterRequsetVO.getScreenName())
					|| "UPLD_INV_CN_REPORT".equalsIgnoreCase(advanceFiterRequsetVO.getScreenName())))
			{
				advanceFiterRequsetVO.setUserId(null);
			}
			advancedFilterDAO.getPeriodFilterDate(advanceFiterRequsetVO);			
			advanceFiterRequsetVO.setPeriodFromDate(advanceFiterRequsetVO.getPeriodFromDate());
			advanceFiterRequsetVO.setPeriodToDate(advanceFiterRequsetVO.getPeriodToDate());
		}catch(DataAccessException exception){
			log.error(EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(EXCEPTION_UNABLE_TO_PROCESS);	
		}		
		return advanceFiterRequsetVO;
	}
	
	/**
	 * This method is for getting Org For Branch Report
	 * 
	 * @param requsetVO
	 * @return
	 * @throws BNPApplicationException
	 */

	@Override
	public List<PeriodStatusResponseVO> getCptyOrgIdForClientReport(ReportRequestVO requsetVO)
			throws BNPApplicationException {
		Map<String,Object> filterMap = new HashMap<String, Object>();
		filterMap.put(PaymentOrderConstants.ORG_ID, requsetVO.getOrgId());
		filterMap.put(PaymentOrderConstants.PAYMENT_ORDER_USER_ID, requsetVO.getUserId());
		filterMap.put(PaymentOrderConstants.BRANCH_ID, requsetVO.getBranch());		
		filterMap.put(PaymentOrderConstants.VIEW_TYPE, requsetVO.getViewType());
		
		
		periodStatusDAO.getCptyOrgIdForClientReport(filterMap);
		List<PeriodStatusResponseVO> filterVO = (List<PeriodStatusResponseVO>) filterMap.get("periodStatusRespone");		
		return filterVO;
	}

	/**
	 * This method is for getting Plot Parameters For Limit Type
	 * 
	 * @param requsetVO
	 * @return
	 * @throws BNPApplicationException
	 */

	@Override
	public List<PeriodStatusResponseVO> getPlotParamForLmtUtlReport(ReportRequestVO requsetVO)
			throws BNPApplicationException {
		Map<String,Object> filterMap = new HashMap<String, Object>();
		filterMap.put(PaymentOrderConstants.VIEW_TYPE, requsetVO.getViewType());
		periodStatusDAO.getPlotParamForLmtUtlReport(filterMap);
		List<PeriodStatusResponseVO> filterVO = (List<PeriodStatusResponseVO>) filterMap.get("periodStatusRespone");		
		return filterVO;
	}
}
