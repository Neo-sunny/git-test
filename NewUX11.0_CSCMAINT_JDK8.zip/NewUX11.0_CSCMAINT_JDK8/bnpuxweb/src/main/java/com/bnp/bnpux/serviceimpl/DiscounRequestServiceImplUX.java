/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas.
 * 
 * Created on:   06 June 2016	
 * 
 * Purpose:      Payment Order Service Implementation
 * 
 * Change History: 
 * Date                                    Author                                                                               Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 06 June 2016						    Bala Murugan Elangovan														 	 Service Implementation 
 * *****************************************************************************************************************************************************************/
package com.bnp.bnpux.serviceimpl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.common.vo.PaymentOrderListVO;
import com.bnp.bnpux.common.vo.RecallResponseGridVO;
import com.bnp.bnpux.common.vo.RecallResponseVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.dao.IPaymentOrderDAO;
import com.bnp.bnpux.service.IDiscountServiceUX;
import com.bnp.bnpux.vo.errorMessageVO.ErrorMessageVO;
import com.bnp.bnpux.vo.responseVO.DiscountResponseVO;
import com.bnp.eipp.services.invoice.bindingvo.ErrorMessage;
import com.bnp.scm.common.IResourceManager;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.CacheConstants;
import com.bnp.scm.services.common.util.NumberFormatConversionUtil;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.discounting.IDiscountRequestService;
import com.bnp.scm.services.discounting.mb.ITPDiscRequestService;
import com.bnp.scm.services.discounting.util.BNPDiscountUtil;
import com.bnp.scm.services.discounting.vo.DiscountRequestVO;
import com.bnp.scm.services.invoice.vo.RecallInvoiceVO;
import com.bnp.scm.services.limitmgmt.ILimitCheckService;

@Component
@Scope("request")
public class DiscounRequestServiceImplUX implements IDiscountServiceUX{
	
	/**
	 * Logger log for PaymentOrderServiceImpl class
	 */
	public static final Logger log = LoggerFactory.getLogger(DiscounRequestServiceImplUX.class);
	
	/**
	 * IPaymentOrderDAO paymentOrderDAO;
	 */
	@Autowired
	private IPaymentOrderDAO paymentOrderDAO;
	
	@Autowired
	private IDiscountRequestService discountRequestService;
	
	@Autowired
	private ITPDiscRequestService tpDiscReqService;
	
	@Autowired	
	private  ILimitCheckService limitCheckService;
	
	@Autowired
	protected IResourceManager resourceManager;

	private String statusMsg;
	
	List<DiscountRequestVO> finalResultList = null;
	
	
	/**
	 * @param lDiscountRequest
	 * @param user
	 * @return DiscountRequestVO List
	 * @throws BNPApplicationException 
	 * @Description Save Discount
	 */
	public List<DiscountRequestVO> saveDiscount(List<DiscountRequestVO> lDiscountRequest, UserInfoVO user) throws BNPApplicationException {
		List<DiscountRequestVO> resultList = new ArrayList<DiscountRequestVO>();
		//Brazil changes	
		List<DiscountRequestVO> negRecordList = new ArrayList<DiscountRequestVO>();
		
	
		if(lDiscountRequest.size() == 1) {
			if(lDiscountRequest.size() == 1) {
				if(!checkAvailableAmount(lDiscountRequest.get(0))) {
					return null;
				}
			}
			
			resultList = saveDiscountRequest(lDiscountRequest, user);
			
			//selectedNegList.addAll(selList);
		}
		else {
			String key = null;
			Map<String, List<DiscountRequestVO>> grpDisc = new HashMap<String, List<DiscountRequestVO>>();
		
			for(DiscountRequestVO discReqVO : lDiscountRequest) {
				key = discReqVO.getSellerOrgId() + discReqVO.getBuyerOrgId() +  discReqVO.getPaymentCurrencyCode() 
						+ String.valueOf(BNPDiscountUtil.getDateWithoutTime(discReqVO.getDueDate())) + String.valueOf(BNPDiscountUtil.getDateWithoutTime(discReqVO.getDiscountDate()))
						+ discReqVO.getDisableSettlementPymtVal() + discReqVO.getSplProd() + discReqVO.getBillType();  // Bill Type Changes - QC 1168
				if (grpDisc.get(key) == null) {
					grpDisc.put(key, new ArrayList<DiscountRequestVO>());
				}
				grpDisc.get(key).add(discReqVO);
				
				if (isNegotiatedRateTransaction(discReqVO)) {
						negRecordList.add(discReqVO);
				}
					
				
			}
		/*	if (!negRecordList.isEmpty()
					&& negRecordList.size() != lDiscountRequest.size()) {
				showNegRatePopup = false;
				setDisableDiscountForRateNeg(false);
				displayErrorMessage(ErrorConstants.SELECT_RECORD_RATENEGO_NOT_ELIGIBLE_TRANSACTIONS);

				setResultDiscLst(null);
				return null;

			}*/
			
			Set<Map.Entry<String, List<DiscountRequestVO>>> entries = grpDisc.entrySet();
			for(Map.Entry<String, List<DiscountRequestVO>> entry : entries) {
				resultList.addAll(saveDiscountRequest(entry.getValue(),user));
	        }
			//selectedNegList.addAll(selList);
		}
		
//		if(getResultDiscLst().size()!=0) {
//			clearDataList();
//			try {
//				populateTableData();
//			}
//			catch(BNPApplicationException ex) {
//				statusMsg= resourceManager.getMessage(ErrorConstants.PROCESSING_ERROR);
//			}
//		}
//		if(getResultDiscLst().size() == 0) {
//			setResultDiscLst(null);
//		}
//		return getViewPage();
		
		return resultList;
		
	}
	
	
	/**
	 * @param selectedDiscountReqVO
	 * @return boolean
	 * @Description Check Available Amount
	 */
	private boolean checkAvailableAmount(DiscountRequestVO selectedDiscountReqVO){
		if(selectedDiscountReqVO.getAvailableAmt().doubleValue() <= 0){
			statusMsg = resourceManager.getMessage(ErrorConstants.AVAILAMT_SHOULD_GT_ZERO);
			return false;
		}else if(selectedDiscountReqVO.getAvailableAmt().compareTo(selectedDiscountReqVO.getOriginalAmt()) > 0){
			statusMsg = resourceManager.getMessage(ErrorConstants.AVAILAMT_SHOULD_LT_ORGAMT);
			return false;
		}
		else{
			return true;
		}
	}
	
	
	private boolean isNegotiatedRateTransaction(DiscountRequestVO discountRequestVO){
		boolean isValid = false;
		
		/*if(getUserTypeID().equals(BNPConstants.BANKADMIN) && StatusConstants.ALLOW_DISC_RATE_NEG_Y.equalsIgnoreCase(discountRequestVO.getAllowDiscRateNeg())){
			isValid = true;
		}*/
		return isValid;
	}
	
	
	/**
	 * @param discLst
	 * @param user
	 * @return DiscountRequestVO List
	 * @throws BNPApplicationException 
	 * @Description Save Discount Request
	 */
	public List<DiscountRequestVO> saveDiscountRequest(List<DiscountRequestVO> discLst,UserInfoVO user) throws BNPApplicationException {
		List<DiscountRequestVO> resultList = new ArrayList<DiscountRequestVO>();
		String sUserId =user.getUserId();
		String sUserType=user.getUserTypeId();
	//	String sSellerRefNo="";
		
		// Getting branch time zone
		String branchTimeZone = "";
		List<String> branchTZs = new ArrayList<String>();
		TimeZone timeZone = null;
		long currentDateMillis = 0; //getDiscountDateWithoutTime(new Date());
		List<DiscountRequestVO> tempDiscLst = null;
		boolean isValid = false;
		boolean isDiscGroupingAllowed = false;
		//showNegRatePopup=false; 
	 	Set<String> senderOrgIdSet=new HashSet<String>();
		Set<String> orgIdSet=new HashSet<String>();
		String flag = BNPConstants.SUCCESS; // Added for Fortify Issue CSCDEV -5711- Poor Error Handling: Return Inside Finally
		for (DiscountRequestVO discVO : discLst) {
			senderOrgIdSet.add(discVO.getSenderOrgId());
			orgIdSet.add(discVO.getProductType()==1?discVO.getSellerOrgId():discVO.getBuyerOrgId());
			try {	
				if(branchTZs != null && !branchTZs.contains(discVO.getSupportBranchId())){
					branchTimeZone = discountRequestService.getSupportBranchTimeZone(discVO.getSupportBranchId());
				}			
			} catch (BNPApplicationException e) {
				branchTimeZone = null;
				log.error(e.getMessage(),e);
			}
			
			if (branchTimeZone == null) {
				timeZone = TimeZone.getDefault();
			} else {
				timeZone = TimeZone.getTimeZone(branchTimeZone);
				branchTZs.add(discVO.getSupportBranchId());
			}			
			
			Date currentDate = BNPDiscountUtil.getDiscountDate(timeZone);
			currentDateMillis = getDiscountDateWithoutTime(currentDate);			

			isValid = true;
			
			if(isAvailableInRecallTrans(discVO.getPaymtId())) {
			  setStatusMsg(resourceManager.getMessage(ErrorConstants.RECALL_DISCOUNT_VIOLATION));
			  isValid = false;
			}
			
			//914727-Change done for CSCDEV-521 5.1-Starts
			/**	a18839 CSCDEV-3252 20-02-2015 Starts	*/
			//if(CacheConstants.YES.equalsIgnoreCase(discVO.getOfferLetterGenFlag()) && !checkKycCompleted(discVO.getBuyerRefNo(),discVO.getBuyerOrgId()))
			if(CacheConstants.YES.equalsIgnoreCase(discVO.getOfferLetterGenFlag()) && !checkKycCompleted(discVO.getBuyerRefNoUnq(),discVO.getBuyerOrgId()))
			/**	a18839 CSCDEV-3252 20-02-2015 Ends	*/
			{
				setStatusMsg(resourceManager.getMessage(ErrorConstants.KYC_COMPLETED_CHECK));
				isValid = false;
				
			}
			//914727-Change done for CSCDEV-521 5.1-Ends
			
			if(!checkDiscountStatus(discVO)) {
				setStatusMsg(resourceManager.getMessage(ErrorConstants.SELECT_RELEASED_RECORD));
				isValid = false;
			}
			if(isValid && getDiscountDateWithoutTime(discVO.getDiscountDate()) < currentDateMillis) {
				setStatusMsg(resourceManager.getMessage(ErrorConstants.DISC_DATE_CANNOT_BE_IN_THE_PAST));
				isValid = false;
			}
			if(isValid && !compareDueDateAndDiscountDate(discVO.getDueDate(), discVO.getDiscountDate())) {
				isValid = false;
			}
		
		    // 933039 Change done for CSCDEV-3764 Starts 
			log.debug("Auto DIsc flag for " + discVO.getSenderOrgId() +"is "+ discVO.getAutoDiscFlag() );
			
			if(isValid && BNPConstants.Y.equals(discVO.getAutoDiscFlag()) && isAutoDiscInProgress(discVO)){
			 log.debug("Inside Concureency block" );
				setStatusMsg(resourceManager.getMessage(ErrorConstants.CONCURRENT_ACCESS));
				isValid = false;
			}
			
			orgIdSet.addAll(senderOrgIdSet);
			if(discountRequestService.isAutoDiscountingForGroupID(new ArrayList<String>(senderOrgIdSet))){
				//displayErrorMessage(ErrorConstants.AUTO_DISCOUNTING_IN_PROGRESS);
				setStatusMsg(resourceManager.getMessage(ErrorConstants.AUTO_DISCOUNTING_IN_PROGRESS));
				isValid = false;
				//return null;
			}else if(discountRequestService.isAutoDiscounting(new ArrayList<String>(orgIdSet))){
				//displayErrorMessage(ErrorConstants.AUTO_DISCOUNTING_IN_PROGRESS);
				setStatusMsg(resourceManager.getMessage(ErrorConstants.AUTO_DISCOUNTING_IN_PROGRESS));
				isValid = false;
				//return null;
			}
     		// 933039 Change done for CSCDEV-3764 ends 
			if(!isValid) {
				discVO.setRemarks(getStatusMsg());
				discVO.setIndicativeDiscountRate(null);
				discVO.setIndicativeDiscountAmt(null);
				//getResultDiscLst().add(discVO);
				resultList.add(discVO);
			 	senderOrgIdSet=new HashSet<String>();
				orgIdSet=new HashSet<String>();
				continue;
				//return resultList;
			}
			//Need to check how t place this
			discVO.setMakerId(sUserId);
			discVO.setUserType(sUserType);
			discVO.setSellerRefNo(discVO.getBuyerRefNo());//Need to confirm---------
		 	discVO.setPrevIndDiscRate(discVO.getIndicativeDiscountRate());
			if(BNPDiscountUtil.isMultiBankingModel(discVO.getMbModel())) {
				try {
					discVO.setTpDiscounts(tpDiscReqService.getTPDiscountsForRequest(discVO));
				} catch (BNPApplicationException e) {
					log.error(e.getMessage(),e);
					//displayErrorMessage(e.getErrorCode());
				}
			}
			try {
				if (discVO.getDiscountCharges() == null || discVO.getDiscountCharges().isEmpty()) {
					discVO.setDiscountCharges(discountRequestService.fetchDiscountTmpChargesList(discVO));
				}	
			} catch (BNPApplicationException e) {
				log.error(e.getMessage(),e);
				//displayErrorMessage(e.getErrorCode());
			}
		}
		
		/*orgIdSet.addAll(senderOrgIdSet);
		if(discountRequestService.isAutoDiscountingForGroupID(new ArrayList<String>(senderOrgIdSet))){
			//displayErrorMessage(ErrorConstants.AUTO_DISCOUNTING_IN_PROGRESS);
			return null;
		}else if(discountRequestService.isAutoDiscounting(new ArrayList<String>(orgIdSet))){
			//displayErrorMessage(ErrorConstants.AUTO_DISCOUNTING_IN_PROGRESS);
			isValid = false;
			return null;
		}*/
	
	//Brazil changes starts	
//		if(sUserType.equals(BNPConstants.BANKADMIN)){
//			List<DiscountRequestVO> nonNegRecords = new ArrayList<DiscountRequestVO>();
//			for (DiscountRequestVO discVO : discLst) {
//				if (isNegotiatedRateTransaction(discVO)) {
//					discVO.setNegotiatedRate(discVO.getIndicativeDiscountRate());
//					selList.add(discVO);
//				} else {
//					nonNegRecords.add(discVO);
//				}
//			}
//		  
//			 if(!selList.isEmpty() && nonNegRecords.isEmpty()){
//					showNegRatePopup= true;
//					setCheckNegAll(true);
//					setDisableDiscountForRateNeg(true);
//					return BNPConstants.SUCCESS;
//		 	} else if (!selList.isEmpty() && !nonNegRecords.isEmpty()) {
//		 		for (DiscountRequestVO discountRequestVO : nonNegRecords) {
//		 			discountRequestVO.setRemarks(resourceManager.getMessage(
//		 					ErrorConstants.SELECT_RECORD_RATENEGO_NOT_ELIGIBLE_TRANSACTIONS));
//		 			getResultDiscLst().add(discountRequestVO);
//				}
//		 		return null;
//		 	} else{
//		 			showNegRatePopup= false ;
//		 			setDisableDiscountForRateNeg(false);
// 		 	}
//			
//		}
//Brazil changes ends
		
		//914725 Changes for CSCDEV-3245 Start
		//Checking lock on LMSConcurrency table and if released, only then proceeding else throwing error on screen
		//Map<String, Object> resultMap = limitCheckService.processLMSConcurrencyRequest(null,discLst.get(0).getSenderOrgId(),null,BNPConstants.RAISE_DISCOUNT,false);
		//928747 Changes for CSCDEV-6169 End
		if(isValid){
		Map<String, Object> resultMap = limitCheckService.processLMSConcurrencyRequest(discLst.get(0).getSenderOrgId(),null,BNPConstants.RAISE_DISCOUNT);
		String lkId = (String)resultMap.get("LK_ID");
		//928747 Changes for CSCDEV-6169 End
		boolean wasLocked = (Boolean)resultMap.get("IS_LOCKED");
		try
		{
			//resultList = new ArrayList<DiscountRequestVO>();
			if(!wasLocked)
			{
				if(discLst.size() > 1) {
					try {
						isDiscGroupingAllowed = discountRequestService.isDiscGroupingAllowed(discLst.get(0));
					}
					catch(BNPApplicationException e) {
						isDiscGroupingAllowed = false;
						log.error(e.getMessage(),e);
					}
					if(!isDiscGroupingAllowed) {	
						for (DiscountRequestVO discVO : discLst) {
							tempDiscLst = new ArrayList<DiscountRequestVO>();
							tempDiscLst.add(discVO);
							//RO 9.0 UAT Issue Fix CSC-5260 5268 STARTS
							DiscountRequestVO  tempVo = insertDiscRequest(tempDiscLst,user,discLst);
							//RO 9.0 UAT Issue Fix CSC-5260 5268 ENDS
							resultList.add(tempVo);
//							try {
//								setAccessLogDetails(ScreenConstants.ACCESS_LOG_DISCOUNT_RAISE, resultVO != null ? resultVO.getDiscountRefNo() : null);
//							} 
//							catch (BNPApplicationException e) {
//								LOGGER.error("DataAccessException in insertAccessLog:",e);
//							}
						}
					}
				}
				if(isDiscGroupingAllowed || discLst.size() == 1) {
					//RO 9.0 UAT Issue Fix CSC-5260 5268 STARTS
					DiscountRequestVO  tempVo = insertDiscRequest(discLst,user,discLst);
					//RO 9.0 UAT Issue Fix CSC-5260 5268 ENDS
					resultList.add(tempVo);
//					try {
//						setAccessLogDetails(ScreenConstants.ACCESS_LOG_DISCOUNT_RAISE , resultVO != null ? resultVO.getDiscountRefNo() : null);
//					} 
//					catch (BNPApplicationException e) {
//						LOGGER.error("DataAccessException in insertAccessLog:",e);
//					}
				}
				//Unlocking Flag for Concurrency after completion
				//limitCheckService.unlockLMSConcReq(null,discLst.get(0).getSenderOrgId(),false);
			}
			else
			{
				//displayErrorMessage((String)resultMap.get("LOCKED_BY_PROCESS") + " " + resourceManager.getMessage(ErrorConstants.LMS_CONCURRENCY_ERROR));
				setStatusMsg((String)resultMap.get("LOCKED_BY_PROCESS") + " " + resourceManager.getMessage(ErrorConstants.LMS_CONCURRENCY_ERROR));
				for (DiscountRequestVO discVO : discLst) {
					discVO.setRemarks(getStatusMsg());
					discVO.setIndicativeDiscountRate(null);
					discVO.setIndicativeDiscountAmt(null);
					resultList.add(discVO);
				}
			}
		}
		//Replacing catch with finally block
		//catch(BNPApplicationException be)
		finally
		{
			if(!wasLocked)
			{
				try
				{
					//928747 Changes for CSCDEV-6169 Start
					//limitCheckService.unlockLMSConcReq(null,discLst.get(0).getSenderOrgId(),false);
					limitCheckService.unlockLMSConcReq(lkId);
					//928747 Changes for CSCDEV-6169 End
				}
				catch(BNPApplicationException e)
				{
					log.error(e.getMessage(), e);
					isValid = false;
					//return null;
					flag = null; // Added for Fortify Issue CSCDEV-5711- Poor Error Handling: Return Inside Finally
				}
			}
		}
		}
		//914725 Changes for CSCDEV-3245 End
		//return BNPConstants.SUCCESS;
		return resultList; // Added for Fortify Issue CSCDEV-5711 - Poor Error Handling: Return Inside Finally
	}
	
	/**
	 * @param paymentId
	 * @return boolean
	 * @throws BNPApplicationException 
	 * @Description check for availability of payment Id in Recall Transaction
	 */
	private boolean isAvailableInRecallTrans(long paymentId) throws BNPApplicationException{
	  return discountRequestService.isAvailableInRecallTrans(String.valueOf(paymentId));
	}
	
	/**
	 * @param discountDate
	 * @return long
	 * @Description Get Discount Date Without Time
	 */
	private long getDiscountDateWithoutTime(Date discountDate) {
		return BNPDiscountUtil.getDateWithoutTime(discountDate);
	}
	
	/**
	 * @param buyerRefNoUnq
	 * @param buyerOrgId
	 * @return boolean
	 * @throws BNPApplicationException 
	 * @Description 
	 */
	private boolean checkKycCompleted(String buyerRefNoUnq,String buyerOrgId) throws BNPApplicationException
	{
		boolean flag=false;
		try
		{
	    //flag=discountRequestService.checkKycCompleted(buyerRefNo,buyerOrgId);
		flag=discountRequestService.checkKycCompleted(buyerRefNoUnq,buyerOrgId);
	    /**	a18839 CSCDEV-3252 20-02-2015 Ends	*/
	    return flag;
		}
		catch(BNPApplicationException e)
		{
			log.error(e.getMessage(),e);
		   return flag;
		}
		
	}
	
	/**
	 * @param selectedDiscountReqVO
	 * @return boolean
	 * @Description check Discount Status
	 */
	public boolean checkDiscountStatus(DiscountRequestVO selectedDiscountReqVO){
		if(selectedDiscountReqVO.getDiscountStatus().equals(StatusConstants.RELEASED))
			return true;
		else
			return false;
	}
	
	/**
	 * @param dueDate
	 * @param discountDate
	 * @return boolean
	 * @Description compare DueDate And DiscountDate
	 */
	private boolean compareDueDateAndDiscountDate(Date dueDate,
			Date discountDate) {
		if (discountDate == null) {
			setStatusMsg(resourceManager.getMessage(ErrorConstants.DISC_DATE_CANNOT_BE_EMPTY));
			return false;
		}
		
		long dueDateTime = getTime(dueDate);
		long discDateTime = discountDate.getTime();

		if (dueDateTime <= discDateTime) {
			setStatusMsg(resourceManager.getMessage(ErrorConstants.DUEDATE_CANNOT_LESS_THAN_DISCDATE));
			return false;
		}
		return true;
	}
	
	/**
	 * @param discountRequestVO
	 * @return
	 * @throws BNPApplicationException 
	 * @Description is Auto Discount InProgress
	 */
	private boolean  isAutoDiscInProgress(DiscountRequestVO discountRequestVO) throws BNPApplicationException{
		
		return discountRequestService.isAutoDiscInProgress(discountRequestVO);
	}
	
	/**
	 * @param date
	 * @return long
	 * @Description get Time
	 */
	private long getTime(Date date) {
		return BNPDiscountUtil.getDueDateInMillis(date);
	}
	//RO 9.0 UAT Issue Fix CSC-5260 5268 STARTS
	/**
	 * @param tempDiscLst
	 * @param user
	 * @param selectedList
	 * @return DiscountRequestVO
	 * @Description insert Discount Request
	 */
	private DiscountRequestVO  insertDiscRequest(List<DiscountRequestVO> tempDiscLst,UserInfoVO user,List<DiscountRequestVO> selectedList) {
	//RO 9.0 UAT Issue Fix CSC-5260 5268 ENDS
		
		String sUserType = user.getUserTypeId();
		DiscountRequestVO resultVO = null;
		List<Integer> limitErrorList=new ArrayList(Arrays.asList(ErrorConstants.LIMIT_CHECK_FAILED, ErrorConstants.LIMIT_EXCEEDS, ErrorConstants.LIMIT_CHECK_FAILED_FOR_TP_BANK));

		try {
					
			//Code change done for CSC 7911
			//discountRequestService.updateTxnTimestampNew(tempDiscLst);
			 resultVO = discountRequestService.insertDiscountRequest(tempDiscLst);
			// Fix for Issue 6176 - Comparing the remarks with string value of the Integer
			// To display the Indicative rate and Amount
			if(resultVO.getRemarks()!=null && resultVO.getRemarks().equals(String.valueOf(ErrorConstants.DISCOUNT_SUCCESS))) {
				/*Modified below code to get Remark locale code from ErrorConstants for UAT Defect - CSC-5852 */
				//resultVO.setRemarks(resourceManager.getMessage(ErrorConstants.DISCOUNT_SUCCESS));
				resultVO.setRemarks(String.valueOf(ErrorConstants.DISCOUNT_SUCCESS));
				resultVO.setIndicativeNetAmt(formatAmount(resultVO.getIndicativeNetAmt(), resultVO.getFractionalDigits(),resultVO.getRoundingMode()));
				// Added for CSCDEV-6046 : Starts
				if(null != resultVO.getIndicativeNetAmt() && resultVO.getIndicativeNetAmt().compareTo(BigDecimal.ZERO) < 0){
					resultVO.setIndicativeNetAmt(BigDecimal.ZERO);
				}
				// Added for CSCDEV-6046 : Ends
				resultVO.setAvailableAmt(formatAmount(resultVO.getAvailableAmt(),resultVO.getFractionalDigits(),resultVO.getRoundingMode()));
			}
			else {
				//914727 CSCDEV-3253 24-DEC-2014:start
				if(BNPConstants.PAYABLE==resultVO.getProductType() && sUserType.equalsIgnoreCase(BNPConstants.SUPPLIER))
				{
					  if(limitErrorList.contains(Integer.parseInt(resultVO.getRemarks())))
				      {
				  		resultVO.setRemarks(String.valueOf(ErrorConstants.LIMIT_EXCEEDS_PAYABLE));
				      }
				}
				
				//914727 CSCDEV-3253 24-DEC-2014:end
				/*Modified below code to get Remark locale code from ErrorConstants for UAT Defect - CSC-5852 */
				//resultVO.setRemarks(resourceManager.getMessage(resultVO.getRemarks()));
				resultVO.setRemarks(String.valueOf(resultVO.getRemarks()));
			}
//			getResultDiscLst().add(resultVO);
			finalResultList.add(resultVO);
			return resultVO;
		}
		catch(BNPApplicationException e) {
			//FO 7.0 Fortify Issue Fix
			log.error("Error Message in saveDiscountRequest(): " + e.getMessage(),e);
			log.error("Error Code in saveDiscountRequest(): " + e.getErrorCode(),e);
			setStatusMsg(resourceManager.getMessage(e.getErrorCode()));
			//displayErrorMessage(e.getErrorCode());
		}
		//RO 9.0 UAT Issue Fix CSC-5260 5268 STARTS
		try {
			discountRequestService.resetProcessingFlagNew(selectedList);
		} catch (BNPApplicationException e) {
			setStatusMsg(resourceManager.getMessage(e.getErrorCode()));
		}
		//RO 9.0 UAT Issue Fix CSC-5260 5268 ENDS
	return resultVO;
	}
	
	/**
	 * @param value
	 * @param roundValue
	 * @param roundingMode
	 * @return BigDecimal
	 * @Description Format Amount
	 */
	private BigDecimal formatAmount(BigDecimal value,Integer roundValue, String roundingMode){
		return NumberFormatConversionUtil.formatBigDecWithMode(value, roundValue, roundingMode);
	}
	/**
	 * @param paymentOrderListtVO
	 * @param user
	 * @return DiscountResponseVO
	 * @throws BNPApplicationException
	 * @see com.bnp.bnpux.service.IDiscountServiceUX#getDiscRequestVO(java.util.List, com.bnp.bnpux.common.vo.UserInfoVO)
	 * @Description get DiscRequest VO
	 */
	public DiscountResponseVO getDiscRequestVO(List<PaymentOrderListVO> paymentOrderListtVO,UserInfoVO user) throws BNPApplicationException{
		//resultList = new ArrayList<DiscountRequestVO>();
		List<ErrorMessageVO> errorList = new ArrayList<ErrorMessageVO>();
		ErrorMessageVO error  = null;
		DiscountResponseVO finalResult = new DiscountResponseVO();
		finalResultList = new ArrayList<DiscountRequestVO>();
		//List<DiscountRequestVO> discVOList = new ArrayList<DiscountRequestVO>();
		List<DiscountRequestVO>  discVo = paymentOrderDAO.getDiscountRequestVO(paymentOrderListtVO);
		//discVOList = paymentOrderDAO.getDiscountRequestVO(paymentOrderListtVO);
		
			for(PaymentOrderListVO paymentorderlist:  paymentOrderListtVO){
				String buyerRefNo = paymentorderlist.getBuyerRefNo();
				for(DiscountRequestVO  dicRequestlist:discVo){
					if(buyerRefNo.equalsIgnoreCase(dicRequestlist.getBuyerRefNo())){
						dicRequestlist.setAvailableAmt(paymentorderlist.getAvailableAmount());
						dicRequestlist.setDiscountDate(paymentorderlist.getDiscountDate());
						break;
					}				

				}
			}
		try {
			finalResultList = 	saveDiscount(discVo,user);
			for(PaymentOrderListVO paymentorderlist:  paymentOrderListtVO){
				//String pymtId = paymentorderlist.getPymtId();
				String buyerRefNo = paymentorderlist.getBuyerRefNo();
				boolean isAvailable = false;
				for(DiscountRequestVO  dicRequestlist:discVo){
					if(buyerRefNo.equalsIgnoreCase(dicRequestlist.getBuyerRefNo())){
						isAvailable = true;
						break;
					}				
				}
				if(!isAvailable){
					/* Modified below changes for UAT defect 5304*/
					//errorList.add(addActionPopupErrorMessages(paymentorderlist.getBuyerRefNo(), "Please select a valid record for Discount Request.",true));
					errorList.add(addActionPopupErrorMessages(paymentorderlist.getBuyerRefNo(), resourceManager.getMessage(String.valueOf(ErrorConstants.DISCOUNT_REQUEST_FAILIURE)),true));
				}
			}
			
		} catch (BNPApplicationException e) {
			setStatusMsg(resourceManager.getMessage(e.getErrorCode()));
			log.error(e.getMessage(),e);
		}
		if(errorList.size()>0){
		finalResult.setErrorList(errorList);
		}
		finalResult.setDiscountRequestVO(finalResultList);
		return finalResult;
	}


	public String getStatusMsg() {
		return statusMsg;
	}


	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}
	
	
	/**
	 * @param uniqueID
	 * @param message
	 * @param error
	 * @return ErrorMessageVO 
	 * @Description Add Error message to list
	 */
	private ErrorMessageVO addActionPopupErrorMessages(String uniqueID, String message, boolean error){
		 ErrorMessageVO objErrorMessageVO  = new ErrorMessageVO();
	     objErrorMessageVO.setUniqueID(uniqueID);
	     objErrorMessageVO.setMessage(message);
	     objErrorMessageVO.setError(error);
	     return objErrorMessageVO;
		
	}
}

