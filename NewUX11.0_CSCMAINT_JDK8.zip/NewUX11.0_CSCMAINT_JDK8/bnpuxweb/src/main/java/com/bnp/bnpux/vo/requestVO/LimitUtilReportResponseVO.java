/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-JUL-2017
 * 
 * Purpose:      Limit Utilization Response VO
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27-JUL-2017				Divyashri Subramaniam						To Handle service calls Response Object related to Limit Utilization 
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.requestVO;

import java.util.ArrayList;
import java.util.List;
import com.bnp.bnpux.common.vo.DashbrdPendingActionSummaryVO;
import com.bnp.bnpux.common.vo.LimitUtilDetailReportVO;
import com.bnp.bnpux.common.vo.LimitUtilReportBarChartVO;
import com.bnp.scm.services.common.vo.NameValueVO;

public class LimitUtilReportResponseVO {
	
	private String userId;

	private String userType;
	
	private String errMessage;
	
	private Integer errCode;

	private List<NameValueVO> branchList = new ArrayList<NameValueVO>();
	
	private List<NameValueVO> organisationList = new ArrayList<NameValueVO>();
	
	private List<String> currencyList = new ArrayList<String>();
	
	private LimitUtilReportBarChartVO limitUtilReportBarChartVO;
	
	private List<LimitUtilDetailReportVO> limitUtilDetailReportVOs;
	
	private List<DashbrdPendingActionSummaryVO> pendingActionDetailsList;
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getErrMessage() {
		return errMessage;
	}

	public void setErrMessage(String errMessage) {
		this.errMessage = errMessage;
	}

	public Integer getErrCode() {
		return errCode;
	}

	public void setErrCode(Integer errCode) {
		this.errCode = errCode;
	}

	public List<NameValueVO> getBranchList() {
		return branchList;
	}

	public void setBranchList(List<NameValueVO> branchList) {
		this.branchList = branchList;
	}

	public List<NameValueVO> getOrganisationList() {
		return organisationList;
	}

	public void setOrganisationList(List<NameValueVO> organisationList) {
		this.organisationList = organisationList;
	}

	public List<String> getCurrencyList() {
		return currencyList;
	}

	public void setCurrencyList(List<String> currencyList) {
		this.currencyList = currencyList;
	}

	public LimitUtilReportBarChartVO getLimitUtilReportBarChartVO() {
		return limitUtilReportBarChartVO;
	}

	public void setLimitUtilReportBarChartVO(LimitUtilReportBarChartVO limitUtilReportBarChartVO) {
		this.limitUtilReportBarChartVO = limitUtilReportBarChartVO;
	}

	public List<LimitUtilDetailReportVO> getLimitUtilDetailReportVOs() {
		return limitUtilDetailReportVOs;
	}

	public void setLimitUtilDetailReportVOs(List<LimitUtilDetailReportVO> limitUtilDetailReportVOs) {
		this.limitUtilDetailReportVOs = limitUtilDetailReportVOs;
	}

	public List<DashbrdPendingActionSummaryVO> getPendingActionDetailsList() {
		return pendingActionDetailsList;
	}

	public void setPendingActionDetailsList(List<DashbrdPendingActionSummaryVO> pendingActionDetailsList) {
		this.pendingActionDetailsList = pendingActionDetailsList;
	}


}
