/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:      Transaction Request Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 * 21 Feb 2017						Sathishkumar B														      FO 10.0 - S008, S009, S010, S011, S012, S013, S014
 * 16 Mar 2017						aasriniv																  FO 10.0 - Advanced FIlter Implementation - Transactions
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.requestVO;

import java.util.Date;
import java.util.List;

import com.bnp.bnpux.common.vo.AdvancedFilterVO;
import com.bnp.bnpux.common.vo.CommitmentFeeUxVO;
import com.bnp.bnpux.common.vo.CreditNotesDetailsUxVO;
import com.bnp.bnpux.common.vo.DiscountDetailsUxVO;
import com.bnp.bnpux.common.vo.IndicativeChargesUxVO;
import com.bnp.bnpux.common.vo.InvoiceDetailsUxVO;
import com.bnp.bnpux.common.vo.OrganizationVO;
import com.bnp.bnpux.common.vo.PaymentOrderListDetailsVO;
import com.bnp.bnpux.common.vo.TransactionChargeAmtVO;
import com.bnp.bnpux.common.vo.TransactionConfimedAmtVO;
import com.bnp.bnpux.common.vo.TransactionListVO;
import com.bnp.bnpux.common.vo.TransactionSummaryVO;

public class TransactionRequestVO {
	
	private String userId;

	private String userType;

	private String orgId;
	
	private String leadOrgId;

	private String currencyCode;

	private String paymentOrderNo;

	private String paymentOrderStatus;
	
	private Date maturityDate;	
	
	private Long recordFrom;
	
	private Long recordTo;
	
	private Integer recordCount;
	
	private String maturityFilter;
	
	private String errorFlag;
	
	private String advanceFilter;
	
	private String groupIndicator;
	
	private String viewType;
	
	private String supplierOrgId;
	
	private String buyerOrgId;
	
	private Date paymentDate;
	
	private String buyerRefNoUniqueValue;
	
	private String paymentFlagValue;
	
	private String leadOrgIdValue;
	

	private String periodFilter;
	
	private String statusFilter;
	
	private String branchFilter;
	
	private String paymentRefNo;
	
	private String recType;
	
	private String quickSearchText;
	
	private String discRefNo;
	
	/* Added below variables for code review comments(HashMap to RequestVO  in service layer)*/
	
	/**FO 10.0 - S008, S009, S010, S011, S012, S013, S014**/
	
	private String errorMsg;
	
	private String debitRefNo;
	
	private List<TransactionSummaryVO> summaryList;
	
	private List<TransactionListVO> transactionList;
	
	private List<TransactionSummaryVO> transactionSummary;
	
	private List<TransactionListVO> transactionListDetails;
	
	private List<IndicativeChargesUxVO> indicativeChargesUxVOList;
	
	private List<CommitmentFeeUxVO> commitmentFeeUxVOList; 
	
	private List<CommitmentFeeUxVO> commitmentFeeUxVOHeader;
	 
	private List<PaymentOrderListDetailsVO> poDetailsList;
	
	private List<InvoiceDetailsUxVO> invoiceDetailsList;
	
	private List<CreditNotesDetailsUxVO> creditNotesDetailsList;
	
	private List<OrganizationVO> organizationVOList;
	
	private List<DiscountDetailsUxVO> discountDetailsUxVOList;
	
	private List<TransactionChargeAmtVO> transactionChargeAmtVOList;
	
	private TransactionConfimedAmtVO transactionConfirmedAmtVO;

	private OrganizationVO organizationVO;
	
	private DiscountDetailsUxVO discountDetailsUxVO;

	private String exportType;
	/**FO 10.0 - S008, S009, S010, S011, S012, S013, S014**/
	
	private List<AdvancedFilterVO> advancedFilterListVO;
	
	public String getQuickSearchText() {
		return quickSearchText;
	}

	public void setQuickSearchText(String quickSearchText) {
		this.quickSearchText = quickSearchText;
	}

	public String getPeriodFilter() {
		return periodFilter;
	}

	public void setPeriodFilter(String periodFilter) {
		this.periodFilter = periodFilter;
	}

	public String getStatusFilter() {
		return statusFilter;
	}

	public void setStatusFilter(String statusFilter) {
		this.statusFilter = statusFilter;
	}
	public String getPaymentFlagValue() {
		return paymentFlagValue;
	}

	public void setPaymentFlagValue(String paymentFlagValue) {
		this.paymentFlagValue = paymentFlagValue;
	}

	public String getLeadOrgIdValue() {
		return leadOrgIdValue;
	}

	public void setLeadOrgIdValue(String leadOrgIdValue) {
		this.leadOrgIdValue = leadOrgIdValue;
	}

	public String getBuyerRefNoUniqueValue() {
		return buyerRefNoUniqueValue;
	}

	public void setBuyerRefNoUniqueValue(String buyerRefNoUniqueValue) {
		this.buyerRefNoUniqueValue = buyerRefNoUniqueValue;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getLeadOrgId() {
		return leadOrgId;
	}

	public void setLeadOrgId(String leadOrgId) {
		this.leadOrgId = leadOrgId;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getPaymentOrderNo() {
		return paymentOrderNo;
	}

	public void setPaymentOrderNo(String paymentOrderNo) {
		this.paymentOrderNo = paymentOrderNo;
	}

	public String getPaymentOrderStatus() {
		return paymentOrderStatus;
	}

	public void setPaymentOrderStatus(String paymentOrderStatus) {
		this.paymentOrderStatus = paymentOrderStatus;
	}

	public Date getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(Date maturityDate) {
		this.maturityDate = maturityDate;
	}

	

	public Integer getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(Integer recordCount) {
		this.recordCount = recordCount;
	}

	public String getMaturityFilter() {
		return maturityFilter;
	}

	public void setMaturityFilter(String maturityFilter) {
		this.maturityFilter = maturityFilter;
	}

	public String getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	public String getAdvanceFilter() {
		return advanceFilter;
	}

	public void setAdvanceFilter(String advanceFilter) {
		this.advanceFilter = advanceFilter;
	}

	public String getGroupIndicator() {
		return groupIndicator;
	}

	public void setGroupIndicator(String groupIndicator) {
		this.groupIndicator = groupIndicator;
	}

	public String getViewType() {
		return viewType;
	}

	public void setViewType(String viewType) {
		this.viewType = viewType;
	}

	public String getSupplierOrgId() {
		return supplierOrgId;
	}

	public void setSupplierOrgId(String supplierOrgId) {
		this.supplierOrgId = supplierOrgId;
	}

	public String getBuyerOrgId() {
		return buyerOrgId;
	}

	public void setBuyerOrgId(String buyerOrgId) {
		this.buyerOrgId = buyerOrgId;
	}

	public Date getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getBranchFilter() {
		return branchFilter;
	}

	public void setBranchFilter(String branchFilter) {
		this.branchFilter = branchFilter;
	}

	public String getPaymentRefNo() {
		return paymentRefNo;
	}

	public void setPaymentRefNo(String paymentRefNo) {
		this.paymentRefNo = paymentRefNo;
	}

	public String getRecType() {
		return recType;
	}

	public void setRecType(String recType) {
		this.recType = recType;
	}

	public List<TransactionSummaryVO> getTransactionSummary() {
		return transactionSummary;
	}

	public void setTransactionSummary(List<TransactionSummaryVO> transactionSummary) {
		this.transactionSummary = transactionSummary;
	}

	public List<TransactionListVO> getTransactionListDetails() {
		return transactionListDetails;
	}

	public void setTransactionListDetails(List<TransactionListVO> transactionListDetails) {
		this.transactionListDetails = transactionListDetails;
	}

	public String getDiscRefNo() {
		return discRefNo;
	}

	public void setDiscRefNo(String discRefNo) {
		this.discRefNo = discRefNo;
	}

	public List<IndicativeChargesUxVO> getIndicativeChargesUxVOList() {
		return indicativeChargesUxVOList;
	}

	public void setIndicativeChargesUxVOList(List<IndicativeChargesUxVO> indicativeChargesUxVOList) {
		this.indicativeChargesUxVOList = indicativeChargesUxVOList;
	}

	public List<CommitmentFeeUxVO> getCommitmentFeeUxVOList() {
		return commitmentFeeUxVOList;
	}

	public void setCommitmentFeeUxVOList(List<CommitmentFeeUxVO> commitmentFeeUxVOList) {
		this.commitmentFeeUxVOList = commitmentFeeUxVOList;
	}

	public List<PaymentOrderListDetailsVO> getPoDetailsList() {
		return poDetailsList;
	}

	public void setPoDetailsList(List<PaymentOrderListDetailsVO> poDetailsList) {
		this.poDetailsList = poDetailsList;
	}

	public List<InvoiceDetailsUxVO> getInvoiceDetailsList() {
		return invoiceDetailsList;
	}

	public void setInvoiceDetailsList(List<InvoiceDetailsUxVO> invoiceDetailsList) {
		this.invoiceDetailsList = invoiceDetailsList;
	}

	public List<CreditNotesDetailsUxVO> getCreditNotesDetailsList() {
		return creditNotesDetailsList;
	}

	public void setCreditNotesDetailsList(List<CreditNotesDetailsUxVO> creditNotesDetailsList) {
		this.creditNotesDetailsList = creditNotesDetailsList;
	}

	public List<OrganizationVO> getOrganizationVOList() {
		return organizationVOList;
	}

	public void setOrganizationVOList(List<OrganizationVO> organizationVOList) {
		this.organizationVOList = organizationVOList;
	}

	public List<DiscountDetailsUxVO> getDiscountDetailsUxVOList() {
		return discountDetailsUxVOList;
	}

	public void setDiscountDetailsUxVOList(List<DiscountDetailsUxVO> discountDetailsUxVOList) {
		this.discountDetailsUxVOList = discountDetailsUxVOList;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public List<TransactionSummaryVO> getSummaryList() {
		return summaryList;
	}

	public void setSummaryList(List<TransactionSummaryVO> summaryList) {
		this.summaryList = summaryList;
	}

	public List<TransactionListVO> getTransactionList() {
		return transactionList;
	}

	public void setTransactionList(List<TransactionListVO> transactionList) {
		this.transactionList = transactionList;
	}

	public List<TransactionChargeAmtVO> getTransactionChargeAmtVOList() {
		return transactionChargeAmtVOList;
	}

	public void setTransactionChargeAmtVOList(List<TransactionChargeAmtVO> transactionChargeAmtVOList) {
		this.transactionChargeAmtVOList = transactionChargeAmtVOList;
	}

	public TransactionConfimedAmtVO getTransactionConfirmedAmtVO() {
		return transactionConfirmedAmtVO;
	}

	public void setTransactionConfirmedAmtVO(TransactionConfimedAmtVO transactionConfirmedAmtVO) {
		this.transactionConfirmedAmtVO = transactionConfirmedAmtVO;
	}

	public OrganizationVO getOrganizationVO() {
		return organizationVO;
	}

	public void setOrganizationVO(OrganizationVO organizationVO) {
		this.organizationVO = organizationVO;
	}

	public DiscountDetailsUxVO getDiscountDetailsUxVO() {
		return discountDetailsUxVO;
	}

	public void setDiscountDetailsUxVO(DiscountDetailsUxVO discountDetailsUxVO) {
		this.discountDetailsUxVO = discountDetailsUxVO;
	}

	public String getExportType() {
		return exportType;
	}

	public void setExportType(String exportType) {
		this.exportType = exportType;
	}

	public List<AdvancedFilterVO> getAdvancedFilterListVO() {
		return advancedFilterListVO;
	}

	public void setAdvancedFilterListVO(List<AdvancedFilterVO> advancedFilterListVO) {
		this.advancedFilterListVO = advancedFilterListVO;
	}

	public List<CommitmentFeeUxVO> getCommitmentFeeUxVOHeader() {
		return commitmentFeeUxVOHeader;
	}

	public void setCommitmentFeeUxVOHeader(List<CommitmentFeeUxVO> commitmentFeeUxVOHeader) {
		this.commitmentFeeUxVOHeader = commitmentFeeUxVOHeader;
	}

	public String getDebitRefNo() {
		return debitRefNo;
	}

	public void setDebitRefNo(String debitRefNo) {
		this.debitRefNo = debitRefNo;
	}

	public Long getRecordFrom() {
		return recordFrom;
	}

	public void setRecordFrom(Long recordFrom) {
		this.recordFrom = recordFrom;
	}

	public Long getRecordTo() {
		return recordTo;
	}

	public void setRecordTo(Long recordTo) {
		this.recordTo = recordTo;
	}


}
