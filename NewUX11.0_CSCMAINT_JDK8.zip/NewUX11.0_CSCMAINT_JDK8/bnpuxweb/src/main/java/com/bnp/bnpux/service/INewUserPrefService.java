/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas.
 * 
 * Created on:   25 APR 2016
 * 
 * Purpose:     User Preference Service Interface
 * 
 * Change History: 
 * Date                                    Author                                                                               Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 25 APR 2016						    Bala Murugan Elangovan														 	 Recall Implementation 
 * ****************************************************************************************************************************************************************/


package com.bnp.bnpux.service;

import java.util.List;
import java.util.Locale;
import com.bnp.bnpux.common.vo.UserPreferenceVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;


public interface INewUserPrefService {

	/**
	 * This API is used to save the user preference info such as Date format and Currency Format
	 * @param userVO
	 * @return 
	 * @throws BNPApplicationException
	 */
	UserPreferenceVO saveUserPreferenceInfo(UserPreferenceVO userVO) throws BNPApplicationException;
	
	/**
	 * This API is used to get user preference details.
	 * @param userId
	 * @return
	 * @throws BNPApplicationException
	 */
	UserPreferenceVO getUserPreferenceInfo(String userId,String userType) throws BNPApplicationException;	
	
	/**
	 * Get Time Zone List	
	 * @return List<NameValueVO>
	 * @throws BNPApplicationException
	 */
	List<NameValueVO> getTimeZoneList() throws BNPApplicationException;
	
	/**
	 * Get Locale from user id
	 * @param userId
	 * @return Locale
	 * @throws BNPApplicationException
	 */
	Locale getUserLocale(String userId) throws BNPApplicationException;	
	
}
