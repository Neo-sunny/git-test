/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  21 June 2017
 * 
 * Purpose:      Limit Utilization Report Summary VO
 * 
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 21 June 2017       Ratna Gokhale, Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/

package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;

public class LimitUtilizationReportVO{
	
	private String clOrgId;
	
	private String clOrgName;
	
	private String currencyCode;
	
	private String errorMessage;

	
	private String programId;
	
	private String branchCode;
	
	private String groupCurrencyCode;
	
	private int decimalPoint;
	
	private String orgRole;
	
	private String groupName;
	
	private String parentOrgId;
	
	


	public String getProgramId() {
		return programId;
	}

	public void setProgramId(String programId) {
		this.programId = programId;
	}



	public int getDecimalPoint() {
		return decimalPoint;
	}

	public void setDecimalPoint(int decimalPoint) {
		this.decimalPoint = decimalPoint;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getGroupCurrencyCode() {
		return groupCurrencyCode;
	}

	public void setGroupCurrencyCode(String groupCurrencyCode) {
		this.groupCurrencyCode = groupCurrencyCode;
	}


	public String getOrgRole() {
		return orgRole;
	}

	public void setOrgRole(String orgRole) {
		this.orgRole = orgRole;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getParentOrgId() {
		return parentOrgId;
	}

	public void setParentOrgId(String parentOrgId) {
		this.parentOrgId = parentOrgId;
	}

	public String getClOrgId() {
		return clOrgId;
	}

	public void setClOrgId(String clOrgId) {
		this.clOrgId = clOrgId;
	}

	public String getClOrgName() {
		return clOrgName;
	}

	public void setClOrgName(String clOrgName) {
		this.clOrgName = clOrgName;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	

}
