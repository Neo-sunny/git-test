/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Modal Controller
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.bnpux.service.IModalService;


@RestController
@RequestMapping("/modalController")
public class ModalController {
	
	
	/**
	 * Logger for PaymentOrderController
	 */
	public static final Logger log = LoggerFactory.getLogger(ModalController.class);
	

	/**
	 * Autowired Interface IPaymentOrderService
	 */
	@Autowired
	private IModalService modalService;
	

	/**
	 * This method is for getting Perishable popup timeout value
	 * 
	 * @return
	 */
	@RequestMapping(value = "getPerishablePopupTimeOut.rest", method = RequestMethod.POST)
	public int getPaymentOrderDetails() {
		int timeOutValue = 0;
		timeOutValue = modalService.getPerishablePopupTimeOut();
		return timeOutValue;		
		
	}
	
	

}
