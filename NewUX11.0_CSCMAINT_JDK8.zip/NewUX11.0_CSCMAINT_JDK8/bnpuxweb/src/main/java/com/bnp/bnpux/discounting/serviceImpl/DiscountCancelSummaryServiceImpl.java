/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Discount Request Cancel Service Implementation
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.discounting.serviceImpl;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
/*import org.springframework.context.annotation.Scope;*/
import org.springframework.stereotype.Component;

import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.discounting.service.IDiscountCancelSummaryService;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.discounting.IDiscountRequestService;
import com.bnp.scm.services.discounting.IDiscountService;
import com.bnp.scm.services.discounting.vo.DiscountRequestVO;

@Component
public class DiscountCancelSummaryServiceImpl extends AbstractServiceImpl<DiscountRequestVO> implements IDiscountCancelSummaryService  {

	@Autowired
		private IDiscountRequestService discountReqService;

	
	
	/* 
	 * This method is for cancel Discount Request
	 * 
	 * (non-Javadoc)
	 * @see com.bnp.bnpux.discounting.service.IDiscountCancelSummaryService#cancel(java.util.List, java.lang.String)
	 */
	@Override
	public String cancel(List<DiscountRequestVO> discVOList, String userId)
			throws BNPApplicationException {

		String ErrorMsg = "Discount Request Cancelled Successfully.";
		selectedList = discVOList;

		Iterator<DiscountRequestVO> selectedListIterator = selectedList
				.iterator();
		while (selectedListIterator.hasNext()) {
			DiscountRequestVO discVo = selectedListIterator.next();
			String createdby = discVo.getCreatedBy();
			String makerid = discVo.getMakerId();
			if (validateRecordForCancel(discVo.getDiscountStatus())) {
				if (checkMakerForCancel(userId, discVo.getCreatedBy())) {
					discountReqService.cancelDiscountRequest(discVo, userId);
				} else {
					ErrorMsg = "Only Maker can cancel this record";
				}
			} else {
				ErrorMsg = "Please select a APPROVED/RELEASE PENDING/PENDING DISCOUNT REJECTED record to Cancel";
			}
		}
		return ErrorMsg;
	}
	
	
	/**
	 * This method is for validating Discount Request for cancel
	 * 
	 * @param discountStatus
	 * @return
	 */
	private boolean validateRecordForCancel(String discountStatus) {
		if(discountStatus.equals(StatusConstants.DISCOUNT_RELEASE_PENDING) ||
				discountStatus.equals(StatusConstants.DISCOUNT_RELEASE_APPROVE_PENDING) || 
				discountStatus.equals(StatusConstants.PENDING_DISCOUNT_REJECTED)){
			return true;
		}
		else{
			//disReqStatus = resourceManager.getMessage(ErrorConstants.CANNOT_CANCEL_RECORD);
			return false;
		}
  }
	
	private boolean checkMakerForCancel(String loginUserId, String createdBy) {
		if(createdBy != null && (loginUserId.equals(createdBy) )){
			return true;
		}
		else{
			// Added this if check for Auto Discounting, in that case maker id will be "SYSTEM"
			if(createdBy != null && createdBy.equals(BNPConstants.SYSTEM)){
				return true;
			}
			else{
			//disReqStatus = resourceManager.getMessage(ErrorConstants.MAKER_CHECK_CANCEL);
			return false;
			}
		}
	}



@Override
public void populateTableData() throws BNPApplicationException {
	// TODO Auto-generated method stub
	
}

@Override
protected String getViewPage() {
	// TODO Auto-generated method stub
	return null;
}

@Override
protected String getSummaryPage() {
	// TODO Auto-generated method stub
	return null;
}

@Override
protected String getScreenConstant() {
	// TODO Auto-generated method stub
	return null;
}


}
