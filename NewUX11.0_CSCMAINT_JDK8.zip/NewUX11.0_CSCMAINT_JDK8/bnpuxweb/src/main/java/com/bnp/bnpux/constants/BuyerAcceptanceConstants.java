package com.bnp.bnpux.constants;

public interface BuyerAcceptanceConstants {

	public static final String BUYER_ACCEPTANCE_ERROR_DETAILS = "Database Error Flag : "; 

	public static final String VIEW_TYPE_BUYERACCEPT = "BUYERACCEPT";
	
	public static final String VIEW_TYPE_UPLOAD_DATE = "UPLOAD_DATE"; 
	
	public static final String VIEW_TYPE_BUYERACCEPT_LIST = "BUYERACCEPT_LIST"; 
	
	public static final String EXCEPTION_UNABLE_TO_PROCESS = "Unable to get Buyer Acceptance details - Database Exception"; 
		
	public static final String ADV_FLTR_GET = "GET";
	
	public static final String ADV_FLTR_DELETE = "DELETE";
	
	public static final String DATE_FORMAT_DD_MMM_YYY = "dd-MMM-yyyy";
    public static final String BA_DOWNLOAD = "DWLD";
	
	public static final String BA_ATTACHEMENT_DTL = "DTL";
	
	public static final String BA_DOWNLOAD_ALL = "ALLDWLD";
    public static final String SCF_FILE_NAME ="ScfAttachment.zip";
	
	public static final String EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL = "Unable to Get Attachment Details";

	public static final String BA_UNDO_REQUEST = "BUYER_ACCEPTANCE_UNDO";
	
	public static final String ACTION_ACCEPT = "ACCEPT";
	
	public static final String ACTION_APPROVE = "APPROVE";
	
	public static final String ACTION_REJECT = "REJECT";
	
	public static final String ACTION_UNDO = "UNDO";
	
	public static final String GROUP_INDICATOR_DUE_DATE = "M";
	
}
