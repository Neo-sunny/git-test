/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Message Bundle Controller
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import java.util.Enumeration;
import java.util.Locale;
import java.util.Properties;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.service.INewLoginService;


@RestController
@RequestMapping("/msgBundleCtrl")
public class MessageBundleController {
	private static final Logger log = LoggerFactory.getLogger(MessageBundleController.class);
	
	//@Autowired
	INewLoginService loginService;
			
	
	/**
	 * This method is for getting Message Bundle
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "getmessageBundle.rest", method = RequestMethod.GET)
	public Properties  post(HttpServletRequest request) {
		log.debug(request.getParameter("lang"));
		String[] locale=request.getParameter("lang").split("_");
		Locale lc=new Locale(locale[0],locale[1]);
		 ResourceBundle b1=null;
		try
		{
		 b1 = ResourceBundle.getBundle("resources/translations/label", lc);
		 log.debug(b1+"<<>>"+lc.getLanguage());		
		}
		catch (Exception e){
			log.error(e.getMessage(),e);		
		}		 
		Properties properties = convertResourceBundleToProperties(b1);	    
	    return properties;
	}
	
	/**
	 * This method is for converting resource bundle to properties
	 *  
	 * @param resource
	 * @return
	 */
	 private static Properties convertResourceBundleToProperties(ResourceBundle resource) {
	        Properties properties = new Properties();
	        Enumeration<String> keys = resource.getKeys();
	        while (keys.hasMoreElements()) {
	            String key = (String) keys.nextElement();
	            properties.put(key, resource.getString(key));
	            log.debug(resource.getString(key)+"<<>>"+key);
	        }
	        return properties;
	  }

}