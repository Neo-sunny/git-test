/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     Period Status Filter Interface
 * 
 * Change History: 
 * Date                                                  Author                                                 Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    	Initial Version 
 * 08 Mar 2017                		skbhaska                                    								FO 10.0 - S30 - Holiday Calendar
 * 07 Jun 2017                      banandha                                    		                        FO 10.0 - S3024 , S3023
 *****************************************************************************************************************************************************************/
package com.bnp.bnpux.service;

import java.util.List;

import com.bnp.bnpux.common.vo.AdvancedFilterVO;
import com.bnp.bnpux.vo.requestVO.PaymentOrderRequestVO;
import com.bnp.bnpux.vo.requestVO.ReportRequestVO;
import com.bnp.bnpux.vo.responseVO.PeriodStatusResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface IPeriodStatusFilterService {
	
	/**
	 * This method is for getting Period Status Filter
	 * 
	 * @param requsetVO
	 * @return
	 * @throws BNPApplicationException
	 */
	List<PeriodStatusResponseVO> getPeriodStatusFilter(PaymentOrderRequestVO requsetVO) throws BNPApplicationException; 
	
	/**
	 * This method is for getting Org For Branch Report
	 * 
	 * @param requsetVO
	 * @return
	 * @throws BNPApplicationException
	 */
	List<PeriodStatusResponseVO> getOrgForBranchReport(ReportRequestVO requsetVO) throws BNPApplicationException;
	/**
	 * This method is for getting Buyer Supplier Org ID For Aging Report when brach changed
	 * 
	 * @param requsetVO
	 * @return
	 * @throws BNPApplicationException
	 */
	List<PeriodStatusResponseVO> getBuyerSupplierOrgIDForBranchAgingReport(ReportRequestVO requsetVO) throws BNPApplicationException;
	
	/***
	 * This method is for getting the filter values for Holiday Calendar - FO 10.0 - S30 - Holiday Calendar
	 * @param requsetVO
	 * @return List<PeriodStatusResponseVO>
	 * @throws BNPApplicationException
	 */
	List<PeriodStatusResponseVO> getPeriodStatusFilterHolidayCal(PaymentOrderRequestVO requsetVO) throws BNPApplicationException;
	
	/**
	 * This method is for getting Email Inquiry - Events For Organization
	 * 
	 * @param requsetVO
	 * @return
	 * @throws BNPApplicationException
	 */
	List<PeriodStatusResponseVO> getEmailEventForBranchReport(ReportRequestVO requsetVO) throws BNPApplicationException;
	/**
	 * This method is for getting Issue Date From Period Filter Change
	 * 
	 * @param requsetVO
	 * @return
	 * @throws BNPApplicationException
	 */
	AdvancedFilterVO getPeriodFilterDate(AdvancedFilterVO advanceFiterRequsetVO) throws BNPApplicationException;
	
	/**
	 * This method is for getting List for CounterParty Org ID in Settlement Due Reminder Report
	 * for selected Client Org Id
	 * @param paramMap
	 * @return 
	 */

	public List<PeriodStatusResponseVO> getCptyOrgIdForClientReport(ReportRequestVO requsetVO) throws BNPApplicationException;

	public List<PeriodStatusResponseVO> getPlotParamForLmtUtlReport(ReportRequestVO requsetVO) throws BNPApplicationException;
}
