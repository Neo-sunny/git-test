/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   28 Mar 2017	
 * 
 * Purpose:       File Management PreApprovedSuppList Value Object
 * 
 * Change History: 
 * Date                       Author                                    Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 28 Mar 2017			      sree reshmi					               Initial Version 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;


public class FileMgmtPreAppSuppListVO {
	
	private String buyerOrgId;
	private String orgName;
	private String address1;
	private String address2;
	private String address3;
	private String city;
	
	private String country;
	private String postal;
	private String phone;      
	private String email;
	private String templateId;
	private String recordStatus;
	public String getBuyerOrgId() {
		return buyerOrgId;
	}
	public void setBuyerOrgId(String buyerOrgId) {
		this.buyerOrgId = buyerOrgId;
	}
	
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getAddress3() {
		return address3;
	}
	public void setAddress3(String address3) {
		this.address3 = address3;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getPostal() {
		return postal;
	}
	public void setPostal(String postal) {
		this.postal = postal;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTemplateId() {
		return templateId;
	}
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
	public String getRecordStatus() {
		return recordStatus;
	}
	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}
	
	

}
