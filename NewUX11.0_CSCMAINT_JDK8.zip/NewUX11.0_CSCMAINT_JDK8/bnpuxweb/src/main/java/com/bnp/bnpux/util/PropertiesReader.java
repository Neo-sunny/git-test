/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   07 Apr 2016
 * 
 * Purpose:     Property Reader
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 11 Apr 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 
 *****************************************************************************************************************************************************************/
package com.bnp.bnpux.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.scm.services.common.exception.BNPPropertyReader;

public class PropertiesReader {

	private static Properties commonProperties = null;
	public static final Logger log = LoggerFactory.getLogger(PropertiesReader.class);	
	static {
		loadCommonProperties();			
	}

	/**
	 * @Name : loadCommonProperties
	 * @Description : This method is the used to load the common property files
	 */
	private static void loadCommonProperties() {
		InputStream in = null;
		try {
			synchronized (PropertiesReader.class) {
				if (commonProperties == null) {
					in = BNPPropertyReader.class.getResourceAsStream(BNPConstants.BNP_COMMON_PROPERTIES);
					commonProperties = new Properties();
					commonProperties.load(in);
				}
			}
		}
		catch (IOException ex) {
			log.error(ex.getMessage(),ex);
		}
		catch (Exception ex) {
			log.error(ex.getMessage(),ex);
		}finally{
			if(in != null){
				try{
					in.close();
				}catch(IOException ioe){
					log.error(ioe.getMessage(),ioe);
				}
			}
		}
	}

	/**
	 * @Name : getProperty
	 * @Description : This method is the used to returns the value corresponding the key from the common property file
	 * @param keyVal
	 * @return String
	 */
	public static String getProperty(String keyVal) {
		String value = null;
		value = commonProperties.getProperty(keyVal.trim());
		return value;
	}
}
