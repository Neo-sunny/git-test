/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     CreditAssignmentLetter Service Implementation
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 
 *****************************************************************************************************************************************************************/
package com.bnp.bnpux.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.service.ICreditAssignmentLetterService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.discounting.dao.IFinancialInqDAO;
import com.bnp.scm.services.discounting.vo.CreditAssignmentVO;

@Component
public class CreditAssignmentLetterServiceImpl implements ICreditAssignmentLetterService{
	
	@Autowired
	private IFinancialInqDAO finInqDao;
	
	/**
	 * This method is for getting the Credit Assignment letters
	 * 
	 * @param pymtId
	 * @return CreditAssignmentVO List
	 * @throws BNPApplicationException
	 * @see com.bnp.bnpux.service.ICreditAssignmentLetterService#getCreditAssgntLetters(long)
	 * @Description get CreditAssignment Letters
	 */
	@Override
	public List<CreditAssignmentVO> getCreditAssgntLetters(long pymtId) throws BNPApplicationException {
		List<CreditAssignmentVO> crdtAsgnLetters = finInqDao.getCreditAssgntLetters(pymtId);
		
		 if(null != crdtAsgnLetters && !crdtAsgnLetters.isEmpty()){
			 int i=0;
			 for(CreditAssignmentVO crdVO:crdtAsgnLetters){
				 if(null != crdVO){
					 i++;
					 crdVO.setSlNo(i);
				 }
			 }
		 }
		return crdtAsgnLetters;
	}
	
	

}
