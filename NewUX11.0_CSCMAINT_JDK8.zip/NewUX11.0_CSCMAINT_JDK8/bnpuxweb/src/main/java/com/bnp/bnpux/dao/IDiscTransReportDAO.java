/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  21 June 2017
 * 
 * Purpose:      Credit Note Inquiry Report Interface for Data Access Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 21 June 2017       Ratna Gokhale, Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.dao;

import java.util.List;

import com.bnp.bnpux.vo.requestVO.DiscTransRequestVO;
import com.bnp.bnpux.vo.responseVO.DiscTransResponseVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;

public interface IDiscTransReportDAO {
	

	/**
	 * This method is for getting Credit Note Inquiry Report List
	 * 
	 * @param DiscTransRequestVO
	 * @return DiscTransResponseVO List
	 */
	List<DiscTransResponseVO> getReportList(DiscTransRequestVO discTransRequestVO);
	
	/**
	 * This method is for getting Credit Note Inquiry Report List Details
	 * 
	 * @param DiscTransRequestVO
	 * @return DiscTransResponseVO List
	 */
	List<DiscTransResponseVO> getReportListDetails(DiscTransRequestVO discTransRequestVO);
	

	/**
	 * This method is for getting Chart Axis
	 * 
	 * @param DiscTransRequestVO
	 * @return ReportChartResponseVO List
	 */
	List<ReportChartResponseVO> getChartAxis(DiscTransRequestVO discTransRequestVO);
	
}
