/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14 Mar 2017
 * 
 * Purpose:       File Management List Value Object
 * 
 * Change History: 
 * Date                       Author                                    Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 14 Mar 2017			      skbhaska					                Initial Version - FO 10.0 - S2005, S2007
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.util.Date;

public class FileMgmtListVO {

	private String fileName;
	private Integer fileID;
	private String fileStatus;
	private String uploadedBy;
	private String senderOrgID;
	private String releasedBy;
	private String source;
	private String fileType;
	private String errorCode;
	private String errorDesc;
	private String instrumentType;	
	private String instrumentGroup;
	private String recordNo;
	private String docType;
	private String chkBoxEntlLevel1;
	private String expandAllowed;
	private String attachmentFlag;
	private String quickSearchExpand;
	private String authButtonEnableFlag;
	private String rejButtonEnableFlag;
	private String statusValue;
	private String statusKey;
	
	public String getQuickSearchExpand() {
		return quickSearchExpand;
	}

	public void setQuickSearchExpand(String quickSearchExpand) {
		this.quickSearchExpand = quickSearchExpand;
	}

	public String getAttachmentFlag() {
		return attachmentFlag;
	}

	public void setAttachmentFlag(String attachmentFlag) {
		this.attachmentFlag = attachmentFlag;
	}

	public String getChkBoxEntlLevel1() {
		return chkBoxEntlLevel1;
	}

	public void setChkBoxEntlLevel1(String chkBoxEntlLevel1) {
		this.chkBoxEntlLevel1 = chkBoxEntlLevel1;
	}


	

	public String getExpandAllowed() {
		return expandAllowed;
	}

	public void setExpandAllowed(String expandAllowed) {
		this.expandAllowed = expandAllowed;
	}

	private Date fileReceivedDate;

	private Integer docTypeCode;
	private String senderOrgName;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Integer getFileID() {
		return fileID;
	}

	public void setFileID(Integer fileID) {
		this.fileID = fileID;
	}

	public String getFileStatus() {
		return fileStatus;
	}

	public void setFileStatus(String fileStatus) {
		this.fileStatus = fileStatus;
	}

	public String getUploadedBy() {
		return uploadedBy;
	}

	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}

	public String getSenderOrgID() {
		return senderOrgID;
	}

	public void setSenderOrgID(String senderOrgID) {
		this.senderOrgID = senderOrgID;
	}

	public String getReleasedBy() {
		return releasedBy;
	}

	public void setReleasedBy(String releasedBy) {
		this.releasedBy = releasedBy;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	public String getInstrumentType() {
		return instrumentType;
	}

	public void setInstrumentType(String instrumentType) {
		this.instrumentType = instrumentType;
	}

	public String getInstrumentGroup() {
		return instrumentGroup;
	}

	public void setInstrumentGroup(String instrumentGroup) {
		this.instrumentGroup = instrumentGroup;
	}

	public String getRecordNo() {
		return recordNo;
	}

	public void setRecordNo(String recordNo) {
		this.recordNo = recordNo;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public Date getFileReceivedDate() {
		return fileReceivedDate;
	}

	public void setFileReceivedDate(Date fileReceivedDate) {
		this.fileReceivedDate = fileReceivedDate;
	}

	public Integer getDocTypeCode() {
		return docTypeCode;
	}

	public void setDocTypeCode(Integer docTypeCode) {
		this.docTypeCode = docTypeCode;
	}

	public String getSenderOrgName() {
		return senderOrgName;
	}

	public void setSenderOrgName(String senderOrgName) {
		this.senderOrgName = senderOrgName;
	}

	public String getAuthButtonEnableFlag() {
		return authButtonEnableFlag;
	}

	public void setAuthButtonEnableFlag(String authButtonEnableFlag) {
		this.authButtonEnableFlag = authButtonEnableFlag;
	}

	public String getRejButtonEnableFlag() {
		return rejButtonEnableFlag;
	}

	public void setRejButtonEnableFlag(String rejButtonEnableFlag) {
		this.rejButtonEnableFlag = rejButtonEnableFlag;
	}

	/**
	 * @return the statusValue
	 */
	public String getStatusValue() {
		return statusValue;
	}

	/**
	 * @param statusValue the statusValue to set
	 */
	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}

	/**
	 * @return the statusKey
	 */
	public String getStatusKey() {
		return statusKey;
	}

	/**
	 * @param statusKey the statusKey to set
	 */
	public void setStatusKey(String statusKey) {
		this.statusKey = statusKey;
	}

}
