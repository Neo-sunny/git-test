/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   13-FEB-2017
 * 
 * Purpose:      Invoice Details Ux VO
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 13-FEB-2017				  Sathishkumar B									New VO - S271, S273, S274, S275, S276, S277
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

public class InvoiceDetailsUxVO extends AbstractVO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8565085696032279383L;

	private String invoiceNo;
	
	private String issueDate;
	
	private String dueDate;
	
	private String invoiceCCY;
	
	private String originalAmount;
	
	private String cnUtilizedAmount;
	
	private String buyerRef;
	
	private String sellerRef;
	
	private String updatedAmount;

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public String getInvoiceCCY() {
		return invoiceCCY;
	}

	public void setInvoiceCCY(String invoiceCCY) {
		this.invoiceCCY = invoiceCCY;
	}

	public String getOriginalAmount() {
		return originalAmount;
	}

	public void setOriginalAmount(String originalAmount) {
		this.originalAmount = originalAmount;
	}

	public String getCnUtilizedAmount() {
		return cnUtilizedAmount;
	}

	public void setCnUtilizedAmount(String cnUtilizedAmount) {
		this.cnUtilizedAmount = cnUtilizedAmount;
	}

	public String getBuyerRef() {
		return buyerRef;
	}

	public void setBuyerRef(String buyerRef) {
		this.buyerRef = buyerRef;
	}

	public String getSellerRef() {
		return sellerRef;
	}

	public void setSellerRef(String sellerRef) {
		this.sellerRef = sellerRef;
	}

	public String getUpdatedAmount() {
		return updatedAmount;
	}

	public void setUpdatedAmount(String updatedAmount) {
		this.updatedAmount = updatedAmount;
	}

	
	
	
}
