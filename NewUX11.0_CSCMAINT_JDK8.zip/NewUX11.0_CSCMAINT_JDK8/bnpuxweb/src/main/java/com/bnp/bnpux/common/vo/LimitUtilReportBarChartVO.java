package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;
import com.bnp.scm.services.discounting.vo.LimitUtilReportVO;

public class LimitUtilReportBarChartVO {
	
	private BigDecimal entityAvblLimitPtg;
	
	private boolean showEntityAvblLimitPtg;
	
	private BigDecimal effectiveAvlAmtPtg;
	
	private boolean showEffectiveAvlAmtPtg;
	
	private BigDecimal entityUtilizedLimitPtg;
	
	private boolean showEntityUtilizedLimitPtg;
	
	private BigDecimal entityBlokLimitPtg;
	
	private boolean showEntityBlokLimitPtg;
	
	private BigDecimal totalAmount;
	
	private LimitUtilReportVO limitUtilReportVO;

	public BigDecimal getEntityAvblLimitPtg() {
		return entityAvblLimitPtg;
	}

	public void setEntityAvblLimitPtg(BigDecimal entityAvblLimitPtg) {
		this.entityAvblLimitPtg = entityAvblLimitPtg;
	}

	public BigDecimal getEffectiveAvlAmtPtg() {
		return effectiveAvlAmtPtg;
	}

	public void setEffectiveAvlAmtPtg(BigDecimal effectiveAvlAmtPtg) {
		this.effectiveAvlAmtPtg = effectiveAvlAmtPtg;
	}

	public BigDecimal getEntityUtilizedLimitPtg() {
		return entityUtilizedLimitPtg;
	}

	public void setEntityUtilizedLimitPtg(BigDecimal entityUtilizedLimitPtg) {
		this.entityUtilizedLimitPtg = entityUtilizedLimitPtg;
	}

	public BigDecimal getEntityBlokLimitPtg() {
		return entityBlokLimitPtg;
	}

	public void setEntityBlokLimitPtg(BigDecimal entityBlokLimitPtg) {
		this.entityBlokLimitPtg = entityBlokLimitPtg;
	}

	public BigDecimal getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}

	public LimitUtilReportVO getLimitUtilReportVO() {
		return limitUtilReportVO;
	}

	public void setLimitUtilReportVO(LimitUtilReportVO limitUtilReportVO) {
		this.limitUtilReportVO = limitUtilReportVO;
	}

	public boolean isShowEntityAvblLimitPtg() {
		return showEntityAvblLimitPtg;
	}

	public void setShowEntityAvblLimitPtg(boolean showEntityAvblLimitPtg) {
		this.showEntityAvblLimitPtg = showEntityAvblLimitPtg;
	}

	public boolean isShowEffectiveAvlAmtPtg() {
		return showEffectiveAvlAmtPtg;
	}

	public void setShowEffectiveAvlAmtPtg(boolean showEffectiveAvlAmtPtg) {
		this.showEffectiveAvlAmtPtg = showEffectiveAvlAmtPtg;
	}

	public boolean isShowEntityUtilizedLimitPtg() {
		return showEntityUtilizedLimitPtg;
	}

	public void setShowEntityUtilizedLimitPtg(boolean showEntityUtilizedLimitPtg) {
		this.showEntityUtilizedLimitPtg = showEntityUtilizedLimitPtg;
	}

	public boolean isShowEntityBlokLimitPtg() {
		return showEntityBlokLimitPtg;
	}

	public void setShowEntityBlokLimitPtg(boolean showEntityBlokLimitPtg) {
		this.showEntityBlokLimitPtg = showEntityBlokLimitPtg;
	}

}
