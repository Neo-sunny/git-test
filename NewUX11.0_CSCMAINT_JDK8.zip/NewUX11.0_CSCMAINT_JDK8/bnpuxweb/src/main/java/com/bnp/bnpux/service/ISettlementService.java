/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas.
 * 
 * Created on:   06 June 2016	
 * 
 * Purpose:      Payment Order Service Interface
 * 
 * Change History: 
 * Date                                    Author                                                                               Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 06 June 2016						    Bala Murugan Elangovan														 	 Service Interface 
 * *****************************************************************************************************************************************************************/
package com.bnp.bnpux.service;


import com.bnp.bnpux.vo.requestVO.InProcessAlreadySettDetailsRequestVO;
import com.bnp.bnpux.vo.requestVO.SettlementCreditNoteLineItemRequestVO;
import com.bnp.bnpux.vo.requestVO.SettlementInvoiceDetailsRequestVO;
import com.bnp.bnpux.vo.requestVO.SettlementRequestVO;
import com.bnp.bnpux.vo.responseVO.InProcessAlreadySettDetailsResponseVO;
import com.bnp.bnpux.vo.responseVO.SettlementCreditNoteLineItemResponseVO;
import com.bnp.bnpux.vo.responseVO.SettlementInvoiceLineItemResponseVO;
import com.bnp.bnpux.vo.responseVO.SettlementResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface ISettlementService {

	/**
	 * This method is for getting Settlement Details
	 * 
	 * @param settlementRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	SettlementResponseVO getSettlementDetails(SettlementRequestVO settlementRequestVO) throws BNPApplicationException;
	
	
	
	/**
	 * This method is for getting Settlement Details count on Advanced Filter
	 * 
	 * @param settlementRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	SettlementResponseVO getAdvancedFilterCount(SettlementRequestVO settlementRequestVO) throws BNPApplicationException;	

	/**
	 * This method is for getting InProcess Amount Details Callout
	 * 
	 * @param inProcessAmtDetailsRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	// Commented below method since it is merged with Already Paid amount callout
	//AlreadySettledDetailsResponseVO getInProcessAmtDetailsCallout(InProcessAmtDetailsRequestVO inProcessAmtDetailsRequestVO)throws BNPApplicationException;

	/**
	 * This method is for getting Already Paid Amount Details Callout
	 * 
	 * @param alreadySettledDetailsRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	InProcessAlreadySettDetailsResponseVO getInProcessAlreadySettDetailsCallout(InProcessAlreadySettDetailsRequestVO alreadySettledDetailsRequestVO)throws BNPApplicationException;

	/**
	 * This method is for getting Credit Note Line Item details
	 * 
	 * @param settlementCreditNoteLineItemRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	SettlementCreditNoteLineItemResponseVO getSettlementCreditNoteLineItemdetails(SettlementCreditNoteLineItemRequestVO settlementCreditNoteLineItemRequestVO)throws BNPApplicationException;

	/**
	 * This method is for getting Invoice Details
	 * 
	 * @param settlementInvoiceDetailsRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	SettlementInvoiceLineItemResponseVO getSettlementInvoiceDetails(SettlementInvoiceDetailsRequestVO settlementInvoiceDetailsRequestVO)throws BNPApplicationException;	

}
