/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Transaction Confimed Amount Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;

public class TransactionConfimedAmtVO {
	
	private BigDecimal financingAmount;
	
	private BigDecimal	confirmedInterestAmt;
	
	private BigDecimal appliedMinDisFee;
	
	private BigDecimal appliedMinDisFeeSum;
	
	private BigDecimal confirmedChargeAmount;
	
	private BigDecimal confirmedNetAmount;
	
	private String currencyCode;
	
	private String confirmedDiscTenure;
	
	private String confirmedIntRate;

	private String rateChargeType;

	private BigDecimal calcConfIntAmt;
	
	private BigDecimal confirmedNetAmountCallout;
	
	public BigDecimal getCalcConfIntAmt() {
		return calcConfIntAmt;
	}

	public void setCalcConfIntAmt(BigDecimal calcConfIntAmt) {
		this.calcConfIntAmt = calcConfIntAmt;
	}

	public BigDecimal getFinancingAmount() {
		return financingAmount;
	}

	public void setFinancingAmount(BigDecimal financingAmount) {
		this.financingAmount = financingAmount;
	}

	public BigDecimal getConfirmedInterestAmt() {
		return confirmedInterestAmt;
	}

	public void setConfirmedInterestAmt(BigDecimal confirmedInterestAmt) {
		this.confirmedInterestAmt = confirmedInterestAmt;
	}

	public BigDecimal getAppliedMinDisFee() {
		return appliedMinDisFee;
	}

	public void setAppliedMinDisFee(BigDecimal appliedMinDisFee) {
		this.appliedMinDisFee = appliedMinDisFee;
	}

	public BigDecimal getAppliedMinDisFeeSum() {
		return appliedMinDisFeeSum;
	}

	public void setAppliedMinDisFeeSum(BigDecimal appliedMinDisFeeSum) {
		this.appliedMinDisFeeSum = appliedMinDisFeeSum;
	}

	public BigDecimal getConfirmedChargeAmount() {
		return confirmedChargeAmount;
	}

	public void setConfirmedChargeAmount(BigDecimal confirmedChargeAmount) {
		this.confirmedChargeAmount = confirmedChargeAmount;
	}

	public BigDecimal getConfirmedNetAmount() {
		return confirmedNetAmount;
	}

	public void setConfirmedNetAmount(BigDecimal confirmedNetAmount) {
		this.confirmedNetAmount = confirmedNetAmount;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	
	

	public String getConfirmedDiscTenure() {
		return confirmedDiscTenure;
	}

	public void setConfirmedDiscTenure(String confirmedDiscTenure) {
		this.confirmedDiscTenure = confirmedDiscTenure;
	}

	public String getConfirmedIntRate() {
		return confirmedIntRate;
	}

	public void setConfirmedIntRate(String confirmedIntRate) {
		this.confirmedIntRate = confirmedIntRate;
	}

	public String getRateChargeType() {
		return rateChargeType;
	}

	public void setRateChargeType(String rateChargeType) {
		this.rateChargeType = rateChargeType;
	}

	public BigDecimal getConfirmedNetAmountCallout() {
		return confirmedNetAmountCallout;
	}

	public void setConfirmedNetAmountCallout(BigDecimal confirmedNetAmountCallout) {
		this.confirmedNetAmountCallout = confirmedNetAmountCallout;
	}
	
	
	/**
	 * Getter methods introduced to send the amounts as
	 * String to avoid amount > 16 digits getting truncated
	 * Added as part of defect Fix CSC-7835
	 */
	
	public String getCalcConfIntAmtStr() {
		return (calcConfIntAmt!=null)?calcConfIntAmt.toPlainString():"";
	}
	
	public String getFinancingAmountStr() {
		return (financingAmount!=null)?financingAmount.toPlainString():"";
	}
	
	public String getConfirmedInterestAmtStr() {
		return (confirmedInterestAmt!=null)?confirmedInterestAmt.toPlainString():"";
	}
	
	public String getConfirmedChargeAmountStr() {
		return (confirmedChargeAmount!=null)?confirmedChargeAmount.toPlainString():"";
	}
	
	public String getConfirmedNetAmountStr() {
		return (confirmedNetAmount!=null)?confirmedNetAmount.toPlainString():"";
	}
	
	public String getConfirmedNetAmountCalloutStr() {
		return (confirmedNetAmountCallout!=null)?confirmedNetAmountCallout.toPlainString():"";
	}
	
	
	public String getAppliedMinDisFeeStr() {
		return (appliedMinDisFee!=null)?appliedMinDisFee.toPlainString():"";
	}
	
	

}
