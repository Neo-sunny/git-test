/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 March 2017
 * 
 * Purpose:      Release File Functionality
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 March 2017            Oracle Financial Services Software Ltd                  Initial Version 
 * 27 March 2017            Bhuvaneswari                                            S2034 File managementUndo action 
 *  *  *************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.bnp.bnpux.vo.errorMessageVO.ErrorMessageVO;

public class ReleaseFileMgmtResponseVO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<ErrorMessageVO> errMessageVO = new ArrayList<ErrorMessageVO>();
	private List<FileMgmtResponseGridVO> fileMgmtResponseGridVO = new ArrayList<FileMgmtResponseGridVO>();
	
	/**
	 * @return the fileMgmtResponseGridVO
	 */
	public List<FileMgmtResponseGridVO> getFileMgmtResponseGridVO() {
		return fileMgmtResponseGridVO;
	}
	/**
	 * @param fileMgmtResponseGridVO the fileMgmtResponseGridVO to set
	 */
	public void setFileMgmtResponseGridVO(
			List<FileMgmtResponseGridVO> fileMgmtResponseGridVO) {
		this.fileMgmtResponseGridVO = fileMgmtResponseGridVO;
	}
	/**
	 * @return the errMessageVO
	 */
	public List<ErrorMessageVO> getErrMessageVO() {
		return errMessageVO;
	}
	/**
	 * @param errMessageVO the errMessageVO to set
	 */
	public void setErrMessageVO(List<ErrorMessageVO> errMessageVO) {
		this.errMessageVO = errMessageVO;
	}
	
	
	

}
