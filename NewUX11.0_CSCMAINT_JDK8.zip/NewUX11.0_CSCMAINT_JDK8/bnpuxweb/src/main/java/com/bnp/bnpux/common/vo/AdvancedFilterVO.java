/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   02-Mar-2017
 * 
 * Purpose:      Advanced Filter VO
 * 
 * Change History:
 *  
 * Date                       Author                                            Reason
 * 02-Mar-2017			Bala Murugan Elangovan					Base version for Advanced filter VO 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/

package com.bnp.bnpux.common.vo;

import java.util.Date;
import java.util.List;

public class AdvancedFilterVO {
	
	private String filterId;
	
	private String filterName;
	
	private String operatorId;
	
	private String operatorName;
	
	private String filterFromValue;
	
	private String filterToValue;
	
	private String filterElementId;
	
	private String filterElementValue;
	
	private List userFilterObject;
	
	private String getWhat;
	
	private String advanceFilterId;
	
	private String advanceFilterName;
	
	private String eligibleOperator;
	
	private Integer filterSequence;
	
	private String labelId;
	
	private String fromValueLabelId;
	
	private String toValueLabelId;
	
	private String defaultOperatorId;
	
	private String screenElementType;
	
	private String dataType;
	
	private Integer fieldLength;
	
	private String recordStatus;

	private String screenRefFieldId;
	
	private String screenFromFieldId;
	
	private String screenToFieldId;
	
	private String userId;
	
	private String userTypeId;
	
	private String screenName;
	
	private String errorFlag;
	
	private String errorMessage;

	private String periodCategory;
	
	private Date sysdate;
	
	private String branchId;
	
	List<AdvancedFilterVO> advancedFilterList;
	
	List<AdvancedFilterVO> periodDateList;
	
	private Date periodFromDate;
	
	private Date periodToDate;	

	private String userPreferenceFilterKey;
	
	private String userPreferenceFilterName;	
	
	private String fromValue;	
	
	private String toValue;	
	
	private String valueList;	
	
	private Object[] autoFillList;	

	
	public String getUserPreferenceFilterKey() {
		return userPreferenceFilterKey;
	}

	public void setUserPreferenceFilterKey(String userPreferenceFilterKey) {
		this.userPreferenceFilterKey = userPreferenceFilterKey;
	}

	public String getUserPreferenceFilterName() {
		return userPreferenceFilterName;
	}

	public void setUserPreferenceFilterName(String userPreferenceFilterName) {
		this.userPreferenceFilterName = userPreferenceFilterName;
	}

	

	public String getFilterElementValue() {
		return filterElementValue;
	}

	public void setFilterElementValue(String filterElementValue) {
		this.filterElementValue = filterElementValue;
	}

	public String getGetWhat() {
		return getWhat;
	}

	public void setGetWhat(String getWhat) {
		this.getWhat = getWhat;
	}

	public String getFilterElementId() {
		return filterElementId;
	}

	public void setFilterElementId(String filterElementId) {
		this.filterElementId = filterElementId;
	}

	public List getUserFilterObject() {
		return userFilterObject;
	}

	public void setUserFilterObject(List userFilterObject) {
		this.userFilterObject = userFilterObject;
	}

	public String getFilterId() {
		return filterId;
	}

	public void setFilterId(String filterId) {
		this.filterId = filterId;
	}

	public String getFilterName() {
		return filterName;
	}

	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}

	public String getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(String operatorId) {
		this.operatorId = operatorId;
	}

	public String getOperatorName() {
		return operatorName;
	}

	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}

	public String getFilterFromValue() {
		return filterFromValue;
	}

	public void setFilterFromValue(String filterFromValue) {
		this.filterFromValue = filterFromValue;
	}

	public String getFilterToValue() {
		return filterToValue;
	}

	public void setFilterToValue(String filterToValue) {
		this.filterToValue = filterToValue;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserTypeId() {
		return userTypeId;
	}

	public void setUserTypeId(String userTypeId) {
		this.userTypeId = userTypeId;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public String getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	public String getPeriodCategory() {
		return periodCategory;
	}

	public void setPeriodCategory(String periodCategory) {
		this.periodCategory = periodCategory;
	}

	public Date getSysdate() {
		return sysdate;
	}

	public void setSysdate(Date sysdate) {
		this.sysdate = sysdate;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public List<AdvancedFilterVO> getAdvancedFilterList() {
		return advancedFilterList;
	}

	public void setAdvancedFilterList(List<AdvancedFilterVO> advancedFilterList) {
		this.advancedFilterList = advancedFilterList;
	}

	public List<AdvancedFilterVO> getPeriodDateList() {
		return periodDateList;
	}

	public void setPeriodDateList(List<AdvancedFilterVO> periodDateList) {
		this.periodDateList = periodDateList;
	}

	public Date getPeriodFromDate() {
		return periodFromDate;
	}

	public void setPeriodFromDate(Date periodFromDate) {
		this.periodFromDate = periodFromDate;
	}

	public Date getPeriodToDate() {
		return periodToDate;
	}

	public void setPeriodToDate(Date periodToDate) {
		this.periodToDate = periodToDate;
	}

	public String getScreenFromFieldId() {
		return screenFromFieldId;
	}

	public void setScreenFromFieldId(String screenFromFieldId) {
		this.screenFromFieldId = screenFromFieldId;
	}

	public String getScreenToFieldId() {
		return screenToFieldId;
	}

	public void setScreenToFieldId(String screenToFieldId) {
		this.screenToFieldId = screenToFieldId;
	}

	public String getScreenRefFieldId() {
		return screenRefFieldId;
	}

	public void setScreenRefFieldId(String screenRefFieldId) {
		this.screenRefFieldId = screenRefFieldId;
	}

	public String getAdvanceFilterId() {
		return advanceFilterId;
	}

	public void setAdvanceFilterId(String advanceFilterId) {
		this.advanceFilterId = advanceFilterId;
	}

	public String getAdvanceFilterName() {
		return advanceFilterName;
	}

	public void setAdvanceFilterName(String advanceFilterName) {
		this.advanceFilterName = advanceFilterName;
	}

	public String getEligibleOperator() {
		return eligibleOperator;
	}

	public void setEligibleOperator(String eligibleOperator) {
		this.eligibleOperator = eligibleOperator;
	}

	public Integer getFilterSequence() {
		return filterSequence;
	}

	public void setFilterSequence(Integer filterSequence) {
		this.filterSequence = filterSequence;
	}

	public String getLabelId() {
		return labelId;
	}

	public void setLabelId(String labelId) {
		this.labelId = labelId;
	}

	public String getFromValueLabelId() {
		return fromValueLabelId;
	}

	public void setFromValueLabelId(String fromValueLabelId) {
		this.fromValueLabelId = fromValueLabelId;
	}

	public String getToValueLabelId() {
		return toValueLabelId;
	}

	public void setToValueLabelId(String toValueLabelId) {
		this.toValueLabelId = toValueLabelId;
	}

	public String getDefaultOperatorId() {
		return defaultOperatorId;
	}

	public void setDefaultOperatorId(String defaultOperatorId) {
		this.defaultOperatorId = defaultOperatorId;
	}

	public String getScreenElementType() {
		return screenElementType;
	}

	public void setScreenElementType(String screenElementType) {
		this.screenElementType = screenElementType;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	
	public Integer getFieldLength() {
		return fieldLength;
	}

	public void setFieldLength(Integer fieldLength) {
		this.fieldLength = fieldLength;
	}

	public String getRecordStatus() {
		return recordStatus;
	}

	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getFromValue() {
		return fromValue;
	}

	public void setFromValue(String fromValue) {
		this.fromValue = fromValue;
	}

	public String getToValue() {
		return toValue;
	}

	public void setToValue(String toValue) {
		this.toValue = toValue;
	}

	public String getValueList() {
		return valueList;
	}

	public void setValueList(String valueList) {
		this.valueList = valueList;
	}

	public Object[] getAutoFillList() {
		return autoFillList;
	}

	public void setAutoFillList(Object[] autoFillList) {
		this.autoFillList = autoFillList;
	}

}
