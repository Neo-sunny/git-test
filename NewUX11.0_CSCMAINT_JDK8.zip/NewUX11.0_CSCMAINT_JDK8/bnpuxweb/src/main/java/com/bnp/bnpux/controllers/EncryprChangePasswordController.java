package com.bnp.bnpux.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.util.RequestIdentityValidator;
import com.bnp.scm.services.common.ChangePasswordRequestVO;
import com.bnp.scm.services.common.SSMAuthService;
@RestController
@RequestMapping("/EncryptSecurityBeanCtrl")
public class EncryprChangePasswordController {
	public static final Logger log = LoggerFactory.getLogger(EncryprChangePasswordController.class);
	
	
	
    @Autowired
	RequestIdentityValidator validateRequest;
    @Autowired
	private SSMAuthService ssmAuthService;
    
    @RequestMapping(value = "getPublicComponentInfo.rest", method = RequestMethod.POST)
	public  ChangePasswordRequestVO EncryptPawwordChange(@RequestBody ChangePasswordRequestVO changePasswordRequestVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		   
		try {
			
			String publicExponent = changePasswordRequestVO.getPublicExponent();
			String nodulus = changePasswordRequestVO.getModulus();
			
			boolean requestValidatedFlag = validateRequest.validate(changePasswordRequestVO.getUserId(), httpServletRequest.getSession());
			if(requestValidatedFlag){				    								
				ssmAuthService.initialize();
				HttpSession session = httpServletRequest.getSession(false);				
				
				changePasswordRequestVO.setPublicExponent(ssmAuthService.getPublicExponent());
				changePasswordRequestVO.setModulus(ssmAuthService.getModulus());
				changePasswordRequestVO.setSessionID(session.getId());
				return changePasswordRequestVO;
				
			}else{
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} 
		catch (Exception exception) {
			log.error("Error occured in method EncryptPawwordChange() ", exception);
		}
	return changePasswordRequestVO;
    }
}
