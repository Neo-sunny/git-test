/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   21 June 2017
 * 
 * Purpose:      Limit Utilization Report Service Implementation
 * 
 * Change History:
 *  
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 21 June 2017       Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.constants;

public interface LimitUtilizationConstants {
	
	public static final String VIEW_TYPE = "viewType";
	
	public static final String LIMIT_UTILIZATION_LIST = "limitUtilizationReportList";//"creditNoteInqList";
	
	public static final String LIMIT_UTILIZATION_DETAILS = "limitUtilizationReportDetails";// "creditNoteInqListDetails";
	

}
