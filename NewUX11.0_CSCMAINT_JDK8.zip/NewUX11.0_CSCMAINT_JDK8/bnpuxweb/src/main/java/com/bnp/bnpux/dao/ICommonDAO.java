/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Common Interface for Data Access Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 23-Feb-2017				AnubhaJ												modified FO 10.0 S015,S016,S017
************************************************************************************************************************************************************/
package com.bnp.bnpux.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.bnp.bnpux.common.vo.CountryFlagVO;
import com.bnp.bnpux.common.vo.UserBranchVO;

public interface ICommonDAO {

	/**
	 * This method is for getting Branch cut off time
	 * 
	 * @param userBranch
	 * @return
	 */
	public List<Map<String,String>> getBranchesCutOffTime(UserBranchVO userBranch);
	
	/**
	 * This method is for getting country flag
	 * 
	 * @param countryCd
	 * @return
	 */
	public CountryFlagVO getCountryFlag(String countryCd);
	
	/**
	 * This method is for getting Perishable popup timout 
	 * @return
	 */
	public int getPerishablePopupTimeOut();
	
	/*
	 * FO 10.0 S015 :Contact Us Location drop down
	 */
	public List<CountryFlagVO> fetchCountryList();
}
