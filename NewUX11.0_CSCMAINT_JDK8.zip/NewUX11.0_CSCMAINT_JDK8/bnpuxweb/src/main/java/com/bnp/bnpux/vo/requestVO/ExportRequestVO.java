/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     Export Request Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 * 28 Feb 2017                    Aarthee Srinivasan                                  FO 10.0
************************************************************************************************************************************************************/	
	package com.bnp.bnpux.vo.requestVO;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.util.Date;
import java.util.List;

import com.bnp.bnpux.common.vo.AdvancedFilterVO;



	public class ExportRequestVO {
		
		private String userId;

		private String userType;

		private String orgId;
		
		private String leadOrgId;

		private String currencyCode;

		private String paymentOrderNo;

		private String paymentOrderStatus;
		
		private Date maturityDate;	
		
		private Integer recordFrom;
		
		private Integer recordTo;
		
		private Integer recordCount;
		
		private String maturityFilter;
		
		private String errorFlag;
		
		private String advanceFilter;
		
		private String groupIndicator;
		
		private String viewType;
		
		private String supplierOrgId;
		
		private String buyerOrgId;
		
		private java.util.Date paymentDate;
		
		private java.sql.Date paymentDate1;
		
		private String buyerRefNoUniqueValue;
		
		private String paymentFlagValue;
		
		private String leadOrgIdValue;
		
		private String periodFilter;
		
		private String statusFilter;
		
		private String branchFilter;
		
		private String exportType;
		
		private String pageInfo;
		
		private String langPreferance;
		
		private String quickSearch;
		
		private String discountRefNumber;

		private String counterPartyOrgId;
		
		private Date fromDate;
		
		private Date toDate;
		
		private Date fromMDate;
		
		private Date toMDate;
		
		private BigDecimal fromAmount;
		
		private BigDecimal toAmount;
		
		private String fileFilter;
		
		private String branchNameFilter;
		
		private String buyerNameFilter;
		
		private String supplierNameFilter;
		
		private String periodNameFilter;
		
		private String statusNameFilter;
		
		private String fromAmountFilter;
		
		private String toAmountFilter;
		
		private String plotParamValue;
		
		private String pagePopUpInfo;
		
		private String paymentId;
		
		private String discRefNo;
		
		private String recFlag;
		
		private String fileName;
		
		//CMA
		
		private String getWhat;
		
		private String reportType;
		
		private String reportTypeName;
		
		private Date projSettleDate;
		
		private String limitType;
		
		private String limitTypeFilter;
		
		private String orgIdFilter;
		
		private String counterPartyOrgIdFilter;
		
		private String reportFrequency;
		
		private String reportScheduleID;
		
		private String reportFromDateTime;
		
		private String reportToDateTime;
		
		private List<String> sectionsList;
		
		private List<ResultSet> sectionsData;
		
		private List<List<String>> sectionsHeader;
		

		private String creditNoteRefNum;
		
		private String utilizationRefNum;
		
		private String duePeriod; 
		
		private String dueDays;
		
		private String discType;

		
		List<AdvancedFilterVO> advancedFilterListVO;	

		private String chartName;
		
		public List<AdvancedFilterVO> getAdvancedFilterListVO() {
			return advancedFilterListVO;
		}

		public void setAdvancedFilterListVO(List<AdvancedFilterVO> advancedFilterListVO) {
			this.advancedFilterListVO = advancedFilterListVO;
		}
		
		public List<List<String>> getSectionsHeader() {
			return sectionsHeader;
		}

		public void setSectionsHeader(List<List<String>> sectionsHeader) {
			this.sectionsHeader = sectionsHeader;
		}

		public String getCreditNoteRefNum() {
			return creditNoteRefNum;
		}

		public void setCreditNoteRefNum(String creditNoteRefNum) {
			this.creditNoteRefNum = creditNoteRefNum;
		}

		public String getUtilizationRefNum() {
			return utilizationRefNum;
		}

		public void setUtilizationRefNum(String utilizationRefNum) {
			this.utilizationRefNum = utilizationRefNum;
		}

		public List<ResultSet> getSectionsData() {
			return sectionsData;
		}

		public void setSectionsData(List<ResultSet> sectionsData) {
			this.sectionsData = sectionsData;
		}

		public List<String> getSectionsList() {
			return sectionsList;
		}

		public void setSectionsList(List<String> sectionsList) {
			this.sectionsList = sectionsList;
		}

		public String getRecFlag() {
			return recFlag;
		}

		public void setRecFlag(String recFlag) {
			this.recFlag = recFlag;
		}
		
		public String getDiscRefNo() {
			return discRefNo;
		}

		public void setDiscRefNo(String discRefNo) {
			this.discRefNo = discRefNo;
		}
		
		public String getPagePopUpInfo() {
			return pagePopUpInfo;
		}

		public void setPagePopUpInfo(String pagePopUpInfo) {
			this.pagePopUpInfo = pagePopUpInfo;
		}

		public String getPaymentId() {
			return paymentId;
		}

		public void setPaymentId(String paymentId) {
			this.paymentId = paymentId;
		}
				
		public void setCounterPartyOrgId(String counterPartyOrgId) {
			this.counterPartyOrgId = counterPartyOrgId;
		}

		public String getDiscountRefNumber() {
			return discountRefNumber;
		}

		public void setDiscountRefNumber(String discountRefNumber) {
			this.discountRefNumber = discountRefNumber;
		}

		public String getQuickSearch() {
			return quickSearch;
		}

		public void setQuickSearch(String quickSearch) {
			this.quickSearch = quickSearch;
		}

		public String getPeriodFilter() {
			return periodFilter;
		}

		public void setPeriodFilter(String periodFilter) {
			this.periodFilter = periodFilter;
		}

		public String getStatusFilter() {
			return statusFilter;
		}

		public void setStatusFilter(String statusFilter) {
			this.statusFilter = statusFilter;
		}
		public String getPaymentFlagValue() {
			return paymentFlagValue;
		}

		public void setPaymentFlagValue(String paymentFlagValue) {
			this.paymentFlagValue = paymentFlagValue;
		}

		public String getLeadOrgIdValue() {
			return leadOrgIdValue;
		}

		public void setLeadOrgIdValue(String leadOrgIdValue) {
			this.leadOrgIdValue = leadOrgIdValue;
		}

		public String getBuyerRefNoUniqueValue() {
			return buyerRefNoUniqueValue;
		}

		public void setBuyerRefNoUniqueValue(String buyerRefNoUniqueValue) {
			this.buyerRefNoUniqueValue = buyerRefNoUniqueValue;
		}

		public String getUserId() {
			return userId;
		}

		public void setUserId(String userId) {
			this.userId = userId;
		}

		public String getUserType() {
			return userType;
		}

		public void setUserType(String userType) {
			this.userType = userType;
		}

		public String getOrgId() {
			return orgId;
		}

		public void setOrgId(String orgId) {
			this.orgId = orgId;
		}

		public String getLeadOrgId() {
			return leadOrgId;
		}

		public void setLeadOrgId(String leadOrgId) {
			this.leadOrgId = leadOrgId;
		}

		public String getCurrencyCode() {
			return currencyCode;
		}

		public void setCurrencyCode(String currencyCode) {
			this.currencyCode = currencyCode;
		}

		public String getPaymentOrderNo() {
			return paymentOrderNo;
		}

		public void setPaymentOrderNo(String paymentOrderNo) {
			this.paymentOrderNo = paymentOrderNo;
		}

		public String getPaymentOrderStatus() {
			return paymentOrderStatus;
		}

		public void setPaymentOrderStatus(String paymentOrderStatus) {
			this.paymentOrderStatus = paymentOrderStatus;
		}

		public Date getMaturityDate() {
			return maturityDate;
		}

		public void setMaturityDate(Date maturityDate) {
			this.maturityDate = maturityDate;
		}

		public Integer getRecordFrom() {
			return recordFrom;
		}

		public void setRecordFrom(Integer recordFrom) {
			this.recordFrom = recordFrom;
		}

		public Integer getRecordTo() {
			return recordTo;
		}

		public void setRecordTo(Integer recordTo) {
			this.recordTo = recordTo;
		}

		public Integer getRecordCount() {
			return recordCount;
		}

		public void setRecordCount(Integer recordCount) {
			this.recordCount = recordCount;
		}

		public String getMaturityFilter() {
			return maturityFilter;
		}

		public void setMaturityFilter(String maturityFilter) {
			this.maturityFilter = maturityFilter;
		}

		public String getErrorFlag() {
			return errorFlag;
		}

		public void setErrorFlag(String errorFlag) {
			this.errorFlag = errorFlag;
		}

		public String getAdvanceFilter() {
			return advanceFilter;
		}

		public void setAdvanceFilter(String advanceFilter) {
			this.advanceFilter = advanceFilter;
		}

		public String getGroupIndicator() {
			return groupIndicator;
		}

		public void setGroupIndicator(String groupIndicator) {
			this.groupIndicator = groupIndicator;
		}

		public String getViewType() {
			return viewType;
		}

		public void setViewType(String viewType) {
			this.viewType = viewType;
		}

		public String getSupplierOrgId() {
			return supplierOrgId;
		}

		public void setSupplierOrgId(String supplierOrgId) {
			this.supplierOrgId = supplierOrgId;
		}

		public String getBuyerOrgId() {
			return buyerOrgId;
		}

		public void setBuyerOrgId(String buyerOrgId) {
			this.buyerOrgId = buyerOrgId;
		}

		public Date getPaymentDate() {
			return paymentDate;
		}

		public void setPaymentDate(Date paymentDate) {
			this.paymentDate = paymentDate;
		}

		public String getBranchFilter() {
			return branchFilter;
		}

		public void setBranchFilter(String branchFilter) {
			this.branchFilter = branchFilter;
		}

		public String getExportType() {
			return exportType;
		}

		public void setExportType(String exportType) {
			this.exportType = exportType;
		}

		public String getPageInfo() {
			return pageInfo;
		}

		public void setPageInfo(String pageInfo) {
			this.pageInfo = pageInfo;
		}

		public String getLangPreferance() {
			return langPreferance;
		}

		public void setLangPreferance(String langPreferance) {
			this.langPreferance = langPreferance;
		}

		public java.sql.Date getPaymentDate1() {
			return paymentDate1;
		}

		public void setPaymentDate1(java.sql.Date paymentDate1) {
			this.paymentDate1 = paymentDate1;
		}

		public String getCounterPartyOrgId() {
			return counterPartyOrgId;
		}

		public Date getFromDate() {
			return fromDate;
		}

		public void setFromDate(Date fromDate) {
			this.fromDate = fromDate;
		}

		public Date getToDate() {
			return toDate;
		}

		public void setToDate(Date toDate) {
			this.toDate = toDate;
		}

		public BigDecimal getFromAmount() {
			return fromAmount;
		}

		public void setFromAmount(BigDecimal fromAmount) {
			this.fromAmount = fromAmount;
		}

		public BigDecimal getToAmount() {
			return toAmount;
		}

		public void setToAmount(BigDecimal toAmount) {
			this.toAmount = toAmount;
		}

		public String getFileFilter() {
			return fileFilter;
		}

		public void setFileFilter(String fileFilter) {
			this.fileFilter = fileFilter;
		}
		
		public String getBranchNameFilter() {
			return branchNameFilter;
		}

		public void setBranchNameFilter(String branchNameFilter) {
			this.branchNameFilter = branchNameFilter;
		}
		
		public String getBuyerNameFilter() {
			return buyerNameFilter;
		}

		public void setBuyerNameFilter(String buyerNameFilter) {
			this.buyerNameFilter = buyerNameFilter;
		}

		public String getSupplierNameFilter() {
			return supplierNameFilter;
		}

		public void setSupplierNameFilter(String supplierNameFilter) {
			this.supplierNameFilter = supplierNameFilter;
		}

		public String getPeriodNameFilter() {
			return periodNameFilter;
		}

		public void setPeriodNameFilter(String periodNameFilter) {
			this.periodNameFilter = periodNameFilter;
		}

		public String getStatusNameFilter() {
			return statusNameFilter;
		}

		public void setStatusNameFilter(String statusNameFilter) {
			this.statusNameFilter = statusNameFilter;
		}

		public String getFromAmountFilter() {
			return fromAmountFilter;
		}

		public void setFromAmountFilter(String fromAmountFilter) {
			this.fromAmountFilter = fromAmountFilter;
		}

		public String getToAmountFilter() {
			return toAmountFilter;
		}

		public void setToAmountFilter(String toAmountFilter) {
			this.toAmountFilter = toAmountFilter;
		}

		public String getPlotParamValue() {
			return plotParamValue;
		}

		public void setPlotParamValue(String plotParamValue) {
			this.plotParamValue = plotParamValue;
		}

		public String getFileName() {
			return fileName;
		}

		public void setFileName(String fileName) {
			this.fileName = fileName;
		}

		public String getGetWhat() {
			return getWhat;
		}

		public void setGetWhat(String getWhat) {
			this.getWhat = getWhat;
		}

		public String getReportType() {
			return reportType;
		}

		public void setReportType(String reportType) {
			this.reportType = reportType;
		}

		public String getReportTypeName() {
			return reportTypeName;
		}

		public void setReportTypeName(String reportTypeName) {
			this.reportTypeName = reportTypeName;
		}

		public Date getProjSettleDate() {
			return projSettleDate;
		}

		public void setProjSettleDate(Date projSettleDate) {
			this.projSettleDate = projSettleDate;
		}

		public String getLimitType() {
			return limitType;
		}

		public void setLimitType(String limitType) {
			this.limitType = limitType;
		}

		public String getLimitTypeFilter() {
			return limitTypeFilter;
		}

		public void setLimitTypeFilter(String limitTypeFilter) {
			this.limitTypeFilter = limitTypeFilter;
		}

		public String getOrgIdFilter() {
			return orgIdFilter;
		}

		public void setOrgIdFilter(String orgIdFilter) {
			this.orgIdFilter = orgIdFilter;
		}

		public String getCounterPartyOrgIdFilter() {
			return counterPartyOrgIdFilter;
		}

		public void setCounterPartyOrgIdFilter(String counterPartyOrgIdFilter) {
			this.counterPartyOrgIdFilter = counterPartyOrgIdFilter;
		}

		public String getReportFrequency() {
			return reportFrequency;
		}

		public void setReportFrequency(String reportFrequency) {
			this.reportFrequency = reportFrequency;
		}

		public String getReportScheduleID() {
			return reportScheduleID;
		}

		public void setReportScheduleID(String reportScheduleID) {
			this.reportScheduleID = reportScheduleID;
		}

		public String getReportFromDateTime() {
			return reportFromDateTime;
		}

		public void setReportFromDateTime(String reportFromDateTime) {
			this.reportFromDateTime = reportFromDateTime;
		}

		public String getReportToDateTime() {
			return reportToDateTime;
		}

		public void setReportToDateTime(String reportToDateTime) {
			this.reportToDateTime = reportToDateTime;
		}
		public Date getFromMDate() {
			return fromMDate;
		}

		public void setFromMDate(Date fromMDate) {
			this.fromMDate = fromMDate;
		}

		public Date getToMDate() {
			return toMDate;
		}

		public void setToMDate(Date toMDate) {
			this.toMDate = toMDate;
		}
				
		public String getChartName() {
			return chartName;
		}

		public void setChartName(String chartName) {
			this.chartName = chartName;
		}

		public String getDuePeriod() {
			return duePeriod;
		}

		public void setDuePeriod(String duePeriod) {
			this.duePeriod = duePeriod;
		}

		public String getDueDays() {
			return dueDays;
		}

		public void setDueDays(String dueDays) {
			this.dueDays = dueDays;
		}

		public String getDiscType() {
			return discType;
		}

		public void setDiscType(String discType) {
			this.discType = discType;
		}

		

	}
