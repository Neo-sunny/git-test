/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas.
 * 
 * Created on:   25 APR 2016
 * 
 * Purpose:      Create User Service Interface
 * 
 * Change History: 
 * Date                                    Author                                                                               Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 25 APR 2016						    Bala Murugan Elangovan														 	 Recall Implementation 
 * *****************************************************************************************************************************************************************/

package com.bnp.bnpux.serviceimpl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;


import com.bnp.bnpux.constants.ErrorConstants;
import com.bnp.bnpux.dao.ICreateUserDAO;
import com.bnp.bnpux.service.ICreateUserService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;

/**
 * The Class CreateUserServiceImpl.
 */
@Component
public class CreateUserServiceImpl implements ICreateUserService {
	
	/**
	 * Logger log for CreateUserServiceImpl class
	 */
	public static final Logger log = LoggerFactory.getLogger(CreateUserServiceImpl.class);
	
	/**
	 * ICreateUserDAO createUserDAO;
	 */
	@Autowired
	private ICreateUserDAO createUserDAO;
	
	/**
	 * Populate language list.
	 *
	 * @return NameValueVO list
	 * @throws BNPApplicationException the bNP application exception
	 */
	@Override
	public List<NameValueVO> populateLanguageList() throws BNPApplicationException {
		List<NameValueVO> lanList=null;
		try {			
			lanList=createUserDAO.populatePrefLanguageList();
		} 
		catch (DataAccessException exception) {
			log.error(exception.getMessage(),exception);
			throw new BNPApplicationException(ErrorConstants.ERROR_POPULATE_LANGUAGE,exception.getMessage());
		}
		catch (RuntimeException exception) {
			log.error(exception.getMessage(),exception);
			throw new BNPApplicationException(ErrorConstants.ERROR_POPULATE_LANGUAGE,exception.getMessage());
		}
		return lanList;
	}

	/**
	 * Populate country list.
	 *
	 * @return NameValueVO list
	 * @throws BNPApplicationException the bNP application exception
	 */
	@Override
	public List<NameValueVO> populateCountryList() throws BNPApplicationException {
		List<NameValueVO> conList=null;
		try {
			conList=createUserDAO.populateCountryList();
		} 
		catch (DataAccessException exception) {
			log.error(exception.getMessage(),exception);
			throw new BNPApplicationException(ErrorConstants.ERROR_POPULATE_COUNTRY,exception.getMessage());
		}
		catch (RuntimeException exception) {
			log.error(exception.getMessage(),exception);
			throw new BNPApplicationException(ErrorConstants.ERROR_POPULATE_COUNTRY,exception.getMessage());
		}
		return conList;
	}
	
}
