/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:      Settlement Response Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.responseVO;

import java.util.List;

import com.bnp.bnpux.common.vo.SettlementListDetailsVO;
import com.bnp.bnpux.common.vo.SettlementListVO;
import com.bnp.bnpux.common.vo.SettlementSummaryVO;
import com.bnp.bnpux.common.vo.StatusDetailsVO;

public class SettlementResponseVO {
	
	private String errorMsg;
	
	private List<SettlementSummaryVO> settlementSummaryList;
	
	private List<SettlementListVO> settlementListVO;
	
	private List<SettlementListDetailsVO> settlementListDetailsVO;
	
	
	private List<StatusDetailsVO> statusDet;




	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	

	public List<StatusDetailsVO> getStatusDet() {
		return statusDet;
	}

	public void setStatusDet(List<StatusDetailsVO> statusDet) {
		this.statusDet = statusDet;
	}

	public List<SettlementListVO> getSettlementListVO() {
		return settlementListVO;
	}

	public void setSettlementListVO(List<SettlementListVO> settlementListVO) {
		this.settlementListVO = settlementListVO;
	}

	public List<SettlementListDetailsVO> getSettlementListDetailsVO() {
		return settlementListDetailsVO;
	}

	public void setSettlementListDetailsVO(List<SettlementListDetailsVO> settlementListDetailsVO) {
		this.settlementListDetailsVO = settlementListDetailsVO;
	}

	public List<SettlementSummaryVO> getSettlementSummaryList() {
		return settlementSummaryList;
	}

	public void setSettlementSummaryList(List<SettlementSummaryVO> settlementSummaryList) {
		this.settlementSummaryList = settlementSummaryList;
	}    
    
}
