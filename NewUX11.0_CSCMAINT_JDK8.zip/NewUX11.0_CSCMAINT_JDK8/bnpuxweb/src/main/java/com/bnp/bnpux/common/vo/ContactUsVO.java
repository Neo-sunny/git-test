/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   23-Feb-2017 by AnubhaJ
 * 
 * Purpose:      Contact Us pop Up object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 23-Feb-2017				AnubhaJ												Created FO 10.0 S015,S016,S017
************************************************************************************************************************************************************/

package com.bnp.bnpux.common.vo;

import java.io.Serializable;

public class ContactUsVO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String userId;
	
	private String name;
	private String mobile;
	private String email;
	private String location;
	private String company;
	private String subject;
	private String questions;
	private String emailRequired;
	private String captchaText;
	private String captchaTextValue;
	private String errorMsg;
	
	
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getQuestions() {
		return questions;
	}
	public void setQuestions(String questions) {
		this.questions = questions;
	}
	public String getEmailRequired() {
		return emailRequired;
	}
	public void setEmailRequired(String emailRequired) {
		this.emailRequired = emailRequired;
	}
	public String getCaptchaTextValue() {
		return captchaTextValue;
	}
	public void setCaptchaTextValue(String captchaTextValue) {
		//System.out.println("inside setcaptcha"+ captchaTextValue);
		this.captchaTextValue = captchaTextValue;
	}
	public String getCaptchaText() {
		return captchaText;
	}
	public void setCaptchaText(String captchaText) {
		//System.out.println("inside setcaptchatext"+ captchaText);
		this.captchaText = captchaText;
	}
	
}
