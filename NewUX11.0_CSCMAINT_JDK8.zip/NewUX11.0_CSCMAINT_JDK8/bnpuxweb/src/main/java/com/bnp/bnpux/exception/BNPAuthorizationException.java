/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   06 Feb 2017
 * 
 * Purpose:      BNP Runtime exception
 * 
 * Change History: 
 * Date                             Author                                      Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 06 Feb 2017                      belangov                                    Initial Version 
 *****************************************************************************************************************************************************************/
package com.bnp.bnpux.exception;

/**
 * User defined Exception class. This is base exception which will be extended by all User defined Exceptions. 
 * This will be thrown when error occurs while doing crucial operation , Mainly to handle runtime exceptions.
 */
public class BNPAuthorizationException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String message;

	public BNPAuthorizationException(String message) {
		super();
		this.message = message;
	}

	public BNPAuthorizationException() {
		super();
	}

	public BNPAuthorizationException(String message, Throwable cause) {
		super(message, cause);
	}

	public BNPAuthorizationException(Throwable cause) {
		super(cause);
	}
	
	@Override
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
