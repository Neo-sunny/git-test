/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   16-NOV-2016
 * 
 * Purpose:      Request Identity Validation
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.util;

import javax.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class RequestIdentityValidator {
	
	private static final Logger log = LoggerFactory.getLogger(RequestIdentityValidator.class);
	
	public boolean validate(String voUserId, HttpSession session){
		boolean validateFlag = false;
		String sessionUserId = (String) session.getAttribute("USER_ID");
		log.debug("voUserId : "+voUserId+" session UserID : "+sessionUserId);
		if(sessionUserId != null && sessionUserId != "" && voUserId != null && voUserId != ""){
			if(sessionUserId.equals(voUserId)){
				validateFlag = true;
			}
		}
		return validateFlag;
	}
}
