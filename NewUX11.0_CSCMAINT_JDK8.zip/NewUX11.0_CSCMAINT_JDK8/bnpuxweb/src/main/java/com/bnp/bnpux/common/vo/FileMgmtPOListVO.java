/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   28 Mar 2017	
 * 
 * Purpose:       File Management PO Value Object
 * 
 * Change History: 
 * Date                       Author                                    Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 28 Mar 2017			      belangov					               Initial Version 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;
import java.util.Date;

public class FileMgmtPOListVO {
	
	private String recordInd;
	
	private String refId;
	
	private String fileId;
	
	private String buyerOrgId;
	
	private String supplierOrgId;
	
	private String refNo;
	
	private String refNoUnique;
	
	private Date dueDate; 
	
	private String ccyCode;
	
	private BigDecimal amount; 
	
	private String status;
	
	private BigDecimal balanceAmount;
	
	private BigDecimal updatedAmount;
	
	private String paymentId; 
	
	private BigDecimal decimals;
	
	private String creditNoteType;
	
	private String attachmentFlag;
	
	private String rowNo;
	
	private String instrumentType;
	
	private String instrumentGroup;
	
	private String recordCount;
	
	private String poLinkEnableFlag;
	
	private String statusValue;
	
	private String statusKey;
	
	public String getPoLinkEnableFlag() {
		return poLinkEnableFlag;
	}

	public void setPoLinkEnableFlag(String poLinkEnableFlag) {
		this.poLinkEnableFlag = poLinkEnableFlag;
	}

	public String getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(String recordCount) {
		this.recordCount = recordCount;
	}

	public String getRecordInd() {
		return recordInd;
	}

	public void setRecordInd(String recordInd) {
		this.recordInd = recordInd;
	}

	public String getRefId() {
		return refId;
	}

	public void setRefId(String refId) {
		this.refId = refId;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getBuyerOrgId() {
		return buyerOrgId;
	}

	public void setBuyerOrgId(String buyerOrgId) {
		this.buyerOrgId = buyerOrgId;
	}

	public String getSupplierOrgId() {
		return supplierOrgId;
	}

	public void setSupplierOrgId(String supplierOrgId) {
		this.supplierOrgId = supplierOrgId;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public String getRefNoUnique() {
		return refNoUnique;
	}

	public void setRefNoUnique(String refNoUnique) {
		this.refNoUnique = refNoUnique;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public String getCcyCode() {
		return ccyCode;
	}

	public void setCcyCode(String ccyCode) {
		this.ccyCode = ccyCode;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public BigDecimal getBalanceAmount() {
		return balanceAmount;
	}

	public void setBalanceAmount(BigDecimal balanceAmount) {
		this.balanceAmount = balanceAmount;
	}

	public BigDecimal getUpdatedAmount() {
		return updatedAmount;
	}

	public void setUpdatedAmount(BigDecimal updatedAmount) {
		this.updatedAmount = updatedAmount;
	}

	public String getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	public BigDecimal getDecimals() {
		return decimals;
	}

	public void setDecimals(BigDecimal decimals) {
		this.decimals = decimals;
	}

	public String getCreditNoteType() {
		return creditNoteType;
	}

	public void setCreditNoteType(String creditNoteType) {
		this.creditNoteType = creditNoteType;
	}

	public String getAttachmentFlag() {
		return attachmentFlag;
	}

	public void setAttachmentFlag(String attachmentFlag) {
		this.attachmentFlag = attachmentFlag;
	}

	public String getRowNo() {
		return rowNo;
	}

	public void setRowNo(String rowNo) {
		this.rowNo = rowNo;
	}

	public String getInstrumentType() {
		return instrumentType;
	}

	public void setInstrumentType(String instrumentType) {
		this.instrumentType = instrumentType;
	}

	public String getInstrumentGroup() {
		return instrumentGroup;
	}

	public void setInstrumentGroup(String instrumentGroup) {
		this.instrumentGroup = instrumentGroup;
	}

	/**
	 * @return the statusValue
	 */
	public String getStatusValue() {
		return statusValue;
	}

	/**
	 * @param statusValue the statusValue to set
	 */
	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}

	/**
	 * @return the statusKey
	 */
	public String getStatusKey() {
		return statusKey;
	}

	/**
	 * @param statusKey the statusKey to set
	 */
	public void setStatusKey(String statusKey) {
		this.statusKey = statusKey;
	}
	
	/**
	 * Getter methods introduced to send the amounts as
	 * String to avoid amount > 16 digits getting truncated
	 * Added as part of defect Fix CSC-7835
	 */
	
	public String getAmountStr() {
		return (amount!=null)?amount.toPlainString():"";
	}
	
	public String getUpdatedAmountStr() {
		return (updatedAmount!=null)?updatedAmount.toPlainString():"";
	}
	
	public String getBalanceAmountStr() {
		return (balanceAmount!=null)?balanceAmount.toPlainString():"";
	}
}
