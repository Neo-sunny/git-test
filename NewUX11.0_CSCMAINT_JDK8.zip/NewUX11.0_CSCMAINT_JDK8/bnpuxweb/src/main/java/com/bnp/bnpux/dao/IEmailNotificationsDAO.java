package com.bnp.bnpux.dao;

import java.util.List;

import com.bnp.bnpux.common.vo.EmailNotificationsVO;
import com.bnp.bnpux.vo.requestVO.EmailNotificationsRequestVO;
import com.bnp.bnpux.vo.responseVO.EmailNotificationsResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface IEmailNotificationsDAO {

	EmailNotificationsResponseVO getNotificationsList(EmailNotificationsRequestVO noticationsVO);
	
	EmailNotificationsResponseVO getEmailInqReportList(EmailNotificationsRequestVO emailInqRptVO);
	
	EmailNotificationsVO getEmailInqReportDetails(EmailNotificationsVO notificationVo);
	
	List<EmailNotificationsVO> getAttachmentData(EmailNotificationsVO emailNotificationsVO);

}
