/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     InProcess Amount Details Request Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.requestVO;

public class InProcessAmtDetailsRequestVO {


	private String paymntRefNo;
	
	private String paymntRefNoUnique;
    private String settLeadingorgId;
    private String inProcessFlg;
    private String discType;
    
	public String getPaymntRefNo() {
		return paymntRefNo;
	}
	public void setPaymntRefNo(String paymntRefNo) {
		this.paymntRefNo = paymntRefNo;
	}
	public String getPaymntRefNoUnique() {
		return paymntRefNoUnique;
	}
	public void setPaymntRefNoUnique(String paymntRefNoUnique) {
		this.paymntRefNoUnique = paymntRefNoUnique;
	}
	public String getSettLeadingorgId() {
		return settLeadingorgId;
	}
	public void setSettLeadingorgId(String settLeadingorgId) {
		this.settLeadingorgId = settLeadingorgId;
	}
	public String getInProcessFlg() {
		return inProcessFlg;
	}
	public void setInProcessFlg(String inProcessFlg) {
		this.inProcessFlg = inProcessFlg;
	}
	public String getDiscType() {
		return discType;
	}
	public void setDiscType(String discType) {
		this.discType = discType;
	}
	
	
	
}

