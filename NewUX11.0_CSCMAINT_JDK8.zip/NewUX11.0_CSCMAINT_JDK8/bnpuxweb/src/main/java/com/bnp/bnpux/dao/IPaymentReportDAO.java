package com.bnp.bnpux.dao;

import java.util.List;

import com.bnp.bnpux.common.vo.PaymentReportDetailsVO;
import com.bnp.bnpux.common.vo.PaymentReportVO;
import com.bnp.bnpux.vo.requestVO.PaymentReportRequestVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;

public interface IPaymentReportDAO {
	
	/**
	 * This method is for getting Payment Report List
	 * 
	 * @param PaymentReportRequestVO
	 * @return PaymentReportVO List
	 */
	List<PaymentReportVO> getPaymentReport(PaymentReportRequestVO paymentReportRequestVO);
	
	/**
	 * This method is for getting Payment Report List Details
	 * 
	 * @param PaymentReportRequestVO
	 * @return PaymentReportDetailsVO List
	 */
	List<PaymentReportDetailsVO> getPaymentReportDetails(PaymentReportRequestVO paymentReportRequestVO);
	
	/**
	 * This method is for getting Chart Axis
	 * 
	 * @param PaymentReportRequestVO
	 * @return ReportChartResponseVO List
	 */
	List<ReportChartResponseVO> getChartAxis(PaymentReportRequestVO paymentReportRequestVO);
	
	
}
