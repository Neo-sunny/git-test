/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   29 Mar 2017	
 * 
 * Purpose:       Buyer Acceptance screen
 * 
 * Change History: 
 * Date                       Author                                    Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 29 Mar 2017			      kmanimar					                Initial Version - FO 10.0 - S2098
 * 08 Apr 2017                srreshmi                                  FO 10.0 - S2066-attachment popup
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.constants.BuyerAcceptanceConstants;
import com.bnp.bnpux.service.IAuditService;
import com.bnp.bnpux.service.IBuyerAcceptanceNewUXService;
import com.bnp.bnpux.util.CommonUtil;
import com.bnp.bnpux.util.RequestIdentityValidator;
import com.bnp.bnpux.vo.errorMessageVO.ErrorMessageVO;
import com.bnp.bnpux.vo.requestVO.BuyerAcceptanceRequestVO;
import com.bnp.bnpux.vo.responseVO.BuyerAcceptanceResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@RestController
@RequestMapping("/buyerAcceptanceCtrl")
public class BuyerAcceptanceController {

	/**
	 * Logger for BuyerAcceptanceController
	 */
	public static final Logger log = LoggerFactory.getLogger(BuyerAcceptanceController.class);

	/**
	 * Autowired Interface IBuyerAcceptanceService
	 */
	@Autowired
	private IBuyerAcceptanceNewUXService buyerAcceptanceService;

	@Autowired
	RequestIdentityValidator validateRequest;

	@Autowired 
	private CommonUtil commonUtil;

	@Autowired
	private IAuditService auditService;
	
	/**
	 * This method is for getting the Buyer Acceptance Details
	 * 
	 * @param BuyerAcceptanceRequestVO
	 * @return
	 */
	@RequestMapping(value = "getBuyerAcceptanceDetails.rest", method = RequestMethod.POST)
	public BuyerAcceptanceResponseVO getBuyerAcceptanceDetails(@RequestBody BuyerAcceptanceRequestVO buyerAcceptanceRequestVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		BuyerAcceptanceResponseVO buyerAcceptanceResponseVO = new BuyerAcceptanceResponseVO();
		try {
			boolean requestValidatedFlag = validateRequest.validate(buyerAcceptanceRequestVO.getUserId(), httpServletRequest.getSession());
			if (requestValidatedFlag) {
				buyerAcceptanceResponseVO = buyerAcceptanceService.getBuyerAcceptanceDetails(buyerAcceptanceRequestVO);
			} else {
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (BNPApplicationException exception) {
			buyerAcceptanceResponseVO.setErrorMsg(exception.getMessage());
			log.error(exception.getMessage(), exception);
		}
		return buyerAcceptanceResponseVO;
	}
	
	/**
	 * This method is for getting the Buyer Acceptance Details count for Adv filter
	 * 
	 * @param BuyerAcceptanceRequestVO
	 * @return
	 */
	@RequestMapping(value = "getAdvancedFilterIndicatorCount.rest", method = RequestMethod.POST)
	public BuyerAcceptanceResponseVO getAdvancedFilterIndicatorCount(@RequestBody BuyerAcceptanceRequestVO buyerAcceptanceRequestVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		BuyerAcceptanceResponseVO buyerAcceptanceResponseVO = new BuyerAcceptanceResponseVO();
		try {
			boolean requestValidatedFlag = validateRequest.validate(buyerAcceptanceRequestVO.getUserId(), httpServletRequest.getSession());
			if (requestValidatedFlag) {
				buyerAcceptanceResponseVO = buyerAcceptanceService.getAdvancedFilterCount(buyerAcceptanceRequestVO);
			} else {
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (BNPApplicationException exception) {
			buyerAcceptanceResponseVO.setErrorMsg(exception.getMessage());
			log.error(exception.getMessage(), exception);
		}
		return buyerAcceptanceResponseVO;
	}
	
	
@RequestMapping(value = "getAttachmentList.rest", method = RequestMethod.POST)
public BuyerAcceptanceResponseVO getAttachmentList(@RequestBody BuyerAcceptanceRequestVO buyerAcceptanceRequestVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
	BuyerAcceptanceResponseVO buyerAcceptanceResponseVO = new BuyerAcceptanceResponseVO();
	try {
		boolean requestValidatedFlag = validateRequest.validate(buyerAcceptanceRequestVO.getUserId(), httpServletRequest.getSession());
		if (requestValidatedFlag) {
			buyerAcceptanceResponseVO = buyerAcceptanceService.getAttachmentList(buyerAcceptanceRequestVO);
			if(!BuyerAcceptanceConstants.BA_ATTACHEMENT_DTL.equals(buyerAcceptanceRequestVO.getGetWhat())){
				httpServletResponse.setHeader("Content-Disposition","attachment;filename=\"" + BuyerAcceptanceConstants.SCF_FILE_NAME + "\"");				
				try {
					httpServletResponse.getOutputStream().write(buyerAcceptanceResponseVO.getData());
					httpServletResponse.getOutputStream().close();
				} catch (IOException e) {
					log.error(e.getMessage(),e);
				}
			}
		} else {
			log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
			httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		}
	} catch (BNPApplicationException exception) {
		buyerAcceptanceResponseVO.setErrorMsg(exception.getMessage());
		log.error(exception.getMessage(), exception);
	}
	return buyerAcceptanceResponseVO;
}


	/**
	 * This method triggers the Undo action for the Buyer Acceptance 
	 * 
	 * @param ReleaseFileMgmtRequestVO
	 * @return ReleaseFileMgmtResponseVO
	 * @throws BNPApplicationException 
	 */
	@RequestMapping(value = "doBuyerAcceptanceAction.rest", method = RequestMethod.POST)
	public BuyerAcceptanceResponseVO doBuyerAcceptanceAction(@RequestBody BuyerAcceptanceRequestVO actionReqVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		BuyerAcceptanceResponseVO buyerAcceptanceResVO = null;
		HttpSession session = httpServletRequest.getSession();
		UserInfoVO user = (UserInfoVO) session.getAttribute("userInfo");
		boolean requestValidatedFlag = validateRequest.validate(user.getUserId(), httpServletRequest.getSession());
		if (requestValidatedFlag) {
			try {
				buyerAcceptanceResVO = buyerAcceptanceService.doBuyerAcceptanceAction(actionReqVO , user);			
				auditService.insertAuditLog(commonUtil.constructAuditVo(user , BuyerAcceptanceConstants.VIEW_TYPE_BUYERACCEPT+actionReqVO.getAction()));
			
			} catch (BNPApplicationException exception) {
				buyerAcceptanceResVO = new  BuyerAcceptanceResponseVO();
				buyerAcceptanceResVO.setErrMessageVO(new ArrayList<ErrorMessageVO>());
				commonUtil.addBAResponseVO(null, exception.getErrorMessage(), true, buyerAcceptanceResVO);			
				log.error(exception.getMessage(), exception);
		
			}
		}else {
			log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
			httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		}
		
		log.debug("n Buyer Acceptance Controller - exits");
		return buyerAcceptanceResVO;
	}
}