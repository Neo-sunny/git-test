/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   23-Feb-2017 by AnubhaJ
 * 
 * Purpose:      Contact Us pop Up object
*
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 23-Feb-2017				AnubhaJ												Created FO 10.0 S015,S016,S017
************************************************************************************************************************************************************/

package com.bnp.bnpux.constants;


public interface ContactUsConstants {
	
	
		public static final String LOCATION_DR_DW = "getlocationListList.rest";
		public static final String EXCEPTION_UNABLE_TO_PROCESS = "Unable to Get Location Drop down - Database Exception";
		public static final String GET_CAPTCHA = "getCaptcha.rest";
		public static final String SUBMIT_CONTACTUS ="submitContactUs.rest";
}
