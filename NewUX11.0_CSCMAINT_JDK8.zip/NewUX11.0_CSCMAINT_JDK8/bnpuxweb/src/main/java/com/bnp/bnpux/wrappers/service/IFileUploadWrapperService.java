/******************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   31 Mar 2011
 * 
 * Purpose:      Financial Inquiry Functionality
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 

* 1 MAY 2017            	Bhuvaneswari                                       File Upload 
*************************************************************************************************************************************************************/
package com.bnp.bnpux.wrappers.service;

import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

import com.bnp.bnpux.vo.requestVO.FileUploadRequestVO;
import com.bnp.scm.services.filemgmt.vo.FileVO;

/**
 * The Class FileUploadBean.
 */
public interface IFileUploadWrapperService {

	/**
	 * @param fileUpldVO
	 * @param file
	 * @param sessionId 
	 * @return 
	 * @throws IOException 
	 */
	public FileVO onUpload(FileUploadRequestVO fileUpldVO, MultipartFile file, String sessionId) throws IOException;
	}
