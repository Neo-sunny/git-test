/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     Image Util
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 
 *****************************************************************************************************************************************************************/
package com.bnp.bnpux.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ImageUtil {

	private static  byte []  orgLogo;
	
	private static final Logger log = LoggerFactory.getLogger(ImageUtil.class);

	private ImageUtil()
	{
		super();
	}
	
	/**
	 * @param imagePath
	 * @return byte[]
	 * @Description get Organization Logo
	 */
	public static byte[] getOrgLogo(String imagePath) {
		if(orgLogo == null)
		{
			try {
				orgLogo = extractBytes(imagePath);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				log.error(e.getMessage(),e);
			}
		}
		return orgLogo;
	}
	
	/**
	 * @param imgPath
	 * @return byte[]
	 * @throws IOException
	 * @Description  Fetch Byte Array of Image from Specified Path 
	 */
	private static byte[] extractBytes (String imgPath) throws IOException {
		 // open image
		
		File file = null;
		FileInputStream imageInFile = null;
		ByteArrayOutputStream bos = null;
		byte[] imageData;
		try{
		file = new File(imgPath);
		imageInFile = new FileInputStream(file);
		bos = new ByteArrayOutputStream();
		byte[] buf = new byte[1024];
		for (int readNum; (readNum = imageInFile.read(buf)) != -1;) {
           //Writes to this byte array output stream
           bos.write(buf, 0, readNum);            
        }
		
		imageData = bos.toByteArray();
		}finally{
			try{
				if(bos!=null)
					bos.close();
			}catch (IOException IOEx){
				log.error("Exception in closing the stream"+IOEx);
			}
			try{
				if(imageInFile!=null)
					imageInFile.close();
			}catch (IOException IOEx1){
				log.error("Exception in closing the stream"+IOEx1);
			}
			
		}
		return imageData;
		
		}
}
