/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14 Mar 2017
 * 
 * Purpose:      File Management Constants
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 14 Mar 2017			             skbhaska					                Initial Version - FO 10.0 - S2005, S2007
 * 29 Mar 2017                       srreshmi                                    S2022,S2024
************************************************************************************************************************************************************/
package com.bnp.bnpux.constants;

public interface FileMgmtConstants {

	public static final String FILE_MANAGEMENT_ERROR_DETAILS = "Database Error Flag : "; 
	
	public static final String FILE_MANAGEMENT_GROUPBY_UD = "UD"; 

	public static final String VIEW_TYPE_FILEMGMT = "FILEMGMT"; 

	public static final String VIEW_TYPE_UPLOAD_DATE = "UPLOAD_DATE"; 
	
	public static final String VIEW_TYPE_FILEMGMT_LIST = "FILEMGMT_LIST"; 
	
	public static final String EXCEPTION_UNABLE_TO_PROCESS = "Unable to Get File Management Details - Database Exception"; 
		
	public static final String ADV_FLTR_GET = "GET";
	
	public static final String ADV_FLTR_DELETE = "DELETE";
	
	public static final String DATE_FORMAT_DD_MMM_YYY = "dd-MMM-yyyy";

	public static final String VIEW_TYPE_FILEMGMT_SUBGRID_DATA = "FILEMGMT_LIST_PO";

	public static final String VIEW_TYPE_FILEMGMT_LIST_INVOICE = "FILEMGMT_LIST_INVOICE";
	
	public static final String VIEW_TYPE_FILEMGMT_LIST_PS = "FILEMGMT_LIST_PS";
	
	public static final String VIEW_TYPE_FILEMGMT_LIST_DA = "FILEMGMT_LIST_DA";
	
	public static final String DISCOUNT_DOC_DOCTYPECODE_1 = "1";
	
	public static final String DISCOUNT_DOC_ATTACH_DOCTYPECODE_2 = "2";
	
	public static final String INVOICE_SETTLEMENT_DOCTYPECODE_3 = "3";
	
	public static final String ROLLOVER_SETTLE_DOCTYPECODE_4 = "4";
	
	public static final String PREAPPROVED_SUPP_DOCTYPECODE_5 = "5";

	public static final String FILE_RELEASE_REQUEST = "FILE_RELEASE";
	
	public static final String FILE_AUTHORIZE_REQUEST = "FILE_AUTHORIZE";
	
	public static final String FILE_REJECT_REQUEST = "FILE_REJECT";

	public static final String FILE_UNDO_REQUEST = "FILE_UNDO";
	
	public static final String FILE_MANAGMENT_DOWNLOAD = "DWLD";
	
	public static final String FILE_MANAGMENT_ATTACHEMENT_DTL = "DTL";
	
	public static final String FILE_MANAGMENT_DOWNLOAD_ALL = "ALLDWLD";
	
	public static final String SCF_FILE_NAME ="ScfAttachment.zip";
	
	public static final String EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL = "Unable to Get Attachment Details";
	
	public static final String EXCEPTION_UNABLE_TO_GET_UPDATED_FILE_UPLOAD_STATUS = "Unable to Get Updated File Upload status Details";
	
	
}
