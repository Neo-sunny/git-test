/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Transaction List Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class TransactionListVO implements Serializable{ // Modified for Sonar Fix to make the VO Serializable
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String buyerOrgId;
	
	private String buyerOrgName;
	
	private String sellerOrgId;
	
	private String sellerOrgName;
	
	private String currencyCode;
	
	private BigDecimal supplierBalAmt;
	
	private String buyerRefNo;
	
	private String discRefNo;
	
	private String batchRefNo;
	
	private String discStatus;
	
	private Date paymentDueDate;
	
	private BigDecimal paymentAmount;
	
	private BigDecimal indChargeAmount;
	
	private BigDecimal indDiscAmount;
	
	private BigDecimal indNetAmount;
	
	private BigDecimal confirmedNetAmount;
	
	private BigDecimal sumPaymentAmount;
	
	private BigDecimal sumIndicatorChargeAmount;
	
	private BigDecimal sumIndicatorDiscAmount;
	
	private BigDecimal sumIndicatorNetAmount;
	
	private BigDecimal sumConfirmedNetAmount;
	
	private String recordCount;
	
	private String rowNo;
	
	private boolean callOutIndPymtAmtFlag;
	
	private boolean callOutIndChrgeAmtFlag;
	
	private boolean callOutIndicativeAmtFlag;
	
	private String checkboxIndFlag;
	
	private String userDiscFlag;
	
	private boolean callOutNetIndAmtFlag;
	
	private String buyerRefNoInd;
	
	private String recInd;
	
	private int decimalPoint;
	
	private String makerId;
	
	private String mbModel;
	
	private String indicativeDiscRate;
	
	private String discTenure;
	
	private String rateChargeType;
	
	private BigDecimal calcIndicativeDiscAmt;
	
	private BigDecimal indAppMinDiscFeeAmt;
	
	private boolean callOutConfimedAmtFlag;

	private String recFlag;
	
	private BigDecimal financingAmount;
	
	private BigDecimal	confirmedInterestAmt;
	
	private BigDecimal appliedMinDisFee;
	
	private BigDecimal appliedMinDisFeeSum;
	
	private BigDecimal confirmedChargeAmount;
	
	private String confirmedDiscTenure;
	
	private String confirmedIntRate;
	
	private BigDecimal calcConfIntAmt;
	
	private boolean undoCallOutIndicator;
	
	private transient List<TransactionChargeAmtVO> transChargeAmntVOList;
	
	private BigDecimal confirmedNetAmountCallout;

	private Date maturityDate;
	
	private String pymtId;
	
	private String rateChargeTypeVal;
	
	private String isSupplierPercent;	    
	
	private String statusKeyValue;
	
	private String statusDisplayValue;
	
	public String getStatusKeyValue() {
		return statusKeyValue;
	}

	public void setStatusKeyValue(String statusKeyValue) {
		this.statusKeyValue = statusKeyValue;
	}

	public String getStatusDisplayValue() {
		return statusDisplayValue;
	}

	public void setStatusDisplayValue(String statusDisplayValue) {
		this.statusDisplayValue = statusDisplayValue;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getMakerId() {
		return makerId;
	}

	public void setMakerId(String makerId) {
		this.makerId = makerId;
	}

	public String getBuyerOrgId() {
		return buyerOrgId;
	}

	public void setBuyerOrgId(String buyerOrgId) {
		this.buyerOrgId = buyerOrgId;
	}

	public String getBuyerOrgName() {
		return buyerOrgName;
	}

	public void setBuyerOrgName(String buyerOrgName) {
		this.buyerOrgName = buyerOrgName;
	}

	public String getSellerOrgId() {
		return sellerOrgId;
	}

	public void setSellerOrgId(String sellerOrgId) {
		this.sellerOrgId = sellerOrgId;
	}

	public String getSellerOrgName() {
		return sellerOrgName;
	}

	public void setSellerOrgName(String sellerOrgName) {
		this.sellerOrgName = sellerOrgName;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public BigDecimal getSupplierBalAmt() {
		return supplierBalAmt;
	}

	public void setSupplierBalAmt(BigDecimal supplierBalAmt) {
		this.supplierBalAmt = supplierBalAmt;
	}

	public String getBuyerRefNo() {
		return buyerRefNo;
	}

	public void setBuyerRefNo(String buyerRefNo) {
		this.buyerRefNo = buyerRefNo;
	}

	public String getDiscRefNo() {
		return discRefNo;
	}

	public void setDiscRefNo(String discRefNo) {
		this.discRefNo = discRefNo;
	}

	public String getBatchRefNo() {
		return batchRefNo;
	}

	public void setBatchRefNo(String batchRefNo) {
		this.batchRefNo = batchRefNo;
	}

	public String getDiscStatus() {
		return discStatus;
	}

	public void setDiscStatus(String discStatus) {
		this.discStatus = discStatus;
	}

	public Date getPaymentDueDate() {
		return paymentDueDate;
	}

	public void setPaymentDueDate(Date paymentDueDate) {
		this.paymentDueDate = paymentDueDate;
	}

	public BigDecimal getPaymentAmount() {
		return paymentAmount;
	}
	
	public void setPaymentAmount(BigDecimal paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public BigDecimal getIndChargeAmount() {
		return indChargeAmount;
	}

	public void setIndChargeAmount(BigDecimal indChargeAmount) {
		this.indChargeAmount = indChargeAmount;
	}

	public BigDecimal getIndDiscAmount() {
		return indDiscAmount;
	}

	public void setIndDiscAmount(BigDecimal indDiscAmount) {
		this.indDiscAmount = indDiscAmount;
	}

	public BigDecimal getIndNetAmount() {
		return indNetAmount;
	}

	public void setIndNetAmount(BigDecimal indNetAmount) {
		this.indNetAmount = indNetAmount;
	}

	public BigDecimal getConfirmedNetAmount() {
		return confirmedNetAmount;
	}

	public void setConfirmedNetAmount(BigDecimal confirmedNetAmount) {
		this.confirmedNetAmount = confirmedNetAmount;
	}

	public BigDecimal getSumPaymentAmount() {
		return sumPaymentAmount;
	}

	public void setSumPaymentAmount(BigDecimal sumPaymentAmount) {
		this.sumPaymentAmount = sumPaymentAmount;
	}

	public BigDecimal getSumIndicatorChargeAmount() {
		return sumIndicatorChargeAmount;
	}

	public void setSumIndicatorChargeAmount(BigDecimal sumIndicatorChargeAmount) {
		this.sumIndicatorChargeAmount = sumIndicatorChargeAmount;
	}

	public BigDecimal getSumIndicatorDiscAmount() {
		return sumIndicatorDiscAmount;
	}

	public void setSumIndicatorDiscAmount(BigDecimal sumIndicatorDiscAmount) {
		this.sumIndicatorDiscAmount = sumIndicatorDiscAmount;
	}

	public BigDecimal getSumIndicatorNetAmount() {
		return sumIndicatorNetAmount;
	}

	public void setSumIndicatorNetAmount(BigDecimal sumIndicatorNetAmount) {
		this.sumIndicatorNetAmount = sumIndicatorNetAmount;
	}

	public BigDecimal getSumConfirmedNetAmount() {
		return sumConfirmedNetAmount;
	}

	public void setSumConfirmedNetAmount(BigDecimal sumConfirmedNetAmount) {
		this.sumConfirmedNetAmount = sumConfirmedNetAmount;
	}
	
	public String getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(String recordCount) {
		this.recordCount = recordCount;
	}

	public String getRowNo() {
		return rowNo;
	}

	public void setRowNo(String rowNo) {
		this.rowNo = rowNo;
	}

	public boolean isCallOutIndPymtAmtFlag() {
		return callOutIndPymtAmtFlag;
	}

	public void setCallOutIndPymtAmtFlag(boolean callOutIndPymtAmtFlag) {
		this.callOutIndPymtAmtFlag = callOutIndPymtAmtFlag;
	}

	public boolean isCallOutIndChrgeAmtFlag() {
		return callOutIndChrgeAmtFlag;
	}

	public void setCallOutIndChrgeAmtFlag(boolean callOutIndChrgeAmtFlag) {
		this.callOutIndChrgeAmtFlag = callOutIndChrgeAmtFlag;
	}

	public boolean isCallOutIndicativeAmtFlag() {
		return callOutIndicativeAmtFlag;
	}

	public void setCallOutIndicativeAmtFlag(boolean callOutIndicativeAmtFlag) {
		this.callOutIndicativeAmtFlag = callOutIndicativeAmtFlag;
	}

	public String getCheckboxIndFlag() {
		return checkboxIndFlag;
	}

	public void setCheckboxIndFlag(String checkboxIndFlag) {
		this.checkboxIndFlag = checkboxIndFlag;
	}

	public String getUserDiscFlag() {
		return userDiscFlag;
	}

	public void setUserDiscFlag(String userDiscFlag) {
		this.userDiscFlag = userDiscFlag;
	}

	public boolean isCallOutNetIndAmtFlag() {
		return callOutNetIndAmtFlag;
	}

	public void setCallOutNetIndAmtFlag(boolean callOutNetIndAmtFlag) {
		this.callOutNetIndAmtFlag = callOutNetIndAmtFlag;
	}

	public String getBuyerRefNoInd() {
		return buyerRefNoInd;
	}

	public void setBuyerRefNoInd(String buyerRefNoInd) {
		this.buyerRefNoInd = buyerRefNoInd;
	}

	public String getRecInd() {
		return recInd;
	}

	public void setRecInd(String recInd) {
		this.recInd = recInd;
	}

	public int getDecimalPoint() {
		return decimalPoint;
	}

	public void setDecimalPoint(int decimalPoint) {
		this.decimalPoint = decimalPoint;
	}

	public String getMbModel() {
		return mbModel;
	}

	public void setMbModel(String mbModel) {
		this.mbModel = mbModel;
	}

	public String getIndicativeDiscRate() {
		return indicativeDiscRate;
	}

	public void setIndicativeDiscRate(String indicativeDiscRate) {
		this.indicativeDiscRate = indicativeDiscRate;
	}

	public String getDiscTenure() {
		return discTenure;
	}

	public void setDiscTenure(String discTenure) {
		this.discTenure = discTenure;
	}

	public String getRateChargeType() {
		return rateChargeType;
	}

	public void setRateChargeType(String rateChargeType) {
		this.rateChargeType = rateChargeType;
	}

	public String getRecFlag() {
		return recFlag;
	}

	public void setRecFlag(String recFlag) {
		this.recFlag = recFlag;
	}

	public BigDecimal getCalcIndicativeDiscAmt() {
		return calcIndicativeDiscAmt;
	}

	public void setCalcIndicativeDiscAmt(BigDecimal calcIndicativeDiscAmt) {
		this.calcIndicativeDiscAmt = calcIndicativeDiscAmt;
	}

	public BigDecimal getIndAppMinDiscFeeAmt() {
		return indAppMinDiscFeeAmt;
	}

	public void setIndAppMinDiscFeeAmt(BigDecimal indAppMinDiscFeeAmt) {
		this.indAppMinDiscFeeAmt = indAppMinDiscFeeAmt;
	}

	public boolean isCallOutConfimedAmtFlag() {
		return callOutConfimedAmtFlag;
	}

	public void setCallOutConfimedAmtFlag(boolean callOutConfimedAmtFlag) {
		this.callOutConfimedAmtFlag = callOutConfimedAmtFlag;
	}

	public BigDecimal getFinancingAmount() {
		return financingAmount;
	}

	public void setFinancingAmount(BigDecimal financingAmount) {
		this.financingAmount = financingAmount;
	}

	public BigDecimal getConfirmedInterestAmt() {
		return confirmedInterestAmt;
	}

	public void setConfirmedInterestAmt(BigDecimal confirmedInterestAmt) {
		this.confirmedInterestAmt = confirmedInterestAmt;
	}

	public BigDecimal getAppliedMinDisFee() {
		return appliedMinDisFee;
	}

	public void setAppliedMinDisFee(BigDecimal appliedMinDisFee) {
		this.appliedMinDisFee = appliedMinDisFee;
	}

	public BigDecimal getAppliedMinDisFeeSum() {
		return appliedMinDisFeeSum;
	}

	public void setAppliedMinDisFeeSum(BigDecimal appliedMinDisFeeSum) {
		this.appliedMinDisFeeSum = appliedMinDisFeeSum;
	}

	public BigDecimal getConfirmedChargeAmount() {
		return confirmedChargeAmount;
	}

	public void setConfirmedChargeAmount(BigDecimal confirmedChargeAmount) {
		this.confirmedChargeAmount = confirmedChargeAmount;
	}

	public String getConfirmedDiscTenure() {
		return confirmedDiscTenure;
	}

	public void setConfirmedDiscTenure(String confirmedDiscTenure) {
		this.confirmedDiscTenure = confirmedDiscTenure;
	}

	public String getConfirmedIntRate() {
		return confirmedIntRate;
	}

	public BigDecimal getConfirmedNetAmountCallout() {
		return confirmedNetAmountCallout;
	}

	public void setConfirmedNetAmountCallout(BigDecimal confirmedNetAmountCallout) {
		this.confirmedNetAmountCallout = confirmedNetAmountCallout;
	}

	public void setConfirmedIntRate(String confirmedIntRate) {
		this.confirmedIntRate = confirmedIntRate;
	}

	public List<TransactionChargeAmtVO> getTransChargeAmntVOList() {
		return transChargeAmntVOList;
	}

	public void setTransChargeAmntVOList(List<TransactionChargeAmtVO> transChargeAmntVOList) {
		this.transChargeAmntVOList = transChargeAmntVOList;
	}

	public BigDecimal getCalcConfIntAmt() {
		return calcConfIntAmt;
	}

	public void setCalcConfIntAmt(BigDecimal calcConfIntAmt) {
		this.calcConfIntAmt = calcConfIntAmt;
	}
	
	public boolean isUndoCallOutIndicator() {
		return undoCallOutIndicator;
	}

	public void setUndoCallOutIndicator(boolean undoCallOutIndicator) {
		this.undoCallOutIndicator = undoCallOutIndicator;
	}

	public Date getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(Date maturityDate) {
		this.maturityDate = maturityDate;
	}

	public String getPymtId() {
		return pymtId;
	}

	public void setPymtId(String pymtId) {
		this.pymtId = pymtId;
	}

	public String getRateChargeTypeVal() {
		return rateChargeTypeVal;
	}

	public void setRateChargeTypeVal(String rateChargeTypeVal) {
		this.rateChargeTypeVal = rateChargeTypeVal;
	}

	public String getIsSupplierPercent() {
		return isSupplierPercent;
	}

	public void setIsSupplierPercent(String isSupplierPercent) {
		this.isSupplierPercent = isSupplierPercent;
	}
	
	/**
	 * Getter methods introduced to send the amounts as
	 * String to avoid amount > 16 digits getting truncated
	 * Added as part of defect Fix CSC-7835
	 */
	
	public String getPaymentAmountStr() {
		return paymentAmount.toPlainString();
	}
	
	public String getIndChargeAmountStr() {
		return (indChargeAmount!=null)?indChargeAmount.toPlainString():"";
	}

	public String getIndDiscAmountStr() {
		return (indDiscAmount!=null)?indDiscAmount.toPlainString():"";
	}

	public String getIndNetAmountStr() {
		return (indNetAmount!=null)?indNetAmount.toPlainString():"";
	}

	public String getConfirmedNetAmountStr() {
		return (confirmedNetAmount!=null)?confirmedNetAmount.toPlainString():"";
	}

	public String getSumPaymentAmountStr() {
		return (sumPaymentAmount!=null)?sumPaymentAmount.toPlainString():"";
	}

	public String getSumIndicatorChargeAmountStr() {
		return (sumIndicatorChargeAmount!=null)?sumIndicatorChargeAmount.toPlainString():"";
	}

	public String getSumIndicatorDiscAmountStr() {
		return (sumIndicatorDiscAmount!=null)?sumIndicatorDiscAmount.toPlainString():"";
	}

	public String getSumIndicatorNetAmountStr() {
		return (sumIndicatorNetAmount!=null)?sumIndicatorNetAmount.toPlainString():"";
	}

	public String getSumConfirmedNetAmountStr() {
		return (sumConfirmedNetAmount!=null)?sumConfirmedNetAmount.toPlainString():"";
	}

	public String getFinancingAmountStr() {
		return (financingAmount!=null)?financingAmount.toPlainString():"";
	}

	public String getConfirmedChargeAmountStr() {
		return (confirmedChargeAmount!=null)?confirmedChargeAmount.toPlainString():"";
	}

	public String getConfirmedNetAmountCalloutStr() {
		return (confirmedNetAmountCallout!=null)?confirmedNetAmountCallout.toPlainString():"";
	}

	public String getSupplierBalAmtStr() {
		return (supplierBalAmt!=null)?supplierBalAmt.toPlainString():"";
	}

	public String getCalcIndicativeDiscAmtStr() {
		return (calcIndicativeDiscAmt!=null)?calcIndicativeDiscAmt.toPlainString():"";
	}

	public String getIndAppMinDiscFeeAmtStr() {
		return (indAppMinDiscFeeAmt!=null)?indAppMinDiscFeeAmt.toPlainString():"";
	}

	public String getConfirmedInterestAmtStr() {
		return (confirmedInterestAmt!=null)?confirmedInterestAmt.toPlainString():"";
	}

	public String getCalcConfIntAmtStr() {
		return (calcConfIntAmt!=null)?calcConfIntAmt.toPlainString():"";
	}
}
