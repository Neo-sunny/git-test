/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   29 Mar 2017	
 * 
 * Purpose:       Buyer Acceptance screen
 * 
 * Change History: 
 * Date                       Author                                    Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 29 Mar 2017			      kmanimar					                Initial Version - FO 10.0 - S2098
 * 10 Apr 2017                srreshmi                                  FO 10.0-S2066-attachment popup
************************************************************************************************************************************************************/
package com.bnp.bnpux.dao;

import java.util.List;

import com.bnp.bnpux.common.vo.BaAttachmentListVO;
import com.bnp.bnpux.common.vo.BuyerAcceptanceListVO;
import com.bnp.bnpux.common.vo.BuyerAcceptanceSummaryVO;
import com.bnp.bnpux.vo.requestVO.BuyerAcceptanceRequestVO;
import com.bnp.scm.services.invoice.vo.BuyerAcceptanceVO;

public interface IBuyerAcceptanceDAO {

	/**
	 * This method is for getting Buyer Acceptance Summary
	 * 
	 * @param paramMap
	 * @return
	 */
	List<BuyerAcceptanceSummaryVO> getBuyerAcceptanceSummary(BuyerAcceptanceRequestVO buyerAcceptanceRequestVO);
	
	/**
	 * This method is for getting Buyer Acceptance List
	 * 
	 * @param paramMap
	 * @return
	 */
	
	List<BuyerAcceptanceListVO> getBuyerAcceptanceList(BuyerAcceptanceRequestVO buyerAcceptanceRequestVO);
	/**
	 * This method is for getting Attachment List
	 * 
	 * @param paramMap
	 * @return
	 */
	List<BaAttachmentListVO> getAttachmentList(BuyerAcceptanceRequestVO buyerAcceptanceRequestVO);
	
	/**
	 * This method is for getting Buyer Acceptance Summary with advance filter
	 * 
	 * @param paramMap
	 * @return
	 */
	List<BuyerAcceptanceSummaryVO> getBuyerAcceptanceSummaryWithAdvFilter(BuyerAcceptanceRequestVO buyerAcceptanceRequestVO);
	
	/**
	 * This method is for getting Buyer Acceptance Summary with advance filter
	 * 
	 * @param paramMap
	 * @return
	 */
	List<BuyerAcceptanceSummaryVO> getAdvFilterIndicatorCount(BuyerAcceptanceRequestVO buyerAcceptanceRequestVO);
	
	/**
	 * This method is for getting Buyer Acceptance List  with advance filter
	 * 
	 * @param paramMap
	 * @return
	 */
	
	List<BuyerAcceptanceListVO> getBuyerAcceptanceListWithAdvFilter(BuyerAcceptanceRequestVO buyerAcceptanceRequestVO);
	
	/**
	 * @param actionReqVO
	 * @return
	 */
	List<BuyerAcceptanceVO> getBuyerAcceptanceVO(BuyerAcceptanceRequestVO actionReqVO);


	
}
