/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:      Cache Service Implementation
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
************************************************************************************************************************************************************/
package com.bnp.csc.services.common.cache;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bnp.csc.services.common.dao.IUserCacheDAO;
import com.bnp.csc.services.common.vo.BranchVO;

@Service("userCacheService")
public class UserCacheServiceImpl implements IUserCacheService{

	@Autowired
	private IUserCacheDAO userCacheDao;
	
	/**
	 * @param userId
	 * @return List<BranchVO>
	 * @Description Service Method for getting Branch List for Org User
	 * @see com.bnp.csc.services.common.cache.IUserCacheService#getBranchListForOrgUser(java.lang.String)
	 *
	 */
	@Override
	public List<BranchVO> getBranchListForOrgUser(String userId) {
		return userCacheDao.getBranchDetailsForLoginUser(userId);
	}

	/**
	 * @param params
	 * @return Date
	 * @see com.bnp.csc.services.common.cache.IUserCacheService#getHolidayAdjustedDate(java.util.Map)
	 * @Description Service Method for getting Holiday Adjusted Date
	 */
	@Override
	public Date getHolidayAdjustedDate(Map<String, Object> params) {
		// TODO Auto-generated method stub
		return userCacheDao.getHolidayAdjustedDate(params);
	}

	/**
	 * @param params
	 * @see com.bnp.csc.services.common.cache.IUserCacheService#getNextBusinessDay(java.util.Map)
	 * @Description Service Method for getting Next Business Day
	 */
	@Override
	public void getNextBusinessDay(Map<String, Object> params) {
		// TODO Auto-generated method stub
		userCacheDao.getNextBusinessDay(params);
	}

}
