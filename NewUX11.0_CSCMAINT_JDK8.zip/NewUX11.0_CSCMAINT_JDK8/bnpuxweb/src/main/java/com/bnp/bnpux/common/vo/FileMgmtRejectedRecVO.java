package com.bnp.bnpux.common.vo;

public class FileMgmtRejectedRecVO {
	
	private String type;
	private String errorData;
	private String errorMsg;
	private Integer bandRecCount;
	
	
	public Integer getBandRecCount() {
		return bandRecCount;
	}
	public void setBandRecCount(Integer bandRecCount) {
		this.bandRecCount = bandRecCount;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getErrorData() {
		return errorData;
	}
	public void setErrorData(String errorData) {
		this.errorData = errorData;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}	
	
}
