/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   15-JUL-2017
 * 
 * Purpose:      SCF Attach Upload Wrapper Service to connect to Common Service
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 15-JUL-2017				Divyashri Subramaniam						Interface Service as intermediate for Common Services
************************************************************************************************************************************************************/
package com.bnp.bnpux.wrappers.service;

import com.bnp.bnpux.vo.requestVO.DashSettelmentDueRequestVO;
import com.bnp.bnpux.vo.requestVO.LimitUtilReportRequestVO;
import com.bnp.bnpux.vo.requestVO.LimitUtilReportResponseVO;
import com.bnp.bnpux.vo.responseVO.DashSettelmentDueResponseVO;

public interface ILimitUtilReportWrapperService {
	
	public  LimitUtilReportResponseVO getDefaultFilerList(LimitUtilReportRequestVO limitUtilReportRequestVO);
	
	public  LimitUtilReportResponseVO getOrgFilterList(LimitUtilReportRequestVO limitUtilReportRequestVO);
	
	public  LimitUtilReportResponseVO getCcyFilterList(LimitUtilReportRequestVO limitUtilReportRequestVO);
	
	public  LimitUtilReportResponseVO getSearchedData(LimitUtilReportRequestVO limitUtilReportRequestVO);
	
	public  LimitUtilReportResponseVO getSearchedDataOnCcyChange(LimitUtilReportRequestVO limitUtilReportRequestVO);
	
	public  LimitUtilReportResponseVO getLimitDetails(LimitUtilReportRequestVO limitUtilReportRequestVO);
	
	public DashSettelmentDueResponseVO getSettlementSearchDetails(DashSettelmentDueRequestVO dashSettelmentDueRequestVO);
}
