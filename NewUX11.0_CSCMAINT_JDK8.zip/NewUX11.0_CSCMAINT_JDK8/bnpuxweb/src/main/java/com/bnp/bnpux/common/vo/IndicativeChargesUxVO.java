/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   10-FEB-2017
 * 
 * Purpose:      Indicative Charges Ux VO
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 10-FEB-2017				  Sathishkumar B									New VO - S271, S273, S274, S275, S276, S277
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

public class IndicativeChargesUxVO extends AbstractVO{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6108821441751670510L;

	private String chargeCode;
	
	private String chargeDesc;
	
	private String chargeCCY;
	
	private String chargeAmount;
	
	private String chargeCodeIdentifier;
	
	private String chargeAmountToBeDiscounted;
	
	private double chargePercentage;
	
	private String confirmedChargedAmount;
	
	private String chargeCodeIdentifierDesc;

	public String getChargeCode() {
		return chargeCode;
	}

	public void setChargeCode(String chargeCode) {
		this.chargeCode = chargeCode;
	}

	public String getChargeDesc() {
		return chargeDesc;
	}

	public void setChargeDesc(String chargeDesc) {
		this.chargeDesc = chargeDesc;
	}

	public String getChargeCCY() {
		return chargeCCY;
	}

	public void setChargeCCY(String chargeCCY) {
		this.chargeCCY = chargeCCY;
	}

	public String getChargeAmount() {
		return chargeAmount;
	}

	public void setChargeAmount(String chargeAmount) {
		this.chargeAmount = chargeAmount;
	}

	public String getChargeCodeIdentifier() {
		return chargeCodeIdentifier;
	}

	public void setChargeCodeIdentifier(String chargeCodeIdentifier) {
		this.chargeCodeIdentifier = chargeCodeIdentifier;
	}

	public String getChargeAmountToBeDiscounted() {
		return chargeAmountToBeDiscounted;
	}

	public void setChargeAmountToBeDiscounted(String chargeAmountToBeDiscounted) {
		this.chargeAmountToBeDiscounted = chargeAmountToBeDiscounted;
	}

	public double getChargePercentage() {
		return chargePercentage;
	}

	public void setChargePercentage(double chargePercentage) {
		this.chargePercentage = chargePercentage;
	}

	public String getConfirmedChargedAmount() {
		return confirmedChargedAmount;
	}

	public void setConfirmedChargedAmount(String confirmedChargedAmount) {
		this.confirmedChargedAmount = confirmedChargedAmount;
	}

	public String getChargeCodeIdentifierDesc() {
		return chargeCodeIdentifierDesc;
	}

	public void setChargeCodeIdentifierDesc(String chargeCodeIdentifierDesc) {
		this.chargeCodeIdentifierDesc = chargeCodeIdentifierDesc;
	}

	
	
	
	
}
