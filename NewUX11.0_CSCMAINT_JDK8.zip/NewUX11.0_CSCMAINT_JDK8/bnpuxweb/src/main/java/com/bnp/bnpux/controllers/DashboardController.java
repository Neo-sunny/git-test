/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-JUL-2017
 * 
 * Purpose:      Limit Utilization  Controller
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27-JUL-2017				Divyashri Subramaniam						To Handle service calls related to Limit Utilization 
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.service.IDashboardService;
import com.bnp.bnpux.util.RequestIdentityValidator;
import com.bnp.bnpux.vo.requestVO.DashPendingActRequestVO;
import com.bnp.bnpux.vo.requestVO.DashSettelmentDueRequestVO;
import com.bnp.bnpux.vo.requestVO.LimitUtilReportRequestVO;
import com.bnp.bnpux.vo.requestVO.LimitUtilReportResponseVO;
import com.bnp.bnpux.vo.requestVO.RequestParamVO;
import com.bnp.bnpux.vo.responseVO.DashSettelmentDueResponseVO;
import com.bnp.bnpux.wrappers.service.ILimitUtilReportWrapperService;

@RestController
@RequestMapping("/dashboardController")
public class DashboardController {

	public static final Logger log = LoggerFactory.getLogger(DashboardController.class);

	@Autowired
	private ILimitUtilReportWrapperService limitUtilReportWrapperService;
	
	@Autowired
	private IDashboardService dashboardService;
	
    @Autowired
	RequestIdentityValidator validateRequest;
	
	@RequestMapping(value = "getDefaultFilerList.rest", method = RequestMethod.POST)
	public LimitUtilReportResponseVO getDefaultFilerList(@RequestBody LimitUtilReportRequestVO limitUtilReportRequestVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
	    	LimitUtilReportResponseVO limitUtilReportResponseVO = new LimitUtilReportResponseVO();
			try {
				boolean requestValidatedFlag = validateRequest.validate(limitUtilReportRequestVO.getUserId(), httpServletRequest.getSession());					
				if(requestValidatedFlag && limitUtilReportRequestVO.getGetFilterValType() != null){				    									
					if(limitUtilReportRequestVO.getGetFilterValType().equals("DEFAULT")){
						limitUtilReportResponseVO = limitUtilReportWrapperService.getDefaultFilerList(limitUtilReportRequestVO);
					}
					else if(limitUtilReportRequestVO.getGetFilterValType().equals("GET_ORG")){
						limitUtilReportResponseVO = limitUtilReportWrapperService.getOrgFilterList(limitUtilReportRequestVO);
					}
					else if(limitUtilReportRequestVO.getGetFilterValType().equals("GET_CCY")){
						limitUtilReportResponseVO = limitUtilReportWrapperService.getCcyFilterList(limitUtilReportRequestVO);
					}
				}else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} 
			catch (Exception exception) {
				limitUtilReportResponseVO.setErrMessage(exception.getMessage());
				log.error(exception.getMessage(), exception);
			}
			return limitUtilReportResponseVO;
		}
	
	@RequestMapping(value = "getSearchedData.rest", method = RequestMethod.POST)
	public LimitUtilReportResponseVO getSearchedData(@RequestBody LimitUtilReportRequestVO limitUtilReportRequestVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
	    	LimitUtilReportResponseVO limitUtilReportResponseVO = new LimitUtilReportResponseVO();
			try {
				boolean requestValidatedFlag = validateRequest.validate(limitUtilReportRequestVO.getUserId(), httpServletRequest.getSession());					
				if(requestValidatedFlag){		
					if(limitUtilReportRequestVO.getSelectedCcy() == null || limitUtilReportRequestVO.getSelectedCcy().equals("")){
						limitUtilReportResponseVO = limitUtilReportWrapperService.getSearchedData(limitUtilReportRequestVO);
					}
					else if(limitUtilReportRequestVO.getSelectedCcy().length() != 0){
						limitUtilReportResponseVO = limitUtilReportWrapperService.getSearchedDataOnCcyChange(limitUtilReportRequestVO);
					}
				}else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} 
			catch (Exception exception) {
				limitUtilReportResponseVO.setErrMessage(exception.getMessage());
				log.error(exception.getMessage(), exception);
			}
			return limitUtilReportResponseVO;
		}
	
	@RequestMapping(value = "getLimitDetails.rest", method = RequestMethod.POST)
	public LimitUtilReportResponseVO getLimitDetails(@RequestBody LimitUtilReportRequestVO limitUtilReportRequestVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
	    	LimitUtilReportResponseVO limitUtilReportResponseVO = new LimitUtilReportResponseVO();
			try {
				boolean requestValidatedFlag = validateRequest.validate(limitUtilReportRequestVO.getUserId(), httpServletRequest.getSession());					
				if(requestValidatedFlag){		
					if(limitUtilReportRequestVO.getLimitDetailKey() != null && (limitUtilReportRequestVO.getLimitDetailKey().equals("Group") || limitUtilReportRequestVO.getLimitDetailKey().equals("TP"))){
						limitUtilReportResponseVO = limitUtilReportWrapperService.getLimitDetails(limitUtilReportRequestVO);
					}
				}else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} 
			catch (Exception exception) {
				limitUtilReportResponseVO.setErrMessage(exception.getMessage());
				log.error(exception.getMessage(), exception);
			}
			return limitUtilReportResponseVO;
		}
	@RequestMapping(value = "getSettlementSearchDetails.rest", method = RequestMethod.POST)
	public DashSettelmentDueResponseVO getSettlementSearchDetails(@RequestBody DashSettelmentDueRequestVO dashSettelmentDueRequestVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		DashSettelmentDueResponseVO dashSettelmentDueResponseVO = new DashSettelmentDueResponseVO();
			try {
				boolean requestValidatedFlag = validateRequest.validate(dashSettelmentDueRequestVO.getUserId(), httpServletRequest.getSession());					
				if(requestValidatedFlag){		
					dashSettelmentDueResponseVO = limitUtilReportWrapperService.getSettlementSearchDetails(dashSettelmentDueRequestVO);
				}else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} 
			catch (Exception exception) {
				dashSettelmentDueResponseVO.setErrorMessage(exception.getMessage());
				log.error(exception.getMessage(), exception);
			}
			return dashSettelmentDueResponseVO;
		}
	
	@RequestMapping(value = "getPendingActionDetails.rest", method = RequestMethod.POST)
	public LimitUtilReportResponseVO getPendingActionDetails(@RequestBody DashPendingActRequestVO dashPendingActRequestVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		LimitUtilReportResponseVO limitUtilReportResponseVO = null;
			try {
				boolean requestValidatedFlag = validateRequest.validate(dashPendingActRequestVO.getUserId(), httpServletRequest.getSession());					
				if(requestValidatedFlag){		
					limitUtilReportResponseVO = dashboardService.getPendingActionDetails(dashPendingActRequestVO);
				}else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			} 
			catch (Exception exception) {
				log.error(exception.getMessage(), exception);
			}
			return limitUtilReportResponseVO;
		}
	@RequestMapping(value="getRequestedParamMapping.rest",method=RequestMethod.POST)
	public String getRequestedParamMapping(@RequestBody RequestParamVO requestParamVO,HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse){
		String outputValue = null;
		try{
			boolean requestValidatedFlag = validateRequest.validate(requestParamVO.getUserId(), httpServletRequest.getSession());
			if(requestValidatedFlag){
				outputValue = dashboardService.getRequestedParamMapping(requestParamVO);
			}else{
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		}catch(Exception exception){
			log.error(exception.getMessage(),exception);
		}
		return outputValue;
	}
}