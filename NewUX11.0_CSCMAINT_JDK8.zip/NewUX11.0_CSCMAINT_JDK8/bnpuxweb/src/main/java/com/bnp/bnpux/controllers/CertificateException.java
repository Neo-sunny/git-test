/*************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   01 Sep 2011
 * 
 * Purpose:     This class is used handle exceptions occur in the application
 * 
 * Change History: 
 * Date                             Author                                                                    Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------- 
 * 22 Sep 2011                      Oracle Financial Services Software Ltd                                    Added comments
 * 
 ***************************************************************************/

package com.bnp.bnpux.controllers;

/**
 * @Author : Oracle Financial Services Software Limited
 * @Name : CertificateException.java
 * @Description : This class is used handle exceptions occur in the application
 */
public class CertificateException extends Exception {

	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public CertificateException() {
		super();
	}

	/**
	 * @param message
	 */
	public CertificateException(String message) {
		super(message);
	}

	/**
	 * @param exception
	 */
	public CertificateException(Exception exception) {
		super(exception);
	}
	
	/**
	 * @param message
	 * @param exception
	 */
	public CertificateException(String message, Exception exception) {
		super(message, exception);
	}

}
