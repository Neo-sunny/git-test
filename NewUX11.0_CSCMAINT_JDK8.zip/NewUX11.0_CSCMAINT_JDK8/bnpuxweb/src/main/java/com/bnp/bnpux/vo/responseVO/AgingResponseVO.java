/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  21 June 2017
 * 
 * Purpose:      Credit Note Inquiry Report Summary VO
 * 
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 21 June 2017       Ratna Gokhale, Oracle Financial Services Software Ltd     Initial Version
 * 
 ************************************************************************************************************************************************************/

package com.bnp.bnpux.vo.responseVO;

import java.util.List;

import com.bnp.bnpux.common.vo.AgingRptDetails;
import com.bnp.bnpux.common.vo.AgingRptSummaryList;

public class AgingResponseVO {

	private String errorMessage;
	
	private List<AgingRptSummaryList> agingRptSummaryList;
	
	private List<AgingRptSummaryList> agingRptList;

	private List<AgingRptDetails> agingRptDetailsList;

	private List<AgingRptDetails> agingRptPODetailsList;

	private List<AgingRptDetails> agingRptInvDetailsList;

	private List<AgingRptDetails> agingRptCNDetailsList;	

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage
	 *            the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * @return the agingRptDetailsList
	 */
	public List<AgingRptDetails> getAgingRptDetailsList() {
		return agingRptDetailsList;
	}

	/**
	 * @param agingRptDetailsList the agingRptDetailsList to set
	 */
	public void setAgingRptDetailsList(List<AgingRptDetails> agingRptDetailsList) {
		this.agingRptDetailsList = agingRptDetailsList;
	}

	/**
	 * @return the agingRptPODetailsList
	 */
	public List<AgingRptDetails> getAgingRptPODetailsList() {
		return agingRptPODetailsList;
	}

	/**
	 * @param agingRptPODetailsList the agingRptPODetailsList to set
	 */
	public void setAgingRptPODetailsList(List<AgingRptDetails> agingRptPODetailsList) {
		this.agingRptPODetailsList = agingRptPODetailsList;
	}

	/**
	 * @return the agingRptInvDetailsList
	 */
	public List<AgingRptDetails> getAgingRptInvDetailsList() {
		return agingRptInvDetailsList;
	}

	/**
	 * @param agingRptInvDetailsList the agingRptInvDetailsList to set
	 */
	public void setAgingRptInvDetailsList(
			List<AgingRptDetails> agingRptInvDetailsList) {
		this.agingRptInvDetailsList = agingRptInvDetailsList;
	}

	/**
	 * @return the agingRptCNDetailsList
	 */
	public List<AgingRptDetails> getAgingRptCNDetailsList() {
		return agingRptCNDetailsList;
	}

	/**
	 * @param agingRptCNDetailsList the agingRptCNDetailsList to set
	 */
	public void setAgingRptCNDetailsList(List<AgingRptDetails> agingRptCNDetailsList) {
		this.agingRptCNDetailsList = agingRptCNDetailsList;
	}

	/**
	 * @return the agingRptSummaryList
	 */
	public List<AgingRptSummaryList> getAgingRptSummaryList() {
		return agingRptSummaryList;
	}

	/**
	 * @param agingRptSummaryList the agingRptSummaryList to set
	 */
	public void setAgingRptSummaryList(List<AgingRptSummaryList> agingRptSummaryList) {
		this.agingRptSummaryList = agingRptSummaryList;
	}

	/**
	 * @return the agingRptList
	 */
	public List<AgingRptSummaryList> getAgingRptList() {
		return agingRptList;
	}

	/**
	 * @param agingRptList the agingRptList to set
	 */
	public void setAgingRptList(List<AgingRptSummaryList> agingRptList) {
		this.agingRptList = agingRptList;
	}

	
}
