/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   17-NOV-2016
 * 
 * Purpose:      Payment Order List Details Collection Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.util.List;

public class PaymentOrderListCollectionVO {
	
	private String userId;
	
	private List<PaymentOrderListVO> paymentOrderListCollection;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<PaymentOrderListVO> getPaymentOrderListCollection() {
		return paymentOrderListCollection;
	}

	public void setPaymentOrderListCollection(List<PaymentOrderListVO> paymentOrderListCollection) {
		this.paymentOrderListCollection = paymentOrderListCollection;
	}
	
	
}
