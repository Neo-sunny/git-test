/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   23-Feb-2017 by AnubhaJ
 * 
 * Purpose:      Contact Us pop Up object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 23-Feb-2017				AnubhaJ												Created FO 10.0 S015,S016,S017
************************************************************************************************************************************************************/

package com.bnp.bnpux.controllers;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.io.IOException;
import java.io.OutputStream;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.common.vo.ContactUsVO;
import com.bnp.bnpux.common.vo.CountryFlagVO;
import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.constants.ContactUsConstants;
import com.bnp.bnpux.constants.ErrorConstants;
import com.bnp.bnpux.service.IContactUsService;
import com.bnp.bnpux.util.RequestIdentityValidator;
import com.bnp.scm.services.common.exception.BNPApplicationException;


@RestController
@RequestMapping("/contactUs")
public class ContactUsController {
	/**
	 * Logger for ContactUsController
	 */
	public static final Logger log = LoggerFactory.getLogger(ContactUsController.class);
	
	
	/**
	 * Autowired Interface IContactUsService
	 */
	@Autowired
	private IContactUsService contactUsService;
	
	@Autowired
	private RequestIdentityValidator validateRequest;
	
	
	/**
	 * This method is for getting the Location Drop down
	 * @param 
	 * @return List<SettlementResponseVO>
	 * @throws BNPApplicationException
	 */
	
	@RequestMapping(value = ContactUsConstants.LOCATION_DR_DW, method = RequestMethod.POST)
	public List<CountryFlagVO> getLocationDetails(@RequestBody ContactUsVO contactUsVO,HttpServletRequest request,HttpServletResponse response) {		
		List<CountryFlagVO> countryList = new ArrayList<CountryFlagVO>();
		try {
			boolean requestValidatedFlag = validateRequest.validate(contactUsVO.getUserId(),request.getSession());
			if(requestValidatedFlag){
				countryList = contactUsService.fetchLocationDropDwn();
			}
			else{
				countryList = null;
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
				
		} catch (BNPApplicationException exception) {
			log.error(exception.getMessage(),exception);	
		}
		return countryList;
	}
	/**
	 * This method is for submitting the data and sending email
	 * @param ContactUsVO
	 * @return ContactUsVO
	 * @throws BNPApplicationException
	 */
	@RequestMapping(value = ContactUsConstants.SUBMIT_CONTACTUS, method = RequestMethod.POST)
	public ContactUsVO submitDetails(@RequestBody ContactUsVO contactUsVO,HttpServletRequest request,HttpServletResponse response) {		
		
		try {
			boolean requestValidatedFlag = validateRequest.validate(contactUsVO.getUserId(),request.getSession());
			if(requestValidatedFlag){
				String validCaptcha = (String)request.getSession().getAttribute("CONTACT_US_CAPTCHA");
				if(validCaptcha != null && contactUsVO.getCaptchaText() != null && validCaptcha.equals(contactUsVO.getCaptchaText())){
					contactUsVO =  contactUsService.sendContactUsDetails(contactUsVO);
				}else{
					contactUsVO.setErrorMsg(Integer.toString(ErrorConstants.CAPTCHA_TEXT_NOT_MATCHED));
				}
			}
			else{
				//countryList = null;
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
				
		} catch (Exception exception) {
			contactUsVO.setErrorMsg(Integer.toString(ErrorConstants.EMAIL_SEND_FAIL));
			log.error(exception.getMessage(),exception);	
		}
		return contactUsVO;
	}
	
	
	@RequestMapping(value = ContactUsConstants.GET_CAPTCHA, method = RequestMethod.GET)
	public void getCaptcha(@RequestParam("userId") String userId,HttpServletRequest request,HttpServletResponse response) {		
		 OutputStream stream= null;
		try {
			 stream = response.getOutputStream();
			boolean requestValidatedFlag = validateRequest.validate(userId,request.getSession());
			if(requestValidatedFlag){
				SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
				String randomCaptchaNo = String.valueOf(random.nextLong()).substring(1, 5);
				
				request.getSession().setAttribute("CONTACT_US_CAPTCHA",randomCaptchaNo);
				
				int width = 70, height = 30, x, y;
				x = random.nextInt(15 - 1 + 1) + 5;
				y = random.nextInt(15 - 1 + 1) + 5;
				response.setContentType("image/jpeg");
	             BufferedImage img = new BufferedImage(width, height,
						BufferedImage.TYPE_INT_RGB);

				Graphics2D g2d = img.createGraphics();

				Font font = new Font("Mistral", Font.BOLD+Font.ITALIC, 16);
				
				g2d.setFont(font);
				g2d.setColor(Color.LIGHT_GRAY);
				g2d.fillRect(0, 0, width, height);

				g2d.setColor(Color.black);
				
				g2d.drawArc (x, y, x+80, y+180,x+50,y+55);
				g2d.drawArc (x, y, x+80, x+80,x+26,y+90);
				g2d.drawLine(x, y, x+80, y+80);
				g2d.drawLine(x+20, y, x+80, y+80);
				g2d.drawString(randomCaptchaNo, 17, 20);

				g2d.dispose();

				ImageIO.write(img, "jpeg", stream);
				stream.flush();
			}
			else{
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
				
		}  catch (NoSuchAlgorithmException e) {
			log.error(e.getMessage(),e);	
		} catch (IOException e) {
			log.error(e.getMessage(),e);	
		}finally{
			try {
				if(stream!=null){
					stream.close();
				}
			} catch (IOException e) {
				log.error(e.getMessage(),e);
			}
		}
	}
	
	
}

