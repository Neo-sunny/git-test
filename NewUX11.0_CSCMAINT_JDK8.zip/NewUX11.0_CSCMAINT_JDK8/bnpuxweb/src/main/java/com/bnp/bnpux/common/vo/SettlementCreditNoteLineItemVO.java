/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Settlement Credit Note Line Item Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;

public class SettlementCreditNoteLineItemVO {

	public SettlementCreditNoteLineItemVO(){		
	}
	
	private String critSuppItmNo;
	private String critSuppPartNo;
	private String critItmDesc;
	private String critUOM;
	private int critQTY;
	private BigDecimal critPrice;
	private BigDecimal critTotalPrice;	
	private String critPoNo;
	private String error_result;
	private String error_msg;
	
	public String getCritSuppItmNo() {
		return critSuppItmNo;
	}
	public void setCritSuppItmNo(String critSuppItmNo) {
		this.critSuppItmNo = critSuppItmNo;
	}
	public String getCritSuppPartNo() {
		return critSuppPartNo;
	}
	public void setCritSuppPartNo(String critSuppPartNo) {
		this.critSuppPartNo = critSuppPartNo;
	}
	public String getCritItmDesc() {
		return critItmDesc;
	}
	public void setCritItmDesc(String critItmDesc) {
		this.critItmDesc = critItmDesc;
	}
	public String getCritUOM() {
		return critUOM;
	}
	public void setCritUOM(String critUOM) {
		this.critUOM = critUOM;
	}	

	public BigDecimal getCritPrice() {
		return critPrice;
	}
	public void setCritPrice(BigDecimal critPrice) {
		this.critPrice = critPrice;
	}
	public BigDecimal getCritTotalPrice() {
		return critTotalPrice;
	}
	public void setCritTotalPrice(BigDecimal critTotalPrice) {
		this.critTotalPrice = critTotalPrice;
	}
	public String getCritPoNo() {
		return critPoNo;
	}
	public void setCritPoNo(String critPoNo) {
		this.critPoNo = critPoNo;
	}
	public String getError_result() {
		return error_result;
	}
	public void setError_result(String error_result) {
		this.error_result = error_result;
	}
	public String getError_msg() {
		return error_msg;
	}
	public void setError_msg(String error_msg) {
		this.error_msg = error_msg;
	}
	public int getCritQTY() {
		return critQTY;
	}
	public void setCritQTY(int critQTY) {
		this.critQTY = critQTY;
	}
	
	
	/**
	 * Getter methods introduced to send the amounts as
	 * String to avoid amount > 16 digits getting truncated
	 * Added as part of defect Fix CSC-7835
	 */
	

	public String getCritPriceStr() {
		return (critPrice!=null)?critPrice.toPlainString():"";
	}

	public String getCritTotalPriceStr() {
		return (critTotalPrice!=null)?critTotalPrice.toPlainString():"";
	}
	
	/**End of CSC-7835 Changes**/
	
}

