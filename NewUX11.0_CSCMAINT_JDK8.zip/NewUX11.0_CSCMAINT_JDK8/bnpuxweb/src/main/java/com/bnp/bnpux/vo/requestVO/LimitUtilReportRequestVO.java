/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-JUL-2017
 * 
 * Purpose:      Limit Utilization  Request VO
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27-JUL-2017				Divyashri Subramaniam						To Handle service calls Request Object related to Limit Utilization 
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.requestVO;

public class LimitUtilReportRequestVO {
	
	private String userId;

	private String userType;
	
	private String errMessage;
	
	private String selectedBranch;
	
	private String selectedOrgId;
	
	private String selectedCcy;
	
	private String getFilterValType;
	
	private String limitDetailKey;
	
	private Integer errCode;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getErrMessage() {
		return errMessage;
	}

	public void setErrMessage(String errMessage) {
		this.errMessage = errMessage;
	}

	public Integer getErrCode() {
		return errCode;
	}

	public void setErrCode(Integer errCode) {
		this.errCode = errCode;
	}

	public String getSelectedBranch() {
		return selectedBranch;
	}

	public void setSelectedBranch(String selectedBranch) {
		this.selectedBranch = selectedBranch;
	}

	public String getSelectedOrgId() {
		return selectedOrgId;
	}

	public void setSelectedOrgId(String selectedOrgId) {
		this.selectedOrgId = selectedOrgId;
	}

	public String getGetFilterValType() {
		return getFilterValType;
	}

	public void setGetFilterValType(String getFilterValType) {
		this.getFilterValType = getFilterValType;
	}

	public String getSelectedCcy() {
		return selectedCcy;
	}

	public void setSelectedCcy(String selectedCcy) {
		this.selectedCcy = selectedCcy;
	}

	public String getLimitDetailKey() {
		return limitDetailKey;
	}

	public void setLimitDetailKey(String limitDetailKey) {
		this.limitDetailKey = limitDetailKey;
	}

}
