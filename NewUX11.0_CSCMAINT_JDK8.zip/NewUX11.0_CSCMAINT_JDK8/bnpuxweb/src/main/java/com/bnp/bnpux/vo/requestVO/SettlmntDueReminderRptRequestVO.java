package com.bnp.bnpux.vo.requestVO;

import java.util.Date;
import java.util.List;

import com.bnp.bnpux.common.vo.SettlmntDueReminderDetailsVO;
import com.bnp.bnpux.common.vo.SettlmntDueReminderVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;

public class SettlmntDueReminderRptRequestVO {
	
	
	private String userId;

	private String userTypeId;

	private String orgId;
	
	private String counterPtyOrgId;
	
	private String currencyCode;
	
	private String getWhat;
	
	private String branch;
	
	private String period;
	
	private String reportType;
	
	private Date projSettleDate;
	
	private String errorMsg;
	
	private Integer recordFrom;
	
	private Integer recordTo;
	
	private String exportType;
	
	private String viewType;
	
	private List<ReportChartResponseVO> reportChartList;
	
	/**
	 * @return the viewType
	 */
	public String getViewType() {
		return viewType;
	}

	/**
	 * @param viewType the viewType to set
	 */
	public void setViewType(String viewType) {
		this.viewType = viewType;
	}

	private List<SettlmntDueReminderVO> settlmntDueReminder;
	
	private List<SettlmntDueReminderDetailsVO> settlmntDueReminderDetails;
	
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the userTypeId
	 */
	public String getUserTypeId() {
		return userTypeId;
	}

	/**
	 * @param userTypeId the userTypeId to set
	 */
	public void setUserTypeId(String userTypeId) {
		this.userTypeId = userTypeId;
	}

	/**
	 * @return the orgId
	 */
	public String getOrgId() {
		return orgId;
	}

	/**
	 * @param orgId the orgId to set
	 */
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	/**
	 * @return the counterPtyOrgId
	 */
	public String getCounterPtyOrgId() {
		return counterPtyOrgId;
	}

	/**
	 * @param counterPtyOrgId the counterPtyOrgId to set
	 */
	public void setCounterPtyOrgId(String counterPtyOrgId) {
		this.counterPtyOrgId = counterPtyOrgId;
	}

	/**
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	/**
	 * @return the getWhat
	 */
	public String getGetWhat() {
		return getWhat;
	}

	/**
	 * @param getWhat the getWhat to set
	 */
	public void setGetWhat(String getWhat) {
		this.getWhat = getWhat;
	}

	/**
	 * @return the branch
	 */
	public String getBranch() {
		return branch;
	}

	/**
	 * @param branch the branch to set
	 */
	public void setBranch(String branch) {
		this.branch = branch;
	}

	/**
	 * @return the period
	 */
	public String getPeriod() {
		return period;
	}

	/**
	 * @param period the period to set
	 */
	public void setPeriod(String period) {
		this.period = period;
	}

	/**
	 * @return the reportType
	 */
	public String getReportType() {
		return reportType;
	}

	/**
	 * @param reportType the reportType to set
	 */
	public void setReportType(String reportType) {
		this.reportType = reportType;
	}

	/**
	 * @return the projSettleDate
	 */
	public Date getProjSettleDate() {
		return projSettleDate;
	}

	/**
	 * @param projSettleDate the projSettleDate to set
	 */
	public void setProjSettleDate(Date projSettleDate) {
		this.projSettleDate = projSettleDate;
	}

	/**
	 * @return the errorMsg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}

	/**
	 * @param errorMsg the errorMsg to set
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	/**
	 * @return the recordFrom
	 */
	public Integer getRecordFrom() {
		return recordFrom;
	}

	/**
	 * @param recordFrom the recordFrom to set
	 */
	public void setRecordFrom(Integer recordFrom) {
		this.recordFrom = recordFrom;
	}

	/**
	 * @return the recordTo
	 */
	public Integer getRecordTo() {
		return recordTo;
	}

	/**
	 * @param recordTo the recordTo to set
	 */
	public void setRecordTo(Integer recordTo) {
		this.recordTo = recordTo;
	}

	/**
	 * @return the exportType
	 */
	public String getExportType() {
		return exportType;
	}

	/**
	 * @return the settlmntDueReminder
	 */
	public List<SettlmntDueReminderVO> getSettlmntDueReminder() {
		return settlmntDueReminder;
	}

	/**
	 * @param settlmntDueReminder the settlmntDueReminder to set
	 */
	public void setSettlmntDueReminder(
			List<SettlmntDueReminderVO> settlmntDueReminder) {
		this.settlmntDueReminder = settlmntDueReminder;
	}

	/**
	 * @param exportType the exportType to set
	 */
	public void setExportType(String exportType) {
		this.exportType = exportType;
	}

	/**
	 * @return the settlmntDueReminderDetails
	 */
	public List<SettlmntDueReminderDetailsVO> getSettlmntDueReminderDetails() {
		return settlmntDueReminderDetails;
	}

	/**
	 * @param settlmntDueReminderDetails the settlmntDueReminderDetails to set
	 */
	public void setSettlmntDueReminderDetails(
			List<SettlmntDueReminderDetailsVO> settlmntDueReminderDetails) {
		this.settlmntDueReminderDetails = settlmntDueReminderDetails;
	}

	/**
	 * @return the reportChartList
	 */
	public List<ReportChartResponseVO> getReportChartList() {
		return reportChartList;
	}

	/**
	 * @param reportChartList the reportChartList to set
	 */
	public void setReportChartList(List<ReportChartResponseVO> reportChartList) {
		this.reportChartList = reportChartList;
	}

}
