/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      User Preference Interface for Data Access Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.dao;

import java.util.List;


import com.bnp.bnpux.common.vo.UserPreferenceVO;
import com.bnp.scm.services.common.vo.NameValueVO;

public interface IUserPrefDAO {

	/**
	 * This method is for getting TimeZone List
	 * 
	 * @return
	 */
	List<NameValueVO> getTimeZoneList();

	/**
	 * This method is for saving User Preference 
	 * 
	 * @param userPrefVO
	 */
	void saveUserPreference(UserPreferenceVO userPrefVO);

	/**
	 * This method is for getting Locale
	 * 
	 * @param langId
	 * @return
	 */
	String getLocale(String langId);

	/**
	 * This method is for getting User Preference 
	 * 
	 * @param userId
	 * @return
	 */
	UserPreferenceVO getUserPreferenceInfo(String userId);

	/**
	 * This method is for getting TimeZone For BA
	 * 
	 * @param userId
	 * @return
	 */
	NameValueVO getTimeZoneForBA(String userId);

	/**
	 * This method is for getting TimeZone For BuyerSeller
	 * 
	 * @param userId
	 * @return
	 */
	NameValueVO getTimeZoneForBuyerSeller(String userId);

	/**
	 * This method is for getting TimeZone
	 * 
	 * @return
	 */
	List<NameValueVO> getTimeZone();

	/**
	 * This method is for getting DealType
	 * 
	 * @param userId
	 * @return
	 */
	String getDealType(String userId);

	/**
	 * This method is for getting Country TimeZone Code
	 * 
	 * @return
	 */
	List<NameValueVO> getCountryTimeZoneCode();

	/**
	 * This method is for getting UserLocale
	 * 
	 * @param userId
	 * @return
	 */
	String getUserLocale(String userId);
	
}
