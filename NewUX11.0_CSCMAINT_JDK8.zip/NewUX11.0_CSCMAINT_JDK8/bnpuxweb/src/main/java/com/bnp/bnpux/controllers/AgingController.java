/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   21 June 2017
 * 
 * Purpose:      Credit Note Inquiry Report Controller
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 21 June 2017       Ratna Gokhale, Oracle Financial Services Software Ltd     Initial Version
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.service.IAgingReportService;
import com.bnp.bnpux.util.RequestIdentityValidator;
import com.bnp.bnpux.vo.requestVO.AgingRequestVO;
import com.bnp.bnpux.vo.responseVO.AgingResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@RestController
@RequestMapping("/AgingController")
public class AgingController {


	/**
	 * Logger for AgingController
	 */
	public static final Logger log = LoggerFactory.getLogger(AgingController.class);
	
	
	/**
	 * Autowired Interface IAgingReportService
	 */
	@Autowired
	private IAgingReportService reportService;
	
	@Autowired
	RequestIdentityValidator validateRequest;
	
	
	/**
	 * This method is for getting the Credit Note Inquiry Reports Details list
	 * 
	 * @param agingReqVO
	 * @return
	 */
	@RequestMapping(value = "getAgingRptList.rest", method = RequestMethod.POST)
	public AgingResponseVO getAgingRptList(@RequestBody AgingRequestVO agingReqVO,HttpServletRequest request,HttpServletResponse response) {		
		AgingResponseVO agingResponseVO = new AgingResponseVO();
		try {
			boolean requestValidatedFlag = validateRequest.validate(agingReqVO.getUserId(),request.getSession());
			if(requestValidatedFlag){
				agingResponseVO = reportService.getReportList(agingReqVO);
			}
			else{
				agingResponseVO = null;
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (BNPApplicationException exception) {
			agingResponseVO.setErrorMessage(exception.getMessage());
			log.error(exception.getMessage(),exception);	
		}
		return agingResponseVO;
	}
	
}