/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   29 Mar 2017	
 * 
 * Purpose:       Buyer Acceptance screen
 * 
 * Change History: 
 * Date                       Author                                    Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 29 Mar 2017			      kmanimar					                Initial Version - FO 10.0 - S2098
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.requestVO;

import java.util.Date;
import java.util.List;

import com.bnp.bnpux.common.vo.AdvancedFilterVO;
import com.bnp.bnpux.common.vo.BaAttachmentListVO;
import com.bnp.bnpux.common.vo.BuyerAcceptanceListVO;
import com.bnp.bnpux.common.vo.BuyerAcceptanceSummaryVO;


public class BuyerAcceptanceRequestVO {

	private String userId;
	private String userType;
	private Long recordFrom;
	private Long recordTo;
	private String groupIndicator;
    private String groupValue;
	private String buyerOrgId;
	private String supplierOrgId;
	private String statusFilter;
	private String periodFilter;
	private String branchFilter;
	private String quickSearchText;
	private String viewType;
	private String errorFlag;
	private String referenceNumber;
	private List<BuyerAcceptanceSummaryVO> buyerAcceptanceSummaryVOList;
	private List<BuyerAcceptanceListVO> buyerAcceptanceListVOList;
	private String fileId;
    private String invGroupCode;
    private String getWhat;
    private String refId;
	private String refNo;
	private String recType;
	private String orgId;
	private String action;
	private List<BaAttachmentListVO> baAttachmentListVO;
	private List<AdvancedFilterVO> advancedFilterListVO;
	private String lotNumber;
	private Date dueDate;
	
	public Date getDueDate() {
		return dueDate;
	}
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}
	public String getLotNumber() {
		return lotNumber;
	}
	public void setLotNumber(String lotNumber) {
		this.lotNumber = lotNumber;
	}
	public List<AdvancedFilterVO> getAdvancedFilterListVO() {
		return advancedFilterListVO;
	}
	public void setAdvancedFilterListVO(List<AdvancedFilterVO> advancedFilterListVO) {
		this.advancedFilterListVO = advancedFilterListVO;
	}
	public String getBuyerOrgId() {
		return buyerOrgId;
	}
	public void setBuyerOrgId(String buyerOrgId) {
		this.buyerOrgId = buyerOrgId;
	}
	public String getSupplierOrgId() {
		return supplierOrgId;
	}
	public void setSupplierOrgId(String supplierOrgId) {
		this.supplierOrgId = supplierOrgId;
	}
	public String getUserId() {
		return userId;
	}
	public List<BuyerAcceptanceListVO> getBuyerAcceptanceListVOList() {
		return buyerAcceptanceListVOList;
	}
	public void setBuyerAcceptanceListVOList(List<BuyerAcceptanceListVO> buyerAcceptanceListVOList) {
		this.buyerAcceptanceListVOList = buyerAcceptanceListVOList;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getGroupIndicator() {
		return groupIndicator;
	}
	public void setGroupIndicator(String groupIndicator) {
		this.groupIndicator = groupIndicator;
	}
	public String getPeriodFilter() {
		return periodFilter;
	}
	public void setPeriodFilter(String periodFilter) {
		this.periodFilter = periodFilter;
	}
	public String getStatusFilter() {
		return statusFilter;
	}
	public void setStatusFilter(String statusFilter) {
		this.statusFilter = statusFilter;
	}
	public String getBranchFilter() {
		return branchFilter;
	}
	public void setBranchFilter(String branchFilter) {
		this.branchFilter = branchFilter;
	}
	public String getQuickSearchText() {
		return quickSearchText;
	}
	public void setQuickSearchText(String quickSearchText) {
		this.quickSearchText = quickSearchText;
	}
	public String getViewType() {
		return viewType;
	}
	public void setViewType(String viewType) {
		this.viewType = viewType;
	}
	public String getErrorFlag() {
		return errorFlag;
	}
	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}
	public String getGroupValue() {
		return groupValue;
	}
	public void setGroupValue(String groupValue) {
		this.groupValue = groupValue;
	}
	
	public List<BuyerAcceptanceSummaryVO> getBuyerAcceptanceSummaryVOList() {
		return buyerAcceptanceSummaryVOList;
	}
	public void setBuyerAcceptanceSummaryVOList(List<BuyerAcceptanceSummaryVO> buyerAcceptanceSummaryVOList) {
		this.buyerAcceptanceSummaryVOList = buyerAcceptanceSummaryVOList;
	}
	public String getReferenceNumber() {
		return referenceNumber;
	}
	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getInvGroupCode() {
		return invGroupCode;
	}
	public void setInvGroupCode(String invGroupCode) {
		this.invGroupCode = invGroupCode;
	}
	public String getGetWhat() {
		return getWhat;
	}
	public void setGetWhat(String getWhat) {
		this.getWhat = getWhat;
	}
	public String getRefId() {
		return refId;
	}
	public void setRefId(String refId) {
		this.refId = refId;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public String getRecType() {
		return recType;
	}
	public void setRecType(String recType) {
		this.recType = recType;
	}
	public List<BaAttachmentListVO> getBaAttachmentListVO() {
		return baAttachmentListVO;
	}
	public void setBaAttachmentListVO(List<BaAttachmentListVO> baAttachmentListVO) {
		this.baAttachmentListVO = baAttachmentListVO;
	}
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}
	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}
	public Long getRecordFrom() {
		return recordFrom;
	}
	public void setRecordFrom(Long recordFrom) {
		this.recordFrom = recordFrom;
	}
	public Long getRecordTo() {
		return recordTo;
	}
	public void setRecordTo(Long recordTo) {
		this.recordTo = recordTo;
	}

}
