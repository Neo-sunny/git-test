/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Discount Request Service Implementation
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.discounting.serviceImpl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.common.vo.PaymentOrderListVO;
import com.bnp.bnpux.dao.IPaymentOrderDAO;
import com.bnp.bnpux.discounting.service.ISearchDiscountRequestsService;
import com.bnp.scm.common.ResourceManager;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.discounting.IDiscountRequestService;
import com.bnp.scm.services.discounting.mb.ITPDiscRequestService;
import com.bnp.scm.services.discounting.util.BNPDiscountUtil;
import com.bnp.scm.services.discounting.vo.DiscountRequestVO;

@Component
public class SearchDiscountRequestsServiceImpl implements ISearchDiscountRequestsService {

private static final Logger log = LoggerFactory.getLogger(SearchDiscountRequestsServiceImpl.class);		
	
	private String statusMsg;	

	private BigDecimal totalIndicativeDiscountAmt = new BigDecimal(0);

	private BigDecimal totalIndicativeNetAmt = new BigDecimal(0);

	private BigDecimal indicativeChargeAmt = new BigDecimal(0);	
	
	private BigDecimal totalAvailableAmt = new BigDecimal(0);

	private boolean recalculateflag=false;
	
	private boolean disableDiscount;

	public ITPDiscRequestService getTpDiscReqService() {
		return tpDiscReqService;
	}


	public void setTpDiscReqService(ITPDiscRequestService tpDiscReqService) {
		this.tpDiscReqService = tpDiscReqService;
	}



	public IDiscountRequestService getDiscountService() {
		return discountService;
	}


	public void setDiscountService(IDiscountRequestService discountService) {
		this.discountService = discountService;
	}


	public BigDecimal getTotalIndicativeDiscountAmt() {
		return totalIndicativeDiscountAmt;
	}


	public BigDecimal getTotalIndicativeNetAmt() {
		return totalIndicativeNetAmt;
	}


	public BigDecimal getIndicativeChargeAmt() {
		return indicativeChargeAmt;
	}


	public BigDecimal getTotalAvailableAmt() {
		return totalAvailableAmt;
	}


	public boolean isRecalculateflag() {
		return recalculateflag;
	}


	public boolean isDisableDiscount() {
		return disableDiscount;
	}




	@Autowired
	private ITPDiscRequestService tpDiscReqService;

	@Autowired
	private IDiscountRequestService discountService;

	
	
	@Autowired
	private IPaymentOrderDAO paymentOrderDAO;
	
	
	@Autowired
	private ResourceManager resourceManager;
	
	/*
	 * This method is for getting Discount Request
	 * 
	 *  (non-Javadoc)
	 * @see com.bnp.bnpux.discounting.service.ISearchDiscountRequestsService#getDiscRequestVO(com.bnp.bnpux.common.vo.PaymentOrderListVO)
	 */
	public DiscountRequestVO getDiscRequestVO(PaymentOrderListVO paymentOrderListtVO) throws BNPApplicationException{
		
		List<PaymentOrderListVO> discVO1 = new ArrayList<PaymentOrderListVO>();
		discVO1.add(paymentOrderListtVO);
		List<DiscountRequestVO>  discVo = paymentOrderDAO.getDiscountRequestVO(discVO1);
		if(discVo.size()>0){
			discVo.get(0).setAvailableAmt(paymentOrderListtVO.getAvailableAmount());
			discVo.get(0).setDiscountDate(paymentOrderListtVO.getDiscountDate());
		}else{
			DiscountRequestVO disc = new DiscountRequestVO();
			disc.setErrorData(Integer.toString(ErrorConstants.RECALCULATE_VALID_RECORD));
			return disc;
		}
		try {
			recalculateDiscountRequest(discVo.get(0));
		} catch (Exception e) {
			log.error(e.getMessage(),e);
			DiscountRequestVO disc = new DiscountRequestVO();
			disc.setErrorData(Integer.toString(ErrorConstants.PROCESSING_ERROR));
			return disc;
		}
		return discVo.get(0);
		
		
		
	}
	
	
	/* 
	 * This method is for recalculating discount request
	 * 
	 * (non-Javadoc)
	 * @see com.bnp.bnpux.discounting.service.ISearchDiscountRequestsService#recalculateDiscountRequest(com.bnp.scm.services.discounting.vo.DiscountRequestVO)
	 */
	public DiscountRequestVO recalculateDiscountRequest(DiscountRequestVO discountVO) {
		boolean discStatusCheck =true;

		statusMsg=null;
			if(discountVO.getDiscountDate() != null){
				if(!checkAvailableAmount(discountVO)){
					return discountVO;
				}
				discStatusCheck = checkDiscountStatus(discountVO);
				if(discStatusCheck){
					
					if (!compareDueDateAndDiscountDate(discountVO)) {
						return discountVO;
					}
					try {
						discountVO.setRefreshRatesFromDiscReqScreen(true);
						if(BNPDiscountUtil.isMultiBankingModel(discountVO.getMbModel())) {
							discountVO.setTpDiscounts(tpDiscReqService.getTPDiscountsForRequest(discountVO));
						}
						discountVO.setDiscountCharges(discountService.fetchDiscountTmpChargesList(discountVO));
						discountService.recalculateDiscountRequest(discountVO);
						discountVO.setErrorData(resourceManager.getMessage(ErrorConstants.DISCOUNT_RECALC_SUCCESS));
						discountVO.setErrorMessage(ErrorConstants.DISCOUNT_RECALC_SUCCESS);
					} catch (BNPApplicationException e) {
						discountVO.setErrorData(resourceManager.getMessage(e.getErrorCode()));
						log.error(e.getMessage(),e);
						return discountVO;
					}
				}
				else{
					discountVO.setErrorData(resourceManager.getMessage(ErrorConstants.SELECT_RELEASED_RECORD));
					return discountVO;
				}
			}
			else{
				//setStatusMsg(resourceManager.getMessage(ErrorConstants.DISC_DATE_NOT_NULL));
				discountVO.setErrorData(resourceManager.getMessage(ErrorConstants.DISC_DATE_NOT_NULL));
				return discountVO;
			}
			
			return discountVO;
		}
		

	/**
	 * This method is for checking available amount
	 * 
	 * @param selectedDiscountReqVO
	 * @return
	 */
	private boolean checkAvailableAmount(DiscountRequestVO selectedDiscountReqVO){
		if(selectedDiscountReqVO.getAvailableAmt().doubleValue() <= 0){
			selectedDiscountReqVO.setErrorData(resourceManager.getMessage(ErrorConstants.AVAILAMT_SHOULD_GT_ZERO));
			return false;
		}else if(selectedDiscountReqVO.getAvailableAmt().compareTo(selectedDiscountReqVO.getOriginalAmt()) > 0){
			selectedDiscountReqVO.setErrorData(resourceManager.getMessage(ErrorConstants.AVAILAMT_SHOULD_LT_ORGAMT));
			return false;
		}
		else{
			return true;
		}
	}

	/**
	 * This method is for checking Discount status
	 * 
	 * @param selectedDiscountReqVO
	 * @return
	 */
	public boolean checkDiscountStatus(DiscountRequestVO selectedDiscountReqVO){
		if(selectedDiscountReqVO.getDiscountStatus().equals(StatusConstants.RELEASED))
			return true;
		else
			return false;
	}

	private boolean compareDueDateAndDiscountDate(DiscountRequestVO discountVO) {
		if (discountVO.getDiscountDate() == null) {
			discountVO.setErrorData(resourceManager.getMessage(ErrorConstants.DISC_DATE_CANNOT_BE_EMPTY));	
			return false;
		}

		long dueDateTime = getTime(discountVO.getDueDate());
		long discDateTime = discountVO.getDiscountDate().getTime();

		if (dueDateTime <= discDateTime) {
			discountVO.setErrorData(resourceManager.getMessage(ErrorConstants.DUEDATE_CANNOT_LESS_THAN_DISCDATE));
			return false;
		}
		return true;
	}

	private long getTime(Date date) {
		return BNPDiscountUtil.getDueDateInMillis(date);
	}
	
	@Override
	public String getViewPage() {
		return "success";
	}


	public String getStatusMsg() {
		return statusMsg;
	}

	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}







}
