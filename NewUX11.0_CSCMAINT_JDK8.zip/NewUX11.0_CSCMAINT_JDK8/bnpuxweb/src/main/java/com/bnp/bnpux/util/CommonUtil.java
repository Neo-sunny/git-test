/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 March 2017
 * 
 * Purpose:      Release File Functionality
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 7  April 2017			Oracle Financial Services Software Ltd					Initial version
 *  7  April 2017			Oracle Financial Services Software Ltd					File management common methods added 
 **********************************************************************************************************************/

package com.bnp.bnpux.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.common.vo.BuyerAcceptanceListVO;
import com.bnp.bnpux.common.vo.FileMgmtListVO;
import com.bnp.bnpux.common.vo.FileMgmtResponseGridVO;
import com.bnp.bnpux.common.vo.ReleaseFileMgmtResponseVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.constants.PaymentOrderConstants;
import com.bnp.bnpux.vo.errorMessageVO.ErrorMessageVO;
import com.bnp.bnpux.vo.requestVO.AuditRequestVO;
import com.bnp.bnpux.vo.responseVO.BuyerAcceptanceResponseVO;
import com.bnp.scm.common.IResourceManager;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.invoice.vo.BuyerAcceptanceVO;


@Component
public class CommonUtil {
	
	public static final Logger log = LoggerFactory.getLogger(CommonUtil.class);
	
	@Autowired
	protected IResourceManager resourceManager;
	
	/**
	 * @param fileName
	 * @param message
	 * @param releaseFileMgmtResponseVO
	 * @param b
	 */
	public  void addReleaseFileMgmtResponseVO(String fileName,
			String message, boolean isError,
			ReleaseFileMgmtResponseVO releaseFileMgmtResponseVO) {
		FileMgmtResponseGridVO fileMgmtResponseGridVO = new FileMgmtResponseGridVO();
		ErrorMessageVO objErrorMessageVO = new ErrorMessageVO();

		fileMgmtResponseGridVO.setFileName(fileName);
		fileMgmtResponseGridVO.setMessage(message);
		fileMgmtResponseGridVO.setError(isError);

		objErrorMessageVO.setUniqueID(fileName);
		objErrorMessageVO.setMessage(message);
		objErrorMessageVO.setError(isError);

		releaseFileMgmtResponseVO.getErrMessageVO().add(objErrorMessageVO);
		releaseFileMgmtResponseVO.getFileMgmtResponseGridVO().add(
				fileMgmtResponseGridVO);

	}

	/**
	 * @param releaseFileMgmtResponseVO
	 * @param reqFileDetailsVOlist
	 * @param fileDetailsVOList
	 * @param infoMessage
	 * @return ReleaseFileMgmtResponseVO
	 * @throws BNPApplicationException
	 * @Description ReleaseFileMgmtResponseVO checkEligibleRecordsForRelase;
	 *              method to implement error data for the records not eligible
	 *              for Recall
	 */
	public  ReleaseFileMgmtResponseVO checkEligibleRecordsForFileMgmtAction(
			ReleaseFileMgmtResponseVO releaseFileMgmtResponseVO,
			List<FileMgmtListVO> reqFileDetailsVOlist,
			List<FileDetailsVO> fileDetailsVOList, String infoMessage)
			throws BNPApplicationException {
		int diffcnt = 0;

		if (reqFileDetailsVOlist != null) {
			if (fileDetailsVOList != null && !fileDetailsVOList.isEmpty()) {
				// Difference count to form the Error message
				diffcnt = reqFileDetailsVOlist.size()
						- fileDetailsVOList.size();
			} else {
				for (FileMgmtListVO fileMgmtVO : reqFileDetailsVOlist) {
					addReleaseFileMgmtResponseVO(fileMgmtVO.getFileName(),
							infoMessage, true, releaseFileMgmtResponseVO);
				}
				return releaseFileMgmtResponseVO;
			}
		}

		if (diffcnt > 0) {
			for (FileMgmtListVO fileMgmtVO : reqFileDetailsVOlist) {
				// comparing the pymtId in RecallVO conversion list and forming
				// the error message for the Ids that are returned in Query i.e.
				// Not eligible
				int diffcnt1 = 0;
				boolean isAvailable = false;
				for (FileDetailsVO fileDetailVo : fileDetailsVOList) {
					if (fileMgmtVO.getFileID() == (fileDetailVo.getFileId())) {
						isAvailable = true;
						break;
						// breaks when the finds the match in list. This is to
						// avoid unnecessary looping
					}
				}

				if (!isAvailable) {
					diffcnt1++;
					addReleaseFileMgmtResponseVO(fileMgmtVO.getFileName(),
							infoMessage, true, releaseFileMgmtResponseVO);

				}
				if (diffcnt == diffcnt1) {
					break;
					// breaks when all the unavailable Ids are found. This is to
					// avoid unnecessary looping
				}
			}
		}
		return releaseFileMgmtResponseVO;

	}

	/**
	 * @param user
	 * @param fileUndoRequest
	 * @return 
	 */
	public  AuditRequestVO constructAuditVo(UserInfoVO user, String fileUndoRequest) {
		AuditRequestVO auditVo = new AuditRequestVO();
		auditVo.setUserId(user.getUserId());
		auditVo.setSessionId(user.getSessionId());
		auditVo.setFuncId(fileUndoRequest);
		auditVo.setOrgId(user.getOrgId());
		return auditVo;
	}

	/**
	 * @param httpServletRequest
	 * @return
	 */
	public  UserInfoVO getUserVoFromSession(
			HttpServletRequest httpServletRequest) {
		
		HttpSession session =  httpServletRequest.getSession();
		UserInfoVO user = (UserInfoVO) session.getAttribute("userInfo");
		if(user != null) {
			user.setSessionId((String) session.getAttribute("USER_AUTH_TOKEN"));
		}
		return user;
	}

   

/**
 * @param object
 * @param message
 * @param isError
 * @param baActionsResponseVO
 */
public void addBAResponseVO(String invRefNo, String message, boolean isError,
		BuyerAcceptanceResponseVO baActionsResponseVO) {
	ErrorMessageVO objErrorMessageVO = new ErrorMessageVO();
	
	objErrorMessageVO.setUniqueID(invRefNo);
	objErrorMessageVO.setMessage(message);
	objErrorMessageVO.setError(isError);

	baActionsResponseVO.getErrMessageVO().add(objErrorMessageVO);

}

/**
 * @param validBAList
 * @param baActionsResponseVO
 * @param isError
 * @param message
 */
public void addBAResponseVOForValidRecords(List<BuyerAcceptanceVO> validBAList,
		BuyerAcceptanceResponseVO baActionsResponseVO, boolean isError,
		String message) {
	for(BuyerAcceptanceVO buyerAcceptanceVO : validBAList){
		addBAResponseVO(buyerAcceptanceVO.getInvRefNo(), message, isError, baActionsResponseVO);
	}
	
}
	/**
 	* @param Date receivedDate
 	* @return String simple date formatted string
 	*/
	public String getSimpleFormattedDateString(Date receivedDate) {
		String formattedDate = null;
		SimpleDateFormat formatter = new SimpleDateFormat(PaymentOrderConstants.DATE_FORMAT_DD_MMM_YYY);
		try {
			if(receivedDate != null){
				formattedDate = formatter.format(receivedDate);
			}
        } catch (Exception e) {
        	formattedDate = null;
        	log.error("Unable to parse received Date", e);
        }
		return formattedDate;
	}
	public  void checkEligibleRecordsForBuyerAcceptanceAction(
		BuyerAcceptanceResponseVO baActionsResponseVO,
		List<BuyerAcceptanceListVO> reqBAList,
		List<BuyerAcceptanceVO> dbBAVOList, int baRecordStatusNotMatching)
		throws BNPApplicationException {
		/*Compare screen doc& ctrl status with DB returned status, if different record not eligible for action*/
			for (BuyerAcceptanceListVO baReqVO : reqBAList) {								
				for (int i=0 ; i<dbBAVOList.size();i++) {
						if (baReqVO.getReferenceNumber().equals(dbBAVOList.get(i).getInvRefNo()) && 
								(!dbBAVOList.get(i).getCtrlStatus().equals(baReqVO.getCtrlStatus()) || !dbBAVOList.get(i).getDocStatus().equals(baReqVO.getDocStatus()))) {
								 addBAResponseVO(baReqVO.getReferenceNumber(), resourceManager.getMessage(baRecordStatusNotMatching), true, baActionsResponseVO);
								 dbBAVOList.remove(dbBAVOList.get(i));
						}
					}
					
				}
			
		}
		
	
	
}


