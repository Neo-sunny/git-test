/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Discount Request Recall Service Implementation
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 23 Feb 2018				Divyashri S										 R11.0 Sprint4 S2018X1701 
************************************************************************************************************************************************************/
package com.bnp.bnpux.discounting.serviceImpl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.common.vo.RecallResponseGridVO;
import com.bnp.bnpux.common.vo.RecallResponseVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.discounting.service.IRecallInvoicesNexUXService;
import com.bnp.bnpux.vo.errorMessageVO.ErrorMessageVO;
import com.bnp.scm.common.IResourceManager;
/*import com.bnp.scm.scheduler.service.JobHandlerService;*/
import com.bnp.scm.scheduler.util.SchedulerConstants;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.IAccessLogService;
import com.bnp.scm.services.common.cache.ICacheService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.ScreenConstants;
import com.bnp.scm.services.common.vo.AbstractVO;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.bnp.scm.services.discounting.IDiscountCalculatorService;
import com.bnp.scm.services.discounting.IDiscountProcessService;
import com.bnp.scm.services.discounting.IDiscountRequestService;
import com.bnp.scm.services.discounting.dao.IDiscountRequestDAO;
import com.bnp.scm.services.discounting.vo.DiscountRequestVO;
import com.bnp.scm.services.invoice.IRecallInvoiceService;
import com.bnp.scm.services.invoice.vo.RecallInvoiceVO;

@Component
@Scope("request")
public class RecallInvoicesNexUXServiceImpl extends AbstractServiceImpl<RecallInvoiceVO> implements IRecallInvoicesNexUXService {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The logger. */
	private static Logger LOGGER = LoggerFactory.getLogger(RecallInvoicesNexUXServiceImpl.class);
	
	/** The detail page. */
	private static String DETAIL_PAGE =  "/facelets/invoice/recallInvoiceDetail.xhtml";
	
	/** The detail page. */
	private static String SUMMARY_PAGE =  "/facelets/invoice/recallInvoiceSummary.xhtml";
	
	/** The cache service. */
	@Autowired
	private ICacheService cacheService;
	
/*	@Autowired
	JobHandlerService jobHandlerService;*/
	
	/** The recall invoice service. */
	@Autowired
	private IRecallInvoiceService recallInvoiceService;
	
	/** The discount service. */
	@Autowired
	IDiscountRequestService discountService;
	

	@Autowired
	private IDiscountRequestDAO requestDAO;
	
	@Autowired
	private IDiscountCalculatorService discountCalcService;
	
	@Autowired
	private IDiscountProcessService discountProcessService;
	
	@Autowired
	private IDiscountRequestDAO discountRequestDAO;
	
	@Autowired
	private IDiscountRequestService discountRequestService;
	
/*	@Autowired
	private ErrorMessageHelper errorMessageHelper;*/
	
	/** The resource manager. */
	@Autowired
	private IResourceManager resourceManager;
	
	/** The access log service. */
	@Autowired
	private IAccessLogService accessLogService;
	
	/** The auto suggestion map. */
	Map<String, Object> autoSuggestionMap = new HashMap<String, Object>();	
	
	/** The branch id list. */
	private List<NameValueVO> branchIdList;
	
	/** The payment staus list. */
	private List<NameValueVO> paymentStausList;
	
	/** The lot size. */
	private int lotSize;
	
	/** The page no. */
	private int pageNo;
	
	/** The is details page. */
	private boolean isDetailsPage = false;
	
	/** The dependent invoice list. */
	private List<RecallInvoiceVO> dependentInvoiceList;
	
	/** The dependent crd note list. */
	private List<RecallInvoiceVO> dependentCrdNoteList;
	
	/** The dependent crd note list. */
	private List<NameValueVO> mesagesList;
	
	/** The dependent crd note list. */
	private List<NameValueVO> auditList;
	
	/** The is has next record. */
	private boolean isHasNextRecord=false;
	
	/** The Supplier Org list. */
	private List<NameValueVO> supplierOrgIds;
	
	/** The Buyer Org list. */
	private List<NameValueVO> buyerOrgIds;
	
	/** The Action from Summary. */
	private boolean actionFromSummary=false;
	
	/** The is message pop up hidden. */
	private boolean showMessagePopUp = false;
	
	/**
	 * Gets the auto suggestion map.
	 *
	 * @return the auto suggestion map
	 */
	public Map<String, Object> getAutoSuggestionMap() {
		return autoSuggestionMap;
	}

	/**
	 * Sets the auto suggestion map.
	 *
	 * @param autoSuggestionMap the auto suggestion map
	 */
	public void setAutoSuggestionMap(Map<String, Object> autoSuggestionMap) {
		this.autoSuggestionMap = autoSuggestionMap;
	}
	
	/**
	 * Checks if is show message pop up.
	 *
	 * @return true, if is show message pop up
	 */
	public boolean isShowMessagePopUp() {
		return showMessagePopUp;
	}

	/**
	 * Sets the show message pop up.
	 *
	 * @param showMessagePopUp the new show message pop up
	 */
	public void setShowMessagePopUp(boolean showMessagePopUp) {
		this.showMessagePopUp = showMessagePopUp;
	}

	/**
	 * Validate maker checker.
	 *
	 * @param recallInvoiceVO the recall invoice vo
	 * @return true, if successful
	 */
	private boolean validateMakerChecker(RecallInvoiceVO recallInvoiceVO, UserInfoVO user){
	  return (recallInvoiceVO != null && user.getUserId().equals(recallInvoiceVO.getMakerId()));
	}
	
	/**
	 * _log time taken.
	 *
	 * @param startTime the start time
	 * @param endTime the end time
	 * @param method the method
	 */
	private void _logTimeTaken(long startTime,long endTime,String method){
	  _debugInformation("The Time taken to execute the method "+method+" is "+(endTime - startTime)/(1000000) +" Milli Seconds");
	}
	
	/**
	 * Gets the logger.
	 *
	 * @return the logger
	 */
	public Logger getLogger(){
	  return LOGGER;
	}
	
	/**
	 * _debug information.
	 *
	 * @param information the information
	 */
	public void _debugInformation(String information){
	  getLogger().debug(information);
	}
	
	/**
	 * Gets the payment staus list.
	 *
	 * @return the payment staus list
	 */
	public List<NameValueVO> getPaymentStausList() {
		return paymentStausList;
	}

	/**
	 * Sets the payment staus list.
	 *
	 * @param paymentStausList the new payment staus list
	 */
	public void setPaymentStausList(List<NameValueVO> paymentStausList) {
		this.paymentStausList = paymentStausList;
	}

	/**
	 * Gets the branch id list.
	 *
	 * @return the branch id list
	 */
	public List<NameValueVO> getBranchIdList() {
		return branchIdList;
	}

	/**
	 * Sets the branch id list.
	 *
	 * @param branchIdList the new branch id list
	 */
	public void setBranchIdList(List<NameValueVO> branchIdList) {
		this.branchIdList = branchIdList;
	}
	
	/**
	 * Gets the page no.
	 *
	 * @return the page no
	 */
	public int getPageNo() {
		return pageNo;
	}

	/**
	 * Sets the page no.
	 *
	 * @param pageNo the new page no
	 */
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}
	
	/**
	 * Gets the lot size.
	 *
	 * @return the lot size
	 */
	public int getLotSize() {
	  return lotSize;
	}

	/**
	 * Sets the lot size.
	 *
	 * @param lotSize the new lot size
	 */
	public void setLotSize(int lotSize) {
	  this.lotSize = lotSize;
	}

	/**
	 * Checks if is details page.
	 *
	 * @return true, if is details page
	 */
	public boolean isDetailsPage() {
	  return isDetailsPage;
	}

	/**
	 * Sets the details page.
	 *
	 * @param isDetailsPage the new details page
	 */
	public void setDetailsPage(boolean isDetailsPage) {
	  this.isDetailsPage = isDetailsPage;
	}

	/**
	 * Gets the dependent invoice list.
	 *
	 * @return the dependent invoice list
	 */
	public List<RecallInvoiceVO> getDependentInvoiceList() {
	  return dependentInvoiceList;
	}

	/**
	 * Sets the dependent invoice list.
	 *
	 * @param dependentInvoiceList the new dependent invoice list
	 */
	public void setDependentInvoiceList(List<RecallInvoiceVO> dependentInvoiceList) {
	  this.dependentInvoiceList = dependentInvoiceList;
	}

	/**
	 * Gets the dependent crd note list.
	 *
	 * @return the dependent crd note list
	 */
	public List<RecallInvoiceVO> getDependentCrdNoteList() {
	  return dependentCrdNoteList;
	}

	/**
	 * Sets the dependent crd note list.
	 *
	 * @param dependentCrdNoteList the new dependent crd note list
	 */
	public void setDependentCrdNoteList(List<RecallInvoiceVO> dependentCrdNoteList) {
	  this.dependentCrdNoteList = dependentCrdNoteList;
	}

	/**
	 * Gets the mesages list.
	 *
	 * @return the mesages list
	 */
	public List<NameValueVO> getMesagesList() {
		return mesagesList;
	}

	/**
	 * Sets the mesages list.
	 *
	 * @param mesagesList the new mesages list
	 */
	public void setMesagesList(List<NameValueVO> mesagesList) {
		this.mesagesList = mesagesList;
	}
	
	/**
	 * Gets the audit list.
	 *
	 * @return the audit list
	 */
	public List<NameValueVO> getAuditList() {
		return auditList;
	}

	/**
	 * Sets the audit list.
	 *
	 * @param auditList the new audit list
	 */
	public void setAuditList(List<NameValueVO> auditList) {
		this.auditList = auditList;
	}
	
	/**
	 * @return the isHasNextRecord
	 */
	public boolean isHasNextRecord() {
		return isHasNextRecord;
	}

	/**
	 * @param isHasNextRecord the isHasNextRecord to set
	 */
	public void setHasNextRecord(boolean isHasNextRecord) {
		this.isHasNextRecord = isHasNextRecord;
	}
	
	/**
	 * @return the getSupplierOrgIds
	 */
	public List<NameValueVO> getSupplierOrgIds() {
		return supplierOrgIds;
	}

	/**
	 * @param supplierOrgIds
	 */
	public void setSupplierOrgIds(List<NameValueVO> supplierOrgIds) {
		this.supplierOrgIds = supplierOrgIds;
	}

	/**
	 * @return the getBuyerOrgIds
	 */
	public List<NameValueVO> getBuyerOrgIds() {
		return buyerOrgIds;
	}

	/**
	 * @param buyerOrgIds
	 */
	public void setBuyerOrgIds(List<NameValueVO> buyerOrgIds) {
		this.buyerOrgIds = buyerOrgIds;
	}


	/**
	 * @return the actionFromSummary
	 */
	public boolean isActionFromSummary() {
		return actionFromSummary;
	}

	/**
	 * @param actionFromSummary
	 */
	public void setActionFromSummary(boolean actionFromSummary) {
		this.actionFromSummary = actionFromSummary;
	}
	
	@Override
	public void addSelectedData(){
	  _debugInformation("Entering method addSelectedData() from RecallInvoicesNexUXServiceImpl");
	  long startTime = System.nanoTime();
	  super.addSelectedData();
	  if(selectedList != null && selectedList.size() == 1 ){
	    selectedData=selectedList.get(0);
	  }
	  _logTimeTaken(startTime,(System.nanoTime()),"addSelectedData()");
	  _debugInformation("Exit of method addSelectedData() from RecallInvoicesNexUXServiceImpl");
	}
	
	@Override
	protected String getViewPage() {
	  _debugInformation("Entering method getViewPage() from RecallInvoicesNexUXServiceImpl");
	  return DETAIL_PAGE;
	}

	@Override
	protected String getSummaryPage() {
	  _debugInformation("Entering method getSummaryPage() from RecallInvoicesNexUXServiceImpl");
	  setHasNextRecord(false);
/*	  populateEntitlementDetails();*/
	  return SUMMARY_PAGE;
	}
	
	/**
	 * Checks if is concurrently accessed by process.
	 *
	 * @return true, if is concurrently accessed by process
	 */
	//JIRA - 5930 Fix  Start
	private boolean isConcurrentlyAccessedByProcess(RecallInvoiceVO currentSelectedData) {
	  boolean isConcurrentlyAccessedByProcess = false;
	  try{
	    for(RecallInvoiceVO instance : recallInvoiceService.getDependentInvoice(currentSelectedData)){
	      isConcurrentlyAccessedByProcess = recallInvoiceService.isConcurrentlyAccessedByProcess(currentSelectedData,instance);
	      if(isConcurrentlyAccessedByProcess) return isConcurrentlyAccessedByProcess;
		}
	  }catch(BNPApplicationException exception){
		getLogger().error("Exception Occured whil executing the method isConcurrentlyAccessedByProcess() :: {} ",exception);
	    return true;
	  }
	  return isConcurrentlyAccessedByProcess;
	}
	//JIRA - 5930 Fix  End
	/**
	 * Checks if is recall without approval eligible.
	 */
	private boolean isRecallWithoutApprovalEligible(UserInfoVO user){
	  boolean isRecallWithoutApprovalEligible = false;	
	  try{
	    if(BNPConstants.BUYER_ROLE.equals(user.getUserTypeId()) || BNPConstants.SUPPLIER_ROLE.equals(user.getUserTypeId())){
	      isRecallWithoutApprovalEligible = (recallInvoiceService.isRecallWithoutApproveEligible(user.getOrgId()));  
	      /**  To Be checked  **/
	    }
	  }catch (BNPApplicationException exception) {
	    getLogger().error("Exception occured while executing method isRecallWithoutApprovalEligible : {} ",exception);
		displayErrorMessage(exception.getErrorCode());
	  }
	  return isRecallWithoutApprovalEligible;
	}
	
	/**
	 * Checks if is approval allowed.
	 *
	 * @param currentUserId the current user id
	 * @param makerId the maker id
	 * @return true, if is approval allowed
	 */
	private boolean isApprovalAllowed(String currentUserId,String makerId){
	  _debugInformation("Entering method isApprovalAllowed() from RecallInvoicesNexUXServiceImpl with userid :: "+currentUserId+" Record maker Id :: "+makerId);
	  boolean isApprovalAllowed = true;
	  try {
	    String currentUserType = cacheService.getUserType(currentUserId);
		String makerIdUSerType = cacheService.getUserType(makerId);
		if(currentUserType.equals(makerIdUSerType)) {
		  isApprovalAllowed = false; 
		}else if (BNPConstants.BANKUSER_ROLE.equals(makerIdUSerType) && (BNPConstants.BUYER_ROLE.equals(currentUserType) || BNPConstants.SUPPLIER_ROLE.equals(currentUserType))){
		  isApprovalAllowed = true; 	
		}else if((BNPConstants.BUYER_ROLE.equals(makerIdUSerType) || BNPConstants.SUPPLIER_ROLE.equals(makerIdUSerType)) && (BNPConstants.BANKUSER_ROLE.equals(currentUserType))){
		  isApprovalAllowed = false; 	
		}
	  } catch (BNPApplicationException exception) {
	    getLogger().error("Exception occured whil executing method isApprovalAllowed() :: {} ",exception);
		displayErrorMessage(exception.getErrorCode());
	  }
	  return isApprovalAllowed;
	}

	/**
	 * Checks if is valid record to proceed action.
	 *
	 * @param action the action
	 * @return the string
	 */
//JIRA - 5930 Fix  Start
	public String isValidRecordToProceedAction(String action, RecallInvoiceVO currentSelectedData,UserInfoVO user){
	  _debugInformation("Entering method isValidRecordToProceedAction() from RecallInvoicesNexUXServiceImpl");
	  _debugInformation("Validating Action for the Button :: "+action);
	  String infoMesssage = BNPConstants.VALID_RECORD;
	  if(BNPConstants.ACTION_RECALL_BUTTON.equals(action)){
	    if(BNPConstants.RECALL_STATUS.equals(currentSelectedData.getPymtStatus())){
	      infoMesssage = resourceManager.getMessage(ErrorConstants.CONCURRENT_RECALL_EXCEPTION);  
		}else if(BNPConstants.PENDING_FOR_RECALL_STATUS.equals(currentSelectedData.getPymtStatus())){
		  infoMesssage= resourceManager.getMessage(ErrorConstants.CONCURRENT_PENDING_RECALL_EXCEPTION);
		}else if(isConcurrentlyAccessedByProcess(currentSelectedData)){
		  infoMesssage= resourceManager.getMessage(ErrorConstants.RECALL_CONCURRENT_PROCESS);
		}else if(isActionFromSummary() && isMaturityStatus(currentSelectedData)){
		  infoMesssage= resourceManager.getMessage(ErrorConstants.RECALL_ACTION_MAT_SETTLEMENT);
		}
	    //R11.0 Sprint4 S2018X1701 - Added condition to check whether MP record has been created
	    else if(isMaturityPaymentCreated(currentSelectedData.getPymtId())){
		  infoMesssage= resourceManager.getMessage(ErrorConstants.RECALL_ACTION_MP_CREATED);
		}
	  }else if(BNPConstants.ACTION_UNDO_BUTTON.equals(action)){
		//JIRA - 5930 Fix  -Start- modified the maker violation to come first
		if(!user.getUserId().equals(currentSelectedData.getMakerId())){
		  	  infoMesssage = resourceManager.getMessage(ErrorConstants.UNDO_MAKER_VIOLATION);
		}else if(!BNPConstants.PENDING_FOR_RECALL_STATUS.equals(currentSelectedData.getPymtStatus())){
	  	  infoMesssage = resourceManager.getMessage(ErrorConstants.PENDING_RECALL_VIOLATION);
	  	}
		//JIRA - 5930 Fix  -End
	  }else if(BNPConstants.ACTION_APPROVE_BUTTON.equals(action)){
	    if(!BNPConstants.PENDING_FOR_RECALL_STATUS.equals(currentSelectedData.getPymtStatus())){
		  infoMesssage = resourceManager.getMessage(ErrorConstants.RECALL_APPROVE_VIOLATION);
		}else if(isApprovalAllowed(user.getUserId(),currentSelectedData.getMakerId())){
		  infoMesssage = resourceManager.getMessage(ErrorConstants.RECALL_USER_VIOLATION);  
		}else if(validateMakerChecker(currentSelectedData,user)){
		  infoMesssage = resourceManager.getMessage(ErrorConstants.MAKER_APPROVAL_VIOLATION);
		}else if(isActionFromSummary() && isMaturityStatus(currentSelectedData)){
		  infoMesssage= resourceManager.getMessage(ErrorConstants.RECALL_APPROVE_ACTION_MAT_SETTLEMENT);
		}
	    //R11.0 Sprint4 S2018X1701 - Added condition to check whether MP record has been created
	  	else if(isMaturityPaymentCreated(currentSelectedData.getPymtId())){
	  	  infoMesssage= resourceManager.getMessage(ErrorConstants.RECALL_ACTION_MP_CREATED);
	  	}
	  }else if(BNPConstants.ACTION_SEARCH_BUTTON.equals(action)){
	    if(dataVO.getFileUploadFrom() != null && dataVO.getFileUploadTo() == null) {
	      infoMesssage = resourceManager.getMessage(ErrorConstants.ENTER_TODATE);
		}else if(dataVO.getFileUploadFrom() == null && dataVO.getFileUploadTo() != null){
		  infoMesssage = resourceManager.getMessage(ErrorConstants.ENTER_FROMDATE);
		}else if((dataVO.getFileUploadFrom() != null && dataVO.getFileUploadTo() != null && dataVO.getFileUploadFrom().compareTo(dataVO.getFileUploadTo()) > 0)){
		  infoMesssage = resourceManager.getMessage(ErrorConstants.FROMDATE_LESSTHAN_TODATE);
		}
		else if((dataVO.getDueDateFrom() != null && dataVO.getDueDateTo() != null && dataVO.getDueDateFrom().compareTo(dataVO.getDueDateTo()) > 0)){
		  infoMesssage = resourceManager.getMessage(ErrorConstants.INV_FROMDATE_LESSTHAN_TODATE);
		}
	  }
	  _debugInformation("Message After Validation :: "+infoMesssage);
	  _debugInformation("Exit of method isValidRecordToProceedAction() from RecallInvoicesNexUXServiceImpl");
	  return infoMesssage;
	}
//JIRA - 5930 Fix  End	
	/**
	 * Refresh threashold values.
	 *
	 * @throws BNPApplicationException the BNP application exception
	 */
	private void refreshThreasholdValues() throws BNPApplicationException {
	  _debugInformation("Entering method refreshThreasholdValues() from RecallInvoicesNexUXServiceImpl");
	  Map<String, String> threshold =  cacheService.getThresholdCache();
	  if(threshold != null && threshold.containsKey(getScreenConstant())){
	    pagThresholdValue = getSearchOrExportThresold(threshold,BNPConstants.SEARCH);
		exportThreshold = getSearchOrExportThresold(threshold,BNPConstants.EXPORT);
	  }
	  _debugInformation("Exit of method refreshThreasholdValues() from RecallInvoicesNexUXServiceImpl");
	}
	
	/**
	 * Sets the default branch ofthe user.
	 *
	 * @throws BNPApplicationException the BNP application exception
	 */
/*	private void setDefaultBranchOftheUser() throws BNPApplicationException{
	  List<NameValueVO> defaultBranch = cacheService.fetchPrimaryBranchOfUser(getUserId());
	  if(!CollectionUtils.isEmpty(defaultBranch)){
		String defaultBranchId = cacheService.fetchPrimaryBranchOfUser(getUserId()).get(0).getName();
	    dataVO.setBranchId(defaultBranchId);
	    _debugInformation("The default branch of the User :: "+getUserId()+" is :: "+defaultBranchId);
	  }
	}*/
	
	/**
	 * This Method is Intended to form the user detail Map and the amain auto suggestion Map.The User details map
	 * contains two keys and value Pairs where the first key Contains the Logged
	 * in user id and the second key contains the logged in user type. IN case
	 * of bank admin its "BA" , and buyer its "B" and Supplier its "S".The Auto Suggestion Map contains basically two lists
	 * as keys and value Pairs where BNPConstants.SUPPLIER_ORG_IDS will contains the Supplier OrganizatioN id List and 
	 * BNPConstants.BUYER_ORG_IDS key will contain the buyer organization 
	 * 
	 * @throws BNPApplicationException  
	 * 
	 */
	private void setAutoSuggestionMap(UserInfoVO user) throws BNPApplicationException {
	  _debugInformation("Entering the method setAutoSuggestionMap() from RecallInvoicesNexUXServiceImpl");
	  Map<Object, Object> userDetails = new HashMap<Object, Object>();
	  Map<String, Object> autoSuggestionMap = new HashMap<String, Object>();
	  userDetails.put(BNPConstants.USER_ID_KEY, user.getUserId());
      userDetails.put(BNPConstants.USER_TYPE_KEY, user.getUserTypeId());
      _debugInformation("The Value from the user details Map :: "+userDetails);
      _debugInformation("Setting Supplier Related Organizations in the Auto Suggestion Map");
	  if(BNPConstants.BANKADMIN.equals(user.getUserTypeId())){
	    autoSuggestionMap.put(BNPConstants.SUPPLIER_ORG_IDS, recallInvoiceService.getSupplierOrgListForBankAdmin(user.getUserId()));
	  }else if(BNPConstants.SUPPLIER.equals(user.getUserTypeId())){
	    autoSuggestionMap.put(BNPConstants.SUPPLIER_ORG_IDS, discountService.getSupplierOrgListForOrgUser(user.getUserId()));
	  }else if(BNPConstants.BUYER.equals(user.getUserTypeId())){
	    autoSuggestionMap.put(BNPConstants.SUPPLIER_ORG_IDS,discountService.getSellerOrgForBuyer(userDetails));
	  }
	  _debugInformation("Setting Buyer Related Organizations in the Auto Suggestion Map");
      if(BNPConstants.BANKADMIN.equals(user.getUserTypeId())){
        autoSuggestionMap.put(BNPConstants.BUYER_ORG_IDS, recallInvoiceService.getBuyerOrgListForBankAdmin(user.getUserId()));
      }else if(BNPConstants.SUPPLIER.equals(user.getUserTypeId())){
        autoSuggestionMap.put(BNPConstants.BUYER_ORG_IDS, discountService.getBuyerOrgListForSupplier(user.getUserId()));
	  }else if(BNPConstants.BUYER.equals(user.getUserTypeId())){
	    autoSuggestionMap.put(BNPConstants.BUYER_ORG_IDS, discountService.getBuyerOrgListForBuyer(user.getUserId()));
	  }
      setAutoSuggestionMap(autoSuggestionMap);
      _debugInformation("Exit of method setAutoSuggestionMap() from RecallInvoicesNexUXServiceImpl");
	}

	public void initInvoiceRecallDetails(UserInfoVO user){
	  _debugInformation("Entering method initInvoiceRecallDetails() from RecallInvoicesNexUXServiceImpl");
	  dataVO = new RecallInvoiceVO();
	  setPageNo(1);
	  try{
	    setBranchIdList(cacheService.getBranchNameBasedOnUser(user.getUserId()));
		setPaymentStausList(cacheService.getRecallInvoiceStatusList());
		dataVO.setCurrentUserId(user.getUserId());
		dataVO.setUserType(user.getUserTypeId());
		/*setDefaultBranchOftheUser();*/
		/*populateEntitlementDetails();*/
		setAutoSuggestionMap(user);
		//refreshThreasholdValues();
		//tableDataList = recallInvoiceService.getRecallInvoiceDetails(dataVO);
		setPageNo(1);
		isRecallWithoutApprovalEligible(user);
		setDefaultSearchCriteria();
	  }catch (BNPApplicationException exception) {
		getLogger().error("Exception occured whil executing method initInvoiceRecallDetails()");
	    displayErrorMessage(exception.getErrorCode());
	  }
	  _debugInformation("Exit of method initInvoiceRecallDetails() from RecallInvoicesNexUXServiceImpl");
	}
	
	@Override
	public void populateTableData() {
	  _debugInformation("Entering method populateTableData() from RecallInvoicesNexUXServiceImpl");
	  dataVO.setCurrentUserId(getUserId());
	  dataVO.setUserType(getUserTypeID());
	  try {
		tableDataList = recallInvoiceService.getRecallInvoiceDetails(dataVO);
	  } catch (BNPApplicationException exception) {
	    getLogger().error("Exception occured whil executing method initInvoiceRecallDetails()");
		displayErrorMessage(exception.getErrorCode());
	  }
	  setPageNo(1);
	  _debugInformation("Exit of method populateTableData() from RecallInvoicesNexUXServiceImpl");
	}
	
	/**
	 * View details from link.
	 *
	 * @return the string
	 */
//JIRA - 5930 Fix  Start Commented the method
	/*public String viewDetailsFromLink(){
	  _debugInformation("Entering method viewDetailsFromLink() from RecallInvoicesNexUXServiceImpl");
	  getSelectedList().clear();
	  setCheckAll(false);
	  setHasNextRecord(true);
	  selectedData.setRowSelected(true);
	  addSelectedData();
	  setDetailsPage(true);
	  getRecallInvoiceScreen(selectedData); 
	  enableDisableButtons(selectedData.getPymtStatus());
	  _logAccessDetails(BNPConstants.ACTION_VIEW_DETAIL_FROM_LINK,selectedData.getPymtId());
	  _debugInformation("Exit of method viewDetailsFromLink() from RecallInvoicesNexUXServiceImpl");
	  return getViewPage();
	}*/
//JIRA - 5930 Fix  End Commented the method	
	/**
	 * Gets the recall invoice screen.
	 *
	 * @param recallInvoiceVO the recall invoice vo
	 * @return the recall invoice screen
	 */
	private void getRecallInvoiceScreen(RecallInvoiceVO recallInvoiceVO) {
	  _debugInformation("Entering method getRecallInvoiceScreen() from RecallInvoicesNexUXServiceImpl");
	  try {
	    setDependentInvoiceList(recallInvoiceService.getDependentInvoice(recallInvoiceVO));
	    setDependentCrdNoteList(recallInvoiceService.getDependentCrdNote(recallInvoiceVO));
	    setAuditList(recallInvoiceService.getRecallAudutList(recallInvoiceVO));
	    //JIRA - 5930 Fix  Start
		recallInvoiceVO.setDependentInvoicesList(getDependentInvoiceList());
	    recallInvoiceVO.setDependentCreditNotesList(getDependentCrdNoteList());
	    //recallInvoiceVO.setPymtId(recallInvoiceVO.getPymtId());
	    recallInvoiceVO.setInvoiceTotalAmt(calculateTotalAmt(dependentInvoiceList,BNPConstants.SCF_INVOICE));
	    recallInvoiceVO.setCnTotalAmt(calculateTotalAmt(dependentCrdNoteList,BNPConstants.SCF_CN));
	    recallInvoiceVO.setAuditListSize(auditList.size());//R8.0 - UAT Defect Fix - CSCDEV-5725 
		//JIRA - 5930 Fix  End  
	}catch (BNPApplicationException exception) {
		getLogger().error("Exception occured whil executing method getRecallInvoiceScreen()");
	    displayErrorMessage(exception.getErrorCode());
	  }
	  _debugInformation("Exit of method getRecallInvoiceScreen() from RecallInvoicesNexUXServiceImpl");
	}
	
	
/*	@Override
	public void populateNextRecord(){
	  _debugInformation("Entering method populateNextRecord() from RecallInvoicesNexUXServiceImpl");
	  super.populateNextRecord();
	  if(selectedData != null){
	    if(selectedData.getMakerId() != null){
	      selectedData.setInitialMakerId(selectedData.getMakerId());
		}
	  selectedData.setCurrentUserId(loginBean.getUserVO().getUserId());	
	  }
	  setDetailsPage(true);
	  _debugInformation("Getting details for the Payment Id :: "+selectedData.getPymtId());
	  getRecallInvoiceScreen(selectedData);
	  _logAccessDetails(BNPConstants.ACTION_VIEW_DETAIL_BUTTON,selectedData.getPymtId());
	  populateEntitlementDetails();
	  enableDisableButtons(selectedData.getPymtStatus());
	  _debugInformation("Entering method populateNextRecord() from RecallInvoicesNexUXServiceImpl");
	}*/
	
	/**
	 * @param recallInvoiceVO
	 * @throws BNPApplicationException
	 */
	private void reveresePaidByCreditNoteRecordStatus(RecallInvoiceVO recallInvoiceVO) throws BNPApplicationException{
	  if(recallInvoiceVO!=null && recallInvoiceVO.getDependentInvoicesList()!=null){
	    for(RecallInvoiceVO individualInvoice:recallInvoiceVO.getDependentInvoicesList()){
		  if(BNPConstants.UTILIZED_WITH_LINKED_CREDIT_NOTE.equals(individualInvoice.getInvType())){
		    recallInvoiceService.reveresePaidByCreditNoteRecordStatus(individualInvoice.getDependentPaymentId());
		  }
		}
   	   }
   	 }
	
	/**
	 * Approve individual records.
	 *
	 * @return the list
	 */
//JIRA - 5930 Fix  Start
	@SuppressWarnings("unchecked")
	private List<NameValueVO> approveIndividualRecords(List<RecallResponseGridVO> recallResGridListVO, RecallInvoiceVO currentSelectedData,UserInfoVO user){
	  List<NameValueVO> messageList = new ArrayList<NameValueVO>();
	  if(currentSelectedData != null) currentSelectedData.setCreatedBy(user.getUserId());
	  String infoMesssage = BNPConstants.EMPTY;	
	  String isValidMessage = isValidRecordToProceedAction(BNPConstants.ACTION_APPROVE_BUTTON, currentSelectedData,user);
	  RecallResponseGridVO recallRespGridVO = new RecallResponseGridVO();
	  if(BNPConstants.VALID_RECORD.equalsIgnoreCase(isValidMessage)){
	    try {
	      _logAccessDetails(BNPConstants.ACTION_APPROVE_BUTTON,currentSelectedData!=null?currentSelectedData.getPymtId():null,currentSelectedData,user); // Modified null check for Sonar Fix 
	      getRecallInvoiceScreen(currentSelectedData);
	      Map<String,Object> returnMap = recallInvoiceService.approvePendingForRecallInvoices(currentSelectedData); 
	      infoMesssage = String.valueOf(returnMap.get(BNPConstants.MESSAGE_LIST_KEY));
	      List<String> paymentIdList = (List<String>) returnMap.get(BNPConstants.PAYMENT_IDS_KEY);
	      refreshOADRecordsInRecallFlow(paymentIdList,currentSelectedData!=null?currentSelectedData.getBranchId():null); // Modified for Sonar Fix
	      reveresePaidByCreditNoteRecordStatus(currentSelectedData);
	      if(currentSelectedData!=null){
	    	  messageList.add(new NameValueVO(currentSelectedData.getPaymntRefNumber(),infoMesssage,BNPConstants.SUCCESS_DATA));
	      }
		  // Concatinating line break with Payment Ref No to resolve the UI issue of aligning row with the payment ref no column when info msg returned with 3 lines.
		  String paymentRef = BNPConstants.EMPTY;
		  if(currentSelectedData!=null){
			  if(infoMesssage.split(BNPConstants.NEXT_LINE).length>2){
				  paymentRef = currentSelectedData.getPaymntRefNumber()+BNPConstants.NEXT_LINE+BNPConstants.NEXT_LINE+BNPConstants.NEXT_LINE;
			  }else if(infoMesssage.split(BNPConstants.NEXT_LINE).length==2){
				  paymentRef = currentSelectedData.getPaymntRefNumber()+BNPConstants.NEXT_LINE+BNPConstants.NEXT_LINE;
			  }
			  else{
				  paymentRef = currentSelectedData.getPaymntRefNumber();
			  }
		  }
		  addRecallResponseGridMessages(paymentRef,infoMesssage,false,recallResGridListVO);
	      
	    } catch (BNPApplicationException exception) {
	      getLogger().error("Exception occured whil executing method approveRecords() : {} ",exception);
		  displayErrorMessage(exception.getErrorCode());
		  addActionPopupRecallMessages(currentSelectedData!=null?currentSelectedData.getPaymntRefNumber():null,resourceManager.getMessage(exception.getErrorCode()),true); // Modified null check for Sonar Fix 
		  addRecallResponseGridMessages(currentSelectedData!=null?currentSelectedData.getPaymntRefNumber():null+BNPConstants.NEXT_LINE+BNPConstants.NEXT_LINE,resourceManager.getMessage(exception.getErrorCode()),true,recallResGridListVO); // Modified for Sonar Fix
	    }
	  }else{		
		String msgForGrid = getFailureMessageListForGrid(BNPConstants.RECALL_APPROVE_FAILURE_MESSAGE,isValidMessage);
		isValidMessage = getFailureMessageList(BNPConstants.RECALL_APPROVE_FAILURE_MESSAGE,isValidMessage);
	    messageList.add(new NameValueVO(currentSelectedData!=null?currentSelectedData.getPaymntRefNumber():null,isValidMessage,BNPConstants.FAILURE_DATA));// Modified null check for Sonar Fix
	    addActionPopupRecallMessages(currentSelectedData!=null?currentSelectedData.getPaymntRefNumber():null,isValidMessage,true); // Modified null check for Sonar Fix 
	    addRecallResponseGridMessages(currentSelectedData!=null?currentSelectedData.getPaymntRefNumber():null,msgForGrid,true,recallResGridListVO); // Modified null check for Sonar Fix 
	  }
	  return messageList;
	}
//JIRA - 5930 Fix  End	
	/**
	 * Approve records.
	 */
	/*public void approveRecords() {
	  _debugInformation("Entering method approveRecords() from RecallInvoicesNexUXServiceImpl");
	   setMesagesList(approveIndividualRecords());
	  _debugInformation("Exit of method approveRecords() from RecallInvoicesNexUXServiceImpl");
	}*/
	
	/**
	 * Undo individual records.
	 *
	 * @return the list
	 */
//JIRA - 5930 Fix  Start
	private List<NameValueVO> undoIndividualRecords(List<RecallResponseGridVO> recallResGridListVO, RecallInvoiceVO currentSelectedData, UserInfoVO user){
	  String infoMesssage = BNPConstants.EMPTY;
	  currentSelectedData.setCreatedBy(user.getUserId());
	  List<NameValueVO> messageList = new ArrayList<NameValueVO>();
	  String isValidMessage = isValidRecordToProceedAction(BNPConstants.ACTION_UNDO_BUTTON,currentSelectedData,user);
	  if(BNPConstants.VALID_RECORD.equalsIgnoreCase(isValidMessage)){
	    try {
	      _logAccessDetails(BNPConstants.ACTION_UNDO_BUTTON,currentSelectedData.getPymtId(), currentSelectedData, user);
		  infoMesssage = recallInvoiceService.undoPendingForRecallInvoices(currentSelectedData);
		  messageList.add(new NameValueVO(currentSelectedData.getPaymntRefNumber(),infoMesssage,BNPConstants.SUCCESS_DATA));
		  // Concatinating line break with Payment Ref No to resolve the UI issue of aligning row with the payment ref no column when info msg returned with 3 lines.
		  String paymentRef = BNPConstants.EMPTY;
		  if(infoMesssage.split(BNPConstants.NEXT_LINE).length>2){
			  paymentRef = currentSelectedData.getPaymntRefNumber()+BNPConstants.NEXT_LINE+BNPConstants.NEXT_LINE+BNPConstants.NEXT_LINE;
		  }else if(infoMesssage.split(BNPConstants.NEXT_LINE).length==2){
			  paymentRef = currentSelectedData.getPaymntRefNumber()+BNPConstants.NEXT_LINE+BNPConstants.NEXT_LINE;
		  }
		  else{
			  paymentRef = currentSelectedData.getPaymntRefNumber();
		  }
		  addRecallResponseGridMessages(paymentRef,infoMesssage,false,recallResGridListVO);
		}catch (BNPApplicationException exception) {
		  getLogger().error("Exception occured whil executing method approveRecords() : {} ",exception);
		  displayErrorMessage(exception.getErrorCode());
		  addActionPopupRecallMessages(currentSelectedData.getPaymntRefNumber(),resourceManager.getMessage(exception.getErrorCode()),true);
		  addRecallResponseGridMessages(currentSelectedData.getPaymntRefNumber()+BNPConstants.NEXT_LINE+BNPConstants.NEXT_LINE,resourceManager.getMessage(exception.getErrorCode()),true,recallResGridListVO);
		}
	  }else{		 
		String msgForGrid = getFailureMessageListForGrid(BNPConstants.RECALL_UNDO_FAILURE_MESSAGE,isValidMessage);
		isValidMessage = getFailureMessageList(BNPConstants.RECALL_UNDO_FAILURE_MESSAGE,isValidMessage); 
	    messageList.add(new NameValueVO(currentSelectedData.getPaymntRefNumber(),isValidMessage,BNPConstants.FAILURE_DATA));
	    addActionPopupRecallMessages(currentSelectedData.getPaymntRefNumber(),isValidMessage,true);
	    addRecallResponseGridMessages(currentSelectedData.getPaymntRefNumber(),msgForGrid,true,recallResGridListVO);
	  }	
	  return messageList;
	}
//JIRA - 5930 Fix  End	
	/**
	 * Undo recall.
	 */
	/*public void undoRecall(){
	  _debugInformation("Entering method undoRecall() from RecallInvoicesNexUXServiceImpl");
	   setMesagesList(undoIndividualRecords());
	  _debugInformation("Exit of method undoRecall() from RecallInvoicesNexUXServiceImpl");	
	} */
	
	/**
	 * Gets the failure message list.
	 *
	 * @param actionMessage the action message
	 * @param specificMessage the specific message
	 * @return the failure message list
	 */
	public String getFailureMessageList(String actionMessage,String specificMessage){
	  StringBuilder errorMessage = new StringBuilder();
	  errorMessage.append(actionMessage);
	  errorMessage.append(BNPConstants.FULL_STOP_DELIMITER_WITH_SPACE);
	  //errorMessage.append(BNPConstants.NEXT_LINE);
	  errorMessage.append(specificMessage);
	  return errorMessage.toString();
	}
	
	/**
	 * Gets the failure message list.
	 *
	 * @param actionMessage the action message
	 * @param specificMessage the specific message
	 * @return the failure message list
	 */
	public String getFailureMessageListForGrid(String actionMessage,String specificMessage){
	  StringBuilder errorMessage = new StringBuilder();
	  errorMessage.append(actionMessage);
	  //errorMessage.append(BNPConstants.FULL_STOP_DELIMITER_WITH_SPACE);
	  errorMessage.append(BNPConstants.NEXT_LINE);
	  errorMessage.append(specificMessage);
	  return errorMessage.toString();
	}
	
	/**
	 * Recall individual records.
	 *
	 * @return the list
	 */
//JIRA - 5930 Fix  Start
	@SuppressWarnings("unchecked")
	private List<NameValueVO> recallIndividualRecords(List<RecallResponseGridVO> recallResGridListVO, RecallInvoiceVO currentSelectedData, UserInfoVO user){
      String infoMesssage = BNPConstants.EMPTY;	
      currentSelectedData.setCreatedBy(user.getUserId());
      currentSelectedData.setMakerId(user.getUserId());
      currentSelectedData.setRecallIWthoutApproval(isRecallWithoutApprovalEligible(user));
	  List<NameValueVO> messageList = new ArrayList<NameValueVO>();
	  String isValidMessage = isValidRecordToProceedAction(BNPConstants.ACTION_RECALL_BUTTON, currentSelectedData,user);
	  if(BNPConstants.VALID_RECORD.equalsIgnoreCase((isValidMessage))){
	    try {
	      _logAccessDetails(BNPConstants.ACTION_RECALL_BUTTON,currentSelectedData.getPymtId(), currentSelectedData, user);
		  Map<String,Object> returnMap = recallInvoiceService.recallInvoice(currentSelectedData);
	      infoMesssage = String.valueOf(returnMap.get(BNPConstants.MESSAGE_LIST_KEY));
	      if(currentSelectedData.isRecallIWthoutApproval()){
	    	List<String> paymentIdList = (List<String>) returnMap.get(BNPConstants.PAYMENT_IDS_KEY);
	        refreshOADRecordsInRecallFlow(paymentIdList,currentSelectedData.getBranchId()); 
	        }
		  messageList.add(new NameValueVO(currentSelectedData.getPaymntRefNumber(),infoMesssage,BNPConstants.SUCCESS_DATA));
		  // Concatinating line break with Payment Ref No to resolve the UI issue of aligning row with the payment ref no column when info msg returned with 3 lines.
		  String paymentRef = BNPConstants.EMPTY;
		  if(infoMesssage.split(BNPConstants.NEXT_LINE).length>2){
			  paymentRef = currentSelectedData.getPaymntRefNumber()+BNPConstants.NEXT_LINE+BNPConstants.NEXT_LINE+BNPConstants.NEXT_LINE;
		  }else if(infoMesssage.split(BNPConstants.NEXT_LINE).length==2){
			  paymentRef = currentSelectedData.getPaymntRefNumber()+BNPConstants.NEXT_LINE+BNPConstants.NEXT_LINE;
		  }
		  else{
			  paymentRef = currentSelectedData.getPaymntRefNumber();
		  }
		  addRecallResponseGridMessages(paymentRef,infoMesssage,false,recallResGridListVO);
		} catch (BNPApplicationException exception) {
			
		  getLogger().error("Exception occured whil executing method recallfromdetail() : {} ",exception);
		  displayErrorMessage(exception.getErrorCode());
		  addActionPopupRecallMessages(currentSelectedData.getPaymntRefNumber(),resourceManager.getMessage(exception.getErrorCode()),true);
		  addRecallResponseGridMessages(currentSelectedData.getPaymntRefNumber()+BNPConstants.NEXT_LINE+BNPConstants.NEXT_LINE,resourceManager.getMessage(exception.getErrorCode()),true,recallResGridListVO);
		}
	  }else{
		String msgForGrid = getFailureMessageListForGrid(BNPConstants.RECALL_FAILURE_MESSAGE,isValidMessage);
		isValidMessage = getFailureMessageList(BNPConstants.RECALL_FAILURE_MESSAGE,isValidMessage);
		messageList.add(new NameValueVO(currentSelectedData.getPaymntRefNumber(),isValidMessage,BNPConstants.FAILURE_DATA));
	    addActionPopupRecallMessages(currentSelectedData.getPaymntRefNumber(),isValidMessage,true);
	    addRecallResponseGridMessages(currentSelectedData.getPaymntRefNumber(),msgForGrid,true,recallResGridListVO);
	  }	
	  return messageList;
	}
//JIRA - 5930 Fix  End	
	
	/**
	 * Recallfromdetail.
	 */
	/*public void recallfromdetail(){
	  _debugInformation("Entering method recallfromdetail() from RecallInvoicesNexUXServiceImpl");
	   setMesagesList(recallIndividualRecords());
	  _debugInformation("Exit of method recallfromdetail() from RecallInvoicesNexUXServiceImpl");
	} */
	
	/**
	 * Concurrent access.
	 *
	 * @param recallInvoiceVO the recall invoice vo
	 */
	public void concurrentAccess(RecallInvoiceVO recallInvoiceVO) {
	  int count = 0;
	  boolean concurrentAccess = false;
	  try {
	    if (recallInvoiceVO != null) {
		  count = recallInvoiceService.getConcurrentCount(recallInvoiceVO);
		  if (count > 0) concurrentAccess = true;
		}
		if (concurrentAccess) displayErrorMessage(ErrorConstants.CONCURRENT_ACCESS);
	  } catch (BNPApplicationException exception) {
	    getLogger().error("Exception in Concurrent Access :: {} " + exception);
		displayErrorMessage(exception.getErrorCode());
	  }
	  _debugInformation("Exit of method concurrentAccess() from RecallInvoicesNexUXServiceImpl");
	}
	
	@Override
	protected String getScreenConstant() {
	  _debugInformation("Entering method getScreenConstant() from RecallInvoicesNexUXServiceImpl");
	  return ScreenConstants.RECALLINVOICES;
	}

	
	/**
	 * Recall from summary.
	 */
//JIRA - 5930 Fix  Start Commented the Method
	/*public void recallfromSummary() {
	  _debugInformation("Entering Method recallfromSummary() from RecallInvoicesNexUXServiceImpl");
	  setActionFromSummary(true);
	  setMesagesList(getConsolidatedMessageList(BNPConstants.ACTION_RECALL_BUTTON));
	  setActionFromSummary(false);
	  _debugInformation("Exit of method recallfromSummary() from RecallInvoicesNexUXServiceImpl");
	}*/
//JIRA - 5930 Fix  End Commented the method
	/**
	 * Undo from summary.
	 */
//JIRA - 5930 Fix  Start Commented the Method
	/*public void undoFromSummary(){
	  _debugInformation("Entering Method undoFromSummary() from RecallInvoicesNexUXServiceImpl");
	  setActionFromSummary(true);
	  setMesagesList(getConsolidatedMessageList(BNPConstants.ACTION_UNDO_BUTTON));
	  setActionFromSummary(false);
	 _debugInformation("Exit of method undoFromSummary() from RecallInvoicesNexUXServiceImpl");
	}*/
//JIRA - 5930 Fix  End Commented the Method	
	/**
	 * Approvefrom summary.
	 */
//JIRA - 5930 Fix  Start Commented the Method
	/*public void approvefromSummary() {
	  _debugInformation("Entering into approvefromSummary recallInvoice for approve:");
	  setActionFromSummary(true);
	  setMesagesList(getConsolidatedMessageList(BNPConstants.ACTION_APPROVE_BUTTON));
	  setActionFromSummary(false);
	  _debugInformation("Exit of method undoFromSummary() from RecallInvoicesNexUXServiceImpl");
    }*/
//JIRA - 5930 Fix  End Commented the Method	
	/**
	 * Gets the consolidated message list.
	 *
	 * @param action the action
	 * @return the consolidated message list
	 */
//JIRA - 5930 Fix  Start - Also Added recallVOList as parameter
	private List<NameValueVO> getConsolidatedMessageList(String action,List<RecallResponseGridVO> recallResGridListVO, UserInfoVO userObj,List<RecallInvoiceVO> recallVOList){
	  List<NameValueVO> messageList = new ArrayList<NameValueVO>();
	  if (recallVOList != null && !recallVOList.isEmpty()) {
	    for (RecallInvoiceVO recallInvoiceVO : recallVOList) {
	    	RecallInvoiceVO currentSelectedData = new RecallInvoiceVO();
	    	currentSelectedData = recallInvoiceVO;
		  //setSelectedData(recallInvoiceVO);
		  //selectedData.setCreatedBy(getUserId());
	    	currentSelectedData.setCreatedBy(userObj.getUserId());
		  if((!BNPConstants.ACTION_APPROVE_BUTTON.equalsIgnoreCase(action)) && (!BNPConstants.ACTION_UNDO_BUTTON.equalsIgnoreCase(action))){
		    //selectedData.setMakerId(getUserId());
			  currentSelectedData.setMakerId(userObj.getUserId());
		  }
		  getRecallInvoiceScreen(currentSelectedData);
		  if(BNPConstants.ACTION_APPROVE_BUTTON.equalsIgnoreCase(action)){
		    messageList.addAll(approveIndividualRecords(recallResGridListVO,currentSelectedData,userObj));
		  }else if(BNPConstants.ACTION_UNDO_BUTTON.equalsIgnoreCase(action)){
		    messageList.addAll(undoIndividualRecords(recallResGridListVO,currentSelectedData,userObj));
		  }else if(BNPConstants.ACTION_RECALL_BUTTON.equalsIgnoreCase(action)){
		    messageList.addAll(recallIndividualRecords(recallResGridListVO,currentSelectedData,userObj));
		  }
		}
	    setShowMessagePopUp(true);
	  }
	  return messageList;
	}
//JIRA - 5930 Fix  End	
	
	/**
	 * Checks if is maturity status.
	 *
	 * @return true, if is maturity status
	 */
//JIRA - 5930 Fix  Start
	private boolean isMaturityStatus(RecallInvoiceVO currentSelectedData ){
	  boolean result = false;
	  try{
	    List<RecallInvoiceVO> dependentInvoices=recallInvoiceService.getDependentInvoice(currentSelectedData); 
		for(RecallInvoiceVO dependedntInvoice: dependentInvoices){
		  if(null == dependedntInvoice.getDependentPaymentId()){
		    dependedntInvoice.setDependentPaymentId(dependedntInvoice.getPymtId());
		  }
		  result = recallInvoiceService.isMaturityStatus(dependedntInvoice.getDependentPaymentId());
		  if(result) return result;
		}
	  }catch(BNPApplicationException exception){
	    getLogger().error("Exception occured while executing isMaturityStatus :: {} ",exception);
		displayErrorMessage(exception.getErrorCode());
	  }
	  return result;
	}
	
	/**
	 * Checks if is maturity payment created.
	 *
	 * @return true, if is maturity payment is created
	 */
	private boolean isMaturityPaymentCreated(String pymtId){
	  boolean result = false;
	  try{
		  result = recallInvoiceService.isMaturityPaymentCreated(pymtId);
	  }catch(BNPApplicationException exception){
	    getLogger().error("Exception occured while executing isMaturityPaymentCreated :: {} ",exception);
		displayErrorMessage(exception.getErrorCode());
	  }
	  return result;
	}
	
	
//JIRA - 5930 Fix  End	
	/**
	 * Enable disable buttons in the recall detail screen based on the Status of the Record and the entitlement.
	 *
	 * @param paymentStatus the payment status
	 */
	private void enableDisableButtons(String paymentStatus) {
	  _debugInformation("Entering method enableDisableButtons() from RecallInvoicesNexUXServiceImpl");
	  if(getEntitlementVO() != null) {
	    if(BNPConstants.RECALL_STATUS.equalsIgnoreCase(paymentStatus)){
	      if(!getEntitlementVO().isRecallDisabled())  getEntitlementVO().setUndoDisabled(true);
	      if(!getEntitlementVO().isApproveDisabled()) getEntitlementVO().setApproveDisabled(true);
	      if(!getEntitlementVO().isRecallDisabled())  getEntitlementVO().setRecallDisabled(true);
		}else if(BNPConstants.PENDING_FOR_RECALL_STATUS.equalsIgnoreCase(paymentStatus)){
		  if(!getEntitlementVO().isRecallDisabled())  getEntitlementVO().setUndoDisabled(false);
		  if(!getEntitlementVO().isApproveDisabled()) getEntitlementVO().setApproveDisabled(false);
		  if(!getEntitlementVO().isRecallDisabled())  getEntitlementVO().setRecallDisabled(true);  
		}else if(BNPConstants.RELEASED.equalsIgnoreCase(paymentStatus)){
		  if(!getEntitlementVO().isRecallDisabled())  getEntitlementVO().setUndoDisabled(true);
		  if(!getEntitlementVO().isApproveDisabled()) getEntitlementVO().setApproveDisabled(true);
		  if(!getEntitlementVO().isRecallDisabled())  getEntitlementVO().setRecallDisabled(false);   
		}  
	  }
	  _debugInformation("Exit of method enableDisableButtons() from RecallInvoicesNexUXServiceImpl");
	}
//JIRA - 5930 Fix  Start	
	/*@Override
	public void searchData(){
	  _debugInformation("Entering method searchData() from RecallInvoicesNexUXServiceImpl");
	  long startTime = System.nanoTime();
	  try{
		_logAccessDetails(BNPConstants.ACTION_SEARCH_BUTTON,BNPConstants.ACTION_SEARCH_BUTTON, selectedData);
	    super.initialize();
		dataVO.setCurrentUserId(getUserId());
		dataVO.setUserType(getUserTypeID());
		String infoMessage = isValidRecordToProceedAction(BNPConstants.ACTION_SEARCH_BUTTON, selectedData);
		if(BNPConstants.VALID_RECORD.equalsIgnoreCase(infoMessage)){
		  rowCount = recallInvoiceService.getRecallInvoiceDetailsCount(dataVO);
		  refreshThreasholdValues();
		 if(validatePaginationThreshold()){
		   dataVO.setEndRow(pagThresholdValue);
		 }
		 super.searchData();
		}else{
		  displayErrorMessage(infoMessage);
		}
	  }catch(BNPApplicationException exception){
		getLogger().error("Exception occured while executing the method searchData() in RecallInvoicesNexUXServiceImpl :: {} ",exception);
        displayErrorMessage(exception.getErrorCode());
      }
	  _logTimeTaken(startTime,(System.nanoTime()),"searchData()");
	  _debugInformation("Exit from method searchData() from RecallInvoicesNexUXServiceImpl");
	}	*/
//JIRA - 5930 Fix  End	
	/**
	 * Refresh OAD records in recall flow.
	 *
	 * @param paymentIds the payment identifiers
	 * @param branchId the branch identifiers
	 * @throws BNPApplicationException the BNP application exception
	 */
	private void refreshOADRecordsInRecallFlow(List<String> paymentIds,String branchId) throws BNPApplicationException {
	  _debugInformation("Entering method refreshOADRecordsInRecallFlow() from RecallInvoicesNexUXServiceImpl");
	  long startTime = System.nanoTime();
	  try{	
	    Map<String, String> inputMap = new HashMap<String, String>();
	    inputMap.put(BNPConstants.BRANCH_ID_KEY1, branchId);
	    // Initially the value for the PID was Empty. The status of the payment in the OAD table was not getting updated as the PID does not have a unique reference 
	    //so a common identifier was identified for recall flow in order to switch between PROCESSING and RELEASED status.
	    inputMap.put(SchedulerConstants.PARAM_NAME_JOB_HIST_ID,BNPConstants.RECALL_PID);
	    _debugInformation("The Values from the parameter map while entering to refresh records inputMap :: "+inputMap+ " and list of Payment ids are :: "+paymentIds);
	    for(String paymentId : paymentIds){
	      _debugInformation("Recomputation Started for the Payment Id :: "+paymentId);	
	      DiscountRequestVO discountRequestVO = recallInvoiceService.getOadRecord(paymentId);
	      if(discountRequestVO != null){
	        discountRequestVO.setDiscountDate(calculateDiscDate(discountRequestVO));
	        _debugInformation("The New Discount Date for the payemnt id :: "+paymentId+ " is :: "+discountRequestVO.getDiscountDate());
		    discountRequestVO.setTimeZoneTZ(TimeZone.getTimeZone(discountService.getSupportBranchTimeZone(branchId)));
		    _debugInformation("The TimeZone for the payemnt id :: "+paymentId+ " is :: "+discountRequestVO.getTimeZoneTZ());
		    discountRequestVO.setOadFlafg(true);
		    recallInvoiceService.refreshOADRecords(inputMap,branchId,discountRequestVO);
		    _debugInformation("Recomputation Completed for the Payment Id :: "+paymentId);
	      }
	    }
	  }catch(BNPApplicationException exception){
	   getLogger().error("Exception occured while executing the method refreshOADRecordsInRecallFlow() in RecallInvoicesNexUXServiceImpl :: {} ",exception);
	   throw exception;
	  }
	  _logTimeTaken(startTime,(System.nanoTime()),"refreshOADRecordsInRecallFlow()");
	  _debugInformation("Exit from method refreshOADRecordsInRecallFlow() from RecallInvoicesNexUXServiceImpl");
	}
	
	/*@Override
	public int getSearchDataCount(){
	  _debugInformation("Entering Method getSearchDataCount() from RecallInvoicesNexUXServiceImpl");
	  int count = 0;
	  try{
	    dataVO.setCurrentUserId(getUserId());
		dataVO.setUserType(getUserTypeID());
		count = recallInvoiceService.getRecallInvoiceDetailsCount(dataVO);
		_debugInformation("The Count retrieved from  getSearchDataCount() for the search criteria :: "+dataVO+ "  is :: "+count);
	  }catch(BNPApplicationException exception){
		getLogger().error("Exception occured whil executing the method getSearchDataCount() :: {} ",exception);
		displayErrorMessage(exception.getErrorCode());
	  }
	  _debugInformation("Exit of Method getSearchDataCount() from RecallInvoicesNexUXServiceImpl");
	  return count;
	}*/
	
	@Override
	public void getSummarySearchData(){
	  _debugInformation("Entering  Method getSummarySearchData() from RecallInvoicesNexUXServiceImpl");
	  long startTime = System.nanoTime();
	  try{
		exportList = recallInvoiceService.getRecallInvoiceDetails(dataVO);
	  }catch(BNPApplicationException exception){
		getLogger().error("Exception occured whil executing the method getSummarySearchData() :: {} ",exception);
	    displayErrorMessage(exception.getErrorCode());
	  }
	  _logTimeTaken(startTime,(System.nanoTime()),"getSummarySearchData()");
	  _debugInformation("Exit of Method getSummarySearchData() from RecallInvoicesNexUXServiceImpl");
	}	  
	
/*	@Override
	public List<String> getListToExport() {
	  _debugInformation("Entering to build data in Method getListToExport() from RecallInvoicesNexUXServiceImpl");
	  long startTime = System.nanoTime();
	  List<String> listToExport = new ArrayList<String>();
	  listToExport.add(getTableHeader(ScreenConstants.EXPORT_SUMMARY_TABLE_ID));
	  for(RecallInvoiceVO recallInvoiceVO : exportList){
	    StringBuilder builder = new StringBuilder();
	    builder.append(getStringValue(recallInvoiceVO.getBranchNameId()));
	    builder.append(getStringValue(recallInvoiceVO.getSeller()));
	    builder.append(getStringValue(recallInvoiceVO.getBuyer()));
	    builder.append(getStringValue(recallInvoiceVO.getCounterPtyErpId()));
	    builder.append(getStringValue(recallInvoiceVO.getPymtStatus()));
	    builder.append(getStringValue(recallInvoiceVO.getPaymntRefNumber()));
	    builder.append(getStringValue(recallInvoiceVO.getInvoiceNumber()));
	    builder.append(getStringValue(recallInvoiceVO.getInvoiceIssDate()));
	    builder.append(getStringValue(recallInvoiceVO.getCcy()));
	    if(recallInvoiceVO.getPymtAmount()!=null){
	    	builder.append(getStringValue(recallInvoiceVO.getPymtAmount().toPlainString()));
	    }else{
	    	builder.append(getStringValue(recallInvoiceVO.getPymtAmount()));
	    }
	    builder.append(getStringValue(recallInvoiceVO.getDueDate()));
	    builder.append(getStringValue(recallInvoiceVO.getFileUploadDate()));
	    builder.append(getStringValue(recallInvoiceVO.getFileRef()));
	    builder.append(getStringValue(recallInvoiceVO.getBuyerRef()));
	    builder.append(getStringValue(recallInvoiceVO.getSupplierRef()));
		listToExport.add(builder.toString());
	  }
	  _logAccessDetails(BNPConstants.ACTION_EXPORT,BNPConstants.ACTION_EXPORT);
	  _logTimeTaken(startTime,(System.nanoTime()),"getListToExport()");
	  _debugInformation("Exit of Method getListToExport() from RecallInvoicesNexUXServiceImpl");
	  return listToExport;
	}*/
	
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.fo.common.AbstractBean#getAutoCompleteSearchData(java.lang.String)
	 */
	protected List<NameValueVO> getAutoCompleteSearchData(String attribute) {
	  _debugInformation("Entering Method getAutoCompleteSearchData() from RecallInvoicesNexUXServiceImpl");
      List<NameValueVO> dataList = new ArrayList<NameValueVO>();
      if (attribute != null) {
        if (BNPConstants.SUPPLIER_ID_AUTO_SUG.equals(attribute)) {
    	   fetchOrganizationList(BNPConstants.SUPPLIER_ID_AUTO_SUG);
    	   dataList.addAll(getSupplierOrgIds());
    	} else if (BNPConstants.BUYER_ID_AUTO_SUG.equals(attribute)) {
    	  fetchOrganizationList(BNPConstants.BUYER_ID_AUTO_SUG);
    	  dataList.addAll(getBuyerOrgIds());
    	}
      }
      _debugInformation("Exit of Method getAutoCompleteSearchData() from RecallInvoicesNexUXServiceImpl");
      return dataList;
	}
	
	/**
	 * Set supplier and buyer organization list 
	 * @param orgType
	 */
	@SuppressWarnings("unchecked")
	private void fetchOrganizationList(String orgType) {
	  _debugInformation("Entering Method fetchOrganizationList() from RecallInvoicesNexUXServiceImpl");
	  if(BNPConstants.SUPPLIER_ID_AUTO_SUG.equals(orgType) && supplierOrgIds == null && getAutoSuggestionMap() != null && getAutoSuggestionMap().containsKey(BNPConstants.SUPPLIER_ORG_IDS)){
	    setSupplierOrgIds((List<NameValueVO>) getAutoSuggestionMap().get(BNPConstants.SUPPLIER_ORG_IDS));
      }else if(BNPConstants.BUYER_ID_AUTO_SUG.equals(orgType) && buyerOrgIds == null && getAutoSuggestionMap() != null && getAutoSuggestionMap().containsKey(BNPConstants.BUYER_ORG_IDS)){
        setBuyerOrgIds((List<NameValueVO>) getAutoSuggestionMap().get(BNPConstants.BUYER_ORG_IDS));
      }
	  _debugInformation("Exit of Method fetchOrganizationList() from RecallInvoicesNexUXServiceImpl");
	}

    
    /**
     * Set Default Value for the Search Field
     */
    public void setDefaultSearchCriteria() {
      _debugInformation("Entering Method setDefaultSearchCriteria() from RecallInvoicesNexUXServiceImpl");
	  dataVO.setCounterPtyErpId(BNPConstants.DEFAULT_SEARCH_VALUE);
	  dataVO.setPaymntRefNumber(BNPConstants.DEFAULT_SEARCH_VALUE);
	  dataVO.setInvoiceNumber(BNPConstants.DEFAULT_SEARCH_VALUE);
	  dataVO.setFileRef(BNPConstants.DEFAULT_SEARCH_VALUE);
	  dataVO.setBuyerRef(BNPConstants.DEFAULT_SEARCH_VALUE);
	  dataVO.setSupplierRef(BNPConstants.DEFAULT_SEARCH_VALUE);
	  dataVO.setPymtStatus(BNPConstants.ALL);
	  _debugInformation("Exit of Method setDefaultSearchCriteria() from RecallInvoicesNexUXServiceImpl");
	}
	
    
    /**
     * This is is used to calculate total amount for dependent invoice and credit note.
     *
     * @param inputList the input list
     * @param type the type
     * @return the big decimal
     */
    private BigDecimal calculateTotalAmt(List<RecallInvoiceVO> inputList, String type){
      _debugInformation("Entering Method calculateTotalAmt() from RecallInvoicesNexUXServiceImpl");
      _debugInformation("The recall Invoices ist from calculateTotalAmt() Method is "+inputList+ " of type "+type);
	  BigDecimal totalAmount = new BigDecimal(0);
	  if(BNPConstants.SCF_INVOICE.equals(type)){
	    for(RecallInvoiceVO reInvoiceVO:inputList){
		  if(reInvoiceVO.getInvAmount().compareTo(BigDecimal.ZERO) > 0) totalAmount = totalAmount.add(reInvoiceVO.getInvAmount());
		}
	  }else if(BNPConstants.SCF_CN.equals(type)){
	    for(RecallInvoiceVO reInvoiceVO:inputList){
		  if(reInvoiceVO.getUtilzAmount().compareTo(BigDecimal.ZERO) > 0) totalAmount = totalAmount.add(reInvoiceVO.getUtilzAmount());
		}
	  }
	  _debugInformation("The Total Calculated Amount from the type : "+type+ "is :: "+totalAmount);
	  _debugInformation("Exit of Method calculateTotalAmt() from RecallInvoicesNexUXServiceImpl");
	  return totalAmount;
	}
    
    /**
     * This method is used to refresh the status of the record.
     */
//JIRA - 5930 Fix  Start Commented the Method
    /*public void refreshDetailData() {
      _debugInformation("Entering Method refreshDetailData() from RecallInvoicesNexUXServiceImpl");
	  try {
	    selectedData.setPymtStatus(null);
	  	selectedData.setInvoiceIssDate(null);
		selectedData.setBranchId(null);
		selectedData.setBuyerRef(null);
		selectedData.setSupplierRef(null);
		selectedData.setCounterPtyErpId(null);
		/* * is replaced with % against Invoice Ref no for Multi Select*/
		/*if(selectedData.getInvoiceNumber().equals(BNPConstants.DEPT_ALLOC_CONSTANT)){
			selectedData.setInvoiceNumber(BNPConstants.DEFAULT_SEARCH_VALUE);
		}
		selectedData = recallInvoiceService.refreshRecallInvoiceDetails(selectedData);
		getRecallInvoiceScreen(selectedData);//R8.0 - UAT Defect Fix - CSCDEV-5725 
		_debugInformation("The Record refreshed from the database :: "+selectedData);
	  }catch (BNPApplicationException exception) {
	    getLogger().error("Exception occured whil executing method refreshDetailData() : {} ",exception);
		displayErrorMessage(exception.getErrorCode());
	  }
	  _debugInformation("Exit of Method refreshDetailData() from RecallInvoicesNexUXServiceImpl");
	}*/
//JIRA - 5930 Fix  End Commented the Method    
    /**
     * Sets the access log details.
     *
     * @param actionName the action name
     * @param referenceKey the reference key
     * @throws BNPApplicationException the BNP application exception
     */
//JIRA - 5930 Fix  Start
    private void _logAccessDetails(String actionName,String referenceKey, RecallInvoiceVO currentSelectedData, UserInfoVO user) {
/*	  HttpServletRequest request= (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
	  HttpSession session=request.getSession(false);*/
	  AbstractVO abstractInstance = new AbstractVO();
	  abstractInstance.setCurrentUserId(user.getUserId());
	  /*abstractInstance.setSessionId(session.getId());*/
	  StringBuilder _searchInformation = new StringBuilder();
	  /*_searchInformation.append(extractSystemLevelInformation(request));*/
	  if((BNPConstants.ACTION_SEARCH_BUTTON.equals(actionName) || BNPConstants.ACTION_EXPORT.equals(actionName)) && dataVO != null){
	    _searchInformation.append(dataVO.toString());
	  }else if(!BNPConstants.ACTION_SEARCH_BUTTON.equals(actionName) && currentSelectedData != null){
	    _searchInformation.append(currentSelectedData.toString());
	  }
	  abstractInstance.setModifiedData(_searchInformation.toString());
	  abstractInstance.setCheckPoint(actionName);
	  abstractInstance.setScreenId(getScreenConstant());
	  abstractInstance.setAccessLogRefNo(referenceKey);
	  try {
		insertAccessLog(abstractInstance);
	  } catch (BNPApplicationException exception) {
	    getLogger().error("Exception occured whil executing method _logAccessDetails() : {} ",exception);
	  }
	}
//JIRA - 5930 Fix  End	
	/**
	 * Insert access log details.
	 *
	 * @param abstractVO the abstract vo
	 * @throws BNPApplicationException the BNP application exception
	 */
	private void insertAccessLog(AbstractVO abstractVO)throws BNPApplicationException {
	  accessLogService.insertAccessLog(abstractVO);
	}
	
	public Date calculateDiscDate(DiscountRequestVO discountRequestVO) throws BNPApplicationException{
		Date discDate = null;
		//861827 CSCDEV-6584 06012016 start
		Map<String, Map<Object, Object>> branchDiscMap = new HashMap<String, Map<Object,Object>>();
		Map<Object, Object> branchDisc = null;
		boolean validateCutOff;
		//branchDisc = branchDiscMap.get(keyBuilder);
		branchDisc = branchDiscMap.get(discountRequestVO.getSupportBranchId() + discountRequestVO.getPaymentCurrencyCode() + discountRequestVO.getRateType());
		if(branchDisc == null) {
			branchDisc = discountRequestDAO.getBranchDiscDefinitions(discountRequestVO);
			if(branchDisc == null) {
				throw new BNPApplicationException(ErrorConstants.BRANCH_DISC_DOESNOT_EXIST);
			}
			//branchDiscMap.put(keyBuilder, branchDisc);
			branchDiscMap.put(discountRequestVO.getSupportBranchId() + discountRequestVO.getPaymentCurrencyCode() + discountRequestVO.getRateType(), branchDisc);
		}
		//861827 CSCDEV-6584 06012016 end
			Map<String, Map<Object, Object>> buyerAcctMap = new HashMap<String, Map<Object,Object>>();
			discountCalcService.populateBuyerAccountDetails(discountRequestVO, buyerAcctMap);
		discountRequestVO.setCddDetailsMap(requestDAO.getCDDdetails(discountRequestVO.getPaymtId()));
		Map<String, Map<String,Object>> validateLeadDaysMap = new HashMap<String, Map<String,Object>>();
		discountCalcService.validateLeadDaysForSysDate(discountRequestVO, validateLeadDaysMap);
		discountRequestVO.getCddDetailsMap().put("SYS_DISC_DATE",discountRequestVO.getSystemDate());
		discountRequestVO.setDiscDateManualFlg(true);
		discDate=discountProcessService.calculateDiscountDate(discountRequestVO,discountRequestVO.getFileId());
		//861827 CSCDEV-6584 06012016 start
		discountRequestVO.setExtCutoffTime(String.valueOf(branchDisc.get("DISC_REQ_EXT_CUTTOFF")));
		validateCutOff = discountService.validateCutOffTime(discountRequestVO, discountRequestVO.getRateType()); 
		if (validateCutOff) {
			discDate=discountService.getNextBusinessDay(discountRequestVO, 1);	
		}
		//861827 CSCDEV-6584 06012016 end
		
		discountRequestVO.setDiscDateManualFlg(false);
		return discDate;
	}
	
	/* Recall Response Vo */
	private RecallResponseVO recallResponseVO;
	
	
	/* Recall Response Grid Vo */
	//private List<RecallResponseGridVO> recallResGridListVO;
	
	/**
	 * Recall from NewUX.
	 */
	public RecallResponseVO recallfromNewUX(List<RecallInvoiceVO> recallVOList, UserInfoVO user) {
	  _debugInformation("Entering Method recallfromNewUX() from RecallInvoicesNexUXServiceImpl");
	  //JIRA - 5930 Fix  Start
	  List<RecallResponseGridVO> recallResGridListVO = new ArrayList<RecallResponseGridVO>(); 
	  //JIRA - 5930 Fix  End
	  initializeRecallVariables();
	  selectedList=recallVOList;	  
	  setUserId(user.getUserId());
	  setUserTypeID(user.getUserTypeId());
	  initInvoiceRecallDetails(user);
	  //JIRA - 5930 Fix  Start - Also Added recallVOList as parameter
	  setMesagesList(getConsolidatedMessageList(BNPConstants.ACTION_RECALL_BUTTON,recallResGridListVO,user,recallVOList));
	  //JIRA - 5930 Fix  End
	  //clearDataList();
	  _debugInformation("Exit of method recallfromNewUX() from RecallInvoicesNexUXServiceImpl");
	  recallResponseVO.setRecallResponseGridVO(recallResGridListVO);
	  recallResponseVO.seterrMessageVO( errorMessageHelper.getErrorMessageVOList());
      return recallResponseVO;
	}
	
	/**
	 * Approvefrom NewUX.
	 */
	public RecallResponseVO approvefromNewUX(List<RecallInvoiceVO> recallVOList, UserInfoVO user) {
	  _debugInformation("Entering into approvefromNewUX recallInvoice for approve:");
	  //JIRA - 5930 Fix  Start
      List<RecallResponseGridVO> recallResGridListVO = new ArrayList<RecallResponseGridVO>();
	  //JIRA - 5930 Fix  End
      initializeRecallVariables();
	  selectedList=recallVOList;	  
	  setUserId(user.getUserId());
	  setUserTypeID(user.getUserTypeId());
	  initInvoiceRecallDetails(user);
      //JIRA - 5930 Fix  Start - Also Added recallVOList as parameter
	  setMesagesList(getConsolidatedMessageList(BNPConstants.ACTION_APPROVE_BUTTON,recallResGridListVO,user,recallVOList));
	  //JIRA - 5930 Fix  End
	  //clearDataList();
	  _debugInformation("Exit of method approvefromNewUX() from RecallInvoicesNexUXServiceImpl");
	  recallResponseVO.setRecallResponseGridVO(recallResGridListVO);
	  recallResponseVO.seterrMessageVO( errorMessageHelper.getErrorMessageVOList());
      return recallResponseVO;
    }
	
	/**
	 * Undo from NewUX.
	 */
	public RecallResponseVO undofromNewUX(List<RecallInvoiceVO> recallVOList, UserInfoVO user){
	  _debugInformation("Entering Method undoFromNewUX() from RecallInvoicesNexUXServiceImpl");
	  //JIRA - 5930 Fix  Start
      List<RecallResponseGridVO> recallResGridListVO = new ArrayList<RecallResponseGridVO>();
	  //JIRA - 5930 Fix  End
      initializeRecallVariables();
	  selectedList=recallVOList;	  
	  setUserId(user.getUserId());
	  setUserTypeID(user.getUserTypeId());
	  initInvoiceRecallDetails(user);
	  //JIRA - 5930 Fix  Start - Also Added recallVOList as parameter
      setMesagesList(getConsolidatedMessageList(BNPConstants.ACTION_UNDO_BUTTON,recallResGridListVO,user,recallVOList));
	  //JIRA - 5930 Fix  End
	  //clearDataList();
	  _debugInformation("Exit of method undoFromNewUX() from RecallInvoicesNexUXServiceImpl");
	  recallResponseVO.setRecallResponseGridVO(recallResGridListVO);
	  recallResponseVO.seterrMessageVO( errorMessageHelper.getErrorMessageVOList());
      return recallResponseVO;
	}
	

	
	 /**
     * Sets the access log details.
     *
     * @param actionName the action name
     * @param referenceKey the reference key
     * @throws BNPApplicationException the BNP application exception
     */
//JIRA - 5930 Fix  Start Commented the Method
    /*private void _logAccessDetails(String actionName,String referenceKey,UserInfoVO uservo) {
	  HttpServletRequest request= (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
	  HttpSession session=request.getSession(false);
	  AbstractVO abstractInstance = new AbstractVO();
	  abstractInstance.setCurrentUserId(uservo.getUserId());
	  abstractInstance.setSessionId(uservo.getSessionId());
	  abstractInstance.setCheckPoint(propertyLoader.getValue(actionName));
	  abstractInstance.setSessionId(session.getId());
	  StringBuilder _searchInformation = new StringBuilder();
	  _searchInformation.append(extractSystemLevelInformation(request));
	  if((BNPConstants.ACTION_SEARCH_BUTTON.equals(actionName) || BNPConstants.ACTION_EXPORT.equals(actionName)) && dataVO != null){
	    _searchInformation.append(dataVO.toString());
	  }else if(!BNPConstants.ACTION_SEARCH_BUTTON.equals(actionName) && selectedData != null){
	    _searchInformation.append(selectedData.toString());
	  }
	  //abstractInstance.setModifiedData(_searchInformation.toString());
	  abstractInstance.setModifiedData(selectedData.toString());
	  abstractInstance.setCheckPoint(actionName);
	  abstractInstance.setScreenId(getScreenConstant());
	  abstractInstance.setAccessLogRefNo(referenceKey);
	  try {
		insertAccessLog(abstractInstance);
	  } catch (BNPApplicationException exception) {
	    getLogger().error("Exception occured whil executing method _logAccessDetails() : {} ",exception);
	  }
	}*/
//JIRA - 5930 Fix  End Commented the Method    
	private void initializeRecallVariables(){
		  recallResponseVO = new RecallResponseVO();
		  /*recallResGridListVO  = new ArrayList<RecallResponseGridVO>();;*/
		  errorMessageHelper.setErrorMessageVOList(new ArrayList<ErrorMessageVO>());
	}
	
	private void addRecallResponseGridMessages(String paymntRefNumber, String message,boolean isError, List<RecallResponseGridVO> recallResGridListVO){
		 RecallResponseGridVO objRecallResponseGridVO = new RecallResponseGridVO();
		 objRecallResponseGridVO.setPaymntRefNumber(paymntRefNumber);
		 objRecallResponseGridVO.setMessage(message);
		 objRecallResponseGridVO.setError(isError);
		 recallResGridListVO.add(objRecallResponseGridVO);
		
	}
	
	protected void addActionPopupRecallMessages(String uniqueID, String message, boolean error){
		 ErrorMessageVO objErrorMessageVO  = new ErrorMessageVO();
	     objErrorMessageVO.setUniqueID(uniqueID);
	     objErrorMessageVO.setMessage(message);
	     objErrorMessageVO.setError(error);
	     errorMessageHelper.getErrorMessageVOList().add(objErrorMessageVO);
		
	}



}
