/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Settlement Constants
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.constants;

public interface SettlementConstants {

	public final static String SETTLEMENT_ORDER_USER_ID = "userId";
	
	public final static String SETTLEMENT_ORDER_USER_TYPE_ID = "userTypeId";
	
	public final static String RECORD_FROM = "recordFrom";
	
	public final static String RECORD_TO = "recordTo";
	
	public final static String MATURITY_FILTER = "maturityFilter";
	
	public final static String ADVANCE_FILTER = "advanceFilter";

	public static final String SETTLEMENT_ORDER_SUMMARY = "settlementdetails";

	public static final String SETTLEMENT_ORDER_UNABLE_TO_GET_DETAILS = "Unable to get the settlement Order Details";

	public static final String SETTLEMENT_ORDER_ERROR_FLAG = "errorFlag";

	public static final String SETTLEMENT_ORDER_ERROR_DETAILS = "Database Error Flag : ";

	public static final String SETTLEMENT_ORDER_LIST = "settlementOrderList";
	
	public static final String SETTLEMENT_ORDER_LIST_DETAILS = "settlementListDetails";

	public static final String GROUP_INT = "groupInd";

	public static final String DUE_DATE = "dueDate";

	public static final String VIEW_TYPE = "viewType";

	public static final String VIEW_TYPE_SETTLEMENT = "SETTLEMENT";

	public static final String VIEW_TYPE_MATURITY = "MATURITY";
	
	public static final String VIEW_TYPE_SETTLEMENT_LIST = "SETTLEMENT_LIST";
	
	public static final String VIEW_TYPE_SETTLEMENT_LIST_DETAILS = "SETTLEMENT_LIST_DETAILS";
	
	public static final String BUYER_ORG_ID = "buyerOrgId";
	
	public static final String SUPPLIER_ORG_ID = "supplierOrgId";
	
	public static final String CURRENCY_CODE = "currencyCode";

	public static final String PAYMENT_UNIQUE_REFERNCE_ID = "paymentRefNumberUnique";
	
	public static final String SETTLEMENT_ORDER_EXCEPTION = "Unexpected Database Error ";

	public static final String EXCEPTION_UNABLE_TO_PROCESS = "Unable to Get Settlement Order Details - Database Exception";
	
	public static final String EXCEPTION_UNABLE_TO_PROCESS_PO_CALLOUT = "Unable to Get Settlement Order Callout Details - Database Exception";

	public static final String DISC_REQ_NO = "discRefNo";
	
	public static final String SETTLEMENT_ORDERDISC_REQUEST_REST_GET_SETTLEMENTORDER = "putDiscRequestdetails.rest";
	public static final String AVLBLE_AMT_GRTR_ZERO = "Available Amount should be greater than zero";
	
	public static final String AVLBLE_AMT_LSR_DISC_AMT = "Available Amount should be less than Discount Amount";
	
	public static final String LEAD_ORG_ID = "leadOrgId";
	
	public static final String ORG_ID = "orgId";

	public static final String SETTLEMENT_ORDER_REST_GET_PO_CREDITNOTE_LINE_ITEM ="getSettlementOrderCreditNoteLineItemdetails.rest";
	
	public static final String SETTLEMENT_ORDER_REST_GET_PO_ORDER_INVOICE_DETAILS_CALLOUT="getSettlementOrderInvoiceDetails.rest";

	public static final String SETTLEMENT_ORDER_INVOICE_DETAILS_AVAILABLE_AMT_CALL_OUT ="getSettlementOrderAvlbleAmtCallOut.rest";
	
	public static final String 	SETTLEMENT_ORDER_REST_GET_ATTACHMENT = "getSettlementOrderdAttchdetails.rest";
	
	public static final String FILTER_STATUS = "filterStatus";
	public static final String FILTER_PERIOD = "filterPeriod";
	public static final String FILTER_BRANCH = "filterBranch";
	
	public static final String QUICK_SEARCH = "quickSearchText";
	
	public final static String SETTLEMENT_ORDER_CREDIT_NOTE_LINE_ITEM_ID = "cnt_id";
	
	public static final String SETTLEMENT_ORDER_CREDIT_NOTE_LINE_ITEM_SUMMARY = "result_set";
	
	public static final String SETTLEMENT_ORDER_CREDIT_NOTE_LINE_ITEM_ERROR_FLAG =  "error_result";
	
	public static final String SETTLEMENT_ORDER_CREDIT_NOTE_LINE_ITEM_EROR_MSG = "error_msg"; 
	
	public static final String SETTLEMENT_ORDER_INVOICE_DETAILS_CALL_OUT_INV_ID = "inv_id";
	
	public static final String SETTLEMENT_ORDER_INVOICE_DETAILS_CALL_OUT_SUMMARY = "result_set";
	
	public static final String SETTLEMENT_ORDER_ERROR_MSG = "error_msg";
	
	public static final String SETTLEMENT_ORDER_PAYMENT_REF_NO ="payment_ref_no";
	public static final String SETTLEMENT_ORDER_ORD_ID ="org_id";
	public static final String SETTLEMENT_ORDER_PAYMENT_REF_UNIQUE="payment_ref_no_unique";
	public static final String  SETTLEMENT_ORDER_ALREADY_SETT_FLG="alreadySettFlg";
	public static final String SETTLEMENT_ORDER_POPOVER_DETAILS= "result_set";
	public static final String EXCEPTION_UNABLE_TO_PROCESS_REQUEST = "Unable to Get the Details - Database Exception";
	public static final String SETTLEMENT_ORDER_DISCOUNT_TYPE ="disc_type";

	/* Added below constants to identify Settlement Callouts*/
	public static final String SETTLEMENT_CALLOUT_FLAG_ALREADYSETTLED = "ALREADYSETTLED";

	public static final String SETTLEMENT_CALLOUT_FLAG_INPROCESS = "INPROCESS";
	

}
