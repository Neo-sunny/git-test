/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   13 July 2017
 * 
 * Purpose:      Credit Note Inquiry Report Service Implementation
 * 
 * Change History:
 *  
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 13 July 2017       Jaimal Singh, Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.constants;

public interface PaymentReportConstants {
	
    public static final String VIEW_TYPE = "viewType";
    
    public static final String PAYMENT_REPORT_SUMMARY = "SUMMARY";
	
	public static final String PAYMENT_REPORT_LIST = "paymentReportList";
	
	public static final String PAYMENT_REPORT_LIST_DETAILS = "paymentReportListDetails";
	

}
