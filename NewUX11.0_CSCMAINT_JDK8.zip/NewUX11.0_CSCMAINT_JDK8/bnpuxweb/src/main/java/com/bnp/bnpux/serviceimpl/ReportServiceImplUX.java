/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     Report Service Implementation
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 
 *****************************************************************************************************************************************************************/
package com.bnp.bnpux.serviceimpl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.constants.ReportsConstant;
import com.bnp.bnpux.dao.IReportDAO;
import com.bnp.bnpux.service.IReportService;
import com.bnp.bnpux.vo.requestVO.ReportRequestVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;
import com.bnp.bnpux.vo.responseVO.ReportResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@Component
public class ReportServiceImplUX implements IReportService{

	/**
	 * Logger log for ReportServiceImpl class
	 */
	public static final Logger log = LoggerFactory.getLogger(ReportServiceImplUX.class);
	
	/**
	 * IReportDAO settlemntDAO;
	 */
	@Autowired
	private IReportDAO settlementDAO;

	/**
	 * This method is for getting Report details
	 * 
	 * @param ReportRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public ReportResponseVO getReportDetails(ReportRequestVO ReportRequestVO)
			throws BNPApplicationException {
		// TODO Auto-generated method stub
		String errorFlag = null;	
		ReportResponseVO reportResponseVO = new ReportResponseVO();
		try{
			Map<String,Object> reportMap = new HashMap<String, Object>();		
			List<ReportResponseVO> reportResponseVOlist = new ArrayList<ReportResponseVO>();
			reportMap.put(ReportsConstant.REPORT_ORDER_USER_ID, ReportRequestVO.getUserId());
			reportMap.put(ReportsConstant.REPORT_ORDER_USER_TYPE_ID, ReportRequestVO.getUserType());
			reportMap.put(ReportsConstant.REPORT_ORDER_ORG_ID, ReportRequestVO.getOrgId());
			reportMap.put(ReportsConstant.REPORT_ORDER_COUNTER_PTY_ID, ReportRequestVO.getCounterPtyId());
			reportMap.put(ReportsConstant.REPORT_ORDER_CURRENCY_CODE, ReportRequestVO.getCurrencyCode());
			if(ReportRequestVO.getUploadFromDate()!=null){
				reportMap.put(ReportsConstant.REPORT_ORDER_UPLOAD_FROM_DATE, DateUtils.truncate(ReportRequestVO.getUploadFromDate(), Calendar.DATE));
			}else{
				reportMap.put(ReportsConstant.REPORT_ORDER_UPLOAD_FROM_DATE, null);
			}
			if(ReportRequestVO.getUploadToDate()!=null){
				reportMap.put(ReportsConstant.REPORT_ORDER_UPLOAD_TO_DATE, DateUtils.truncate(ReportRequestVO.getUploadToDate(), Calendar.DATE));
			}else{
				reportMap.put(ReportsConstant.REPORT_ORDER_UPLOAD_TO_DATE, null);
			}
			
			reportMap.put(ReportsConstant.REPORT_ORDER_FILE_STATUS, ReportRequestVO.getFileStatus());
			reportMap.put(ReportsConstant.REPORT_ORDER_FILE_PERIOD, ReportRequestVO.getFilePeriod());
			reportMap.put(ReportsConstant.REPORT_ORDER_FILE_BRANCH, ReportRequestVO.getFileBranch());
			reportMap.put(ReportsConstant.REPORT_ORDER_STATUS, ReportRequestVO.getStatus());
			reportMap.put(ReportsConstant.REPORT_ORDER_GET_WHAT, ReportRequestVO.getGetWhat());
			reportMap.put("exportType","");
			
			
			
		    settlementDAO.getReportSummary(reportMap);
		    reportResponseVOlist = (List<ReportResponseVO>) reportMap.get(ReportsConstant.REPORT_ORDER_LIST_DETAILS);
			if(reportResponseVOlist != null){
				reportResponseVO.setReportResponseVOlist(reportResponseVOlist);
				//Added for the chart implementation :start
				/*List<ReportChartResponseVO> reportChartVOList = new ArrayList<ReportChartResponseVO>();
				reportChartVOList = getReportChartAxis(ReportRequestVO);
				reportResponseVO.setReportChartResponseVOlist(reportChartVOList);*/
				//Added for the chart implementation :ends
			}else{
				errorFlag = (String) reportMap.get(ReportsConstant.SETTLEMENT_ORDER_ERROR_FLAG);
				if(errorFlag != null){				
					log.error(ReportsConstant.SETTLEMENT_ORDER_ERROR_FLAG + errorFlag);
				}
			}
		}catch(Exception exception){
			log.error(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS);
		}
		return reportResponseVO;
	}
	
	/**
	 * This method is for getting Report list
	 * 
	 * @param ReportRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public ReportResponseVO getReporList(ReportRequestVO ReportRequestVO)
			throws BNPApplicationException {
		// TODO Auto-generated method stub
		String errorFlag = null;	
		ReportResponseVO reportResponseVO = new ReportResponseVO();
		try{
			Map<String,Object> reportMap = new HashMap<String, Object>();		
			List<ReportResponseVO> reportResponseVOlist = new ArrayList<ReportResponseVO>();
			reportMap.put(ReportsConstant.REPORT_ORDER_FILE_ID, ReportRequestVO.getFileID());
			reportMap.put(ReportsConstant.REPORT_ORDER_STATUS, ReportRequestVO.getStatus());
			reportMap.put(ReportsConstant.SETTLEMENT_ORDER_ERROR_FLAG, ReportRequestVO.getUserId());
			
			settlementDAO.getReporList(reportMap);
			reportResponseVOlist = (List<ReportResponseVO>) reportMap.get(ReportsConstant.REPORT_ORDER_LIST_DETAILS_LIST);
			if(reportResponseVOlist != null){
				reportResponseVO.setReportResponseVOlist(reportResponseVOlist);
			}else{
				errorFlag = (String) reportMap.get(ReportsConstant.SETTLEMENT_ORDER_ERROR_FLAG);
				if(errorFlag != null){				
					log.error(ReportsConstant.SETTLEMENT_ORDER_ERROR_FLAG + errorFlag);
				}
			}
		}catch(Exception e){
			log.error(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS, e);
			throw new BNPApplicationException(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS);
		}
		return reportResponseVO;
		}

	/**
	 * This method is for getting report chart axis 
	 * 
	 * @param requestVo
	 * @return
	 * @throws BNPApplicationException
	 */
	public List<ReportChartResponseVO> getReportChartAxis (ReportRequestVO requestVo)throws BNPApplicationException {
		List<ReportChartResponseVO> reportVOList = new ArrayList<ReportChartResponseVO>();
		try{
			Map<String,Object> reportListMap = new HashMap<String, Object>();
		reportListMap.put(ReportsConstant.REPORT_ORDER_USER_ID, requestVo.getUserId());
		reportListMap.put(ReportsConstant.REPORT_ORDER_USER_TYPE_ID, requestVo.getUserType());
		
		if(requestVo.getOrgId()==null || requestVo.getOrgId().trim()==""){
			reportListMap.put(ReportsConstant.REPORT_ORDER_ORG_ID, "");
		}else{
			reportListMap.put(ReportsConstant.REPORT_ORDER_ORG_ID, requestVo.getOrgId());
		}
		if(requestVo.getCounterPtyId()==null || requestVo.getCounterPtyId().trim()==""){
			reportListMap.put(ReportsConstant.REPORT_ORDER_COUNTER_PTY_ID, "");
		}else{
			reportListMap.put(ReportsConstant.REPORT_ORDER_COUNTER_PTY_ID, requestVo.getCounterPtyId());
		}
		if(requestVo.getCurrencyCode()==null || requestVo.getCurrencyCode().trim()==""){
			reportListMap.put(ReportsConstant.REPORT_ORDER_CURRENCY_CODE, "");
		}else{
			reportListMap.put(ReportsConstant.REPORT_ORDER_CURRENCY_CODE, requestVo.getCurrencyCode());
		}
		if(requestVo.getUploadFromDate()==null){
			reportListMap.put(ReportsConstant.REPORT_ORDER_UPLOAD_FROM_DATE, null);
		}else{
			reportListMap.put(ReportsConstant.REPORT_ORDER_UPLOAD_FROM_DATE, DateUtils.truncate(requestVo.getUploadFromDate(), Calendar.DATE));
		}
		if(requestVo.getUploadToDate()==null ){
			reportListMap.put(ReportsConstant.REPORT_ORDER_UPLOAD_TO_DATE,null);
		}else{
			reportListMap.put(ReportsConstant.REPORT_ORDER_UPLOAD_TO_DATE, DateUtils.truncate(requestVo.getUploadToDate(), Calendar.DATE));
		}
		if(requestVo.getStatus()==null || requestVo.getStatus().trim()==""){
			reportListMap.put(ReportsConstant.REPORT_ORDER_STATUS,"");
		}else{
			reportListMap.put(ReportsConstant.REPORT_ORDER_STATUS,  requestVo.getStatus());
		}
		if(requestVo.getFilePeriod()==null || requestVo.getFilePeriod().trim()==""){
			reportListMap.put(ReportsConstant.REPORT_ORDER_FILE_PERIOD, "");
		}else{
			reportListMap.put(ReportsConstant.REPORT_ORDER_FILE_PERIOD,  requestVo.getFilePeriod());	
		}
		if(requestVo.getFileBranch()==null || requestVo.getFileBranch().trim()==""){
			reportListMap.put(ReportsConstant.REPORT_ORDER_FILE_BRANCH, "");
		}else{
			reportListMap.put(ReportsConstant.REPORT_ORDER_FILE_BRANCH, requestVo.getFileBranch());
		}
		if(requestVo.getFileStatus()==null || requestVo.getFileStatus().trim()==""){
			reportListMap.put(ReportsConstant.REPORT_ORDER_FILE_STATUS, "");
		}else{
			reportListMap.put(ReportsConstant.REPORT_ORDER_FILE_STATUS, requestVo.getFileStatus());
		}
		
		reportListMap.put(ReportsConstant.REPORT_ORDER_GET_WHAT, requestVo.getChartType());
		 
		reportListMap.put("exportType","");
		/*if(settlementRequestVO.getBranchFilter()==null || requestVo.getBranchFilter().trim()==""){
			reportListMap.put(SettlementConstants.FILTER_BRANCH, "null");	
		}else{
			reportListMap.put(SettlementConstants.FILTER_BRANCH, requestVo.getBranchFilter());
		}*/
		
		
		/*if(settlementRequestVO.getBranchFilter()==null || requestVo.getBranchFilter().trim()==""){
			reportListMap.put(SettlementConstants.FILTER_BRANCH, "null");	
		}else{
			reportListMap.put(SettlementConstants.FILTER_BRANCH, requestVo.getBranchFilter());
		}*/
		settlementDAO.getChartAxis(reportListMap);
		reportVOList = (List<ReportChartResponseVO>) reportListMap.get(ReportsConstant.REPORT_CHART_LIST);
		
		
		/*if(reportVOList != null){
			settlementResponseVO.setSettlementListVO(settlementVOList);
		}*/	
		}catch(Exception exception){
			log.error(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS);
		}
		return reportVOList;
	}
}
