/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   19-Aug-2017
 * 
 * Purpose:      Dashboard Pending Action List Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 19-Aug-2017				Divyashri S								To hold the List data for Pending Action section
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;

public class DashbrdPendingActionListVO {
	
	private String ccy;
	
	private String screen;
	
	private int count;
	
	private int decimal;
	
	private BigDecimal amount;
	
	private String actionDisplayKey;
	
	private String countLabel;
	
	private String status;
	
	private String statusKey;
	
	private String makeCheckFlg;

	public String getCcy() {
		return ccy;
	}

	public void setCcy(String ccy) {
		this.ccy = ccy;
	}

	public String getScreen() {
		return screen;
	}

	public void setScreen(String screen) {
		this.screen = screen;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getDecimal() {
		return decimal;
	}

	public void setDecimal(int decimal) {
		this.decimal = decimal;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getActionDisplayKey() {
		return actionDisplayKey;
	}

	public void setActionDisplayKey(String actionDisplayKey) {
		this.actionDisplayKey = actionDisplayKey;
	}

	public String getCountLabel() {
		return countLabel;
	}

	public void setCountLabel(String countLabel) {
		this.countLabel = countLabel;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusKey() {
		return statusKey;
	}

	public void setStatusKey(String statusKey) {
		this.statusKey = statusKey;
	}

	public String getMakeCheckFlg() {
		return makeCheckFlg;
	}

	public void setMakeCheckFlg(String makeCheckFlg) {
		this.makeCheckFlg = makeCheckFlg;
	}
	
	/**
	 * Getter methods introduced to send the amounts as
	 * String to avoid amount > 16 digits getting truncated
	 * Added as part of defect Fix CSC-7835
	**/
	
	public String getAmountStr() {
		return (amount != null)?amount.toPlainString():"";
	}
	
	
}
