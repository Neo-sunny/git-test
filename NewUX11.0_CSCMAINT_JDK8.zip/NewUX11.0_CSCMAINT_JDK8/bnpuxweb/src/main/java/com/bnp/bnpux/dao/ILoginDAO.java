/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Login Interface for Data Access Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 02 Mar 2017                Purjayar                                        UX10.0 S021 - Display icon only on 2FA authentication- Added method getchk2FAUser
 * 14 Dec 2017			  	  Rameshwar Khedekar							  FO 10.0.2- CSC 8692: Existing pin validation, disable certificate logic
************************************************************************************************************************************************************/
package com.bnp.bnpux.dao;

import java.util.List;
import java.util.Map;

import com.bnp.bnpux.common.vo.EntitlementVO;
import com.bnp.bnpux.common.vo.OrganizationVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.common.vo.UserVO;
import com.bnp.bnpux.common.vo.WhiteLabelVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;


public interface ILoginDAO {
	
	/**
	 * This method is for getting user login status
	 * 
	 * @param map
	 * @return
	 */
	UserVO getUserLoginStatus(Map<String, String> map);
	
	/**
	 * This method is for getting User UX info
	 * 
	 * @param userVO
	 * @return
	 */
	List<UserInfoVO> getUserUXInfo(UserVO userVO);
	
	/**
	 * This method is for getting Org logo
	 * 
	 * @param orgId
	 * @return
	 */
	OrganizationVO getOrgLogo(String orgId);
	
	/**
	 * This method is for getting white label details
	 * 
	 * @param userId
	 * @return
	 * @throws BNPApplicationException
	 */
	List<WhiteLabelVO> getWhiteLabelDetails(String userId)  throws BNPApplicationException;
	
	/**********Added for New UX 9.0 - User story S18,S19 starts ***********/
	/**
	 * This method is for getting entitlement details
	 * 
	 * @param userId
	 * @return
	 */
	List<EntitlementVO> getEntitlmntDet(String userId); 
	/**********Added for New UX 9.0 - User story S18,S19 ends ***********/
	
	/**********Added for New UX 9.0 (Session handling)- */
	/**
	 * This method is for updating the new session details
	 *  
	 * @param userVO
	 * @return
	 */
	UserVO updateNewSessionDetails(UserVO userVO);
	
	/**
	 * This method is for getting updating user history session
	 * 
	 * @param userVO
	 */
	void updateUserHistorySession(UserVO userVO);
	
	/**
	 * This method is for getting user login status for new ux
	 * 
	 * @param map
	 * @return
	 */
	UserVO getUserLoginStatusForNewUX(Map<String, String> map);
	
	/**
	 * @param userVO
	 */
	void insertA(UserVO userVO);
	
	/**
	 * This method is for getting Time interval
	 * 
	 * @return
	 */
	List<NameValueVO> getTimeInterval();
	
	/**
	 * This method is for getting scroll info
	 * 
	 * @return
	 * @throws BNPApplicationException
	 */
	List<NameValueVO> getScrollInfoList()  throws BNPApplicationException;
	
	/**
	 * This method is for getting is counter party
	 * 
	 * @param userId
	 * @return
	 */
	String getIsCounterpartyUser(String userId);
	
	/**
	 * This method is for getting is counter party
	 * 
	 * @param userId
	 * @return
	 */
	String getchk2FAUser(String userId)throws BNPApplicationException;

	/**
	 * This method is to get the session inactive time interval from the DB.
	 * For Bank user , query will fetch it from the PARAM_MASTER table and
	 * org user query will fetch it from the M_ORGANIZATION table.
	 * 
	 * @param userId
	 * @return String
	 */
	String getSessionInactiveInterval(String userId)throws BNPApplicationException;
	
	/**
	 * Existing pin validation, disable certificate logic
	 * @param mapValues
	 * @retun Map
	 */
	void updateCertStatus(Map mapValues);
	
	/**
	 * gets current Serial No of Certificate by UserId
	 * @param userId
	 * @return String
	 */
	String getSerialNoByUser(String userId);
	
	/**
	 * This method is used to validate uploaded file hashkey with DB hashkey
	 * @param mapValues
	 * @return
	 * @throws BNPApplicationException
	 */
	Integer isCertificateHashKeyValid(Map<String, String> mapValues);

	/**
	 * This method is used to update newly generated Certificate hash key
	 * @param mapValues
	 * @throws BNPApplicationException
	 */
	void updateCertificateHashKey(Map<String, String> mapValues);
	
	/**
	 * This method is used to get user certificate Hash Key.
	 * @param userId
	 * @return String
	 */
	String getUserCertHashkey(String userId);
}


