/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Report Controller
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.constants.ReportsConstant;
import com.bnp.bnpux.service.IReportService;
import com.bnp.bnpux.util.RequestIdentityValidator;
import com.bnp.bnpux.vo.requestVO.ReportRequestVO;
import com.bnp.bnpux.vo.responseVO.ReportResponseVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@RestController
@RequestMapping("/reportCtrl")
public class ReportController {


	/**
	 * Logger for ReportController
	 */
	public static final Logger log = LoggerFactory.getLogger(ReportController.class);
	
	
	/**
	 * Autowired Interface ISettlementService
	 */
	@Autowired
	private IReportService reportService;
	
	@Autowired
	RequestIdentityValidator validateRequest;
	/**
	 * This method is for getting the Reports Details
	 * 
	 * @param ReportRequestVO
	 * @return
	 */
	@RequestMapping(value = ReportsConstant.REPORT_SUMMARY_REST_GET_DETAILS, method = RequestMethod.POST)
	public ReportResponseVO getReportDetails(@RequestBody ReportRequestVO ReportRequestVO,HttpServletRequest request,HttpServletResponse response) {		
		ReportResponseVO reportResponseVO = new ReportResponseVO();
		try {
			boolean requestValidatedFlag = validateRequest.validate(ReportRequestVO.getUserId(),request.getSession());
			if(requestValidatedFlag){
				reportResponseVO = reportService.getReportDetails(ReportRequestVO);
			}
			else{
				reportResponseVO = null;
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
				
		} catch (BNPApplicationException exception) {
			reportResponseVO.setErrorMessag(exception.getMessage());
			log.error(exception.getMessage(),exception);	
		}
		return reportResponseVO;
	}
	
	/**
	 * This method is for getting the Reports Details list
	 * 
	 * @param ReportRequestVO
	 * @return
	 */
	@RequestMapping(value = ReportsConstant.REPORT_SUMMARY_REST_GET_DETAILS_LIST, method = RequestMethod.POST)
	public ReportResponseVO getReportDetailList(@RequestBody ReportRequestVO ReportRequestVO,HttpServletRequest request,HttpServletResponse response) {		
		ReportResponseVO reportResponseVO = new ReportResponseVO();
		try {
			boolean requestValidatedFlag = validateRequest.validate(ReportRequestVO.getUserId(),request.getSession());
			if(requestValidatedFlag){
				reportResponseVO = reportService.getReporList(ReportRequestVO);
			}
			else{
				reportResponseVO = null;
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (BNPApplicationException exception) {
			reportResponseVO.setErrorMessag(exception.getMessage());
			log.error(exception.getMessage(),exception);	
		}
		return reportResponseVO;
	}

	/**
	 * This method is for getting the Chart Data
	 * 
	 * @param requestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@RequestMapping(value = ReportsConstant.REPORT_SUMMARY_REST_GET_CHART_DATA, method = RequestMethod.POST,produces= MediaType.APPLICATION_JSON_VALUE,headers = {"content-type=application/json","content-type=application/xml"})
	public List<ReportChartResponseVO> getChartData(@RequestBody ReportRequestVO requestVO,HttpServletRequest request,HttpServletResponse response) throws BNPApplicationException { 
		List<ReportChartResponseVO> reportChartLst =null;
		try {
			if(requestVO !=null){
				boolean requestValidatedFlag = validateRequest.validate(requestVO.getUserId(),request.getSession());
				if(requestValidatedFlag){
					reportChartLst = reportService.getReportChartAxis(requestVO);
				}
				else{
					log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				}
			}
		} catch (BNPApplicationException exception) {
			log.error(exception.getMessage(),exception);	
		}
		return reportChartLst;
	}
}
