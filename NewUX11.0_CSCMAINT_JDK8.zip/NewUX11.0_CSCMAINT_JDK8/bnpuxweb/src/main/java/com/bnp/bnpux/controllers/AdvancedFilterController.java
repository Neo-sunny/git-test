/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   02-Mar-2017
 * 
 * Purpose:      Advanced Filter Controller
 * 
 * Change History:
 *  
 * Date                       Author                                            Reason
 * 02-Mar-2017			Bala Murugan Elangovan					Base version for Advanced filter controller 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.common.vo.AdvancedFilterVO;
import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.service.IAdvancedFilterService;
import com.bnp.bnpux.util.RequestIdentityValidator;
import com.bnp.bnpux.vo.requestVO.AdvancedFilterRequestVO;
import com.bnp.bnpux.vo.responseVO.AdvancedFilterResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@RestController
@RequestMapping("/advancedFilterCtrl")
public class AdvancedFilterController {
	
	/**
	 * Logger log for AdvancedFilterController class
	 */
	public static final Logger log = LoggerFactory.getLogger(AdvancedFilterController.class);

	/**
	 * IAdvancedFilterService advancedFilterService;
	 */
	@Autowired
	private IAdvancedFilterService advancedFilterService;	
	
	/**
	 * RequestIdentityValidator validateRequest;
	 */
	@Autowired
	private RequestIdentityValidator validateRequest;	
	

	
	/**
	 * This method is used to get configurable Advanced Filters elements
	 * 
	 * @param advanceFiterRequsetVO , httpRequest , httpResponse
	 * @return advanceFilterVO
	 */
	@RequestMapping(value = "getAdvancedFiltersList.rest", method = RequestMethod.POST)
	public AdvancedFilterVO getAdvancedFiltersList(@RequestBody AdvancedFilterVO advanceFiterRequsetVO, HttpServletRequest httpRequest, HttpServletResponse httpResponse){
		AdvancedFilterVO advanceFilterVO = new AdvancedFilterVO();		
		try{
			boolean validateRequestFlag = validateRequest.validate(advanceFiterRequsetVO.getUserId(), httpRequest.getSession());
			if(validateRequestFlag){		
				advanceFilterVO = advancedFilterService.getAdvancedFiltersList(advanceFiterRequsetVO);
			}
			else{		
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		}catch(BNPApplicationException bnpException){
			advanceFilterVO.setErrorMessage(bnpException.getMessage());
			log.error(bnpException.getMessage(),bnpException);
		}
		return advanceFilterVO;
	}
	
	
	/**
	 * This method is perform actions like save,edit,remove,fetch in advanced filter
	 * 
	 * @param advanceFiterRequsetVO , httpRequest , httpResponse
	 * @return advanceFilterVO
	 */
	@RequestMapping(value = "doAdvancedFilterAction.rest", method = RequestMethod.POST)
	public AdvancedFilterResponseVO doAdvancedFilterAction(@RequestBody AdvancedFilterRequestVO advanceFiterRequsetVO, HttpServletRequest httpRequest, HttpServletResponse httpResponse){
		
		AdvancedFilterResponseVO responseVO = new AdvancedFilterResponseVO();		
		try{
			boolean validateRequestFlag = validateRequest.validate(advanceFiterRequsetVO.getUserId(), httpRequest.getSession());
			if(validateRequestFlag){		
				advancedFilterService.doAdvancedFilterAction(advanceFiterRequsetVO);
				responseVO.setAdvancedFilterList(advanceFiterRequsetVO.getAdvancedFilterList());
				responseVO.setErrorMsg(advanceFiterRequsetVO.getErrorFlag());
			}
			else{		
				log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		}catch(BNPApplicationException bnpException){
			responseVO.setErrorMsg(bnpException.getErrorMessage());
			log.error(bnpException.getMessage(),bnpException);
		}
		return responseVO;
	}
	
	
	
			
}
