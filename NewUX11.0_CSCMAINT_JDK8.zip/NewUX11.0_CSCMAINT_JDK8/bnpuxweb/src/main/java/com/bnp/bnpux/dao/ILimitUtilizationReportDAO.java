/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  21 June 2017
 * 
 * Purpose:      Limit Utilization Report Interface for Data Access Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 21 June 2017       Ratna Gokhale, Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.dao;

import java.util.List;

import com.bnp.bnpux.vo.requestVO.LimitUtilizationRequestVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;

public interface ILimitUtilizationReportDAO {
	

	/**
	 * This method is for getting Limit Utilization Report List
	 * 
	 * @param LimitUtilizationRequestVO
	 * @return LimitUtilizationRequestVO List
	 */
	List<LimitUtilizationRequestVO> getReportList(LimitUtilizationRequestVO limitUtilizationRequestVO);
	
	/**
	 * This method is for getting Limit Utilization Report List Details
	 * 
	 * @param LimitUtilizationRequestVO
	 * @return LimitUtilizationRequestVO List
	 */
	List<LimitUtilizationRequestVO> getReportListDetails(LimitUtilizationRequestVO limitUtilizationRequestVO);
	

	/**
	 * This method is for getting Chart Axis
	 * 
	 * @param LimitUtilizationRequestVO
	 * @return ReportChartResponseVO List
	 */
	List<ReportChartResponseVO> getChartAxis(LimitUtilizationRequestVO limitUtilizationRequestVO);
	
		

}
