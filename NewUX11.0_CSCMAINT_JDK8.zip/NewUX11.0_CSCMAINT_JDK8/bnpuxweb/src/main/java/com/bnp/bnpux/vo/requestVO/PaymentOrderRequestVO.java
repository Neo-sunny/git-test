/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     PaymentOrder Request Object
 * 
 * Change History: 
 * Date                       		Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd            Initial Version 
 * 08 Mar 2017                		skbhaska                                    	  FO 10.0 - S30 - Holiday Calendar
 * 01-JAN-2018				        Bala Murugan Elangovan						Added new method validateDiscDateWithHoliday for S101001 as part of FO10.1 Sprint 2
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.requestVO;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.bnp.bnpux.common.vo.AdvancedFilterVO;
import com.bnp.bnpux.common.vo.PaymentOrderListDetailsVO;
import com.bnp.bnpux.common.vo.PaymentOrderListVO;
import com.bnp.bnpux.common.vo.PaymentOrderSummaryVO;
import com.bnp.bnpux.vo.responseVO.PeriodStatusResponseVO;

public class PaymentOrderRequestVO {

	private String userId;

	private String userType;

	private String orgId;
	
	private String leadOrgId;

	private String currencyCode;

	private BigDecimal availableAmt;

	private BigDecimal indicativeNetAmt;

	private BigDecimal supplierBalance;

	private String paymentOrderNo;

	private String paymentOrderStatus;
	
	private Date maturityDate;	
	
	private Long recordFrom;
	
	private Long recordTo;
	
	private Integer recordCount;
	
	private String maturityFilter;
	
	private String errorFlag;
	
	private String advanceFilter;
	
	private String groupIndicator;
	
	private String viewType;
	
	private String supplierOrgId;
	
	private String buyerOrgId;
	
	private String buyerRefNumberUnique;
	
	private String discRefNo;
	
	private String periodFilter;
	
	private String statusFilter;

	private String branchFilter;
	
	private String quickSearchText;
	
	private String pymtId;
	
	private String branchId;
	
	private Date discountDate;
	
	private String leadDays;
	
	private String ignCcyHoliday;
	
	private Date nextDate;
	
	private Date modifiedDiscDate;
	
	List<AdvancedFilterVO> advancedFilterListVO;		
	
	public List<AdvancedFilterVO> getAdvancedFilterListVO() {
		return advancedFilterListVO;
	}

	public void setAdvancedFilterListVO(List<AdvancedFilterVO> advancedFilterListVO) {
		this.advancedFilterListVO = advancedFilterListVO;
	}
	
	/* Added below variables for code review comments(HashMap to RequestVO  in service layer)*/
	private List<PaymentOrderSummaryVO> paymentdetails;
	
	private List<PaymentOrderListVO> paymentOrderList;
	
	private List<PaymentOrderListDetailsVO> paymentOrderListDetails;
	
	/**FO 10.0 - S30 - Holiday Calendar**/
	private List<PeriodStatusResponseVO> periodStatusRespone;
	/**FO 10.0 - S30 - Holiday Calendar**/

	public String getQuickSearchText() {
		return quickSearchText;
	}

	public void setQuickSearchText(String quickSearchText) {
		this.quickSearchText = quickSearchText;
	}

	public String getPeriodFilter() {
		return periodFilter;
	}

	public void setPeriodFilter(String periodFilter) {
		this.periodFilter = periodFilter;
	}

	public String getStatusFilter() {
		return statusFilter;
	}

	public void setStatusFilter(String statusFilter) {
		this.statusFilter = statusFilter;
	}

	public Date getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(Date maturityDate) {
		this.maturityDate = maturityDate;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public BigDecimal getAvailableAmt() {
		return availableAmt;
	}

	public void setAvailableAmt(BigDecimal availableAmt) {
		this.availableAmt = availableAmt;
	}

	public BigDecimal getIndicativeNetAmt() {
		return indicativeNetAmt;
	}

	public void setIndicativeNetAmt(BigDecimal indicativeNetAmt) {
		this.indicativeNetAmt = indicativeNetAmt;
	}

	public BigDecimal getSupplierBalance() {
		return supplierBalance;
	}

	public void setSupplierBalance(BigDecimal supplierBalance) {
		this.supplierBalance = supplierBalance;
	}

	public String getPaymentOrderNo() {
		return paymentOrderNo;
	}

	public void setPaymentOrderNo(String paymentOrderNo) {
		this.paymentOrderNo = paymentOrderNo;
	}

	public String getPaymentOrderStatus() {
		return paymentOrderStatus;
	}

	public void setPaymentOrderStatus(String paymentOrderStatus) {
		this.paymentOrderStatus = paymentOrderStatus;
	}

	public String getLeadOrgId() {
		return leadOrgId;
	}

	public void setLeadOrgId(String leadOrgId) {
		this.leadOrgId = leadOrgId;
	}



	public Integer getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(Integer recordCount) {
		this.recordCount = recordCount;
	}

	public String getMaturityFilter() {
		return maturityFilter;
	}

	public void setMaturityFilter(String maturityFilter) {
		this.maturityFilter = maturityFilter;
	}

	public String getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	public String getAdvanceFilter() {
		return advanceFilter;
	}

	public void setAdvanceFilter(String advanceFilter) {
		this.advanceFilter = advanceFilter;
	}


	public String getViewType() {
		return viewType;
	}

	public void setViewType(String viewType) {
		this.viewType = viewType;
	}

	public String getGroupIndicator() {
		return groupIndicator;
	}

	public void setGroupIndicator(String groupIndicator) {
		this.groupIndicator = groupIndicator;
	}

	public String getSupplierOrgId() {
		return supplierOrgId;
	}

	public void setSupplierOrgId(String supplierOrgId) {
		this.supplierOrgId = supplierOrgId;
	}

	public String getBuyerOrgId() {
		return buyerOrgId;
	}

	public void setBuyerOrgId(String buyerOrgId) {
		this.buyerOrgId = buyerOrgId;
	}

	public String getBuyerRefNumberUnique() {
		return buyerRefNumberUnique;
	}

	public void setBuyerRefNumberUnique(String buyerRefNumberUnique) {
		this.buyerRefNumberUnique = buyerRefNumberUnique;
	}

	public String getDiscRefNo() {
		return discRefNo;
	}

	public void setDiscRefNo(String discRefNo) {
		this.discRefNo = discRefNo;
	}

	public String getBranchFilter() {
		return branchFilter;
	}

	public void setBranchFilter(String branchFilter) {
		this.branchFilter = branchFilter;
	}

	public String getPymtId() {
		return pymtId;
	}

	public void setPymtId(String pymtId) {
		this.pymtId = pymtId;
	}

	public List<PaymentOrderSummaryVO> getPaymentdetails() {
		return paymentdetails;
	}

	public void setPaymentdetails(List<PaymentOrderSummaryVO> paymentdetails) {
		this.paymentdetails = paymentdetails;
	}

	public List<PaymentOrderListVO> getPaymentOrderList() {
		return paymentOrderList;
	}

	public void setPaymentOrderList(List<PaymentOrderListVO> paymentOrderList) {
		this.paymentOrderList = paymentOrderList;
	}

	public List<PaymentOrderListDetailsVO> getPaymentOrderListDetails() {
		return paymentOrderListDetails;
	}

	public void setPaymentOrderListDetails(List<PaymentOrderListDetailsVO> paymentOrderListDetails) {
		this.paymentOrderListDetails = paymentOrderListDetails;
	}

	/**FO 10.0 - S30 - Holiday Calendar**/
	public List<PeriodStatusResponseVO> getPeriodStatusRespone() {
		return periodStatusRespone;
	}

	public void setPeriodStatusRespone(List<PeriodStatusResponseVO> periodStatusRespone) {
		this.periodStatusRespone = periodStatusRespone;
	}
	/**FO 10.0 - S30 - Holiday Calendar**/

	public Long getRecordFrom() {
		return recordFrom;
	}

	public void setRecordFrom(Long recordFrom) {
		this.recordFrom = recordFrom;
	}

	public Long getRecordTo() {
		return recordTo;
	}

	public void setRecordTo(Long recordTo) {
		this.recordTo = recordTo;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public Date getDiscountDate() {
		return discountDate;
	}

	public void setDiscountDate(Date discountDate) {
		this.discountDate = discountDate;
	}

	public String getLeadDays() {
		return leadDays;
	}

	public void setLeadDays(String leadDays) {
		this.leadDays = leadDays;
	}

	public String getIgnCcyHoliday() {
		return ignCcyHoliday;
	}

	public void setIgnCcyHoliday(String ignCcyHoliday) {
		this.ignCcyHoliday = ignCcyHoliday;
	}

	public Date getNextDate() {
		return nextDate;
	}

	public void setNextDate(Date nextDate) {
		this.nextDate = nextDate;
	}

	public Date getModifiedDiscDate() {
		return modifiedDiscDate;
	}

	public void setModifiedDiscDate(Date modifiedDiscDate) {
		this.modifiedDiscDate = modifiedDiscDate;
	}
	
	

}
