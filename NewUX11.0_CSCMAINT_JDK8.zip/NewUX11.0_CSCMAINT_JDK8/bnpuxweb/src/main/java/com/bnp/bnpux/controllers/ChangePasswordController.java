package com.bnp.bnpux.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.util.RequestIdentityValidator;
import com.bnp.scm.services.common.ChangePasswordRequestVO;
import com.bnp.scm.services.common.IChangePasswordWrapperService;
@RestController
@RequestMapping("/changePasswordCtrl")
public class ChangePasswordController {
	public static final Logger log = LoggerFactory.getLogger(ChangePasswordController.class);
	
	@Autowired
	private IChangePasswordWrapperService changePasswordWrapperService;
	
    @Autowired
	RequestIdentityValidator validateRequest;
	
    @RequestMapping(value = "getUpdatePasswordInfo.rest", method = RequestMethod.POST)
	public ChangePasswordRequestVO updateRecords(@RequestBody ChangePasswordRequestVO changePasswordRequestVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		try {
			
			boolean requestValidatedFlag = validateRequest.validate(changePasswordRequestVO.getUserId(), httpServletRequest.getSession());
			if(requestValidatedFlag){	
				
			    changePasswordWrapperService.UpdateRecords(changePasswordRequestVO, httpServletRequest, httpServletResponse);
				return changePasswordRequestVO;
			}else{
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} 
		catch (Exception exception) {
			log.error(exception.getMessage(), exception);
			changePasswordRequestVO.setErrMessage(exception.getMessage());
		}
		return changePasswordRequestVO;
	}
}
