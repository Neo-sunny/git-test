/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   23-FEB-2017
 * 
 * Purpose:      Payment Order Detail Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 23-FEB-2017             Divyashri Subramaniam                            Created for New popUp in Payment Order Screen
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

public class PaymentOrderDetailVO{
	
	private String shortName;
	
	private String postalAddress;
	
	private String city;
	
	private String state;
	
	private String postalCode;
	
	private String cptyShortName;
	
	private String cptyPostalAddress;
	
	private String cptyCity;
	
	private String cptyState;
	
	private String cptyPostalCode;
	
	private String fileId;
	
	private String uploadedBy;
	
	private String fileStatus;
	
	private String fileName;
	
	private String releasedBy;
	
	private String pymtDueDate;
	
	private String adjDueDate;
	
	private String sepaCollInitDate;
	
	private String refType;
	
	private String invCount;
	
	private String ccyCode;
	
	private String pymtAmount;
	
	private String sepaCollSettStatus;
	
	private String autoCollectMessage;
	
	private String remPymtAmount;
	
	private String updatedPymtAmount;
	
	private String outStlmtAmount;
	
	private String supportBranch;
	
	private int csvExportThreshold;
	
	private int pdfExportThreshold;
	
	private int xlsExportThreshold;
	
	private String consolDiscDate;
	
	private String refValue;
	
	private int decimalPoint;
	
	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public String getPostalAddress() {
		return postalAddress;
	}

	public void setPostalAddress(String postalAddress) {
		this.postalAddress = postalAddress;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getCptyShortName() {
		return cptyShortName;
	}

	public void setCptyShortName(String cptyShortName) {
		this.cptyShortName = cptyShortName;
	}

	public String getCptyPostalAddress() {
		return cptyPostalAddress;
	}

	public void setCptyPostalAddress(String cptyPostalAddress) {
		this.cptyPostalAddress = cptyPostalAddress;
	}

	public String getCptyCity() {
		return cptyCity;
	}

	public void setCptyCity(String cptyCity) {
		this.cptyCity = cptyCity;
	}

	public String getCptyState() {
		return cptyState;
	}

	public void setCptyState(String cptyState) {
		this.cptyState = cptyState;
	}

	public String getCptyPostalCode() {
		return cptyPostalCode;
	}

	public void setCptyPostalCode(String cptyPostalCode) {
		this.cptyPostalCode = cptyPostalCode;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getUploadedBy() {
		return uploadedBy;
	}

	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}

	public String getFileStatus() {
		return fileStatus;
	}

	public void setFileStatus(String fileStatus) {
		this.fileStatus = fileStatus;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getReleasedBy() {
		return releasedBy;
	}

	public void setReleasedBy(String releasedBy) {
		this.releasedBy = releasedBy;
	}

	public String getPymtDueDate() {
		return pymtDueDate;
	}

	public void setPymtDueDate(String pymtDueDate) {
		this.pymtDueDate = pymtDueDate;
	}

	public String getAdjDueDate() {
		return adjDueDate;
	}

	public void setAdjDueDate(String adjDueDate) {
		this.adjDueDate = adjDueDate;
	}

	public String getSepaCollInitDate() {
		return sepaCollInitDate;
	}

	public void setSepaCollInitDate(String sepaCollInitDate) {
		this.sepaCollInitDate = sepaCollInitDate;
	}

	public String getRefType() {
		return refType;
	}

	public void setRefType(String refType) {
		this.refType = refType;
	}

	public String getInvCount() {
		return invCount;
	}

	public void setInvCount(String invCount) {
		this.invCount = invCount;
	}

	public String getCcyCode() {
		return ccyCode;
	}

	public void setCcyCode(String ccyCode) {
		this.ccyCode = ccyCode;
	}

	public String getPymtAmount() {
		return pymtAmount;
	}

	public void setPymtAmount(String pymtAmount) {
		this.pymtAmount = pymtAmount;
	}

	public String getSepaCollSettStatus() {
		return sepaCollSettStatus;
	}

	public void setSepaCollSettStatus(String sepaCollSettStatus) {
		this.sepaCollSettStatus = sepaCollSettStatus;
	}

	public String getAutoCollectMessage() {
		return autoCollectMessage;
	}

	public void setAutoCollectMessage(String autoCollectMessage) {
		this.autoCollectMessage = autoCollectMessage;
	}

	public String getRemPymtAmount() {
		return remPymtAmount;
	}

	public void setRemPymtAmount(String remPymtAmount) {
		this.remPymtAmount = remPymtAmount;
	}

	public String getUpdatedPymtAmount() {
		return updatedPymtAmount;
	}

	public void setUpdatedPymtAmount(String updatedPymtAmount) {
		this.updatedPymtAmount = updatedPymtAmount;
	}

	public String getOutStlmtAmount() {
		return outStlmtAmount;
	}

	public void setOutStlmtAmount(String outStlmtAmount) {
		this.outStlmtAmount = outStlmtAmount;
	}

	public String getSupportBranch() {
		return supportBranch;
	}

	public void setSupportBranch(String supportBranch) {
		this.supportBranch = supportBranch;
	}

	public int getCsvExportThreshold() {
		return csvExportThreshold;
	}

	public void setCsvExportThreshold(int csvExportThreshold) {
		this.csvExportThreshold = csvExportThreshold;
	}

	public int getPdfExportThreshold() {
		return pdfExportThreshold;
	}

	public void setPdfExportThreshold(int pdfExportThreshold) {
		this.pdfExportThreshold = pdfExportThreshold;
	}

	public int getXlsExportThreshold() {
		return xlsExportThreshold;
	}

	public void setXlsExportThreshold(int xlsExportThreshold) {
		this.xlsExportThreshold = xlsExportThreshold;
	}

	public String getConsolDiscDate() {
		return consolDiscDate;
	}

	public void setConsolDiscDate(String consolDiscDate) {
		this.consolDiscDate = consolDiscDate;
	}

	public String getRefValue() {
		return refValue;
	}

	public void setRefValue(String refValue) {
		this.refValue = refValue;
	}

	/**
	 * @return the decimalPoint
	 */
	public int getDecimalPoint() {
		return decimalPoint;
	}

	/**
	 * @param decimalPoint the decimalPoint to set
	 */
	public void setDecimalPoint(int decimalPoint) {
		this.decimalPoint = decimalPoint;
	}
}
