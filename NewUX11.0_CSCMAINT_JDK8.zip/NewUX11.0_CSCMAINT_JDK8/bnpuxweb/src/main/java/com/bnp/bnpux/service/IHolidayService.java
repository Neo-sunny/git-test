/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     Holiday Service Interface
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                Oracle Financial Services Software Ltd            Initial Version 
 * 08 Mar 2017                skbhaska                                    		FO 10.0 - S30 - Holiday Calendar
 *****************************************************************************************************************************************************************/
package com.bnp.bnpux.service;

import java.util.List;

import com.bnp.bnpux.common.vo.HolidayVO;
import com.bnp.bnpux.vo.requestVO.HolidayRequestVO;
import com.bnp.bnpux.vo.responseVO.HolidayResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface IHolidayService {
	
	/**
	 * This method is for getting holiday list
	 * 
	 * @param holidayRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	public List<HolidayVO> getHolidayList(HolidayRequestVO holidayRequestVO) throws BNPApplicationException;
	
	
	/**
	 * This method is used to get the list of holiday based on CYY List, Year, Org ID, Branch (For BA Users) 
	 * @param holidayRequestVO
	 * @return HolidayResponseVO
	 * @throws BNPApplicationException
	 */
	public List<HolidayVO> getHolidayListForCalendar(HolidayRequestVO holidayRequestVO) throws BNPApplicationException;

}
