/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   21 June 2017
 * 
 * Purpose:    Limit Utilization Report Service Interface
 * 
 * Change History: 
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 21 June 2017       Ratna Gokhale, Oracle Financial Services Software Ltd     Initial Version
 * 
 *****************************************************************************************************************************************************************/
package com.bnp.bnpux.service;

import java.util.List;

import com.bnp.bnpux.vo.requestVO.LimitUtilizationRequestVO;
import com.bnp.bnpux.vo.responseVO.LimitUtilizationResponseVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface ILimitUtilizationReportService {

	/**
	 * This method is for getting Limit Utilization Report details
	 * 
	 * @param LimitUtilizationRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	LimitUtilizationResponseVO getReportDetails(LimitUtilizationRequestVO limitUtilizationRequestVO) throws BNPApplicationException;

	/**
	 * This method is for getting Limit Utilization Report list
	 * 
	 * @param LimitUtilizationRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	LimitUtilizationResponseVO getReportList(LimitUtilizationRequestVO limitUtilizationRequestVO)	throws BNPApplicationException;
	
	/**
	 * This method is for getting report chart axis 
	 * 
	 * @param requestVo
	 * @return
	 * @throws BNPApplicationException
	 */
	List<ReportChartResponseVO> getReportChartAxis (LimitUtilizationRequestVO requestVo)throws BNPApplicationException;


	
}
