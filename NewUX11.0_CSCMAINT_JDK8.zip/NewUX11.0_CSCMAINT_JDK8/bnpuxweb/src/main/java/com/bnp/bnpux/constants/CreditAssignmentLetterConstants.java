/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Credit Assignment Letter Constants
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.constants;

public class CreditAssignmentLetterConstants {
	
	public static final String 	CREDIT_LETTER_REST_GET_LIST ="getCreditAssgntLetters.rest";
	
	public static final String 	CREDIT_LETTER_REST_DOWNLOAD ="downloadCreditAssgntLetter.rest";

}
