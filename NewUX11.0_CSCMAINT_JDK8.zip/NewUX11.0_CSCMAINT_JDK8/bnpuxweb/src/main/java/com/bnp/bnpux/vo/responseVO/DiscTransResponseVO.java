/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  21 June 2017
 * 
 * Purpose:      Discount Transaction Report Response VO
 * 
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 21 June 2017       Ratna Gokhale, Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/

package com.bnp.bnpux.vo.responseVO;

import java.util.List;

import com.bnp.bnpux.common.vo.DiscTransDetailsVO;
import com.bnp.bnpux.common.vo.DiscTransVO;
import com.bnp.bnpux.common.vo.CreditNoteUtilizationVO;

public class DiscTransResponseVO{

	
	private String errorMessage;
	
	private List<DiscTransVO> discTransList;
	
	private List<DiscTransDetailsVO> discTransDetails;
	
	private List<CreditNoteUtilizationVO> discTransUtilization;
	
	private List<ReportChartResponseVO> reportChartList;
	
	public List<ReportChartResponseVO> getReportChartList() {
		return reportChartList;
	}

	public void setReportChartList(List<ReportChartResponseVO> reportChartList) {
		this.reportChartList = reportChartList;
	}

	public List<CreditNoteUtilizationVO> getDiscTransUtilization() {
		return discTransUtilization;
	}

	public void setDiscTransUtilization(List<CreditNoteUtilizationVO> discTransUtilization) {
		this.discTransUtilization = discTransUtilization;
	}

	public List<DiscTransDetailsVO> getDiscTransDetails() {
		return discTransDetails;
	}

	public void setDiscTransDetails(List<DiscTransDetailsVO> discTransDetails) {
		this.discTransDetails = discTransDetails;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public List<DiscTransVO> getDiscTransList() {
		return discTransList;
	}

	public void setDiscTransList(List<DiscTransVO> discTransList) {
		this.discTransList = discTransList;
	}


}
