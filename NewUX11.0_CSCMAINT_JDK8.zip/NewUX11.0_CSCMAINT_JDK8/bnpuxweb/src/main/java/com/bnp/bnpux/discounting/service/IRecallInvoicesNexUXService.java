/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Interface for Discount Request button actions
 *  
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.discounting.service;

import java.util.List;

import com.bnp.bnpux.common.vo.RecallResponseVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.vo.errorMessageVO.ErrorMessageVO;
import com.bnp.scm.services.invoice.vo.RecallInvoiceVO;

public interface IRecallInvoicesNexUXService {

	/**
	 * This method is for Recall Discount Request
	 * 
	 * @param recallVOList
	 * @param user
	 * @return
	 */
	RecallResponseVO recallfromNewUX(List<RecallInvoiceVO> recallVOList, UserInfoVO user);
	
	/**
	 * This method is for Approving Discount Request
	 * 
	 * @param recallVOList
	 * @param user
	 * @return
	 */
	RecallResponseVO approvefromNewUX(List<RecallInvoiceVO> recallVOList, UserInfoVO user);
	
	/**
	 * This method is for Undo Discount Request
	 * 
	 * @param recallVOList
	 * @param user
	 * @return
	 */
	RecallResponseVO undofromNewUX(List<RecallInvoiceVO> recallVOList, UserInfoVO user);

}
