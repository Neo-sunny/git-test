/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14-FEB-2017
 * 
 * Purpose:      Discount Details popup Ux VO
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 14-FEB-2017				  Sathishkumar B									New VO - S271, S273, S274, S275, S276, S277
 * 28-JUL-2017                Anand                                             Sprint 7 - S1411004
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

public class DiscountDetailsUxVO extends AbstractVO{
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = -5484025482742751972L;
	
	private String discStatus;
	
	/**Reference Details**/
	private String disRefNo;
	private String pymtRefNo;
	private String batchRefNo;
	private String addRefNo;
	private String custRefNo;
	private String beneReconRefValue;
	private String priorDisRefNo;
	/**Reference Details**/
	
	/**Amount Details**/
	private String orgAmt;
	private String supplierAcctNo;
	private String creditNoteAmount;
	private String pymtAmt;
	private String confChargeAmt;
	private String confirmedNetAmount;
	/**Amount Details**/
	
	/**Discount Details**/	
	private String docType;
	private String pymtDueDate;
	private String overdueDiscRate;
	private String discAvlbleAmt;
	private String isRolovrCrtd;
	private String isMinDiscFeeApplied;
	private String createdDate;
	private String confirmedInterestrate;
	private String confirmedInterestAmt;
	private String discPymtStatus;
	//Sprint 7 - S1411004 start 
	private String confirmedBaseRateFloored;
	//Sprint 7 - S1411004 end
	/**Discount Details**/
	
	
	/**Indicative Amount Details**/
	private String indDiscRate;
	private String indChargeAmt;
	private String indDiscAmt;
	private String indNetAmt;
	//Sprint 7 - S1411004 start
	private String indBaserateFloored;
	//Sprint 7 - S1411004 end
	/**Indicative Amount Details**/
	
	
	/**Other Details**/
	private String minFinancialAmt;
	private String buyerMarginAcc;
	private String bankMarginAccount;
	private String dueDate;
	private String isRolovrReq;
	private String discTenure;
	private String rateChargeType;
	private String billType;
	private String remarks;
	/**Other Details**/
	
	private String ccyCode;
	
	/**Export Threshold**/
	private int csvExportThreshold;
	private int pdfExportThreshold;
	private int xlsExportThreshold;
	/**Export Threshold**/
	
	
	public String getDiscStatus() {
		return discStatus;
	}
	public void setDiscStatus(String discStatus) {
		this.discStatus = discStatus;
	}
	public String getDisRefNo() {
		return disRefNo;
	}
	public void setDisRefNo(String disRefNo) {
		this.disRefNo = disRefNo;
	}
	public String getPymtRefNo() {
		return pymtRefNo;
	}
	public void setPymtRefNo(String pymtRefNo) {
		this.pymtRefNo = pymtRefNo;
	}
	public String getBatchRefNo() {
		return batchRefNo;
	}
	public void setBatchRefNo(String batchRefNo) {
		this.batchRefNo = batchRefNo;
	}
	public String getAddRefNo() {
		return addRefNo;
	}
	public void setAddRefNo(String addRefNo) {
		this.addRefNo = addRefNo;
	}
	public String getCustRefNo() {
		return custRefNo;
	}
	public void setCustRefNo(String custRefNo) {
		this.custRefNo = custRefNo;
	}
	public String getBeneReconRefValue() {
		return beneReconRefValue;
	}
	public void setBeneReconRefValue(String beneReconRefValue) {
		this.beneReconRefValue = beneReconRefValue;
	}
	public String getPriorDisRefNo() {
		return priorDisRefNo;
	}
	public void setPriorDisRefNo(String priorDisRefNo) {
		this.priorDisRefNo = priorDisRefNo;
	}
	public String getOrgAmt() {
		return orgAmt;
	}
	public void setOrgAmt(String orgAmt) {
		this.orgAmt = orgAmt;
	}
	public String getSupplierAcctNo() {
		return supplierAcctNo;
	}
	public void setSupplierAcctNo(String supplierAcctNo) {
		this.supplierAcctNo = supplierAcctNo;
	}
	public String getCreditNoteAmount() {
		return creditNoteAmount;
	}
	public void setCreditNoteAmount(String creditNoteAmount) {
		this.creditNoteAmount = creditNoteAmount;
	}
	public String getPymtAmt() {
		return pymtAmt;
	}
	public void setPymtAmt(String pymtAmt) {
		this.pymtAmt = pymtAmt;
	}
	public String getConfChargeAmt() {
		return confChargeAmt;
	}
	public void setConfChargeAmt(String confChargeAmt) {
		this.confChargeAmt = confChargeAmt;
	}
	public String getConfirmedNetAmount() {
		return confirmedNetAmount;
	}
	public void setConfirmedNetAmount(String confirmedNetAmount) {
		this.confirmedNetAmount = confirmedNetAmount;
	}
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getPymtDueDate() {
		return pymtDueDate;
	}
	public void setPymtDueDate(String pymtDueDate) {
		this.pymtDueDate = pymtDueDate;
	}
	public String getOverdueDiscRate() {
		return overdueDiscRate;
	}
	public void setOverdueDiscRate(String overdueDiscRate) {
		this.overdueDiscRate = overdueDiscRate;
	}
	public String getDiscAvlbleAmt() {
		return discAvlbleAmt;
	}
	public void setDiscAvlbleAmt(String discAvlbleAmt) {
		this.discAvlbleAmt = discAvlbleAmt;
	}
	public String getIsRolovrCrtd() {
		return isRolovrCrtd;
	}
	public void setIsRolovrCrtd(String isRolovrCrtd) {
		this.isRolovrCrtd = isRolovrCrtd;
	}
	public String getIsMinDiscFeeApplied() {
		return isMinDiscFeeApplied;
	}
	public void setIsMinDiscFeeApplied(String isMinDiscFeeApplied) {
		this.isMinDiscFeeApplied = isMinDiscFeeApplied;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getConfirmedInterestrate() {
		return confirmedInterestrate;
	}
	public void setConfirmedInterestrate(String confirmedInterestrate) {
		this.confirmedInterestrate = confirmedInterestrate;
	}
	public String getConfirmedInterestAmt() {
		return confirmedInterestAmt;
	}
	public void setConfirmedInterestAmt(String confirmedInterestAmt) {
		this.confirmedInterestAmt = confirmedInterestAmt;
	}
	public String getDiscPymtStatus() {
		return discPymtStatus;
	}
	public void setDiscPymtStatus(String discPymtStatus) {
		this.discPymtStatus = discPymtStatus;
	}
	//Sprint 7 - S1411004 start
	public String getConfirmedBaseRateFloored() {
		return confirmedBaseRateFloored;
	}
	public void setConfirmedBaseRateFloored(String confirmedBaseRateFloored) {
		this.confirmedBaseRateFloored = confirmedBaseRateFloored;
	}
	//Sprint 7 - S1411004 End
	public String getIndDiscRate() {
		return indDiscRate;
	}
	public void setIndDiscRate(String indDiscRate) {
		this.indDiscRate = indDiscRate;
	}
	public String getIndChargeAmt() {
		return indChargeAmt;
	}
	public void setIndChargeAmt(String indChargeAmt) {
		this.indChargeAmt = indChargeAmt;
	}
	public String getIndDiscAmt() {
		return indDiscAmt;
	}
	public void setIndDiscAmt(String indDiscAmt) {
		this.indDiscAmt = indDiscAmt;
	}
	public String getIndNetAmt() {
		return indNetAmt;
	}
	public void setIndNetAmt(String indNetAmt) {
		this.indNetAmt = indNetAmt;
	}
	//Sprint 7 - S1411004 start
	public String getIndBaserateFloored() {
		return indBaserateFloored;
	}
	public void setIndBaserateFloored(String indBaserateFloored) {
		this.indBaserateFloored = indBaserateFloored;
	}
	//Sprint 7 - S1411004 end
	public String getMinFinancialAmt() {
		return minFinancialAmt;
	}
	public void setMinFinancialAmt(String minFinancialAmt) {
		this.minFinancialAmt = minFinancialAmt;
	}
	public String getBuyerMarginAcc() {
		return buyerMarginAcc;
	}
	public void setBuyerMarginAcc(String buyerMarginAcc) {
		this.buyerMarginAcc = buyerMarginAcc;
	}
	public String getBankMarginAccount() {
		return bankMarginAccount;
	}
	public void setBankMarginAccount(String bankMarginAccount) {
		this.bankMarginAccount = bankMarginAccount;
	}
	public String getDueDate() {
		return dueDate;
	}
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	public String getIsRolovrReq() {
		return isRolovrReq;
	}
	public void setIsRolovrReq(String isRolovrReq) {
		this.isRolovrReq = isRolovrReq;
	}
	public String getDiscTenure() {
		return discTenure;
	}
	public void setDiscTenure(String discTenure) {
		this.discTenure = discTenure;
	}
	public String getRateChargeType() {
		return rateChargeType;
	}
	public void setRateChargeType(String rateChargeType) {
		this.rateChargeType = rateChargeType;
	}
	public String getBillType() {
		return billType;
	}
	public void setBillType(String billType) {
		this.billType = billType;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getCcyCode() {
		return ccyCode;
	}
	public void setCcyCode(String ccyCode) {
		this.ccyCode = ccyCode;
	}
	public int getCsvExportThreshold() {
		return csvExportThreshold;
	}
	public void setCsvExportThreshold(int csvExportThreshold) {
		this.csvExportThreshold = csvExportThreshold;
	}
	public int getPdfExportThreshold() {
		return pdfExportThreshold;
	}
	public void setPdfExportThreshold(int pdfExportThreshold) {
		this.pdfExportThreshold = pdfExportThreshold;
	}
	public int getXlsExportThreshold() {
		return xlsExportThreshold;
	}
	public void setXlsExportThreshold(int xlsExportThreshold) {
		this.xlsExportThreshold = xlsExportThreshold;
	}
	 
	
	
}

