/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
* 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
* 
 * Created on:   27-OCT-2016
* 
 * Purpose:      Audit Controller
* 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/package com.bnp.bnpux.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.service.IAuditService;
import com.bnp.bnpux.util.RequestIdentityValidator;
import com.bnp.bnpux.vo.requestVO.AuditRequestVO;


@RestController
@RequestMapping("/auditCtrl")
public class AuditController {
	private static final Logger log = LoggerFactory.getLogger(AuditController.class);
	
	@Autowired
	private IAuditService auditService;
	
	@Autowired
	RequestIdentityValidator validateRequest;
	/**
	 * This method is used for inserting audit logs
	 * @param auditVo
	 */
	@RequestMapping(value = "insertAuditLog.rest", method = RequestMethod.POST)
	public void insertAuditLog(@RequestBody AuditRequestVO auditVo,HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse){
		boolean requestValidatedFlag = validateRequest.validate(auditVo.getUserId(),httpServletRequest.getSession());
		if(requestValidatedFlag){
			auditService.insertAuditLog(auditVo);
		}
		else{
			log.warn(BNPConstants.UNAUTHORIZED_ACCESS);
			httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		}
	}

}