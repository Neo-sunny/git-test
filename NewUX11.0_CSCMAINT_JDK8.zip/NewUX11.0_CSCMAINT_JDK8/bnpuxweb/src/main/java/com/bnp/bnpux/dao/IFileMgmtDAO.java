/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14 Mar 2017
 * 
 * Purpose:       File Management Interface for Data Access Object
 * 
 * Change History: 
 * Date                       		Author                                      Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 14 Mar 2017			            skbhaska					                Initial Version - FO 10.0 - S2005, S2007
 * 28 Mar 2017						belangov									PO / Invoice / Credit note  List view - S2013
 * 29 Mar 2017                      srreshmi                                    S2022, S2024-Pre approved supplier list and Discount type attachment list 
 * 04 Apr 2017                      Divyashri                                   S2020 -Invoice Settlement list details
 * 08-May-2017				        Bala Murugan Elangovan						File Upload - Polling Logic implementation
************************************************************************************************************************************************************/
package com.bnp.bnpux.dao;

import java.util.List;

import com.bnp.bnpux.common.vo.FileMgmtAttachmentListVO;
import com.bnp.bnpux.common.vo.FileMgmtInvSettleListVO;
import com.bnp.bnpux.common.vo.FileMgmtInvoiceListVO;
import com.bnp.bnpux.common.vo.FileMgmtListVO;
import com.bnp.bnpux.common.vo.FileMgmtPOListVO;
import com.bnp.bnpux.common.vo.FileMgmtPreAppSuppListVO;
import com.bnp.bnpux.common.vo.FileMgmtRolloverStlVO;
import com.bnp.bnpux.common.vo.FileMgmtSummaryVO;
import com.bnp.bnpux.vo.requestVO.FileMgmtRequestVO;
import com.bnp.bnpux.vo.requestVO.FileUploadRequestVO;
import com.bnp.bnpux.vo.requestVO.ReleaseFileMgmtRequestVO;
import com.bnp.bnpux.vo.responseVO.FileMgmtResponseVO;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;

public interface IFileMgmtDAO {

	/**
	 * This method is for getting File Management Summary
	 * 
	 * @param paramMap
	 * @return
	 */
	List<FileMgmtSummaryVO> getFileMgmtSummary(FileMgmtRequestVO fileMgmtRequestVO);
	
	
	/**
	 * This method is for getting File Management summary with Advanced Filters 
	 * @param FileMgmtRequestVO
	 * @return
	 */
	List<FileMgmtSummaryVO> getFileMgmtSummaryWithAdvFilter(FileMgmtRequestVO fileMgmtRequestVO);
	
	
	/**
	 * This method is for getting File Management summary with Advanced Filters count
	 * @param FileMgmtRequestVO
	 * @return
	 */
	List<FileMgmtSummaryVO> getAdvancedFilterCount(FileMgmtRequestVO fileMgmtRequestVO);
	
	
	/**
	 * This method is for getting File Management List
	 * 
	 * @param paramMap
	 * @return
	 */
	List<FileMgmtListVO> getFileMgmtList(FileMgmtRequestVO paymentOrderRequestVO);
	
	
	/**
	 * This method is for getting File Management List with Advanced Filters 
	 * @param FileMgmtRequestVO
	 * @return
	 */
	List<FileMgmtListVO> getFileMgmtListWithAdvFilter(FileMgmtRequestVO fileMgmtRequestVO);
	
	
	/**
	 * This method is for getting File Management List Details
	 * 
	 * @param paramMap
	 * @return
	 */
	List<FileMgmtListVO> getFileMgmtListDetails(FileMgmtRequestVO fileMgmtRequestVO);


	/**
	 * This method is for getting File Management PO List Details
	 * @param fileMgmtRequestVO
	 * @return
	 */
	List<FileMgmtPOListVO> getFileManagementPODetails(FileMgmtRequestVO fileMgmtRequestVO);

	/**
	 * This method is for getting File Management PO List Details
	 * @param fileMgmtRequestVO
	 * @return
	 */
	List<FileMgmtInvSettleListVO> getFileManagementInvSettleDetails(FileMgmtRequestVO fileMgmtRequestVO);
	
	/**
	 * This method is for getting File Management Invoice List Details
	 * @param fileMgmtRequestVO
	 * @return
	 */
	List<FileMgmtInvoiceListVO> getFileManagementInvoiceDetails(FileMgmtRequestVO fileMgmtRequestVO);
	/**
	 * This method is for getting File Management PS List Details
	 * @param fileMgmtRequestVO
	 * @return
	 */

	List<FileMgmtPreAppSuppListVO> getFileManagementPSDetails(FileMgmtRequestVO fileMgmtRequestVO);
	/**
	 * This method is for getting File Management DA List Details
	 * @param fileMgmtRequestVO
	 * @return
	 */

	List<FileMgmtAttachmentListVO> getFileManagementDADetails(FileMgmtRequestVO fileMgmtRequestVO);
	
	/**
	 * This method is for getting File Management RS List Details
	 * @param fileMgmtRequestVO
	 * @return
	 */

	List<FileMgmtRolloverStlVO>getFileManagementRSDetails(FileMgmtRequestVO fileMgmtRequestVO);
	
	
	/**
	 * This method is for getting Release File List Details
	 * 
	 * @param paramMap
	 * @return
	 */
	List<FileDetailsVO> getReleaseFileDetailsVO(ReleaseFileMgmtRequestVO releaseFileRequestVo);
	
	/**
	 * This method is for getting AttachmentList
	 * 
	 * @param paramMap
	 * @return
	 */	
	List<FileMgmtAttachmentListVO> getFMAttachmentList(FileMgmtRequestVO fileMgmtRequestVO);


	/**
	 * 
	 * @param fileUploadRequestVO
	 * @return
	 */
	List<FileMgmtResponseVO> getUpdatedFileUploadStatus(FileUploadRequestVO fileUploadRequestVO);

	
	
}
