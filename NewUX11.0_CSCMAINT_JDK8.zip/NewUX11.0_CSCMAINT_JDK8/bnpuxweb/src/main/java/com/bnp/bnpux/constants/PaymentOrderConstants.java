/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Payment Order Constants
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.constants;

public interface PaymentOrderConstants {

	public final static String PAYMENT_ORDER_USER_ID = "userId";
	
	public final static String PAYMENT_ORDER_USER_TYPE_ID = "userTypeId";
	
	public final static String RECORD_FROM = "recordFrom";
	
	public final static String RECORD_TO = "recordTo";
	
	public final static String MATURITY_FILTER = "maturityFilter";
	
	public final static String ADVANCE_FILTER = "advanceFilter";

	public static final String PAYMENT_ORDER_SUMMARY = "paymentdetails";

	public static final String PAYMENT_ORDER_UNABLE_TO_GET_DETAILS = "Unable to get the Payment Order Details";

	public static final String PAYMENT_ORDER_ERROR_FLAG = "errorFlag";

	public static final String PAYMENT_ORDER_ERROR_DETAILS = "Database Error Flag : ";

	public static final String PAYMENT_ORDER_LIST = "paymentOrderList";
	
	public static final String PAYMENT_ORDER_LIST_DETAILS = "paymentOrderListDetails";

	public static final String GROUP_INT = "groupInd";

	public static final String MATURITY_DATE = "maturityDate";

	public static final String VIEW_TYPE = "viewType";

	public static final String VIEW_TYPE_PAYMENT = "PAYMENT";

	public static final String VIEW_TYPE_MATURITY = "MATURITY";
	
	public static final String VIEW_TYPE_PAYMENT_LIST = "PAYMENT_LIST";
	
	public static final String VIEW_TYPE_PAYMENT_LIST_DETAILS = "PAYMENT_LIST_DETAILS";
	
	public static final String BUYER_ORG_ID = "buyerOrgId";
	
	public static final String SUPPLIER_ORG_ID = "supplierOrgId";
	
	public static final String CURRENCY_CODE = "currencyCode";

	public static final String BUYER_UNIQUE_REFERNCE_ID = "buyerRefNumberUnique";
	
	public static final String PAYMENT_ORDER_EXCEPTION = "Unexpected Database Error ";

	public static final String EXCEPTION_UNABLE_TO_PROCESS = "Unable to Get Payment Order Details - Database Exception";
	
	public static final String EXCEPTION_UNABLE_TO_PROCESS_PO_CALLOUT = "Unable to Get Payment Order Callout Details - Database Exception";

	public static final String DISC_REQ_NO = "discRefNo";
	
	public static final String AVLBLE_AMT_GRTR_ZERO = "Available Amount should be greater than zero";
	
	public static final String AVLBLE_AMT_LSR_DISC_AMT = "Available Amount should be less than Discount Amount";
	
	public static final String LEAD_ORG_ID = "leadOrgId";
	
	public static final String ORG_ID = "orgId";

	public static final String FILTER_STATUS = "filterStatus";
	public static final String FILTER_PERIOD = "filterPeriod";
	public static final String FILTER_BRANCH = "filterBranch";
	
	public static final String QUICK_SEARCH = "quickSearchText";
	
	public final static String PAYMENT_ORDER_CREDIT_NOTE_LINE_ITEM_ID = "cnt_id";
	
	public static final String PAYMENT_ORDER_CREDIT_NOTE_LINE_ITEM_SUMMARY = "result_set";
	
	public static final String PAYMENT_ORDER_CREDIT_NOTE_LINE_ITEM_ERROR_FLAG =  "error_result";
	
	public static final String PAYMENT_ORDER_CREDIT_NOTE_LINE_ITEM_EROR_MSG = "error_msg"; 
	
	public static final String PAYMENT_ORDER_INVOICE_DETAILS_CALL_OUT_INV_ID = "inv_id";
	
	public static final String PAYMENT_ORDER_INVOICE_DETAILS_CALL_OUT_SUMMARY = "result_set";
	
	public static final String PAYMENT_ORDER_ERROR_MSG = "error_msg";
	
	public static final String PAYMENT_ORDER_PAYMENT_ID = "paymentID";
	public static final String DISCOUNT_REQUEST = "REQUEST";
	public static final String DISCOUNT_RECALCULATE = "RECALCULATE";

	// Added For User Stories - Recall - Starts
	
	public static final String RECALL_REQUEST = "RECALL REQUEST";
	public static final String RECALL_APPROVE = "RECALL APPROVE";
	public static final String RECALL_UNDO = "RECALL UNDO";
	
	public static final String BRANCH_ID = "branchId";
	
	// Added For User Stories - Recall - Ends
	
	public static final String PO_REF_POPUP = "PO_REF_POPUP";
	
	public static final String ADV_FLTR_GET = "GET";
	
	public static final String ADV_FLTR_DELETE = "DELETE";
	
	public static final String DATE_FORMAT_DD_MMM_YYY = "dd-MMM-yyyy"; //Fo 10.0 S038
	
	
}
