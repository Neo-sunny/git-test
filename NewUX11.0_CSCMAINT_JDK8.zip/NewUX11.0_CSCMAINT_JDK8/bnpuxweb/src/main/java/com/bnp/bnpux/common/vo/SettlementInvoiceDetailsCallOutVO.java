/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Settlement Invoice Details CallOut Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;


public class SettlementInvoiceDetailsCallOutVO {

	private String supItemNo;
	private String itemPartNo;
	private String  itemDesc;
	private String itemUOM;
	private BigDecimal itemQty;
	private BigDecimal itemUnitPrice;
	private BigDecimal itemTotalPrice;
	private String itemPoNo;
	private String error_result;
	private String error_msg;

	public 	SettlementInvoiceDetailsCallOutVO(){		
	}
	
	public String getSupItemNo() {
		return supItemNo;
	}
	public void setSupItemNo(String supItemNo) {
		this.supItemNo = supItemNo;
	}
	public String getItemPartNo() {
		return itemPartNo;
	}
	public void setItemPartNo(String itemPartNo) {
		this.itemPartNo = itemPartNo;
	}
	public String getItemDesc() {
		return itemDesc;
	}
	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}
	public String getItemUOM() {
		return itemUOM;
	}
	public void setItemUOM(String itemUOM) {
		this.itemUOM = itemUOM;
	}	
	public String getItemPoNo() {
		return itemPoNo;
	}
	public void setItemPoNo(String itemPoNo) {
		this.itemPoNo = itemPoNo;
	}
	public String getError_result() {
		return error_result;
	}
	public void setError_result(String error_result) {
		this.error_result = error_result;
	}
	public String getError_msg() {
		return error_msg;
	}
	public void setError_msg(String error_msg) {
		this.error_msg = error_msg;
	}

	public BigDecimal getItemQty() {
		return itemQty;
	}

	public void setItemQty(BigDecimal itemQty) {
		this.itemQty = itemQty;
	}

	public BigDecimal getItemUnitPrice() {
		return itemUnitPrice;
	}

	public void setItemUnitPrice(BigDecimal itemUnitPrice) {
		this.itemUnitPrice = itemUnitPrice;
	}

	public BigDecimal getItemTotalPrice() {
		return itemTotalPrice;
	}

	public void setItemTotalPrice(BigDecimal itemTotalPrice) {
		this.itemTotalPrice = itemTotalPrice;
	}

	
	/**
	 * Getter methods introduced to send the amounts as
	 * String to avoid amount > 16 digits getting truncated
	 * Added as part of defect Fix CSC-7835
	 */
	

	public String getItemQtyStr() {
		return (itemQty!=null)?itemQty.toPlainString():"";
	}
	
	public String getItemUnitPriceStr() {
		return (itemUnitPrice!=null)?itemUnitPrice.toPlainString():"";
	}

	public String getItemTotalPriceStr() {
		return (itemTotalPrice!=null)?itemTotalPrice.toPlainString():"";
	}
	
	/**End of CSC-7835 Changes**/


}
