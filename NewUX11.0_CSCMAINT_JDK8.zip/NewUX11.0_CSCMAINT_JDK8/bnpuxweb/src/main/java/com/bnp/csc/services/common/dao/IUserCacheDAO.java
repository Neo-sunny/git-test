/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:      Cache Data Access Object Interface
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
************************************************************************************************************************************************************/
package com.bnp.csc.services.common.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.bnp.csc.services.common.vo.BranchVO;

public interface IUserCacheDAO {

	/**
	 * @param userId
	 * @return Date
	 * @Description To get Branch details for login User
	 */
	public List<BranchVO> getBranchDetailsForLoginUser(String userId);
	/**
	 * @param params
	 * @return Date
	 * @Description To get Holiday Adjusted Date
	 */
	public Date getHolidayAdjustedDate(Map<String,Object> params);
	/**
	 * @param params 
	 * @Description To get Next Business Day
	 */
	public void getNextBusinessDay(Map<String,Object> params);
}
