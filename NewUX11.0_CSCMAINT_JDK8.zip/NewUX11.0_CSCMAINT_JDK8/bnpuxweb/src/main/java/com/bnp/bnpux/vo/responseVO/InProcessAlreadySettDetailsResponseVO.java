package com.bnp.bnpux.vo.responseVO;

import java.util.List;

//import com.bnp.bnpux.common.vo.PaymentOrderInvoiceDetailsCallOutVO;
import com.bnp.bnpux.common.vo.InProcessAlreadySettCalloutVO;

public class InProcessAlreadySettDetailsResponseVO {

private String error_msg;	
private String error_result;

public String getError_result() {
	return error_result;
}

public void setError_result(String error_result) {
	this.error_result = error_result;
}

public String getError_msg() {
	return error_msg;
}

public void setError_msg(String error_msg) {
	this.error_msg = error_msg;
}

	/* Changed below variable name to maintain for both In process and Already Paid Callouts*/
	
	private List<InProcessAlreadySettCalloutVO> settlementInprocessAlreadySettlemntDetailsCalloutVO;

	public List<InProcessAlreadySettCalloutVO> getSettlementInprocessAlreadySettlemntDetailsCalloutVO() {
		return settlementInprocessAlreadySettlemntDetailsCalloutVO;
	}

	public void setSettlementInprocessAlreadySettlemntDetailsCalloutVO(
			List<InProcessAlreadySettCalloutVO> settlementInprocessAlreadySettlemntDetailsCalloutVO) {
		this.settlementInprocessAlreadySettlemntDetailsCalloutVO = settlementInprocessAlreadySettlemntDetailsCalloutVO;
	}

	
	
	
}
