package com.bnp.bnpux.service;

import java.util.List;

import com.bnp.bnpux.vo.requestVO.RemittanceRequestVO;
import com.bnp.bnpux.vo.responseVO.RemittanceResponseVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface IRemittanceReportService {

	/**
	 * This method is for getting Remittance Report details
	 * 
	 * @param RemittanceResponseVO
	 * @return
	 * @throws BNPApplicationException
	 */
	RemittanceRequestVO getReportSummary(RemittanceRequestVO requestVo) throws BNPApplicationException;


	/**
	 * This method is for getting Remittance Report details
	 * 
	 * @param RemittanceResponseVO
	 * @return
	 * @throws BNPApplicationException
	 */
	RemittanceRequestVO getReportDetails(RemittanceRequestVO requestVo) throws BNPApplicationException;

	
	/**
	 * This method is for getting Remittance report chart axis 
	 * 
	 * @param requestVo
	 * @return
	 * @throws BNPApplicationException
	 */
	List<ReportChartResponseVO> getReportChartAxis (RemittanceRequestVO requestVo)throws BNPApplicationException;

}
