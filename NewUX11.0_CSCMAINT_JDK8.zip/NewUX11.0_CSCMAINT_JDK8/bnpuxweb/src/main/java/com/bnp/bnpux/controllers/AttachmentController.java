/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Attachment Controller
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.constants.AttachmentConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.AttachmentVO;
import com.bnp.bnpux.service.INewAttachmentService;
import com.bnp.bnpux.vo.requestVO.AttachmentRequestVO;
import com.bnp.bnpux.vo.requestVO.SCFAttachUploadRequestVO;
import com.bnp.bnpux.vo.responseVO.AttachmentResponseVO;
import com.bnp.bnpux.wrappers.service.ISCFAttachFileUploadWrapperService;

@RestController
@RequestMapping("/attchCtrl")
public class AttachmentController {
	
	public static final Logger log = LoggerFactory.getLogger(AttachmentController.class);
	
	@Autowired
	private INewAttachmentService attachmentService;
	
	@Autowired
	private ISCFAttachFileUploadWrapperService iscfAttachFileUploadWrapperService;
	
	/**
	 * Method to download Attachment
	 * 
	 * @param attachmentRequestVO
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = AttachmentConstants.ATTACH_REST_GET_ATTACHMENT_DATA, method = RequestMethod.POST)
	public void downloadSCFAttachment(@RequestBody AttachmentRequestVO attachmentRequestVO, HttpServletRequest request,HttpServletResponse response) {
		System.out.println("Inside downloadSCFAttachment");
		AttachmentResponseVO attachmentResponseVO = new AttachmentResponseVO();
		try {
			attachmentResponseVO = attachmentService.downloadSCFAttachment(attachmentRequestVO);			response.setContentType("application/zip");
			response.setHeader("Content-Disposition","attachment;filename=\"" + AttachmentConstants.SCF_FILE_NAME + "\"");
			response.setContentLength(attachmentResponseVO.getData().length);
		    try {
				response.getOutputStream().write(attachmentResponseVO.getData());
				response.getOutputStream().close();
			} catch (IOException e) {
				log.error(e.getMessage(),e);
			}
	        
		} catch (BNPApplicationException exception) {
			attachmentResponseVO.setErrorMsg(exception.getMessage());
			log.error(exception.getMessage(),exception);			
		}	
	}
	
	@RequestMapping(value = "getSCFUploadAttachment.rest", method = RequestMethod.POST)
	public void downloadSCFUploadAttachment(@RequestBody SCFAttachUploadRequestVO scfAttachUploadRequestVO, HttpServletRequest request,HttpServletResponse response) {
		System.out.println("Inside downloadSCFAttachment");
		AttachmentResponseVO attachmentResponseVO = new AttachmentResponseVO();
		try {
			AttachmentVO selectedRow = scfAttachUploadRequestVO.getRemoveAttachVO();
			if (selectedRow != null && selectedRow.getAttachOper()!= null && (selectedRow.getAttachOper().equalsIgnoreCase("ADD") || selectedRow.getAttachOper().equalsIgnoreCase("DEL"))) {
				List<AttachmentVO> attachVOList = new ArrayList<AttachmentVO>();
				attachVOList.add(selectedRow);
				if(attachVOList != null){
					attachmentResponseVO = attachmentService.downLoadSingleSCFAttachment(attachVOList);
				}
			}
			else{
				AttachmentRequestVO attachmentRequestVO = new AttachmentRequestVO();
				attachmentRequestVO.setSeqNo(scfAttachUploadRequestVO.getSeqNo());
				attachmentRequestVO.setFileName(scfAttachUploadRequestVO.getFileName());
				attachmentResponseVO = attachmentService.downloadSCFAttachment(attachmentRequestVO);	
			}
			response.setContentType("application/zip");
			response.setHeader("Content-Disposition","attachment;filename=\"" + AttachmentConstants.SCF_FILE_NAME + "\"");
			response.setContentLength(attachmentResponseVO.getData().length);
		    try {
				response.getOutputStream().write(attachmentResponseVO.getData());
				response.getOutputStream().close();
			} catch (IOException e) {
				log.error(e.getMessage(),e);
			}
	        
		} catch (BNPApplicationException exception) {
			attachmentResponseVO.setErrorMsg(exception.getMessage());
			log.error(exception.getMessage(),exception);			
		}	
	}
	/**
	 * Method to download all attachments
	 * 
	 * @param attachmentRequestVO
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = AttachmentConstants.ATTACH_REST_GET_ALL_ATTACHMENT_DATA, method = RequestMethod.POST)
	public void downloadAllSCFAttachment(@RequestBody AttachmentRequestVO attachmentRequestVO, HttpServletRequest request,HttpServletResponse response) {		
		AttachmentResponseVO attachmentResponseVO = new AttachmentResponseVO();
		try {
			attachmentResponseVO = attachmentService.downloadAllSCFAttachment(attachmentRequestVO);
			response.setHeader("Content-Disposition","attachment;filename=\"" + AttachmentConstants.SCF_FILE_NAME + "\"");
			
			try {
				response.getOutputStream().write(attachmentResponseVO.getData());
				response.getOutputStream().close();
			} catch (IOException e) {
				log.error(e.getMessage(),e);
			}
			
		} catch (BNPApplicationException exception) {
			attachmentResponseVO.setErrorMsg(exception.getMessage());
			log.error(exception.getMessage(),exception);	
		}
	}
}
