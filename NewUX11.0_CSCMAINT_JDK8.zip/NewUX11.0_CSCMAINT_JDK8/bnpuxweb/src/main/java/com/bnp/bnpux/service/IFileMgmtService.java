/*****************************************************************************************************************************************************************
 * Author: Oracle Financial Services Software Ltd for BNP Paribas.
 * 
 * Created on:   14-March-2017	
 * 
 * Purpose:      File Management Service Interface
 * 
 * Change History: 
 * Date                                    Author                                                                               Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 14-March-2017			              Sree Reshmi						                                                    Initial Version
 * 08-May-2017				        Bala Murugan Elangovan							                              File Upload - Polling Logic implementation
 * *****************************************************************************************************************************************************************/
package com.bnp.bnpux.service;

import com.bnp.bnpux.common.vo.ReleaseFileMgmtResponseVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.vo.requestVO.FileMgmtRequestVO;
import com.bnp.bnpux.vo.requestVO.FileUploadRequestVO;
import com.bnp.bnpux.vo.requestVO.ReleaseFileMgmtRequestVO;
import com.bnp.bnpux.vo.responseVO.FileMgmtResponseVO;
import com.bnp.bnpux.vo.responseVO.FileUploadResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface IFileMgmtService {

	/**
	 * This method is for getting File Management Details
	 * 
	 * @param FileMgmtRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	FileMgmtResponseVO getFileManagementDetails(FileMgmtRequestVO fileMgmtRequestVO) throws BNPApplicationException;
	
	
	/**
	 * This method is for getting File Management count for Advanced filter
	 * 
	 * @param FileMgmtRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	FileMgmtResponseVO getAdvancedFilterCount(FileMgmtRequestVO fileMgmtRequestVO) throws BNPApplicationException;

	/**
	 * This method is for undo File Upload Request Details
	 * 
	 * @param user
	 * 
	 * @param ReleaseFileMgmtRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	ReleaseFileMgmtResponseVO undoFileUploadRequest(ReleaseFileMgmtRequestVO releaseFileMgmtRequestVo, UserInfoVO user)
			throws BNPApplicationException;

	/**
	 * @param user
	 * @param ReleaseFileMgmtRequestVO
	 * @return
	 */
	ReleaseFileMgmtResponseVO releaseFileUploadRequest(ReleaseFileMgmtRequestVO releaseFileMgmtRequestVo,
			UserInfoVO user) throws BNPApplicationException;

	/**
	 * @param releaseFileMgmtRequestVo
	 * @param user
	 * @return
	 * @throws BNPApplicationException
	 */
	ReleaseFileMgmtResponseVO authorizeFileUploadRequest(ReleaseFileMgmtRequestVO releaseFileMgmtRequestVo,
			UserInfoVO user) throws BNPApplicationException;

	/**
	 * @param releaseFileMgmtRequestVO
	 * @param user
	 * @return
	 * @throws BNPApplicationException
	 */
	ReleaseFileMgmtResponseVO rejectFile(ReleaseFileMgmtRequestVO releaseFileMgmtRequestVO, UserInfoVO user)
			throws BNPApplicationException;

	/**
	 * Method is used to get updated file upload status
	 * 
	 * @param fileMgmtRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	FileUploadResponseVO getUpdatedFileUploadStatus(FileUploadRequestVO fileUploadResponseVO) throws BNPApplicationException;

	/**
	 * Method is used to get Attachment List
	 * 
	 * @param fileMgmtRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	FileMgmtResponseVO getAttachmentList(FileMgmtRequestVO fileMgmtRequestVO) throws BNPApplicationException;

}
