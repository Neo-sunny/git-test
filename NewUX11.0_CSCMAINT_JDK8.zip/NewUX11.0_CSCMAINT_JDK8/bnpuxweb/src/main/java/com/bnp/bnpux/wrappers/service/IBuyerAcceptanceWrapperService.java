/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 March 2017
 * 
 * Purpose:      Release File Functionality
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 March 2017            Oracle Financial Services Software Ltd                  Initial Version 
 * 27 March 2017            Bhuvaneswari                                            S2034 File managementUndo action 
 *  *  *************************************************************************************************************************************************************/
package com.bnp.bnpux.wrappers.service;

import java.util.List;

import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.vo.responseVO.BuyerAcceptanceResponseVO;
import com.bnp.scm.services.invoice.vo.BuyerAcceptanceVO;

public interface IBuyerAcceptanceWrapperService {

	/**
	 * @param user 
	 * @param detailsVOList 
	 * @return 
	 * 
	 */
	BuyerAcceptanceResponseVO undoInvoice(List<BuyerAcceptanceVO> detailsVOList, UserInfoVO user, BuyerAcceptanceResponseVO responseVO);

	
	/**
	 * @param detailsVOList
	 * @param user
	 * @return
	 */
	BuyerAcceptanceResponseVO approveInvoice(List<BuyerAcceptanceVO> detailsVOList, UserInfoVO user, BuyerAcceptanceResponseVO responseVO);

	/**
	 * @param detailsVOList
	 * @param user
	 * @return
	 */
	BuyerAcceptanceResponseVO rejectInvoice(List<BuyerAcceptanceVO> detailsVOList, UserInfoVO user, BuyerAcceptanceResponseVO responseVO);
	
	/**
	 * @param detailsVOList
	 * @param user
	 * @param responseVO 
	 * @return
	 */

	BuyerAcceptanceResponseVO acceptInvoice(List<BuyerAcceptanceVO> detailsVOList, UserInfoVO user, BuyerAcceptanceResponseVO responseVO);

	
}
