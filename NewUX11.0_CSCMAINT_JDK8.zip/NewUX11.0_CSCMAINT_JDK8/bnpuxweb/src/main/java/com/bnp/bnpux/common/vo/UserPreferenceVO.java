/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      User Preference Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.util.List;
import java.util.TimeZone;

import com.bnp.bnpux.constants.CacheConstants;
import com.bnp.scm.services.common.vo.NameValueVO;

public class UserPreferenceVO {

	/** The date format list. */
	private List<NameValueVO> dateFormatList;
	
	/** The amount format list. */
	private List<NameValueVO> amountFormatList;
	
	/** The preferred date fmt. */
	private String preferredDateFmt;
	
	/** The preferred amt fmt. */
	private String preferredAmtFmt;
	
	/** The preferred date fmt with24 hours time. */
	private String preferredDateFmtWith24HoursTime;
	
	/** The default home page. */
	private String defaultHomePage;
	
	/** The user id. */
	private String userId;
	
	/** The country zone list. */
	private List<NameValueVO> countryZoneList;
	
	/** The language list. */
	private List<NameValueVO> languageList;
	
	/** The country zone. */
	private String countryZone;
	
	/** The language. */
	private String language;
	
	/** The time zone in gmt. */
	private String timeZoneInGMT;
	
	/** The time zone. */
	private TimeZone timeZone;
	
	/** The sup branch t zone in gmt. */
	private String supBranchTZoneInGMT;
	
	/** The sup branch t zone. */
	private TimeZone supBranchTZone;
	
	/** The support branch tzid. */
	private String supportBranchTZID;
	
	/** The primary org deal type. */
	private String primaryOrgDealType;
	
	/** The primary locale */
	private String locale;
	
	/** Time Zone List */
	private List<NameValueVO> timeZoneCodeList;	
	
	private List<NameValueVO> localeAmtFrmtList;
	
	/**
	 * Gets the timezonecode list
	 *
	 * @return List<NameValueVO> timeZoneCodeList
	 */
	public List<NameValueVO> getTimeZoneCodeList() {
		return timeZoneCodeList;
	}

	/**
	 * sets the timezonecode list
	 *
	 * @return the default home page
	 */
	public void setTimeZoneCodeList(List<NameValueVO> timeZoneCodeList) {
		this.timeZoneCodeList = timeZoneCodeList;
	}

	/**
	 * Gets the locale.
	 *
	 * @return the locale 
	 */
	public String getLocale() {
		return locale;
	}

	/**
	 * Sets the locale
	 *
	 * @param loacle
	 */
	public void setLocale(String locale) {
		this.locale = locale;
	}

	/**
	 * Gets the default home page.
	 *
	 * @return the default home page
	 */
	public String getDefaultHomePage() {
		return defaultHomePage;
	}
	
	/**
	 * Sets the default home page.
	 *
	 * @param defaultHomePage the new default home page
	 */
	public void setDefaultHomePage(String defaultHomePage) {
		this.defaultHomePage = defaultHomePage;
	}
	
	/**
	 * Gets the preferred date fmt with24 hours time.
	 *
	 * @return the preferred date fmt with24 hours time
	 */
	public String getPreferredDateFmtWith24HoursTime() {
      if(preferredDateFmtWith24HoursTime==null)
	    preferredDateFmtWith24HoursTime=CacheConstants.DEFAULT_DATE_FORMAT_WITH_24TIME;
		return preferredDateFmtWith24HoursTime;
	}
		
	/**
	 * Sets the preferred date fmt with24 hours time.
	 *
	 * @param preferredDateFmtWith24HoursTime the new preferred date fmt with24 hours time
	 */
	public void setPreferredDateFmtWith24HoursTime(String preferredDateFmtWith24HoursTime) {
	  this.preferredDateFmtWith24HoursTime = preferredDateFmtWith24HoursTime;
	}
		
	/**
	 * Gets the date format list.
	 *
	 * @return the date format list
	 */
	public List<NameValueVO> getDateFormatList() {
		return dateFormatList;
	}
	
	/**
	 * Sets the date format list.
	 *
	 * @param dateFormatList the new date format list
	 */
	public void setDateFormatList(List<NameValueVO> dateFormatList) {
	  this.dateFormatList = dateFormatList;
	}
	
	/**
	 * Gets the amount format list.
	 *
	 * @return the amount format list
	 */
	public List<NameValueVO> getAmountFormatList() {
	  return amountFormatList;
	}
	
	/**
	 * Sets the amount format list.
	 *
	 * @param amountFormatList the new amount format list
	 */
	public void setAmountFormatList(List<NameValueVO> amountFormatList) {
	  this.amountFormatList = amountFormatList;
	}
	
	/**
	 * Gets the preferred date fmt.
	 *
	 * @return the preferred date fmt
	 */
	public String getPreferredDateFmt() {
	  if(preferredDateFmt==null)
	    preferredDateFmt=CacheConstants.DEFAULT_DATE_FORMAT;
	  return preferredDateFmt;
	}
	
	/**
	 * Sets the preferred date fmt.
	 *
	 * @param preferredDateFmt the new preferred date fmt
	 */
	public void setPreferredDateFmt(String preferredDateFmt) {
		this.preferredDateFmt = preferredDateFmt;
	}
	
	/**
	 * Gets the preferred amt fmt.
	 *
	 * @return the preferred amt fmt
	 */
	public String getPreferredAmtFmt() {
	  if(preferredAmtFmt==null)
	    preferredAmtFmt=CacheConstants.US_LOCALE;
	  return preferredAmtFmt;
	}
	
	/**
	 * Sets the preferred amt fmt.
	 *
	 * @param preferredAmtFmt the new preferred amt fmt
	 */
	public void setPreferredAmtFmt(String preferredAmtFmt) {
	  this.preferredAmtFmt = preferredAmtFmt;
	}
	
	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
	  this.userId = userId;
	}
	
	/**
	 * Gets the country zone list.
	 *
	 * @return the country zone list
	 */
	public List<NameValueVO> getCountryZoneList() {
	  return countryZoneList;
	}
	
	/**
	 * Sets the country zone list.
	 *
	 * @param countryZoneList the new country zone list
	 */
	public void setCountryZoneList(List<NameValueVO> countryZoneList) {
	  this.countryZoneList = countryZoneList;
	}
	
	/**
	 * Gets the country zone.
	 *
	 * @return the country zone
	 */
	public String getCountryZone() {
	  return countryZone;
	}
	
	/**
	 * Sets the country zone.
	 *
	 * @param countryZone the new country zone
	 */
	public void setCountryZone(String countryZone) {
	  this.countryZone = countryZone;
	}
	
	/**
	 * Gets the language list.
	 *
	 * @return the language list
	 */
	public List<NameValueVO> getLanguageList() {
	  return languageList;
	}
	
	/**
	 * Sets the language list.
	 *
	 * @param languageList the new language list
	 */
	public void setLanguageList(List<NameValueVO> languageList) {
	  this.languageList = languageList;
	}
	
	/**
	 * Gets the language.
	 *
	 * @return the language
	 */
	public String getLanguage() {
	  return language;
	}
	
	/**
	 * Sets the language.
	 *
	 * @param language the new language
	 */
	public void setLanguage(String language) {
	  this.language = language;
	}
	
	/**
	 * Gets the time zone.
	 *
	 * @return the time zone
	 */
	public TimeZone getTimeZone() {
	  return TimeZone.getTimeZone(getTimeZoneInGMT());
	}
	
	/**
	 * Sets the time zone.
	 *
	 * @param timeZone the new time zone
	 */
	public void setTimeZone(TimeZone timeZone) {
	  this.timeZone = timeZone;
	}
	
	/**
	 * Gets the time zone in gmt.
	 *
	 * @return the time zone in gmt
	 */
	public String getTimeZoneInGMT() {
	  if(timeZoneInGMT==null){
	    timeZoneInGMT="GMT+08:00";
	  }
	  return timeZoneInGMT;
	}
	
	/**
	 * Sets the time zone in gmt.
	 *
	 * @param timeZoneInGMT the new time zone in gmt
	 */
	public void setTimeZoneInGMT(String timeZoneInGMT) {
	  this.timeZoneInGMT = timeZoneInGMT;
	}
	
	/**
	 * Gets the sup branch t zone in gmt.
	 *
	 * @return the sup branch t zone in gmt
	 */
	public String getSupBranchTZoneInGMT() {
	  if(supBranchTZoneInGMT==null){
	    supBranchTZoneInGMT="GMT+08:00";
	  }
	  return supBranchTZoneInGMT;
	}
	
	/**
	 * Sets the sup branch t zone in gmt.
	 *
	 * @param supBranchTZoneInGMT the new sup branch t zone in gmt
	 */
	public void setSupBranchTZoneInGMT(String supBranchTZoneInGMT) {
	  this.supBranchTZoneInGMT = supBranchTZoneInGMT;
	}
	
	/**
	 * Gets the sup branch t zone.
	 *
	 * @return the sup branch t zone
	 */
	public TimeZone getSupBranchTZone() {
	  return TimeZone.getTimeZone(getSupBranchTZoneInGMT());
	}
	
	/**
	 * Sets the sup branch t zone.
	 *
	 * @param supBranchTZone the new sup branch t zone
	 */
	public void setSupBranchTZone(TimeZone supBranchTZone) {
	  this.supBranchTZone = supBranchTZone;
	}
	
	/**
	 * Gets the primary org deal type.
	 *
	 * @return the primary org deal type
	 */
	public String getPrimaryOrgDealType() {
	  return primaryOrgDealType;
	}
	
	/**
	 * Sets the primary org deal type.
	 *
	 * @param primaryOrgDealType the new primary org deal type
	 */
	public void setPrimaryOrgDealType(String primaryOrgDealType) {
		this.primaryOrgDealType = primaryOrgDealType;
	}
	
	/**
	 * Sets the support branch tzid.
	 *
	 * @param supportBranchTZID the supportBranchTZID to set
	 */
	public void setSupportBranchTZID(String supportBranchTZID) {
		this.supportBranchTZID = supportBranchTZID;
	}
	
	/**
	 * Gets the support branch tzid.
	 *
	 * @return the supportBranchTZID
	 */
	public String getSupportBranchTZID() {
		return supportBranchTZID;
	}
	
	public List<NameValueVO> getLocaleAmtFrmtList() {
		return localeAmtFrmtList;
	}

	public void setLocaleAmtFrmtList(List<NameValueVO> localeAmtFrmtList) {
		this.localeAmtFrmtList = localeAmtFrmtList;
	}

	@Override
	public String toString() {
		return "UserPreferenceVO ["
				+ (dateFormatList != null ? "dateFormatList=" + dateFormatList
						+ ", " : "")
				+ (amountFormatList != null ? "amountFormatList="
						+ amountFormatList + ", " : "")
				+ (preferredDateFmt != null ? "preferredDateFmt="
						+ preferredDateFmt + ", " : "")
				+ (preferredAmtFmt != null ? "preferredAmtFmt="
						+ preferredAmtFmt + ", " : "")
				+ (preferredDateFmtWith24HoursTime != null ? "preferredDateFmtWith24HoursTime="
						+ preferredDateFmtWith24HoursTime + ", "
						: "")
				+ (defaultHomePage != null ? "defaultHomePage="
						+ defaultHomePage + ", " : "")
				+ (userId != null ? "userId=" + userId + ", " : "")
				+ (countryZoneList != null ? "countryZoneList="
						+ countryZoneList + ", " : "")
				+ (languageList != null ? "languageList=" + languageList + ", "
						: "")
				+ (countryZone != null ? "countryZone=" + countryZone + ", "
						: "")
				+ (language != null ? "language=" + language + ", " : "")
				+ (timeZoneInGMT != null ? "timeZoneInGMT=" + timeZoneInGMT
						+ ", " : "")
				+ (timeZone != null ? "timeZone=" + timeZone + ", " : "")
				+ (supBranchTZoneInGMT != null ? "supBranchTZoneInGMT="
						+ supBranchTZoneInGMT + ", " : "")
				+ (supBranchTZone != null ? "supBranchTZone=" + supBranchTZone
						+ ", " : "")
				+ (supportBranchTZID != null ? "supportBranchTZID="
						+ supportBranchTZID + ", " : "")
				+ (primaryOrgDealType != null ? "primaryOrgDealType="
						+ primaryOrgDealType : "") + "]";
	}
	
	
}
