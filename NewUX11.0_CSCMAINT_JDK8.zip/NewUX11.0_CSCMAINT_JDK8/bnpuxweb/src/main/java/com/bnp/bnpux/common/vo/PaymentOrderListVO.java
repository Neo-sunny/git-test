/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Payment Order List Details Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;
import java.util.Date;

public class PaymentOrderListVO {
	
	private String buyerOrgName;
	
	private String supplierOrgName;
	
	private String buyerRefNo;
	
	private String buyerRefNoUnique;
	
	private Date dueDate;
	
	private String paymentInvoiceStatus;
	
	private Date discountDate;
	
	private BigDecimal discountaAvlAmount;
	
	private BigDecimal indicatorNetAmountt;
	
	private BigDecimal alreadyPaidAmount;
	
	private BigDecimal inProgressAmount;
	
	private boolean attachmentIconInd;
	
	private boolean creditAssignIconInd;
	
	private boolean remarksIconInd;
	
	private String indDRCheckboxFlag;
	
	private boolean canDiscDateChange;
	
	private boolean canAvailAmtChange;
	
	private BigDecimal sumIndicativeNetAmount;
	
	private BigDecimal sumAlreadyPaidAmount;
	
	private BigDecimal sumSupplierBalanceAmount;
	
	private String recordCount;
	
	private String recordNumber;
	
	private BigDecimal availableAmount;
	
	private boolean callOutAvailableAmtFlag;
	
	private boolean callOutIndNetAmtFlag;
	
    private String leadingOrgId;

    private String userDiscFlag;
	
	private String errorMsg;
	
	private BigDecimal supplierBalanceAmt;	
	
	private boolean dueDateDisplay;
	
	private int remainingDays;
	
	private String discountRemarks;
	
	private boolean avlAmtDisplay;
	
	private String isEPRTrans;
	
	private boolean alreadyPaidFlg;
	
	private boolean inProcessTransFlg;
	
	private int decimalPoint;
	
	private String pymtId;
	
	private Integer attachUpldIcoFlag;
	
	/** Net Indicative Amt Call Out - Added for new UX 9.0 Sprint 3 CallOut - S172 - Starts **/
	private BigDecimal indDiscAmt;
	
	private String chargeCCYCode;
	
	private String interestCYYCode;
	
	private BigDecimal minDiscFeeAmt;
	
	private BigDecimal indChargeAmt;
	/** Net Indicative Amt Call Out - Added for new UX 9.0 Sprint 3 CallOut - S172 -  Ends**/
	
	private String branchId;
	
	private String docType;
	
	private String attchUpBrOrgNm;
	
	private String attachUpSpOrgNm;
	
	/**Payment Type Id - Added for R10.0 S33400 - Recall popup - display Updated indicative amount only for Payment deals start**/
	private String pymtType;
	
	private String updatedPymtAmount;
	
	/**Payment Type Id - Added for R10.0 S33400 - Recall popup - display Updated indicative amount only for Payment deals end **/
	
	public String getAttchUpBrOrgNm() {
		return attchUpBrOrgNm;
	}

	public void setAttchUpBrOrgNm(String attchUpBrOrgNm) {
		this.attchUpBrOrgNm = attchUpBrOrgNm;
	}

	public String getAttachUpSpOrgNm() {
		return attachUpSpOrgNm;
	}

	public void setAttachUpSpOrgNm(String attachUpSpOrgNm) {
		this.attachUpSpOrgNm = attachUpSpOrgNm;
	}
	
	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public BigDecimal getIndChargeAmt() {
		return indChargeAmt;
	}

	public void setIndChargeAmt(BigDecimal indChargeAmt) {
		this.indChargeAmt = indChargeAmt;
	}

	/** Available Amt Call Out - Added for new UX 9.0 Sprint 3 CallOut - S173 - Starts **/
	private String buyerOrgId;
	
	private String sellerOrgId;
	
	private String leadOrgId;
	
	private BigDecimal indDiscRate;
	
	private BigDecimal totalChargeAmt;
	
	private boolean recallInd;
	
	private String expandFlag;
	
	private boolean undoCallOutIndicator;
	
	private String ccyCode;
	
	private String addToBasketEligible;
	
	private String rateChargeType;
	
	private String statusKeyValue;
	
	private String statusDisplayValue;
	
	public String getStatusKeyValue() {
		return statusKeyValue;
	}

	public void setStatusKeyValue(String statusKeyValue) {
		this.statusKeyValue = statusKeyValue;
	}

	public String getStatusDisplayValue() {
		return statusDisplayValue;
	}

	public void setStatusDisplayValue(String statusDisplayValue) {
		this.statusDisplayValue = statusDisplayValue;
	}

	
	public String getRateChargeType() {
		return rateChargeType;
	}

	public void setRateChargeType(String rateChargeType) {
		this.rateChargeType = rateChargeType;
	}

	public String getAddToBasketEligible() {
		return addToBasketEligible;
	}

	public void setAddToBasketEligible(String addToBasketEligible) {
		this.addToBasketEligible = addToBasketEligible;
	}

	public String getCcyCode() {
		return ccyCode;
	}

	public void setCcyCode(String ccyCode) {
		this.ccyCode = ccyCode;
	}

	public String getExpandFlag() {
		return expandFlag;
	}

	public void setExpandFlag(String expandFlag) {
		this.expandFlag = expandFlag;
	}

	private String rateChargeFlag;
	
	
	public String getRateChargeFlag() {
		return rateChargeFlag;
	}

	public void setRateChargeFlag(String rateChargeFlag) {
		this.rateChargeFlag = rateChargeFlag;
	}

	/** Available Amt Call Out - Added for new UX 9.0 Sprint 3 CallOut - S173 - Starts **/

	public String getPymtId() {
		return pymtId;
	}

	public void setPymtId(String pymtId) {
		this.pymtId = pymtId;
	}

	public int getDecimalPoint() {
		return decimalPoint;
	}

	public void setDecimalPoint(int decimalPoint) {
		this.decimalPoint = decimalPoint;
	}

	public boolean isDueDateDisplay() {
		return dueDateDisplay;
	}

	public void setDueDateDisplay(boolean dueDateDisplay) {
		this.dueDateDisplay = dueDateDisplay;
	}

	public int getRemainingDays() {
		return remainingDays;
	}

	public void setRemainingDays(int remainingDays) {
		this.remainingDays = remainingDays;
	}

	public String getDiscountRemarks() {
		return discountRemarks;
	}

	public void setDiscountRemarks(String discountRemarks) {
		this.discountRemarks = discountRemarks;
	}

	public boolean isAvlAmtDisplay() {
		return avlAmtDisplay;
	}

	public void setAvlAmtDisplay(boolean avlAmtDisplay) {
		this.avlAmtDisplay = avlAmtDisplay;
	}

	public String getIsEPRTrans() {
		return isEPRTrans;
	}

	public void setIsEPRTrans(String isEPRTrans) {
		this.isEPRTrans = isEPRTrans;
	}

	public boolean isAlreadyPaidFlg() {
		return alreadyPaidFlg;
	}

	public void setAlreadyPaidFlg(boolean alreadyPaidFlg) {
		this.alreadyPaidFlg = alreadyPaidFlg;
	}

	public boolean isInProcessTransFlg() {
		return inProcessTransFlg;
	}

	public void setInProcessTransFlg(boolean inProcessTransFlg) {
		this.inProcessTransFlg = inProcessTransFlg;
	}

	public String getBuyerOrgName() {
		return buyerOrgName;
	}

	public void setBuyerOrgName(String buyerOrgName) {
		this.buyerOrgName = buyerOrgName;
	}

	public String getSupplierOrgName() {
		return supplierOrgName;
	}

	public void setSupplierOrgName(String supplierOrgName) {
		this.supplierOrgName = supplierOrgName;
	}

	public String getBuyerRefNo() {
		return buyerRefNo;
	}

	public void setBuyerRefNo(String buyerRefNo) {
		this.buyerRefNo = buyerRefNo;
	}

	public String getBuyerRefNoUnique() {
		return buyerRefNoUnique;
	}

	public void setBuyerRefNoUnique(String buyerRefNoUnique) {
		this.buyerRefNoUnique = buyerRefNoUnique;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public String getPaymentInvoiceStatus() {
		return paymentInvoiceStatus;
	}

	public void setPaymentInvoiceStatus(String paymentInvoiceStatus) {
		this.paymentInvoiceStatus = paymentInvoiceStatus;
	}

	public Date getDiscountDate() {
		return discountDate;
	}

	public void setDiscountDate(Date discountDate) {
		this.discountDate = discountDate;
	}

	public BigDecimal getIndicatorNetAmountt() {
		return indicatorNetAmountt;
	}

	public void setIndicatorNetAmountt(BigDecimal indicatorNetAmountt) {
		this.indicatorNetAmountt = indicatorNetAmountt;
	}

	public BigDecimal getAlreadyPaidAmount() {
		return alreadyPaidAmount;
	}

	public void setAlreadyPaidAmount(BigDecimal alreadyPaidAmount) {
		this.alreadyPaidAmount = alreadyPaidAmount;
	}

	public BigDecimal getInProgressAmount() {
		return inProgressAmount;
	}

	public void setInProgressAmount(BigDecimal inProgressAmount) {
		this.inProgressAmount = inProgressAmount;
	}
	

	public boolean isAttachmentIconInd() {
		return attachmentIconInd;
	}

	public void setAttachmentIconInd(boolean attachmentIconInd) {
		this.attachmentIconInd = attachmentIconInd;
	}
	

	public String getIndDRCheckboxFlag() {
		return indDRCheckboxFlag;
	}

	public void setIndDRCheckboxFlag(String indDRCheckboxFlag) {
		this.indDRCheckboxFlag = indDRCheckboxFlag;
	}

	public BigDecimal getSumIndicativeNetAmount() {
		return sumIndicativeNetAmount;
	}

	public void setSumIndicativeNetAmount(BigDecimal sumIndicativeNetAmount) {
		this.sumIndicativeNetAmount = sumIndicativeNetAmount;
	}

	public BigDecimal getSumAlreadyPaidAmount() {
		return sumAlreadyPaidAmount;
	}

	public void setSumAlreadyPaidAmount(BigDecimal sumAlreadyPaidAmount) {
		this.sumAlreadyPaidAmount = sumAlreadyPaidAmount;
	}

	public BigDecimal getSumSupplierBalanceAmount() {
		return sumSupplierBalanceAmount;
	}

	public void setSumSupplierBalanceAmount(BigDecimal sumSupplierBalanceAmount) {
		this.sumSupplierBalanceAmount = sumSupplierBalanceAmount;
	}

	public String getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(String recordCount) {
		this.recordCount = recordCount;
	}

	public String getRecordNumber() {
		return recordNumber;
	}

	public void setRecordNumber(String recordNumber) {
		this.recordNumber = recordNumber;
	}

	public BigDecimal getDiscountaAvlAmount() {
		return discountaAvlAmount;
	}

	public void setDiscountaAvlAmount(BigDecimal discountaAvlAmount) {
		this.discountaAvlAmount = discountaAvlAmount;
	}

	
	public BigDecimal getAvailableAmount() {
		return availableAmount;
	}

	public void setAvailableAmount(BigDecimal availableAmount) {
		this.availableAmount = availableAmount;
	}

	
	public boolean isCanDiscDateChange() {
		return canDiscDateChange;
	}

	public void setCanDiscDateChange(boolean canDiscDateChange) {
		this.canDiscDateChange = canDiscDateChange;
	}

	public boolean isCanAvailAmtChange() {
		return canAvailAmtChange;
	}

	public void setCanAvailAmtChange(boolean canAvailAmtChange) {
		this.canAvailAmtChange = canAvailAmtChange;
	}

	public boolean isCallOutAvailableAmtFlag() {
		return callOutAvailableAmtFlag;
	}

	public void setCallOutAvailableAmtFlag(boolean callOutAvailableAmtFlag) {
		this.callOutAvailableAmtFlag = callOutAvailableAmtFlag;
	}

	public boolean isCallOutIndNetAmtFlag() {
		return callOutIndNetAmtFlag;
	}

	public void setCallOutIndNetAmtFlag(boolean callOutIndNetAmtFlag) {
		this.callOutIndNetAmtFlag = callOutIndNetAmtFlag;
	}

	public String getLeadingOrgId() {
		return leadingOrgId;
	}

	public void setLeadingOrgId(String leadingOrgId) {
		this.leadingOrgId = leadingOrgId;
	}

	
	public String getUserDiscFlag() {
		return userDiscFlag;
	}

	public void setUserDiscFlag(String userDiscFlag) {
		this.userDiscFlag = userDiscFlag;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public boolean isCreditAssignIconInd() {
		return creditAssignIconInd;
	}

	public void setCreditAssignIconInd(boolean creditAssignIconInd) {
		this.creditAssignIconInd = creditAssignIconInd;
	}

	public boolean isRemarksIconInd() {
		return remarksIconInd;
	}

	public void setRemarksIconInd(boolean remarksIconInd) {
		this.remarksIconInd = remarksIconInd;
	}

	public BigDecimal getSupplierBalanceAmt() {
		return supplierBalanceAmt;
	}

	public void setSupplierBalanceAmt(BigDecimal supplierBalanceAmt) {
		this.supplierBalanceAmt = supplierBalanceAmt;
	}

	
	/** Net Indicative Amt Call Out - Added for new UX 9.0 Sprint 3 CallOut - S172 -  Starts**/
	public BigDecimal getIndDiscAmt() {
		return indDiscAmt;
	}

	public void setIndDiscAmt(BigDecimal indDiscAmt) {
		this.indDiscAmt = indDiscAmt;
	}

	public String getChargeCCYCode() {
		return chargeCCYCode;
	}

	public void setChargeCCYCode(String chargeCCYCode) {
		this.chargeCCYCode = chargeCCYCode;
	}

	public String getInterestCYYCode() {
		return interestCYYCode;
	}

	public void setInterestCYYCode(String interestCYYCode) {
		this.interestCYYCode = interestCYYCode;
	}

	public BigDecimal getMinDiscFeeAmt() {
		return minDiscFeeAmt;
	}

	public void setMinDiscFeeAmt(BigDecimal minDiscFeeAmt) {
		this.minDiscFeeAmt = minDiscFeeAmt;
	}


	/** Net Indicative Amt Call Out - Added for new UX 9.0 Sprint 3 CallOut - S172 -  Ends**/
	
	/** Available Amt Call Out - Added for new UX 9.0 Sprint 3 CallOut - S173 - Starts **/
	public String getBuyerOrgId() {
		return buyerOrgId;
	}

	public void setBuyerOrgId(String buyerOrgId) {
		this.buyerOrgId = buyerOrgId;
	}

	public String getSellerOrgId() {
		return sellerOrgId;
	}

	public void setSellerOrgId(String sellerOrgId) {
		this.sellerOrgId = sellerOrgId;
	}

	public String getLeadOrgId() {
		return leadOrgId;
	}

	public void setLeadOrgId(String leadOrgId) {
		this.leadOrgId = leadOrgId;
	}
	
	public BigDecimal getIndDiscRate() {
		return indDiscRate;
	}

	public void setIndDiscRate(BigDecimal indDiscRate) {
		this.indDiscRate = indDiscRate;
	}
	/** Available Amt Call Out - Added for new UX 9.0 Sprint 3 CallOut - S173 - Ends **/

	public BigDecimal getTotalChargeAmt() {
		return totalChargeAmt;
	}

	public void setTotalChargeAmt(BigDecimal totalChargeAmt) {
		this.totalChargeAmt = totalChargeAmt;
	}

	public boolean isRecallInd() {
		return recallInd;
	}

	public void setRecallInd(boolean recallInd) {
		this.recallInd = recallInd;
	}

	public boolean isUndoCallOutIndicator() {
		return undoCallOutIndicator;
	}

	public void setUndoCallOutIndicator(boolean undoCallOutIndicator) {
		this.undoCallOutIndicator = undoCallOutIndicator;
	}

	public Integer getAttachUpldIcoFlag() {
		return attachUpldIcoFlag;
	}

	public void setAttachUpldIcoFlag(Integer attachUpldIcoFlag) {
		this.attachUpldIcoFlag = attachUpldIcoFlag;
	}

	/**
	 * @return the pymtType
	 */
	public String getPymtType() {
		return pymtType;
	}

	/**
	 * @param pymtType the pymtType to set
	 */
	public void setPymtType(String pymtType) {
		this.pymtType = pymtType;
	}

	/**
	 * @return the updatedPymtAmount
	 */
	public String getUpdatedPymtAmount() {
		return updatedPymtAmount;
	}

	/**
	 * @param updatedPymtAmount the updatedPymtAmount to set
	 */
	public void setUpdatedPymtAmount(String updatedPymtAmount) {
		this.updatedPymtAmount = updatedPymtAmount;
	}
	
	
	
	/**
	 * Getter methods introduced to send the amounts as
	 * String to avoid amount > 16 digits getting truncated
	 * Added as part of defect Fix CSC-7835
	 */
	
	public String getDiscountaAvlAmountStr()
	{
		return (discountaAvlAmount!=null)?discountaAvlAmount.toPlainString():"";
	}
	
	public String getIndicatorNetAmounttStr()
	{
		return (indicatorNetAmountt!=null)?indicatorNetAmountt.toPlainString():"";
	}
	
	public String getAlreadyPaidAmountStr()
	{
		return (alreadyPaidAmount!=null)?alreadyPaidAmount.toPlainString():"";
	}
	
	public String getInProgressAmountStr()
	{
		return (inProgressAmount!=null)?inProgressAmount.toPlainString():"";
	}
	
	public String getSumIndicativeNetAmountStr()
	{
		return (sumIndicativeNetAmount!=null)?sumIndicativeNetAmount.toPlainString():"";
	}
	
	public String getSumAlreadyPaidAmountStr()
	{
		return (sumAlreadyPaidAmount!=null)?sumAlreadyPaidAmount.toPlainString():"";
	}
	
	public String getSumSupplierBalanceAmountStr()
	{
		return (sumSupplierBalanceAmount!=null)?sumSupplierBalanceAmount.toPlainString():"";
	}
	
	public String getAvailableAmountStr()
	{
		return (availableAmount!=null)?availableAmount.toPlainString():"";
	}
	
	public String getSupplierBalanceAmtStr()
	{
		return (supplierBalanceAmt!=null)?supplierBalanceAmt.toPlainString():"";
	}
	
	public String getMinDiscFeeAmtStr()
	{
		return (minDiscFeeAmt!=null)?minDiscFeeAmt.toPlainString():"";
	}
	
	public String getIndChargeAmtStr()
	{
		return (indChargeAmt!=null)?indChargeAmt.toPlainString():"";
	}
	
	public String getIndDiscAmtStr()
	{
		return (indDiscAmt!=null)?indDiscAmt.toPlainString():"";
	}
	
}
