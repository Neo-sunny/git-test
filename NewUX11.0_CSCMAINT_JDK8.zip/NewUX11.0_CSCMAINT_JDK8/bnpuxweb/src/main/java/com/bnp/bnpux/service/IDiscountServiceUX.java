/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     Export Service Implementation
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 
 *****************************************************************************************************************************************************************/

package com.bnp.bnpux.service;

import java.util.List;

import com.bnp.bnpux.common.vo.PaymentOrderListVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.vo.responseVO.DiscountResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface IDiscountServiceUX {

	/**
	 * This method is for getting Discount Request
	 * 
	 * @param paymentOrderListtVO
	 * @param user
	 * @return
	 * @throws BNPApplicationException
	 */
	public DiscountResponseVO getDiscRequestVO(List<PaymentOrderListVO> paymentOrderListtVO,UserInfoVO user) throws BNPApplicationException;
}
