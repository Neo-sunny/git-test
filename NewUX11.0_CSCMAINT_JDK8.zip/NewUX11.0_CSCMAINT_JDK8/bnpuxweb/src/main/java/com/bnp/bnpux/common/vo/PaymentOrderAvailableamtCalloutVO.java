/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Payment Order Available Amt Call out Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/

package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;

public class PaymentOrderAvailableamtCalloutVO {

	
	private String buyer_ref_no_unique;
    private String buyer_org_id;
    private String seller_org_id;                 
    private String lead_org_id;
    private BigDecimal total_orginal_amt;
    private BigDecimal cn_utilized_amt;
    private BigDecimal cap_percent;
    private BigDecimal avlble_amt_aft_cap;
    private BigDecimal already_discounted;
    private BigDecimal avlble_amt;
    private BigDecimal grp_one_cr_amt;
	private String error_result;
    private String error_msg;
	public String getBuyer_ref_no_unique() {
		return buyer_ref_no_unique;
	}
	public void setBuyer_ref_no_unique(String buyer_ref_no_unique) {
		this.buyer_ref_no_unique = buyer_ref_no_unique;
	}
	public String getBuyer_org_id() {
		return buyer_org_id;
	}
	public void setBuyer_org_id(String buyer_org_id) {
		this.buyer_org_id = buyer_org_id;
	}
	public String getSeller_org_id() {
		return seller_org_id;
	}
	public void setSeller_org_id(String seller_org_id) {
		this.seller_org_id = seller_org_id;
	}
	public String getLead_org_id() {
		return lead_org_id;
	}
	public void setLead_org_id(String lead_org_id) {
		this.lead_org_id = lead_org_id;
	}
	public BigDecimal getTotal_orginal_amt() {
		return total_orginal_amt;
	}
	public void setTotal_orginal_amt(BigDecimal total_orginal_amt) {
		this.total_orginal_amt = total_orginal_amt;
	}
	public BigDecimal getCn_utilized_amt() {
		return cn_utilized_amt;
	}
	public void setCn_utilized_amt(BigDecimal cn_utilized_amt) {
		this.cn_utilized_amt = cn_utilized_amt;
	}
	public BigDecimal getCap_percent() {
		return cap_percent;
	}
	public void setCap_percent(BigDecimal cap_percent) {
		this.cap_percent = cap_percent;
	}
	public BigDecimal getAvlble_amt_aft_cap() {
		return avlble_amt_aft_cap;
	}
	public void setAvlble_amt_aft_cap(BigDecimal avlble_amt_aft_cap) {
		this.avlble_amt_aft_cap = avlble_amt_aft_cap;
	}
	public BigDecimal getAlready_discounted() {
		return already_discounted;
	}
	public void setAlready_discounted(BigDecimal already_discounted) {
		this.already_discounted = already_discounted;
	}
	public BigDecimal getAvlble_amt() {
		return avlble_amt;
	}
	public void setAvlble_amt(BigDecimal avlble_amt) {
		this.avlble_amt = avlble_amt;
	}
	public String getError_result() {
		return error_result;
	}
	public void setError_result(String error_result) {
		this.error_result = error_result;
	}
	public String getError_msg() {
		return error_msg;
	}
	public void setError_msg(String error_msg) {
		this.error_msg = error_msg;
	}
	public BigDecimal getGrp_one_cr_amt() {
		return grp_one_cr_amt;
	}
	public void setGrp_one_cr_amt(BigDecimal grp_one_cr_amt) {
		this.grp_one_cr_amt = grp_one_cr_amt;
	}
	
	
	/**
	 * Getter methods introduced to send the amounts as
	 * String to avoid amount > 16 digits getting truncated
	 * Added as part of defect Fix CSC-7835
	 */
	
	public String getTotal_orginal_amtStr()
	{
		return (total_orginal_amt != null)?total_orginal_amt.toPlainString():"";
	}
	
	public String getCn_utilized_amtStr()
	{
		return (cn_utilized_amt != null)?cn_utilized_amt.toPlainString():"";
	}
	
	public String getCap_percentStr()
	{
		return (cap_percent != null)?cap_percent.toPlainString():"";
	}
	
	public String getAvlble_amt_aft_capStr()
	{
		return (avlble_amt_aft_cap != null)?avlble_amt_aft_cap.toPlainString():"";
	}
	
	public String getAlready_discountedStr()
	{
		return (already_discounted != null)?already_discounted.toPlainString():"";
	}
	
	public String getAvlble_amtStr()
	{
		return (avlble_amt != null)?avlble_amt.toPlainString():"";
	}
	
	public String getGrp_one_cr_amtStr()
	{
		return (grp_one_cr_amt != null)?grp_one_cr_amt.toPlainString():"";
	}
	
	/**End of CSC-7835 Changes **/
	   
    
}