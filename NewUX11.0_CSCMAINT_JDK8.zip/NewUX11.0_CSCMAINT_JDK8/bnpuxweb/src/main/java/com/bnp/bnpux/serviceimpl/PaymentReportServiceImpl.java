package com.bnp.bnpux.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.bnpux.constants.PaymentReportConstants;
import com.bnp.bnpux.constants.ReportsConstant;
import com.bnp.bnpux.dao.IPaymentReportDAO;
import com.bnp.bnpux.service.IPaymentReportService;
import com.bnp.bnpux.vo.requestVO.PaymentReportRequestVO;
import com.bnp.bnpux.vo.responseVO.PaymentReportResponseVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@Component
public class PaymentReportServiceImpl implements IPaymentReportService {
	
	@Autowired
	IPaymentReportDAO paymentReportDAO;
	
	/**
	 * Logger log for Payment Report class
	 */
	private static final Logger log = LoggerFactory.getLogger(PaymentReportServiceImpl.class);
	
	/**
	 * Constant for Exception message
	 */
	public static final String EXCEPTION_UNABLE_TO_PROCESS = "Unable to process action - Database Exception";
	
	/**
	 * This service implementation method is used to fetch latest Payment Report list
	 * 
	 * @param PaymentReportRequestVO 
	 * @return PaymentReportResponseVO
	 */
	public PaymentReportResponseVO getPaymentReportList(PaymentReportRequestVO paymentReportRequestVO) throws BNPApplicationException {
		PaymentReportResponseVO paymentReportResponseVO =null;
		try{
			paymentReportResponseVO = new PaymentReportResponseVO();
			
			if(PaymentReportConstants.PAYMENT_REPORT_LIST.equalsIgnoreCase(paymentReportRequestVO.getViewType())) {
				paymentReportDAO.getPaymentReport(paymentReportRequestVO);
				if(paymentReportRequestVO.getPaymentReport()!= null) {
					paymentReportResponseVO.setPaymentReportList(paymentReportRequestVO.getPaymentReport());
				}
			}else if(PaymentReportConstants.PAYMENT_REPORT_LIST_DETAILS.equalsIgnoreCase(paymentReportRequestVO.getViewType())) {
				paymentReportDAO.getPaymentReportDetails(paymentReportRequestVO);
				if(paymentReportRequestVO.getPaymentReportDetails() != null) {
					paymentReportResponseVO.setPaymentReportDetailsList(paymentReportRequestVO.getPaymentReportDetails());
				}
			
			if(paymentReportRequestVO.getErrorMsg() != null){				
				log.error(EXCEPTION_UNABLE_TO_PROCESS + paymentReportRequestVO.getErrorMsg());
			 }
		   }
		 } catch(Exception exception) {
			log.error(EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(EXCEPTION_UNABLE_TO_PROCESS);	
		}
		return paymentReportResponseVO;
	}
	
	/**
	 * This method is for getting report chart axis 
	 * 
	 * @param requestVo
	 * @return
	 * @throws BNPApplicationException
	 */
	public List<ReportChartResponseVO> getReportChartAxis (PaymentReportRequestVO paymentReportRequestVO)throws BNPApplicationException {
		List<ReportChartResponseVO> reportVOList = new ArrayList<ReportChartResponseVO>();
		try{
			
			paymentReportDAO.getChartAxis(paymentReportRequestVO);
		reportVOList = (List<ReportChartResponseVO>) paymentReportRequestVO.getReportChartList();
		/*if(reportVOList != null){
			settlementResponseVO.setSettlementListVO(settlementVOList);
		}*/	
		}catch(Exception exception){
			log.error(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(ReportsConstant.EXCEPTION_UNABLE_TO_PROCESS);
		}
		return reportVOList;
   }
		
}
