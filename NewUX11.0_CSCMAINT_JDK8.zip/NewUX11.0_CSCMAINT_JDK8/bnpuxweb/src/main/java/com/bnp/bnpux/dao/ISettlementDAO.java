/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Settlement Interface for Data Access Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 14-MAR-2017              Divyashri Subramaniam                           Added 2 method definition for Applying Advanced Filter values
************************************************************************************************************************************************************/
package com.bnp.bnpux.dao;

import java.util.List;
import java.util.Map;

import com.bnp.bnpux.common.vo.InProcessAlreadySettCalloutVO;
import com.bnp.bnpux.common.vo.SettlementCreditNoteLineItemVO;
import com.bnp.bnpux.common.vo.SettlementInvoiceDetailsCallOutVO;
import com.bnp.bnpux.common.vo.SettlementListDetailsVO;
import com.bnp.bnpux.common.vo.SettlementListVO;
import com.bnp.bnpux.common.vo.SettlementSummaryVO;
import com.bnp.bnpux.vo.requestVO.SettlementRequestVO;

public interface ISettlementDAO {

	/**
	 * This method is for getting Settlement Summary
	 * 
	 * @param paramMap
	 * @return
	 */
	/*Modified below method for code review comments(HashMap to RequestVO  in service layer)*/
	//List<SettlementSummaryVO> getSettlementSummary(Map<String, Object> paramMap);
	List<SettlementSummaryVO> getSettlementSummary(SettlementRequestVO settlementRequestVO);
	
	/**
	 * This method is for getting Settlement Summary with Advanced Filter Values
	 * 
	 * @param paramMap
	 * @return
	 */
	List<SettlementSummaryVO> getSettlementSummaryWithAdvFilter(SettlementRequestVO settlementRequestVO);
	
	
	/**
	 * This method is for getting Settlement Summary with Advanced Filter count 
	 * 
	 * @param paramMap
	 * @return
	 */
	List<SettlementSummaryVO> getAdvFilterIndicatorCount(SettlementRequestVO settlementRequestVO);
	
	/**
	 * This method is for getting Settlement List
	 * 
	 * @param paramMap
	 * @return
	 */
	/*Modified below method for code review comments(HashMap to RequestVO  in service layer)*/
	//List<SettlementListVO> getSettlementList(Map<String, Object> paramMap);
	List<SettlementListVO> getSettlementList(SettlementRequestVO settlementRequestVO);
	
	/**
	 * This method is for getting Settlement List with Advance Filter Values
	 * 
	 * @param paramMap
	 * @return
	 */
	List<SettlementListVO> getSettlementListWithAdvFilter(SettlementRequestVO settlementRequestVO);
	
	/**
	 * This method is for getting Settlement List Details
	 * 
	 * @param paramMap
	 * @return
	 */
	/*Modified below method for code review comments(HashMap to RequestVO  in service layer)*/
	//List<SettlementListDetailsVO> getSettlementListDetails(Map<String, Object> paramMap);
	List<SettlementListDetailsVO> getSettlementListDetails(SettlementRequestVO settlementRequestVO);

	/**
	 * This method is for getting InProcess Amount Details Callout
	 * 
	 * @param paramMap
	 * @return
	 */
	InProcessAlreadySettCalloutVO getInProcessAmtDetailsCallout(Map<String, Object> paramMap);

	/**
	 * This method is for getting Already Paid Amount Details Callout
	 * 
	 * @param paramMap
	 * @return
	 */
	InProcessAlreadySettCalloutVO getAlreadyPaidAmtDetailsCallout(Map<String, Object> paramMap);

	/**
	 * This method is for getting Settlement Invoice Details
	 * 
	 * @param invoiceLineItemMap
	 * @return
	 */
	SettlementInvoiceDetailsCallOutVO getSettlementInvoiceDetails(Map<String, Object> invoiceLineItemMap);

	/**
	 * This method is for getting Settlement Credit Note Line Item details
	 * 
	 * @param creditNoteLineItemMap
	 * @return
	 */
	SettlementCreditNoteLineItemVO getSettlementCreditNoteLineItemdetails(Map<String, Object> creditNoteLineItemMap);

	
}


