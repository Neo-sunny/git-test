/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Attachment Constants
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.constants;

public class AttachmentConstants {
	
	public static final String ORG_ID = "orgId";
	
	public static final String TYPE = "type";
	
	public static final String ATTACHMENT_LIST_DETAILS = "attacmentListDetails";
	
	public static final String ATTACHMENT_FILE_NAME = "fileName";
	
	public static final String ATTACHMENT_SEQ_NO = "seqNo";
	
	public static final String ATTACH_PK_ID = "attachPkId";
	
	public static final String EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL = "Unable to Get Attachment Details";
	
	public static final String 	ATTACH_REST_GET_ATTACHMENT_DATA = "getAttachment.rest";
	
	public static final String 	ATTACH_REST_GET_ALL_ATTACHMENT_DATA = "getAllAttachments.rest";
	
	public static final String SCF_FILE_NAME ="ScfAttachment.zip";
	
	public static final String ATTACHMENT_REF_ID = "refId";
	
	public static final String ATTACHMENT_FILE_ID = "fileId";
	
	public static final String ATTACHMENT_TYPE = "type";
	
}
