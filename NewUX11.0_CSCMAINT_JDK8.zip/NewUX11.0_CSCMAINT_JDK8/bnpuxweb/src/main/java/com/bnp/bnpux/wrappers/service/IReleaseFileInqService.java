/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 March 2017
 * 
 * Purpose:      Release File Functionality
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 March 2017            Oracle Financial Services Software Ltd                  Initial Version 
 * 27 March 2017            Bhuvaneswari                                            S2034 File managementUndo action 
 *  *  *************************************************************************************************************************************************************/
package com.bnp.bnpux.wrappers.service;

import java.util.List;

import com.bnp.bnpux.common.vo.ReleaseFileMgmtResponseVO;
import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;

public interface IReleaseFileInqService {

	/**
	 * This API initiates the deletion of a file
	 * @param FileDetailsVO
	 * @param deletedBy
	 * @throws BNPApplicationException
	 */
	ReleaseFileMgmtResponseVO deleteFile(List<FileDetailsVO> fileDetailsVOList, UserInfoVO user);

	/**
	 * This API initiates the release of a file
	 * @param FileDetailsVO
	 * @param deletedBy
	 * @throws BNPApplicationException
	 */
	ReleaseFileMgmtResponseVO releaseFile(List<FileDetailsVO> fileDetailsVOList, UserInfoVO user);

	/**
	 * @param fileDetailsVOList
	 * @param user
	 * @return
	 */
	ReleaseFileMgmtResponseVO authorizeFile(List<FileDetailsVO> fileDetailsVOList, UserInfoVO user) throws BNPApplicationException;
	
	/**
	 * @param fileDetailsVOList
	 * @param user
	 * @return
	 */
	ReleaseFileMgmtResponseVO rejectFile(List<FileDetailsVO> fileDetailsVOList, UserInfoVO user) throws BNPApplicationException;
	
}


