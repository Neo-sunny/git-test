/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:      Report Response Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.responseVO;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class ReportResponseVO {

	private String fileName;
	
	private Date fileRecDate;
	
	private String fileType;
	
	private String fileStatus;
	
	private String errorDesc;
	
	private String fileId;
	
	private String errorMessage;

	private String paymentReferenceNo;
	
	private String orgId;
	
	private String  leadOrgId;
	
	private Date paymentDueDate;
	
	private String paymentInvStatus;
	
	private BigDecimal paymentAmount;
	
	private BigDecimal paymentAmountBalance;
	
	private BigDecimal settlementAmount;
	
	private Date adjustedDueDate;
	
	private Date adjustExtDueDate;
	
	private String invCnType;
	
	private Date extendDueDate;
	
	private String InvRefCreditNoteRef;
	
	private String InvCurryCreditNoteCury;
	
	private BigDecimal InvAmountCreditNoteAmt;
	
	private Date InvIssDateCreditNoteIssDate;
	
	private Date invDueDate;
	
	private String InvStatCreditNoteStat;
	
	private String CreditNoteType;
	
	private String InvSettlementStatus;
	
	private String errorMessag;
	
	private long invCnt;
	
	private Date creditNoteEffDate;
	
	List<ReportResponseVO> reportResponseVOlist;

	List<ReportChartResponseVO> reportChartResponseVOlist;//Added for chart population on change of filters
	
	private String fileStatusValue;
	
	private String fileStatusKey;
	
	private String paymentInvStatusValue;
	
	private String statusKey;
	
	private String invStatCreditNoteStatValue;
	
	private String reportFileStatusValue;
	
	private String reportFileStatusKey;
	
	public List<ReportChartResponseVO> getReportChartResponseVOlist() {
		return reportChartResponseVOlist;
	}

	public void setReportChartResponseVOlist(List<ReportChartResponseVO> reportChartResponseVOlist) {
		this.reportChartResponseVOlist = reportChartResponseVOlist;
	}
	
	public List<ReportResponseVO> getReportResponseVOlist() {
		return reportResponseVOlist;
	}

	public void setReportResponseVOlist(List<ReportResponseVO> reportResponseVOlist) {
		this.reportResponseVOlist = reportResponseVOlist;
	}

	public String getErrorMessag() {
		return errorMessag;
	}

	public void setErrorMessag(String errorMessag) {
		this.errorMessag = errorMessag;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Date getFileRecDate() {
		return fileRecDate;
	}

	public void setFileRecDate(Date fileRecDate) {
		this.fileRecDate = fileRecDate;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getFileStatus() {
		return fileStatus;
	}

	public void setFileStatus(String fileStatus) {
		this.fileStatus = fileStatus;
	}

	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	public String getPaymentReferenceNo() {
		return paymentReferenceNo;
	}

	public void setPaymentReferenceNo(String  paymentReferenceNo) {
		this.paymentReferenceNo = paymentReferenceNo;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getLeadOrgId() {
		return leadOrgId;
	}

	public void setLeadOrgId(String leadOrgId) {
		this.leadOrgId = leadOrgId;
	}

	public Date getPaymentDueDate() {
		return paymentDueDate;
	}

	public void setPaymentDueDate(Date paymentDueDate) {
		this.paymentDueDate = paymentDueDate;
	}

	public String getPaymentInvStatus() {
		return paymentInvStatus;
	}

	public void setPaymentInvStatus(String paymentInvStatus) {
		this.paymentInvStatus = paymentInvStatus;
	}

	public BigDecimal getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(BigDecimal paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public BigDecimal getPaymentAmountBalance() {
		return paymentAmountBalance;
	}

	public void setPaymentAmountBalance(BigDecimal paymentAmountBalance) {
		this.paymentAmountBalance = paymentAmountBalance;
	}

	public BigDecimal getSettlementAmount() {
		return settlementAmount;
	}

	public void setSettlementAmount(BigDecimal settlementAmount) {
		this.settlementAmount = settlementAmount;
	}

	public Date getAdjustedDueDate() {
		return adjustedDueDate;
	}

	public void setAdjustedDueDate(Date adjustedDueDate) {
		this.adjustedDueDate = adjustedDueDate;
	}

	public Date getAdjustExtDueDate() {
		return adjustExtDueDate;
	}

	public void setAdjustExtDueDate(Date adjustExtDueDate) {
		this.adjustExtDueDate = adjustExtDueDate;
	}

	public String getInvCnType() {
		return invCnType;
	}

	public void setInvCnType(String invCnType) {
		this.invCnType = invCnType;
	}

	public Date getExtendDueDate() {
		return extendDueDate;
	}

	public void setExtendDueDate(Date extendDueDate) {
		this.extendDueDate = extendDueDate;
	}

	public String getInvRefCreditNoteRef() {
		return InvRefCreditNoteRef;
	}

	public void setInvRefCreditNoteRef(String invRefCreditNoteRef) {
		InvRefCreditNoteRef = invRefCreditNoteRef;
	}

	public String getInvCurryCreditNoteCury() {
		return InvCurryCreditNoteCury;
	}

	public void setInvCurryCreditNoteCury(String invCurryCreditNoteCury) {
		InvCurryCreditNoteCury = invCurryCreditNoteCury;
	}

	public BigDecimal getInvAmountCreditNoteAmt() {
		return InvAmountCreditNoteAmt;
	}

	public void setInvAmountCreditNoteAmt(BigDecimal invAmountCreditNoteAmt) {
		InvAmountCreditNoteAmt = invAmountCreditNoteAmt;
	}

	public Date getInvIssDateCreditNoteIssDate() {
		return InvIssDateCreditNoteIssDate;
	}

	public void setInvIssDateCreditNoteIssDate(Date invIssDateCreditNoteIssDate) {
		InvIssDateCreditNoteIssDate = invIssDateCreditNoteIssDate;
	}

	public Date getInvDueDate() {
		return invDueDate;
	}

	public void setInvDueDate(Date invDueDate) {
		this.invDueDate = invDueDate;
	}

	public Date getCreditNoteEffDate() {
		return creditNoteEffDate;
	}

	public void setCreditNoteEffDate(Date creditNoteEffDate) {
		this.creditNoteEffDate = creditNoteEffDate;
	}

	public String getInvStatCreditNoteStat() {
		return InvStatCreditNoteStat;
	}

	public void setInvStatCreditNoteStat(String invStatCreditNoteStat) {
		InvStatCreditNoteStat = invStatCreditNoteStat;
	}

	public String getCreditNoteType() {
		return CreditNoteType;
	}

	public void setCreditNoteType(String creditNoteType) {
		CreditNoteType = creditNoteType;
	}

	public String getInvSettlementStatus() {
		return InvSettlementStatus;
	}

	public void setInvSettlementStatus(String invSettlementStatus) {
		InvSettlementStatus = invSettlementStatus;
	}
	
	
	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public long getInvCnt() {
		return invCnt;
	}

	public void setInvCnt(long invCnt) {
		this.invCnt = invCnt;
	}

	/**
	 * @return the fileStatusValue
	 */
	public String getFileStatusValue() {
		return fileStatusValue;
	}

	/**
	 * @param fileStatusValue the fileStatusValue to set
	 */
	public void setFileStatusValue(String fileStatusValue) {
		this.fileStatusValue = fileStatusValue;
	}

	/**
	 * @return the paymentInvStatusValue
	 */
	public String getPaymentInvStatusValue() {
		return paymentInvStatusValue;
	}

	/**
	 * @param paymentInvStatusValue the paymentInvStatusValue to set
	 */
	public void setPaymentInvStatusValue(String paymentInvStatusValue) {
		this.paymentInvStatusValue = paymentInvStatusValue;
	}

	/**
	 * @return the fileStatusKey
	 */
	public String getFileStatusKey() {
		return fileStatusKey;
	}

	/**
	 * @param fileStatusKey the fileStatusKey to set
	 */
	public void setFileStatusKey(String fileStatusKey) {
		this.fileStatusKey = fileStatusKey;
	}

	/**
	 * @return the invStatCreditNoteStatValue
	 */
	public String getInvStatCreditNoteStatValue() {
		return invStatCreditNoteStatValue;
	}

	/**
	 * @param invStatCreditNoteStatValue the invStatCreditNoteStatValue to set
	 */
	public void setInvStatCreditNoteStatValue(String invStatCreditNoteStatValue) {
		this.invStatCreditNoteStatValue = invStatCreditNoteStatValue;
	}

	/**
	 * @return the statusKey
	 */
	public String getStatusKey() {
		return statusKey;
	}

	/**
	 * @param statusKey the statusKey to set
	 */
	public void setStatusKey(String statusKey) {
		this.statusKey = statusKey;
	}

	/**
	 * @return the reportFileStatusValue
	 */
	public String getReportFileStatusValue() {
		return reportFileStatusValue;
	}

	/**
	 * @param reportFileStatusValue the reportFileStatusValue to set
	 */
	public void setReportFileStatusValue(String reportFileStatusValue) {
		this.reportFileStatusValue = reportFileStatusValue;
	}

	/**
	 * @return the reportFileStatusKey
	 */
	public String getReportFileStatusKey() {
		return reportFileStatusKey;
	}

	/**
	 * @param reportFileStatusKey the reportFileStatusKey to set
	 */
	public void setReportFileStatusKey(String reportFileStatusKey) {
		this.reportFileStatusKey = reportFileStatusKey;
	}
	
	/**
	 * Getter methods introduced to send the amounts as
	 * String to avoid amount > 16 digits getting truncated
	 * Added as part of defect Fix CSC-7835
	 */
	
	public String getInvAmountCreditNoteAmtStr() {
		return (InvAmountCreditNoteAmt!=null)?InvAmountCreditNoteAmt.toPlainString():"";
	}
	
	public String getPaymentAmountStr() {
		return (paymentAmount!=null)?paymentAmount.toPlainString():"";
	}
	
	public String getPaymentAmountBalanceStr() {
		return (paymentAmountBalance!=null)?paymentAmountBalance.toPlainString():"";
	}
	
	public String getSettlementAmountStr() {
		return (settlementAmount!=null)?settlementAmount.toPlainString():"";
	}
	
}
