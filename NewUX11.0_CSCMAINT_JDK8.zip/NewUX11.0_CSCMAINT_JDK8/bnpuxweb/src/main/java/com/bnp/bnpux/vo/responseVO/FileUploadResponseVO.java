package com.bnp.bnpux.vo.responseVO;

import java.util.List;

import com.bnp.bnpux.common.vo.FileUploadStatusVO;

public class FileUploadResponseVO {
	
	private String errorMsg;
	
	private List<FileUploadStatusVO> fileStatusListVO;

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public List<FileUploadStatusVO> getFileStatusListVO() {
		return fileStatusListVO;
	}

	public void setFileStatusListVO(List<FileUploadStatusVO> fileStatusListVO) {
		this.fileStatusListVO = fileStatusListVO;
	}		
	

}
