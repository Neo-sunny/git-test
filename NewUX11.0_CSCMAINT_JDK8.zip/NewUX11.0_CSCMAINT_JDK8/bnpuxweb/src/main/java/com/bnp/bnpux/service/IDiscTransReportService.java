/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   21 June 2017
 * 
 * Purpose:     Discount Transaction Report Service Interface
 * 
 * Change History: 
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 21 June 2017       Ratna Gokhale, Oracle Financial Services Software Ltd     Initial Version
 * 
 *****************************************************************************************************************************************************************/
package com.bnp.bnpux.service;

import java.util.List;

import com.bnp.bnpux.vo.requestVO.DiscTransRequestVO;
import com.bnp.bnpux.vo.responseVO.DiscTransResponseVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface IDiscTransReportService {

	/**
	 * This method is for getting Discount Transaction Report details
	 * 
	 * @param DiscTransRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	DiscTransResponseVO getReportDetails(DiscTransRequestVO DiscTransRequestVO) throws BNPApplicationException;

	/**
	 * This method is for getting Discount Transaction Report list
	 * 
	 * @param DiscTransRequestVO
	 * @return
	 * @throws BNPApplicationException
	 */
	DiscTransResponseVO getReportList(DiscTransRequestVO DiscTransRequestVO)	throws BNPApplicationException;

	/**
	 * This method is for getting report chart axis 
	 * 
	 * @param requestVo
	 * @return
	 * @throws BNPApplicationException
	 */
	List<ReportChartResponseVO> getReportChartAxis (DiscTransRequestVO requestVo)throws BNPApplicationException;
	
}
