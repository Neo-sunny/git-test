/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:      Payment Order CreditNote LineItem Response Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.responseVO;

import java.util.List;

import com.bnp.bnpux.common.vo.PaymentOrderCreditNoteLineItemVO;


public class PaymentOrderCreditNoteLineItemResponseVO {

	
private String error_result;
public String getError_result() {
	return error_result;
}

public void setError_result(String error_result) {
	this.error_result = error_result;
}

public String getError_msg() {
	return error_msg;
}

public void setError_msg(String error_msg) {
	this.error_msg = error_msg;
}

private String error_msg;
	
	private List<PaymentOrderCreditNoteLineItemVO> paymentOrderCreditNoteLineItemVO;
	
	public List<PaymentOrderCreditNoteLineItemVO> getPaymentOrderCreditNoteLineItemVO() {
		return paymentOrderCreditNoteLineItemVO;
	}

	public void setPaymentOrderCreditNoteLineItemVO(
			List<PaymentOrderCreditNoteLineItemVO> paymentOrderCreditNoteLineItemVO) {
		this.paymentOrderCreditNoteLineItemVO = paymentOrderCreditNoteLineItemVO;
	}
	
	
	
	
}
