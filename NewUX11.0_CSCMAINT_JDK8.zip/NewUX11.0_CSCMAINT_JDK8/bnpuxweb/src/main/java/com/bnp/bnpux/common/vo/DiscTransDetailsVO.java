/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  21 June 2017
 * 
 * Purpose:      Credit Note Inquiry Report Summary VO
 * 
 * Date                       Author                                            Reason
 * -----------------------------------------------------------------------------------------------------------------------------------------------
 * 21 June 2017       Rameshwar Khedekar, Oracle Financial Services Software Ltd     Initial Version
 * 
************************************************************************************************************************************************************/

package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;
import java.util.Date;

public class DiscTransDetailsVO {
	
	
	private String errorMessage;
	
	
	private String dscRefNo;
	
	private String status;
	
	private Date discountDate;
	
	private Date maturityDate;
	
	private String tenor;
	
	private String ccy;
	
	private BigDecimal originalAmount;
	
	private BigDecimal financedAmount;
	
	private BigDecimal discountAmount;
	
	private BigDecimal indicativeNetAmount;
	
	
	private String custRefNo;
	
	private String indicativeDiscRate;
	
	private String indicativeChargeAmount;

	private Date originalMturityDate;
	
	private String adjustmentDays;
	
	
	
	private int decimalPoint;



	public String getErrorMessage() {
		return errorMessage;
	}



	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}



	public String getDscRefNo() {
		return dscRefNo;
	}



	public void setDscRefNo(String dscRefNo) {
		this.dscRefNo = dscRefNo;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public Date getDiscountDate() {
		return discountDate;
	}



	public void setDiscountDate(Date discountDate) {
		this.discountDate = discountDate;
	}



	public Date getMaturityDate() {
		return maturityDate;
	}



	public void setMaturityDate(Date maturityDate) {
		this.maturityDate = maturityDate;
	}



	public String getTenor() {
		return tenor;
	}



	public void setTenor(String tenor) {
		this.tenor = tenor;
	}



	public String getCcy() {
		return ccy;
	}



	public void setCcy(String ccy) {
		this.ccy = ccy;
	}



	public BigDecimal getOriginalAmount() {
		return originalAmount;
	}



	public void setOriginalAmount(BigDecimal originalAmount) {
		this.originalAmount = originalAmount;
	}



	public BigDecimal getFinancedAmount() {
		return financedAmount;
	}



	public void setFinancedAmount(BigDecimal financedAmount) {
		this.financedAmount = financedAmount;
	}



	public BigDecimal getDiscountAmount() {
		return discountAmount;
	}



	public void setDiscountAmount(BigDecimal discountAmount) {
		this.discountAmount = discountAmount;
	}



	public BigDecimal getIndicativeNetAmount() {
		return indicativeNetAmount;
	}



	public void setIndicativeNetAmount(BigDecimal indicativeNetAmount) {
		this.indicativeNetAmount = indicativeNetAmount;
	}



	public String getCustRefNo() {
		return custRefNo;
	}



	public void setCustRefNo(String custRefNo) {
		this.custRefNo = custRefNo;
	}



	public String getIndicativeDiscRate() {
		return indicativeDiscRate;
	}



	public void setIndicativeDiscRate(String indicativeDiscRate) {
		this.indicativeDiscRate = indicativeDiscRate;
	}



	public String getIndicativeChargeAmount() {
		return indicativeChargeAmount;
	}



	public void setIndicativeChargeAmount(String indicativeChargeAmount) {
		this.indicativeChargeAmount = indicativeChargeAmount;
	}



	public Date getOriginalMturityDate() {
		return originalMturityDate;
	}



	public void setOriginalMturityDate(Date originalMturityDate) {
		this.originalMturityDate = originalMturityDate;
	}



	public String getAdjustmentDays() {
		return adjustmentDays;
	}



	public void setAdjustmentDays(String adjustmentDays) {
		this.adjustmentDays = adjustmentDays;
	}



	public int getDecimalPoint() {
		return decimalPoint;
	}



	public void setDecimalPoint(int decimalPoint) {
		this.decimalPoint = decimalPoint;
	}
	
	
	public String getOriginalAmountStr() {
		return (originalAmount != null)? originalAmount.toPlainString():"";
	}
	
	public String getFinancedAmountStr() {
		return (financedAmount != null)? financedAmount.toPlainString():"";
	}
	
	public String getDiscountAmountStr() {
		return (discountAmount != null)? discountAmount.toPlainString():"";
	}
	
	public String getIndicativeNetAmountStr() {
		return (indicativeNetAmount != null)? indicativeNetAmount.toPlainString():"";
	
	}
	
	public String getIndicativeChargeAmountStr() {
		return indicativeChargeAmount;
	}
	
	
}
