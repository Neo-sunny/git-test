package com.bnp.bnpux.dao;

import java.util.List;

import com.bnp.bnpux.vo.requestVO.RemittanceRequestVO;
import com.bnp.bnpux.vo.responseVO.ReportChartResponseVO;

public interface IRemittanceReportDAO {
	/**
	 * This method is for getting Limit Utilization Report List
	 * 
	 * @param RemittanceRequestVO
	 * @return RemittanceRequestVO List
	 */
	List<RemittanceRequestVO> getReportList(RemittanceRequestVO requestVO);
	/**
	 * This method is for getting Limit Utilization Report List
	 * 
	 * @param RemittanceRequestVO
	 * @return RemittanceRequestVO List
	 */
	List<RemittanceRequestVO> getReportSummary(RemittanceRequestVO requestVO);
	
	/**
	 * This method is for getting Limit Utilization Report List Details
	 * 
	 * @param RemittanceRequestVO
	 * @return RemittanceRequestVO List
	 */
	List<RemittanceRequestVO> getReportListDetails(RemittanceRequestVO requestVO);
	

	/**
	 * This method is for getting Chart Axis
	 * 
	 * @param RemittanceRequestVO
	 * @return ReportChartResponseVO List
	 */
	List<ReportChartResponseVO> getChartAxis(RemittanceRequestVO requestVO);
	
}
