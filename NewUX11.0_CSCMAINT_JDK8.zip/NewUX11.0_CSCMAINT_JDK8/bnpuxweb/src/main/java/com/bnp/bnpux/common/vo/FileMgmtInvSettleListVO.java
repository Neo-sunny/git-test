/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   04 APR 2017	
 * 
 * Purpose:       File Management - PO INVOICE SETTLEMENT Value Object
 * 
 * Change History: 
 * Date                       Author                                    Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 04 APR 2017			      Divyashri					               Initial Version 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.math.BigDecimal;
import java.util.Date;

public class FileMgmtInvSettleListVO {
	
	private String invRefNumber;
	
	private String buyerOrgId;
	
	private String supplierOrgId;
	
	private Date issueDate; 
	
	private String settleCcyCode;
	
	private BigDecimal settleAmt; 
	
	private String invStmtstatus;
	
	private Date releaseDate;
	
	private String rNo;
	
	private String recordCnt;
	
	private int decimalPoint;

	public String getRecordCnt() {
		return recordCnt;
	}

	public void setRecordCnt(String recordCnt) {
		this.recordCnt = recordCnt;
	}

	public String getInvRefNumber() {
		return invRefNumber;
	}

	public void setInvRefNumber(String invRefNumber) {
		this.invRefNumber = invRefNumber;
	}

	public String getBuyerOrgId() {
		return buyerOrgId;
	}

	public void setBuyerOrgId(String buyerOrgId) {
		this.buyerOrgId = buyerOrgId;
	}

	public String getSupplierOrgId() {
		return supplierOrgId;
	}

	public void setSupplierOrgId(String supplierOrgId) {
		this.supplierOrgId = supplierOrgId;
	}

	public Date getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}

	public String getSettleCcyCode() {
		return settleCcyCode;
	}

	public void setSettleCcyCode(String settleCcyCode) {
		this.settleCcyCode = settleCcyCode;
	}

	public BigDecimal getSettleAmt() {
		return settleAmt;
	}

	public void setSettleAmt(BigDecimal settleAmt) {
		this.settleAmt = settleAmt;
	}

	public String getInvStmtstatus() {
		return invStmtstatus;
	}

	public void setInvStmtstatus(String invStmtstatus) {
		this.invStmtstatus = invStmtstatus;
	}

	public Date getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}

	public String getrNo() {
		return rNo;
	}

	public void setrNo(String rNo) {
		this.rNo = rNo;
	}

	public int getDecimalPoint() {
		return decimalPoint;
	}

	public void setDecimalPoint(int decimalPoint) {
		this.decimalPoint = decimalPoint;
	}
	
	public String getSettleAmtStr() {
		return (settleAmt != null)?settleAmt.toPlainString():"";
	}
	
}
