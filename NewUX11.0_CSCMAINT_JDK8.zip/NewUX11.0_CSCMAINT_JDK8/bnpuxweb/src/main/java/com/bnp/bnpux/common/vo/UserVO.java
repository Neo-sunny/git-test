/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      User Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.util.Date;


public class UserVO extends AbstractVO{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String userId;
	private String emailID;
	private String ssoPwd;
	private String employeeType;
	private String userTypeId;
	private String supportBranchId;
	private Date lastLogin;
	private String userStatus;
	private int invalidAttempts;
	private String sessionId;
	private String newUXSessionId;
	private String dbTimeZone;
	private boolean ssoFlag;
	private String timeZone;
	
	
	public String getDbTimeZone() {
		return dbTimeZone;
	}
	public void setDbTimeZone(String dbTimeZone) {
		this.dbTimeZone = dbTimeZone;
	}
	
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public String getSsoPwd() {
		return ssoPwd;
	}
	public void setSsoPwd(String ssoPwd) {
		this.ssoPwd = ssoPwd;
	}
	public String getEmployeeType() {
		return employeeType;
	}
	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}
	public String getUserTypeId() {
		return userTypeId;
	}
	public void setUserTypeId(String userTypeId) {
		this.userTypeId = userTypeId;
	}
	public String getSupportBranchId() {
		return supportBranchId;
	}
	public void setSupportBranchId(String supportBranchId) {
		this.supportBranchId = supportBranchId;
	}
	public Date getLastLogin() {
		return lastLogin;
	}
	public void setLastLogin(Date lastLogin) {
		this.lastLogin = lastLogin;
	}
	public String getUserStatus() {
		return userStatus;
	}
	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}
	public int getInvalidAttempts() {
		return invalidAttempts;
	}
	public void setInvalidAttempts(int invalidAttempts) {
		this.invalidAttempts = invalidAttempts;
	}
	public boolean isSsoFlag() {
		return ssoFlag;
	}
	public void setSsoFlag(boolean ssoFlag) {
		this.ssoFlag = ssoFlag;
	}
	public String getTimeZone() {
		return timeZone;
	}
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}
	public String getNewUXSessionId() {
		return newUXSessionId;
	}
	public void setNewUXSessionId(String newUXSessionId) {
		this.newUXSessionId = newUXSessionId;
	}
	
}
