/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   02-Mar-2017
 * 
 * Purpose:      Advanced Filter Service
 * 
 * Change History:
 *  
 * Date                       Author                                            Reason
 * 02-Mar-2017			Bala Murugan Elangovan					Base version for Advanced filter Service 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.service;

import com.bnp.bnpux.common.vo.AdvancedFilterVO;
import com.bnp.bnpux.vo.requestVO.AdvancedFilterRequestVO;
import com.bnp.bnpux.vo.responseVO.AdvancedFilterResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface IAdvancedFilterService {

	/**
	 * Interface method for getAdvacneFiltersList
	 * @param advanceFiterRequsetVO
	 * @return
	 * @throws BNPApplicationException
	 */
	AdvancedFilterVO getAdvancedFiltersList(AdvancedFilterVO advanceFiterRequsetVO) throws BNPApplicationException;

	AdvancedFilterResponseVO doAdvancedFilterAction(AdvancedFilterRequestVO advanceFiterRequsetVO) throws BNPApplicationException;

	
}
