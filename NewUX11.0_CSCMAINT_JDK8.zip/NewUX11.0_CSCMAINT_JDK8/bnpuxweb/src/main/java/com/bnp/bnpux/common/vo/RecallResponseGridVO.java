/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Recall Response Grid Value Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.io.Serializable;

public class RecallResponseGridVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/** The paymnt ref number. */
	private String paymntRefNumber;
	
	private String message;
	
	private boolean isError;
	
	/**
	 * Gets the paymnt ref number.
	 *
	 * @return the paymntRefNumber
	 */
	public String getPaymntRefNumber() {
		return paymntRefNumber;
	}
	
	/**
	 * Sets the paymnt ref number.
	 *
	 * @param paymntRefNumber the paymntRefNumber to set
	 */
	public void setPaymntRefNumber(String paymntRefNumber) {
		this.paymntRefNumber = paymntRefNumber;
	}
	
	/**
	 * Gets the paymnt ref number.
	 *
	 * @return the paymntRefNumber
	 */
	public String getMessage() {
		return message;
	}
	
	/**
	 * Sets the paymnt ref number.
	 *
	 * @param paymntRefNumber the paymntRefNumber to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	public boolean isError() {
		return isError;
	}

	public void setError(boolean isError) {
		this.isError = isError;
	}

}
