package com.bnp.bnpux.controllers;

import java.io.IOException;
import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bnp.bnpux.common.vo.UserInfoVO;
import com.bnp.bnpux.common.vo.ViewScheduledReportListVO;
import com.bnp.bnpux.constants.BNPConstants;
import com.bnp.bnpux.constants.ExportConstants;
import com.bnp.bnpux.constants.ReportsConstant;
import com.bnp.bnpux.util.RequestIdentityValidator;
import com.bnp.bnpux.vo.requestVO.ViewScheduledReportRequestVO;
import com.bnp.bnpux.vo.responseVO.ViewScheduledReportResponseVO;
import com.bnp.bnpux.wrappers.service.ReportBeanWrapperService;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@RestController
@RequestMapping("/viewSchdRprtCtrl")
public class ViewScheduledReportController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ViewScheduledReportController.class);
	@Autowired
	RequestIdentityValidator validateRequest;
	@Autowired
	private ReportBeanWrapperService reportBeanWrapperService;
	/**
	 * This method will be called on load from the screen and fetch all Scheduled report records
	 * 
	 * @param viewScheduleRptRequestVO
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @return ViewScheduledReportResponseVO
	 */
	
	@RequestMapping(value = "getViewScheduleRptDetails.rest", method = RequestMethod.POST)
	public ViewScheduledReportResponseVO getViewScheduleRptDetails(@RequestBody ViewScheduledReportRequestVO viewScheduleRptRequestVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		LOGGER.debug("class: ViewScheduledReportController,   method:getViewScheduleRptDetails  - Start");
		ViewScheduledReportResponseVO viewScheduledReportResponseVO = new ViewScheduledReportResponseVO();
		try {
			/** Search OPTION based on period **/
			if (viewScheduleRptRequestVO.getDateFrom()!=null && viewScheduleRptRequestVO.getDateTo()!=null){
					viewScheduleRptRequestVO.setPeriod("");
			}
			//FOR TESTING
//			viewScheduleRptRequestVO.setDateTo("");
//			viewScheduleRptRequestVO.setDateFrom("");
//			viewScheduleRptRequestVO.setPeriod("");
			
			boolean requestValidatedFlag = validateRequest.validate(viewScheduleRptRequestVO.getUserId(), httpServletRequest.getSession());
			if (requestValidatedFlag) {
				viewScheduledReportResponseVO = reportBeanWrapperService.getInitReport(viewScheduleRptRequestVO);
			} else {
				viewScheduledReportResponseVO = null;
				LOGGER.warn(BNPConstants.UNAUTHORIZED_ACCESS);
				httpServletResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			}
		} catch (BNPApplicationException exception) {
			viewScheduledReportResponseVO.setErrorMessage(exception.getMessage());
			LOGGER.error(exception.getMessage(), exception);
		}
		LOGGER.debug("class: ViewScheduledReportController,   method:getViewScheduleRptDetails  - Start");
		return viewScheduledReportResponseVO;
	}
	
	/**
	 * download report on click of report schedule ID link in the table
	 * @param viewScheduledReportRequestVO
	 * @param request
	 * @param response
	 */
	@RequestMapping(value="downloadLinkDetails.rest", method=RequestMethod.POST)
	public void downloadLinkDetails(@RequestBody ViewScheduledReportRequestVO viewScheduledReportRequestVO, HttpServletRequest request, HttpServletResponse response)
	{
		LOGGER.debug("class: ViewScheduledReportController,   downloadLinkDetails  - Start");
		HttpSession session = request.getSession();
		UserInfoVO user = (UserInfoVO) session.getAttribute("userInfo");
		String fileName = null;
		try{
			boolean requestValidatedFlag = validateRequest.validate(user.getUserId(),request.getSession());
			if(requestValidatedFlag){
				LOGGER.debug("class: ViewScheduledReportController,   calling service method downloadLinkDetails");
				fileName = viewScheduledReportRequestVO.getReportFileName();
				
				if(ExportConstants.CSV_FORMAT.equalsIgnoreCase(viewScheduledReportRequestVO.getReportFormat())){
					 response.setContentType("application/csv");
					response.setHeader("Content-Disposition","attachment;filename=\"" + fileName + ".csv\"");
					response.setHeader("fileName", fileName+".csv");
				
				} else if(ExportConstants.XLS_FORMAT.equalsIgnoreCase(viewScheduledReportRequestVO.getReportFormat())){
					 response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
					response.setHeader("Content-Disposition","attachment;filename=\"" + fileName + ".xls\"");
					response.setHeader("fileName", fileName+".xls");
				
				} else if(ExportConstants.PDF_FORMAT.equalsIgnoreCase(viewScheduledReportRequestVO.getReportFormat())){
					response.setContentType("application/pdf");
					response.setHeader("Content-Disposition","attachment;filename=\"" + fileName + ".pdf\"");
					response.setHeader("fileName", fileName+".pdf");
				}
				
				response.setContentLength(viewScheduledReportRequestVO.getReportData().length);
				response.getOutputStream().write(viewScheduledReportRequestVO.getReportData());
				response.getOutputStream().close();
			}
		}
		catch (IOException e) {
			response.setHeader("errorMessage", e.getMessage());
			response.setHeader("isError", "true");
			LOGGER.error(e.getMessage(),e);
		}
		catch(Exception e){
			response.setHeader("errorMessage", e.getMessage());
			response.setHeader("isError", "true");
			LOGGER.error(e.getMessage());
		}
	}
	
	@RequestMapping(value = "getZipAttachment.rest", method = RequestMethod.POST)
	public void downloadZipAttachment(@RequestBody ViewScheduledReportRequestVO viewScheduledReportRequestVO, HttpServletRequest request, HttpServletResponse response) throws BNPApplicationException, ParseException {
		System.out.println("Inside downloadZipAttachment");
		ViewScheduledReportResponseVO viewScheduledReportResponseVO = new ViewScheduledReportResponseVO();
		String fileName = null;
		try {
			String todaysDtTime=  viewScheduledReportRequestVO.getLastViewed().replaceAll("[^\\d]", "").trim();
			fileName = ReportsConstant.SCHEDULED_REPORTS+todaysDtTime+".zip";
			
			for(ViewScheduledReportListVO vo : viewScheduledReportRequestVO.getViewScheduledReportList()){
				viewScheduledReportRequestVO.setGeneratedReportId(vo.getGeneratedReportId());
				updateLastViewed(viewScheduledReportRequestVO, request, response);
			}
			viewScheduledReportResponseVO = reportBeanWrapperService.downloadZipAttachment(viewScheduledReportRequestVO.getViewScheduledReportList());
			response.setContentType("application/zip");
			response.setHeader("Content-Disposition","attachment;filename=\"" + fileName + "\"");
			response.setHeader("fileName", fileName);
			response.setContentLength(viewScheduledReportResponseVO.getData().length);
		    try {
				response.getOutputStream().write(viewScheduledReportResponseVO.getData());
				response.getOutputStream().close();
			} catch (IOException e) {
				LOGGER.error(e.getMessage(),e);
			}
	        
		} catch (BNPApplicationException exception) {
			response.setHeader("errorFound", "true");
			response.setHeader("errorMessage", exception.getMessage());
			viewScheduledReportResponseVO.setErrorMessage(exception.getMessage());
			LOGGER.error(exception.getMessage(),exception);			
		}	
	}
	
	
	/**
	 * update Last Viewed column with userID
	 * @param viewScheduleRptRequestVO
	 * @throws BNPApplicationException
	 * @throws ParseException 
	 */
	@RequestMapping(value="updateLastViewed.rest", method=RequestMethod.POST)
	public void updateLastViewed(@RequestBody ViewScheduledReportRequestVO viewScheduledReportRequestVO, HttpServletRequest request, HttpServletResponse response) throws BNPApplicationException, ParseException
	{
		LOGGER.debug("class: ViewScheduledReportController,  updateLastViewed  - Start");
		try {
			viewScheduledReportRequestVO.setU_generatedReportId(Long.parseLong(viewScheduledReportRequestVO.getGeneratedReportId()));
			
			reportBeanWrapperService.updateLastViewed(viewScheduledReportRequestVO);
		} catch (DataAccessException exception) {
			LOGGER.error(ReportsConstant.EXCEPTION_UNABLE_TO_PROCES, exception);
			throw new BNPApplicationException(ReportsConstant.EXCEPTION_UNABLE_TO_PROCES);
		}
		LOGGER.debug("class: ViewScheduledReportController,  updateLastViewed  - End");
	}
}
