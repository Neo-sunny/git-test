/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   26-May-2017
 * 
 * Purpose:      Notifications Service Implementation
 * 
 * Change History:
 *  
 * Date                       Author                                            Reason
 * 26-May-2017			Bala Murugan Elangovan					Notifications Service Implementation 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.serviceimpl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.bnp.bnpux.common.vo.EmailAttachmentVO;
import com.bnp.bnpux.common.vo.EmailNotificationsVO;
import com.bnp.bnpux.common.vo.FileMgmtAttachmentListVO;
import com.bnp.bnpux.constants.AttachmentConstants;
import com.bnp.bnpux.constants.FileMgmtConstants;
import com.bnp.bnpux.dao.IEmailNotificationsDAO;
import com.bnp.bnpux.service.IEmailNotificationsService;
import com.bnp.bnpux.vo.requestVO.EmailNotificationsRequestVO;
import com.bnp.bnpux.vo.requestVO.FileMgmtRequestVO;
import com.bnp.bnpux.vo.responseVO.EmailNotificationsResponseVO;
import com.bnp.bnpux.vo.responseVO.FileMgmtResponseVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

@Component
public class EmailNotificationsServiceImpl implements IEmailNotificationsService{

	@Autowired
	private IEmailNotificationsDAO notificationsDAO;
	
	/**
	 * Logger log for EmailNotificationsServiceImpl class
	 */
	private static final Logger log = LoggerFactory.getLogger(EmailNotificationsServiceImpl.class);
	
	/**
	 * Constant for Exception message
	 */
	public static final String EXCEPTION_UNABLE_TO_PROCESS = "Unable to process action - Database Exception";
	
	/**
	 * This service implementation method is used to fetch latest notification list
	 * 
	 * @param EmailNotificationsResponseVO 
	 * @return EmailNotificationsResponseVO
	 */
	@Override
	public EmailNotificationsResponseVO getNotificationsList(EmailNotificationsRequestVO noticationsVO) throws BNPApplicationException {
		EmailNotificationsResponseVO noticationsResponseVO = null; 
		try{
			notificationsDAO.getNotificationsList(noticationsVO);
			noticationsResponseVO = new EmailNotificationsResponseVO();
			noticationsResponseVO.setNotificationsList(noticationsVO.getNotificationsList());
			noticationsResponseVO.setPollingTime(noticationsVO.getPollingTime());
		}catch(DataAccessException exception){
			log.error(EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(EXCEPTION_UNABLE_TO_PROCESS);	
		}
		return noticationsResponseVO;
	}

	/**
	 * This service implementation method is used to fetch email Inquiry Report list
	 * 
	 * @param EmailInquiryRptRequestVO 
	 * @return EmailNotificationsResponseVO
	 */
	@Override
	public EmailNotificationsResponseVO getEmailInqRptList(EmailNotificationsRequestVO noticationsVO) throws BNPApplicationException {
		EmailNotificationsResponseVO noticationsResponseVO = null; 
		try{
			notificationsDAO.getEmailInqReportList(noticationsVO);
			noticationsResponseVO = new EmailNotificationsResponseVO();
			if(noticationsVO.getNotificationsList() != null && noticationsVO.getNotificationsList().size()>0 && noticationsVO.getNotificationsList().get(0) != null){
			noticationsResponseVO.setNotificationsList(noticationsVO.getNotificationsList());
			}
			
		}catch(DataAccessException exception){
			log.error(EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(EXCEPTION_UNABLE_TO_PROCESS);	
		}
		return noticationsResponseVO;
	}
	
	/**
	 * This service implementation method is used to fetch email Inquiry Report list
	 * 
	 * @param EmailInquiryRptRequestVO 
	 * @return EmailNotificationsResponseVO
	 */
	@Override
	public EmailNotificationsVO getEmailInqRptDetails(EmailNotificationsVO noticationsVO) throws BNPApplicationException {
		try{
			notificationsDAO.getEmailInqReportDetails(noticationsVO);
			}catch(DataAccessException exception){
			log.error(EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(EXCEPTION_UNABLE_TO_PROCESS);	
		}
		return noticationsVO;
	}

	/**
	 * This method is for getting attachment information for the file and Download operations
	 * 
	 * @param emailNotificationsVO
	 * @return
	 * @throws BNPApplicationException
	 */
	@Override
	public EmailNotificationsVO getAttachmentData(EmailNotificationsVO emailNotificationsVO) throws BNPApplicationException {
		EmailNotificationsVO emailAttachResponseVO = new EmailNotificationsVO();
		List<EmailAttachmentVO> emailAttachmentListVO = new ArrayList<EmailAttachmentVO>();
		try{			
			notificationsDAO.getAttachmentData(emailNotificationsVO);
			emailAttachmentListVO = emailNotificationsVO.getAttachmentContents();
			if(!CollectionUtils.isEmpty(emailNotificationsVO.getAttachmentContents()))
			{
				if(emailNotificationsVO.getAttachmentContents().size() > 1){
					emailAttachResponseVO = downLoadAll(emailAttachmentListVO, emailAttachmentListVO.get(0).getAttachmentName());
					emailAttachResponseVO.setAllFlag(true);
				}
				else
				{
					emailAttachResponseVO.setAttachmentName(emailAttachmentListVO.get(0).getAttachmentName());
					emailAttachResponseVO.setAttachmentData(emailAttachmentListVO.get(0).getData());
					emailAttachResponseVO.setAllFlag(false);
				}
			}
		}catch(DataAccessException exception){
			log.error(FileMgmtConstants.EXCEPTION_UNABLE_TO_PROCESS, exception);
			throw new BNPApplicationException(FileMgmtConstants.EXCEPTION_UNABLE_TO_PROCESS);
		}
		return emailAttachResponseVO;
	}
	
	/**
	 * This method is for downloading all
	 * 
	 * @param listAttachmentDetails
	 * @return AttachmentResponseVO
	 * @throws BNPApplicationException 
	 * @Description downLoad All Attachment
	 */
	public EmailNotificationsVO downLoadAll(List listAttachmentDetails, String attachmentName)throws BNPApplicationException
	{
		EmailNotificationsVO attachmentresponse = new EmailNotificationsVO();
		try
		{
			byte[] readBuff;	
			readBuff =compressFiles(listAttachmentDetails);
			attachmentresponse.setAttachmentData(readBuff);
			attachmentresponse.setAttachmentName(attachmentName);
		}catch (Exception e) {
			log.error(FileMgmtConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL,e);
			throw new BNPApplicationException(FileMgmtConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL);
		}
		return attachmentresponse;
	}
	
	public byte[] compressFiles(List listdownLoadAll) throws BNPApplicationException{

				ByteArrayOutputStream objbyteArrayStream = null;
				ZipOutputStream outputStream = null;
				byte[] objByteoutput = null;
				
				try{
					if(!listdownLoadAll.isEmpty()){
						objbyteArrayStream = new ByteArrayOutputStream();
						outputStream = new ZipOutputStream(objbyteArrayStream);
						for ( int i = 0; i<listdownLoadAll.size();i++)
						{
							EmailAttachmentVO objFileVO = (EmailAttachmentVO)listdownLoadAll.get(i);
							String fileName = objFileVO.getAttachmentName();
							outputStream.putNextEntry(new ZipEntry(getFileName(fileName,i)));
							outputStream.write(objFileVO.getData());
							outputStream.closeEntry();
							objFileVO = null;
						}
						outputStream.finish();
						outputStream.flush();
						objByteoutput = objbyteArrayStream.toByteArray();

					}
				}
				catch (IOException ioe) {
					log.error(FileMgmtConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL,ioe);
					throw new BNPApplicationException(FileMgmtConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL);
				}
				finally
				{
					try{
						if(objbyteArrayStream!=null){
							objbyteArrayStream.close();
						}
						if(outputStream!=null)
						{
						outputStream.finish();
						outputStream.flush();
						outputStream.close();
						}
					}
					catch (IOException ioe) {
						log.error(AttachmentConstants.EXCEPTION_UNABLE_TO_GET_ATTACHMENT_DETAIL,ioe);
					}
				}
				return objByteoutput;
			}
	
	private String getFileName(String fileName, int num){
		StringBuilder fileNameTemp = new StringBuilder(fileName);
		StringBuilder toAppend = new StringBuilder();
		toAppend.append("(").append(num+1).append(")");
		if(fileName.lastIndexOf(".") != -1){
			fileNameTemp.insert(fileName.length()-(fileName.length()-fileName.lastIndexOf(".")),toAppend);
		}else{
			fileNameTemp.insert(fileName.length(),toAppend);
		}
		return fileNameTemp.toString();
	}
	
}
