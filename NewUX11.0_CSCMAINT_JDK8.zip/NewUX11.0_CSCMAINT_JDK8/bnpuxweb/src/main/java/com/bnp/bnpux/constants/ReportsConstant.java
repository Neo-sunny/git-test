/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Reports Constants
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.constants;

public interface ReportsConstant {

	
	public final static String REPORT_ORDER_USER_ID = "userId";
	
	public final static String REPORT_ORDER_USER_TYPE_ID = "userType";
	
	public final static String REPORT_ORDER_ORG_ID = "orgId";
	
	public final static String REPORT_ORDER_COUNTER_PTY_ID= "cptyOrgId";
	
	public final static String REPORT_ORDER_CURRENCY_CODE = "currencyCode";
	
	public final static String REPORT_ORDER_UPLOAD_FROM_DATE = "uploadFromDate";
	
	public final static String REPORT_ORDER_UPLOAD_TO_DATE= "uploadToDate";
	
	public final static String REPORT_ORDER_FILE_STATUS = "fileStatus";
	
	public final static String REPORT_ORDER_FILE_PERIOD = "filePeriod";
	
	public final static String REPORT_ORDER_FILE_BRANCH = "fileBranch";
	
	public final static String REPORT_ORDER_STATUS = "status";
	
	public final static String REPORT_ORDER_GET_WHAT = "getWhat";
	
	public final static String REPORT_ORDER_FILE_ID = "fileID";
	
	public final static String REPORT_ORDER_LIST_DETAILS   = "ReportUploadDetails";
	
	public final static String REPORT_ORDER_LIST_DETAILS_LIST   = "ReportUploadDetailslist";
	
	public static final String SETTLEMENT_ORDER_ERROR_FLAG = "errorFlag";
	
	public static final String REPORT_SUMMARY_REST_GET_DETAILS = "getReportDetails.rest";
	
	public static final String REPORT_SUMMARY_REST_GET_DETAILS_LIST = "getReportDetailList.rest";
	
	public static final String EXCEPTION_UNABLE_TO_PROCESS = "Unable to Get Report Order Details - Database Exception";
	
	public final static String REPORT_ORDER_FILTER_FILE_STATUS = "filterFileStatus";
	
	public final static String REPORT_CHART_LIST="reportChartList";
	
	public final static String REPORT_SUMMARY_REST_GET_CHART_DATA ="chartData.rest";
	
	public final static String REPORT_FLAG_N ="N";
	
	public static final String EXCEPTION_UNABLE_TO_PROCES = "Unable to Get View Scheduled Reports Details - Database Exception";
	
	public static final String SCHEDULED_REPORTS = "ScheduledReports-";
}
