/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:      Discount Response Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.responseVO;

import java.io.Serializable;
import java.util.List;

import com.bnp.bnpux.vo.errorMessageVO.ErrorMessageVO;
import com.bnp.scm.services.discounting.vo.DiscountRequestVO;

public class DiscountResponseVO implements Serializable{

	
private static final long serialVersionUID = 1L;
	
	private ErrorMessageVO errMessageVO;
	private List<DiscountRequestVO> discountRequestVO;
	
	private List<ErrorMessageVO> errorList;
	
	public List<DiscountRequestVO> getDiscountRequestVO() {
		return discountRequestVO;
	}
	public void setDiscountRequestVO(List<DiscountRequestVO> discountRequestVO) {
		this.discountRequestVO = discountRequestVO;
	}
	public ErrorMessageVO getErrMessageVO() {
		return errMessageVO;
	}
	public void setErrMessageVO(ErrorMessageVO errMessageVO) {
		this.errMessageVO = errMessageVO;
	}
	public List<ErrorMessageVO> getErrorList() {
		return errorList;
	}
	public void setErrorList(List<ErrorMessageVO> errorList) {
		this.errorList = errorList;
	}
	
}
