/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Transaction Interface for Data Access Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 21 Feb 2017				Sathishkumar B										FO 10.0 - S008, S009, S010, S011, S012, S013, S014
 * 16 Mar 2017				aasriniv											FO 10.0 - Advanced Filter Implementation - Transactions
********************************************b****************************************************************************************************************/
package com.bnp.bnpux.dao;

import java.util.List;
import java.util.Map;

import com.bnp.bnpux.common.vo.CommitmentFeeUxVO;
import com.bnp.bnpux.common.vo.DiscountDetailsUxVO;
import com.bnp.bnpux.common.vo.TransactionChargeAmtVO;
import com.bnp.bnpux.common.vo.TransactionConfimedAmtVO;
import com.bnp.bnpux.common.vo.TransactionListVO;
import com.bnp.bnpux.common.vo.TransactionSummaryVO;
import com.bnp.bnpux.vo.requestVO.TransactionRequestVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.discounting.vo.DiscountRequestVO;

public interface ITransactionDAO {

	/**
	 * This method is for getting Transaction Summary
	 * 
	 * @param paramMap
	 * @return
	 */
	/*Modified below method for code review comments(HashMap to RequestVO  in service layer)*/
	//List<TransactionSummaryVO> getTransactionSummaryInfo(Map<String, Object> paramMap);
	
	List<TransactionSummaryVO> getTransactionSummaryInfo(TransactionRequestVO transactionReqVO);
	
	/**
	 * This method is get Transaction details with advanced filter information
	 * @param transactionReqVO
	 * @return
	 */
	List<TransactionSummaryVO> getTransactionSummaryInfoWithAdvFilter(TransactionRequestVO transactionReqVO);

	/**
	 * This method is for getting Count of records fetched
	 * @param paymentOrderRequestVO
	 * @return
	 */
	List<TransactionSummaryVO> getAdvFilterIndicatorCount(TransactionRequestVO transactionReqVO);
	
	/**
	 * This method is for getting Transaction List
	 * 
	 * @param transactionListMap
	 * @return
	 */
	/*Modified below method for code review comments(HashMap to RequestVO  in service layer)*/
	//List<TransactionListVO> getTransactionListInfo(Map<String, Object> transactionListMap);
	
	List<TransactionListVO> getTransactionListInfo(TransactionRequestVO transactionReqVO);
	
	/**
	 * This method is get Transaction details with advanced filter information
	 * @param transactionReqVO
	 * @return
	 */
	List<TransactionListVO> getTransactionListInfoWithAdvFilter(TransactionRequestVO transactionReqVO);
	
	
	// Added for User Stories S144 by Purushoth	
	/**
	 * This method is for getting Discount Request 
	 * 
	 * @param transactionListVO
	 * @return
	 */
	List<DiscountRequestVO> getDiscountRequestVO(List<TransactionListVO> transactionListVO);
	
	// Ended for User Stories S144 by Purushoth	
	
	//For Cancel
	/**
	 * This method is for cancelling Discount Request 
	 * 
	 * @param transactionListVO
	 * @return
	 */
	DiscountRequestVO getDiscountRequestCancelVO(TransactionListVO transactionListVO);
	
	// Ended for User Stories S144 by Purushoth	
	
	// Added for User Stories S148 by Rohit	
	/**
	 * This method is for getting Buyer acceptance
	 * 
	 * @param transactionListVO
	 * @return
	 */
	DiscountRequestVO getDiscountRequestVOBuyerAcceptance(TransactionListVO transactionListVO);
	
	// Added for User Stories S148 by Rohit	
	
	/**
	 * This method is for getting Transaction charge amount info
	 * 
	 * @param paramMap
	 * @return
	 */
	List<TransactionChargeAmtVO> getTransactionChargeAmtInfo(Map<String, Object> paramMap);

	/**
	 * This method is for getting Confirmed amount info 
	 * 
	 * @param paramMap
	 * @return
	 */
	List<TransactionConfimedAmtVO> getTransactionConfirmedAmtInfo(Map<String, Object> paramMap);
	
	/**
	 * This Method for getting Discount Popup Details - FO 10.0 - S008, S009, S010, S011, S012, S013, S014
	 * @param transactionReqVO
	 * @return
	 */
	void getDiscountPopupDetails(TransactionRequestVO transactionReqVO);
	
	CommitmentFeeUxVO fetchDebitNoteRef(TransactionRequestVO transactionReqVO);
	
}
