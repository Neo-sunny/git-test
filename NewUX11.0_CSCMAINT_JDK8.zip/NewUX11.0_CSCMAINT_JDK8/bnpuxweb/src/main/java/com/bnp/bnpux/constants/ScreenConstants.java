/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27-OCT-2016
 * 
 * Purpose:      Screen Constants
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 
************************************************************************************************************************************************************/
package com.bnp.bnpux.constants;

public interface ScreenConstants {

	String DISCOUNTINQUIRY ="DISCOUNTINQUIRY";
	String BANKCODETYPE = "BANKCODETYPES";
	String COUNTRYSETUP="COUNTRYSETUP";
	String BRANCHDISC="BRANCHDISC";
	String RELEASEFILEINQ="RELEASEFILEENQ";
	String BANKCODE="BANKCODE";
	String ENTITLEMENT="ENTITLEMENT";
	String ASSIGNFUNCTIONS="ASSIGNFUNCROLE";
	String ADDREMOVEREGADMINFUNCTIONS="ADDREMOVEREGADMINFUNCTIONS";
	String ADDREMOVEBANKADMINFUNCTIONS="ADDREMOVEBANKADMINFUNCTIONS";
	String ASSIGNREGADMINROLES="ASSIGNREGADMINROLES";
	String ASSIGNBANKADMINROLES="ASSIGNBANKADMINROLES";
	String DEFSUPBRANCH="DEFSUPBRANCH";
	
	// Organization Group Screen ID is added
	String ORGGRPSETUP="ORGGRPSETUP";
	String BUYER_ACCOUNT="BUYERACCT";
	String SUPPLIER_ACCOUNT="SUPPACCT";
	
	String CUSTOM_REPORT_TEMPLATE_SCREEN="CUSTOMREPORTTEMPLATE";
	
	// ERP Scheduler Screen ID is added
	String ERPSCHEDULER="ERPSCHEDULER";
	
	// Event Configuration Screen ID is added
	String EVENTCONFIG="EVENTCONFIG";	
	
	// Organization Email Group Screen ID is added
	String ORGEMAILGROUP="ORGEMAILGROUP";
	
	// Bank Admin Email Group Screen ID is added
	String BANKADMINEMAILGROUP="BANKADMINEMAILGROUP";
	
	// Schedule Download Screen ID is added
	String SCHEDULEDOWNLOAD="SCHEDULEDOWNLOAD";	
	
	String RA="REG_ADMIN";
	String BA ="BANK_ADMIN";
	String B ="BUYER";
	String S="SELLER";
	String OA="ORG_ADMIN";
	
	String REG_ADMIN="RA";
	String BANK_ADMIN="BA";
	String ORG_ADMIN="OA";
	String BUYER="B";
	String SELLER="S";
	// Modified for fetching BA and TP roles for RA user
	String QRY_USERS_FOR_RA="\'BA\',\'TP\'";
	String QRY_USERS_FOR_BA="\'B\',\'S',\'BCMBOA\',\'SCMBOA',\'BCMSOA\',\'SCMSOA',\'BCMB\',\'BCMS',\'SCMB\',\'SCMS',\'BCMBALL\',\'BCMSALL',\'SCMBALL\',\'SCMSALL'";
	String QRY_USERS_FOR_BCMBALL="\'BCMBOA\',\'BCMB\'";
	String QRY_USERS_FOR_BCMSALL="\'BCMSOA\',\'BCMS\'";
	String QRY_USERS_FOR_SCMBALL="\'SCMBOA\',\'SCMB\'";
	String QRY_USERS_FOR_SCMSALL="\'SCMSOA\',\'SCMS\'";
	
	String USERTYPES_FOR_BCMBALL="\'BCMBOA\',\'BCMBALL\'";
	String USERTYPES_FOR_BCMSALL="\'BCMSOA\',\'BCMSALL\'";
	String USERTYPES_FOR_SCMBALL="\'SCMBOA\',\'SCMBALL\'";
	String USERTYPES_FOR_SCMSALL="\'SCMSOA\',\'SCMSALL\'";
	
	String NEW_RECORD="NEW_RECORD";
	String CREATED_RECORD="CREATED_RECORD";
	String APPROVE_RECORD="APPROVE_RECORD";
	String DELETE_RECORD="DELETE_RECORD";
	String MODIFY_RECORD="MODIFY_RECORD";
	String REJECT_RECORD="REJECT_RECORD";
	String WAITING_FOR_APPROVAL_REQUEST="NEW";
	String ACTIVE_REQUEST="APPROVED";
	String DELETE_REQUEST="DELETE";
	String MODIFY_REQUEST="MODIFIED";
	String REQUEST="REQUEST";
	String FIELD_SEPERATOR="~";
	String CREATE_ORG_VALUE_CONVERSION_A="A";
	String CREATE_ORG_VALUE_CONVERSION_B="B";
	String CREATE_ORG_VALUE_CONVERSION_C="C";
	String CREATE_ORG_BOOLEAN_CONVERSION_TRUE="Y";
	String CREATE_ORG_VALUE_CONVERSION_FALSE="N";
	//String NEW_PASSWORD="NEW_PASSWORD";
	
	String AUD_REC_STATUS_NEW="C";
	String AUD_REC_STATUS_APPROVED="A";
	String AUD_REC_STATUS_MODIFIED="M";
	String AUD_REC_STATUS_REJECT="R";
	String AUD_REC_STATUS_DELETED="D";
	String MASTER_REQ_STATUS_NEW="WA";
	String MASTER_REQ_STATUS_APPROVED="NA";
	String MASTER_REQ_STATUS_MODIFIED="MO";
	String MASTER_REQ_STATUS_REJECT="R";
	String MASTER_REQ_STATUS_DELETE="DM";
	
	//Brnach Discounting Setup
	String BRANCH_DISC_DISCPAY="M";
	String BRANCH_DISC_MATUREPAY="D";
	String BRANCH_DISC_BOTH="B";
	String BRANCH_DISC_NIL="N";
	String 	DISCOUNTAPPROVESUMMARY = 	"DISCOUNTAPPROVESUMMARY";
	String  DISCOUNTRELEASESUMMARY = "DISCOUNTRELEASESUMMARY";
	String DISCOUNTCANCELSUMMARY = "DISCOUNTCANCELSUMMARY";
	String DISCOUNTCONFIRMATIONSUMMARY = "DISCOUNTCANCELSUMMARY";
	String DISCREQUESTCONF = "DISCREQUESTCONF";
	String BUYERACCEPTANCE="BUYERACCEPTANCE";

	// LinkUser OrganizationRequest/Accept
	String LINK_STATUS_REJECT_WAITING="RW";
	String LINK_STATUS_APPVOVAL_WAITING="AW";
	String LINK_REC_STATUS_ACC_DELETE = "DW";
	String MASTER_REQ_STATUS_AUTHORISED="AA";

	//For request or import Admin certificate
	String REQIMPCERT="REQIMPCERT";
	String ISSUEBANKCERT="ISSUEBANKCERT";
	String USERCERTMANAGEMENT="USERCERTMANAGEMENT";

	//Discounting Definition setup
	String DISCDEF="DISCDEF";
	String DISCRATE="DISCRATE";
	
	//User Admin
	String BANKADMINUSERS="BANKADMINUSERS";
	String REGADMINUSER="REGADMINUSER";
	String BANKADMINUSERUPDATE="BANKADMINUSERUPDATE";
	String ORGCREATEUSER="ORGCREATEUSER";
	
	// Added for create organizaton
	String CREATEORG="CREATEORG";
	
	// Added for Regional admin
	String REG_ADMIN_ROLE = "REG_ADMIN_ROLE";
	String ALLOWED="Y";
	
	// Added for Link org for discounting

	String LINKORGDISC="LINKORGDISC";
	String COUNTERPARTYLIMITSETUP = "COUNTERPARTYLIMITSETUP";
	

	// Added for Link user to organization request and accept
	String LINKUSERTOORGREQ="LINKUSERTOORGREQ";
	String LINKUSERTOORGACC="LINKUSERTOORGACC";

	// Added for Program setup
	String PROGRAMSETUP = "PROGRAMSETUP";
	String PROGRAM_ID_COLUMN = "programIDColumn";
	String PROGRAM_ID_COLUMN_COUTNER_PARTY = "programIDColumnInCounterParty";

	//Added for static link org and bene
	String LINKORGANDBENE="LINKORGBENE";
	

	//Added for Discounting
	
	String PAYABLES="Payables";
	String RECEIVABLES="Receivables";
	String PAYMENTS="Payments";
	String INVOICES="Invoices";
	
	//Added for LinkBank Admin to branch
	String LINKBANKADMINTOBRANCH = "LINKBANKADMINBRANCH";
	
	//Added for Regional Admin
	String UNAPPROVED_ACTION_COLUMN = "unApprovedActionsColumn";
	String USER_ID_COLUMN = "userIDColumn";
	String PRIMARY_ID_COLUMN = "primaryIDColumn";
	String USER_STATUS_ENABLED = "EN";
	
	String DISCOUNTSPREAD="DISCSPREAD";

	//Added for BankCode Type
	String BANK_CODE_TYPE_ID_COLUMN="typeIDColumn";
	
	//Added for Buyer Account Screen DefectID 1701
	String BUYER_ORGID_COLUMN_BUYER_ACC="buyerOrgIdColumnInBuyerAcc";
	String SUPPLIER_ORGID_COLUMN_SUPPLIER_ACC="supplierOrgIdColumnInSupplierAcc";
	String USER_ID_COLUMN_IN_CERTIFICATE="userIdColumnInCertificate";

	
	//ACCESS LOG TRANSACTIONS
	String ACCESS_LOG_FILE_UPLOAD="FILE UPLOAD";
	String ACCESS_LOG_FILE_RELEASE="FILE RELEASE";
	String ACCESS_LOG_FILE_UNDO="FILE UNDO";
	String ACCESS_LOG_FILE_PENDING_FOR_AUTHORIZATION="FILE PENDING FOR AUTHORIZATION";
	String ACCESS_LOG_DISCOUNT_RAISE="RAISE DISCOUNT";
	String ACCESS_LOG_DISCOUNT_APPROVE="DISCOUNT APPROVE";
	String ACCESS_LOG_DISCOUNT_REJECT="DISCOUNT REJECT";
	String ACCESS_LOG_RELEASE_DISCOUNT="RELEASE DISCOUNT";
	String ACCESS_LOG_RELEASE_DISCOUNT_APPROVE="RELEASE DISCOUNT APPROVE";
	String ACCESS_LOG_RELEASE_DISCOUNT_REJECT="RELEASE DISCOUNT REJECT";
	String ACCESS_LOG_RELEASE_DISCOUNT_UNDO="RELEASE DISCOUNT UNDO";
	String ACCESS_LOG_CANCEL_DISCOUNT="CANCEL DISCOUNT REQUEST";
	String ACCESS_LOG_CANCEL_DISCOUNT_APPROVE="CANCEL DISCOUNT REQUEST APPROVE";
	String ACCESS_LOG_CANCEL_DISCOUNT_UNDO="CANCEL DISCOUNT REQUEST UNDO";
	String ACCESS_LOG_CONFIRM_DISCOUNT="CONFIRM DISCOUNT REQUEST";
	String ACCESS_LOG_CONFIRM_DISCOUNT_REJECT="CONFIRM DISCOUNT REQUEST REJECT";
	String ACCESS_LOG_UPDATE_MATURITY_PYMT="UPDATE MATURITY SETTLEMENT";
	String ACCESS_LOG_UPD_DISC_SETTLMNT="UPDATE DISCOUNT SETTLEMENT";
	String ACCESS_LOG_UPD_PYBLE_SETTLMNT="UPDATE PAYABLE SETTLEMENT";
	String ACCESS_LOG_APPROVE_MATURITY_PYMT="APPROVE MATURITY SETTLEMENT";
	String ACCESS_LOG_APPROVE_DISC_SETTLMNT="APPROVE DISCOUNT SETTLEMENT";
	String ACCESS_LOG_APPROVE_PYBLE_SETTLMNT="APPROVE PAYABLE SETTLEMENT";
	String ACCESS_LOG_SETTLMNT_DOWNLOAD="SETTLEMENT DOWNLOAD";
	String MANUALFILEUPLOAD="MANUALFILEUPLOAD";
	String SETTLEMENTS="SETTLEMENTS";
	String DOWNLOADSETTLEMENT="DOWNLOADSETTLEMENT";	
	
	String DISCOUNTREQUEST="DISCOUNTREQUEST";
	
	String LINK_STATUS_PENDING_WAITING="PW";
	// added for Resend Suppress Release 1.1
	String MESSAGEMONITORING="MESSAGEMONITORING";
	// end for Resend Suppress Release 1.1

	// added for Resend Suppress Release 1.1
	String CRC_STATUS="NOT VALIDATED";
	String NOTALLOWED_STATUS="N";
	// end for Resend Suppress Release 1.1
	
	String GROUP_ID_COLUMN = "groupIdColumn";
	String REF_NO_JOIN=" for the Reference No ";
	//TD4375
	String ORG_NAME_COLUMN="orgName";
	
	/* Added for Certificate Management Screen */		
	String CERTMANAGEMENT="CERTMANAGEMENT";

	String PAYMENT_METHOD = "PYMTMTHD";

	/* Added for Financial Inquiry */
	String FINANCIAL_INQ="FINANCIALINQ";
	/* Added for CreditNote Inquiry */
	String CREDITNOTEINQUIRY="CREDITNOTEINQUIRY";

	/* Added for Printer Definiton */
	String PRINTER_DEF="PRINTERDEFINITION";
		
	/* Added for Auto Discounting */
	String AUTO_DISC="AUTODISCOUNT";

	/* Added for Currency Setup*/
	String CCY_SETUP="CURRENCYSETUP";
	String CCY_HOLIDAY="CURRENCYHOLIDAY";
	/* Added for Support Branch Holiday Setup*/
	String SUP_BRANCH_HOLIDAY="BRANCHOLIDAYSETUP";

	String DUEDATEADJUST = "DUEDATEADJUST";
	
	String PYMT_MTHD_BRANCH = "PYMTMTHDBYBRANCH";
	String BANK_MARGIN_ACCOUNT = "BANKMARGINACCOUNT";
	String EPDFORBUYER = "EPDFORBUYER";
    String DISPCODE ="DISPCODE";
	String PYMTADJCODE="PYMTADJCODE";
	
	
	/* Added for Link Organization for EIPP  */
	String LINKORGEIPP="LINKORGEIPP";
	
	/* Added for Dispute Allocation Rule  */
	String	DISPALLOCRULE="DISPALLOCRULE";

	String BILLTYPE="BILLTYPE";
	String BILLTYPELOGO="BILLTYPELOGO";

	String DEPARTMENTEIPP = "DEPARTMENTEIPP";
	String DEPARTMENTALLOCRULEEIPP = "DEPARTMENTALLOCRULEEIPP";	

	String BILL_TYPE_STYLE_SHEET="BILLTYPESTYLESHEET";
	
	String BRANDING="BRANDING";
	String DISPUTE_MGMT = "DISPUTEMGMT";

	String BCMBOA = "BCMBOA";                                                                                                                                                                               
	String SCMBOA = "SCMBOA";                                                                                                                                                                                    
	String BCMSOA = "BCMSOA";                                                                                                                                                                             
	
	/* Added for Job Monitoring*/
	String SCMSOA = "SCMSOA";                                                                                                                                                                                    
	String BCMB = "BCMB";                                                                                                                                                                              
	String BCMS = "BCMS";                                                                                                                                                                                  
	String SCMB = "SCMB";                                                                                                                                                                                     
	String SCMS = "SCMS";   
	String BCMBALL = "BCMBALL";
	String BCMSALL = "BCMSALL";
	String SCMBALL = "SCMBALL";
	String SCMSALL = "SCMSALL";

	String EIPP = "EIPP";
	String SCF = "SCF";
	String EDRAFT = "EDRAFT";

	String SCHEDULEREP = "SCHEDULEREP";
	String ONLINEREP="ONLINEREP";
	String VIEWSCHEDULEREP="VIEWSCHEDULEREP";
	String AUDITTRAILREPORT="AUDITTRAILREPORT";
	String CREDITNOTEREPORT="CREDITNOTEREPORT";
	String DISPUTERESOLUTIONREPORT="DISPUTERESOLUTIONREPORT";
	String EMAILRECIPIENTSETUPREPORT="EMAILRECIPIENTSETUPREPORT";
	String MISTRANSACTIONCOUNTREPORT="MISTRANSACTIONCOUNTREPORT";
	String NONFINANCIALINQUIRYREPORT="NONFINANCIALINQUIRYREPORT";
	
	 /* Added for EIPP Inquiry screens */
	 String EIPPCREDITNOTEINQUIRY="EIPPCREDITNOTEINQUIRY";
	 String EIPPNONFININQUIRY="EIPPNONFININQUIRY";

	String DEPARTMENTAPPROVALEIPP="DEPTAPPROVAL";
	
	
	/* Added for Dispute Inquiry */
	String DISPUTE_INQ="DISPUTEINQ";
	String	EIPPINVCCANCEL="EIPPINVCCANCEL";
	String TRANS_EIPP = "TRANSEIPP";
	String SUPPLIER="SUPPLIER";

/* ADDED FOR EDRAFT - START */
	String EDRAFT_MANUALFILEUPLOAD = "EDRAFTMANUALFILEUPLOAD";
	String NOTIFICATION_ACCEPTED = "NOTIACCEPT";
	String ENDORSEMENT_ACCEPTED = "ENDACCEPT";
	String Y = "Y";
	String N = "N";
	String COLL_DWLD_HEADER_LIST = "COLL_DWLD_HEADER_LIST";
	String COLL_DWLD_FILE_NAME = "COLL_DWLD_FILE_NAME";
	String ENDR_COLL_DWLD_HEADER_LIST = "ENDR_COLL_DWLD_HEADER_LIST";
	String ENDR_COLL_DWLD_FILE_NAME = "ENDR_COLL_DWLD_FILE_NAME";
	String DISC_DWLD_HEADER_LIST = "DISC_DWLD_HEADER_LIST";
	String DISC_DWLD_FILE_NAME = "DISC_DWLD_FILE_NAME";
	String ENDR_DWLD_HEADER_LIST = "ENDR_DWLD_HEADER_LIST";
	String ENDR_DWLD_FILE_NAME = "ENDR_DWLD_FILE_NAME";
	String PAYM_DWLD_FILE_NAME = "PAYM_DWLD_FILE_NAME";
	String OVER_PAYM_DWLD_FILE_NAME = "OVER_PAYM_DWLD_FILE_NAME";
	String INQR_DWLD_FILE_NAME = "INQR_DWLD_FILE_NAME";
	
	
	String JMS_HEADER_EXT_QUEUE = "message.jms.header.extqueue";
	String JMS_HEADER_EXT_QUEUE_NAME = "message.type.remote.queuename";
	String JMS_HEADER_MSG_ID = "message.jms.header.bnppmsgid";
	String JMS_MSG_TYPE_SEND_QUEUE_NAME = "message.type.send.queuename";
	String JMS_MSG_TYPE_SEND_LOCAL_QUEUE_NAME = "message.type.local.send.queuename";
	String TRANS_DISC_REQ = "edraft.trans.disc.req";
	String TRANS_END_REQ = "edraft.trans.endr.req";
	
	//Added for review fix - By Ganga -Starts
	String EDRAFT_END_REVOC_HEADER_LIST = "EDRAFT_END_REVOC_HEADER_LIST";
	String EDRAFT_END_REVOC_FILE_NAME = "EDRAFT_END_REVOC_FILE_NAME";
	String EDRAFT_PMT_HEADER_LIST = "EDRAFT_PMT_HEADER_LIST";
	String EDRAFT_OVERDUE_PMT_HEADER_LIST = "EDRAFT_OVERDUE_PMT_HEADER_LIST";
	String EDRAFT_TRANS_INQ_HEADER_LIST = "EDRAFT_TRANS_INQ_HEADER_LIST";
	//Added for retro fix 
	String REV_ENDREQACK = "ENDREQACK";
	String REV_ENDREQPP = "ENDREQPP";
	//Fix for SIT -49 
	String COLL_ACC = "PAC";
	String COLL_REJ = "PRE";

	String EDRAFT_ISSUER_COMMITMENT = "bnp.edraft.default.issuer.commitment";
	String EDRAFT_ACCEPTOR_COMMITMENT = "bnp.edraft.default.acceptor.commitment";
	
	
/* ADDED FOR EDRAFT - END */	
	
	/* MULTI BANKING CONSTANTS - START */
	
	// Third Party Bank 
	String THIRDPARTYBANK = "THIRDPARTYBANK";
	String THIRDPARTYBANKUSER="THIRDPARTYBANKUSER";
	String THIRDPARTY = "TP";
	
	/* MULTI BANKING CONSTANTS - END */
	
	
	// Multibanking - Discounting Defn. - Begin
	String EMPTY_STRING = "";
	String PRO_RATA_MODEL = "Pro-rata";
	String PRO_RATA_MODEL_VALUE = "Pro-rata";
	String SUPPLIER_DIRECT = "Supplier Direct";
	String SUPPLIER_DIRECT_MODEL_VALUE = "Supplier Direct";
	String YES_CONSTANT = "YES";
	String NO_CONSTANT = "No";
	String MULTI_BANK_CONSTANT = "MBK";
	String EPD_CONSTANT = "EPD";
	String UNFUNDED_CONSTANT = "UNFUNDED";
	String DEFAUlT_CONSTANT = "DEFAULT";
	String TRUE_FLAG = "true";
	String YES_CONSTANT_VALUE = "Y";
	String NO_CONSTANT_VALUE = "N";
	String ACCT_TYPE_FUNDING = "FUNDING";
	String ACCT_TYPE_SETTLEMENT = "SETTLEMENT";
	String NEW_VALUE = "NEW";
	String VIEW_SAVE =  "viewSave";
	String ONE_VALUE = "1";
	String TWO_VALUE = "2";
	String THREE_VALUE = "3";
	String FOUR_VALUE = "4";
	String FIVE_VALUE = "5";
	String SIX_VALUE = "6";
	String SEVEN_VALUE = "7";
	String EIGHT_VALUE = "8";
	String NINE_VALUE = "9";
	String SUMMARY_APPROVE = "summaryApprove";
	String VIEW_APPROVE = "viewApprove";
	// Multibanking - Discounting Defn. - End
	
	
	 /* MB Changes
	  * Added for Third party bank */
	 String THIRDPARTYBANKACCT="THIRDPARTYBANKACCT";
	 //toolkit changes
	  String FILERELEASE = "TOOLKITRELEASEFILE";
	  
	  	 // added for Multibanking Discount Request Transaction
	 String TPDISCTRANS = "TPDISCTRANS";
	 
	 String DISC_REQUEST = "discRequest";
	 String FT_REQUEST = "ftRequest";
	 String BNP_VALUE = "BNP";
	 String ALL_VALUE = "ALL";
	 
	String JOBMONITORING="JOBMONITORING";
	String JOBSCHEDULER="JOBSCHEDULER";

	 /* Added for Discount Inquiry */
	 String DISCINQUIRYREQUEST="DISCINQUIRYREQUEST";
	/* Added for 2.2 Reports*/
	String AGINGREPORT="AGINGREPORT";
	String CREDITFUNDINGREPORT="CREDITFUNDINGREPORT";
	String DISCOUNTTRANSACTIONREPORT= "DISCOUNTTRANSACTIONREPORT";
	String INSURANCEUSAGEREPORT = "INSURANCEUSAGEREPORT";
	String EARLYPAYEMENTDISCOUNTREPORT ="EARLYPAYEMENTDISCOUNTREPORT";
	String MARGINREPORTBUYER="MARGINREPORTBUYER";
	String MARGINTRANSACTIONREPORT="MARGINTRANSACTIONREPORT";
	String REMITTANCEREPORT="REMITTANCEREPORT";
	String REPORT="REPORT";
	String BA_REPORT="BAREPORT";
	
	/* Added for 3.0 Reports*/
	String CREDITUSAGEREPORT="CREDITUSAGEREPORT";
	String DUEDATEADJUSTMENTREPORT="DUEDATEADJUSTMENTREPORT";
	
	// Start : Added for Release 2.2 Multi banking Discount Transaction Report
	String MBDISCTRANSREP = "Multi Banking Discount Transaction Report";
	String BRANCHID_LIST = "branchIdList";
	String THIRD_PARTY_BRANCH_ID_LIST = "thirdPartyBranchIDList";
	String BUYER_ID = "buyerID";
	String SUPPLIER_ID = "supplierID";
	String CURRENCY = "currency";
	String MULTI_BANK_BRANCHID_LIST = "multiBankBranchIdList";
	String MULTI_BANK_SUPPLIER_ID = "multiBankSupplierID";
	String MULTI_BANK_BUYER_ID = "multiBankBuyerID";
	// Ends : Added for Release 2.2 Multi banking Discount Transaction Report	
	
	 //Added for Insurance - Mar 8, 2012 starts
	 String INSURANCELIMIT="INSURANCELIMIT";
	 String LIMITUTILREPORT="LIMITUTILREPORT";
	 //Added for Insurance - Mar 8, 2012 ends0

	//Start - Added by sonika on 23apr2012 for Eware screens
	String SUMMARY="SUMMARY";
	//String EWARESUMMARY="EWARESUMMARY";
	
	//docset
	/*String DOCUMENTSET="DOCUMENTSET";
	String DOCUMENTSETINQUIRY="DOCUMENTSETINQUIRY";
	String DOCUMENTUPLOAD="DOCUMENTUPLOAD";
	String DOCUMENTUPLOADSUMMARY="DOCUMENTUPLOADSUMMARY";
	String RELEASEFILEINQUIRY= "RELEASEFILEINQUIRY";
	String DOCUMENTRETURN="DOCUMENTRETURN";
	String ACKNOWLEDGMENTQUEUE ="ACKNOWLEDGMENTQUEUE";
	String BRANCHSCRUTINYQUEUE="BRANCHSCRUTINYQUEUE";
	String RESPONSETOBANKTHROWBACK="RESPONSETOBANKTHROWBACK";
	String REGULARSCRUTINYQUEUE="REGULARSCRUTINYQUEUE";*/
	
	//BE
	/*String AUTHBEINITIATION="AUTHBEINITIATION";
	String AUTHORIZESCRUTINYQUEUE="AUTHORIZESCRUTINYQUEUE";
	String BEACKQUEUEBE="BEACKQUEUEBE";
	String BEAUTHREGULARSCRUTINY="BEAUTHREGULARSCRUTINY";
	String BEBRANCHSCRUTINYQUEUE="BEBRANCHSCRUTINYQUEUE";
	String BEINITIATION="BEINITIATION";
	String BEINQUIRY="BEINQUIRY";
	String BENEFICIARYDETAILREPORT="BENEFICIARYDETAILREPORT";
	String BEREGULARSCRUTINY="BEREGULARSCRUTINY";
	String BERESPONSETOBANKTHROW="BERESPONSETOBANKTHROW";*/
	//reports
	String REPORTS="REPORTS";
	String FIXEDREPORTS="FIXEDREPORTS";
	String AUDITTRAILREPORTS="AUDITTRAILREPORTS";
	String AUDITTRAILREPORTSFORDOCFLOW="AUDITTRAILREPORTSFORDOCFLOW";
	String AUDITTRAILREPORTSFORMAINTAIN="AUDITTRAILREPORTSFORMAINTAIN";
	String CUSTOMIZEDINVOICEDETAILREPORT="CUSTOMIZEDINVOICEDETAILREPORT";
	String CUSTOMIZEDREPORTS="CUSTOMIZEDREPORTS";
	String DETAILDOCSTATUSREPORT="DETAILDOCSTATUSREPORT";
	String DETAILDOCSUMMARYREPORT="DETAILDOCSUMMARYREPORT";
	String DETAILPAYSTATUSREPORT="DETAILPAYSTATUSREPORT";	
	
	//payment
	String PAYMENT="PAYMENT";
	String EXCEPTIONHANDLING="EXCEPTIONHANDLING";	
	String INITITATEPAYMENT="INITITATEPAYMENT";
	String PAYMENTACKNOWLEDGMENT="PAYMENTACKNOWLEDGMENT";
	String PAYMENTAUTHORIZATION="PAYMENTAUTHORIZATION";
	String PAYMENTCONSOLIDATION="PAYMENTCONSOLIDATION";
	String PAYMENTFILEGENERATION="PAYMENTFILEGENERATION";
	String PAYMENTGENERATION="PAYMENTGENERATION";
	String PAYMENTSCRUTINY="PAYMENTSCRUTINY";	
	String  EXCEPTIONPAYMENTBRANCH ="EXCEPTIONPAYMENTBRANCH";
	String  EXCEPTIONPAYMENTCUSTOMER ="EXCEPTIONPAYMENTCUSTOMER";
	String  EXCEPTIONPAYMENTMO ="EXCEPTIONPAYMENTMO";
	
	//static
	String USERGROUP="USERGROUP";
	//String CREATEORGEWARE="CREATEORGEWARE";
	//String EVENTCONFIGEWARE="EVENTCONFIGEWARE";
	//String BUYERACCTEWARE="BUYERACCTEWARE";
	//String LINKBANKADMINBRANCHEWARE="LINKBANKADMINBRANCHEWARE";
	String FETCHACCFRMATLAS2 = "FETCHACCFRMATLAS2";
	
	//End - Added by sonika on 23apr2012 for Eware screens
	
	 	/* Added for EDraft Static Scren */
	String EDRAFT_USER_HRCHY_SETUP = "EDRAFTUSERHRCHYSETUP";
	String EDRAFT_AUTH_PROFILE_SETUP = "EDRAFTAUTHPROFILESETUP";
	
	/* Added for pledge */
	String EDRAFT_PLEDGE_SUMMARY = "EDRAFTPLDGRREQ";
	String PLEDGE_REQ_DWLD_HEADER_LIST="PLEDGE_REQ_DWLD_HEADER_LIST";
	String PLEDGE_REQ_DWLD_FILE_NAME="PLEDGE_REQ_DWLD_FILE_NAME";
	String PLEDGE_PLDGR_REL_DWLD_HEADER_LIST="PLEDGE_PLDGR_REL_DWLD_HEADER_LIST";
	String PLEDGE_PLDGR_REL_DWLD_FILE_NAME="PLEDGE_PLDGR_REL_DWLD_FILE_NAME";
	String PLEDGE_PLDGEE_REQ_SIGNOFF_DWLD_HEADER_LIST="PLEDGE_PLDGEE_REQ_SIGNOFF_DWLD_HEADER_LIST";
	String PLEDGE_PLDGEE_REQ_SIGNOFF_DWLD_FILE_NAME="PLEDGE_PLDGEE_REQ_SIGNOFF_DWLD_FILE_NAME";		
	String PLEDGE_PLDGEE_REL_REQ_DWLD_HEADER_LIST="PLEDGE_PLDGEE_REL_REQ_DWLD_HEADER_LIST";
	String PLEDGE_PLDGEE_REL_REQ_DWLD_FILE_NAME="PLEDGE_PLDGEE_REL_REQ_DWLD_FILE_NAME";
	
	String TRANS_PLDGR_PLDG_REQ="edraft.trans.pledge.req";
	String PLDGR_PLDG_REQ_MAPPER="message.edraft.pledge.pledgereq.xsd.path";

	String TRANS_PLDGEE_PLDG_REL_REQ="edraft.trans.pledgee.rel.req";
	String PLDGEE_PLDG_REL_REQ_MAPPER="message.edraft.pledge.pledgerelreq.xsd.path";

	/* Added for Guarantee & Withdraw */
	String EDRAFT_GUAR_REQ_DWLD_HEADER_LIST = "EDRAFT_GUAR_REQ_DWLD_HEADER_LIST";
	String EDRAFT_GUAR_REQ_DWLD_FILE_NAME = "EDRAFT_GUAR_REQ_DWLD_FILE_NAME";
	String EDRAFT_GUAR_REC_DWLD_HEADER_LIST = "EDRAFT_GUAR_REC_DWLD_HEADER_LIST";
	String EDRAFT_GUAR_REC_DWLD_FILE_NAME = "EDRAFT_GUAR_REC_DWLD_FILE_NAME";
	String EDRAFT_WITHDR_REQ_DWLD_HEADER_LIST = "EDRAFT_WITHDR_REQ_DWLD_HEADER_LIST";
	String EDRAFT_WITHDR_REQ_DWLD_FILE_NAME = "EDRAFT_WITHDR_REQ_DWLD_FILE_NAME";

	String TRANS_GUAR_REQ = "edraft.trans.guarantee.req";
	String TRANS_WITHDRAW_REQ = "edraft.trans.withDraw.req";
	
	String GUARANTEE_NEW_REQ_RECEIVED="GRTREQSPP";	
	
	String EDRAFT_ISSUANCE_HEADER_LIST="EDRAFT_ISSUANCE_HEADER_LIST";
	String EDRAFT_ISSUANCE_FILE_NAME="EDRAFT_ISSUANCE_FILE_NAME";

	String EDRAFT_ACCEPTANCE_HEADER_LIST="EDRAFT_ACCEPTANCE_HEADER_LIST";
	String EDRAFT_ACCEPTANCE_FILE_NAME="EDRAFT_ACCEPTANCE_FILE_NAME";
	
	String EDRAFT_ACCEPTANCE_PRESENT_HEADER_LIST="EDRAFT_ACCEPTANCE_PRESENT_HEADER_LIST";
	String EDRAFT_ACCEPTANCE_PRESENT_FILE_NAME="EDRAFT_ACCEPTANCE_PRESENT_FILE_NAME";
	
	String ISSUE_REQ = "edraft.issue.req";
	
	String ACCEPT_REQ = "edraft.accept.req";
	
	String COLLECTION_REQ = "edraft.collection.req";
	
	/* Added for common acceptance message */
	String EDRAFT_COMM_ACC_TYPE="trans.type.edraft.acc.send";
	String EDRAFT_COMM_ACC_XSD_PATH="message.edraft.acc.xsd";

	String EDRAFT_PMT_REQ_RECD_HEADER_LIST = "PMT_REQ_RECD_HEADER_LIST";
	String EDRAFT_PMT_REQ_RECD_FILE_NAME = "PMT_REQ_RECD_FILE_NAME";
	
	String ACCREQMAKER="accReqMaker";
	String ACCREQCHECKER="accReqChecker";
	String ACCPRESENTMAKER="accPresentMaker";
	String ACCPRESENTCHECKER="accPresentChecker";

	/* Added For Recourse - START */
	String RECOURSE_DWLD_FILE_NAME = "RECOURSE_DWLD_FILE_NAME";
	String TRANS_REC_REQ = "edraft.trans.recourse.req";
	String TRANS_REC_NOTI_REQ = "edraft.trans.recourse.noti";
	String EDRAFT_RECOURSE_HEADER_LIST = "EDRAFT_RECOURSE_HEADER_LIST";
	/* Added For Recourse - END */

	//added for repo&redem
	
	String REPO_DISC_DWLD_HEADER_LIST = "REPO_DISC_DWLD_HEADER_LIST";
	String REPO_DISC_DWLD_FILE_NAME = "REPO_DISC_DWLD_FILE_NAME";
	String REDEM_DISC_DWLD_HEADER_LIST = "REDEM_DISC_DWLD_HEADER_LIST";
	String REDEM_DISC_DWLD_FILE_NAME = "REDEM_DISC_DWLD_FILE_NAME";
	String REPO_ACCEPTED = "REPORDMSIGD";
	String ISSUE_REGD = "ISSREGD";
	String ACCPT_PRES_SIGD = "ACPREQSIGD";
//	String REPO_REDM_SIGD = "REPOREDMSSIGD";
	String PLG_REL_SIGD = "PLGRELSSIGD";
	
	String PLEDGE_ACC = "PLGRELSSIGD";
	
	//Added for collection request
	String EDRAFT_REQ_COLL_HEADER_LIST = "EDRAFT_REQ_COLL_HEADER_LIST";
	String EDRAFT_REQ_COLL_FILE_NAME = "EDRAFT_REQ_COLL_FILE_NAME";
	
	//Fix for UAT defect 294(CR)- Starts
	String DC00 = "DC00";
	String DC01 = "DC01";
	String DC02 = "DC02";
	String DC03 = "DC03";
	String DC04 = "DC04";
	String DC05 = "DC05";
	String DC06 = "DC06";
	String DC07 = "DC07";
	String DC08 = "DC08";
	String DC09 = "DC09";
	//Fix for UAT defect 294(CR) -Ends	
	
/* ADDED FOR EDRAFT - END */

	//Added for TP Discounting Access Logger starts
	String ACCESS_LOG_TPDISCOUNT_SAVE="TPDISCOUNT SAVE";
	String ACCESS_LOG_TPDISCOUNT_APPROVE="TPDISCOUNT APPROVE";
	String ACCESS_LOG_TPDISCOUNT_REJECT="TPDISCOUNT REJECT";
	String ACCESS_LOG_TPDISCOUNT_UNDO="TPDISCOUNT UNDO";
	String ACCESS_LOG_TPDISCOUNT_INTIATE="TPDISCOUNT INTIATE";
	String ACCESS_LOG_TPDISCOUNT_FININQ="TPDISCOUNT FININQUIRY";
	String ACCESS_LOG_TPDISCOUNT_TXNHIST="TPDISCOUNT TXNHISTORY";
	//Added for TP Discounting Access Logger Ends

	 //Added for Marketing & Onboarding Site Maintenance
	 
	 String KYCLGLDOCSETUP="KYCLGLDOCSETUP";
	 String ENBMRKTSITE="ENBMRKTSITE";
	 String INVTEMAILTMPLTE="INVTEMAILTMPLTE";
	 String SUPPLRONBRDG="SUPPLRONBRDG";
	 String SUPPLRACTMGMT = "SUPPLRACTMGMT";
	 
String CUSTSPOTLGHT= "CUSTSPOTLGHT";
	String MRKMATFRMBANK = "MRKMATFRMBANK";
	 //Added for EIPP Phase 2
	 String DIRECTDEBITMANDATE="DIRECTDEBITMANDATE";
	 String MARKETPLACEACCOUNT="MKTPLACEACCT";

 //Added for R3.0 Marketing Marketing and On boarding site  starts
 String ORGONBRDTEMP="ORGONBRDTEMP";
 //Added for R3.0 Marketing Marketing and On boarding site  ends
 
 //Added for EIPP Phase 2
 String BILLINGACCOUNT="BILLINGACCOUNT";
 
 /*Added for EIPP phase 2 - STARTS*/
 String AUTOPAYMENTRULE ="AUTOPYMTRULESETUP";
 String AUTOAUTHORIZATIONRULESETUP = "AUTOAUTHORIZATIONRULESETUP";
 
 /*market place changes*/
 
String BCMMPALL = "BCMMPALL";
String BCMMPOA = "BCMMPOA";
String BCMMPU = "BCMMPU";
String BCMMPBALL = "BCMMPBALL";
String BCMMPBOA = "BCMMPBOA";
String BCMMPB = "BCMMPB";
String BCMMPSALL = "BCMMPSALL";
String BCMMPSOA = "BCMMPSOA";
String BCMMPS = "BCMMPS";
String SCMMPALL = "SCMMPALL";
String SCMMPOA = "SCMMPOA";
String SCMMPU = "SCMMPU";
String SCMMPSALL = "SCMMPSALL";
String SCMMPSOA = "SCMMPSOA";
String SCMMPS = "SCMMPS";
String SCMMPBALL = "SCMMPBALL"; 
String SCMMPBOA = "SCMMPBOA";
String SCMMPB = "SCMMPB";

String SYSTEMRA = "SYSTEMRA";
String SYSTEMBA = "SYSTEMBA";
String SYSTEMBCMMPOA = "SYSTEMBCMMPOA";
String SYSTEMSCMMPOA = "SYSTEMSCMMPOA";

String MKT_PLACE = "MKTPLACE";

String QRY_USERS_FOR_BCMMPALL = "\'BCMMPOA\',\'BCMMPU\'";
String QRY_USERS_FOR_BCMMPBALL = "\'BCMMPBOA\',\'BCMMPB\'";
String QRY_USERS_FOR_BCMMPSALL = "\'BCMMPSOA\',\'BCMMPS\'";
String QRY_USERS_FOR_SCMMPALL = "\'SCMMPOA\',\'SCMMPU\'";
String QRY_USERS_FOR_SCMMPBALL = "\'SCMMPBOA\',\'SCMMPB\'";
String QRY_USERS_FOR_SCMMPSALL = "\'SCMMPSOA\',\'SCMMPS\'";

/* Added for Default Charges */
String DEFCHARGES="DEFCHARGES";
//Added for Early Payment Rebate/Late Payment Fee Rule
String REPAYRULE="PYMTREBATEFEERULE";
//Added for Link Early Payment Rebate/Late Payment Fee Rule
	String LINK_REPAYRULE="LINKPYMTREBATEFEERULE";
String DIS_ALLOW_PYMT_MTHD="DISALLOWPYMTMTHD";



	 //Added For Default Supplier Account Setup Screen
	 String DEFAULTSUPPLIERACCOUNTSETUP="DEFAULTSUPPLIERACCOUNTSETUP";
	 String SUPPLIER_ORG_ID="supplierorgid";
	 String BILL_TYPE="billType";
	 String BUYER_ORG_ID="buyerOrgId";
	 //Added For Customer Charges Matrix Screen
	 String ORGIDWITHNAME="organizationIdWithName";
	 //Customer Charges matrix
	 String CUSTOMERCHARGESMATRIX="CUSTOMERCHARGESMATRIX";
	 String CUST_ORG_ID ="colorganizationId";
	String PREAPPSUPPLRMAIN = "PREAPPSUPPLRMAIN";
	String SUPPLRREGMGMT = "SUPPLRREGMGMT";
	

		String SUPSTATUSREPORT = "SUPSTATUSREPORT";
		String SUPSTATUSAGINGREPORT = "SUPSTATUSAGINGREPORT";
		String MARK_BUYER_ORG_ID = "markBuyerID";
		String MARK_BRANCH_ID = "branchIdList";
	//Added for Early Payment Rebate/Late Payment Fee Inquiry
String REPAYRULE_INQUIRY="PYMTREBATEFEERULEINQUIRY";

 
        // Added for Matching Rule Definition
		String MATCHRULEDEFN = "MATCHRULEDEFN";
		String ATTACHMENTUPLD="ATTACHMENTUPLD";
		//constants added for EIPP 3.0
		 String PYMTCANCELLATION="PYMTCANCELLATION";
		 String PYMTAUTHORIZE="PYMTAUTHORIZATION";
		 String EIPPFININQUIRY="EIPPFININQUIRY";
	 	String PYMT_PREPARATION = "PYMTPREPARATION";

	   //Added For Manual Status Update
	 String MANUALSTATUSUPDATE="MANUALSTATUSUPDATE";

	 String PRINTPAYMENTADVICE="PRINTPAYMENTADVICE";
	
	 // Matching Summary
	String MATCHINGSUMM = "MATCHINGSUMM";
	// View Billing Advice
	String EIPPVIEWBILL = "VIEWBILLINGADVICE";

	//Manual Billing
	String GENMANUALBILL="GENMANUALBILL";
	
	// Start : Added for Release 3.0 Matching and Reconcilation Reports
	String RECONCILATIONREPORT = "Reconcilation Report";
	String MATCHMISTRANSCNTREPORT = "Matching MIS Transaction Count Report";
	// Ends : Added for Release 3.0 Matching and Reconcilation Reports
	
	String ACCESS_LOG_RELEASE_DISCOUNT_REFRESH="REFRESH BASE RATE";
	
	String BATCHING_REFNO_INITIAL="BP";
	
	String UPD_SETTLEMENTS_MFU = "UPDSETTLEMENTSMFU";
	
	String RATE_REFRESH_MFU = "RATEREFRESHMFU";
	
	String DISC_CONFIRMATION_MFU = "DISCCONFIRMATIONMFU";
	
	String TP_DISC_CONFIRMATION_MFU = "TPDISCCONFIRMATIONMFU";

	String INV_SETTLEMENT_MFU = "INVSETTMFU";
		
	String DISCOUNTING_DOC_MFU = "DISCDOCMFU";

	String ESTAT_CONSTANT = "ESTATEMENTREG";
	String ESTATEMENTBRANDING="ESTATEMENTBRANDING";
	String ESTAT_INQUIRY_CONSTANT = "ESTATEMENT_INQUIRY";
	
	String ESTAT_USER_ACCESS_CONSTANT = "ESTMTUSERACCSUMMARY";

	//QC 3706
	String DISCOUNTRATESREPORT = "Discount Rates Report";
	
	//R5.0 Attachments
	String SCFATTACHMENTUPLD_SCRN_CONST = "SCFATTACHMENTUPLD";
	String SCFATTACHMENTUPLD = "Attachment Summary";
	String PAYMENT_TYPE = "P";
	String INVOICE_TYPE = "I";
	String CREDIT_TYPE = "C";
	String REC_STATUS_APPROVE = "A";
	String REC_STATUS_NEW = "C";
	String REC_STATUS_DELETE = "D";
	String ATTACH_ADD = "ADD";
	String ATTACH_DEL = "DEL";	
		
	String DISCOUNTING_DOC_ATTACHMENT_MFU = "DISCDOCATTACHMFU";
	// Funding Account
	String FUNDINGACCOUNT = "FUNDINGACCOUNT";
	String EXTD_TERMS_DISCOUNT = "Extended Terms Discount";
	
	/** Ability to Link Users Implementation*/
	String LINKBANKADMINTOORGANIZATION = "LINKBANKADMINTOORG";
	String  DISCOUNTCHARGES = "DISCOUNTCHARGES";

	String REPORTDESIGNER="REPORTDESIGNER";
	String CUSTOMREPORT="CUSTOMREPORT";
	String HTMLREPORT="HTMLREPORT";
	String EDRAFT_WAREHOUSING_INQUIRY="EDRAFT_WAREHOUSING_INQUIRY";
	String EDRAFTWAREHOUSINGREPORT="EDRAFTWAREHOUSINGREPORT";
	String EDRAFTREDEMPTIONREPORT="EDRAFTREDEMPTIONREPORT";
	String EDRAFTMATURITYREPORT="EDRAFTMATURITYREPORT";
	String CUSTOMREPORTTEMPLATE="CUSTOMREPORTTEMPLATE";
	
	String TEN_VALUE = "10";
	
	/** The Screen Constant of Rollver Request MFU function */
	String ROLLOVER_REQ_MFU = "ROLLOVERREQMFU"; // Added for FO R5.0 - Rollover Request MFU operations
	
	// Added for Rollover Request Summary (BEGIN)
		String DISCROLLOVERREQ = "DISCROLLOVERREQ";
		// Added for Rollover Request Summary (END)
	
	//R5.0 I3 Rollover Changes - Rollover Discount Transaction Report 
	String ROLLOVERDISCOUNTTRANSREPORT = "ROLLOVERDISCOUNTTRANSREPORT";
	String ORGANIZATION_HOLIDAY="ORGHOLIDAYSETUP";

	// Commitment Fee Payment Status Update changes starts
	String COMMITMENTFEEPYMTSTATUSUPDATE = "COMMITMENTFEEPYMTSTATUSUPDATE";
	
	String UF_BRANCH_ID = "branchId";
	String UF_ORG_ID = "orgId";
	String UF_DEBIT_REF_NO = "debitRefNo";
	String UF_CURRENT_DATE = "currentDate";
	String UF_PDF_DATA = "pdfData";
	String UF_DUE_JOB = "Due";
	String UF_ADVICE_JOB = "Advice";
	String UF_JOP_TYPE = "jobType";
	// Commitment Fee Payment Status Update changes ends
	
	//Default Values for Posting Rule for Discount Flag for receivables
	String POSING_RULE_FOR_DISCOUNT_VALUE = "M";
	
	//Added For Extended Term And Rollover Batching Changes-Starts
	String EXTND_BATCHING_REFNO_INITIAL="BE";
	String ROLLOVER_BATCHING_REFNO_INITIAL="BR";
	String ROLLOVER_REFNO_INITIAL="RP";
	String EXTND_REFNO_INITIAL="DE";
	//Added For Extended Term And Rollover Batching Changes-Ends
	
	//Added for R7.0 Marketing Materials  start
	String MRKTGMATERIALS = "MRKTGMATERIALS";
	//Added for R7.0 Marketing Materials end
	
	//Brazil changes starts
	String BUYER_ACCEPT_NOT_REQUIRED = "NR";
	String BUYER_ACCEPT_REQUIRED_WITH_APPROVAL = "RWA";
	String BUYER_ACCEPT_REQUIRED_WITHOUT_APPROVAL = "RWOA";
	String ACCESS_LOG_DISCOUNT_ACCEPT = "DISCOUNT ACCEPT"; 
	//Brazil changes ends
	

//Brazil model- Buyer Acceptance Enhancement changes starts	
	String ACCESS_LOG_DISCOUNT_REQUEST_UNDO = "DISCOUNT REQUEST APPROVAL UNDO";

	String ASSIGNREPORT="ASSIGNREPORT";
	
	//Report Viewer Screen
	String REPORTVIEWER="REPORTVIEWER";

	
	/* FO 8.0 Recall Invoice Screen*/
	String RECALLINVOICES ="RECALLINVOICES";

	
//FO 8.0 export changes starts
	String EXPORT_SUMMARY_TABLE_ID = "dynamicTable";
	String USER_AUDIT_TRAIL = "USERAUDITTRAIL";
	//String PASSWORDPRINT="PASSWORDPRINT";
	String SUMMARY_DATA_TABLE="summaryDataTable";
	String LINK_BA_TO_ORG_EXTND_TABLE_ID="fdata";
	String DISC_CONF_TABLE_ID= "ConfirmDiscountData";
	String STMT_TABLE_ID ="settlementDataTable";
	String MBK_DISC_TABLE_ID ="discountTransTable";
	String PYMT_REMINDER_TABLE_ID = "pmtReminderTable";
	// R8.0 Email Inquiry Screen
	String EMAILINQUIRY ="EMAILINQUIRY";
	
	// R8.0 LMS Static changes - Starts
	String CPLIMIT_SUMMARY_SORT1 = "branchId";
	String CPLIMIT_SUMMARY_SORT2 = "custOrgId";
	String CPLIMIT_SUMMARY_SORT3 = "lmtType";
	String CPLIMIT_SUMMARY_SORT4 = "tpBankId";
	
	// R8.0 LMS Static changes - Ends
	
	String GROUPLIMIT= "GROUPLIMIT";
	
	//R10.0 Aging Report Changes -Start
	String AGING_RPT_SUMMARY = "SUMMARY";
	String AGING_RPT_LIST = "LIST";
	String AGING_RPT_DETAILS = "DETAILS";
	String AGING_RPT_PO_DETAIL = "DETAIL_PO";
	String AGING_RPT_INV_CN_DETAIL = "DETAIL_INV_CN";
	
	//R10.0 Aging Report Changes -End
	
	
	
}