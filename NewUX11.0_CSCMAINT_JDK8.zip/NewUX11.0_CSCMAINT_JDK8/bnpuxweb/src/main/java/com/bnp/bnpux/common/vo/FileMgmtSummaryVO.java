/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14 Mar 2017	
 * 
 * Purpose:       File Management Summary Value Object
 * 
 * Change History: 
 * Date                       Author                                    Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 14 Mar 2017			      skbhaska					                Initial Version - FO 10.0 - S2005, S2007
************************************************************************************************************************************************************/
package com.bnp.bnpux.common.vo;

import java.util.Date;

public class FileMgmtSummaryVO {

	private String recordCount;
	private String recordNo;
	private String bandRecordCount;
	private String docType;
	private String senderOrgId;
	private String fileStatus;
	private String groupValue;
	private Date uploadDate;
	private String fileStatusRevamp;
	public String getFileStatusRevamp() {
		return fileStatusRevamp;
	}

	public void setFileStatusRevamp(String fileStatusRevamp) {
		this.fileStatusRevamp = fileStatusRevamp;
	}

	private Integer docTypeCode;
	private String senderOrgName;

	public String getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(String recordCount) {
		this.recordCount = recordCount;
	}

	public String getRecordNo() {
		return recordNo;
	}

	public void setRecordNo(String recordNo) {
		this.recordNo = recordNo;
	}

	public String getBandRecordCount() {
		return bandRecordCount;
	}

	public void setBandRecordCount(String bandRecordCount) {
		this.bandRecordCount = bandRecordCount;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public Date getUploadDate() {
		return uploadDate;
	}

	public void setUploadDate(Date uploadDate) {
		this.uploadDate = uploadDate;
	}

	public Integer getDocTypeCode() {
		return docTypeCode;
	}

	public void setDocTypeCode(Integer docTypeCode) {
		this.docTypeCode = docTypeCode;
	}

	public String getSenderOrgId() {
		return senderOrgId;
	}

	public void setSenderOrgId(String senderOrgId) {
		this.senderOrgId = senderOrgId;
	}

	public String getFileStatus() {
		return fileStatus;
	}

	public void setFileStatus(String fileStatus) {
		this.fileStatus = fileStatus;
	}

	public String getSenderOrgName() {
		return senderOrgName;
	}

	public void setSenderOrgName(String senderOrgName) {
		this.senderOrgName = senderOrgName;
	}

	public String getGroupValue() {
		return groupValue;
	}

	public void setGroupValue(String groupValue) {
		this.groupValue = groupValue;
	}

	
}
