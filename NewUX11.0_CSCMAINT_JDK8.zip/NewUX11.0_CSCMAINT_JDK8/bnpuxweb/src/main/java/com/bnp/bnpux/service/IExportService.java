/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd - SCF UX
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:     Export Service Interface
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version 
 
 *****************************************************************************************************************************************************************/

package com.bnp.bnpux.service;

import java.io.IOException;

import javax.servlet.ServletOutputStream;

import com.bnp.bnpux.vo.requestVO.ExportRequestVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface IExportService {
 
	/**
	 * This method is for getting Payment Order Export Details
	 * 
	 * @param exportRequestVO
	 * @param outputStream
	 * @throws BNPApplicationException
	 * @throws IOException
	 */
	public void getPaymentOrderExportDetails(ExportRequestVO exportRequestVO, ServletOutputStream outputStream) throws BNPApplicationException, IOException;
	
	/**
	 * This method is for getting Transaction ResultSet
	 * 
	 * @param transactionReqVO
	 * @param outputStream
	 * @throws BNPApplicationException
	 * @throws IOException
	 */
	public  void getTransactionResultSet(ExportRequestVO transactionReqVO, ServletOutputStream outputStream) throws BNPApplicationException, IOException;

	/**
	 * This method is for getting Settlement Results
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @throws BNPApplicationException
	 * @throws IOException
	 */
	public void getSettlementResults(ExportRequestVO exportVO, ServletOutputStream outputStream) throws BNPApplicationException , IOException;

	/**
	 * This method is for getting Reports Export
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException
	 */
	public void getReportsExport(ExportRequestVO exportVO, ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException , IOException;

	/**
	 * This method is for getting Reports Export
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException
	 */
	public void getCreditNoteReportsExport(ExportRequestVO exportVO, ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException , IOException;
	
	
	/**
	 * This method is for getting Limit Utilization Reports Export
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException
	 */
	public void getLimitUtilReportsExport(ExportRequestVO exportVO,ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException,IOException;
	
	//Discount Transaction Report Export
	/**
	 * This method is for getting Discount Transaction Reports Export
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException
	 */
	public void getDiscTransReportsExport(ExportRequestVO exportVO,ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException,IOException;
	//CMA
	/**
	 * This method is for getting Settlement Due Reminder Reports Export
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException
	 */
	public void getExportSettlementDueReminderReportsData(ExportRequestVO exportVO, ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException , IOException;
	
	/**
	 * This method is for getting Payment Reports Export
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException
	 */
	public void getExportPaymentReportsData(ExportRequestVO exportVO, ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException , IOException;

	/**
	 * This method is for getting Payment Order Export PopUp Details
	 * 
	 * @param exportRequestVO
	 * @param outputStream
	 * @throws BNPApplicationException
	 * @throws IOException
	 */
	public void getPaymentOrderExportPopUpDetails(ExportRequestVO exportRequestVO, ServletOutputStream outputStream)throws BNPApplicationException, IOException;
	
	/**
	 * This method is for getting Transaction Export PopUp Details
	 * 
	 * @param exportRequestVO
	 * @param outputStream
	 * @throws BNPApplicationException
	 * @throws IOException
	 */
	public void getTransactionExportPopUpDetails(ExportRequestVO exportRequestVO, ServletOutputStream outputStream)throws BNPApplicationException, IOException;
	
	/**
	 * This method is for getting View Scheduled Reports Export data
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException
	 */
	public void getExportViewScheduledReportsData(ExportRequestVO exportVO, ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException , IOException;
	
	/**
	 * This method is for getting View Scheduled Reports Export data
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException
	 */
	public void getExportRemittanceReportsData(ExportRequestVO exportVO, ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException , IOException;
	
	/**
	 * This method is for getting Aging Report Export data
	 * 
	 * @param exportVO
	 * @param outputStream
	 * @param buffer
	 * @throws BNPApplicationException
	 * @throws IOException
	 */
	public void getAgingReportExportData(ExportRequestVO exportVO, ServletOutputStream outputStream,byte[] buffer) throws BNPApplicationException , IOException;


}
