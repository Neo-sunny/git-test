/********************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 Oct 2016
 * 
 * Purpose:      Payment Order Response Object
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 27 Oct 2016                      Oracle Financial Services Software Ltd                                    Initial Version
 * 01-JAN-2018				        Bala Murugan Elangovan					Added new method validateDiscDateWithHoliday for S101001 as part of FO10.1 Sprint 2 
************************************************************************************************************************************************************/
package com.bnp.bnpux.vo.responseVO;

import java.util.List;

import com.bnp.bnpux.common.vo.PaymentOrderListDetailsVO;
import com.bnp.bnpux.common.vo.PaymentOrderListVO;
import com.bnp.bnpux.common.vo.PaymentOrderSummaryVO;
import com.bnp.bnpux.common.vo.StatusDetailsVO;

public class PaymentOrderResponseVO {
	
	private String errorMsg;
	
	private List<PaymentOrderSummaryVO> paymentOrderSummaryList;
	
	private List<PaymentOrderListVO> paymentOrderListVO;
	
	private List<PaymentOrderListDetailsVO> paymentOrderListDetailsVO;
	
	private String branchId;
	
	private String holidayCheckFlag;
	
	
	private List<StatusDetailsVO> statusDet;

	public List<PaymentOrderSummaryVO> getPaymentOrderSummaryList() {
		return paymentOrderSummaryList;
	}

	public void setPaymentOrderSummaryList(List<PaymentOrderSummaryVO> paymentOrderSummaryList) {
		this.paymentOrderSummaryList = paymentOrderSummaryList;
	}

	public List<PaymentOrderListVO> getPaymentOrderListVO() {
		return paymentOrderListVO;
	}

	public void setPaymentOrderListVO(List<PaymentOrderListVO> paymentOrderListVO) {
		this.paymentOrderListVO = paymentOrderListVO;
	}

	public List<PaymentOrderListDetailsVO> getPaymentOrderListDetailsVO() {
		return paymentOrderListDetailsVO;
	}

	public void setPaymentOrderListDetailsVO(List<PaymentOrderListDetailsVO> paymentOrderListDetailsVO) {
		this.paymentOrderListDetailsVO = paymentOrderListDetailsVO;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	

	public List<StatusDetailsVO> getStatusDet() {
		return statusDet;
	}

	public void setStatusDet(List<StatusDetailsVO> statusDet) {
		this.statusDet = statusDet;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public String getHolidayCheckFlag() {
		return holidayCheckFlag;
	}

	public void setHolidayCheckFlag(String holidayCheckFlag) {
		this.holidayCheckFlag = holidayCheckFlag;
	}    
    
}
