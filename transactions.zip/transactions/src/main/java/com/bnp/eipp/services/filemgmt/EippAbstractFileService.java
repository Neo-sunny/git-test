/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   18 July 2012
 * 
 * Purpose:      EippAbstractFileService
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 July 2012        Oracle Financial Services Software Ltd                  Initial Version
 * 20 Aug 2012		   Vignesh B								               Attachment Processing  
 * 30 Aug 2012 		   Reena S										Rel3.0	    Added for EIPP Payment Status update
 * 07 Sep 2012		   Aarthi T													MFU - Rel 3.0 Matching and Reconcilation		  
 * 17 Oct 2012		   Prabakaran S												Fix for ST Defect # 6793
************************************************************************************************************************************************************/

package com.bnp.eipp.services.filemgmt;

import org.springframework.beans.factory.annotation.Autowired;

import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;

public abstract class EippAbstractFileService {
	
	@Autowired
	protected IFileProcessService fileProcessorService;
	
	@Autowired
	protected BNPPropertyLoaderConfigurer propertyLoader;
	
	@Autowired
	protected IEippMsgProcessorService msgBuilder;
	
	protected String msgType;
	
	protected abstract void processFile(
			FileDetailsVO detailsVO) throws BNPApplicationException;
	
	public long processData(
			FileDetailsVO detailsVO) throws BNPApplicationException {
		msgType = detailsVO.getDocType();
		checkForDuplicateFile(detailsVO);
		populateHeaderDetails(detailsVO);
		processFile(detailsVO);
		
		return detailsVO.getFileId();
	}
	
	 
	protected void checkForDuplicateFile(FileDetailsVO detailsVO) throws BNPApplicationException {
		try {
			fileProcessorService.checkForDuplicateFile(detailsVO);
		} catch (BNPApplicationException ex) {
			detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.load.not"));
			detailsVO.setErrorCode(Integer.toString(ex.getErrorCode()));
			detailsVO.setErrorDesc(ex.getErrorMessage());
			fileProcessorService.saveFileDetails(detailsVO);
			fileProcessorService.triggerEventLog(detailsVO, "FAILURE");
			throw ex;
		}
	}
	
	public void populateHeaderDetails(FileDetailsVO detailsVO) throws BNPApplicationException {
		FileDetailsVO fileVO = fileProcessorService.getHeaderDetails(detailsVO);
		
		if (fileVO == null) {
			detailsVO.setErrorCode(Integer.toString(ErrorConstants.BUYER_ACCOUNT_NOT_AVAILABLE));
			detailsVO.setErrorDesc("Buyer account not available");
			if (detailsVO.getFileType().equalsIgnoreCase(
					BNPConstants.CUSTOM_FILE_TYPE)) {
				detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.load.fail"));				
				fileProcessorService.saveFileDetails(detailsVO);
				fileProcessorService.insertFileUploadMessageDetails(detailsVO);
				throw new BNPApplicationException(ErrorConstants.HEADER_INFO_NOT_AVAILABLE);
			}
		} else {
			detailsVO.setCountryCode(fileVO.getCountryCode());
			detailsVO.setBankCode(fileVO.getBankCode());
			detailsVO.setBranchCode(fileVO.getBranchCode());
			// repopulating sender org id to handle billing count upload by setting
			// branch id as sender org id while fetching header details.
			if (detailsVO.getSenderOrgId() == null) {
				detailsVO.setSenderOrgId(fileVO.getSenderOrgId());
			}
		}		
	}
}
