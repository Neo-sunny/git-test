/****************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   23 Oct 2012
 * 
 * Purpose: Eipp Message VO
 * 
 * Change History: 
 * Date                       	Author                                  Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 23 Oct 2012              	Prabu P                      			Initial Version
 ********************************************************************************************************************************/

package com.bnp.eipp.services.vo.common;

import java.util.List;
import java.util.Map;

import com.bnp.scm.services.common.vo.AbstractVO;
import com.bnp.scm.services.txns.common.vo.MessageVO;

public class EippMessageVO extends AbstractVO {

	private static final long serialVersionUID = 737366230498752238L;

	private Map<String, String> headerMap;

	private MessageVO messageVO;

	private List<? extends AbstractVO> dataList;

	private List<String> refList;

	private String xmlMessage;
	
	private String matchRefNo;

	/**
	 * @return the headerMap
	 */
	public Map<String, String> getHeaderMap() {
		return headerMap;
	}

	/**
	 * @param headerMap the headerMap to set
	 */
	public void setHeaderMap(Map<String, String> headerMap) {
		this.headerMap = headerMap;
	}

	/**
	 * @return the messageVO
	 */
	public MessageVO getMessageVO() {
		return messageVO;
	}

	/**
	 * @param messageVO the messageVO to set
	 */
	public void setMessageVO(MessageVO messageVO) {
		this.messageVO = messageVO;
	}

	/**
	 * @return the dataList
	 */
	public List<? extends AbstractVO> getDataList() {
		return dataList;
	}

	/**
	 * @param dataList the dataList to set
	 */
	public void setDataList(List<? extends AbstractVO> dataList) {
		this.dataList = dataList;
	}

	/**
	 * @return the refList
	 */
	public List<String> getRefList() {
		return refList;
	}
	
	/**
	 * @param refList the refList to set
	 */
	public void setRefList(List<String> refList) {
		this.refList = refList;
	}

	/**
	 * @return the xmlMessage
	 */
	public String getXmlMessage() {
		return xmlMessage;
	}

	/**
	 * @param xmlMessage the xmlMessage to set
	 */
	public void setXmlMessage(String xmlMessage) {
		this.xmlMessage = xmlMessage;
	}

	/**
	 * @return the matchRefNo
	 */
	public String getMatchRefNo() {
		return matchRefNo;
	}

	/**
	 * @param matchRefNo the matchRefNo to set
	 */
	public void setMatchRefNo(String matchRefNo) {
		this.matchRefNo = matchRefNo;
	}
}
