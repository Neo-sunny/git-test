/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   06 Feb 12
 * 
 * Purpose:      Invoice Upload
 * 
 * Change History: 
 * Date                                                  Author                      Version                                                            Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 06 Feb 12                      Oracle Financial Services Software Ltd                                  Initial version
 * 12-July 2012                   Oracle Financial Services Software Ltd            EIPP Phase II - Cancel Invoice MFU
 * 12 Oct 2012						Merdith 														  			Method Parameter changed for validating line item
 * 17 Oct 2012					  Vinoth Kumar M									Pending Match Job
 * 19 Oct 2012					  Merdith S 										ST - 6984 To allow disputing of Line Itm based on LinkorgforEIPP data
 *  23 Oct 2012					Merdith 											ST Defect 6824
 ******************************************************************************************************************************************************************/

package com.bnp.eipp.services.invoice.dao;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.invoice.util.EippAuditConstants;
import com.bnp.eipp.services.invoice.vo.EippAuditVO;
import com.bnp.eipp.services.invoice.vo.EippCreditNoteVO;
import com.bnp.eipp.services.invoice.vo.EippCustFieldsVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceBusinessRulesVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceCancelVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.vo.dispute.DisputeVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.BNPRuntimeException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.NumberFormatConversionUtil;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.common.vo.AttachmentVO;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.ibatis.sqlmap.client.SqlMapExecutor;
import com.ibatis.sqlmap.engine.execution.BatchException;


@Component
public class EippInvcUploadDAOImpl extends SqlMapClientWrapper implements IEippInvcUploadDAO {

	private static final String INSERT_INVOICE_LINE_ITEMS = "EippFileUpload.insertInvoiceLineItems";
	private static final String INSERT_INVOICE_DETAILS = "EippFileUpload.insertInvoiceDetails";
	private static final String INSERT_CREDITNOTE_DETAILS= "EippFileUpload.insertCreditNoteDetails";
	private static final String INSERT_CREDITNOTE_LINE_ITEMS= "EippFileUpload.insertCreditNoteLineItems";
	private static final String DUPLICATE_INVOICE = "Duplicate Invoice";
	private static final String DUPLICATE_CONSTRAINT = "unique constraint";
	private static final String DUPLICATE_PYMT_CN = "unique constraint for payment";
	private static final String INS_INVOICE_HISTORY_FROM_TRANS = "EippFileUpload.insertInvoiceHistoryFromTrans";
	private static final String INS_INVCUST_FLDS_HIST_FROM_TRANS = "EippFileUpload.insertInvCustFldsHisFromTrans";
	private static final String INS_INVOICE_ITEMS_HISTORY_FROM_TRANS = "EippFileUpload.insertInvoiceItemsHistoryFromTrans";
	private static final String INS_INV_ITEMSCUST_FLDS_HIST_FROM_TRANS = "EippFileUpload.insertInvItemsCustFldsHistFromTrans";
	private static final String INS_CREDIT_NOTE_HISTORY_FROM_TRANS = "EippFileUpload.insertCnHistoryFromTrans";
	private static final String INS_CRNTCUST_FLDS_HIST_FROM_TRANS = "EippFileUpload.insertCnCustFldsHistFromTrans";
	private static final String INS_CREDIT_NOTE_ITEMS_HISTORY_FROM_TRANS = "EippFileUpload.insertCnItemsHistoryFromTrans";
	private static final String INS_CRNT_ITEMSCUST_FLDS_HIST_FROM_TRANS = "EippFileUpload.insertCnItemsCustFldsHistFromTrans";
	private static final String GET_ACK_TEMPLATE = "EippFileUpload.getAckTemplate";
	private static final String GET_COUNTER_PARTY_ORG_ID="EippFileUpload.getCounterPartyOrgId";
	private static final String GET_CUST_ORG_ID="EippFileUpload.getCustOrgId";
	private static final String GET_ERP_ID_LIST="EippFileUpload.getERPIDList";
	private static final String GET_EXISTING_CREDIT_NOTES = "EippFileUpload.getExistingCreditNotes";
	private static final String GET_EXISTING_INVOICES = "EippFileUpload.getExistingInvoices";
	private static final String GET_ORG_MODEL_TYPE="EippFileUpload.getOrgModelType";
	private static final String GET_ORG_TIME_ZONE="EippFileUpload.getOrgTimeZone";
	private static final String GET_DEPT_AVAILABLE_COUNT="EippFileUpload.getDeptCount";
	private static final String INSERT_INVC_CUSTOM_FIELDS="EippFileUpload.insertInvcCustFields";
	private static final String INSERT_CRNT_CUSTOM_FIELDS="EippFileUpload.insertCrntCustFields";
	private static final String INSERT_INVCITM_CUSTOM_FIELDS="EippFileUpload.insertInvcItmCustFields";
	private static final String INSERT_CRNTITM_CUSTOM_FIELDS="EippFileUpload.insertCrntItmCustFields";
	private static final String CHECK_FOR_PARTIAL_UPLOAD="EippFileUpload.checkForPartialUpload";
	private static final String IS_BUYER_SELLER_LINKED="EippFileUpload.isBuyerSellerLinked";
	private static final String IS_ACCOUNT_IDENTIFIER_CHECKED="EippFileUpload.isAccountIdChecked";
	private static final String IS_UNIQUE_CHECK_ENABLED="EippFileUpload.isUniqueCheckEnabled";
	private static final String IS_ACCOUNT_IDENTIFIER_EXISTS="EippFileUpload.isAccountIdntExists";
	private static final String IS_LINKED_INVOICE_EXISTS="EippFileUpload.isLinkedInvoiceExists";
	private static final String IS_INVOICE_EXISTS="EippFileUpload.isInvoiceExists";
	private static final String IS_CREDIT_NOTE_EXISTS="EippFileUpload.isCreditNoteExists";
	private static final String GET_CONVERT_TO_UNLINKED="EippFileUpload.getConvertToUnlinked";
	private static final String IS_ACC_IDENTIFIER_CHECKED_IN_BILL_TYPE = "EippFileUpload.checkAccIdInBillType";
	private static final String IS_UNIQUE_CHECK_ENABLED_BT = "EippFileUpload.isBTUniqueCheckEnabled";
	private static final String CREATE_INV_AUDIT = "EippFileUpload.createInvoiceAudit";
	private static final String GET_INV_COUNT_FOR_CN = "EippFileUpload.getInvCountForCreditNote";
	protected static final String UPDATE_REPROCESS_FLAG = "EippFileUpload.updateReprocessFlagForOldRejRecords";
	private static final String INSERT_CANCEL_INVOICE_DETAILS = "EippFileUpload.insertCancelInvoiceDetails";
	private static final String GET_ORG_TYPE="EippFileUpload.getOrgType";
	private static final String IS_BILL_THROUGH_MARKET_PLACE="EippFileUpload.isBillThroughMarketPlace";
	private static final String IS_CUST_LINKED_TO_MARKET_PLACE="EippFileUpload.isCustLinkedToMarketPlace";
	private static final String IS_BUYER_SELLER_LINKED_TO_MKT_PLACE="EippFileUpload.isBuyerSellerLinkedToMarketPlace";
	private static final String GET_RULE_TYPE_FOR_DISCOUNT_RULE_ID="EippFileUpload.getRuleTypeForDiscRuleId";
	/** The Constant INSERT_INV_ATTACHMENTS. */
	private static final String INSERT_INV_ATTACHMENTS_TRANS = "EippFileUpload.insertInvoiceAttachmentTrans";
	private static final String GET_INVOICE_COUNT_AVAILABLE="EippFileUpload.getAvailableInvoiceCount";
	private static final String IS_MARKET_PLACE_IS_PAR_ORG="EippFileUpload.isMarketPlaceIsParOrgId";
	private static final String IS_DEFAULT_BUSI_RULE_ENABLED="EippFileUpload.isDefaultBusinessRuleEnabled";
	private static final String GET_BUSINESS_RULES_FROM_BILL_TYPE="EippFileUpload.getBusinessRulesFromBillType";
	private static final String GET_BUSINESS_RULES_FROM_LINK_ORG="EippFileUpload.getBusinessRulesFromLinkOrg";
	private static final String GET_INVOICES_FOR_VALIDATION="EippFileUpload.getInvoicesForValidation";
	private static final String IS_BILL_TYPE_LINKED_TO_MP = "EippFileUpload.isBillTypeLinkedToMarketPlace";
	
	private static final String INSERT_MATCH_INVOICE_LINE_ITEMS = "MatchingRecon.insertMatchInvoiceLineItems";
	private static final String INSERT_MATCH_INVOICE_DETAILS = "MatchingRecon.insertMatchInvoiceDetails";
	private static final String INSERT_MATCH_CREDITNOTE_DETAILS= "MatchingRecon.insertMatchCreditNoteDetails";
	private static final String INSERT_MATCH_CREDITNOTE_LINE_ITEMS= "MatchingRecon.insertMatchCreditNoteLineItems";
	private static final String INSERT_MATCH_INVC_CUSTOM_FIELDS="MatchingRecon.insertMatchInvcCustFields";
	private static final String IS_MATCH_INVOICE_EXISTS="MatchingRecon.isMatchInvoiceExists";
	private static final String IS_MATCH_CREDIT_NOTE_EXISTS="MatchingRecon.isMatchCreditNoteExists";
	
	private static final String INS_MAT_INVOICE_HISTORY_FROM_TRANS = "MatchingRecon.insertMatchInvHistFromTrans";
	private static final String INS_MAT_INVCUST_FLDS_HIST_FROM_TRANS = "MatchingRecon.insertMatchInvCustFldsHisFromTrans";
	private static final String INS_MAT_INVOICE_ITEMS_HISTORY_FROM_TRANS = "MatchingRecon.insertMatchInvItmsHistFromTrans";
	private static final String INS_MAT_CREDIT_NOTE_HISTORY_FROM_TRANS = "MatchingRecon.insertMatchCnHistFromTrans";
	private static final String INS_MAT_CREDIT_NOTE_ITEMS_HISTORY_FROM_TRANS = "MatchingRecon.insertMatchCnItmsHistFromTrans";
	
	private static final String MATCH_RECORDS_SP = "MatchingRecon.matchRecords";
	private static final String FETCH_ALLOC_TYPE_FROM_LINK_ORG = "EippFileUpload.fetchAllocTypeFromLinkOrg";
	
	private static final String GET_PENDING_MATCH_FILES = "EippFileUpload.getPendingMatchFiles";
	private static final String GET_INV_LI_LINKORG = "EippFileUpload.getdataFromLinkOrg";

	private static final String GET_FIN_NONFIN_FLAG = "MatchingRecon.getFinNonFinFlag";

	private static final String IS_INVOICES_UPLOADED_FOR_FILE = "EippFileUpload.isInvUploadedForFile";
	
	private static final String GET_ATTACHMENT_DATA = "EippFileUpload.getAttachmentData";


	private static Logger LOGGER = LoggerFactory.getLogger(EippInvcUploadDAOImpl.class);
	/**
	 * @Name : uploadFile
	 * @Description : This method is used to parse & upload the data file 
	 * @param pymtList
	 * @param fileVO
	 * @throws BNPApplicationException
	 * @see com.bnp.scm.services.filemgmt.dao.ManualFileUploadDAO#getFileUploadSummary(java.lang.List<com.bnp.scm.services.invoice.vo.InvoicePaymentVO>, com.bnp.scm.services.filemgmt.vo.FileDetailsVO)
	 */
	@SuppressWarnings("rawtypes")
	public void uploadFile(final List<EippInvCntVO> transList,
			final FileDetailsVO fileVO) throws BNPApplicationException {
		
		if(fileVO != null && fileVO.getInstrumentType() != null
				&& fileVO.getInstrumentType().trim().equalsIgnoreCase(BNPConstants.MATCH_RECON_INS_TYPE))
		{
			for (final EippInvCntVO eippInvCntVO : transList) {
				if(eippInvCntVO.getInvoiceList()!=null && 
							!eippInvCntVO.getInvoiceList().isEmpty()) {
					insertMatchingInvcList(eippInvCntVO.getInvoiceList(), fileVO);
				}
				if (eippInvCntVO.getCntList()!=null &&
						!eippInvCntVO.getCntList().isEmpty()) {
					insertMatchCreditNoteList(eippInvCntVO.getCntList(), fileVO);
				}
			}
		}else{
			for (final EippInvCntVO eippInvCntVO : transList) {
				if(eippInvCntVO.getInvoiceList()!=null && 
							!eippInvCntVO.getInvoiceList().isEmpty()) {
						insertInvoiceList(eippInvCntVO.getInvoiceList(), fileVO);
				}
				if (eippInvCntVO.getCntList()!=null &&
						!eippInvCntVO.getCntList().isEmpty()) {
					insertCreditNoteList(eippInvCntVO.getCntList(), fileVO);
				}
			}
		}
	}
	
	private void insertMatchingInvcList(final List<EippInvoiceVO> invoiceList, 
						final FileDetailsVO fileVO) throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
				public List doInSqlMapClient(SqlMapExecutor executor)
				throws SQLException {
					List list = new ArrayList();
					try {
						// inserting invoice staging details
						for (EippInvoiceVO eippInvoiceVO : invoiceList) {
							executor.startBatch();
							eippInvoiceVO.setInvRefNo(eippInvoiceVO.getInvRefNo().trim());
							eippInvoiceVO.setFileId(fileVO.getFileId());
							eippInvoiceVO.setGrossAmt(reduceFractionDigits(eippInvoiceVO.getGrossAmt(), 
									eippInvoiceVO.getFractionalDigits()));
							eippInvoiceVO.setNetAmt(reduceFractionDigits(eippInvoiceVO.getNetAmt(), 
									eippInvoiceVO.getFractionalDigits()));
							eippInvoiceVO.setTotAmtPayable(reduceFractionDigits(eippInvoiceVO.getTotAmtPayable(), 
									eippInvoiceVO.getFractionalDigits()));
							eippInvoiceVO.setTotDiscAmt(reduceFractionDigits(eippInvoiceVO.getTotDiscAmt(), 
									eippInvoiceVO.getFractionalDigits()));
							eippInvoiceVO.setMinAmtPayable(reduceFractionDigits(eippInvoiceVO.getMinAmtPayable(), 
									eippInvoiceVO.getFractionalDigits()));
							eippInvoiceVO.setMakerId(fileVO.getUserId());
							eippInvoiceVO.setMakerDate(new Date(System.currentTimeMillis()));
							eippInvoiceVO.setInvRemAmt(reduceFractionDigits(eippInvoiceVO.getInvRemAmt(), 
									eippInvoiceVO.getFractionalDigits()));
							eippInvoiceVO.setTaxAmount(reduceFractionDigits(eippInvoiceVO.getTaxAmount(), 
									eippInvoiceVO.getFractionalDigits()));
							eippInvoiceVO.setMatchStatus(StatusConstants.PENDING_MATCH_STATUS);
							eippInvoiceVO.setOrgId(fileVO.getSenderOrgId());
							eippInvoiceVO.setAlwNonFinProcess((String)getSqlMapClientTemplate().queryForObject(GET_FIN_NONFIN_FLAG,eippInvoiceVO));
							try{
								executor.insert(INSERT_MATCH_INVOICE_DETAILS, eippInvoiceVO);
								executor.executeBatchDetailed();
							}catch (BatchException e) {
								if(e.getCause().getMessage().contains(DUPLICATE_CONSTRAINT))
									throw new DBException(ErrorConstants.INVOICE_NOT_UNIQUE_ERROR ,DUPLICATE_INVOICE);
								else
									throw e;
							}
							
							executor.startBatch();
							for (EippCustFieldsVO eippCustFieldsVO : eippInvoiceVO.getCustFields()) {
								eippCustFieldsVO.setFkId(eippInvoiceVO.getInvId());
								eippCustFieldsVO.setRecordStatus(eippInvoiceVO.getRecordStatus());
								eippCustFieldsVO.setMakerDate(eippInvoiceVO.getMakerDate());
								eippCustFieldsVO.setMakerId(eippInvoiceVO.getMakerId());
								
								executor.insert(INSERT_MATCH_INVC_CUSTOM_FIELDS,
										eippCustFieldsVO);
							}
							executor.executeBatchDetailed();
							
							executor.startBatch();
							
							// get invoice line items
							for (EippInvCntLineItemVO invoiceLineItem : eippInvoiceVO.getLineItemList()) {
								
								invoiceLineItem.setFkId(eippInvoiceVO.getInvId());
								invoiceLineItem.setItemUnitPrice(reduceFractionDigits
										(invoiceLineItem.getItemUnitPrice(), eippInvoiceVO.getFractionalDigits()));
								invoiceLineItem.setItemTotalPrice(reduceFractionDigits
										(invoiceLineItem.getItemTotalPrice(), eippInvoiceVO.getFractionalDigits()));
								invoiceLineItem.setTaxAmount(reduceFractionDigits
										(invoiceLineItem.getTaxAmount(), eippInvoiceVO.getFractionalDigits()));
								invoiceLineItem.setRecordStatus(eippInvoiceVO.getRecordStatus());
								invoiceLineItem.setMakerId(eippInvoiceVO.getMakerId());
								invoiceLineItem.setMakerDate(eippInvoiceVO.getMakerDate());
								invoiceLineItem.setLineItemStatus(eippInvoiceVO.getInvStatus());
								
								executor.insert(INSERT_MATCH_INVOICE_LINE_ITEMS,
										invoiceLineItem);
								
							}
							executor.executeBatchDetailed();
						}
					} catch (BatchException e) {
						LOGGER.error("Uploading the invoiceLineItem details in a batch failed");
						throw new SQLException(e.getMessage());
					} catch (DBException e) {
						throw new SQLException(e.getErrorMessage());
					}
					//FO 7.0 Fortify Issue Fix
					//LOGGER.debug("List :: " + list);
					return list;
				}
			});
		} catch (DataAccessException e) {
			//976332 CSCDEV-2683 17-NOV-2014:START
			//e.printStackTrace();
			LOGGER.error(e.getMessage());			
			//976332 CSCDEV-2683 17-NOV-2014:END
			if(e.getCause().getMessage().equalsIgnoreCase(DUPLICATE_INVOICE))
				throw new BNPRuntimeException(ErrorConstants.INVOICE_NOT_UNIQUE_ERROR);
			else
				throw new BNPRuntimeException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	
	
	
	
	private void insertInvoiceList(final List<EippInvoiceVO> invoiceList,final FileDetailsVO fileVO) throws BNPApplicationException{
		try {
			getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
				public List doInSqlMapClient(SqlMapExecutor executor)
				throws SQLException {
					List list = new ArrayList();
					try {
						// inserting invoice staging details
						for (EippInvoiceVO eippInvoiceVO : invoiceList) {
							executor.startBatch();
							eippInvoiceVO.setInvRefNo(eippInvoiceVO.getInvRefNo().trim());
							eippInvoiceVO.setFileId(fileVO.getFileId());
							eippInvoiceVO.setGrossAmt(reduceFractionDigits(eippInvoiceVO.getGrossAmt(), 
									eippInvoiceVO.getFractionalDigits()));
							eippInvoiceVO.setNetAmt(reduceFractionDigits(eippInvoiceVO.getNetAmt(), 
									eippInvoiceVO.getFractionalDigits()));
							eippInvoiceVO.setTotAmtPayable(reduceFractionDigits(eippInvoiceVO.getTotAmtPayable(), 
									eippInvoiceVO.getFractionalDigits()));
							eippInvoiceVO.setTotDiscAmt(reduceFractionDigits(eippInvoiceVO.getTotDiscAmt(), 
									eippInvoiceVO.getFractionalDigits()));
							eippInvoiceVO.setMinAmtPayable(reduceFractionDigits(eippInvoiceVO.getMinAmtPayable(), 
									eippInvoiceVO.getFractionalDigits()));
							eippInvoiceVO.setMakerId(fileVO.getUserId());
							eippInvoiceVO.setMakerDate(new Date(System.currentTimeMillis()));
							eippInvoiceVO.setInvRemAmt(reduceFractionDigits(eippInvoiceVO.getInvRemAmt(), 
									eippInvoiceVO.getFractionalDigits()));
							eippInvoiceVO.setTaxAmount(reduceFractionDigits(eippInvoiceVO.getTaxAmount(), 
									eippInvoiceVO.getFractionalDigits()));
							eippInvoiceVO.setInvStatus(StatusConstants.EIPP_NEW_STATUS);
							eippInvoiceVO.setPymtStatus(StatusConstants.EIPP_PYMT_UNPAID);
							try{
								executor.insert(INSERT_INVOICE_DETAILS, eippInvoiceVO);
								executor.executeBatchDetailed();
							}catch (BatchException e) {
								if(e.getCause().getMessage().contains(DUPLICATE_CONSTRAINT))
									throw new DBException(ErrorConstants.INVOICE_NOT_UNIQUE_ERROR ,DUPLICATE_INVOICE);
								else
									throw e;
							}
							EippAuditVO auditVO = new EippAuditVO();
							auditVO.setInvId(eippInvoiceVO.getInvId());
							auditVO.setAuditUser(eippInvoiceVO.getMakerId());
							auditVO.setStatus(eippInvoiceVO.getInvStatus());
							auditVO.setAction(EippAuditConstants.INV_UPLOADED);
							
							// insert into invoice audit
							executor.startBatch();
							executor.insert(CREATE_INV_AUDIT, auditVO);
							executor.executeBatchDetailed();
							
							executor.startBatch();
							for (EippCustFieldsVO eippCustFieldsVO : eippInvoiceVO.getCustFields()) {
								eippCustFieldsVO.setFkId(eippInvoiceVO.getInvId());
								eippCustFieldsVO.setRecordStatus(eippInvoiceVO.getRecordStatus());
								eippCustFieldsVO.setMakerDate(eippInvoiceVO.getMakerDate());
								eippCustFieldsVO.setMakerId(eippInvoiceVO.getMakerId());
								
								executor.insert(INSERT_INVC_CUSTOM_FIELDS,
										eippCustFieldsVO);
							}
							executor.executeBatchDetailed();
							
							executor.startBatch();
							
							// get invoice line items
							for (EippInvCntLineItemVO invoiceLineItem : eippInvoiceVO.getLineItemList()) {
								
								invoiceLineItem.setFkId(eippInvoiceVO.getInvId());
								invoiceLineItem.setItemUnitPrice(reduceFractionDigits
										(invoiceLineItem.getItemUnitPrice(), eippInvoiceVO.getFractionalDigits()));
								invoiceLineItem.setItemTotalPrice(reduceFractionDigits
										(invoiceLineItem.getItemTotalPrice(), eippInvoiceVO.getFractionalDigits()));
								invoiceLineItem.setTaxAmount(reduceFractionDigits
										(invoiceLineItem.getTaxAmount(), eippInvoiceVO.getFractionalDigits()));
								invoiceLineItem.setRecordStatus(eippInvoiceVO.getRecordStatus());
								invoiceLineItem.setMakerId(eippInvoiceVO.getMakerId());
								invoiceLineItem.setMakerDate(eippInvoiceVO.getMakerDate());
								invoiceLineItem.setLineItemStatus(eippInvoiceVO.getInvStatus());
								/*invoiceLineItem.setItemGrossAmt(reduceFractionDigits(
										invoiceLineItem.getItemGrossAmt(),eippInvoiceVO.getFractionalDigits()));*/
								
								executor.insert(INSERT_INVOICE_LINE_ITEMS,
										invoiceLineItem);
								for (EippCustFieldsVO itmCustFieldsVO : invoiceLineItem.getCustFields()) {
									itmCustFieldsVO.setFkId(invoiceLineItem.getLineItemId());
									itmCustFieldsVO.setRecordStatus(invoiceLineItem.getRecordStatus());
									itmCustFieldsVO.setMakerId(invoiceLineItem.getMakerId());
									itmCustFieldsVO.setMakerDate(invoiceLineItem.getMakerDate());
									
									executor.insert(INSERT_INVCITM_CUSTOM_FIELDS,
											itmCustFieldsVO);
								}
							}
							executor.executeBatchDetailed();
							
							if(eippInvoiceVO.getAttachmentList() != null){
								executor.startBatch();
								for (AttachmentVO attachmentVO : eippInvoiceVO.getAttachmentList()) {
									attachmentVO.setRefId(eippInvoiceVO.getInvId());
									attachmentVO.setUploadedDate(eippInvoiceVO.getMakerDate());
									attachmentVO.setUploadedBy(eippInvoiceVO.getMakerId());
								
									executor.insert(INSERT_INV_ATTACHMENTS_TRANS, attachmentVO);
								}
								executor.executeBatchDetailed();
							}
						}
					} catch (BatchException e) {							
						LOGGER.error("Uploading the invoiceLineItem details in a batch failed");
						throw new SQLException(e.getMessage());
					} catch (DBException e) {							
						throw new SQLException(e.getErrorMessage());
					}
					//FO 7.0 Fortify Issue Fix
					//LOGGER.debug("List :: " + list);
					return list;
				}
			});
		} catch (DataAccessException e) {
			
			if(e.getCause().getMessage().equalsIgnoreCase(DUPLICATE_INVOICE))
				throw new BNPApplicationException(ErrorConstants.INVOICE_NOT_UNIQUE_ERROR);
			else
				throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	
	private void insertMatchCreditNoteList(final List<EippCreditNoteVO> creditNoteList,final FileDetailsVO fileVO) throws BNPApplicationException{
		try {
			getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
				public List doInSqlMapClient(SqlMapExecutor executor)
				throws SQLException {
					List list = new ArrayList();
					
					try {
						for (EippCreditNoteVO eippCreditNoteVO : creditNoteList) {

							executor.startBatch();
							eippCreditNoteVO.setCntRefNo(eippCreditNoteVO.getCntRefNo().trim());
							eippCreditNoteVO.setCntOrgAmt(reduceFractionDigits
									(eippCreditNoteVO.getCntOrgAmt(), eippCreditNoteVO.getFractionalDigits()));
							
							if (eippCreditNoteVO.getOrgInvRefNo() != null) {
								eippCreditNoteVO.setOrgInvRefNo(eippCreditNoteVO.getOrgInvRefNo().trim());
							}
							
							if (eippCreditNoteVO.getLinkedInvRefNo() != null) {
								eippCreditNoteVO.setLinkedInvRefNo(eippCreditNoteVO.getLinkedInvRefNo().trim());
							}
							
							
							eippCreditNoteVO.setFileId(fileVO.getFileId());
							eippCreditNoteVO.setMakerId(fileVO.getUserId());
							eippCreditNoteVO.setMakerDate(new Date(System.currentTimeMillis()));
							eippCreditNoteVO.setRecordStatus(StatusConstants.APPROVE_RECORD);
							eippCreditNoteVO.setMatchStatus(StatusConstants.PENDING_MATCH_STATUS);
							//eippCreditNoteVO.setCntStatus(StatusConstants.EIPP_NEW_STATUS);
							
							eippCreditNoteVO.setCntRemAmt(reduceFractionDigits
									(eippCreditNoteVO.getCntRemAmt(), eippCreditNoteVO.getFractionalDigits()));
							eippCreditNoteVO.setCntUtilAmt(reduceFractionDigits
									(eippCreditNoteVO.getCntUtilAmt(), eippCreditNoteVO.getFractionalDigits()));
							eippCreditNoteVO.setSubTotAmt(reduceFractionDigits
									(eippCreditNoteVO.getSubTotAmt(), eippCreditNoteVO.getFractionalDigits()));
							eippCreditNoteVO.setTaxAmount(reduceFractionDigits
									(eippCreditNoteVO.getTaxAmount(), eippCreditNoteVO.getFractionalDigits()));

							try {
								executor.insert(INSERT_MATCH_CREDITNOTE_DETAILS, eippCreditNoteVO);
								executor.executeBatchDetailed();
							} catch (BatchException e) {									
								if(e.getCause().getMessage().contains(DUPLICATE_CONSTRAINT))
									throw new DBException(ErrorConstants.PYMT_CN_NOT_UNIQUE_ERROR ,DUPLICATE_PYMT_CN);
								else
									throw e;
							}
							
							executor.startBatch();
							for (EippInvCntLineItemVO cntLineItem : eippCreditNoteVO.getLineItemList()) {
								
								cntLineItem.setFkId(eippCreditNoteVO.getCntId());
								cntLineItem.setItemUnitPrice(
										reduceFractionDigits(cntLineItem.getItemUnitPrice(), eippCreditNoteVO.getFractionalDigits()));
								cntLineItem.setItemTotalPrice(
										reduceFractionDigits(cntLineItem.getItemTotalPrice(), eippCreditNoteVO.getFractionalDigits()));
								cntLineItem.setTaxAmount(
										reduceFractionDigits(cntLineItem.getTaxAmount(), eippCreditNoteVO.getFractionalDigits()));
								cntLineItem.setLineItemStatus(eippCreditNoteVO.getCntStatus());
								cntLineItem.setRecordStatus(eippCreditNoteVO.getRecordStatus());
								cntLineItem.setMakerDate(eippCreditNoteVO.getMakerDate());
								cntLineItem.setMakerId(eippCreditNoteVO.getMakerId());
								
								executor.insert(INSERT_MATCH_CREDITNOTE_LINE_ITEMS, cntLineItem);
							}
							executor.executeBatchDetailed();
						}
					} catch (BatchException e) {							
						LOGGER.error("Uploading the invoiceLineItem details in a batch failed");
						throw new SQLException(e.getMessage());
					} catch (DBException e) {							
						throw new SQLException(e.getErrorMessage());
					}
					//FO 7.0 Fortify Issue Fix
					//LOGGER.debug("List :: " + list);
					return list;
				}
			});
		} catch (DataAccessException e) {
			if(e.getCause().getMessage().equalsIgnoreCase(DUPLICATE_PYMT_CN))
				throw new BNPRuntimeException(ErrorConstants.PYMT_CN_NOT_UNIQUE_ERROR);
			else
				throw new BNPRuntimeException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	
	private void insertCreditNoteList(final List<EippCreditNoteVO> creditNoteList,final FileDetailsVO fileVO) throws BNPApplicationException{
		try {
			getSqlMapClientTemplate().execute(new SqlMapClientCallback<List<Object>>() {
				public List<Object> doInSqlMapClient(SqlMapExecutor executor)
				throws SQLException {
					List<Object> list = new ArrayList<Object>();
					
					try {
						for (EippCreditNoteVO eippCreditNoteVO : creditNoteList) {

							executor.startBatch();
							eippCreditNoteVO.setCntRefNo(eippCreditNoteVO.getCntRefNo().trim());
							eippCreditNoteVO.setCntOrgAmt(reduceFractionDigits
									(eippCreditNoteVO.getCntOrgAmt(), eippCreditNoteVO.getFractionalDigits()));
							
							if (eippCreditNoteVO.getOrgInvRefNo() != null) {
								eippCreditNoteVO.setOrgInvRefNo(eippCreditNoteVO.getOrgInvRefNo().trim());
							}
							
							if (eippCreditNoteVO.getLinkedInvRefNo() != null) {
								eippCreditNoteVO.setLinkedInvRefNo(eippCreditNoteVO.getLinkedInvRefNo().trim());
							}
							
							
							eippCreditNoteVO.setFileId(fileVO.getFileId());
							eippCreditNoteVO.setMakerId(fileVO.getUserId());
							eippCreditNoteVO.setMakerDate(new Date(System.currentTimeMillis()));
							eippCreditNoteVO.setRecordStatus(StatusConstants.APPROVE_RECORD);
							eippCreditNoteVO.setCntStatus(StatusConstants.EIPP_NEW_STATUS);
							
							eippCreditNoteVO.setCntRemAmt(reduceFractionDigits
									(eippCreditNoteVO.getCntRemAmt(), eippCreditNoteVO.getFractionalDigits()));
							eippCreditNoteVO.setCntUtilAmt(reduceFractionDigits
									(eippCreditNoteVO.getCntUtilAmt(), eippCreditNoteVO.getFractionalDigits()));
							eippCreditNoteVO.setSubTotAmt(reduceFractionDigits
									(eippCreditNoteVO.getSubTotAmt(), eippCreditNoteVO.getFractionalDigits()));
							eippCreditNoteVO.setTaxAmount(reduceFractionDigits
									(eippCreditNoteVO.getTaxAmount(), eippCreditNoteVO.getFractionalDigits()));

							try {
								executor.insert(INSERT_CREDITNOTE_DETAILS, eippCreditNoteVO);
								executor.executeBatchDetailed();
							} catch (BatchException e) {									
								if(e.getCause().getMessage().contains(DUPLICATE_CONSTRAINT))
									throw new DBException(ErrorConstants.PYMT_CN_NOT_UNIQUE_ERROR ,DUPLICATE_PYMT_CN);
								else
									throw e;
							}
							
							executor.startBatch();
							for (EippCustFieldsVO eippCustFieldsVO : eippCreditNoteVO.getCustFields()) {
								eippCustFieldsVO.setFkId(eippCreditNoteVO.getCntId());
								eippCustFieldsVO.setMakerDate(eippCreditNoteVO.getMakerDate());
								eippCustFieldsVO.setMakerId(eippCreditNoteVO.getMakerId());
								eippCustFieldsVO.setRecordStatus(eippCreditNoteVO.getRecordStatus());
								
								executor.insert(INSERT_CRNT_CUSTOM_FIELDS,
										eippCustFieldsVO);
							}
							executor.executeBatchDetailed();
							
							executor.startBatch();
							for (EippInvCntLineItemVO cntLineItem : eippCreditNoteVO.getLineItemList()) {
								
								cntLineItem.setFkId(eippCreditNoteVO.getCntId());
								cntLineItem.setItemUnitPrice(
										reduceFractionDigits(cntLineItem.getItemUnitPrice(), eippCreditNoteVO.getFractionalDigits()));
								cntLineItem.setItemTotalPrice(
										reduceFractionDigits(cntLineItem.getItemTotalPrice(), eippCreditNoteVO.getFractionalDigits()));
								cntLineItem.setTaxAmount(
										reduceFractionDigits(cntLineItem.getTaxAmount(), eippCreditNoteVO.getFractionalDigits()));
								cntLineItem.setLineItemStatus(eippCreditNoteVO.getCntStatus());
								cntLineItem.setRecordStatus(eippCreditNoteVO.getRecordStatus());
								cntLineItem.setMakerDate(eippCreditNoteVO.getMakerDate());
								cntLineItem.setMakerId(eippCreditNoteVO.getMakerId());
								
								executor.insert(INSERT_CREDITNOTE_LINE_ITEMS, cntLineItem);
								
								for (EippCustFieldsVO itmCustFieldsVO : cntLineItem.getCustFields()) {
									itmCustFieldsVO.setFkId(cntLineItem.getLineItemId());
									itmCustFieldsVO.setRecordStatus(cntLineItem.getRecordStatus());
									itmCustFieldsVO.setMakerDate(cntLineItem.getMakerDate());
									itmCustFieldsVO.setMakerId(cntLineItem.getMakerId());
									
									executor.insert(INSERT_CRNTITM_CUSTOM_FIELDS,
											itmCustFieldsVO);
								}
							}
							executor.executeBatchDetailed();
						}
					} catch (BatchException e) {							
						LOGGER.error("Uploading the invoiceLineItem details in a batch failed");
						throw new SQLException(e.getMessage());
					} catch (DBException e) {							
						throw new SQLException(e.getErrorMessage());
					}
					//FO 7.0 Fortify Issue Fix
					//LOGGER.debug("List :: " + list);
					return list;
				}
			});
		} catch (DataAccessException e) {
			if(e.getCause().getMessage().equalsIgnoreCase(DUPLICATE_PYMT_CN))
				throw new BNPRuntimeException(ErrorConstants.PYMT_CN_NOT_UNIQUE_ERROR);
			else
				throw new BNPRuntimeException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	private BigDecimal reduceFractionDigits(BigDecimal value , int decimals) {
		if (value == null) {
			return null;
		} else {
			return NumberFormatConversionUtil.formatNumber(value.doubleValue(), decimals);
		}
		
	}
	
	/**
	 * @Name : insertMatchHistDtlsFromTrans
	 * @Description : This method is used to insert the history details for matching records
	 * @param fileId
	 * @throws BNPApplicationException
	 */
    @Override
	public void insertMatchHistDtlsFromTrans(long fileId) throws BNPApplicationException{
		try {
			getSqlMapClientTemplate().insert(INS_MAT_INVOICE_HISTORY_FROM_TRANS, fileId);
			getSqlMapClientTemplate().insert(INS_MAT_INVCUST_FLDS_HIST_FROM_TRANS, fileId);
			getSqlMapClientTemplate().insert(INS_MAT_INVOICE_ITEMS_HISTORY_FROM_TRANS, fileId);
			getSqlMapClientTemplate().insert(INS_MAT_CREDIT_NOTE_HISTORY_FROM_TRANS, fileId);
			getSqlMapClientTemplate().insert(INS_MAT_CREDIT_NOTE_ITEMS_HISTORY_FROM_TRANS, fileId);
		} catch (Exception e) {
			//976332 CSCDEV-2683 17-NOV-2014:START
			LOGGER.error(e.getMessage());
			//e.printStackTrace();
			LOGGER.error(e.getMessage());
			//976332 CSCDEV-2683 17-NOV-2014:END
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}


	/**
	 * @Name : insertHistoryDetailsFromTrans
	 * @Description : This method is used to insert the history details
	 * @param fileVO
	 * @throws BNPApplicationException
	 * @see com.bnp.scm.services.invoice.dao.IInvoiceUploadDAO#insertHistoryDetailsFromTrans(long)
	 */
    @Override
	public void insertHistoryDetailsFromTrans(long fileId) throws BNPApplicationException {
		try {
				getSqlMapClientTemplate().insert(INS_INVOICE_HISTORY_FROM_TRANS, fileId);
				getSqlMapClientTemplate().insert(INS_INVCUST_FLDS_HIST_FROM_TRANS, fileId);
				getSqlMapClientTemplate().insert(INS_INVOICE_ITEMS_HISTORY_FROM_TRANS, fileId);
				getSqlMapClientTemplate().insert(INS_INV_ITEMSCUST_FLDS_HIST_FROM_TRANS, fileId);
				getSqlMapClientTemplate().insert(INS_CREDIT_NOTE_HISTORY_FROM_TRANS, fileId);
				getSqlMapClientTemplate().insert(INS_CRNTCUST_FLDS_HIST_FROM_TRANS, fileId);
				getSqlMapClientTemplate().insert(INS_CREDIT_NOTE_ITEMS_HISTORY_FROM_TRANS, fileId);
				getSqlMapClientTemplate().insert(INS_CRNT_ITEMSCUST_FLDS_HIST_FROM_TRANS, fileId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
    /**
	 * @Name : getModelTypeForOrganization
	 * @Description : this method is used for getting orgnization's model type
	 * @param orgId
	 * @throws BNPApplicationException
	 */
    public String getModelTypeForOrganization(String orgId) throws BNPApplicationException {
    	try {
			return (String) getSqlMapClientTemplate().queryForObject(GET_ORG_MODEL_TYPE,orgId);
		}
		catch(DataAccessException dex) {
			LOGGER.error(dex.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
    }
    
    /**
     * @Name : getTimezoneForOrganization
     * @Description : this method is used for getting orgnization's branch time zone
     * @param orgId
     * @throws BNPApplicationException
     */
    public String getTimezoneForOrganization(String orgId) throws BNPApplicationException {
    	try {
    		return (String) getSqlMapClientTemplate().queryForObject(GET_ORG_TIME_ZONE,orgId);
    	}
    	catch(DataAccessException dex) {
    		LOGGER.error(dex.getMessage());
    		throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
    	}
    }
	/**
	 * @Name : getAckTemplate
	 * @Description : This method is used to get acknowledgment template for functional ack
	 * @param fileVO
	 * @throws BNPApplicationException
	 */
	public void getAckTemplate(FileDetailsVO fileVO) throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().queryForObject(GET_ACK_TEMPLATE,	fileVO, fileVO);
		}
		catch(DataAccessException dex) {
//			throw new BNPApplicationException("Exception in quering the data", dex);
			LOGGER.error(dex.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR,"Exception in quering the data");
		}
	}
	
	/**
	 * @Name : getERPIDList
	 * @Description : This method is used to get counter party ERP id list
	 * @param orgId
	 * @param billType
	 * @throws BNPApplicationException
	 */
	@Override
	public List<String> getERPIDList(String orgId,String billType) throws BNPApplicationException
	  {
		Properties params = new Properties();
		params.put("orgId", orgId);
		params.put("billType", billType);
		try{
			return getSqlMapClientTemplate().queryForList(GET_ERP_ID_LIST, params);
		}catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	    
	  }
	 
	 @Override
	 public List<String> getCounterPartyOrgId(String orgId, String billType,String cntpERPId)
	    throws BNPApplicationException
	  {
	    Map<String, Object> params = new HashMap<String, Object>();
	    
	    try
	    {
	      params.put("orgId", orgId);
	      params.put("billType", billType);
	      params.put("cntpERPId", cntpERPId);

	      return  (List<String>) getSqlMapClientTemplate().queryForList(GET_COUNTER_PARTY_ORG_ID, params);
	    }
	    catch (DataAccessException e) {
	      throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
	    }

	  }
	 
	 @Override
	 public List<String> getCustomerOrgId(String billType,String custERPId)
	 throws BNPApplicationException
	 {
		 Properties params = new Properties();
		 try
		 {
			 params.put("billType", billType);
			 params.put("custERPId", custERPId);
			 
			 return  (List<String>) getSqlMapClientTemplate().queryForList(GET_CUST_ORG_ID, params);
		 }
		 catch (DataAccessException e) {
			 throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		 }
		 
	 }
	  
	@Override
	public boolean isDepartmentAvailable(String orgId,String dept) 
	throws BNPApplicationException {
		int count = 0;
		 Properties params = new Properties();
		    try
		    {
		      params.put("orgId", orgId);
		      params.put("dept", dept);

		      count =  (Integer) getSqlMapClientTemplate().queryForObject(GET_DEPT_AVAILABLE_COUNT, params);
		    }
		    catch (DataAccessException e) {
		      throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		    }
		  if (count > 0) {
			  return true;
		  } else {
			  return false;
		  }
	}
	@Override
	public boolean checkExistingInvoices(String invRefNo, String orgId) throws BNPApplicationException {
		List<String> invRefList = null;
		try{
			Map<String, Object> params = createParamMap(invRefNo, orgId);
			invRefList =  getSqlMapClientTemplate().queryForList(GET_EXISTING_INVOICES, params);
			if(!(invRefList != null && !invRefList.isEmpty()))
				return false;
			else 
				return true;
		}catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	private Map<String, Object> createParamMap(String refNo, String orgId) {
		Map<String, Object> params = new HashMap<String, Object>();
		
		params.put("refNo", refNo);
		params.put("orgId", orgId);
		
		return params;
	}

	@Override
	public boolean checkExistingCreditNotes(String cntRefNo, String orgId) throws BNPApplicationException {
		Object object = null;
		try{
			Map<String, Object> params = createParamMap(cntRefNo, orgId);
			object = getSqlMapClientTemplate().queryForObject(GET_EXISTING_CREDIT_NOTES, params);
			if(object==null)
				return false;
			else 
				return true;
		}catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public boolean canUploadPartialFile(String orgId) throws BNPApplicationException {
		Object object = null;
		try{
			
			object = getSqlMapClientTemplate().queryForObject(CHECK_FOR_PARTIAL_UPLOAD, orgId);
			if(object != null && object.toString().equalsIgnoreCase("Y"))
				return true;
			else 
				return false;
		}catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public boolean isBuyerSellerLinked(String custOrgId,String cntpOrgId,String billType) throws BNPApplicationException {
		int count = 0;
		Map<String, Object> params = new HashMap<String, Object>();
		
		params.put("custOrgId", custOrgId);
		params.put("cntpOrgId", cntpOrgId);
		params.put("billType", billType);
		
		try{
			
			count = (Integer) getSqlMapClientTemplate().queryForObject(IS_BUYER_SELLER_LINKED, params);
			
			if(count > 0)
				return true;
			else 
				return false;
		}catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public boolean isAccountIdentifierRequired(String custOrgId,String cntpOrgId,String billType) throws BNPApplicationException {
		String accId = null;
		Map<String, Object> params = new HashMap<String, Object>();
		
		params.put("custOrgId", custOrgId);
		params.put("cntpOrgId", cntpOrgId);
		params.put("billType", billType);
		
		try{
			
			accId = (String) getSqlMapClientTemplate().queryForObject(IS_ACCOUNT_IDENTIFIER_CHECKED, params);
			
			if(accId != null && accId.equals("Y")) {
				return true;
			} else if(accId != null && accId.equals("N")) {
				return false;
			} else {  
				accId = (String) getSqlMapClientTemplate().queryForObject(IS_ACC_IDENTIFIER_CHECKED_IN_BILL_TYPE, params);
				
				if (accId != null && accId.equals("Y")) {
					return true;
				} else {
					return false;
				}
			}
		}catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public boolean isUniqueCheckEnabled(String custOrgId,String cntpOrgId,String billType) throws BNPApplicationException {
		String uniqueCheck = null;
		Map<String, Object> params = new HashMap<String, Object>();
		
		params.put("custOrgId", custOrgId);
		params.put("cntpOrgId", cntpOrgId);
		params.put("billType", billType);
		
		try{
			
			uniqueCheck = (String) getSqlMapClientTemplate().queryForObject(IS_UNIQUE_CHECK_ENABLED, params);
			
			if(uniqueCheck != null && uniqueCheck.equals("Y")) {
				return true;
			} else if(uniqueCheck != null && uniqueCheck.equals("N")) {
				return false;
			} else { 
				uniqueCheck = (String) getSqlMapClientTemplate().queryForObject(IS_UNIQUE_CHECK_ENABLED_BT, params);
				
				if(uniqueCheck != null && uniqueCheck.equals("Y")) {
					return true;
				} else {
					return false;
				}
			}
		}catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public boolean isAccountIdentifierExists(String custOrgId,String acctIdnt) 
	throws BNPApplicationException {
		int count = 0;
		Map<String, Object> params = new HashMap<String, Object>();
		
		params.put("custOrgId", custOrgId);
		params.put("acctIdnt", acctIdnt);
		
		try{
			
			count =  (Integer) getSqlMapClientTemplate().queryForObject(IS_ACCOUNT_IDENTIFIER_EXISTS, params);
			
			if(count > 0)
				return true;
			else 
				return false;
		}catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public boolean isLinkedInvoiceExists(EippCreditNoteVO eippCreditNoteVO) 
	throws BNPApplicationException {
		int count = 0;
		
		try{
			
			count =  (Integer) getSqlMapClientTemplate().queryForObject(IS_LINKED_INVOICE_EXISTS, eippCreditNoteVO);
			
			if(count > 0)
				return true;
			else 
				return false;
		}catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public boolean isInvoiceExists(EippInvoiceVO eippInvoiceVO) 
	throws BNPApplicationException {
		int count = 0;
		
		try{
			
			count =  (Integer) getSqlMapClientTemplate().queryForObject(IS_INVOICE_EXISTS, eippInvoiceVO);
			
			if(count > 0)
				return true;
			else 
				return false;
		}catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public boolean isMatchInvoiceExists(EippInvoiceVO eippInvoiceVO) 
		throws BNPApplicationException {
		int count = 0;
		try{
			count =  (Integer) getSqlMapClientTemplate().queryForObject(IS_MATCH_INVOICE_EXISTS, eippInvoiceVO);
			if(count > 0)
				return true;
			else 
				return false;
		}catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	
	@Override
	public boolean isMatchCreditNoteExists(EippCreditNoteVO eippCreditNoteVO) 
	throws BNPApplicationException {
		int count = 0;
		
		try{
			
			count =  (Integer) getSqlMapClientTemplate().queryForObject(IS_MATCH_CREDIT_NOTE_EXISTS, eippCreditNoteVO);
			
			if(count > 0)
				return true;
			else 
				return false;
		}catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public boolean isCreditNoteExists(EippCreditNoteVO eippCreditNoteVO) 
	throws BNPApplicationException {
		int count = 0;
		
		try{
			
			count =  (Integer) getSqlMapClientTemplate().queryForObject(IS_CREDIT_NOTE_EXISTS, eippCreditNoteVO);
			
			if(count > 0)
				return true;
			else 
				return false;
		}catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public boolean canConvertToUnlinked(String orgId) throws BNPApplicationException {
		String flag= null;
		try {
			flag =  (String) getSqlMapClientTemplate().queryForObject(GET_CONVERT_TO_UNLINKED, orgId);
		} catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		if (flag != null && flag.equals("R")) {
			return true;
		} else {
			return false;
		}

	}
	
	public void checkInvCountForCreditNote(
			EippCreditNoteVO creditNote) throws BNPApplicationException {
		Integer count = null;
		
		try {
			count =  (Integer) getSqlMapClientTemplate().queryForObject(GET_INV_COUNT_FOR_CN, creditNote);
			
			count = count == null ? 0 : count;
			
			if (count > 1) {
				throw new BNPApplicationException(ErrorConstants.DUPLICATE_INVOICE_REF_NUM);
			}
		} catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}

	
	
	/**
	 * @Name : updateReprocessFlagForOldRejectedRecords
	 * @Description : This method is update reprocess flag old invalid records 
	 * @param :InvalidFileDataVO
	 * @throws BNPApplicationException
	 * 
	 */
	@Override
	public void updateReprocessFlagForOldRejectedRecords(
			FileDetailsVO detailsVO)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().update(UPDATE_REPROCESS_FLAG, detailsVO);
		} catch (DataAccessException dex) {
			LOGGER.error(dex.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR,
					dex.getMessage());
		}
	}
	
	@Override
	public void insertCancelInvoiceList(final List<EippInvoiceCancelVO> invoiceCancelList,final FileDetailsVO fileVO) throws BNPApplicationException{
		try {
			getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
				public List<Object> doInSqlMapClient(SqlMapExecutor executor)
				throws SQLException {
					List<Object> list = null;

					try {

						// inserting cancel invoice details
						for (EippInvoiceCancelVO eippInvoiceCancelVO : invoiceCancelList) {
							executor.startBatch();

							eippInvoiceCancelVO.setInvRefNo(eippInvoiceCancelVO.getInvRefNo().trim());
							eippInvoiceCancelVO.setFileId(fileVO.getFileId());
							eippInvoiceCancelVO.setMakerId(fileVO.getUserId());
							eippInvoiceCancelVO.setMakerDate(new Date(System.currentTimeMillis()));
							eippInvoiceCancelVO.setRecordStatus(StatusConstants.WAITING_FOR_APPROVAL_REQUEST);
							executor.insert(INSERT_CANCEL_INVOICE_DETAILS, eippInvoiceCancelVO);
							list = executor.executeBatchDetailed();

							EippAuditVO auditVO = new EippAuditVO();

							auditVO.setInvId(eippInvoiceCancelVO.getInvId());
							auditVO.setAuditUser(eippInvoiceCancelVO.getMakerId());
							auditVO.setStatus(eippInvoiceCancelVO.getRecordStatus());
							auditVO.setAction(EippAuditConstants.CANCEL_INV_UPLOADED);

							// insert into invoice audit
							executor.startBatch();
							executor.insert(CREATE_INV_AUDIT, auditVO);
							executor.executeBatchDetailed();

						}
					} catch (BatchException e) {							
						LOGGER.error("Uploading the cancel invoice details in a batch failed");
						throw new SQLException(e);
					} 
					//FO 7.0 Fortify Issue Fix
					//LOGGER.debug("List :: " + list);
					return list;
				}
			});
		} catch (DataAccessException e) {
			throw new BNPRuntimeException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
    /**
	 * @Name : getOrgTypeForOrganization
	 * @Description : this method is used for getting orgnization's org_type
	 * @param orgId
	 * @throws BNPApplicationException
	 */
	@Override
    public String getOrgTypeForOrganization(String orgId) throws BNPApplicationException {
    	try {
			return (String) getSqlMapClientTemplate().queryForObject(GET_ORG_TYPE,orgId);
		}
		catch(DataAccessException dex) {
			LOGGER.error(dex.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
    }
	
	/**
	 * @Name : isBillThroughMarketPlace
	 * @Description : this method validates whether BIll type, bill through is enabled with the given market place org id
	 * @param billType
	 * @param marketPlaceOrgId
	 * @throws BNPApplicationException
	 */
	@Override
	public boolean isBillThroughMarketPlace(String billType, String marketPlaceOrgId) throws BNPApplicationException {
		String billThroughMP = null;
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("billType", billType);
		params.put("marketPlaceOrgId", marketPlaceOrgId);
		
		try{
			billThroughMP = (String) getSqlMapClientTemplate().queryForObject(IS_BILL_THROUGH_MARKET_PLACE, params);
			
			if(billThroughMP != null && billThroughMP.equals("Y")) {
				return true;
			} else{
				return false;
			} 
		}catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/**
	 * @Name : checkMarketPlaceIsParentOrg
	 * @Description : this method checks whether the customer organization has market place as parent organization
	 * @param custOrgId
	 * @param marketPlaceOrgId
	 * @throws BNPApplicationException
	 */
	@Override
	public boolean checkMarketPlaceIsParentOrg(String custOrgId, String marketPlaceOrgId) throws BNPApplicationException {
		int count = 0;
		Properties params = new Properties();
		try {
			params.put("custOrgId", custOrgId);
			params.put("marketPlaceOrgId", marketPlaceOrgId);

			count =  (Integer) getSqlMapClientTemplate().queryForObject(IS_MARKET_PLACE_IS_PAR_ORG, params);
		} catch (DataAccessException e) {
			throw new BNPRuntimeException(ErrorConstants.DATABASE_ERROR);
		}
		return (count > 0) ? true : false;
	}
	
	/**
	 * @Name : isCustomerOrgLinkedToMarketPlace
	 * @Description : this method checks whether the customer organization is linked to this market place org id
	 * @param custOrgId
	 * @param marketPlaceOrgId
	 * @throws BNPApplicationException
	 */
	@Override
	public boolean isCustomerOrgLinkedToMarketPlace(String custOrgId, String marketPlaceOrgId) throws BNPApplicationException {
		int count = 0;
		Properties params = new Properties();
		try {
			params.put("custOrgId", custOrgId);
			params.put("marketPlaceOrgId", marketPlaceOrgId);

			count =  (Integer) getSqlMapClientTemplate().queryForObject(IS_CUST_LINKED_TO_MARKET_PLACE, params);
		} catch (DataAccessException e) {
			throw new BNPRuntimeException(ErrorConstants.DATABASE_ERROR);
		}
		return (count > 0) ? true : false;

	}
	
	/**
	 * @Name : isBuyerSellerLinkedToMarketPlace
	 * @Description : this method checks whether the buyer and seller linked to market place for that bill type
	 * @param custOrgId
	 * @param cntpOrgId
	 * @param billType
	 * @param marketPlaceOrgId
	 * @throws BNPApplicationException
	 */
	@Override
	public boolean isBuyerSellerLinkedToMarketPlace(String custOrgId,String cntpOrgId,String billType,String marketPlaceOrgId) throws BNPApplicationException {
		int count = 0;
		Map<String, Object> params = new HashMap<String, Object>();
		
		params.put("custOrgId", custOrgId);
		params.put("cntpOrgId", cntpOrgId);
		params.put("billType", billType);
		params.put("marketPlaceOrgId", marketPlaceOrgId);
		
		try{
			count = (Integer) getSqlMapClientTemplate().queryForObject(IS_BUYER_SELLER_LINKED_TO_MKT_PLACE, params);
			
			return (count > 0) ? true : false;
			
		}catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/**
	 * @Name : getRuleTypeForDiscountRuleId
	 * @Description : This method returns the Rule type for the Discount rule id
	 * @param EippInvoiceVO eippInvoiceVO
	 * @throws BNPApplicationException
	 */
	@Override
	public String getRuleTypeForDiscountRuleId(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException {
		String ruleType = null;
		Properties params = new Properties();
		try {
			params.put("discRuleId", eippInvoiceVO.getDiscRuleId());
			params.put("billType", eippInvoiceVO.getBillType());
			params.put("supplierOrgId", eippInvoiceVO.getSupplierOrgId());
			params.put("buyerOrgId", eippInvoiceVO.getBuyerOrgId());
			params.put("issueDate", eippInvoiceVO.getIssueDate());

			ruleType =  (String) getSqlMapClientTemplate().queryForObject(GET_RULE_TYPE_FOR_DISCOUNT_RULE_ID, params);
		} catch (DataAccessException e) {
			throw new BNPRuntimeException(ErrorConstants.DATABASE_ERROR);
		}
		return ruleType;

	}
	
	/**
	 * @Name : isInvoiceAvailableInSystem
	 * @Description : This method returns the number of invoices already exists in our system
	 * @param Properties params
	 * @throws BNPApplicationException
	 */
	@Override
	public int isInvoiceAvailableInSystem(Properties params) throws BNPApplicationException{

		int count = 0;
		try{
			count =  (Integer) getSqlMapClientTemplate().queryForObject(GET_INVOICE_COUNT_AVAILABLE, params);
			return count;
		}catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	
	}
	
	/**
	 * @Name : isDefaultBusinessRuleEnabled
	 * @Description : This method checks whether default business rule is enabled in Link org
	 * @param custOrgId
	 * @param cntpOrgId
	 * @param billType
	 * @throws BNPApplicationException
	 */
	@Override
	public boolean isDefaultBusinessRuleEnabled(String custOrgId,String cntpOrgId,String billType)throws BNPApplicationException{
		boolean isDefaultRuleEnabled = false;
		Map<String, Object> params = new HashMap<String, Object>();
		
		try {
			params.put("custOrgId", custOrgId);
			params.put("cntpOrgId", cntpOrgId);
			params.put("billType", billType);
			
			isDefaultRuleEnabled =  (Boolean) getSqlMapClientTemplate().queryForObject(IS_DEFAULT_BUSI_RULE_ENABLED, params);
		} catch (DataAccessException e) {
			throw new BNPRuntimeException(ErrorConstants.DATABASE_ERROR);
		}
		return isDefaultRuleEnabled;
	}
	
	/**
	 * @Name : getBusinessProcessingRulesFromBillType
	 * @Description : This method gets the default business rule applicable for this bill type
	 * @param custOrgId
	 * @param cntpOrgId
	 * @param billType
	 * @throws BNPApplicationException
	 */
	@Override
	public EippInvoiceBusinessRulesVO getBusinessProcessingRulesFromBillType(String custOrgId,String cntpOrgId,String billType)throws BNPApplicationException{
		EippInvoiceBusinessRulesVO businessRulesVO = null;
		Map<String, Object> params = new HashMap<String, Object>();
		
		try {
			params.put("custOrgId", custOrgId);
			params.put("cntpOrgId", cntpOrgId);
			params.put("billType", billType);
			
			businessRulesVO =  (EippInvoiceBusinessRulesVO) getSqlMapClientTemplate().queryForObject(GET_BUSINESS_RULES_FROM_BILL_TYPE, params);
		} catch (DataAccessException e) {
			throw new BNPRuntimeException(ErrorConstants.DATABASE_ERROR);
		}
		return businessRulesVO;
	}
	
	/**
	 * @Name : getBusinessProcessingRulesFromLinkOrg
	 * @Description : This method gets the business rule from link org for this buyer,seller and bill type
	 * @param custOrgId
	 * @param cntpOrgId
	 * @param billType
	 * @throws BNPApplicationException
	 */
	@Override
	public EippInvoiceBusinessRulesVO getBusinessProcessingRulesFromLinkOrg(String custOrgId,String cntpOrgId,String billType)throws BNPApplicationException{
		EippInvoiceBusinessRulesVO businessRulesVO = null;
		Map<String, Object> params = new HashMap<String, Object>();
		
		try {
			params.put("custOrgId", custOrgId);
			params.put("cntpOrgId", cntpOrgId);
			params.put("billType", billType);
			
			businessRulesVO =  (EippInvoiceBusinessRulesVO) getSqlMapClientTemplate().queryForObject(GET_BUSINESS_RULES_FROM_LINK_ORG, params);
		} catch (DataAccessException e) {
			throw new BNPRuntimeException(ErrorConstants.DATABASE_ERROR);
		}
		return businessRulesVO;
	}
	
	/**
	 * @Name : getInvoiceListForValidation
	 * @Description : This method gets the multiple invoice records for validation
	 * @param params
	 * @throws BNPApplicationException
	 */
	@Override
	public List<EippInvoiceVO> getInvoiceListForValidation(Map<String, Object> params) throws BNPApplicationException {
		List<EippInvoiceVO> invoiceList;
		try{
			invoiceList =  (List<EippInvoiceVO>) getSqlMapClientTemplate().queryForList(GET_INVOICES_FOR_VALIDATION, params);
			return invoiceList;
		}catch(DataAccessException e){
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
	}


	@Override
	public boolean isBillTypeLinkedToMarketPlace(String orgId, String billType)
			throws BNPApplicationException {
		Integer count;
		
		Map<String, Object> params = new HashMap<String, Object>();
		
		params.put("orgId", orgId);
		params.put("billType", billType);
		
		try {
			count = (Integer)getSqlMapClientTemplate().queryForObject(IS_BILL_TYPE_LINKED_TO_MP, params);
		} catch (DataAccessException e) {
			LOGGER.error("Error while checking for bill type : " + e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		return count == null ? false : count > 0 ? true : false;
	}
	
	@Override
	public String matchRecords(long fileId) throws BNPApplicationException{
		
		String errorCode = null;
		Map<String,Object> params = new HashMap<String, Object>();
		params.put("fileId", fileId);
		params.put("pymtRefNo", null);
		params.put("errorCode", null);
		try {
			getSqlMapClientTemplate().queryForObject(MATCH_RECORDS_SP, params);
			errorCode = (String) params.get("errorCode");
			//FO 7.0 Fortify Issue Fix
			//LOGGER.info("Error Code Value is" +errorCode);
		} catch (DataAccessException e) {
			LOGGER.error("error in "+ e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		return errorCode;
	}


	@Override
	public String fetchAllocType(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException {
		String allocType = null;
		try{
			allocType =  (String)getSqlMapClientTemplate().queryForObject(FETCH_ALLOC_TYPE_FROM_LINK_ORG , eippInvoiceVO);
		}catch(DataAccessException e){
			//FO 7.0 Fortify Issue Fix
			LOGGER.error("Error while getting alloc type from link org during file upload",e);
			throw new BNPApplicationException(ErrorConstants.PROCESSING_ERROR);
		}
		return allocType;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Long> getPendingMatchFiles(final String orgId) throws BNPApplicationException {
		//FO 7.0 Fortify Issue Fix
		//LOGGER.info("getPendingMatchFiles: " + orgId);
		List<Long> fileLst;
		try{
			fileLst =  (List<Long>) getSqlMapClientTemplate().queryForList(GET_PENDING_MATCH_FILES, orgId);
		}
		catch(DataAccessException ex) {
			LOGGER.error("getPendingMatchFiles: " + ex.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		catch(RuntimeException ex) {
			LOGGER.error("getPendingMatchFiles: " + ex.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return fileLst;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.dao.IEippInvcUploadDAO#chkValidInvLIfromLinkOrg(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
	@Override
	public boolean chkValidInvLIfromLinkOrg(DisputeVO invLIVO){
		LOGGER.debug(" Error in chkValidInvLIfromLinkOrg Entered" );
		return (Boolean)getSqlMapClientTemplate().queryForObject(GET_INV_LI_LINKORG, invLIVO);
	}
	
		@Override
	public boolean isAttUploadedForExistingInvoices(FileDetailsVO detailsVO)
			throws BNPApplicationException {
		Integer count;
		try {
			count = (Integer) getSqlMapClientTemplate().queryForObject(IS_INVOICES_UPLOADED_FOR_FILE, detailsVO.getFileId());
		} catch (DataAccessException e) {
			LOGGER.error("isAttUploadedForExistingInvoices : " + e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return count == null ? false : count > 0 ? true : false;
	}

	@Override
	public byte[] getAttachmentData(long fileId) throws BNPApplicationException {
		byte[] data = null;
		
		try {
			AttachmentVO attachment = (AttachmentVO) getSqlMapClientTemplate().queryForObject(
					GET_ATTACHMENT_DATA, fileId);
			if (attachment != null) {
				data = attachment.getData();
			}
		} catch (DataAccessException e) {
			LOGGER.error("getAttachmentData : " + e.getMessage());
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return data;
	}
}
