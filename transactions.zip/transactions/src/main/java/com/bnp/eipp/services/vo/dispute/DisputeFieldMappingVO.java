/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 28, 20122:50:41 PM
 * 
 * Purpose:      DisputeDetailCustFieldsVO.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Aug 28, 20122:50:41 PM        Oracle Financial Services Software Ltd                  Initial Version  
************************************************************************************************************************************************************/

package com.bnp.eipp.services.vo.dispute;

import java.io.Serializable;

public class DisputeFieldMappingVO implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String otherReasons;
	
	private String buyerMemo;
	
	private DisputeCustFieldsVO quantity=new DisputeCustFieldsVO();	
	
	private DisputeCustFieldsVO unitPrice=new DisputeCustFieldsVO();		
	
	private DisputeCustFieldsVO subtotal=new DisputeCustFieldsVO();	
	
	public DisputeFieldMappingVO()
	{
		quantity.setFieldName("Quantity (Nos.)");
		unitPrice.setFieldName("Unit Price");
		subtotal.setFieldName("Subtotal");
	}
	
	public DisputeCustFieldsVO getQuantity() {
		return quantity;
	}
	public void setQuantity(DisputeCustFieldsVO quantity) {
		this.quantity = quantity;
	}
	public DisputeCustFieldsVO getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(DisputeCustFieldsVO unitPrice) {
		this.unitPrice = unitPrice;
	}
	public DisputeCustFieldsVO getSubtotal() {
		return subtotal;
	}
	public void setSubtotal(DisputeCustFieldsVO subtotal) {
		this.subtotal = subtotal;
	}

	public String getOtherReasons() {
		return otherReasons;
	}

	public void setOtherReasons(String otherReasons) {
		this.otherReasons = otherReasons;
	}

	public String getBuyerMemo() {
		return buyerMemo;
	}

	public void setBuyerMemo(String buyerMemo) {
		this.buyerMemo = buyerMemo;
	}	

}
