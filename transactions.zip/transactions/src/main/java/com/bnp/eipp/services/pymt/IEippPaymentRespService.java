/****************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 Nov 2012
 * 
 * Purpose: Eipp Payment Response Message Service
 * 
 * Change History: 
 * Date                       	Author                                  		Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 27 Nov 2012              	Gangadharan R                      			Initial Version
 * 05 Dec 2012					Gangadharan R								Adhoc - Payment Response logic modification
 ********************************************************************************************************************************/

package com.bnp.eipp.services.pymt;

import com.bnp.eipp.services.vo.payment.EippPaymentMsgDetailVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.txns.common.message.AbstractMsg;

public interface IEippPaymentRespService {
	
	/**
	 * Process message.
	 *
	 * @param message the message
	 * @param detailsVO the details vo
	 */
	void processMessage(AbstractMsg<?> message) throws BNPApplicationException;
	
	/**
	 * Update payment status.
	 *
	 * @param pymtMsgDtlVO the pymt msg dtl vo
	 * @throws BNPApplicationException 
	 */
	void updatePaymentStatus(EippPaymentMsgDetailVO pymtMsgDtlVO) throws BNPApplicationException;
}
