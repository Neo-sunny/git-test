package com.bnp.eipp.services.matching.invoice.bindingvo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.bnp.scm.services.txns.util.calendar.DateAdapter;

/**
 * <p>
 * Java class for InvoiceAndPODetails01 complex type.
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="InvoiceAndPODetails01">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="FileId" type="{}Max35Text" minOccurs="0"/>
 *         &lt;element name="RefNumber" type="{}Max35Text"/>
 *         &lt;element name="ResolutionDept" type="{}Max35Text" minOccurs="0"/>
 *         &lt;element name="DisputeDept" type="{}Max35Text" minOccurs="0"/>
 *         &lt;element name="IssueDate" type="{}Date" minOccurs="0"/>
 *         &lt;element name="RefDate" type="{}Date" minOccurs="0"/>
 *         &lt;element name="DueDate" type="{}Date" minOccurs="0"/>
 *         &lt;element name="Ccy" type="{}CurrencyCode" minOccurs="0"/>
 *         &lt;element name="InvAmt" type="{}CurrencyAndAmount_SimpleType" minOccurs="0"/>
 *         &lt;element name="TaxAmt" type="{}CurrencyAndAmount_SimpleType" minOccurs="0"/>
 *         &lt;element name="TaxRate" type="{}Rate_SimpleType" minOccurs="0"/>
 *         &lt;element name="DiscRuleId" type="{}Max20Text" minOccurs="0"/>
 *         &lt;element name="DiscAmt" type="{}CurrencyAndAmount_SimpleType" minOccurs="0"/>
 *         &lt;element name="TaxNo" type="{}Max30Text" minOccurs="0"/>
 *         &lt;element name="TaxRefDate" type="{}Date" minOccurs="0"/>
 *         &lt;element name="TaxPercent" type="{}Max20Text" minOccurs="0"/>
 *         &lt;element name="PONo" type="{}Max35Text" minOccurs="0"/>
 *         &lt;element name="DelNoteNo" type="{}Max35Text" minOccurs="0"/>
 *         &lt;element name="DelNoteDate" type="{}Date" minOccurs="0"/>
 *         &lt;element name="ShipRefNo" type="{}Max50Text" minOccurs="0"/>
 *         &lt;element name="ShippingMode" type="{}Max35Text" minOccurs="0"/>
 *         &lt;element name="ShippingTerms" type="{}Max35Text" minOccurs="0"/>
 *         &lt;element name="ShipDate" type="{}Date" minOccurs="0"/>
 *         &lt;element name="ShipTo" type="{}Address01" minOccurs="0"/>
 *         &lt;element name="BillTo" type="{}Address01" minOccurs="0"/>
 *         &lt;element name="RemitTo" type="{}Address01" minOccurs="0"/>
 *         &lt;element name="LineItems" type="{}LineItems01" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="InclNote" type="{}AdditionalInformation1" maxOccurs="50" minOccurs="0"/>
 *         &lt;element name="SupplierAccId" type="{}Max30Text" minOccurs="0"/>
 *         &lt;element name="MatchRef" type="{}Max20Text" minOccurs="0"/>
 *         &lt;element name="ReconciliationRate" type="{}Max30Text" minOccurs="0"/>
 *         &lt;element name="MatchType" type="{}Max20Text" minOccurs="0"/>
 *         &lt;element name="MatchStatus" type="{}Max30Text" minOccurs="0"/>
 *         &lt;element name="MatchRemarks" type="{}Max2048Text" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InvoiceAndPODetails01", propOrder = { "fileId", "refNumber", "resolutionDept", "disputeDept",
		"issueDate", "refDate", "dueDate", "ccy", "invAmt", "taxAmt", "taxRate", "discRuleId", "discAmt", "taxNo",
		"taxRefDate", "taxPercent", "poNo", "delNoteNo", "delNoteDate", "shipRefNo", "shippingMode", "shippingTerms",
		"shipDate", "shipTo", "billTo", "remitTo", "lineItems", "inclNote", "supplierAccId", "matchRef",
		"reconciliationRate", "matchType", "matchStatus", "matchRemarks" })
public class InvoiceAndPODetails01 {

	@XmlElement(name = "FileId")
	protected String fileId;

	@XmlElement(name = "RefNumber", required = true)
	protected String refNumber;

	@XmlElement(name = "ResolutionDept")
	protected String resolutionDept;

	@XmlElement(name = "DisputeDept")
	protected String disputeDept;

	@XmlElement(name = "IssueDate", type = String.class)
	@XmlJavaTypeAdapter(DateAdapter.class)
	protected Calendar issueDate;

	@XmlElement(name = "RefDate", type = String.class)
	@XmlJavaTypeAdapter(DateAdapter.class)
	protected Calendar refDate;

	@XmlElement(name = "DueDate", type = String.class)
	@XmlJavaTypeAdapter(DateAdapter.class)
	protected Calendar dueDate;

	@XmlElement(name = "Ccy")
	protected String ccy;

	@XmlElement(name = "InvAmt")
	protected BigDecimal invAmt;

	@XmlElement(name = "TaxAmt")
	protected BigDecimal taxAmt;

	@XmlElement(name = "TaxRate")
	protected BigDecimal taxRate;

	@XmlElement(name = "DiscRuleId")
	protected String discRuleId;

	@XmlElement(name = "DiscAmt")
	protected BigDecimal discAmt;

	@XmlElement(name = "TaxNo")
	protected String taxNo;

	@XmlElement(name = "TaxRefDate", type = String.class)
	@XmlJavaTypeAdapter(DateAdapter.class)
	protected Calendar taxRefDate;

	@XmlElement(name = "TaxPercent")
	protected String taxPercent;

	@XmlElement(name = "PONo")
	protected String poNo;

	@XmlElement(name = "DelNoteNo")
	protected String delNoteNo;

	@XmlElement(name = "DelNoteDate", type = String.class)
	@XmlJavaTypeAdapter(DateAdapter.class)
	protected Calendar delNoteDate;

	@XmlElement(name = "ShipRefNo")
	protected String shipRefNo;

	@XmlElement(name = "ShippingMode")
	protected String shippingMode;

	@XmlElement(name = "ShippingTerms")
	protected String shippingTerms;

	@XmlElement(name = "ShipDate", type = String.class)
	@XmlJavaTypeAdapter(DateAdapter.class)
	protected Calendar shipDate;

	@XmlElement(name = "ShipTo")
	protected Address01 shipTo;

	@XmlElement(name = "BillTo")
	protected Address01 billTo;

	@XmlElement(name = "RemitTo")
	protected Address01 remitTo;

	@XmlElement(name = "LineItems")
	protected List<LineItems01> lineItems;

	@XmlElement(name = "InclNote")
	protected List<AdditionalInformation1> inclNote;

	@XmlElement(name = "SupplierAccId")
	protected String supplierAccId;

	@XmlElement(name = "MatchRef")
	protected String matchRef;

	@XmlElement(name = "ReconciliationRate")
	protected String reconciliationRate;

	@XmlElement(name = "MatchType")
	protected String matchType;

	@XmlElement(name = "MatchStatus")
	protected String matchStatus;

	@XmlElement(name = "MatchRemarks")
	protected String matchRemarks;

	/**
	 * Gets the value of the fileId property.
	 * @return possible object is {@link String }
	 */
	public String getFileId() {
		return fileId;
	}

	/**
	 * Sets the value of the fileId property.
	 * @param value allowed object is {@link String }
	 */
	public void setFileId(String value) {
		this.fileId = value;
	}

	/**
	 * Gets the value of the refNumber property.
	 * @return possible object is {@link String }
	 */
	public String getRefNumber() {
		return refNumber;
	}

	/**
	 * Sets the value of the refNumber property.
	 * @param value allowed object is {@link String }
	 */
	public void setRefNumber(String value) {
		this.refNumber = value;
	}

	/**
	 * Gets the value of the resolutionDept property.
	 * @return possible object is {@link String }
	 */
	public String getResolutionDept() {
		return resolutionDept;
	}

	/**
	 * Sets the value of the resolutionDept property.
	 * @param value allowed object is {@link String }
	 */
	public void setResolutionDept(String value) {
		this.resolutionDept = value;
	}

	/**
	 * Gets the value of the disputeDept property.
	 * @return possible object is {@link String }
	 */
	public String getDisputeDept() {
		return disputeDept;
	}

	/**
	 * Sets the value of the disputeDept property.
	 * @param value allowed object is {@link String }
	 */
	public void setDisputeDept(String value) {
		this.disputeDept = value;
	}

	/**
	 * Gets the value of the issueDate property.
	 * @return possible object is {@link String }
	 */
	public Calendar getIssueDate() {
		return issueDate;
	}

	/**
	 * Sets the value of the issueDate property.
	 * @param value allowed object is {@link String }
	 */
	public void setIssueDate(Calendar value) {
		this.issueDate = value;
	}

	/**
	 * Gets the value of the refDate property.
	 * @return possible object is {@link String }
	 */
	public Calendar getRefDate() {
		return refDate;
	}

	/**
	 * Sets the value of the refDate property.
	 * @param value allowed object is {@link String }
	 */
	public void setRefDate(Calendar value) {
		this.refDate = value;
	}

	/**
	 * Gets the value of the dueDate property.
	 * @return possible object is {@link String }
	 */
	public Calendar getDueDate() {
		return dueDate;
	}

	/**
	 * Sets the value of the dueDate property.
	 * @param value allowed object is {@link String }
	 */
	public void setDueDate(Calendar value) {
		this.dueDate = value;
	}

	/**
	 * Gets the value of the ccy property.
	 * @return possible object is {@link String }
	 */
	public String getCcy() {
		return ccy;
	}

	/**
	 * Sets the value of the ccy property.
	 * @param value allowed object is {@link String }
	 */
	public void setCcy(String value) {
		this.ccy = value;
	}

	/**
	 * Gets the value of the invAmt property.
	 * @return possible object is {@link BigDecimal }
	 */
	public BigDecimal getInvAmt() {
		return invAmt;
	}

	/**
	 * Sets the value of the invAmt property.
	 * @param value allowed object is {@link BigDecimal }
	 */
	public void setInvAmt(BigDecimal value) {
		this.invAmt = value;
	}

	/**
	 * Gets the value of the taxAmt property.
	 * @return possible object is {@link BigDecimal }
	 */
	public BigDecimal getTaxAmt() {
		return taxAmt;
	}

	/**
	 * Sets the value of the taxAmt property.
	 * @param value allowed object is {@link BigDecimal }
	 */
	public void setTaxAmt(BigDecimal value) {
		this.taxAmt = value;
	}

	/**
	 * Gets the value of the taxRate property.
	 * @return possible object is {@link BigDecimal }
	 */
	public BigDecimal getTaxRate() {
		return taxRate;
	}

	/**
	 * Sets the value of the taxRate property.
	 * @param value allowed object is {@link BigDecimal }
	 */
	public void setTaxRate(BigDecimal value) {
		this.taxRate = value;
	}

	/**
	 * Gets the value of the discRuleId property.
	 * @return possible object is {@link String }
	 */
	public String getDiscRuleId() {
		return discRuleId;
	}

	/**
	 * Sets the value of the discRuleId property.
	 * @param value allowed object is {@link String }
	 */
	public void setDiscRuleId(String value) {
		this.discRuleId = value;
	}

	/**
	 * Gets the value of the discAmt property.
	 * @return possible object is {@link BigDecimal }
	 */
	public BigDecimal getDiscAmt() {
		return discAmt;
	}

	/**
	 * Sets the value of the discAmt property.
	 * @param value allowed object is {@link BigDecimal }
	 */
	public void setDiscAmt(BigDecimal value) {
		this.discAmt = value;
	}

	/**
	 * Gets the value of the taxNo property.
	 * @return possible object is {@link String }
	 */
	public String getTaxNo() {
		return taxNo;
	}

	/**
	 * Sets the value of the taxNo property.
	 * @param value allowed object is {@link String }
	 */
	public void setTaxNo(String value) {
		this.taxNo = value;
	}

	/**
	 * Gets the value of the taxRefDate property.
	 * @return possible object is {@link String }
	 */
	public Calendar getTaxRefDate() {
		return taxRefDate;
	}

	/**
	 * Sets the value of the taxRefDate property.
	 * @param value allowed object is {@link String }
	 */
	public void setTaxRefDate(Calendar value) {
		this.taxRefDate = value;
	}

	/**
	 * Gets the value of the taxPercent property.
	 * @return possible object is {@link String }
	 */
	public String getTaxPercent() {
		return taxPercent;
	}

	/**
	 * Sets the value of the taxPercent property.
	 * @param value allowed object is {@link String }
	 */
	public void setTaxPercent(String value) {
		this.taxPercent = value;
	}

	/**
	 * Gets the value of the poNo property.
	 * @return possible object is {@link String }
	 */
	public String getPONo() {
		return poNo;
	}

	/**
	 * Sets the value of the poNo property.
	 * @param value allowed object is {@link String }
	 */
	public void setPONo(String value) {
		this.poNo = value;
	}

	/**
	 * Gets the value of the delNoteNo property.
	 * @return possible object is {@link String }
	 */
	public String getDelNoteNo() {
		return delNoteNo;
	}

	/**
	 * Sets the value of the delNoteNo property.
	 * @param value allowed object is {@link String }
	 */
	public void setDelNoteNo(String value) {
		this.delNoteNo = value;
	}

	/**
	 * Gets the value of the delNoteDate property.
	 * @return possible object is {@link String }
	 */
	public Calendar getDelNoteDate() {
		return delNoteDate;
	}

	/**
	 * Sets the value of the delNoteDate property.
	 * @param value allowed object is {@link String }
	 */
	public void setDelNoteDate(Calendar value) {
		this.delNoteDate = value;
	}

	/**
	 * Gets the value of the shipRefNo property.
	 * @return possible object is {@link String }
	 */
	public String getShipRefNo() {
		return shipRefNo;
	}

	/**
	 * Sets the value of the shipRefNo property.
	 * @param value allowed object is {@link String }
	 */
	public void setShipRefNo(String value) {
		this.shipRefNo = value;
	}

	/**
	 * Gets the value of the shippingMode property.
	 * @return possible object is {@link String }
	 */
	public String getShippingMode() {
		return shippingMode;
	}

	/**
	 * Sets the value of the shippingMode property.
	 * @param value allowed object is {@link String }
	 */
	public void setShippingMode(String value) {
		this.shippingMode = value;
	}

	/**
	 * Gets the value of the shippingTerms property.
	 * @return possible object is {@link String }
	 */
	public String getShippingTerms() {
		return shippingTerms;
	}

	/**
	 * Sets the value of the shippingTerms property.
	 * @param value allowed object is {@link String }
	 */
	public void setShippingTerms(String value) {
		this.shippingTerms = value;
	}

	/**
	 * Gets the value of the shipDate property.
	 * @return possible object is {@link String }
	 */
	public Calendar getShipDate() {
		return shipDate;
	}

	/**
	 * Sets the value of the shipDate property.
	 * @param value allowed object is {@link String }
	 */
	public void setShipDate(Calendar value) {
		this.shipDate = value;
	}

	/**
	 * Gets the value of the shipTo property.
	 * @return possible object is {@link Address01 }
	 */
	public Address01 getShipTo() {
		return shipTo;
	}

	/**
	 * Sets the value of the shipTo property.
	 * @param value allowed object is {@link Address01 }
	 */
	public void setShipTo(Address01 value) {
		this.shipTo = value;
	}

	/**
	 * Gets the value of the billTo property.
	 * @return possible object is {@link Address01 }
	 */
	public Address01 getBillTo() {
		return billTo;
	}

	/**
	 * Sets the value of the billTo property.
	 * @param value allowed object is {@link Address01 }
	 */
	public void setBillTo(Address01 value) {
		this.billTo = value;
	}

	/**
	 * Gets the value of the remitTo property.
	 * @return possible object is {@link Address01 }
	 */
	public Address01 getRemitTo() {
		return remitTo;
	}

	/**
	 * Sets the value of the remitTo property.
	 * @param value allowed object is {@link Address01 }
	 */
	public void setRemitTo(Address01 value) {
		this.remitTo = value;
	}

	/**
	 * Gets the value of the lineItems property.
	 * <p>
	 * This accessor method returns a reference to the live list, not a snapshot. Therefore any modification you make to the returned list will be present inside the JAXB object. This is why there is
	 * not a <CODE>set</CODE> method for the lineItems property.
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
     *    getLineItems().add(newItem);
     * </pre>
	 * <p>
	 * Objects of the following type(s) are allowed in the list {@link LineItems01 }
	 */
	public List<LineItems01> getLineItems() {
		if (lineItems == null) {
			lineItems = new ArrayList<LineItems01>();
		}
		return this.lineItems;
	}

	/**
	 * Gets the value of the inclNote property.
	 * <p>
	 * This accessor method returns a reference to the live list, not a snapshot. Therefore any modification you make to the returned list will be present inside the JAXB object. This is why there is
	 * not a <CODE>set</CODE> method for the inclNote property.
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
     *    getInclNote().add(newItem);
     * </pre>
	 * <p>
	 * Objects of the following type(s) are allowed in the list {@link AdditionalInformation1 }
	 */
	public List<AdditionalInformation1> getInclNote() {
		if (inclNote == null) {
			inclNote = new ArrayList<AdditionalInformation1>();
		}
		return this.inclNote;
	}

	/**
	 * Gets the value of the supplierAccId property.
	 * @return possible object is {@link String }
	 */
	public String getSupplierAccId() {
		return supplierAccId;
	}

	/**
	 * Sets the value of the supplierAccId property.
	 * @param value allowed object is {@link String }
	 */
	public void setSupplierAccId(String value) {
		this.supplierAccId = value;
	}

	/**
	 * Gets the value of the matchRef property.
	 * @return possible object is {@link String }
	 */
	public String getMatchRef() {
		return matchRef;
	}

	/**
	 * Sets the value of the matchRef property.
	 * @param value allowed object is {@link String }
	 */
	public void setMatchRef(String value) {
		this.matchRef = value;
	}

	/**
	 * Gets the value of the reconciliationRate property.
	 * @return possible object is {@link String }
	 */
	public String getReconciliationRate() {
		return reconciliationRate;
	}

	/**
	 * Sets the value of the reconciliationRate property.
	 * @param value allowed object is {@link String }
	 */
	public void setReconciliationRate(String value) {
		this.reconciliationRate = value;
	}

	/**
	 * Gets the value of the matchType property.
	 * @return possible object is {@link String }
	 */
	public String getMatchType() {
		return matchType;
	}

	/**
	 * Sets the value of the matchType property.
	 * @param value allowed object is {@link String }
	 */
	public void setMatchType(String value) {
		this.matchType = value;
	}

	/**
	 * Gets the value of the matchStatus property.
	 * @return possible object is {@link String }
	 */
	public String getMatchStatus() {
		return matchStatus;
	}

	/**
	 * Sets the value of the matchStatus property.
	 * @param value allowed object is {@link String }
	 */
	public void setMatchStatus(String value) {
		this.matchStatus = value;
	}

	/**
	 * Gets the value of the matchRemarks property.
	 * @return possible object is {@link String }
	 */
	public String getMatchRemarks() {
		return matchRemarks;
	}

	/**
	 * Sets the value of the matchRemarks property.
	 * @param value allowed object is {@link String }
	 */
	public void setMatchRemarks(String value) {
		this.matchRemarks = value;
	}

}
