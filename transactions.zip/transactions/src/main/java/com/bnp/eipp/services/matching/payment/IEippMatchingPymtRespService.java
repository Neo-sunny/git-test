/****************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14 Oct 2012
 * 
 * Purpose: Eipp Matching Payment Response Message Service
 * 
 * Change History: 
 * Date                       	Author                                  Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 14 Oct 2012              	Prabu P                      			Initial Version
 ********************************************************************************************************************************/

package com.bnp.eipp.services.matching.payment;

import com.bnp.eipp.services.vo.common.EippMessageVO;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.txns.common.message.AbstractMsg;

public interface IEippMatchingPymtRespService {

	/**
	 * Process Eipp Payment Response Message
	 * @param message
	 * @param detailsVO
	 */
	void processMessage(AbstractMsg<?> message, FileDetailsVO detailsVO);
	
	/**
	 * Generate matching recon reminder message
	 * @param EippMessageVO
	 */
	void generateReconReminderMessage(EippMessageVO eippMsgVO);

}
