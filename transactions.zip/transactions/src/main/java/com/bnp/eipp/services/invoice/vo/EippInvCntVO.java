/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 3, 2012
 * 
 * Purpose:      EippInvCntVO.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 3, 2012       Oracle Financial Services Software Ltd                  Initial Version  
************************************************************************************************************************************************************/

package com.bnp.eipp.services.invoice.vo;

import java.util.ArrayList;
import java.util.List;

public class EippInvCntVO extends EippTransactionVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4634642428124936794L;

	private List<EippInvoiceVO> invoiceList;

	private List<EippCreditNoteVO> cntList;

	// Added for matching & recon Rel 3.0
	private List<String> refList;

	public EippInvCntVO() {
		setInvoiceList(new ArrayList<EippInvoiceVO>());
		setCntList(new ArrayList<EippCreditNoteVO>());
	}

	/**
	 * @param invoiceList the invoiceList to set
	 */
	public void setInvoiceList(List<EippInvoiceVO> invoiceList) {
		this.invoiceList = invoiceList;
	}

	/**
	 * @return the invoiceList
	 */
	public List<EippInvoiceVO> getInvoiceList() {
		return invoiceList;
	}

	/**
	 * @param cntList the cntList to set
	 */
	public void setCntList(List<EippCreditNoteVO> cntList) {
		this.cntList = cntList;
	}

	/**
	 * @return the cntList
	 */
	public List<EippCreditNoteVO> getCntList() {
		return cntList;
	}
	
	/**
	 * @return the refList
	 */
	public List<String> getRefList() {
		return refList;
	}

	/**
	 * @param refList the refList to set
	 */
	public void setRefList(List<String> refList) {
		this.refList = refList;
	}
	
}
