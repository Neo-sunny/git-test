/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Jun 20, 2012
 * 
 * Purpose:      IAutoPaymentRuleDao.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Jun 20, 2012       		Sandhya R 										Initial Version  
 * 22 OCT 2012				Sadhana A V						                Rel 3.0 - Message monitoring changes
************************************************************************************************************************************************************/

package com.bnp.eipp.services.pymt.dao;

import java.util.List;

import com.bnp.eipp.services.vo.payment.EippPaymentMsgDetailVO;
import com.bnp.eipp.services.vo.payment.EippPaymentMsgVO;
import com.bnp.eipp.services.vo.payment.EippPymtVO;
import com.bnp.eipp.services.vo.payment.PaymentInitiateAccountVO;
import com.bnp.scm.services.common.dao.IAbstractCommonDao;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.bnp.scm.services.txns.common.vo.MessageVO;

/**
 * The Interface IEippPaymentMessageDao.
 */
public interface IEippPaymentMessageDao extends IAbstractCommonDao<EippPaymentMsgDetailVO>{
	
	List<EippPaymentMsgDetailVO> getBuySuppPaymentsByGroup(EippPaymentMsgDetailVO inputVO) throws BNPApplicationException;
	
	List<EippPaymentMsgDetailVO> getBuyMktPlcPaymentsByGroup(EippPaymentMsgDetailVO inputVO) throws BNPApplicationException;
	
	List<EippPaymentMsgDetailVO> getMktPlcSuppPaymentsByGroup(EippPaymentMsgDetailVO inputVO) throws BNPApplicationException;
	
	List<EippPaymentMsgDetailVO> getPymtsForBuySup(EippPaymentMsgDetailVO buySup) throws BNPApplicationException;
	
	List<EippPaymentMsgDetailVO> getPymtsForBuyMktPlc(EippPaymentMsgDetailVO buyMktPlc) throws BNPApplicationException;
	
	List<EippPaymentMsgDetailVO> getPymtsForMktPlcSupp(EippPaymentMsgDetailVO mktPlcSupp) throws BNPApplicationException;
	
	List<EippPaymentMsgDetailVO> getSplitDetailsList(EippPaymentMsgDetailVO allPayBuySupp) throws BNPApplicationException;
	
	PaymentInitiateAccountVO getDebitAccountDetails(EippPaymentMsgDetailVO getBuyDet) throws BNPApplicationException;

	PaymentInitiateAccountVO getCreditAccountDetails(EippPaymentMsgDetailVO allPayBuySupp) throws BNPApplicationException;
	
	void updateBatchIdInMaster(EippPaymentMsgDetailVO creDeb) throws BNPApplicationException;

	MessageVO insertMessageInfo(MessageVO messageVO) throws BNPApplicationException;
	
	String getBatchId() throws BNPApplicationException;
	
	String getMessageId() throws BNPApplicationException;
	
	void updatePaymentMessageFlag(EippPaymentMsgVO pymtMsgVO)throws BNPApplicationException;
	
	void insertPymtAudit(EippPaymentMsgDetailVO singPymtMsgVo) throws BNPApplicationException;
	
	List<EippPaymentMsgDetailVO> allReGenList(String msgRef) throws BNPApplicationException;
	
	int updateTxnTimestamp(EippPaymentMsgVO eippPymtMsgVO) throws BNPApplicationException;
	
	void resetProcessingFlag(EippPaymentMsgVO eippPymtMsgVO) throws BNPApplicationException;
	
	void insertMessageDetails(MessageVO messageVO) throws BNPApplicationException;

	void insertMessageInfoInHistory(MessageVO messageVO) throws BNPApplicationException;
	
	void updateMessageInfoStatus(String msgId, String status, String errorDesc) throws BNPApplicationException;
	
	List<NameValueVO> getTagValueBasedonCountry(String string) throws BNPApplicationException;
	
	List<EippPaymentMsgDetailVO> getBilldatas(String inputBranch) throws BNPApplicationException;

	PaymentInitiateAccountVO pymtProcCreBillingDets(EippPaymentMsgDetailVO payAccVo) throws BNPApplicationException;

	PaymentInitiateAccountVO pymtProcInfoPopulationForBuyr(EippPaymentMsgDetailVO singPayAccVo) throws BNPApplicationException;

	PaymentInitiateAccountVO pymtProcInfoForSuplr(EippPaymentMsgDetailVO singPayAccVo) throws BNPApplicationException;

	PaymentInitiateAccountVO pymtProcInfoForMktPlc(EippPaymentMsgDetailVO singPayAccVo) throws BNPApplicationException;
	
	void updateBillingMessageFlag(EippPaymentMsgVO eippPayMsgVO) throws BNPApplicationException;

	EippPaymentMsgDetailVO getBillingDetails(String msgRef) throws BNPApplicationException;
	
	/**
	 * Gets the payment details. This will be used during payment response status update
	 *
	 * @param pymtRefNo the pymtRefNo
	 * @return the payment details
	 * @throws BNPApplicationException the bNP application exception
	 */
	EippPaymentMsgDetailVO getPaymentDetails(String pymtRefNo) throws BNPApplicationException;
	
	/**
	 * Check the given split payment exist.
	 *
	 * @param pymtVO the pymt vo
	 * @return the boolean
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean checkSplitPymtExist(EippPymtVO pymtVO) throws BNPApplicationException;
	
	/**
	 * Update payment status in split.
	 *
	 * @param eippPayMsgDtlVO the eipp pay msg dtl vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void updatePaymentStatusInSplit(EippPaymentMsgDetailVO eippPayMsgDtlVO) throws BNPApplicationException;
	
	/**
	 * Check all split pymt success.
	 *
	 * @param eippPayMsgDtlVO the eipp pay msg dtl vo
	 * @return true, if successful
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean checkAllSplitPymtSuccess(EippPaymentMsgDetailVO eippPayMsgDtlVO) throws BNPApplicationException;
	
	/**
	 * Update payment status in master.
	 *
	 * @param eippPayMsgDtlVO the eipp pay msg dtl vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void updatePaymentStatusInMaster(EippPaymentMsgDetailVO eippPayMsgDtlVO) throws BNPApplicationException;
	
	/**
	 * Gets the all billing det for update.
	 *
	 * @param pymtRefNo the pymt ref no
	 * @return the all billing det for update
	 * @throws BNPApplicationException the bNP application exception
	 */
	EippPaymentMsgDetailVO getBillingDetForUpdate(String pymtRefNo) throws BNPApplicationException;
	
	/**
	 * Update billing status in master.
	 *
	 * @param eippPayMsgDtlVO the eipp pay msg dtl vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void updateBillingStatusInMaster(EippPaymentMsgDetailVO eippPayMsgDtlVO) throws BNPApplicationException;
	
	/**
	 * Check any split pymt failed.
	 *
	 * @param eippPayMsgDtlVO the eipp pay msg dtl vo
	 * @return true, if successful
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean checkAnySplitPymtFailed(EippPaymentMsgDetailVO eippPayMsgDtlVO) throws BNPApplicationException;
}
