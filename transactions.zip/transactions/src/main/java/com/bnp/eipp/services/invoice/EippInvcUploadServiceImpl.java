/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   02 Feb 12  
 * 
 * Purpose:      EIPP Invoice Upload Service Implementation 
 * 
 * Change History: 
 * Date                                                  Author                                                        Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 02 Feb 12                        Oracle Financial Services Software Ltd                                    Initial Version 
 * 12-July 2012                    Oracle Financial Services Software Ltd            EIPP Phase II - Cancel Invoice MFU
 * 21-August 2012                   Vignesh B										Attachment Processing
 * 14 Sep 2012						Prabakaran S															  Modified for EIPP Inv Attachments  
 * 26 Sep 2012						Dinesh D															  	  Modified for MFU - EIPP Disputes   
 * 11 Oct  2012						Merdith S															  	  ST-6894 - Fix for handling payment prepared Invoices
 * 17 Oct 2012			  		  Aarthi T																  Added for Rel 3.0 Matching and Reconcilation Events
 *  19 Oct 2012					  Merdith S 										ST - 6984 To allow disputing of Line Itm based on LinkorgforEIPP data
 *  23 Oct 2012					Merdith 											ST Defect 6824                              
 ********************************************************************************************************************************************************************/
package com.bnp.eipp.services.invoice;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnp.eipp.services.invoice.bindingvo.Document;
import com.bnp.eipp.services.invoice.bindingvo.ErrorMessage;
import com.bnp.eipp.services.invoice.bindingvo.ErrorMessages;
import com.bnp.eipp.services.invoice.bindingvo.File;
import com.bnp.eipp.services.invoice.bindingvo.FinancialCreditNoteV01;
import com.bnp.eipp.services.invoice.bindingvo.FinancialInvoiceV01;
import com.bnp.eipp.services.invoice.bindingvo.Header;
import com.bnp.eipp.services.invoice.dao.IEippInvcUploadDAO;
import com.bnp.eipp.services.invoice.group.EippCntGroupProcessor;
import com.bnp.eipp.services.invoice.group.EippInvGroupProcessor;
import com.bnp.eipp.services.invoice.group.EippMatchCntGroupProcessor;
import com.bnp.eipp.services.invoice.group.EippMatchDocGroupProcessor;
import com.bnp.eipp.services.invoice.vo.EippCreditNoteVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceBusinessRulesVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.txns.util.file.EippFileUtil;
import com.bnp.eipp.services.vo.dispute.DisputeVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.IEventLogService;
import com.bnp.scm.services.common.ILocaleMessageLoaderService;
import com.bnp.scm.services.common.TransactionServiceImpl;
import com.bnp.scm.services.common.dao.IEventLogDAO;
import com.bnp.scm.services.common.dao.SqlMapClientWrapper;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.invoice.IInvoiceUploadService;
import com.bnp.scm.services.invoice.dao.IInvoiceUploadDAO;
import com.bnp.scm.services.invoice.vo.InvalidFileDataVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;
import com.bnp.scm.services.txns.common.message.AbstractMsg;
import com.bnp.scm.services.txns.util.PropertiesReader;
import com.bnp.scm.services.txns.util.xml.XmlBinding;


@Component
public class EippInvcUploadServiceImpl extends TransactionServiceImpl implements IEippInvcUploadService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(EippInvcUploadServiceImpl.class);
	 
	 @Autowired
	 private IInvoiceUploadService invoiceService;
	 @Autowired 
	 private IInvoiceUploadDAO invoiceUploadDAO;
	 @Autowired 
	 private IEippReleaseService eippReleaseService;
	 @Autowired 
	 private BNPPropertyLoaderConfigurer propertyLoader;
	 @Autowired 
	 private IEventLogService eventLogService;

	 @Autowired
	 private IEippInvcUploadDAO eippInvcUploadDao;
	 
	 @Autowired
	 private BeanFactory beanFactory;
	 
	 @Autowired 
	 private IEventLogDAO eventLogDAO;
	 
	 @Autowired 
	 private ILocaleMessageLoaderService msgService;

	
	 /**
		 * @Name : processMatchDocDetails
		 * @Description : This method is used to process the matching doc details
		 * @param detailsVO
		 * @throws BNPApplicationException
		 */
		@Override
		@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
		public Map<String, List<EippInvCntVO>> processMatchDocDetails(AbstractMsg<?> message, 
								FileDetailsVO detailsVO) throws BNPApplicationException {
		
			Map<String, List<EippInvCntVO>> eippInvCntMap = new HashMap<String, List<EippInvCntVO>>();
			List<EippInvCntVO> validInvalidList = new ArrayList<EippInvCntVO>();
			List<EippInvCntVO> validDataList = new ArrayList<EippInvCntVO>();
			List<InvalidFileDataVO> invalidDataList = new ArrayList<InvalidFileDataVO>();
			try {
				
				com.bnp.eipp.services.matching.document.bindingvo.File file = ((com.bnp.eipp.services.matching.document.bindingvo.File)message.getBody());
				EippInvCntVO eippInvCntVO = new EippInvCntVO();
				EippInvCntVO dataVO = new EippInvCntVO();
				if (((List<com.bnp.eipp.services.matching.document.bindingvo.FinancialInvoiceV01>)file.getDocument().getFinInvc()) != null && 
						((List<com.bnp.eipp.services.matching.document.bindingvo.FinancialInvoiceV01>)file.getDocument().getFinInvc()).size() > 0) {
					EippMatchDocGroupProcessor <EippInvoiceVO> invGroupProcessor =
						beanFactory.getBean("eippMatchDocGroupProcessor", EippMatchDocGroupProcessor.class);
					invGroupProcessor.setObjectList(((List<com.bnp.eipp.services.matching.document.bindingvo.FinancialInvoiceV01>)file.getDocument().getFinInvc()));
					invGroupProcessor.setDetailsVO(detailsVO);
					invGroupProcessor.processAndValidateData();
					dataVO.setInvoiceList(invGroupProcessor.getDataList());
					eippInvCntVO.setInvoiceList(invGroupProcessor.getValidInvalidList());
					invalidDataList.addAll(invGroupProcessor.getErrorDataList());
				}
				if(((List<com.bnp.eipp.services.matching.document.bindingvo.FinancialCreditNoteV01>)file.getDocument().getFinCrNt()) != null && 
						((List<com.bnp.eipp.services.matching.document.bindingvo.FinancialCreditNoteV01>)file.getDocument().getFinCrNt()).size() > 0) {
					EippMatchCntGroupProcessor<EippCreditNoteVO> cntGroupProcessor =
						beanFactory.getBean("eippMatchCntGroupProcessor", EippMatchCntGroupProcessor.class);
					cntGroupProcessor.setObjectList(((List<com.bnp.eipp.services.matching.document.bindingvo.FinancialCreditNoteV01>)file.getDocument().getFinCrNt()));
					//cntGroupProcessor.setObjectList(file.getDocument().getFinCrNt());
					cntGroupProcessor.setDetailsVO(detailsVO);
					cntGroupProcessor.processAndValidateData();
					dataVO.setCntList(cntGroupProcessor.getDataList());
					eippInvCntVO.setCntList(cntGroupProcessor.getValidInvalidList());
					invalidDataList.addAll(cntGroupProcessor.getErrorDataList());
				}
				if (!dataVO.getInvoiceList().isEmpty() || !dataVO.getCntList().isEmpty()) {
					validDataList.add(dataVO);
				}
				
				validInvalidList.add(eippInvCntVO);
				
				//Added for 2253
				updateReprocessFlag(invalidDataList,detailsVO);
				if (!invalidDataList.isEmpty()) {
					invoiceUploadDAO.insertInvalidDetails(invalidDataList);
				}
				
				
				if (validDataList == null || validDataList.isEmpty()) {
					detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.validation.fail"));
					detailsVO.setFileStatus(StatusConstants.VALIDATION_FAILED);
					detailsVO.setErrorCode(Integer.toString(ErrorConstants.NO_VALID_EIPP_RECORDS_FOUND));
				} else {
					eippInvcUploadDao.uploadFile(validDataList, detailsVO);
					if(detailsVO.getInstrumentType() != null
							&& detailsVO.getInstrumentType().trim().equalsIgnoreCase(BNPConstants.MATCH_RECON_INS_TYPE)){ //R5.0 - Sonar Fix - Feb21
						eippInvcUploadDao.insertMatchHistDtlsFromTrans(detailsVO.getFileId());
					}
					else{
						eippInvcUploadDao.insertHistoryDetailsFromTrans(detailsVO.getFileId());
					}
					
					boolean canUploadPartialFile = eippInvcUploadDao.canUploadPartialFile(detailsVO.getSenderOrgId());	
					if (!invalidDataList.isEmpty()) {
						if (!canUploadPartialFile) {
							detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.validation.fail"));
							detailsVO.setFileStatus(StatusConstants.VALIDATION_FAILED);
							detailsVO.setErrorDesc("Business validation failed for few records and " +
									"partial upload is not supported for the Organization " + detailsVO.getSenderOrgId());
							detailsVO.setCurrentUserId(BNPConstants.SYSTEM);
							eippReleaseService.deleteFile(detailsVO);
							validDataList.clear();
						}
					} 
				}
				invoiceService.updateFileStatus(detailsVO);
				eippInvCntMap.put(BNPConstants.VALID_INVOICE_LST, validDataList);
				eippInvCntMap.put(BNPConstants.VALID_AND_INVALID_INVOICE_LST, validInvalidList);
			} catch (BNPApplicationException exception) {
				detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.validation.fail"));
				detailsVO.setErrorCode(Integer.toString(exception.getErrorCode()));
				detailsVO.setErrorDesc(exception.getErrorMessage());
				invoiceService.updateFileStatus(detailsVO);
				throw exception;
			}
			return eippInvCntMap;
		}

	 
	/**
	 * @Name : processInvoiceDetails
	 * @Description : This method is used to process the invoice details
	 * @param detailsVO
	 * @throws BNPApplicationException
	 */
	@Override
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	public Map<String, List<EippInvCntVO>> processInvoiceDetails(AbstractMessage<?> message, 
							FileDetailsVO detailsVO) throws BNPApplicationException {
	
		Map<String, List<EippInvCntVO>> eippInvCntMap = new HashMap<String, List<EippInvCntVO>>();
		List<EippInvCntVO> validInvalidList = new ArrayList<EippInvCntVO>();
		List<EippInvCntVO> validDataList = new ArrayList<EippInvCntVO>();
		List<InvalidFileDataVO> invalidDataList = new ArrayList<InvalidFileDataVO>();
		
		boolean canUploadPartialFile = eippInvcUploadDao.canUploadPartialFile(detailsVO.getSenderOrgId());
		try {
			
			File file = ((File)message.getBody());
			
			EippInvCntVO eippInvCntVO = new EippInvCntVO();
			EippInvCntVO dataVO = new EippInvCntVO();
			if (file.getDocument().getFinInvc() != null && 
					file.getDocument().getFinInvc().size() > 0) {
				EippInvGroupProcessor<EippInvoiceVO> invGroupProcessor =
					beanFactory.getBean("eippInvGroupProcessor", EippInvGroupProcessor.class);
				invGroupProcessor.setObjectList(file.getDocument().getFinInvc());
				invGroupProcessor.setDetailsVO(detailsVO);
				invGroupProcessor.processAndValidateData();
				dataVO.setInvoiceList(invGroupProcessor.getDataList());
				eippInvCntVO.setInvoiceList(invGroupProcessor.getValidInvalidList());
				invalidDataList.addAll(invGroupProcessor.getErrorDataList());
				
			}
			if(file.getDocument().getFinCrNt() != null && 
					file.getDocument().getFinCrNt().size() > 0) {
				EippCntGroupProcessor<EippCreditNoteVO> cntGroupProcessor =
					beanFactory.getBean("eippCntGroupProcessor", EippCntGroupProcessor.class);
				cntGroupProcessor.setObjectList(file.getDocument().getFinCrNt());
				cntGroupProcessor.setDetailsVO(detailsVO);
				cntGroupProcessor.processAndValidateData();
				dataVO.setCntList(cntGroupProcessor.getDataList());
				eippInvCntVO.setCntList(cntGroupProcessor.getValidInvalidList());
				invalidDataList.addAll(cntGroupProcessor.getErrorDataList());
			}
			if (!dataVO.getInvoiceList().isEmpty() || !dataVO.getCntList().isEmpty()) {
				validDataList.add(dataVO);
			}
			
			validInvalidList.add(eippInvCntVO);
			
			//Added for 2253
			updateReprocessFlag(invalidDataList,detailsVO);
			if (!invalidDataList.isEmpty()) {
				invoiceUploadDAO.insertInvalidDetails(invalidDataList);
			}
			
			
			if (validDataList == null || validDataList.isEmpty()) {
				detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.validation.fail"));
				detailsVO.setFileStatus(StatusConstants.VALIDATION_FAILED);
				detailsVO.setErrorCode(Integer.toString(ErrorConstants.NO_VALID_EIPP_RECORDS_FOUND));
				//detailsVO.setErrorDesc("No valid Invoice/ Credit Note records found");
//				Commenting this API, as the same event would be triggered while generating func ack in release File API QC - 1904
//				invoiceService.triggerEventLog(detailsVO, "FAILURE");				
			} else {
				eippInvcUploadDao.uploadFile(validDataList, detailsVO);
				//Attachment Processing
				saveAttachments(detailsVO.getFileId(), FILE_TYPE.INVOICE, detailsVO.getUserId());
				//Attachment Processing
				eippInvcUploadDao.insertHistoryDetailsFromTrans(detailsVO.getFileId());
				
				if (!invalidDataList.isEmpty()) {
					
					if (!canUploadPartialFile) {
						detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.validation.fail"));
						detailsVO.setFileStatus(StatusConstants.VALIDATION_FAILED);
						detailsVO.setErrorDesc("Business validation failed for few records and " +
								"partial upload is not supported for the Organization " + detailsVO.getSenderOrgId());
						detailsVO.setCurrentUserId(BNPConstants.SYSTEM);
						eippReleaseService.deleteFile(detailsVO);
//						Commenting this API, as the same event would be triggered while generating func ack in release File API						
//						invoiceService.triggerEventLog(detailsVO,"FAILURE");
						validDataList.clear();
					}
				} 
				
			}
			invoiceService.updateFileStatus(detailsVO);
			eippInvCntMap.put(BNPConstants.VALID_INVOICE_LST, validDataList);
			eippInvCntMap.put(BNPConstants.VALID_AND_INVALID_INVOICE_LST, validInvalidList);
		} catch (BNPApplicationException exception) {
			detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.validation.fail"));
			detailsVO.setErrorCode(Integer.toString(exception.getErrorCode()));
			detailsVO.setErrorDesc(exception.getErrorMessage());
			invoiceService.updateFileStatus(detailsVO);
			throw exception;
		}
		return eippInvCntMap;
	}
	
	@Override
	public void updateReprocessFlag(List<InvalidFileDataVO> invalidDataList, FileDetailsVO detailsVO) throws BNPApplicationException {
		if(detailsVO.getReprocessFlag() != null && BNPConstants.YES.equals(detailsVO.getReprocessFlag())){
			eippInvcUploadDao.updateReprocessFlagForOldRejectedRecords(detailsVO);
		}
	}
	
	
	public void releaseMatchDocFile(AbstractMsg<?> message, 
			FileDetailsVO detailsVO, 
			Map<String, List<EippInvCntVO>> eippInvCntMap) 
							throws BNPApplicationException {
		List<EippInvCntVO> validPymtList = null;
		//List<EippInvCntVO> validInvalidPaymentLst = null; //R5.0 - Sonar Fix - Feb21
	try {
			if(eippInvCntMap != null && eippInvCntMap.size() > 0) {
				validPymtList = eippInvCntMap.get(BNPConstants.VALID_INVOICE_LST);
			//	validInvalidPaymentLst = eippInvCntMap.get(BNPConstants.VALID_AND_INVALID_INVOICE_LST); //R5.0 - Sonar Fix - Feb21
			}
	
			boolean isAutoReleaseEnabled = false;
			if (validPymtList != null && !validPymtList.isEmpty()) {
				isAutoReleaseEnabled = eippReleaseService.insertIntoMasterIfAutoAuthorizationEnabled(detailsVO);
				// Commented due to avoid repeating the same logic
				/*
				if(detailsVO.getInstrumentType() != null && 
						detailsVO.getInstrumentType().trim().equalsIgnoreCase(BNPConstants.MATCH_RECON_INS_TYPE)){
					isAutoReleaseEnabled = eippReleaseService.insertIntoMasterIfAutoAuthorizationEnabled(detailsVO);
					if(isAutoReleaseEnabled){
						String errorCode = eippInvcUploadDao.matchRecords(detailsVO.getFileId());
						if(errorCode != null){
							throw new BNPApplicationException(Integer.parseInt(errorCode));
						}else{
							if(errorCode == null){
								invoiceService.triggerMatchReconcilationEventLog(detailsVO, BNPConstants.AUTO_MATCH_EVENT);
								eippReleaseService.sendMailForAutoMatch(detailsVO);
							}
						}
						
					}
				}else{
					isAutoReleaseEnabled = eippReleaseService.insertIntoMasterIfAutoAuthorizationEnabled(detailsVO);
				}*/
			}else {
				invoiceService.triggerEventLog(detailsVO,"FUNC_ERROR");
			}
			if(isAutoReleaseEnabled){
				detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.release.ok"));
				invoiceService.updateFileStatus(detailsVO);
				invoiceService.triggerEventLog(detailsVO,"RELEASE");
			} else {
				if (validPymtList != null && !validPymtList.isEmpty()) {
					detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.release.pending"));
					invoiceService.updateFileStatus(detailsVO);
					invoiceService.triggerEventLog(detailsVO,"SUCCESS");
				}
			}
		} catch (BNPApplicationException e) {
			if (validPymtList != null && !validPymtList.isEmpty()) {
				detailsVO.setErrorCode(Integer.toString(e.getErrorCode()));
				detailsVO.setErrorDesc("Error during file release...");
				detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.release.pending"));
				invoiceService.updateFileStatus(detailsVO);
			}
		} catch (Exception e) {
			if (validPymtList != null && !validPymtList.isEmpty()) {
				detailsVO.setErrorDesc(e.getMessage());
				detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.release.pending"));
				invoiceService.updateFileStatus(detailsVO);
			}
		}
	}
	

	public void releaseFile(AbstractMessage<?> message, 
				FileDetailsVO detailsVO, 
				Map<String, List<EippInvCntVO>> eippInvCntMap) 
								throws BNPApplicationException {
			List<EippInvCntVO> validPymtList = null;
			List<EippInvCntVO> validInvalidPaymentLst = null;
		try {
			
			if(eippInvCntMap != null && eippInvCntMap.size() > 0) {
				validPymtList = eippInvCntMap.get(BNPConstants.VALID_INVOICE_LST);
				validInvalidPaymentLst = eippInvCntMap.get(BNPConstants.VALID_AND_INVALID_INVOICE_LST); 
			}

			boolean isAutoReleaseEnabled = false;
			if (validPymtList != null && !validPymtList.isEmpty()) {
				isAutoReleaseEnabled = eippReleaseService.insertIntoMasterIfAutoAuthorizationEnabled(detailsVO);
//				Commenting this below snippet - QC 2216
				/*try {
					createTechAck(message, detailsVO, validInvalidPaymentLst);
				} catch (Exception techAckErr){
						LOGGER.info("Error in creating the technical ack "+techAckErr.getMessage());
				}*/
			}else {
				createFuncAck(message, detailsVO, validInvalidPaymentLst, isAutoReleaseEnabled);
				invoiceService.triggerEventLog(detailsVO,"FUNC_ERROR");
			}
			
			if(isAutoReleaseEnabled){
				try{
					createFuncAck(message, detailsVO, validInvalidPaymentLst, isAutoReleaseEnabled);
				}catch(Exception funcAckErr){
					//FO 7.0 Fortify Issue Fix
					LOGGER.error("Error in creating the functional ack "+funcAckErr.getMessage());
				}
				detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.release.ok"));
				detailsVO.setErrorCode(String.valueOf(ErrorConstants.FILE_RELEASE_SUCCESS));
				invoiceService.updateFileStatus(detailsVO);
				invoiceService.triggerEventLog(detailsVO,"RELEASE");
			} else {
				if (validPymtList != null && !validPymtList.isEmpty()) {
					detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.release.pending"));
					invoiceService.updateFileStatus(detailsVO);
					invoiceService.triggerEventLog(detailsVO,"SUCCESS");
				}
			}
		} catch (BNPApplicationException e) {
			if (validPymtList != null && !validPymtList.isEmpty()) {
				detailsVO.setErrorCode(Integer.toString(e.getErrorCode()));
				detailsVO.setErrorDesc("Error during file release...");
				detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.release.pending"));
				invoiceService.updateFileStatus(detailsVO);
			}
		} catch (Exception e) {
			if (validPymtList != null && !validPymtList.isEmpty()) {
				detailsVO.setErrorDesc(e.getMessage());
				detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.release.pending"));
				invoiceService.updateFileStatus(detailsVO);
			}
		}
	}
	

	/**
	 * @Name : createTechAck
	 * @Description : This method is used to create technical acknowledgment
	 * @param detailsVO
	 * @throws BNPApplicationException
	 */
	@Override
	public void createTechAck(AbstractMessage<?> message, FileDetailsVO detailsVO, List<EippInvCntVO> transList) throws BNPApplicationException {
		if(transList != null){
			((File)message.getBody()).setDocument(EippFileUtil.mapVOToJAXB(transList));
			message.setHeader(getAckHeader((Header)message.getHeader(), "TECH_ACK", detailsVO));			
		}
		message.marshallMessage(message.getProperties());
		String xmlContent = message.getXmlMessage();
		XmlBinding.validate(xmlContent, PropertiesReader.getProperty("message.invcnt.xsd.path"));
		//commented since tech ack is removed
		//detailsVO.setTechAckData(xmlContent.getBytes());
		//updateFileUploadDetails(detailsVO);
	}

	@Override
	public void createFuncAck(AbstractMessage<?> message, FileDetailsVO detailsVO, List<EippInvCntVO> transList, boolean isAutoReleaseEnabled) throws BNPApplicationException {
		if(transList != null){
			((File)message.getBody()).setDocument(EippFileUtil.mapVOToJAXB(transList));
		}
		if(transList != null && isAutoReleaseEnabled) {
			setReleasedStatus(((File)message.getBody()).getDocument());
		}
		message.setHeader(getAckHeader((Header)message.getHeader(), "FUNC_ACK",detailsVO));
		message.marshallMessage(message.getProperties());
		String xmlContent = message.getXmlMessage();
		XmlBinding.validate(xmlContent, PropertiesReader.getProperty("message.invcnt.xsd.path"));
		detailsVO.setFuncAckData(xmlContent.getBytes());
		detailsVO.setEippfuncAck(BNPConstants.EIPP_FILE_FUNC_ACK);
	}
	
	private ErrorMessages getErrorMessages(List<InvalidFileDataVO> lstInvalidFileDataVO, String refNo) {
		ErrorMessages errmsgs = null;
		ErrorMessage errmsg = null;
		for(InvalidFileDataVO invalidFileDataVO :lstInvalidFileDataVO) {
			if(refNo.equals(invalidFileDataVO.getRefNo())){
				if(errmsgs == null) {
					errmsgs = new ErrorMessages();
				}
				errmsg = new ErrorMessage();
				errmsg.setErrorCode(invalidFileDataVO.getErrorMessage());
				errmsg.setErrorDesc(msgService.getMessage("en_US", Integer.parseInt(invalidFileDataVO.getErrorMessage())));
				errmsgs.getErrMsg().add(errmsg);
			}
		}
		return errmsgs;
	}
	
	private String getStatus(boolean bInvalid) {
		String status = BNPConstants.VALIDATION_FAILED;
		if(!bInvalid) {
			status = BNPConstants.RELEASED;
		}
		return status;
	}
	
	private boolean isInvalid(ErrorMessages errmsgs) {
		boolean isInValid = false;
		if(errmsgs != null && errmsgs.getErrMsg() != null && errmsgs.getErrMsg().size() > 0) {
			isInValid = true;
		}
		else {
			isInValid = false;
		}
		return isInValid;
	}
	
	public void createFuncAck(AbstractMessage message, 
			FileDetailsVO detailsVO) throws BNPApplicationException {
		byte[] data  = eippInvcUploadDao.getAttachmentData(detailsVO.getFileId());
		
		if (data != null) {
			detailsVO.setFileData(data);
			message.setHeader(getAckHeader((Header)message.getHeader(), "FUNC_ACK",detailsVO));
			message.marshallMessage(message.getProperties());
			String xmlContent = message.getXmlMessage();
			XmlBinding.validate(xmlContent, PropertiesReader.getProperty("message.type.invoiceupload"));
			detailsVO.setFuncAckData(xmlContent.getBytes());
			detailsVO.setEippfuncAck(BNPConstants.EIPP_INV_ATTACHMENT_FUNC_ACK);
			detailsVO.setUserId(detailsVO.getReleasedBy()); 
			invoiceService.triggerEventLog(detailsVO,"RELEASE");
		}
	}
	
	/**
	 * @Name : createFuncAck
	 * @Description : This method is used to create functional acknowledgment
	 * @param detailsVO
	 * @throws BNPApplicationException
	 */
	@Override
	public void createFuncAck(FileDetailsVO detailsVO, String releasedBy) throws BNPApplicationException {
		EippInvCntMessage invCntMsg = new EippInvCntMessage();
		String msgType = propertyLoader.getValue("message.type.eipp");
		invCntMsg.extractMessage(new String(eventLogDAO.getMsgData(detailsVO.getFileId()+"", msgType.trim())));
		List<InvalidFileDataVO> lstInvalidFileDataVO = invoiceUploadDAO.getRejectedRecords(detailsVO.getFileId());
		boolean bInvalid; 
			for(FinancialInvoiceV01 invoice : ((File)invCntMsg.getBody()).getDocument().getFinInvc()){
				bInvalid = false;
				invoice.setErrMsgs(getErrorMessages(lstInvalidFileDataVO, invoice.getInvcHdr().getId()));
				bInvalid = isInvalid(invoice.getErrMsgs()) || bInvalid;
				invoice.setStatus(getStatus(bInvalid));
			}
			for(FinancialCreditNoteV01 creditnote : ((File)invCntMsg.getBody()).getDocument().getFinCrNt()) {
				bInvalid = false;
				creditnote.setErrMsgs(getErrorMessages(lstInvalidFileDataVO, creditnote.getCrNtHdr().getId()));
				bInvalid = isInvalid(creditnote.getErrMsgs()) || bInvalid;
				creditnote.setStatus(getStatus(bInvalid));
			}
		createFuncAck(invCntMsg, detailsVO, null,true);
		detailsVO.setUserId(releasedBy); 
		invoiceService.triggerEventLog(detailsVO,"RELEASE");
	}
	
	/**
	 * Get Acknowledgement Header
	 * @param header
	 * @param ackType
	 * @return Header
	 * @throws BNPApplicationException 
	 */
	private Header getAckHeader(Header header, String ackType, FileDetailsVO detailsVO) throws BNPApplicationException {
		header.setOrgin(PropertiesReader.getProperty("txns.label.fo"));
		header.setDestination(PropertiesReader.getProperty("txns.label.erp"));
		if(ackType != null && ackType.equals("FUNC_ACK")){
			header.setMsgFileType(PropertiesReader.getProperty("message.type.funcack.eipp"));
			detailsVO.setFuncAckId(eventLogService.getMessageId());
			header.setSrcRefId(detailsVO.getFuncAckId());
		}
		else if(ackType != null && ackType.equals("TECH_ACK")){
			header.setMsgFileType(PropertiesReader.getProperty("message.type.techack"));
			detailsVO.setTechAckId(eventLogService.getMessageId());
			header.setSrcRefId(detailsVO.getTechAckId());
		}
		header.setMsgFileSts(PropertiesReader.getProperty("message.type.na"));
		header.setSendTime(new GregorianCalendar());
		return header;
	}

	private void setReleasedStatus(Document document) {
		
		if (document.getFinInvc() != null && !document.getFinInvc().isEmpty()) {
			for (FinancialInvoiceV01 invoice : document.getFinInvc()) {
				if(BNPConstants.VALIDATION_SUCCESS.equals(invoice.getStatus())) {
					invoice.setStatus(BNPConstants.RELEASED);
				}
			}
			
		} 
		if (document.getFinCrNt() != null && !document.getFinCrNt().isEmpty()) {
			for (FinancialCreditNoteV01 creditNote : document.getFinCrNt()) {
				if(BNPConstants.VALIDATION_SUCCESS.equals(creditNote.getStatus())) {
					creditNote.setStatus(BNPConstants.RELEASED);
				}
			}
			
		} 
	}
	
	@Override
	public void release(FileDetailsVO detailsVO,
			AbstractMessage<?> invoiceMessage,
			Map<String, List<EippInvCntVO>> eippInvCntMap)
			throws BNPApplicationException {
		try {
			releaseFile(invoiceMessage, detailsVO,
					eippInvCntMap);

		} catch (BNPApplicationException exception) {
			detailsVO.setFileUploadStatus(propertyLoader
				.getValue("file.status.validation.fail"));
			detailsVO.setErrorCode(Integer.toString(exception.getErrorCode()));
			detailsVO.setErrorDesc(exception.getErrorMessage());
			invoiceService.updateFileStatus(detailsVO);
			throw exception;
		}
	}
	
	@Override
	public void release(FileDetailsVO detailsVO,
			AbstractMsg<?> invoiceMessage,
			Map<String, List<EippInvCntVO>> eippInvCntMap)
			throws BNPApplicationException {
		try {
			releaseMatchDocFile(invoiceMessage, detailsVO,
					eippInvCntMap);
		} catch (BNPApplicationException exception) {
			detailsVO.setFileUploadStatus(propertyLoader
				.getValue("file.status.validation.fail"));
			detailsVO.setErrorCode(Integer.toString(exception.getErrorCode()));
			detailsVO.setErrorDesc(exception.getErrorMessage());
			invoiceService.updateFileStatus(detailsVO);
			throw exception;
		}
	}
	
	
	@Override
	public Map<String, List<EippInvCntVO>> process(
			FileDetailsVO detailsVO, AbstractMsg<?> invoiceMessage) throws BNPApplicationException {
		Map<String, List<EippInvCntVO>> eippInvCntMap = null;
		try{
			eippInvCntMap = processMatchDocDetails(invoiceMessage, detailsVO);
		} catch (BNPApplicationException exception) {
			
			detailsVO.setFileUploadStatus(propertyLoader
					.getValue("file.status.validation.fail"));
			detailsVO.setErrorCode(Integer.toString(exception.getErrorCode()));
			detailsVO.setErrorDesc(exception.getErrorMessage());
			invoiceService.updateFileStatus(detailsVO);
			invoiceService.triggerEventLog(detailsVO,"FAILURE");
			throw exception;
		}
		return eippInvCntMap;
	}

	@Override
	public Map<String, List<EippInvCntVO>> process(
			FileDetailsVO detailsVO, AbstractMessage<?> invoiceMessage) throws BNPApplicationException {
		Map<String, List<EippInvCntVO>> eippInvCntMap = null;
		
		try{

			eippInvCntMap =processInvoiceDetails(invoiceMessage, detailsVO);

		} catch (BNPApplicationException exception) {
			
			detailsVO.setFileUploadStatus(propertyLoader
					.getValue("file.status.validation.fail"));
			detailsVO.setErrorCode(Integer.toString(exception.getErrorCode()));
			detailsVO.setErrorDesc(exception.getErrorMessage());
			invoiceService.updateFileStatus(detailsVO);
			invoiceService.triggerEventLog(detailsVO,"FAILURE");
			throw exception;
		}
		return eippInvCntMap;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvcUploadService#canUploadPartialFile(java.lang.String)
	 */
	@Override
	public boolean canUploadPartialFile(String orgId) throws BNPApplicationException {
		return eippInvcUploadDao.canUploadPartialFile(orgId);
	}
	
	@Override
	public List<String> getCustomerOrgId(String billType, String custERPId) throws BNPApplicationException{
		return eippInvcUploadDao.getCustomerOrgId(billType, custERPId);
	}
	
	@Override
	public String getModelTypeForOrganization(String orgId) throws BNPApplicationException {
		return eippInvcUploadDao.getModelTypeForOrganization(orgId);
	}
	
	@Override
	public String getTimezoneForOrganization(String orgId) throws BNPApplicationException{
		return eippInvcUploadDao.getTimezoneForOrganization(orgId);
	}
	
	@Override
	public List<String> getCounterPartyOrgId(String orgId, String billType,String cntpERPId) throws BNPApplicationException {
		return eippInvcUploadDao.getCounterPartyOrgId(orgId, billType, cntpERPId);
	}
	
	@Override
	public boolean isBuyerSellerLinked(String custOrgId,String cntpOrgId,String billType) throws BNPApplicationException {
		return eippInvcUploadDao.isBuyerSellerLinked(custOrgId, cntpOrgId, billType);
	}
	
	@Override
	public String getOrgTypeForOrganization(String orgId) throws BNPApplicationException {
		return eippInvcUploadDao.getOrgTypeForOrganization(orgId);
	}
	
	@Override
	public boolean isBillThroughMarketPlace(String billType, String marketPlaceOrgId) throws BNPApplicationException {
		return eippInvcUploadDao.isBillThroughMarketPlace(billType, marketPlaceOrgId);
	}
	
	@Override
	public boolean isCustomerOrgLinkedToMarketPlace(String orgId, String marketPlaceOrgId) throws BNPApplicationException {
//		eippInvcUploadDao.checkMarketPlaceIsParentOrg(orgId, marketPlaceOrgId);
		return eippInvcUploadDao.isCustomerOrgLinkedToMarketPlace(orgId, marketPlaceOrgId);
	}
	
	@Override
	public boolean isBuyerSellerLinkedToMarketPlace(String custOrgId,String cntpOrgId,String billType,String marketPlaceOrgId) throws BNPApplicationException {
		return eippInvcUploadDao.isBuyerSellerLinkedToMarketPlace(custOrgId, cntpOrgId, billType, marketPlaceOrgId);
	}
	
	@Override
	public String getRuleTypeForDiscountRuleId(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException {
		return eippInvcUploadDao.getRuleTypeForDiscountRuleId(eippInvoiceVO);
	}
	
	@Override
	public int isInvoiceAvailableInSystem(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException {
		Properties params= new Properties();
		params.put("invRefNo", eippInvoiceVO.getInvRefNo());
		params.put("supplierOrgId", eippInvoiceVO.getSupplierOrgId());
		params.put("buyerOrgId", eippInvoiceVO.getBuyerOrgId());
		params.put("billType", eippInvoiceVO.getBillType());
		params.put("issueDate", eippInvoiceVO.getIssueDate());
		params.put("refDate", eippInvoiceVO.getRefDate());
		
		return eippInvcUploadDao.isInvoiceAvailableInSystem(params);
	}
	
	@Override
	public EippInvoiceBusinessRulesVO getBusinessProcessingRules(String custOrgId,String cntpOrgId,String billType) throws BNPApplicationException {
		if(eippInvcUploadDao.isDefaultBusinessRuleEnabled(custOrgId, cntpOrgId, billType)) {
			return eippInvcUploadDao.getBusinessProcessingRulesFromBillType(custOrgId, cntpOrgId, billType);
		} else{
			return eippInvcUploadDao.getBusinessProcessingRulesFromLinkOrg(custOrgId, cntpOrgId, billType);
		}
	}
	
	/**
	 * This API gets the list of invoices in Ascending order based on File uploaded date/time
	 * @param invoiceVO
	 * @throws BNPApplicationException
	 */
	@Override
	public List<EippInvoiceVO> getInvoiceListForValidation(EippInvoiceVO invoiceVO) throws BNPApplicationException{
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("invRefNo", invoiceVO.getRefNo());
		params.put("supplierOrgId", invoiceVO.getSupplierOrgId());
		params.put("buyerOrgId", invoiceVO.getBuyerOrgId());
		params.put("billType", invoiceVO.getBillType());
		params.put("issueDate", invoiceVO.getIssueDate());
		params.put("invRefDate", invoiceVO.getRefDate());
		
		return eippInvcUploadDao.getInvoiceListForValidation(params);
	}
	
	/**
	 * This API validates multiple invoices and returns the valid Invoice ID for processing  
	 * If all invoices are invalid, returns the latest invoices ID 
	 * @param invoiceList
	 * @throws BNPApplicationException
	 */
	@Override
	public EippInvoiceVO getInvoiceForProcessing(List<EippInvoiceVO> invoiceList) throws BNPApplicationException{

		EippInvoiceVO invoice = null;
		for (EippInvoiceVO invoiceVO : invoiceList) {
			invoice = invoiceVO;
			if (invoice.getInvStatus() != null && 
				(!invoice.getInvStatus().equals(StatusConstants.INVOICE_CANCELLED) && 
				!invoice.getInvStatus().equals(StatusConstants.CANCEL_PENDING_EIPP_APPROVAL) && 
				!invoice.getInvStatus().equals(StatusConstants.EIPP_INV_STATUS_CLOSED))
				&&(invoice.getBlockedAmt().equals(BigDecimal.ZERO) && invoice.getPaidAmt().equals(BigDecimal.ZERO)) // ST-6894 - Fix for handling Payment Prepared Invoice
				&& invoice.getUtilizedCNCount() == 0){
						break;
					
				}
			
		}
		return invoice;
	}

	@Override
	public SqlMapClientWrapper getDao() {
		return (SqlMapClientWrapper) invoiceUploadDAO;
	}
	@Override
	public List<EippInvoiceVO> getInvoiceListForValidation(Map<String, Object> params) throws BNPApplicationException{
		return eippInvcUploadDao.getInvoiceListForValidation(params);
	}


	@Override
	public boolean chkValidInvLIfromLinkOrg(DisputeVO invLIVO) {
		LOGGER.debug(" Error in chkValidInvLIfromLinkOrg Entered" );
		return  eippInvcUploadDao.chkValidInvLIfromLinkOrg(invLIVO);
	}


	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.IEippInvcUploadService#chkValidInvLIfromLinkOrg(com.bnp.eipp.services.invoice.vo.EippInvoiceVO)
	 */
/*	@Override
	public boolean chkValidInvLIfromLinkOrg(EippInvoiceVO invLIVO) {
		LOGGER.debug(" Error in chkValidInvLIfromLinkOrg Entered" );
			return  eippInvcUploadDao.chkValidInvLIfromLinkOrg(invLIVO);
		
	}*/
}
