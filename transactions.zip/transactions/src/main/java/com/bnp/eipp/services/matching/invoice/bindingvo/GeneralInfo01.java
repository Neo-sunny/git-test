package com.bnp.eipp.services.matching.invoice.bindingvo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for GeneralInfo01 complex type.
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GeneralInfo01">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BuyerID" type="{}Max35Text"/>
 *         &lt;element name="BuyerERPID" type="{}Max32Text" minOccurs="0"/>
 *         &lt;element name="BuyerOrgName" type="{}Max105Text"/>
 *         &lt;element name="SupplierID" type="{}Max35Text"/>
 *         &lt;element name="SupplierERPID" type="{}Max32Text" minOccurs="0"/>
 *         &lt;element name="SupplierOrgName" type="{}Max105Text"/>
 *         &lt;element name="BillType" type="{}ExternalDocumentType1Code"/>
 *         &lt;element name="MatchFileTypeID" type="{}Max35Text" minOccurs="0"/>
 *         &lt;element name="SrcFileTypeID" type="{}Max35Text" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GeneralInfo01", propOrder = { "buyerID", "buyerERPID", "buyerOrgName", "supplierID", "supplierERPID",
		"supplierOrgName", "billType", "matchFileTypeID", "srcFileTypeID" })
public class GeneralInfo01 {

	@XmlElement(name = "BuyerID", required = true)
	protected String buyerID;

	@XmlElement(name = "BuyerERPID")
	protected String buyerERPID;

	@XmlElement(name = "BuyerOrgName", required = true)
	protected String buyerOrgName;

	@XmlElement(name = "SupplierID", required = true)
	protected String supplierID;

	@XmlElement(name = "SupplierERPID")
	protected String supplierERPID;

	@XmlElement(name = "SupplierOrgName", required = true)
	protected String supplierOrgName;

	@XmlElement(name = "BillType", required = true)
	protected String billType;

	@XmlElement(name = "MatchFileTypeID")
	protected String matchFileTypeID;

	@XmlElement(name = "SrcFileTypeID")
	protected String srcFileTypeID;

	/**
	 * Gets the value of the buyerID property.
	 * @return possible object is {@link String }
	 */
	public String getBuyerID() {
		return buyerID;
	}

	/**
	 * Sets the value of the buyerID property.
	 * @param value allowed object is {@link String }
	 */
	public void setBuyerID(String value) {
		this.buyerID = value;
	}

	/**
	 * Gets the value of the buyerERPID property.
	 * @return possible object is {@link String }
	 */
	public String getBuyerERPID() {
		return buyerERPID;
	}

	/**
	 * Sets the value of the buyerERPID property.
	 * @param value allowed object is {@link String }
	 */
	public void setBuyerERPID(String value) {
		this.buyerERPID = value;
	}

	/**
	 * Gets the value of the buyerOrgName property.
	 * @return possible object is {@link String }
	 */
	public String getBuyerOrgName() {
		return buyerOrgName;
	}

	/**
	 * Sets the value of the buyerOrgName property.
	 * @param value allowed object is {@link String }
	 */
	public void setBuyerOrgName(String value) {
		this.buyerOrgName = value;
	}

	/**
	 * Gets the value of the supplierID property.
	 * @return possible object is {@link String }
	 */
	public String getSupplierID() {
		return supplierID;
	}

	/**
	 * Sets the value of the supplierID property.
	 * @param value allowed object is {@link String }
	 */
	public void setSupplierID(String value) {
		this.supplierID = value;
	}

	/**
	 * Gets the value of the supplierERPID property.
	 * @return possible object is {@link String }
	 */
	public String getSupplierERPID() {
		return supplierERPID;
	}

	/**
	 * Sets the value of the supplierERPID property.
	 * @param value allowed object is {@link String }
	 */
	public void setSupplierERPID(String value) {
		this.supplierERPID = value;
	}

	/**
	 * Gets the value of the supplierOrgName property.
	 * @return possible object is {@link String }
	 */
	public String getSupplierOrgName() {
		return supplierOrgName;
	}

	/**
	 * Sets the value of the supplierOrgName property.
	 * @param value allowed object is {@link String }
	 */
	public void setSupplierOrgName(String value) {
		this.supplierOrgName = value;
	}

	/**
	 * Gets the value of the billType property.
	 * @return possible object is {@link String }
	 */
	public String getBillType() {
		return billType;
	}

	/**
	 * Sets the value of the billType property.
	 * @param value allowed object is {@link String }
	 */
	public void setBillType(String value) {
		this.billType = value;
	}

	/**
	 * Gets the value of the matchFileTypeID property.
	 * @return possible object is {@link String }
	 */
	public String getMatchFileTypeID() {
		return matchFileTypeID;
	}

	/**
	 * Sets the value of the matchFileTypeID property.
	 * @param value allowed object is {@link String }
	 */
	public void setMatchFileTypeID(String value) {
		this.matchFileTypeID = value;
	}

	/**
	 * Gets the value of the srcFileTypeID property.
	 * @return possible object is {@link String }
	 */
	public String getSrcFileTypeID() {
		return srcFileTypeID;
	}

	/**
	 * Sets the value of the srcFileTypeID property.
	 * @param value allowed object is {@link String }
	 */
	public void setSrcFileTypeID(String value) {
		this.srcFileTypeID = value;
	}

}
