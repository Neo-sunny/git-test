/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 2, 201210:52:10 AM
 * 
 * Purpose:      EippTransactionVO.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 2, 201210:52:10 AM        Oracle Financial Services Software Ltd                  Initial Version
 * Mar 2, 201210:52:10 AM        Oracle Financial Services Software Ltd                  EIPP Dept Approval Additions  
 * 12-July 2012                  Oracle Financial Services Software Ltd                  EIPP Phase II - Cancel Invoice MFU
 * 07 Sept 2012					 Sandhya R												 R3.0 Auto Payment Prep Changes
 * 24 Sep 2012					Aarthi T											    Release File Inq - Rel 3.0 Matching and Reconcilation
************************************************************************************************************************************************************/

package com.bnp.eipp.services.invoice.vo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.bnp.scm.services.common.vo.AbstractVO;
import com.bnp.scm.services.invoice.vo.InvalidFileDataVO;

public class EippTransactionVO extends AbstractVO {

	private static final long serialVersionUID = -5964322879873885652L;
	
	/** The buyer map id. */
	private String buyerMapId;
	
	/** The supplier map id. */
	private String supplierMapId;
	
	/** The mkt place map id. */
	private String mktPlaceMapId;
	
	/** The disable check box. */
	private boolean disableCheckBox;
	
	/** The credit note amt. */
	private BigDecimal creditNoteAmt;
	
	// Start - Ganga - MFU Change
	/** The buyer org name. */
	private String buyerOrgName;
	
	private String supplierOrgName;
	
	private byte[] supplierOrgImage;
	
	private String buyerErpId;
	
	private String supplierErpId;
	
	private String forAttention;
	
	private String billType;
	
	private Date issueDate;
	
	private Date issueDateFrom;
	
	private Date issueDateTo;
	
	private Date refDate;
	
	private String ccyCode;
	
	private BigDecimal taxAmount;
	
	private String taxAmtCcy;
	
	private BigDecimal taxRate;
	
	private String poNumber;
	
	private int lineItemCnt;
	
	private long fileId;
	
	private int fractionalDigits;
	
	private String restrictCheck;
	
	private AddressVO shipToAddr;
	
	private AddressVO billToAddr;
	
	private List<InvalidFileDataVO> invalidFileDataList;
	
	private List<EippInvCntLineItemVO> lineItemList;
	
	private List<EippCustFieldsVO> custFields;
	
	private String note;
	
	private int customCount;
	
	private String status;
	
	private String remarks;
	
	private String mktPlacePymtMthdId;
	
	private String supplierPymtMthdID;
	
	private String pymtStatus;
	
	private String marketPlaceOrgId;
	
	private String billTypeName;
	
	private List<EippCustFieldsVO> matchReconCustFields; // Added for Rel 3.0 Matching and Reconcilation
	
	private String srcFileTypeId;
	
	private String matchFileTypeId;
	
	/** The match Type. */
	private String matchType; 
	
	private String matchRefNo;
	
	private String shipToAddrStr;
	
	private String billToAddrStr;
	
	private String remitToAddrStr;
	
	private String processThruMatchRecon; // Added for Rel 3.0 Matching and Reconcilation
	
	public EippTransactionVO() {
		invalidFileDataList = new ArrayList<InvalidFileDataVO>();
		lineItemList = new ArrayList<EippInvCntLineItemVO>();
		custFields= new ArrayList<EippCustFieldsVO>();
		matchReconCustFields = new ArrayList<EippCustFieldsVO>(); // Added for Rel 3.0 Matching and Reconcilation
	}

	

	/**
	 * @return the buyerErpId
	 */
	public String getBuyerErpId() {
		return buyerErpId;
	}

	/**
	 * @param buyerErpId the buyerErpId to set
	 */
	public void setBuyerErpId(String buyerErpId) {
		this.buyerErpId = buyerErpId;
	}

	/**
	 * @return the supplierErpId
	 */
	public String getSupplierErpId() {
		return supplierErpId;
	}

	/**
	 * @param supplierErpId the supplierErpId to set
	 */
	public void setSupplierErpId(String supplierErpId) {
		this.supplierErpId = supplierErpId;
	}

	/**
	 * @return the billType
	 */
	public String getBillType() {
		return billType;
	}

	/**
	 * @param billType the billType to set
	 */
	public void setBillType(String billType) {
		this.billType = billType;
	}


	/**
	 * @return the issueDate
	 */
	public Date getIssueDate() {
		return issueDate;
	}

	/**
	 * @param issueDate the issueDate to set
	 */
	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}

	/**
	 * @return the refDate
	 */
	public Date getRefDate() {
		return refDate;
	}

	/**
	 * @param refDate the refDate to set
	 */
	public void setRefDate(Date refDate) {
		this.refDate = refDate;
	}

	/**
	 * @return the ccyCode
	 */
	public String getCcyCode() {
		return ccyCode;
	}

	/**
	 * @param ccyCode the ccyCode to set
	 */
	public void setCcyCode(String ccyCode) {
		this.ccyCode = ccyCode;
	}

	/**
	 * @return the taxAmount
	 */
	public BigDecimal getTaxAmount() {
		return taxAmount;
	}

	/**
	 * @param taxAmount the taxAmount to set
	 */
	public void setTaxAmount(BigDecimal taxAmount) {
		this.taxAmount = taxAmount;
	}

	/**
	 * @return the taxRate
	 */
	public BigDecimal getTaxRate() {
		return taxRate;
	}

	/**
	 * @param taxRate the taxRate to set
	 */
	public void setTaxRate(BigDecimal taxRate) {
		this.taxRate = taxRate;
	}

	/**
	 * @return the poNumber
	 */
	public String getPoNumber() {
		return poNumber;
	}

	/**
	 * @param poNumber the poNumber to set
	 */
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	/**
	 * @return the lineItemCnt
	 */
	public int getLineItemCnt() {
		return lineItemCnt;
	}

	/**
	 * @param lineItemCnt the lineItemCnt to set
	 */
	public void setLineItemCnt(int lineItemCnt) {
		this.lineItemCnt = lineItemCnt;
	}

	/**
	 * @return the invalidFileDataList
	 */
	public List<InvalidFileDataVO> getInvalidFileDataList() {
		return invalidFileDataList;
	}

	/**
	 * @param invalidFileDataList the invalidFileDataList to set
	 */
	public void setInvalidFileDataList(List<InvalidFileDataVO> invalidFileDataList) {
		this.invalidFileDataList = invalidFileDataList;
	}

	/**
	 * @param fileId the fileId to set
	 */
	public void setFileId(long fileId) {
		this.fileId = fileId;
	}

	/**
	 * @return the fileId
	 */
	public long getFileId() {
		return fileId;
	}

	/**
	 * @param lineItemList the lineItemList to set
	 */
	public void setLineItemList(List<EippInvCntLineItemVO> lineItemList) {
		this.lineItemList = lineItemList;
	}

	/**
	 * @return the lineItemList
	 */
	public List<EippInvCntLineItemVO> getLineItemList() {
		return lineItemList;
	}

	/**
	 * @param fractionalDigits the fractionalDigits to set
	 */
	public void setFractionalDigits(int fractionalDigits) {
		this.fractionalDigits = fractionalDigits;
	}

	/**
	 * @return the fractionalDigits
	 */
	public int getFractionalDigits() {
		return fractionalDigits;
	}

	public String getTransactionType() {
		return "";
	}
	
	public String getRefNo() {
		return "";
	}
	
	public String toDataString() {
		return "";
	}
	
	
	public void addToInvalidDataList(InvalidFileDataVO invalidData) {
		invalidFileDataList.add(invalidData);
	}

	/**
	 * @param custFields the custFields to set
	 */
	public void setCustFields(List<EippCustFieldsVO> custFields) {
		this.custFields = custFields;
	}

	/**
	 * @return the custFields
	 */
	public List<EippCustFieldsVO> getCustFields() {
		return custFields;
	}

	/**
	 * @param taxAmtCcy the taxAmtCcy to set
	 */
	public void setTaxAmtCcy(String taxAmtCcy) {
		this.taxAmtCcy = taxAmtCcy;
	}

	/**
	 * @return the taxAmtCcy
	 */
	public String getTaxAmtCcy() {
		return taxAmtCcy;
	}

	public String getBuyerOrgName() {
		return buyerOrgName;
	}

	public void setBuyerOrgName(String buyerOrgName) {
		this.buyerOrgName = buyerOrgName;
	}

	public String getSupplierOrgName() {
		return supplierOrgName;
	}

	public void setSupplierOrgName(String supplierOrgName) {
		this.supplierOrgName = supplierOrgName;
	}

	public byte[] getSupplierOrgImage() {
		return supplierOrgImage;
	}

	public void setSupplierOrgImage(byte[] supplierOrgImage) {
		this.supplierOrgImage = copyArray(supplierOrgImage);
	}

	public Date getIssueDateFrom() {
		return issueDateFrom;
	}

	public void setIssueDateFrom(Date issueDateFrom) {
		this.issueDateFrom = issueDateFrom;
	}

	public Date getIssueDateTo() {
		return issueDateTo;
	}

	public void setIssueDateTo(Date issueDateTo) {
		this.issueDateTo = issueDateTo;
	}

	/**
	 * @param forAttention the forAttention to set
	 */
	public void setForAttention(String forAttention) {
		this.forAttention = forAttention;
	}

	/**
	 * @return the forAttention
	 */
	public String getForAttention() {
		return forAttention;
	}

	/**
	 * @param restrictCheck the restrictCheck to set
	 */
	public void setRestrictCheck(String restrictCheck) {
		this.restrictCheck = restrictCheck;
	}

	/**
	 * @return the restrictCheck
	 */
	public String getRestrictCheck() {
		return restrictCheck;
	}

	/**
	 * @param shipToAddr the shipToAddr to set
	 */
	public void setShipToAddr(AddressVO shipToAddr) {
		this.shipToAddr = shipToAddr;
	}

	/**
	 * @return the shipToAddr
	 */
	public AddressVO getShipToAddr() {
		return shipToAddr;
	}

	/**
	 * @param billToAddr the billToAddr to set
	 */
	public void setBillToAddr(AddressVO billToAddr) {
		this.billToAddr = billToAddr;
	}

	/**
	 * @return the billToAddr
	 */
	public AddressVO getBillToAddr() {
		return billToAddr;
	}

	/**
	 * @param note the note to set
	 */
	public void setNote(String note) {
		this.note = note;
	}

	/**
	 * @return the note
	 */
	public String getNote() {
		return note;
	}

	public int getCustomCount() {
		return customCount;
	}

	public void setCustomCount(int customCount) {
		this.customCount = customCount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @param mktPlacePymtMthdId the mktPlacePymtMthdId to set
	 */
	public void setMktPlacePymtMthdId(String mktPlacePymtMthdId) {
		this.mktPlacePymtMthdId = mktPlacePymtMthdId;
	}

	/**
	 * @return the mktPlacePymtMthdId
	 */
	public String getMktPlacePymtMthdId() {
		return mktPlacePymtMthdId;
	}

	/**
	 * @param supplierPymtMthdID the supplierPymtMthdID to set
	 */
	public void setSupplierPymtMthdID(String supplierPymtMthdID) {
		this.supplierPymtMthdID = supplierPymtMthdID;
	}

	/**
	 * @return the supplierPymtMthdID
	 */
	public String getSupplierPymtMthdID() {
		return supplierPymtMthdID;
	}
	
	/**
	 * Sets the pymt status.
	 *
	 * @param pymtStatus the pymtStatus to set
	 */
	public void setPymtStatus(String pymtStatus) {
		this.pymtStatus = pymtStatus;
	}

	/**
	 * Gets the pymt status.
	 *
	 * @return the pymtStatus
	 */
	public String getPymtStatus() {
		return pymtStatus;
	}
	
	public String getMarketPlaceOrgId() {
		return marketPlaceOrgId;
	}

	public void setMarketPlaceOrgId(String marketPlaceOrgId) {
		this.marketPlaceOrgId = marketPlaceOrgId;
	}

	public String getBuyerMapId() {
		return buyerMapId;
	}

	public void setBuyerMapId(String buyerMapId) {
		this.buyerMapId = buyerMapId;
	}

	public String getSupplierMapId() {
		return supplierMapId;
	}

	public void setSupplierMapId(String supplierMapId) {
		this.supplierMapId = supplierMapId;
	}

	public String getMktPlaceMapId() {
		return mktPlaceMapId;
	}

	public void setMktPlaceMapId(String mktPlaceMapId) {
		this.mktPlaceMapId = mktPlaceMapId;
	}

	public boolean isDisableCheckBox() {
		return disableCheckBox;
	}

	public void setDisableCheckBox(boolean disableCheckBox) {
		this.disableCheckBox = disableCheckBox;
	}

	public BigDecimal getCreditNoteAmt() {
		return creditNoteAmt;
	}

	public void setCreditNoteAmt(BigDecimal creditNoteAmt) {
		this.creditNoteAmt = creditNoteAmt;
	}



	/**
	 * @param billTypeName the billTypeName to set
	 */
	public void setBillTypeName(String billTypeName) {
		this.billTypeName = billTypeName;
	}



	/**
	 * @return the billTypeName
	 */
	public String getBillTypeName() {
		return billTypeName;
	}
	
	// Start : Added for Rel 3.0 Matching and Reconcilation
	/**
	 * @return the matchReconCustFields
	 */
	public List<EippCustFieldsVO> getMatchReconCustFields() {
		return matchReconCustFields;
	}

	/**
	 * @param matchReconCustFields the matchReconCustFields to set
	 */
	public void setMatchReconCustFields(List<EippCustFieldsVO> matchReconCustFields) {
		this.matchReconCustFields = matchReconCustFields;
	}

	/**
	 * @return the processThruMatchRecon
	 */
	public String getProcessThruMatchRecon() {
		return processThruMatchRecon;
	}

	/**
	 * @param processThruMatchRecon the processThruMatchRecon to set
	 */
	public void setProcessThruMatchRecon(String processThruMatchRecon) {
		this.processThruMatchRecon = processThruMatchRecon;
	}
	

	/**
	 * @return the srcFileTypeId
	 */
	public String getSrcFileTypeId() {
		return srcFileTypeId;
	}

	/**
	 * @param srcFileTypeId the srcFileTypeId to set
	 */
	public void setSrcFileTypeId(String srcFileTypeId) {
		this.srcFileTypeId = srcFileTypeId;
	}

	/**
	 * @return the matchFileTypeId
	 */
	public String getMatchFileTypeId() {
		return matchFileTypeId;
	}

	/**
	 * @param matchFileTypeId the matchFileTypeId to set
	 */
	public void setMatchFileTypeId(String matchFileTypeId) {
		this.matchFileTypeId = matchFileTypeId;
	}

	/**
	 * @return the matchType
	 */
	public String getMatchType() {
		return matchType;
	}

	/**
	 * @param matchType the matchType to set
	 */
	public void setMatchType(String matchType) {
		this.matchType = matchType;
	}
	
	/**
	 * @return the matchRefNo
	 */
	public String getMatchRefNo() {
		return matchRefNo;
	}
	
	/**
	 * @param matchRefNo the matchRefNo to set
	 */
	public void setMatchRefNo(String matchRefNo) {
		this.matchRefNo = matchRefNo;
	}

	/**
	 * @return the shipToAddrStr
	 */
	public String getShipToAddrStr() {
		return shipToAddrStr;
	}

	/**
	 * @param shipToAddrStr the shipToAddrStr to set
	 */
	public void setShipToAddrStr(String shipToAddrStr) {
		this.shipToAddrStr = shipToAddrStr;
	}

	/**
	 * @return the billToAddrStr
	 */
	public String getBillToAddrStr() {
		return billToAddrStr;
	}

	/**
	 * @param billToAddrStr the billToAddrStr to set
	 */
	public void setBillToAddrStr(String billToAddrStr) {
		this.billToAddrStr = billToAddrStr;
	}

	/**
	 * @return the remitToAddrStr
	 */
	public String getRemitToAddrStr() {
		return remitToAddrStr;
	}

	/**
	 * @param remitToAddrStr the remitToAddrStr to set
	 */
	public void setRemitToAddrStr(String remitToAddrStr) {
		this.remitToAddrStr = remitToAddrStr;
	}

	// Ends : Added for Rel 3.0 Matching and Reconcilation

}
