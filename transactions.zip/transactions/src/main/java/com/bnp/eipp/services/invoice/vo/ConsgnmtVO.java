package com.bnp.eipp.services.invoice.vo;

import java.io.Serializable;
import java.util.List;

public class ConsgnmtVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private List<TransportMeansVO> transportMeans;

	public List<TransportMeansVO> getTransportMeans() {
		return transportMeans;
	}

	public void setTransportMeans(List<TransportMeansVO> transportMeans) {
		this.transportMeans = transportMeans;
	} 
}
