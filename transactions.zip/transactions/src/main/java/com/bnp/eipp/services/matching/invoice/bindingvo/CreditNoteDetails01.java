package com.bnp.eipp.services.matching.invoice.bindingvo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.bnp.scm.services.txns.util.calendar.DateAdapter;

/**
 * <p>
 * Java class for CreditNoteDetails01 complex type.
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CreditNoteDetails01">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CnRefNo" type="{}Max35Text"/>
 *         &lt;element name="LnkInvcNo" type="{}Max35Text" minOccurs="0"/>
 *         &lt;element name="EffDate" type="{}Date" minOccurs="0"/>
 *         &lt;element name="IssueDate" type="{}Date" minOccurs="0"/>
 *         &lt;element name="RefDate" type="{}Date" minOccurs="0"/>
 *         &lt;element name="Ccy" type="{}CurrencyCode" minOccurs="0"/>
 *         &lt;element name="CnAmt" type="{}CurrencyAndAmount_SimpleType" minOccurs="0"/>
 *         &lt;element name="TaxAmt" type="{}CurrencyAndAmount_SimpleType" minOccurs="0"/>
 *         &lt;element name="TaxRate" type="{}Rate_SimpleType" minOccurs="0"/>
 *         &lt;element name="PORefNo" type="{}Max35Text" minOccurs="0"/>
 *         &lt;element name="LineItems" type="{}LineItems01" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="ShipTo" type="{}Address01" minOccurs="0"/>
 *         &lt;element name="BillTo" type="{}Address01" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CreditNoteDetails01", propOrder = { "cnRefNo", "lnkInvcNo", "effDate", "issueDate", "refDate", "ccy",
		"cnAmt", "taxAmt", "taxRate", "poRefNo", "lineItems", "shipTo", "billTo" })
public class CreditNoteDetails01 {

	@XmlElement(name = "CnRefNo", required = true)
	protected String cnRefNo;

	@XmlElement(name = "LnkInvcNo")
	protected String lnkInvcNo;

	@XmlElement(name = "EffDate", type = String.class)
	@XmlJavaTypeAdapter(DateAdapter.class)
	protected Calendar effDate;

	@XmlElement(name = "IssueDate", type = String.class)
	@XmlJavaTypeAdapter(DateAdapter.class)
	protected Calendar issueDate;

	@XmlElement(name = "RefDate", type = String.class)
	@XmlJavaTypeAdapter(DateAdapter.class)
	protected Calendar refDate;

	@XmlElement(name = "Ccy")
	protected String ccy;

	@XmlElement(name = "CnAmt")
	protected BigDecimal cnAmt;

	@XmlElement(name = "TaxAmt")
	protected BigDecimal taxAmt;

	@XmlElement(name = "TaxRate")
	protected BigDecimal taxRate;

	@XmlElement(name = "PORefNo")
	protected String poRefNo;

	@XmlElement(name = "LineItems")
	protected List<LineItems01> lineItems;

	@XmlElement(name = "ShipTo")
	protected Address01 shipTo;

	@XmlElement(name = "BillTo")
	protected Address01 billTo;

	/**
	 * Gets the value of the cnRefNo property.
	 * @return possible object is {@link String }
	 */
	public String getCnRefNo() {
		return cnRefNo;
	}

	/**
	 * Sets the value of the cnRefNo property.
	 * @param value allowed object is {@link String }
	 */
	public void setCnRefNo(String value) {
		this.cnRefNo = value;
	}

	/**
	 * Gets the value of the lnkInvcNo property.
	 * @return possible object is {@link String }
	 */
	public String getLnkInvcNo() {
		return lnkInvcNo;
	}

	/**
	 * Sets the value of the lnkInvcNo property.
	 * @param value allowed object is {@link String }
	 */
	public void setLnkInvcNo(String value) {
		this.lnkInvcNo = value;
	}

	/**
	 * Gets the value of the effDate property.
	 * @return possible object is {@link String }
	 */
	public Calendar getEffDate() {
		return effDate;
	}

	/**
	 * Sets the value of the effDate property.
	 * @param value allowed object is {@link String }
	 */
	public void setEffDate(Calendar value) {
		this.effDate = value;
	}

	/**
	 * Gets the value of the issueDate property.
	 * @return possible object is {@link String }
	 */
	public Calendar getIssueDate() {
		return issueDate;
	}

	/**
	 * Sets the value of the issueDate property.
	 * @param value allowed object is {@link String }
	 */
	public void setIssueDate(Calendar value) {
		this.issueDate = value;
	}

	/**
	 * Gets the value of the refDate property.
	 * @return possible object is {@link String }
	 */
	public Calendar getRefDate() {
		return refDate;
	}

	/**
	 * Sets the value of the refDate property.
	 * @param value allowed object is {@link String }
	 */
	public void setRefDate(Calendar value) {
		this.refDate = value;
	}

	/**
	 * Gets the value of the ccy property.
	 * @return possible object is {@link String }
	 */
	public String getCcy() {
		return ccy;
	}

	/**
	 * Sets the value of the ccy property.
	 * @param value allowed object is {@link String }
	 */
	public void setCcy(String value) {
		this.ccy = value;
	}

	/**
	 * Gets the value of the cnAmt property.
	 * @return possible object is {@link BigDecimal }
	 */
	public BigDecimal getCnAmt() {
		return cnAmt;
	}

	/**
	 * Sets the value of the cnAmt property.
	 * @param value allowed object is {@link BigDecimal }
	 */
	public void setCnAmt(BigDecimal value) {
		this.cnAmt = value;
	}

	/**
	 * Gets the value of the taxAmt property.
	 * @return possible object is {@link BigDecimal }
	 */
	public BigDecimal getTaxAmt() {
		return taxAmt;
	}

	/**
	 * Sets the value of the taxAmt property.
	 * @param value allowed object is {@link BigDecimal }
	 */
	public void setTaxAmt(BigDecimal value) {
		this.taxAmt = value;
	}

	/**
	 * Gets the value of the taxRate property.
	 * @return possible object is {@link BigDecimal }
	 */
	public BigDecimal getTaxRate() {
		return taxRate;
	}

	/**
	 * Sets the value of the taxRate property.
	 * @param value allowed object is {@link BigDecimal }
	 */
	public void setTaxRate(BigDecimal value) {
		this.taxRate = value;
	}

	/**
	 * Gets the value of the poRefNo property.
	 * @return possible object is {@link String }
	 */
	public String getPORefNo() {
		return poRefNo;
	}

	/**
	 * Sets the value of the poRefNo property.
	 * @param value allowed object is {@link String }
	 */
	public void setPORefNo(String value) {
		this.poRefNo = value;
	}

	/**
	 * Gets the value of the lineItems property.
	 * <p>
	 * This accessor method returns a reference to the live list, not a snapshot. Therefore any modification you make to the returned list will be present inside the JAXB object. This is why there is
	 * not a <CODE>set</CODE> method for the lineItems property.
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
     *    getLineItems().add(newItem);
     * </pre>
	 * <p>
	 * Objects of the following type(s) are allowed in the list {@link LineItems01 }
	 */
	public List<LineItems01> getLineItems() {
		if (lineItems == null) {
			lineItems = new ArrayList<LineItems01>();
		}
		return this.lineItems;
	}

	/**
	 * Gets the value of the shipTo property.
	 * @return possible object is {@link Address01 }
	 */
	public Address01 getShipTo() {
		return shipTo;
	}

	/**
	 * Sets the value of the shipTo property.
	 * @param value allowed object is {@link Address01 }
	 */
	public void setShipTo(Address01 value) {
		this.shipTo = value;
	}

	/**
	 * Gets the value of the billTo property.
	 * @return possible object is {@link Address01 }
	 */
	public Address01 getBillTo() {
		return billTo;
	}

	/**
	 * Sets the value of the billTo property.
	 * @param value allowed object is {@link Address01 }
	 */
	public void setBillTo(Address01 value) {
		this.billTo = value;
	}

}
