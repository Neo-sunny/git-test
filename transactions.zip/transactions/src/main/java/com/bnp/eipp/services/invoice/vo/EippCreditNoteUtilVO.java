package com.bnp.eipp.services.invoice.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class EippCreditNoteUtilVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private long cntUtilId;
	
	private String cntRefNo;
	
	private Date cntIssueDate;
	
	private BigDecimal cntAmt;
	
	private BigDecimal cntUtilAmt;
	
	private BigDecimal invUtilAmt;
	
	private String invRefNo;
	
	private String cntStatus;
	
	private String cntType;
	
	private String isManual;

	public long getCntUtilId() {
		return cntUtilId;
	}

	public void setCntUtilId(long cntUtilId) {
		this.cntUtilId = cntUtilId;
	}

	public BigDecimal getCntAmt() {
		return cntAmt;
	}

	public void setCntAmt(BigDecimal cntAmt) {
		this.cntAmt = cntAmt;
	}

	public BigDecimal getCntUtilAmt() {
		return cntUtilAmt;
	}

	public void setCntUtilAmt(BigDecimal cntUtilAmt) {
		this.cntUtilAmt = cntUtilAmt;
	}

	public String getInvRefNo() {
		return invRefNo;
	}

	public void setInvRefNo(String invRefNo) {
		this.invRefNo = invRefNo;
	}

	public String getCntStatus() {
		return cntStatus;
	}

	public void setCntStatus(String cntStatus) {
		this.cntStatus = cntStatus;
	}

	public String getCntType() {
		return cntType;
	}

	public void setCntType(String cntType) {
		this.cntType = cntType;
	}

	public String getCntRefNo() {
		return cntRefNo;
	}

	public void setCntRefNo(String cntRefNo) {
		this.cntRefNo = cntRefNo;
	}

	public Date getCntIssueDate() {
		return cntIssueDate;
	}

	public void setCntIssueDate(Date cntIssueDate) {
		this.cntIssueDate = cntIssueDate;
	}

	/**
	 * @param invUtilAmt the invUtilAmt to set
	 */
	public void setInvUtilAmt(BigDecimal invUtilAmt) {
		this.invUtilAmt = invUtilAmt;
	}

	/**
	 * @return the invUtilAmt
	 */
	public BigDecimal getInvUtilAmt() {
		return invUtilAmt;
	}

	public String getIsManual() {
		return isManual;
	}

	public void setIsManual(String isManual) {
		this.isManual = isManual;
	}

}
