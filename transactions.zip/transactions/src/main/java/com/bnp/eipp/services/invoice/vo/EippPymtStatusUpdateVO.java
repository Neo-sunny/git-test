/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   23 August 2012
 * 
 * Purpose:      Eipp Payment Status update vo
 * 
 * Change History: 
 * Date                       Author                      version                      Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 23 Aug 2012                Reena S                 Initial Version
 * 26 Sep 2012				  Reena S												IUT Fix  
************************************************************************************************************************************************************/

package com.bnp.eipp.services.invoice.vo;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import com.bnp.scm.services.txns.util.calendar.DateAdapter;


enum PymtStatusEnum{
	 SUCCESS,
	 FAILED,
	 CANCELLED;
	 
	 public String value(){
		 return name();
	 }
	 
	 public static PymtStatusEnum fromValue(String v) {
	        return valueOf(v);
	 }
}
/**
 * The Class EippInvoiceCancelVO.
 */
public class EippPymtStatusUpdateVO extends EippTransactionVO {	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L; 

	private long pkId;
	
	private String accountId;
	
	private String customerRefNo;
	
	private String refNo;
	
	private Date feedBackDate;
	
	private BigDecimal pymtAmt;
	
	private String pymtCcy;
	
	private String feedBackStatus;
	
	private PymtStatusEnum newPymtStatus;
	
	private String recordStatus;
	
	private String addtlInfo;

	private String errorCode;
	private String errorDescription;
	private String senderOrgId;
	private boolean isSplitPymt;
	private String mpAccountId;
	private String existingPymtStatus;
	private boolean isBilling;
	private String paymentId;
	
	public String getPaymentId() {
		return paymentId;
	}



	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}



	private String userId;
	private String action;
	
	
	
	public String getUserId() {
		return userId;
	}



	public void setUserId(String userId) {
		this.userId = userId;
	}



	public String getAction() {
		return action;
	}



	public void setAction(String action) {
		this.action = action;
	}



	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.vo.EippTransactionVO#getTransactionType()
	 */
	public String getTransactionType() {
		return "PYMTSTATUSUPDT";
	}
	
	
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.vo.EippTransactionVO#toDataString()
	 */
	public String toDataString() {
		DateAdapter adapter = new DateAdapter();
		Calendar calendar = Calendar.getInstance();
		StringBuilder builder = new StringBuilder();
		builder.append(getTransactionType() + ",");
		builder.append(getBuyerOrgId()+ ",");
		builder.append(getAccountId()+ ",");
		builder.append(getCustomerRefNo()+ ",");
		builder.append(getRefNo() + ",");
		if(getFeedBackDate()!= null) {
			calendar.setTime(getFeedBackDate());
			builder.append( adapter.marshal(calendar)+ ",");
		} else {
			builder.append(",");
		}
		
		builder.append(getFeedBackStatus()+ ",");
		builder.append(getStatus());
	
		return builder.toString();
	}

	
	
	
	
	
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	/**
	 * @return the errorDescription
	 */
	public String getErrorDescription() {
		return errorDescription;
	}
	/**
	 * @param errorDescription the errorDescription to set
	 */
	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}
	public long getPkId() {
		return pkId;
	}
	public void setPkId(long pkId) {
		this.pkId = pkId;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getCustomerRefNo() {
		return customerRefNo;
	}
	public void setCustomerRefNo(String customerRefNo) {
		this.customerRefNo = customerRefNo;
	}
	public Date getFeedBackDate() {
		return feedBackDate;
	}
	public void setFeedBackDate(Date feedBackDate) {
		this.feedBackDate = feedBackDate;
	}	
	public String getPymtCcy() {
		return pymtCcy;
	}
	public void setPymtCcy(String pymtCcy) {
		this.pymtCcy = pymtCcy;
	}
	public String getFeedBackStatus() {
		if(null!=newPymtStatus){
			return newPymtStatus.value();
		}
		return feedBackStatus;
	}
	public void setFeedBackStatus(String feedBackStatus) {
		this.feedBackStatus = feedBackStatus;
	}
	public String getAddtlInfo() {
		return addtlInfo;
	}
	public void setAddtlInfo(String addtlInfo) {
		this.addtlInfo = addtlInfo;
	}



	public String getRecordStatus() {
		return recordStatus;
	}



	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}



	public String getRefNo() {
		return refNo;
	}



	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}



	public String getSenderOrgId() {
		return senderOrgId;
	}



	public void setSenderOrgId(String senderOrgId) {
		this.senderOrgId = senderOrgId;
	}



	public BigDecimal getPymtAmt() {
		return pymtAmt;
	}



	public void setPymtAmt(BigDecimal pymtAmt) {
		this.pymtAmt = pymtAmt;
	}



	public boolean isSplitPymt() {
		return isSplitPymt;
	}



	public void setSplitPymt(boolean isSplitPymt) {
		this.isSplitPymt = isSplitPymt;
	}



	public String getMpAccountId() {
		return mpAccountId;
	}



	public void setMpAccountId(String mpAccountId) {
		this.mpAccountId = mpAccountId;
	}



	public String getExistingPymtStatus() {
		return existingPymtStatus;
	}



	public void setExistingPymtStatus(String existingPymtStatus) {
		this.existingPymtStatus = existingPymtStatus;
	}



	public boolean isBilling() {
		return isBilling;
	}



	public void setBilling(boolean isBilling) {
		this.isBilling = isBilling;
	}



	public PymtStatusEnum getNewPymtStatus() {
		return newPymtStatus;
	}



	public void setNewPymtStatus(PymtStatusEnum newPymtStatus) {
		this.newPymtStatus = newPymtStatus;
	}
	
}
