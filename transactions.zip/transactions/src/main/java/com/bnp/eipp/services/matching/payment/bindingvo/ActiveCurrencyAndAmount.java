package com.bnp.eipp.services.matching.payment.bindingvo;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;

/**
 * <p>
 * Java class for ActiveCurrencyAndAmount complex type.
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ActiveCurrencyAndAmount">
 *   &lt;simpleContent>
 *     &lt;extension base="&lt;>ActiveCurrencyAndAmount_SimpleType">
 *       &lt;attribute name="Ccy" use="required" type="{}ActiveCurrencyCode" />
 *     &lt;/extension>
 *   &lt;/simpleContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ActiveCurrencyAndAmount", propOrder = { "value" })
public class ActiveCurrencyAndAmount {

	@XmlValue
	protected BigDecimal value;

	@XmlAttribute(name = "Ccy", required = true)
	protected String ccy;

	/**
	 * Gets the value of the value property.
	 * @return possible object is {@link BigDecimal }
	 */
	public BigDecimal getValue() {
		return value;
	}

	/**
	 * Sets the value of the value property.
	 * @param value allowed object is {@link BigDecimal }
	 */
	public void setValue(BigDecimal value) {
		this.value = value;
	}

	/**
	 * Gets the value of the ccy property.
	 * @return possible object is {@link String }
	 */
	public String getCcy() {
		return ccy;
	}

	/**
	 * Sets the value of the ccy property.
	 * @param value allowed object is {@link String }
	 */
	public void setCcy(String value) {
		this.ccy = value;
	}

}
