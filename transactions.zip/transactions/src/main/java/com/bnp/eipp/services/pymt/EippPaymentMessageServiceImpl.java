/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Jun 20, 2012
 * 
 * Purpose:      EippPaymentMessageServiceImpl.java
 * 
 * Change History: 
 * Date                       	Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Sep 29, 2012        			Stalin 						              Initial Version  
 * 22 OCT 2012					Sadhana A V						          Rel 3.0 - Message monitoring changes
 * Oct 30, 2012        			Arun G 						              ST Events Fix
 * 02 Nov 2012           		Arun G                                    ST events fix - 7118
************************************************************************************************************************************************************/

package com.bnp.eipp.services.pymt;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.invoice.vo.EippPymtStatusUpdateVO;
import com.bnp.eipp.services.payment.IEippPymtStatusUpdateServices;
import com.bnp.eipp.services.pymt.dao.IEippPaymentMessageDao;
import com.bnp.eipp.services.pymt.message.EIPPMessageFactory;
import com.bnp.eipp.services.pymt.message.PaymentInitiateMessage;
import com.bnp.eipp.services.vo.payment.EippPaymentMsgDetailVO;
import com.bnp.eipp.services.vo.payment.EippPaymentMsgVO;
import com.bnp.eipp.services.vo.payment.PaymentInitiateAccountVO;
import com.bnp.scm.services.common.AbstractServiceImpl;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.dao.IAbstractDAO;
import com.bnp.scm.services.common.event.EventType;
import com.bnp.scm.services.common.event.IEventDelegate;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.common.vo.EventLogVO;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.bnp.scm.services.txns.common.vo.MessageDetailVO;
import com.bnp.scm.services.txns.common.vo.MessageVO;
import com.bnp.scm.services.txns.util.PropertiesReader;

// TODO: Auto-generated Javadoc
/**
 * The Class EippPaymentMessageServiceImpl.
 */
@Component
public class EippPaymentMessageServiceImpl extends AbstractServiceImpl<EippPaymentMsgDetailVO> implements IEippPaymentMessageService{
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(EippPaymentMessageServiceImpl.class);
	
	/** The eipp payment message dao. */
	@Autowired
	private IEippPaymentMessageDao eippPaymentMessageDao;

	/** The message factory. */
	@Qualifier("bnpEIPPMessageFactory")
	private @Autowired EIPPMessageFactory messageFactory;
	
	/** The eipp payment message dao. */
	@Autowired
	private IEippPymtStatusUpdateServices eippPymtStatusUpdateServices;
	
	/** The property loader. */
	@Autowired
	private BNPPropertyLoaderConfigurer propertyLoader;

	/** The event delegate impl. */
	@Autowired
	private IEventDelegate eventDelegateImpl;

	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.AbstractServiceImpl#getDAO()
	 */
	@Override
	public IAbstractDAO<EippPaymentMsgDetailVO> getDAO() {
		return eippPaymentMessageDao;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.IEippPaymentMessageService#getCollectionMessages(java.lang.String[])
	 */
	@Override
	public List<Map<String, Object>> getCollectionMessages(String[] args) throws BNPApplicationException {

		EippPaymentMsgDetailVO inputVO = setInputArgs(args);
		
		List<EippPaymentMsgVO> allCollections = getCollectionsList(inputVO);
		//CSCDEV-2683 :976332:13112014 :START
		//LOGGER.info("allCollections::"+allCollections);
		//CSCDEV-2683 :976332:13112014 :END
		return processMessages(allCollections,"C");
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.IEippPaymentMessageService#getPaymentMessages(java.lang.String[])
	 */
	@Override
	public List<Map<String, Object>> getPaymentMessages(String[] args) throws BNPApplicationException {
		EippPaymentMsgDetailVO inputVO = setInputArgs(args);
		List<EippPaymentMsgVO> allPayments = getPaymentsList(inputVO);
		//CSCDEV-2683 :976332:13112014 :START
		//LOGGER.info("allPayments::"+allPayments);
		//CSCDEV-2683 :976332:13112014 :END
		return processMessages(allPayments,"P");
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.IEippPaymentMessageService#processMessages(java.util.List, java.lang.String)
	 */
	@Override
	public List<Map<String,Object>> processMessages(List<EippPaymentMsgVO> allCollections, String schType) throws BNPApplicationException{
		List<Map<String,Object>> collectionMessages = new ArrayList<Map<String,Object>>();
		try{
			for (EippPaymentMsgVO eippPayMsgVO : allCollections) {
				PaymentInitiateMessage collMessage = null;
				eippPayMsgVO.setSchType(schType);
				Map<String,Object> pmtMessage = new HashMap<String, Object>();
				try{
					collMessage = (PaymentInitiateMessage) messageFactory.getMessageInstance(
							propertyLoader.getValue("message.type.eipp.payment.request"));
					if(collMessage!=null){
						collMessage.constructMessage(eippPayMsgVO);
						//FO 7.0 Fortify Issue Fix
						/*if(collMessage.getXmlMessage()!=null){
							LOGGER.debug("Generated EIPP CollectionMessages XML::"+collMessage.getXmlMessage().toString());
						}*/
						insertPaymentMessageInfo(collMessage,eippPayMsgVO);
						pmtMessage.put("eIPPPaymentMessage", collMessage);
						pmtMessage.put("eIPPPaymentMessageVO", eippPayMsgVO);
						//976332 CSCDEV-2683 18-NOV-2014:START
						//LOGGER.debug("pmtMessage::"+pmtMessage);
						//976332 CSCDEV-2683 18-NOV-2014:END
						collectionMessages.add(pmtMessage);
					}
				}catch(BNPApplicationException exception){
					//FO 7.0 Fortify Issue Fix
					//LOGGER.error("Message Reference is   "+eippPayMsgVO.getBatchId());
					updatePaymentMessageFlag(eippPayMsgVO);
					insertPaymentMessageForFailure(eippPayMsgVO,exception.getErrorMessage());
					continue;
				}
			}
		}catch(BNPApplicationException exception){
			LOGGER.error("processMessages BNPApplicationException is  ::"+exception);
		}
		return collectionMessages;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.IEippPaymentMessageService#processBillingMessages(java.util.List, java.lang.String)
	 */
	@Override
	public List<Map<String,Object>> processBillingMessages(List<EippPaymentMsgVO> allMsg,String schType) throws BNPApplicationException {
		List<Map<String,Object>> billingMessages = new ArrayList<Map<String,Object>>();
		try{
			for (EippPaymentMsgVO eippPayMsgVO : allMsg) {
				PaymentInitiateMessage collMessage = null;
				eippPayMsgVO.setSchType(schType);
				Map<String,Object> pmtMessage = new HashMap<String, Object>();
				try{
					collMessage = (PaymentInitiateMessage) messageFactory.getMessageInstance(
							propertyLoader.getValue("message.type.eipp.payment.request"));
					if(collMessage!=null){
						collMessage.constructMessage(eippPayMsgVO);
						if(collMessage.getXmlMessage()!=null){
							//FO 7.0 Fortify Issue Fix
							//LOGGER.debug("Generated EIPP CollectionMessages XML::"+collMessage.getXmlMessage().toString());
							System.out.println("Generated EIPP CollectionMessages XML::"+collMessage.getXmlMessage().toString());
						}
						insertPaymentMessageInfo(collMessage,eippPayMsgVO);
						pmtMessage.put("eIPPPaymentMessage", collMessage);
						pmtMessage.put("eIPPPaymentMessageVO", eippPayMsgVO);
						//976332 CSCDEV-2683 18-NOV-2014:START
						//LOGGER.debug("pmtMessage::"+pmtMessage);
						//976332 CSCDEV-2683 18-NOV-2014:END
						billingMessages.add(pmtMessage);
					}
				}catch(BNPApplicationException exception){
					//FO 7.0 Fortify Issue Fix
					//LOGGER.error("Message Reference is   "+eippPayMsgVO.getBatchId());
					updateBillingMessageFlag(eippPayMsgVO);
					insertPaymentMessageForFailure(eippPayMsgVO,exception.getErrorMessage());
					continue;
				}
			}
		}catch(BNPApplicationException exception){
			LOGGER.error("processMessages BNPApplicationException is  ::"+exception);
		}
		return billingMessages;
		
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.IEippPaymentMessageService#updateBillingMessageFlag(com.bnp.eipp.services.vo.payment.EippPaymentMsgVO)
	 */
	@Override
	public void updateBillingMessageFlag(EippPaymentMsgVO eippPayMsgVO) throws BNPApplicationException {
		if(eippPayMsgVO!=null)
		{
			eippPayMsgVO.setRecordStatus(BNPConstants.INITIATED_BILL);
			eippPaymentMessageDao.updateBillingMessageFlag(eippPayMsgVO);
		}
	}

	/**
	 * Sets the input args.
	 *
	 * @param args the args
	 * @return the eipp payment msg detail vo
	 */
	private EippPaymentMsgDetailVO setInputArgs(String[] args) {
		EippPaymentMsgDetailVO inputVO=new EippPaymentMsgDetailVO();
		if(args!=null){
			if(args.length>1 && args[1]!=null){
				//FO 7.0 Fortify Issue Fix
				//LOGGER.debug("Branch Id is ::"+args[1]);
				inputVO.setInputBranch(args[1]);
			}
			if(args.length>2 && args[2]!=null){
				//FO 7.0 Fortify Issue Fix
				//LOGGER.debug("Currency Id is ::"+args[2]);
				inputVO.setInputCcy(args[2]);
			}
			if(args.length>3 && null!=args[3]){
				//FO 7.0 Fortify Issue Fix
				//LOGGER.debug("Payment Method Id is ::"+args[3]);
				inputVO.setInputPymtMthd(args[3]);
			}
		}
		return inputVO;
	}
	
	/**
	 * Gets the collections list.
	 *
	 * @param inputVO the input vo
	 * @return the collections list
	 * @throws BNPApplicationException the bNP application exception
	 */
	private List<EippPaymentMsgVO> getCollectionsList(EippPaymentMsgDetailVO inputVO) throws BNPApplicationException {
		
		List<EippPaymentMsgVO> collections = new ArrayList<EippPaymentMsgVO>();
		String batchId=null;
		//CSCDEV-2683 :976332:13112014 :START
		//LOGGER.info("Process leg1 payment Buyer to Supplier ::"+inputVO);
		//CSCDEV-2683 :976332:13112014 :END
		//Process leg1 payment
		List<EippPaymentMsgDetailVO> allBuySuppGroup = eippPaymentMessageDao.getBuySuppPaymentsByGroup(inputVO);
		//CSCDEV-2683 :976332:13112014 :START
		//LOGGER.debug("Process leg1 payment Buyer to Supplier allBuySuppGroup::"+allBuySuppGroup);
		LOGGER.debug("Process leg1 payment Buyer to Supplier allBuySuppGroup::");
		//CSCDEV-2683 :976332:13112014 :END
		for (EippPaymentMsgDetailVO buySupp : allBuySuppGroup) {
			EippPaymentMsgVO collection=null;
			List<EippPaymentMsgDetailVO> buySuplist = populatePymtDetForBuySup(buySupp);
			//CSCDEV-2683 :976332:13112014 :START
			//LOGGER.info("buySuplist ::"+buySuplist);
			//CSCDEV-2683 :976332:13112014 :END
			List<EippPaymentMsgDetailVO> finalList =new ArrayList<EippPaymentMsgDetailVO>();
			for (EippPaymentMsgDetailVO pymtAmtCheck : buySuplist) {
				if(pymtAmtCheck.getPaymentAmt()!=null && pymtAmtCheck.getPaymentAmt().compareTo(BigDecimal.ZERO)>0){
					finalList.add(pymtAmtCheck);
				}else{
					processStatusUpdate(pymtAmtCheck);
				}
			}
			if(finalList!=null && finalList.size()>0){
				collection = populatePymtMsgDets(finalList);
				//CSCDEV-2683 :976332:13112014 :START		
				//LOGGER.info("buySuplist:collection ::"+collection);
				//CSCDEV-2683 :976332:13112014 :END
			batchId = getBatchId();
			//FO 7.0 Fortify Issue Fix
			//LOGGER.info("buySuplist:batchId ::"+batchId);
			collection.setBatchId(batchId);
				updateBatchIdInMaster(finalList,batchId);
			collection.setMrkPlaceInvolved("N");
			collections.add(collection);
		}
		}
		
		//CSCDEV-2683 :976332:13112014 :START
		//LOGGER.info("Process leg1 payment Buyer to MarketPlace ::"+inputVO);
		//CSCDEV-2683 :976332:13112014 :END
		//Process leg2 Paymnets
		List<EippPaymentMsgDetailVO> allBuyMktPlcGroup = eippPaymentMessageDao.getBuyMktPlcPaymentsByGroup(inputVO);
		//CSCDEV-2683 :976332:19112014 :START
		//LOGGER.debug("Process leg1 payment Buyer to MarketPlace allBuyMktPlcGroup::"+allBuyMktPlcGroup);
		//CSCDEV-2683 :976332:19112014 :END
		for (EippPaymentMsgDetailVO buyMktPlc : allBuyMktPlcGroup) {
			EippPaymentMsgVO collection=null;
			List<EippPaymentMsgDetailVO> buyMktPlclist = populatePymtDetForBuyMktPlc(buyMktPlc);
			//FO 7.0 Fortify Issue Fix
			//LOGGER.info("buyMktPlclist ::"+buyMktPlclist);
			List<EippPaymentMsgDetailVO> finalList =new ArrayList<EippPaymentMsgDetailVO>();
			for (EippPaymentMsgDetailVO pymtAmtCheck : buyMktPlclist) {
				if(pymtAmtCheck.getPaymentAmt()!=null && pymtAmtCheck.getPaymentAmt().compareTo(BigDecimal.ZERO)>0){
					finalList.add(pymtAmtCheck);
				}else{
					processStatusUpdate(pymtAmtCheck);
				}
			}
			if(finalList!=null && finalList.size()>0){
				collection = populatePymtMsgDets(finalList);
				//976332 CSCDEV-2683 14-NOV-2014:START			
				//LOGGER.info("buyMktPlclist:collection ::"+collection);
				//976332 CSCDEV-2683 14-NOV-2014:END
			batchId = getBatchId();
			collection.setBatchId(batchId);
			//FO 7.0 Fortify Issue Fix
			//LOGGER.info("buyMktPlclist:batchId ::"+batchId);
				updateBatchIdInMaster(finalList,batchId);
			collection.setMrkPlaceInvolved("Y");
			collections.add(collection);
		}
		}
		
		return collections;
	}
	
	private void processStatusUpdate(EippPaymentMsgDetailVO pymtAmtCheck) throws BNPApplicationException {
		try{
			EippPymtStatusUpdateVO stsUpdVo=new EippPymtStatusUpdateVO();
			stsUpdVo.setUserId("SCHEDULER");
			stsUpdVo.setRefNo(pymtAmtCheck.getPaymentRefNo());
			stsUpdVo.setAction("SCHEDULER");
			eippPymtStatusUpdateServices.updatePaymentStatus(stsUpdVo, true);
		}catch (BNPApplicationException exception) {
			LOGGER.error("BNPApplicationException::"+exception);
			throw new BNPApplicationException("Error in update status");
		}
	}

	/**
	 * Populate pymt det for buy sup.
	 *
	 * @param buySupp the buy supp
	 * @return the list
	 * @throws BNPApplicationException the bNP application exception
	 */
	private List<EippPaymentMsgDetailVO> populatePymtDetForBuySup(EippPaymentMsgDetailVO buySupp) throws BNPApplicationException {
		List<EippPaymentMsgDetailVO> allPymtsForBuySup=null;
		allPymtsForBuySup = eippPaymentMessageDao.getPymtsForBuySup(buySupp);
		//976332 CSCDEV-2683 18-NOV-2014:START
		//LOGGER.debug("populatePymtDetForBuySup::"+allPymtsForBuySup);
		//976332 CSCDEV-2683 18-NOV-2014:END
		setAccountDetails(allPymtsForBuySup);
		return allPymtsForBuySup;
	}
	
	/**
	 * Populate pymt det for buy mkt plc.
	 *
	 * @param buyMktPlc the buy mkt plc
	 * @return the list
	 * @throws BNPApplicationException the bNP application exception
	 */
	private List<EippPaymentMsgDetailVO> populatePymtDetForBuyMktPlc(EippPaymentMsgDetailVO buyMktPlc) throws BNPApplicationException {
		List<EippPaymentMsgDetailVO> allPymtsForBuyMktPlc;
		allPymtsForBuyMktPlc = eippPaymentMessageDao.getPymtsForBuyMktPlc(buyMktPlc);
		setAccountDetails(allPymtsForBuyMktPlc);
		return allPymtsForBuyMktPlc;
	}
	
	/**
	 * Sets the account details.
	 *
	 * @param allPayments the new account details
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void setAccountDetails(List<EippPaymentMsgDetailVO> allPayments) throws BNPApplicationException {
		for (EippPaymentMsgDetailVO allPayBuySupp : allPayments) {
			List<PaymentInitiateAccountVO> debDetlist = new ArrayList<PaymentInitiateAccountVO>();
			List<PaymentInitiateAccountVO> creDetlist = new ArrayList<PaymentInitiateAccountVO>();
			PaymentInitiateAccountVO debDet;
			PaymentInitiateAccountVO creDet;
			
			//Set Debit Deatils - Set Buyer Details
			if(allPayBuySupp.getIsSplitPymt()!=null && "Y".equalsIgnoreCase(allPayBuySupp.getIsSplitPymt().trim())){
				List<EippPaymentMsgDetailVO> allSplitDetails;
				allSplitDetails = eippPaymentMessageDao.getSplitDetailsList(allPayBuySupp);
				for (EippPaymentMsgDetailVO getBuyDet : allSplitDetails) {
					PaymentInitiateAccountVO splitDetails;
					getBuyDet.setMapId(getBuyDet.getBuyerAccMapId());
					splitDetails = eippPaymentMessageDao.getDebitAccountDetails(getBuyDet);
					if(splitDetails!=null){
						splitDetails.setTxnsAmt(getBuyDet.getBuyerTxnAmt());
						splitDetails.setDebCustRef(getBuyDet.getBuyerCustRefNo());
						splitDetails.setClrSysNm(getClrSysNmBasedonCountry(allPayBuySupp.getHdrCountry(),BNPConstants.CLEARING_SYSTEM));
						debDetlist.add(splitDetails);
					}
				}
			}else{
				allPayBuySupp.setMapId(allPayBuySupp.getBuyerAccMapId());
				debDet = eippPaymentMessageDao.getDebitAccountDetails(allPayBuySupp);
				if(debDet!=null){
					debDet.setClrSysNm(getClrSysNmBasedonCountry(allPayBuySupp.getHdrCountry(),BNPConstants.CLEARING_SYSTEM));
					debDetlist.add(debDet);
				}
			}
			allPayBuySupp.setDebitDetailsList(debDetlist);
		
			//Set Credit Details - Supplier or Market Place
			if(allPayBuySupp.getMktPlaceAccIden()!=null){
				//set Market Place Details
				allPayBuySupp.setMapId(allPayBuySupp.getMktPlaceAccMapId());
				creDet = eippPaymentMessageDao.getCreditAccountDetails(allPayBuySupp);
			}else{
				//Set Supplier Details
				allPayBuySupp.setMapId(allPayBuySupp.getSupplierAccMapId());
				creDet = eippPaymentMessageDao.getCreditAccountDetails(allPayBuySupp);
			}
			if(creDet!=null){
				creDet.setClrSysNm(getClrSysNmBasedonCountry(allPayBuySupp.getHdrCountry(),BNPConstants.CLEARING_SYSTEM));
				creDetlist.add(creDet);
			}
			allPayBuySupp.setCreditDetailList(creDetlist);
		}
		
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.IEippPaymentMessageService#getClrSysNmBasedonCountry(java.lang.String, java.lang.String)
	 */
	@Override
	public String getClrSysNmBasedonCountry(String hdrCountry,String keyName) throws BNPApplicationException {
		List<NameValueVO> tagValueBasedonCountryList;
		String tagValue=null;
		tagValueBasedonCountryList=eippPaymentMessageDao.getTagValueBasedonCountry(hdrCountry);
		if(tagValueBasedonCountryList!=null){
			NameValueVO nameValueVO=new NameValueVO(keyName,null);
			
			if(tagValueBasedonCountryList.contains(nameValueVO))
			{
				tagValue=tagValueBasedonCountryList.get(tagValueBasedonCountryList.indexOf(nameValueVO)).getValue();
			}
			return tagValue;
		}
		return tagValue;
	}
	
	private EippPaymentMsgVO populatePymtMsgDets(
			List<EippPaymentMsgDetailVO> paylist, String msgId) throws BNPApplicationException {
		String orgId=null;
		String routeToSys=null;
		EippPaymentMsgVO fullMsgVO = new EippPaymentMsgVO();
		if(paylist!=null && paylist.size()>0){
			if("P".equalsIgnoreCase(paylist.get(0).getSchType())){
				orgId = paylist.get(0).getMktPlaceOrgId();
				routeToSys = paylist.get(0).getSupplierRouteToSys();
			}else{
				orgId = paylist.get(0).getBuyerOrgId();
				if(paylist.get(0).getMktPlaceOrgId()!=null){
					routeToSys = paylist.get(0).getMktPlaceRouteToSys();
				}else{
					routeToSys = paylist.get(0).getSupplierRouteToSys();
				}
			}
			fullMsgVO.setScmOrgId(orgId);
			fullMsgVO.setCountry(paylist.get(0).getHdrCountry());
			fullMsgVO.setBankCode(paylist.get(0).getHdrBankCode());
			fullMsgVO.setBranchCode(paylist.get(0).getHdrBranchCode());
			fullMsgVO.setSupportBranchId(paylist.get(0).getSupportBranchId());
			fullMsgVO.setDestination(routeToSys);
			fullMsgVO.setH2hReceive(true);
			if (msgId != null) {
				fullMsgVO.setMsgId(msgId);
			} else {
				fullMsgVO.setMsgId(getMessageId());
			}
			fullMsgVO.setMsgType(PropertiesReader.getProperty("message.type.eipp.payment.request"));
			fullMsgVO.setPaymentMsgDetVO(paylist);
		}
		return fullMsgVO;
	}
	
	/**
	 * Populate pymt msg dets.
	 *
	 * @param paylist the paylist
	 * @return the eipp payment msg vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private EippPaymentMsgVO populatePymtMsgDets(List<EippPaymentMsgDetailVO> payList) throws BNPApplicationException {
		return populatePymtMsgDets(payList, null);
	}
	
	/**
	 * Update batch id in master.
	 *
	 * @param creDebList the cre deb list
	 * @param batchId the batch id
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void updateBatchIdInMaster(List<EippPaymentMsgDetailVO> creDebList,String batchId) throws BNPApplicationException {
		for (EippPaymentMsgDetailVO creDeb : creDebList) {
			creDeb.setBatchId(batchId);
			eippPaymentMessageDao.updateBatchIdInMaster(creDeb);
		}
	}

	/**
	 * Gets the payments list.
	 *
	 * @param inputVO the input vo
	 * @return the payments list
	 * @throws BNPApplicationException the bNP application exception
	 */
	private List<EippPaymentMsgVO> getPaymentsList(EippPaymentMsgDetailVO inputVO) throws BNPApplicationException {
		//976332 CSCDEV-2683 19-NOV-2014:START
		//LOGGER.debug("inside getPaymentsList::"+inputVO);
		//976332 CSCDEV-2683 19-NOV-2014:END
		List<EippPaymentMsgVO> payments = new ArrayList<EippPaymentMsgVO>();
		String batchId=null;
		List<EippPaymentMsgDetailVO> allMktPlcSuppGroup = eippPaymentMessageDao.getMktPlcSuppPaymentsByGroup(inputVO);
		//976332 CSCDEV-2683 20-NOV-2014:START
		//LOGGER.debug("getPaymentsList:allMktPlcSuppGroup::"+allMktPlcSuppGroup);
		LOGGER.debug("getPaymentsList:allMktPlcSuppGroup::");
		//976332 CSCDEV-2683 20-NOV-2014:END
		for (EippPaymentMsgDetailVO mktPlcSupp : allMktPlcSuppGroup) {
			EippPaymentMsgVO payment=null;
			List<EippPaymentMsgDetailVO> mktPlcSuppList = populatePymtDetForMktPlcSupp(mktPlcSupp);
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("getPaymentsList:mktPlcSuppList::"+mktPlcSuppList);
			List<EippPaymentMsgDetailVO> finalList =new ArrayList<EippPaymentMsgDetailVO>();
			for (EippPaymentMsgDetailVO pymtAmtCheck : mktPlcSuppList) {
				if(pymtAmtCheck.getPaymentAmt()!=null && pymtAmtCheck.getPaymentAmt().compareTo(BigDecimal.ZERO)>0){
					finalList.add(pymtAmtCheck);
				}else{
					processStatusUpdate(pymtAmtCheck);
				}
			}
			if(finalList!=null && finalList.size()>0){
				payment = populatePymtMsgDets(finalList);
				//FO 7.0 Fortify Issue Fix
				//LOGGER.debug("getPaymentsList:payment::"+payment);
			batchId = getBatchId();
			payment.setBatchId(batchId);
			//LOGGER.debug("getPaymentsList:batchId::"+batchId);
				updateBatchIdInMaster(finalList,batchId);
			payment.setMrkPlaceInvolved("Y");
			payments.add(payment);
			}
		}
		return payments;
	}
	
	/**
	 * Populate pymt det for mkt plc supp.
	 *
	 * @param mktPlcSupp the mkt plc supp
	 * @return the list
	 * @throws BNPApplicationException the bNP application exception
	 */
	private List<EippPaymentMsgDetailVO> populatePymtDetForMktPlcSupp(EippPaymentMsgDetailVO mktPlcSupp) throws BNPApplicationException {
		List<EippPaymentMsgDetailVO> allPymtsForMktPlcSupp=null;
		allPymtsForMktPlcSupp = eippPaymentMessageDao.getPymtsForMktPlcSupp(mktPlcSupp);
		setAccountDetailsForPayments(allPymtsForMktPlcSupp);
		return allPymtsForMktPlcSupp;
	}
	
	/**
	 * Sets the account details for payments.
	 *
	 * @param allPaymentsForMktPlcSupp the new account details for payments
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void setAccountDetailsForPayments(List<EippPaymentMsgDetailVO> allPaymentsForMktPlcSupp) throws BNPApplicationException {
		for (EippPaymentMsgDetailVO allPayMktPlcSupp : allPaymentsForMktPlcSupp) {
			List<PaymentInitiateAccountVO> debDetlist = new ArrayList<PaymentInitiateAccountVO>();
			List<PaymentInitiateAccountVO> creDetlist = new ArrayList<PaymentInitiateAccountVO>();
			PaymentInitiateAccountVO debDet;
			PaymentInitiateAccountVO creDet;
			
			//Set Debit Deatils - Set Market Place Details
			allPayMktPlcSupp.setMapId(allPayMktPlcSupp.getMktPlaceAccMapId());
			debDet = eippPaymentMessageDao.getDebitAccountDetails(allPayMktPlcSupp);
			if(debDet!=null){
				debDet.setClrSysNm(getClrSysNmBasedonCountry(allPayMktPlcSupp.getHdrCountry(),BNPConstants.CLEARING_SYSTEM));
				debDetlist.add(debDet);
			}
			allPayMktPlcSupp.setDebitDetailsList(debDetlist);
		
			//Set Credit Details - Supplier Details
			allPayMktPlcSupp.setMapId(allPayMktPlcSupp.getSupplierAccMapId());
			creDet = eippPaymentMessageDao.getCreditAccountDetails(allPayMktPlcSupp);
			if(creDet!=null){
				debDet.setClrSysNm(getClrSysNmBasedonCountry(allPayMktPlcSupp.getHdrCountry(),BNPConstants.CLEARING_SYSTEM));
				creDetlist.add(creDet);
			}
			allPayMktPlcSupp.setCreditDetailList(creDetlist);
		}
		
	}

	/**
	 * Insert payment message for failure.
	 *
	 * @param eippPayMsgVO the eipp pay msg vo
	 * @param errorMessage the error message
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void insertPaymentMessageForFailure(EippPaymentMsgVO eippPayMsgVO,String errorMessage) throws BNPApplicationException{
		MessageVO messageVO = new MessageVO();
		populateMessageVOForPayment(eippPayMsgVO, messageVO);
		messageVO.setStatus(PropertiesReader.getProperty("txns.status.message.ignored"));
		messageVO.setErrorMessage(errorMessage);
		eippPaymentMessageDao.insertMessageInfo(messageVO);
	}
	
	/**
	 * Insert payment message info.
	 *
	 * @param paymentMessage the payment message
	 * @param eippPayMsgVO the eipp pay msg vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void insertPaymentMessageInfo(PaymentInitiateMessage paymentMessage,EippPaymentMsgVO eippPayMsgVO) throws BNPApplicationException{
		MessageVO messageVO = new MessageVO();
		String status = null;
		populateMessageVOForPayment(eippPayMsgVO, messageVO);
		status = getMessageStatus(eippPayMsgVO.isH2hReceive());
		messageVO.setStatus(status);
		setMsgDetail(paymentMessage, messageVO);
		eippPaymentMessageDao.insertMessageInfo(messageVO);
	}
	
	/**
	 * Populate message vo for payment.
	 *
	 * @param eippPayMsgVO the eipp pay msg vo
	 * @param messageVO the message vo
	 */
	private void populateMessageVOForPayment(EippPaymentMsgVO eippPayMsgVO, MessageVO messageVO) {
		messageVO.setMsgType(eippPayMsgVO.getMsgType());
		messageVO.setTransportType(eippPayMsgVO.getDestination());
		messageVO.setSource(PropertiesReader.getProperty("txns.label.fo"));
		messageVO.setOrgId(eippPayMsgVO.getScmOrgId());
		messageVO.setMsgId(eippPayMsgVO.getMsgId());
		messageVO.setMsgRef(eippPayMsgVO.getBatchId());
		messageVO.setSupportBranchId(eippPayMsgVO.getSupportBranchId());
		messageVO.setCreatedBy(BNPConstants.SYSTEM);
	}
	
	/**
	 * Gets the message status.
	 *
	 * @param isH2HReceive the is h2 h receive
	 * @return the message status
	 */
	private String getMessageStatus(boolean isH2HReceive) {
		if(isH2HReceive){
			return PropertiesReader.getProperty("txns.status.message.sent");
		}else {
			return PropertiesReader.getProperty("txns.status.message.pending");
		}
	}
	
	/**
	 * Sets the msg detail.
	 *
	 * @param paymentMessage the payment message
	 * @param msgVO the msg vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void setMsgDetail(PaymentInitiateMessage paymentMessage,MessageVO msgVO) throws BNPApplicationException {
		try{
		MessageDetailVO msgDet = new MessageDetailVO();
		msgDet.setMsg(paymentMessage.getXmlMessage().getBytes(BNPConstants.UTF8_ENCODING));
		msgVO.setMessageDetail(msgDet);
		}catch (UnsupportedEncodingException exception) {
			LOGGER.error("UnsupportedEncodingException::"+exception);
			throw new BNPApplicationException(exception.getMessage(), exception);
		}
	}

	/**
	 * Gets the batch id.
	 *
	 * @return the batch id
	 * @throws BNPApplicationException the bNP application exception
	 */
	private String getBatchId() throws BNPApplicationException {
		return eippPaymentMessageDao.getBatchId();
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.IEippPaymentMessageService#getMessageId()
	 */
	public String getMessageId() throws BNPApplicationException {
		return eippPaymentMessageDao.getMessageId();
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.IEippPaymentMessageService#updatePaymentMessageFlag(com.bnp.eipp.services.vo.payment.EippPaymentMsgVO)
	 */
	@Override
	public void updatePaymentMessageFlag(EippPaymentMsgVO eippPayMsgVO) throws BNPApplicationException {
		if(eippPayMsgVO!=null)
		{
			if("Y".equalsIgnoreCase(eippPayMsgVO.getMrkPlaceInvolved())){
				if("P".equalsIgnoreCase(eippPayMsgVO.getSchType())){
					eippPayMsgVO.setRecordStatus(StatusConstants.PAYMENT_INITIATED);
					eippPayMsgVO.setStatusCode(StatusConstants.PYMT_INIT_2);
				}else{
					eippPayMsgVO.setRecordStatus(StatusConstants.COLLECTION_INITIATED);
					eippPayMsgVO.setStatusCode(StatusConstants.COLL_INIT_1);
					insertEventLog(eippPayMsgVO.getPaymentMsgDetVO(),EventType.EIPP_COLLECTION_INITIATED);
				}
			}else{
				eippPayMsgVO.setRecordStatus(StatusConstants.PAYMENT_INITIATED);
				eippPayMsgVO.setStatusCode(StatusConstants.PYMT_INIT_1);
			}
			insertPaymentAudit(eippPayMsgVO.getPaymentMsgDetVO(),eippPayMsgVO.getRecordStatus(),eippPayMsgVO.getStatusCode());
			eippPaymentMessageDao.updatePaymentMessageFlag(eippPayMsgVO);
		}
		
	}
	
	/**
	 * Insert payment audit.
	 *
	 * @param paymentMsgDetVO the payment msg det vo
	 * @param status the status
	 * @param action the action
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void insertPaymentAudit(List<EippPaymentMsgDetailVO> paymentMsgDetVO,String status,String action) throws BNPApplicationException {
		for(EippPaymentMsgDetailVO singPymtMsgVo: paymentMsgDetVO){
			singPymtMsgVo.setRecordStatus(status);
			singPymtMsgVo.setStatusCode(action);
			eippPaymentMessageDao.insertPymtAudit(singPymtMsgVo);
		}
	}

	/**
	 * Insert event log.
	 *
	 * @param list the list
	 * @param eventType the event type
	 */
	private void insertEventLog(List<EippPaymentMsgDetailVO> list,EventType eventType) {
		try {
			for(EippPaymentMsgDetailVO data: list){
				EventLogVO eventVO = new EventLogVO();
				eventVO.setReferenceKey(String.valueOf(data.getPaymentId()));
				eventVO.setEventType(eventType);
				eventVO.setBuyerOrgId(data.getBuyerOrgId());
				eventVO.setSellerOrgId(data.getSupplierOrgId());
				eventVO.setMktPlcOrgId(data.getMktPlaceOrgId());
				eventVO.setMarketPlaceOrgID(data.getMktPlaceOrgId());
				eventVO.setEventInitiator(BNPConstants.SYSTEM);
				eventDelegateImpl.initEvents(eventVO);
			}
		} catch (BNPApplicationException e) {
			LOGGER.error("Error while raising event log : " + e );
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.IEippPaymentMessageService#updateMessageInfoStatus(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public void updateMessageInfoStatus(String msgId, String status,String errorDesc) throws BNPApplicationException {
		eippPaymentMessageDao.updateMessageInfoStatus(msgId, status,errorDesc);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.IEippPaymentMessageService#getEippPymtDetsForRegenerate(java.lang.String)
	 */
	@Override
	public EippPaymentMsgVO getEippPymtDetsForRegenerate(String msgRef, String msgId)	throws BNPApplicationException {
		EippPaymentMsgVO eippPymtMsgVo = null;
		List<EippPaymentMsgDetailVO> allReGenList = eippPaymentMessageDao.allReGenList(msgRef);
		if(allReGenList != null && allReGenList.size() > 0){
			if(allReGenList.get(0).getSchType()!=null && "P".equalsIgnoreCase(allReGenList.get(0).getSchType())){
				setAccountDetailsForPayments(allReGenList);
			}else{
				setAccountDetails(allReGenList);
			}
			eippPymtMsgVo = populatePymtMsgDets(allReGenList, msgId);
		}
		return eippPymtMsgVo;
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.IEippPaymentMessageService#updateTxnTimestamp(com.bnp.eipp.services.vo.payment.EippPaymentMsgVO)
	 */
	@Override
	public void updateTxnTimestamp(EippPaymentMsgVO eippPymtMsgVO) throws BNPApplicationException {
		eippPaymentMessageDao.updateTxnTimestamp(eippPymtMsgVO);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.IEippPaymentMessageService#resetProcessingFlag(com.bnp.eipp.services.vo.payment.EippPaymentMsgVO)
	 */
	@Override
	public void resetProcessingFlag(EippPaymentMsgVO eippPymtMsgVO) throws BNPApplicationException {
		eippPaymentMessageDao.resetProcessingFlag(eippPymtMsgVO);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.IEippPaymentMessageService#getBilldatas(java.lang.String)
	 */
	@Override
	public List<EippPaymentMsgDetailVO> getBilldatas(String inputBranch) throws BNPApplicationException {
		return eippPaymentMessageDao.getBilldatas(inputBranch);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.IEippPaymentMessageService#pymtProcInfoPopulationForBuyr(com.bnp.eipp.services.vo.payment.EippPaymentMsgDetailVO)
	 */
	@Override
	public PaymentInitiateAccountVO pymtProcInfoPopulationForBuyr(EippPaymentMsgDetailVO singPayAccVo) throws BNPApplicationException {
		return eippPaymentMessageDao.pymtProcInfoPopulationForBuyr(singPayAccVo);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.IEippPaymentMessageService#pymtProcInfoForSuplr(com.bnp.eipp.services.vo.payment.EippPaymentMsgDetailVO)
	 */
	@Override
	public PaymentInitiateAccountVO pymtProcInfoForSuplr(EippPaymentMsgDetailVO singPayAccVo) throws BNPApplicationException {
		return eippPaymentMessageDao.pymtProcInfoForSuplr(singPayAccVo);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.IEippPaymentMessageService#pymtProcInfoForMktPlc(com.bnp.eipp.services.vo.payment.EippPaymentMsgDetailVO)
	 */
	@Override
	public PaymentInitiateAccountVO pymtProcInfoForMktPlc(EippPaymentMsgDetailVO singPayAccVo) throws BNPApplicationException {
		return eippPaymentMessageDao.pymtProcInfoForMktPlc(singPayAccVo);
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.IEippPaymentMessageService#pymtProcCreBillingDets(com.bnp.eipp.services.vo.payment.EippPaymentMsgDetailVO)
	 */
	@Override
	public PaymentInitiateAccountVO pymtProcCreBillingDets(EippPaymentMsgDetailVO payAccVo) throws BNPApplicationException {
		return eippPaymentMessageDao.pymtProcCreBillingDets(payAccVo);
	}
	
	@Override
	public EippPaymentMsgVO preparePayMsgVO(EippPaymentMsgDetailVO payAccVo) throws BNPApplicationException {
		List<EippPaymentMsgDetailVO> outputPayAccVoList =new  ArrayList<EippPaymentMsgDetailVO>();
		EippPaymentMsgVO payMsgVO = new EippPaymentMsgVO();

		//Credit to bank account
		List<PaymentInitiateAccountVO> creAccVoList = new ArrayList<PaymentInitiateAccountVO>();
		PaymentInitiateAccountVO creAccVO = null; 
		creAccVO = pymtProcCreBillingDets(payAccVo);
		if(creAccVO!=null){
			creAccVO.setClrSysNm(getClrSysNmBasedonCountry(creAccVO.getAcctCtryCode(),BNPConstants.CLEARING_SYSTEM));
			creAccVO.setTxnsAmt(payAccVo.getPaymentAmt());
			creAccVO.setTxnsCcy(payAccVo.getPaymentCcy());
			creAccVO.setPaymentRefNo(payAccVo.getPaymentRefNo());
			payMsgVO.setDestination(creAccVO.getCreRouteToSys());
			creAccVoList.add(creAccVO);
		}

		//Debit from buyer,Supplier or marketPlace account
		List<PaymentInitiateAccountVO> debAccVoList = new ArrayList<PaymentInitiateAccountVO>();
		PaymentInitiateAccountVO debAccVO; 
		if(payAccVo.getDebOrgType()!=null && "B".equalsIgnoreCase(payAccVo.getDebOrgType())){
			payAccVo.setBuyerOrgId(payAccVo.getOrgId());
			payAccVo.setBuyerERPId(payAccVo.getDebERPId());
			payAccVo.setBuyerMasterNo(payAccVo.getDebMasterNo());
			payAccVo.setBuyerOrgName(payAccVo.getDebOrgName());
			debAccVO = pymtProcInfoPopulationForBuyr(payAccVo);
		}else if(payAccVo.getDebOrgType()!=null && "S".equalsIgnoreCase(payAccVo.getDebOrgType())){
			payAccVo.setSupplierOrgId(payAccVo.getOrgId());
			payAccVo.setSupplierERPId(payAccVo.getDebERPId());
			payAccVo.setSupplierMasterNo(payAccVo.getDebMasterNo());
			payAccVo.setSupplierOrgName(payAccVo.getDebOrgName());
			debAccVO = pymtProcInfoForSuplr(payAccVo);
		}else{
			payAccVo.setMktPlaceOrgId(payAccVo.getOrgId());
			payAccVo.setMktPlaceMasterNo(payAccVo.getDebMasterNo());
			payAccVo.setMktPlaceOrgName(payAccVo.getDebOrgName());
			debAccVO = pymtProcInfoForMktPlc(payAccVo);
		}
		if(debAccVO!=null){
			debAccVO.setClrSysNm(getClrSysNmBasedonCountry(debAccVO.getAcctCtryCode(),BNPConstants.CLEARING_SYSTEM));
			debAccVO.setTxnsAmt(payAccVo.getPaymentAmt());
			debAccVO.setTxnsCcy(payAccVo.getPaymentCcy());
			debAccVoList.add(debAccVO);
		}

		payAccVo.setCreditDetailList(creAccVoList);
		payAccVo.setDebitDetailsList(debAccVoList);
		outputPayAccVoList.add(payAccVo);

		payMsgVO.setPaymentMsgDetVO(outputPayAccVoList);
		payMsgVO.setCountry(payAccVo.getHdrCountry());
		payMsgVO.setBankCode(payAccVo.getHdrBankCode());
		payMsgVO.setBranchCode(payAccVo.getHdrBranchCode());
		payMsgVO.setScmOrgId(payAccVo.getOrgId());
		payMsgVO.setSupportBranchId(payAccVo.getSupportBranchId());
		payMsgVO.setH2hReceive(true);
		payMsgVO.setMsgId(getMessageId());
		payMsgVO.setMsgType(PropertiesReader.getProperty("message.type.eipp.payment.request"));
		payMsgVO.setBatchId(payAccVo.getPaymentRefNo());
		return payMsgVO;
	}
	
	@Override
	public EippPaymentMsgVO getEippPymtDetsForBillingRegenerate(String msgRef) throws BNPApplicationException {
		EippPaymentMsgDetailVO paymentMsgDetailVO = eippPaymentMessageDao.getBillingDetails(msgRef);
		EippPaymentMsgVO eippPymtMsgVo = preparePayMsgVO(paymentMsgDetailVO);
		return eippPymtMsgVo;
	}
}
