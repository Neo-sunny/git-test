/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   07 September 2012
 * 
 * Purpose:      Eipp Billing Charge Count vo
 * 
 * Change History: 
 * Date                       Author                      version                      Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 07 Sep 2012                Reena S                 Initial Version  				Rel3.0 EIPP Phase II
************************************************************************************************************************************************************/

package com.bnp.eipp.services.invoice.vo;

import java.util.Calendar;
import java.util.Date;

import com.bnp.scm.services.txns.util.calendar.DateAdapter;


public class EippBillingChargeCountVO extends EippTransactionVO {	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L; 

	private String countId;
	private long count;
	private Date billDate;
	
	private boolean orgIdValid;

	private String errorCode;
	private String errorDescription;
	private String senderOrgId;
    
	
	
	
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.vo.EippTransactionVO#getTransactionType()
	 */
	public String getTransactionType() {
		return "BILLCHARGECOUNT";
	}
	
	
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.invoice.vo.EippTransactionVO#toDataString()
	 */
	public String toDataString() {
		DateAdapter adapter = new DateAdapter();
		Calendar calendar = Calendar.getInstance();
		StringBuilder builder = new StringBuilder();
		builder.append(getTransactionType() + ",");
		builder.append(getOrgId()+ ",");
		builder.append(getCountId()+ ",");
		builder.append(getCount()+ ",");
		builder.append(getRefNo() + ",");
		if(getBillDate()!= null) {
			calendar.setTime(getBillDate());
			builder.append( adapter.marshal(calendar)+ ",");
		} else {
			builder.append(",");
		}		
		builder.append(getStatus());
	
		return builder.toString();
	}

	
	
	
	
	
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	/**
	 * @return the errorDescription
	 */
	public String getErrorDescription() {
		return errorDescription;
	}
	/**
	 * @param errorDescription the errorDescription to set
	 */
	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}
	
	



	public String getSenderOrgId() {
		return senderOrgId;
	}



	public void setSenderOrgId(String senderOrgId) {
		this.senderOrgId = senderOrgId;
	}


	public String getCountId() {
		return countId;
	}



	public void setCountId(String countId) {
		this.countId = countId;
	}



	public Date getBillDate() {
		return billDate;
	}



	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}



	public boolean isOrgIdValid() {
		return orgIdValid;
	}



	public void setOrgIdValid(boolean orgIdValid) {
		this.orgIdValid = orgIdValid;
	}



	public long getCount() {
		return count;
	}



	public void setCount(long count) {
		this.count = count;
	}





	
}
