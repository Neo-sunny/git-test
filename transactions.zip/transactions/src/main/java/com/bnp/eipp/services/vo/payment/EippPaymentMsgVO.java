/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   20 Jun 2012 
 * 
 * Purpose:      value Object for Auto Payment Rule Setup Screen
 * 
 * Change History: 
 * Date                       		Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 20 Jun 2012       			 	Sandhya R 										Initial Version  
 ************************************************************************************************************************************************************/

package com.bnp.eipp.services.vo.payment;

import java.util.List;

import com.bnp.scm.services.common.vo.AbstractVO;

/**
 * The Class EippPaymentMsgVO.
 */
public class EippPaymentMsgVO extends AbstractVO {

	private static final long serialVersionUID = 1447433459098574943L;

	private List<EippPaymentMsgDetailVO> paymentMsgDetVO;

	private String batchId;
	private String supportBranchId;
	private String mrkPlaceInvolved;
	private String bankCode;
	private String country;
	private String scmOrgId;
	private boolean h2hReceive;
	private String destination;
	private String msgType;
	private String schType;

	public String getSchType() {
		return schType;
	}

	public void setSchType(String schType) {
		this.schType = schType;
	}

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public List<EippPaymentMsgDetailVO> getPaymentMsgDetVO() {
		return paymentMsgDetVO;
	}

	public void setPaymentMsgDetVO(List<EippPaymentMsgDetailVO> paymentMsgDetVO) {
		this.paymentMsgDetVO = paymentMsgDetVO;
	}

	public String getSupportBranchId() {
		return supportBranchId;
	}

	public void setSupportBranchId(String supportBranchId) {
		this.supportBranchId = supportBranchId;
	}

	public String getMrkPlaceInvolved() {
		return mrkPlaceInvolved;
	}

	public void setMrkPlaceInvolved(String mrkPlaceInvolved) {
		this.mrkPlaceInvolved = mrkPlaceInvolved;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getScmOrgId() {
		return scmOrgId;
	}

	public void setScmOrgId(String scmOrgId) {
		this.scmOrgId = scmOrgId;
	}

	public boolean isH2hReceive() {
		return h2hReceive;
	}

	public void setH2hReceive(boolean h2hReceive) {
		this.h2hReceive = h2hReceive;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getMsgType() {
		return msgType;
	}

	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}

}
