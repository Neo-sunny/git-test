/******************************************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 22, 201210:42:58 PM
 * 
 * Purpose:      DisputeAttachmentVO.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 22, 201210:42:58 PM        Oracle Financial Services Software Ltd                  Initial Version  
************************************************************************************************************************************************************/

package com.bnp.eipp.services.vo.dispute;

import java.io.Serializable;
import java.util.Date;

public class DisputeAttachmentVO implements Serializable {

	private long dispId;

	private String fileName;

	private String orgRole;

	private String uploadedBy;

	private Date uploadedDate;

	private byte[] data;

	/**
	 * @return the dispId
	 */
	public long getDispId() {
		return dispId;
	}

	/**
	 * @param dispId the dispId to set
	 */
	public void setDispId(long dispId) {
		this.dispId = dispId;
	}

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * @return the orgRole
	 */
	public String getOrgRole() {
		return orgRole;
	}

	/**
	 * @param orgRole the orgRole to set
	 */
	public void setOrgRole(String orgRole) {
		this.orgRole = orgRole;
	}

	/**
	 * @return the uploadedBy
	 */
	public String getUploadedBy() {
		return uploadedBy;
	}

	/**
	 * @param uploadedBy the uploadedBy to set
	 */
	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}

	/**
	 * @return the uploadedDate
	 */
	public Date getUploadedDate() {
		return uploadedDate;
	}

	/**
	 * @param uploadedDate the uploadedDate to set
	 */
	public void setUploadedDate(Date uploadedDate) {
		this.uploadedDate = uploadedDate;
	}

	/**
	 * @return the data
	 */
	public byte[] getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(byte[] data) {
		this.data = copyArray(data);
	}

	private byte[] copyArray(byte[] source) {
		byte[] dest = null;
		if (source != null) {
			dest = new byte[source.length];
			System.arraycopy(source, 0, dest, 0, source.length);
		}
		return dest;
	}
}
