/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   02 Feb 12  
 * 
 * Purpose:      EIPP Invoice Upload
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 02 Feb 12                       Oracle Financial Services Software Ltd                                  FO Bo Integration Changes
 * 12-July 2012                    Oracle Financial Services Software Ltd            					   EIPP Phase II - Cancel Invoice MFU                                  
 * 26 Sep 2012					   Dinesh D															  	   Modified for MFU - EIPP Disputes
 *  19 Oct 2012					  Merdith S 										ST - 6984 To allow disputing of Line Itm based on LinkorgforEIPP data
 *   23 Oct 2012					Merdith 											ST Defect 6824
 *****************************************************************************************************************************************************************/

package com.bnp.eipp.services.invoice;

import java.util.List;
import java.util.Map;

import com.bnp.eipp.services.invoice.vo.EippInvCntVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceBusinessRulesVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.vo.dispute.DisputeVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.invoice.vo.InvalidFileDataVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;
import com.bnp.scm.services.txns.common.message.AbstractMsg;


// TODO: Auto-generated Javadoc
/**
 * The Interface IEippInvcUploadService.
 */
public interface IEippInvcUploadService {
	
	
	/**
	 * Process match doc details.
	 *
	 * @param message the message
	 * @param detailsVO the details vo
	 * @return the map
	 * @throws BNPApplicationException the bNP application exception
	 * @Name : processMatchDocDetails
	 * @Description : This method is used to process the match doc details
	 */
	Map<String, List<EippInvCntVO>> processMatchDocDetails(AbstractMsg<?> message, 
			FileDetailsVO detailsVO) throws BNPApplicationException;
	
	/**
	 * Process invoice details.
	 *
	 * @param message the message
	 * @param detailsVO the details vo
	 * @return the map
	 * @throws BNPApplicationException the bNP application exception
	 * @Name : processInvoiceDetails
	 * @Description : This method is used to process the invoice details
	 */
	Map<String, List<EippInvCntVO>> processInvoiceDetails(AbstractMessage<?> message, 
							FileDetailsVO detailsVO) throws BNPApplicationException;
	
	/**
	 * Creates the tech ack.
	 *
	 * @param message the message
	 * @param detailsVO the details vo
	 * @param transList the trans list
	 * @throws BNPApplicationException the bNP application exception
	 * @Name : createTechAck
	 * @Description : This method is used to create technical acknowledgement
	 */
	void createTechAck(AbstractMessage<?> message, FileDetailsVO detailsVO, List<EippInvCntVO> transList) throws BNPApplicationException;
	
	/**
	 * Creates the func ack.
	 *
	 * @param message the message
	 * @param detailsVO the details vo
	 * @param transList the trans list
	 * @param isAutoReleaseEnabled the is auto release enabled
	 * @throws BNPApplicationException the bNP application exception
	 * @Name : createFuncAck
	 * @Description : This method is used to create functional acknowledgement
	 */
	//modified for 3720 added isAutoReleaseEnabled parameter
	void createFuncAck(AbstractMessage<?> message, FileDetailsVO detailsVO, List<EippInvCntVO> transList, boolean isAutoReleaseEnabled) throws BNPApplicationException;
	
	/**
	 * Creates the func ack.
	 *
	 * @param detailsVO the details vo
	 * @param releasedBy the released by
	 * @throws BNPApplicationException the bNP application exception
	 * @Name : createFuncAck
	 * @Description : This method is used to create functional acknowledgement
	 */
	void createFuncAck(FileDetailsVO detailsVO, String releasedBy) throws BNPApplicationException;
	
	/**
	 * Release file.
	 *
	 * @param message the message
	 * @param detailsVO the details vo
	 * @param eippInvCntMap the eipp inv cnt map
	 * @throws BNPApplicationException the bNP application exception
	 */
	void releaseFile(AbstractMessage<?> message, 
			FileDetailsVO detailsVO, Map<String, List<EippInvCntVO>> eippInvCntMap) throws BNPApplicationException;	
	
	/**
	 * Process.
	 *
	 * @param detailsVO the details vo
	 * @param invoiceMessage the invoice message
	 * @return the map
	 * @throws BNPApplicationException the bNP application exception
	 */
	Map<String, List<EippInvCntVO>> process(FileDetailsVO detailsVO,
			AbstractMessage<?> invoiceMessage)
			throws BNPApplicationException;
	
	/**
	 * Release.
	 *
	 * @param detailsVO the details vo
	 * @param invoiceMessage the invoice message
	 * @param eippInvCntMap the eipp inv cnt map
	 * @throws BNPApplicationException the bNP application exception
	 */
	void release(FileDetailsVO detailsVO, AbstractMessage<?> invoiceMessage,
			Map<String, List<EippInvCntVO>> eippInvCntMap)
			throws BNPApplicationException;
	
	/**
	 * Process.
	 *
	 * @param detailsVO the details vo
	 * @param invoiceMessage the invoice message
	 * @return the map
	 * @throws BNPApplicationException the bNP application exception
	 */
	Map<String, List<EippInvCntVO>> process(FileDetailsVO detailsVO,
			AbstractMsg<?> invoiceMessage)
			throws BNPApplicationException;
	
	/**
	 * Release.
	 *
	 * @param detailsVO the details vo
	 * @param invoiceMessage the invoice message
	 * @param eippInvCntMap the eipp inv cnt map
	 * @throws BNPApplicationException the bNP application exception
	 */
	void release(FileDetailsVO detailsVO, AbstractMsg<?> invoiceMessage,
			Map<String, List<EippInvCntVO>> eippInvCntMap)
			throws BNPApplicationException;


	/**
	 * Can upload partial file.
	 *
	 * @param orgId the org id
	 * @return true, if successful
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean canUploadPartialFile(String orgId) throws BNPApplicationException;

	/**
	 * Gets the customer org id.
	 *
	 * @param billType the bill type
	 * @param custERPId the cust erp id
	 * @return the customer org id
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<String> getCustomerOrgId(String billType, String custERPId) throws BNPApplicationException;

	/**
	 * Gets the model type for organization.
	 *
	 * @param orgId the org id
	 * @return the model type for organization
	 * @throws BNPApplicationException the bNP application exception
	 */
	String getModelTypeForOrganization(String orgId) throws BNPApplicationException;

	/**
	 * Gets the timezone for organization.
	 *
	 * @param orgId the org id
	 * @return the timezone for organization
	 * @throws BNPApplicationException the bNP application exception
	 */
	String getTimezoneForOrganization(String orgId) throws BNPApplicationException;

	/**
	 * Gets the counter party org id.
	 *
	 * @param orgId the org id
	 * @param billType the bill type
	 * @param cntpERPId the cntp erp id
	 * @return the counter party org id
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<String> getCounterPartyOrgId(String orgId, String billType,String cntpERPId) throws BNPApplicationException;

	/**
	 * Checks if is buyer seller linked.
	 *
	 * @param custOrgId the cust org id
	 * @param cntpOrgId the cntp org id
	 * @param billType the bill type
	 * @return true, if is buyer seller linked
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean isBuyerSellerLinked(String custOrgId, String cntpOrgId,	String billType) throws BNPApplicationException;

	/**
	 * Update reprocess flag.
	 *
	 * @param invalidDataList the invalid data list
	 * @param detailsVO the details vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void updateReprocessFlag(List<InvalidFileDataVO> invalidDataList,
			FileDetailsVO detailsVO) throws BNPApplicationException;

	/**
	 * Gets the org type for organization.
	 *
	 * @param orgId the org id
	 * @return the org type for organization
	 * @throws BNPApplicationException the bNP application exception
	 */
	String getOrgTypeForOrganization(String orgId) throws BNPApplicationException;

	/**
	 * Checks if is bill through market place.
	 *
	 * @param billType the bill type
	 * @param marketPlaceOrgId the market place org id
	 * @return true, if is bill through market place
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean isBillThroughMarketPlace(String billType, String marketPlaceOrgId) throws BNPApplicationException;

	/**
	 * Checks if is customer org linked to market place.
	 *
	 * @param orgId the org id
	 * @param marketPlaceOrgId the market place org id
	 * @return true, if is customer org linked to market place
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean isCustomerOrgLinkedToMarketPlace(String orgId, String marketPlaceOrgId) throws BNPApplicationException;

	/**
	 * Gets the rule type for discount rule id.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @return the rule type for discount rule id
	 * @throws BNPApplicationException the bNP application exception
	 */
	String getRuleTypeForDiscountRuleId(EippInvoiceVO eippInvoiceVO)throws BNPApplicationException;

	/**
	 * Checks if is invoice available in system.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @return the int
	 * @throws BNPApplicationException the bNP application exception
	 */
	int isInvoiceAvailableInSystem(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException;

	/**
	 * Checks if is buyer seller linked to market place.
	 *
	 * @param custOrgId the cust org id
	 * @param cntpOrgId the cntp org id
	 * @param billType the bill type
	 * @param marketPlaceOrgId the market place org id
	 * @return true, if is buyer seller linked to market place
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean isBuyerSellerLinkedToMarketPlace(String custOrgId,
			String cntpOrgId, String billType, String marketPlaceOrgId)
			throws BNPApplicationException;

	/**
	 * Gets the business processing rules.
	 *
	 * @param custOrgId the cust org id
	 * @param cntpOrgId the cntp org id
	 * @param billType the bill type
	 * @return the business processing rules
	 * @throws BNPApplicationException the bNP application exception
	 */
	EippInvoiceBusinessRulesVO getBusinessProcessingRules(String custOrgId,String cntpOrgId,String billType) throws BNPApplicationException;
	
	/**
	 * Gets the invoice list for validation.
	 *
	 * @param invoiceVO the invoice vo
	 * @return the invoice list for validation
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippInvoiceVO> getInvoiceListForValidation(EippInvoiceVO invoiceVO) throws BNPApplicationException;
	
	/**
	 * Gets the invoice for processing.
	 *
	 * @param invoiceList the invoice list
	 * @return the invoice for processing
	 * @throws BNPApplicationException the bNP application exception
	 */
	EippInvoiceVO getInvoiceForProcessing(List<EippInvoiceVO> invoiceList) throws BNPApplicationException;

	/**
	 * Gets the invoice list for validation.
	 *
	 * @param params the params
	 * @return the invoice list for validation
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippInvoiceVO> getInvoiceListForValidation(Map<String, Object> params)throws BNPApplicationException;
	
	/**
	 * Chk valid inv l ifrom link org.
	 *
	 * @param invLIVO the inv livo
	 * @return true, if successful
	 */
	boolean chkValidInvLIfromLinkOrg(DisputeVO invLIVO);
	
	void createFuncAck(AbstractMessage message, 
			FileDetailsVO detailsVO) throws BNPApplicationException;
	
}
