/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   20 Sep 2012
 * 
 * Purpose:      EippZipFileProcessor
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 20 Sep 2012        Oracle Financial Services Software Ltd                  Initial Version
 * 09 Oct 2012        Reena S												  Getting fileId from saveAttachments   
 * 15 Oct 2012        Merdith S												  ST - 6904 Setting the error desc and zip file name  
 * 17 Oct 2012		  Prabakaran S											  Fix for ST Defect # 6793
 * 23 Dec 2013		  Gangadharan R											  FO.R.5.0 - For Attachment Support
 * 30 Dec 2013						Gangadharan R														FO.R.5.0 - For Attachment Support
************************************************************************************************************************************************************/

package com.bnp.eipp.services.filemgmt.processor;

import java.util.Date;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnp.eipp.services.filemgmt.EippAbstractFileService;
import com.bnp.eipp.services.filemgmt.IFileProcessService;
import com.bnp.eipp.services.filemgmt.factory.FileProcessorFactory;
import com.bnp.eipp.services.filemgmt.util.InstrumentTypeEnum;
import com.bnp.eipp.services.filemgmt.zip.IEippZipFileService;
import com.bnp.eipp.services.invoice.IEippReleaseService;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.dao.ITransactionDAO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.AttachmentProcessingUtil;
import com.bnp.scm.services.common.util.CacheConstants;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.filemgmt.vo.FileUploadVO;
import com.bnp.scm.services.filemgmt.vo.FileVO;
import com.bnp.scm.services.invoice.IInvoiceUploadService;
import java.util.Locale;

@Component
public class EippZipFileProcessor implements IEippZipFileProcessor {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(EippZipFileProcessor.class);
	
	@Autowired
	private IEippZipFileService defaultService;
	
	@Autowired
	private IEippReleaseService releaseService;
	
	@Autowired
	private ITransactionDAO transactionDAO;
	
	@Autowired
	private IInvoiceUploadService invoiceUploadService;
	
	@Autowired
	private IFileProcessService fileProcessorService;
	
	@Autowired
	private BNPPropertyLoaderConfigurer propertyLoader;
	
	@Autowired
	private FileProcessorFactory processorFactory;
	
	private FileDetailsVO createFileDetails(FileUploadVO uploadVO) throws BNPApplicationException {
		FileVO dataFile = uploadVO.getFileVO();
		FileDetailsVO detailsVO = new FileDetailsVO();
		detailsVO.setFileFrmtType(uploadVO.getFileFormatType());	
		detailsVO.setFileName(dataFile.getFileName());
		detailsVO.setUploadDate(new Date(System.currentTimeMillis()));
		detailsVO.setFileProcessedDate(new Date(System.currentTimeMillis()));
		detailsVO.setUserId(dataFile.getUserId());
		detailsVO.setFileType(dataFile.getFileType());
		detailsVO.setSenderOrgId(uploadVO.getSenderOrgId());
		detailsVO.setFileData(dataFile.getData());
		detailsVO.setInstrumentType(InstrumentTypeEnum.getInstrumentType(uploadVO.getFileFormatType()));
		detailsVO.setFileUploadType(uploadVO.getFileType());
		detailsVO.setMsgId(fileProcessorService.getMessageId());
		detailsVO.setSource(CacheConstants.MFU);
		detailsVO.setAttachmentId(uploadVO.getAttachmentId()); 
		detailsVO.setUserType(uploadVO.getLoginUserTypeId());
		detailsVO.setFileTypeId(uploadVO.getFileTypeId()); // Added for R3.0 Manual File Upload for matching and reconcilation
		return detailsVO;
	}
	
	@Transactional (propagation=Propagation.REQUIRED, rollbackFor=Exception.class)
	public void processFile(FileDetailsVO detailsVO) throws BNPApplicationException {
		byte[] data = detailsVO.getFileData();
		
		HashMap<String, byte[]> fileMap = getFileData(data);
		
		if(fileMap.containsKey(BNPConstants.INDEX_FILE_NAME)){
			String fileName  = getFileName(fileMap);
			
			long attachmentId = saveAttachmentDetails(data);
			detailsVO.setAttachmentId(attachmentId);
			
			if (fileName != null && !fileName.isEmpty()) {
				detailsVO.setFileType(getFileType(fileName));
				detailsVO.setFileUploadType(getFileType(fileName));
				
				EippAbstractFileService fileProcessor = processorFactory.getFileService(
						detailsVO.getFileType());
				fileProcessor.processData(detailsVO);
			} else {
				saveAttachments(detailsVO);
			}
			
		} else {
			detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.load.fail"));
			detailsVO.setErrorCode(String.valueOf(ErrorConstants.INDEX_FILE_UNAVAILABLE));
			fileProcessorService.updateFileStatus(detailsVO);
			detailsVO.setReceivedData(detailsVO.getFileData());
			fileProcessorService.insertFileUploadMessageDetails(detailsVO);
			fileProcessorService.triggerEventLog(detailsVO, "FUNC_ERROR");
		}
	}
	
	private long saveAttachmentDetails(
			byte[] data) throws BNPApplicationException {
		long attachmentId = invoiceUploadService.generateAttachmentId();
		//Persist the attachment in DB
		transactionDAO.saveAttachmentZip(attachmentId, data);
		
		return attachmentId;
	}
	
	private HashMap<String, byte[]> getFileData(byte[] data) throws BNPApplicationException {
		/* Method argument list changed for SCF Attachment Support */
		return AttachmentProcessingUtil.getFiles(data, null);
	}
	
	private String getFileName(
			HashMap<String, byte[]> fileMap) throws BNPApplicationException {
		return AttachmentProcessingUtil.getDataFileName(
					fileMap.get(BNPConstants.INDEX_FILE_NAME));
	}
	
	private String getFileType(String fileName) {
		String fileType = null; 
		if (fileName.toLowerCase(Locale.getDefault()).endsWith(BNPConstants.XML)) {//a37126 - Added Fortify Issue - Portability Flaw: Locale Dependent Comparison
			fileType = BNPConstants.STANDARD_FILE_TYPE;
		} else {
			fileType = BNPConstants.CUSTOM_FILE_TYPE;
		}
		return fileType;
	}
	
	public long processFile(FileUploadVO uploadVO) throws BNPApplicationException {
		
		long fileId = 0;
		byte[] data = uploadVO.getFileVO().getData();
		
		HashMap<String, byte[]> fileMap = getFileData(data);
		
		if(fileMap.containsKey(BNPConstants.INDEX_FILE_NAME)){
			String fileName  = getFileName(fileMap);
			
			long attachmentId = saveAttachmentDetails(data);
			//FO 7.0 Fortify Issue Fix
			//LOGGER.debug("attachment id:"+ attachmentId);
			uploadVO.setAttachmentId(attachmentId);
			
			if (fileName != null && !fileName.isEmpty()) {
				
				if (isSCMBuyer(uploadVO.getLoginUserTypeId())&& 
						uploadVO.getFileFormatType().equals(BNPConstants.EIPP_INVOICE_ATT_UPLOAD)) {
					FileDetailsVO detailsVO = createFileDetails(uploadVO);
					
					detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.load.fail"));
					detailsVO.setErrorCode(String.valueOf(ErrorConstants.BCM_BUYER_CANNOT_UPLOAD_INVOICE_FILE));
					fileProcessorService.saveFileDetails(detailsVO);
					fileProcessorService.triggerEventLog(detailsVO, "FUNC_ERROR");		
					return detailsVO.getFileId();
				}
				
				FileVO fileVO = uploadVO.getFileVO();
				setFileVO(fileName, fileMap.get(fileName), fileVO);
				uploadVO.setFileVO(fileVO);
				uploadVO.setFileType(getFileType(fileName));
				
				EippAbstractFileService fileProcessor = processorFactory.getFileService(uploadVO.getFileType());
				FileDetailsVO detailsVO = createFileDetails(uploadVO);
				fileId = fileProcessor.processData(detailsVO);
			} else {
				FileDetailsVO detailsVO = createFileDetails(uploadVO);
				fileProcessorService.saveFileDetails(detailsVO);
				fileProcessorService.insertFileUploadMessageDetails(detailsVO);
				saveAttachments(detailsVO);
				
				fileId = detailsVO.getFileId();
			}
		} else {
			FileDetailsVO detailsVO = createFileDetails(uploadVO);
			
			fileProcessorService.saveFileDetails(detailsVO);
			fileId = detailsVO.getFileId();
			
			detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.load.fail"));
			detailsVO.setErrorCode(String.valueOf(ErrorConstants.INDEX_FILE_UNAVAILABLE));
			fileProcessorService.updateFileStatus(detailsVO);
			detailsVO.setReceivedData(detailsVO.getFileData());
//			fileProcessorService.insertFileUploadMessageDetails(detailsVO);
			fileProcessorService.triggerEventLog(detailsVO, "FUNC_ERROR");
		}
		return fileId;
	}
	
	private boolean isSCMBuyer(String userTypeId) {
		return (BNPConstants.SCMB.equals(userTypeId) ||
				BNPConstants.SCMBALL.equals(userTypeId));
	}
	
	private void saveAttachments(
			FileDetailsVO detailsVO) throws BNPApplicationException {
		
		try {
			defaultService.saveAttachments(detailsVO.getFileId(),
				BNPConstants.FILE_TYPE_INVOICE, detailsVO.getUserId());
			
			boolean isAutoReleaseEnabled = releaseService.insertIntoMasterIfAutoAuthorizationEnabled(detailsVO);
			
			if (!isAutoReleaseEnabled) {
				detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.release.pending"));
				fileProcessorService.updateFileStatus(detailsVO);
				fileProcessorService.triggerEventLog(detailsVO,"SUCCESS");
			} 
		} catch (BNPApplicationException e) {
			detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.load.fail"));
			detailsVO.setErrorCode(Integer.toString(e.getErrorCode()));
			detailsVO.setErrorDesc(e.getErrorMessage());
			fileProcessorService.updateFileStatus(detailsVO);
			detailsVO.setReceivedData(detailsVO.getFileData());
			fileProcessorService.triggerEventLog(detailsVO, "FUNC_ERROR");
		}
	}
	
	/**
	 * Sets the file vo.
	 *
	 * @param fileName the file name
	 * @param data the data
	 * @param fileVO the file vo
	 */
	private void setFileVO(String fileName,byte[] data, FileVO fileVO) {
		String fileType = null;
		int index = fileName.lastIndexOf('.');
		fileType = fileName.substring((index + 1), fileName.length());
		fileVO.setData(data);
//		fileVO.setFileName(fileName);
		//TODO: SET the MIME type
		//fileVO.setContentType("");
		fileVO.setFileType(fileType);
	}
}
