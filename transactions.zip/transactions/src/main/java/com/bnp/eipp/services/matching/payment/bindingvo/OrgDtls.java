package com.bnp.eipp.services.matching.payment.bindingvo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for OrgDtls complex type.
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OrgDtls">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;choice>
 *         &lt;element name="Buyer" type="{}OrgDetails"/>
 *         &lt;element name="Seller" type="{}OrgDetails"/>
 *         &lt;element name="MktPlc" type="{}MarketPlace" minOccurs="0"/>
 *       &lt;/choice>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OrgDtls", propOrder = { "buyer", "seller", "mktPlc" })
public class OrgDtls {

	@XmlElement(name = "Buyer")
	protected OrgDetails buyer;

	@XmlElement(name = "Seller")
	protected OrgDetails seller;

	@XmlElement(name = "MktPlc")
	protected MarketPlace mktPlc;

	/**
	 * Gets the value of the buyer property.
	 * @return possible object is {@link OrgDetails }
	 */
	public OrgDetails getBuyer() {
		return buyer;
	}

	/**
	 * Sets the value of the buyer property.
	 * @param value allowed object is {@link OrgDetails }
	 */
	public void setBuyer(OrgDetails value) {
		this.buyer = value;
	}

	/**
	 * Gets the value of the seller property.
	 * @return possible object is {@link OrgDetails }
	 */
	public OrgDetails getSeller() {
		return seller;
	}

	/**
	 * Sets the value of the seller property.
	 * @param value allowed object is {@link OrgDetails }
	 */
	public void setSeller(OrgDetails value) {
		this.seller = value;
	}

	/**
	 * Gets the value of the mktPlc property.
	 * @return possible object is {@link MarketPlace }
	 */
	public MarketPlace getMktPlc() {
		return mktPlc;
	}

	/**
	 * Sets the value of the mktPlc property.
	 * @param value allowed object is {@link MarketPlace }
	 */
	public void setMktPlc(MarketPlace value) {
		this.mktPlc = value;
	}

}
