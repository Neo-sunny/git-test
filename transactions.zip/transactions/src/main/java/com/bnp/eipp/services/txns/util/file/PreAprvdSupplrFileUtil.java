/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Aug 7, 20129:47:31 AM
 * 
 * Purpose:      PreAprvdSupplrFileUtil is a utility file for mapping jaxb VOs to application VOs
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 *                      Oracle Financial Services Software Ltd                                  Thread Pool changes for file upload
 *****************************************************************************************************************************************************************/


package com.bnp.eipp.services.txns.util.file;

import java.util.ArrayList;
import java.util.List;

import org.dozer.DozerBeanMapper;

import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.invoice.vo.InvalidFileDataVO;
import com.bnp.scm.services.invoice.vo.TransactionVO;
import com.bnp.scm.services.mrktng.bindingvo.Buyer;
import com.bnp.scm.services.mrktng.bindingvo.ErrorMessage;
import com.bnp.scm.services.mrktng.bindingvo.ErrorMessages;
import com.bnp.scm.services.mrktng.bindingvo.PreApvdSellr;
import com.bnp.scm.services.mrktng.bindingvo.SellerList;
import com.bnp.scm.services.mrktng.bindingvo.Sellr;

// TODO: Auto-generated Javadoc
/**
 * The Class PreAprvdSupplrFileUtil.
 */
public class PreAprvdSupplrFileUtil {

	
	/**
	 * Gets the error messages.
	 *
	 * @param invalidDataList the invalid data list
	 * @param mapper the mapper
	 * @return the error messages
	 */
	private static ErrorMessages getErrorMessages(List<InvalidFileDataVO> invalidDataList,DozerBeanMapper mapper){
		ErrorMessages ermsgs = new ErrorMessages();
			for (InvalidFileDataVO invalidFileDataVO : invalidDataList) {
				ErrorMessage errorMessage = mapper.map(invalidFileDataVO, ErrorMessage.class);
				ermsgs.getErrMsg().add(errorMessage);
			}
		return ermsgs;
		
	}
	
	/**
	 * Map vo to jaxb.
	 *
	 * @param transList the trans list
	 * @return the pre apvd sellr
	 */
	public static PreApvdSellr mapVOToJAXB(List<? extends TransactionVO> transList) {
		PreApvdSellr preAprvdSellr = new PreApvdSellr();
		SellerList sellrLst= null;
		DozerBeanMapper mapper = getMapper();
		//Getting the first record in supplierVO list since buyer details is same for all the suppliers hence one record is sufficient to get the details
		Buyer buyer = createBuyer(transList.get(0),mapper);
		
		for (TransactionVO suplrVO : transList) {
			sellrLst = new SellerList();
			sellrLst.getSellr().add(createSellr
						(suplrVO,mapper));
		}
		preAprvdSellr.setBuyer(buyer);
		preAprvdSellr.setSellrLst(sellrLst);
		return preAprvdSellr;
	}



	/**
	 * Gets the mapper.
	 *
	 * @return the mapper
	 */
	private static DozerBeanMapper getMapper() {
		List<String> mappingFiles = new ArrayList<String>();
		mappingFiles.add("mapper/SellrMapper.xml");
		mappingFiles.add("mapper/BuyerMapper.xml");
		// added for Error Msg
		mappingFiles.add("mapper/MarketingErrorMsgMapper.xml");
		DozerBeanMapper mapper = new DozerBeanMapper();
		mapper.setMappingFiles(mappingFiles);
		return mapper;
	}


	
	/**
	 * Creates the buyer.
	 *
	 * @param suplrVO the suplr vo
	 * @param mapper the mapper
	 * @return the buyer
	 */
	private static Buyer createBuyer(TransactionVO suplrVO,
			DozerBeanMapper mapper) {
		return mapper.map(suplrVO, Buyer.class);
	}



	/**
	 * Checks if is empty list.
	 *
	 * @param objectList the object list
	 * @return true, if is empty list
	 */
	private static boolean isEmptyList(List<? extends Object> objectList){
		if (objectList != null && !objectList.isEmpty())
			return false;
		else
			return true;
	}

	/**
	 * Creates the sellr.
	 *
	 * @param suplrVO the suplr vo
	 * @param mapper the mapper
	 * @return the sellr
	 */
	private static Sellr createSellr(TransactionVO suplrVO, DozerBeanMapper mapper) {
		Sellr sellr = mapper.map(suplrVO, Sellr.class);	
		if (!isEmptyList(suplrVO.getInvalidFileDataList())){
			sellr.setErrMsgs(getErrorMessages(suplrVO.getInvalidFileDataList(),mapper));
			sellr.setStatus(BNPConstants.VALIDATION_FAILED);
		}
		return sellr;
	}

}
