package com.bnp.eipp.services.matching.payment.bindingvo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for AccountInfo complex type.
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AccountInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;sequence>
 *           &lt;element name="CreditAcct" type="{}AccountNo" minOccurs="0"/>
 *           &lt;element name="DebitAcct" type="{}AccountNo" minOccurs="0"/>
 *         &lt;/sequence>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AccountInfo", propOrder = { "creditAcct", "debitAcct" })
public class AccountInfo {

	@XmlElement(name = "CreditAcct")
	protected AccountNo creditAcct;

	@XmlElement(name = "DebitAcct")
	protected AccountNo debitAcct;

	/**
	 * Gets the value of the creditAcct property.
	 * @return possible object is {@link AccountNo }
	 */
	public AccountNo getCreditAcct() {
		return creditAcct;
	}

	/**
	 * Sets the value of the creditAcct property.
	 * @param value allowed object is {@link AccountNo }
	 */
	public void setCreditAcct(AccountNo value) {
		this.creditAcct = value;
	}

	/**
	 * Gets the value of the debitAcct property.
	 * @return possible object is {@link AccountNo }
	 */
	public AccountNo getDebitAcct() {
		return debitAcct;
	}

	/**
	 * Sets the value of the debitAcct property.
	 * @param value allowed object is {@link AccountNo }
	 */
	public void setDebitAcct(AccountNo value) {
		this.debitAcct = value;
	}

}
