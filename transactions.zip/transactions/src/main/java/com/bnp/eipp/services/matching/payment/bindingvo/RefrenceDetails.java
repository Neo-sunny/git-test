package com.bnp.eipp.services.matching.payment.bindingvo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for RefrenceDetails complex type.
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RefrenceDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RefNo" type="{}Max35Text"/>
 *         &lt;element name="RefType" type="{}Max16Text"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RefrenceDetails", propOrder = { "refNo", "refType" })
public class RefrenceDetails {

	@XmlElement(name = "RefNo", required = true)
	protected String refNo;

	@XmlElement(name = "RefType", required = true)
	protected String refType;

	/**
	 * Gets the value of the refNo property.
	 * @return possible object is {@link String }
	 */
	public String getRefNo() {
		return refNo;
	}

	/**
	 * Sets the value of the refNo property.
	 * @param value allowed object is {@link String }
	 */
	public void setRefNo(String value) {
		this.refNo = value;
	}

	/**
	 * Gets the value of the refType property.
	 * @return possible object is {@link String }
	 */
	public String getRefType() {
		return refType;
	}

	/**
	 * Sets the value of the refType property.
	 * @param value allowed object is {@link String }
	 */
	public void setRefType(String value) {
		this.refType = value;
	}

}
