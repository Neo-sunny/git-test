package com.bnp.eipp.services.matching.invoice.bindingvo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.bnp.scm.services.txns.common.message.bindingvo.GenericMessage;

/**
 * <p>
 * Java class for Message complex type.
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Message">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Header" type="{}Header"/>
 *         &lt;element name="File" type="{}File"/>
 *         &lt;element name="ErrorDescription" type="{}ErrorDescription" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Message", propOrder = { "header", "file", "errorDescription" })
public class Message extends GenericMessage {

	@XmlElement(name = "Header", required = true)
	protected Header header;

	@XmlElement(name = "File", required = true)
	protected File file;

	@XmlElement(name = "ErrorDescription")
	protected ErrorDescription errorDescription;

	/**
	 * Gets the value of the header property.
	 * @return possible object is {@link Header }
	 */
	public Header getHeader() {
		return header;
	}

	/**
	 * Sets the value of the header property.
	 * @param value allowed object is {@link Header }
	 */
	public void setHeader(Header value) {
		this.header = value;
	}

	/**
	 * Gets the value of the file property.
	 * @return possible object is {@link File }
	 */
	public File getFile() {
		return file;
	}

	/**
	 * Sets the value of the file property.
	 * @param value allowed object is {@link File }
	 */
	public void setFile(File value) {
		this.file = value;
	}

	/**
	 * Gets the value of the errorDescription property.
	 * @return possible object is {@link ErrorDescription }
	 */
	public ErrorDescription getErrorDescription() {
		return errorDescription;
	}

	/**
	 * Sets the value of the errorDescription property.
	 * @param value allowed object is {@link ErrorDescription }
	 */
	public void setErrorDescription(ErrorDescription value) {
		this.errorDescription = value;
	}

}
