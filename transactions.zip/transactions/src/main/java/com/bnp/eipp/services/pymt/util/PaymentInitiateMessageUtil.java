/* ************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  Dec 27, 2011
 * 
 * Purpose:     Payment Message Util
 * 
 * Change History: 
 * Date             Author                                        	Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * Dec 27, 2011		Oracle Financial Services Software Ltd       	Initial Version
 * Oct 04, 2012		ArulSelvanS										To handle null for payment message
 * Nov 21, 2012		Gangadharan R									Adhoc Issues - Defaulting ChrgBr tag value as DEBT
 ******************************************************************************************************************************************************/
package com.bnp.eipp.services.pymt.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.dozer.DozerBeanMapper;

import com.bnp.eipp.services.pymt.paymentinitiate.bindingvo.ChargeBearerType1Code;
import com.bnp.eipp.services.pymt.paymentinitiate.bindingvo.PymtDetails;
import com.bnp.eipp.services.pymt.paymentinitiate.bindingvo.CreditDetails;
import com.bnp.eipp.services.pymt.paymentinitiate.bindingvo.CurrencyAndAmount;
import com.bnp.eipp.services.pymt.paymentinitiate.bindingvo.DebitDetails;
import com.bnp.eipp.services.pymt.paymentinitiate.bindingvo.Document;
import com.bnp.eipp.services.pymt.paymentinitiate.bindingvo.PymtInitDetails;
import com.bnp.eipp.services.vo.payment.EippPaymentMsgDetailVO;
import com.bnp.eipp.services.vo.payment.EippPaymentMsgVO;
import com.bnp.eipp.services.vo.payment.PaymentInitiateAccountVO;

// TODO: Auto-generated Javadoc
/**
 * The Class PaymentInitiateMessageUtil.
 */
public class PaymentInitiateMessageUtil {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentInitiateMessageUtil.class);

	/**
	 * Map vo to jaxb.
	 *
	 * @param paymentMessageVO the payment message vo
	 * @return the document
	 */
	public static Document mapVOToJAXB(EippPaymentMsgVO paymentMessageVO) {
		// Getting the mapper
		DozerBeanMapper mapper = getMapper();
		Document document = new Document();
		try {
			if(paymentMessageVO.getPaymentMsgDetVO()!=null){
				//FO 7.0 Fortify Issue Fix
				//LOGGER.info("paymentMessageVO.getPaymentInitVO().size()::"+ paymentMessageVO.getPaymentMsgDetVO().size());
				List<EippPaymentMsgDetailVO> paylist = paymentMessageVO.getPaymentMsgDetVO();
				for (EippPaymentMsgDetailVO eippPayMsgVO : paylist) {
					PymtInitDetails pymtInitDetails = mapper.map(eippPayMsgVO,PymtInitDetails.class);
					PymtDetails pymtDetails = pymtInitDetails.getPymtDtl();
					
					if(isnull(eippPayMsgVO.getBuyerOrgId())) {
						pymtInitDetails.getOrgDtls().setBuyer(null);
					}
					if(isnull(eippPayMsgVO.getSupplierOrgId())) {
						pymtInitDetails.getOrgDtls().setSeller(null);
					}
					if(isnull(eippPayMsgVO.getMktPlaceOrgId())) {
						pymtInitDetails.getOrgDtls().setMktPlc(null);
					}
	
					pymtDetails.setPymtInitDt(dateToCalendar(eippPayMsgVO.getPaymentInitDt()));
					pymtDetails.setPymtDueDt(dateToCalendar(eippPayMsgVO.getPaymentDueDt()));
						CurrencyAndAmount pymtCcyandAmnt = new CurrencyAndAmount();
						pymtCcyandAmnt.setCcy(eippPayMsgVO.getPaymentCcy());
						pymtCcyandAmnt.setValue(eippPayMsgVO.getPaymentAmt());
					pymtDetails.setTotPymtAmt(pymtCcyandAmnt);
					pymtDetails.setPymtValueDt(dateToCalendar(eippPayMsgVO.getPaymentValueDt()));
					
					pymtDetails.setChrgBr(ChargeBearerType1Code.DEBT);
					
					if(eippPayMsgVO.getDebitDetailsList()!=null){
						pymtDetails.setDbtTxnCnt(eippPayMsgVO.getDebitDetailsList().size());
					}
					if(eippPayMsgVO.getCreditDetailList()!=null){
						pymtDetails.setCrdtTxnCnt(eippPayMsgVO.getCreditDetailList().size());
					}
					DebitDetails singDebDeta = new DebitDetails();
					for (PaymentInitiateAccountVO debDetVO : eippPayMsgVO.getDebitDetailsList()) {
						com.bnp.eipp.services.pymt.paymentinitiate.bindingvo.DebitDetails.AcctDtls debAcc = mapper.map(debDetVO,com.bnp.eipp.services.pymt.paymentinitiate.bindingvo.DebitDetails.AcctDtls.class);
							CurrencyAndAmount debAmyCcy = new CurrencyAndAmount();
							debAmyCcy.setCcy(debDetVO.getTxnsCcy());
							debAmyCcy.setValue(debDetVO.getTxnsAmt());
						debAcc.setTxnAmt(debAmyCcy);
						if(debDetVO.getDebDirDebRef()!=null && !"".equalsIgnoreCase(debDetVO.getDebDirDebRef())){
							debAcc.setDirectDbtRef(debDetVO.getDebDirDebRef());
						}else{
							debAcc.setDirectDbtRef(null);
						}
						if(isnull(debDetVO.getDebCustRef())){
							debAcc.setCustRef(null);
						}else{
							debAcc.setCustRef(debDetVO.getDebCustRef());
						}
						if(isnull(debDetVO.getCorresDet1()) && isnull(debDetVO.getCorresDet2())){
							debAcc.setCorrespDtls(null);
						}
						if(isnull(debDetVO.getPymtDet1()) && isnull(debDetVO.getPymtDet2())){
							debAcc.setPymtDtls(null);
						}
						if(isnull(debDetVO.getBicCode())){
							debAcc.setBICCd(null);
						}
						if(isnull(debDetVO.getAcctOrgId())){
							debAcc.setOrgId(null);
						}
						if(debDetVO.getAccountType()!=null && "C".equalsIgnoreCase(debDetVO.getAccountType())){
							debAcc.setAcctType("Current");
						}else{
							debAcc.setAcctType("Saving");
						}
						if(debAcc.getBankDtl()!=null){
							if(isnull(debDetVO.getBankAddrAddr())){
								debAcc.getBankDtl().getAddrDet().setAddr(null);
							}else{
								debAcc.getBankDtl().getAddrDet().setAddr(debDetVO.getBankAddrAddr().replaceAll("~", ","));
							}
							if(isnull(debDetVO.getBankAddrCity())){
								debAcc.getBankDtl().getAddrDet().setCity(null);
							}
							if(isnull(debDetVO.getBankAddrState())){
								debAcc.getBankDtl().getAddrDet().setState(null);
							}
							if(isnull(debDetVO.getBankAddrZipcd())){
								debAcc.getBankDtl().getAddrDet().setZipCd(null);
							}
							if(isnull(debDetVO.getBankAddrCtryCd())){
								debAcc.getBankDtl().getAddrDet().setCtryCd(null);
							}
							if(isnull(debDetVO.getBankAddrAddr()) && 
									isnull(debDetVO.getBankAddrCity()) && 
									isnull(debDetVO.getBankAddrState()) &&
									isnull(debDetVO.getBankAddrZipcd()) &&
									isnull(debDetVO.getBankAddrCtryCd())
									){
								debAcc.getBankDtl().setAddrDet(null);
							}
						}
						singDebDeta.getAcctDtls().add(debAcc);
					}
					pymtDetails.setDebitDtls(singDebDeta);
					
					CreditDetails creDet = new CreditDetails();
					for (PaymentInitiateAccountVO creDetVO : eippPayMsgVO.getCreditDetailList()) {
						com.bnp.eipp.services.pymt.paymentinitiate.bindingvo.CreditDetails.AcctDtls debAcc = mapper.map(creDetVO,com.bnp.eipp.services.pymt.paymentinitiate.bindingvo.CreditDetails.AcctDtls.class);
							CurrencyAndAmount creAmtCcy = new CurrencyAndAmount();
							creAmtCcy.setCcy(creDetVO.getTxnsCcy());
							creAmtCcy.setValue(creDetVO.getTxnsAmt());
						debAcc.setTxnAmt(creAmtCcy);
						debAcc.setRouteType(creDetVO.getCreRouteType());
						debAcc.setRouteToSys(creDetVO.getCreRouteToSys());
						debAcc.setEndToEndId(creDetVO.getPaymentRefNo());
						if(isnull(creDetVO.getCorresDet1()) && isnull(creDetVO.getCorresDet2())){
							debAcc.setCorrespDtls(null);
						}
						if(isnull(creDetVO.getPymtDet1()) && isnull(creDetVO.getPymtDet2())){
							debAcc.setPymtDtls(null);
						}
						if(isnull(creDetVO.getBicCode())){
							debAcc.setBICCd(null);
						}
						if(isnull(creDetVO.getAcctOrgId())){
							debAcc.setOrgId(null);
						}
						if(creDetVO.getAccountType()!=null && "C".equalsIgnoreCase(creDetVO.getAccountType())){
							debAcc.setAcctType("Current");
						}else{
							debAcc.setAcctType("Saving");
						}
						if(debAcc.getBankDtl()!=null){
							if(isnull(creDetVO.getBankAddrAddr())){
								debAcc.getBankDtl().getAddrDet().setAddr(null);
							}else{
								debAcc.getBankDtl().getAddrDet().setAddr(creDetVO.getBankAddrAddr().replaceAll("~", ","));
							}
							if(isnull(creDetVO.getBankAddrCity())){
								debAcc.getBankDtl().getAddrDet().setCity(null);
							}
							if(isnull(creDetVO.getBankAddrState())){
								debAcc.getBankDtl().getAddrDet().setState(null);
							}
							if(isnull(creDetVO.getBankAddrZipcd())){
								debAcc.getBankDtl().getAddrDet().setZipCd(null);
							}
							if(isnull(creDetVO.getBankAddrCtryCd())){
								debAcc.getBankDtl().getAddrDet().setCtryCd(null);
							}
							if(isnull(creDetVO.getBankAddrAddr()) && 
									isnull(creDetVO.getBankAddrCity()) && 
									isnull(creDetVO.getBankAddrState()) &&
									isnull(creDetVO.getBankAddrZipcd()) &&
									isnull(creDetVO.getBankAddrCtryCd())
									){
								debAcc.getBankDtl().setAddrDet(null);
							}
						}
						creDet.getAcctDtls().add(debAcc);
					}
					pymtDetails.setCreditDtls(creDet);
					
					pymtInitDetails.setPymtDtl(pymtDetails);
					document.getPymtInitiation().add(pymtInitDetails);
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception is ::::: " + e);
		}
		return document;
	}
	
	
	/**
	 * Checks if is null.
	 *
	 * @param str the str
	 * @return true, if is null
	 */
	private static boolean isnull(String str){
		if(str==null || "".equalsIgnoreCase(str)){
			return true;
		}
		return false;
	}

	/**
	 * Gets the mapper.
	 *
	 * @return the mapper
	 */
	private static DozerBeanMapper getMapper() {
		List<String> pmtReqMappingFiles = new ArrayList<String>();
		pmtReqMappingFiles.add("mapper/PaymentInitiateDocMapper.xml");
		pmtReqMappingFiles.add("mapper/PaymentInitiateAccountMapper.xml");
		DozerBeanMapper mapper = new DozerBeanMapper();
		mapper.setMappingFiles(pmtReqMappingFiles);
		return mapper;
	}

	/**
	 * Date to calendar.
	 *
	 * @param date the date
	 * @return the calendar
	 * @throws ParseException the parse exception
	 */
	public static Calendar dateToCalendar(Date date) throws ParseException {
		Calendar cal = null;
		try {
			final String OLD_FORMAT = "yyyy-MM-dd";
			SimpleDateFormat newDateFormat = new SimpleDateFormat("dd-MM-yy HH:mm:ss");
			Date d = newDateFormat.parse(newDateFormat.format(date));
			newDateFormat.applyPattern(OLD_FORMAT);
			String new_date = newDateFormat.format(d);
			DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			date = (Date) formatter.parse(new_date);
			cal = Calendar.getInstance();
			cal.setTime(date);
		} catch (ParseException e) {
			LOGGER.error("ParseException in PaymentInitiateMessageUtil.dateToCalendar :: "+ e);
		}
		//FO 7.0 Fortify Issue Fix
		//LOGGER.info("Calender Date :" + cal);
		return cal;
	}


}
