package com.bnp.eipp.services.matching.payment.bindingvo;

import java.util.Calendar;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.bnp.scm.services.txns.util.calendar.DateAdapter;

/**
 * <p>
 * Java class for PymtIdentificationDetails complex type.
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PymtIdentificationDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Amount" type="{}ActiveCurrencyAndAmount"/>
 *         &lt;element name="AccountInfo" type="{}AccountInfo"/>
 *         &lt;element name="ValueDate" type="{}Date" minOccurs="0"/>
 *         &lt;element name="TxnCode" type="{}Max34Text" minOccurs="0"/>
 *         &lt;element name="EntryDate" type="{}Date" minOccurs="0"/>
 *         &lt;element name="AcctOwnerRef" type="{}Max150Text" minOccurs="0"/>
 *         &lt;element name="InstitutionalRef" type="{}Max150Text" minOccurs="0"/>
 *         &lt;element name="AdditionalInfo" type="{}Max34AlphaNumericText" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PymtIdentificationDetails", propOrder = { "amount", "accountInfo", "valueDate", "txnCode",
		"entryDate", "acctOwnerRef", "institutionalRef", "additionalInfo" })
public class PymtIdentificationDetails {

	@XmlElement(name = "Amount", required = true)
	protected ActiveCurrencyAndAmount amount;

	@XmlElement(name = "AccountInfo", required = true)
	protected AccountInfo accountInfo;

	@XmlElement(name = "ValueDate", type = String.class)
	@XmlJavaTypeAdapter(DateAdapter.class)
	protected Calendar valueDate;

	@XmlElement(name = "TxnCode")
	protected String txnCode;

	@XmlElement(name = "EntryDate", type = String.class)
	@XmlJavaTypeAdapter(DateAdapter.class)
	protected Calendar entryDate;

	@XmlElement(name = "AcctOwnerRef")
	protected String acctOwnerRef;

	@XmlElement(name = "InstitutionalRef")
	protected String institutionalRef;

	@XmlElement(name = "AdditionalInfo")
	protected String additionalInfo;

	/**
	 * Gets the value of the amount property.
	 * @return possible object is {@link ActiveCurrencyAndAmount }
	 */
	public ActiveCurrencyAndAmount getAmount() {
		return amount;
	}

	/**
	 * Sets the value of the amount property.
	 * @param value allowed object is {@link ActiveCurrencyAndAmount }
	 */
	public void setAmount(ActiveCurrencyAndAmount value) {
		this.amount = value;
	}

	/**
	 * Gets the value of the accountInfo property.
	 * @return possible object is {@link AccountInfo }
	 */
	public AccountInfo getAccountInfo() {
		return accountInfo;
	}

	/**
	 * Sets the value of the accountInfo property.
	 * @param value allowed object is {@link AccountInfo }
	 */
	public void setAccountInfo(AccountInfo value) {
		this.accountInfo = value;
	}

	/**
	 * Gets the value of the valueDate property.
	 * @return possible object is {@link String }
	 */
	public Calendar getValueDate() {
		return valueDate;
	}

	/**
	 * Sets the value of the valueDate property.
	 * @param value allowed object is {@link String }
	 */
	public void setValueDate(Calendar value) {
		this.valueDate = value;
	}

	/**
	 * Gets the value of the txnCode property.
	 * @return possible object is {@link String }
	 */
	public String getTxnCode() {
		return txnCode;
	}

	/**
	 * Sets the value of the txnCode property.
	 * @param value allowed object is {@link String }
	 */
	public void setTxnCode(String value) {
		this.txnCode = value;
	}

	/**
	 * Gets the value of the entryDate property.
	 * @return possible object is {@link String }
	 */
	public Calendar getEntryDate() {
		return entryDate;
	}

	/**
	 * Sets the value of the entryDate property.
	 * @param value allowed object is {@link String }
	 */
	public void setEntryDate(Calendar value) {
		this.entryDate = value;
	}

	/**
	 * Gets the value of the acctOwnerRef property.
	 * @return possible object is {@link String }
	 */
	public String getAcctOwnerRef() {
		return acctOwnerRef;
	}

	/**
	 * Sets the value of the acctOwnerRef property.
	 * @param value allowed object is {@link String }
	 */
	public void setAcctOwnerRef(String value) {
		this.acctOwnerRef = value;
	}

	/**
	 * Gets the value of the institutionalRef property.
	 * @return possible object is {@link String }
	 */
	public String getInstitutionalRef() {
		return institutionalRef;
	}

	/**
	 * Sets the value of the institutionalRef property.
	 * @param value allowed object is {@link String }
	 */
	public void setInstitutionalRef(String value) {
		this.institutionalRef = value;
	}

	/**
	 * Gets the value of the additionalInfo property.
	 * @return possible object is {@link String }
	 */
	public String getAdditionalInfo() {
		return additionalInfo;
	}

	/**
	 * Sets the value of the additionalInfo property.
	 * @param value allowed object is {@link String }
	 */
	public void setAdditionalInfo(String value) {
		this.additionalInfo = value;
	}

}
