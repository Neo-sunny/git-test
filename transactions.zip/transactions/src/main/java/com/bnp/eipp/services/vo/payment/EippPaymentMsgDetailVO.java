/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   20 Jun 2012 
 * 
 * Purpose:      value Object for Auto Payment Rule Setup Screen
 * 
 * Change History: 
 * Date                       		Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 20 Jun 2012       			 	Sandhya R 										Initial Version
 * 24 Sep 2012						Raja S											Change for Status Update in Payment Cancellation
 * 02 Nov 2012           			Arun G                                    		ST events fix - 7118	  
 ************************************************************************************************************************************************************/

package com.bnp.eipp.services.vo.payment;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.bnp.scm.services.common.vo.AbstractVO;

// TODO: Auto-generated Javadoc
/**
 * The Class EippPaymentMsgDetailVO.
 */
public class EippPaymentMsgDetailVO extends AbstractVO {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1447433459098574943L;

	// General Deatils
	/** The batch id. */
	private String batchId;
	
	/** The payment id. */
	private String paymentId;
	
	/** The payment ref no. */
	private String paymentRefNo;
	
	/** The payment init dt. */
	private Date paymentInitDt;
	
	/** The payment due dt. */
	private Date paymentDueDt;
	
	/** The payment value dt. */
	private Date paymentValueDt;
	
	/** The payment amt. */
	private BigDecimal paymentAmt;
	
	/** The payment ccy. */
	private String paymentCcy;
	
	/** The input branch. */
	private String inputBranch;
	
	/** The input ccy. */
	private String inputCcy;
	
	/** The input pymt mthd. */
	private String inputPymtMthd;
	
	/** The mrk place involved. */
	private String mrkPlaceInvolved;
	
	/** The buyer txn amt. */
	private BigDecimal buyerTxnAmt;
	
	/** The buyer cust ref no. */
	private String buyerCustRefNo;
	
	/** The mkt place acc iden. */
	private String mktPlaceAccIden;
	
	/** The mkt place org id. */
	private String mktPlaceOrgId;
	
	/** The mkt place org name. */
	private String mktPlaceOrgName;
	
	/** The buyer erp id. */
	private String buyerERPId;
	
	/** The supplier erp id. */
	private String supplierERPId;
	
	/** The buyer master no. */
	private String buyerMasterNo;
	
	/** The supplier master no. */
	private String supplierMasterNo;
	
	/** The mkt place master no. */
	private String mktPlaceMasterNo;
	
	/** The sch type. */
	private String schType;
	
	/** The debit details list. */
	private List<PaymentInitiateAccountVO> debitDetailsList;
	
	/** The credit detail list. */
	private List<PaymentInitiateAccountVO> creditDetailList;
	
	/** The is split pymt. */
	private String isSplitPymt;
	
	/** The split pymt amt. */
	private BigDecimal splitPymtAmt;
	
	/** The is offline pymt. */
	private String isOfflinePymt;
	
	/** The pymt status. */
	private String pymtStatus;
	
	/** The map id. */
	private String mapId;
	
	/** The buyer acc map id. */
	private String buyerAccMapId;
	
	/** The supplier acc map id. */
	private String supplierAccMapId;
	
	/** The mkt place acc map id. */
	private String mktPlaceAccMapId;
	
	/** The buyer acc iden. */
	private String buyerAccIden;
	
	/** The supplier acc iden. */
	private String supplierAccIden;
	
	/** The supplier payment method. */
	private String supplierPaymentMethod;
	
	/** The support branch id. */
	private String supportBranchId;
	
	/** The mkt place payment method. */
	private String mktPlacePaymentMethod;
	
	/** The mkt place route to sys. */
	private String mktPlaceRouteToSys;
	
	/** The supplier route to sys. */
	private String supplierRouteToSys;
	
	/** The remarks. */
	private String remarks;
	
	/** The hdr country. */
	private String hdrCountry;
	
	/** The hdr bank code. */
	private String hdrBankCode;
	
	/** The hdr branch code. */
	private String hdrBranchCode;
	
	/** The user id. */
	private String userId;
	
	/** The action. */
	private String action;
	
	/** The cre org type. */
	private String creOrgType;
	
	/** The deb org type. */
	private String debOrgType;
	
	/** The deb ccy. */
	private String debCcy;
	
	/** The cre ccy. */
	private String creCcy;
	
	/** The cre acc iden. */
	private String creAccIden;
	
	/** The deb acc iden. */
	private String debAccIden;
	
	/** The deb erp id. */
	private String debERPId;
	
	/** The deb master no. */
	private String debMasterNo;
	
	/** The deb org name. */
	private String debOrgName;

	private String payThrowMktPlace;
	/**
	 * Gets the deb erp id.
	 *
	 * @return the deb erp id
	 */
	public String getDebERPId() {
		return debERPId;
	}

	/**
	 * Sets the deb erp id.
	 *
	 * @param debERPId the new deb erp id
	 */
	public void setDebERPId(String debERPId) {
		this.debERPId = debERPId;
	}

	/**
	 * Gets the deb master no.
	 *
	 * @return the deb master no
	 */
	public String getDebMasterNo() {
		return debMasterNo;
	}

	/**
	 * Sets the deb master no.
	 *
	 * @param debMasterNo the new deb master no
	 */
	public void setDebMasterNo(String debMasterNo) {
		this.debMasterNo = debMasterNo;
	}

	/**
	 * Gets the deb org name.
	 *
	 * @return the deb org name
	 */
	public String getDebOrgName() {
		return debOrgName;
	}

	/**
	 * Sets the deb org name.
	 *
	 * @param debOrgName the new deb org name
	 */
	public void setDebOrgName(String debOrgName) {
		this.debOrgName = debOrgName;
	}

	/**
	 * Gets the cre org type.
	 *
	 * @return the cre org type
	 */
	public String getCreOrgType() {
		return creOrgType;
	}

	/**
	 * Sets the cre org type.
	 *
	 * @param creOrgType the new cre org type
	 */
	public void setCreOrgType(String creOrgType) {
		this.creOrgType = creOrgType;
	}

	/**
	 * Gets the deb org type.
	 *
	 * @return the deb org type
	 */
	public String getDebOrgType() {
		return debOrgType;
	}

	/**
	 * Sets the deb org type.
	 *
	 * @param debOrgType the new deb org type
	 */
	public void setDebOrgType(String debOrgType) {
		this.debOrgType = debOrgType;
	}

	/**
	 * Gets the deb ccy.
	 *
	 * @return the deb ccy
	 */
	public String getDebCcy() {
		return debCcy;
	}

	/**
	 * Sets the deb ccy.
	 *
	 * @param debCcy the new deb ccy
	 */
	public void setDebCcy(String debCcy) {
		this.debCcy = debCcy;
	}

	/**
	 * Gets the cre ccy.
	 *
	 * @return the cre ccy
	 */
	public String getCreCcy() {
		return creCcy;
	}

	/**
	 * Sets the cre ccy.
	 *
	 * @param creCcy the new cre ccy
	 */
	public void setCreCcy(String creCcy) {
		this.creCcy = creCcy;
	}

	/**
	 * Gets the cre acc iden.
	 *
	 * @return the cre acc iden
	 */
	public String getCreAccIden() {
		return creAccIden;
	}

	/**
	 * Sets the cre acc iden.
	 *
	 * @param creAccIden the new cre acc iden
	 */
	public void setCreAccIden(String creAccIden) {
		this.creAccIden = creAccIden;
	}

	/**
	 * Gets the deb acc iden.
	 *
	 * @return the deb acc iden
	 */
	public String getDebAccIden() {
		return debAccIden;
	}

	/**
	 * Sets the deb acc iden.
	 *
	 * @param debAccIden the new deb acc iden
	 */
	public void setDebAccIden(String debAccIden) {
		this.debAccIden = debAccIden;
	}

	/**
	 * Gets the mkt place route to sys.
	 *
	 * @return the mkt place route to sys
	 */
	public String getMktPlaceRouteToSys() {
		return mktPlaceRouteToSys;
	}

	/**
	 * Sets the mkt place route to sys.
	 *
	 * @param mktPlaceRouteToSys the new mkt place route to sys
	 */
	public void setMktPlaceRouteToSys(String mktPlaceRouteToSys) {
		this.mktPlaceRouteToSys = mktPlaceRouteToSys;
	}

	/**
	 * Gets the supplier route to sys.
	 *
	 * @return the supplier route to sys
	 */
	public String getSupplierRouteToSys() {
		return supplierRouteToSys;
	}

	/**
	 * Sets the supplier route to sys.
	 *
	 * @param supplierRouteToSys the new supplier route to sys
	 */
	public void setSupplierRouteToSys(String supplierRouteToSys) {
		this.supplierRouteToSys = supplierRouteToSys;
	}

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * Gets the action.
	 *
	 * @return the action
	 */
	public String getAction() {
		return action;
	}

	/**
	 * Sets the action.
	 *
	 * @param action the new action
	 */
	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * Gets the buyer erp id.
	 *
	 * @return the buyer erp id
	 */
	public String getBuyerERPId() {
		return buyerERPId;
	}

	/**
	 * Sets the buyer erp id.
	 *
	 * @param buyerERPId the new buyer erp id
	 */
	public void setBuyerERPId(String buyerERPId) {
		this.buyerERPId = buyerERPId;
	}

	/**
	 * Gets the supplier erp id.
	 *
	 * @return the supplier erp id
	 */
	public String getSupplierERPId() {
		return supplierERPId;
	}

	/**
	 * Sets the supplier erp id.
	 *
	 * @param supplierERPId the new supplier erp id
	 */
	public void setSupplierERPId(String supplierERPId) {
		this.supplierERPId = supplierERPId;
	}

	/**
	 * Gets the buyer master no.
	 *
	 * @return the buyer master no
	 */
	public String getBuyerMasterNo() {
		return buyerMasterNo;
	}

	/**
	 * Sets the buyer master no.
	 *
	 * @param buyerMasterNo the new buyer master no
	 */
	public void setBuyerMasterNo(String buyerMasterNo) {
		this.buyerMasterNo = buyerMasterNo;
	}

	/**
	 * Gets the supplier master no.
	 *
	 * @return the supplier master no
	 */
	public String getSupplierMasterNo() {
		return supplierMasterNo;
	}

	/**
	 * Sets the supplier master no.
	 *
	 * @param supplierMasterNo the new supplier master no
	 */
	public void setSupplierMasterNo(String supplierMasterNo) {
		this.supplierMasterNo = supplierMasterNo;
	}

	/**
	 * Gets the mkt place master no.
	 *
	 * @return the mkt place master no
	 */
	public String getMktPlaceMasterNo() {
		return mktPlaceMasterNo;
	}

	/**
	 * Sets the mkt place master no.
	 *
	 * @param mktPlaceMasterNo the new mkt place master no
	 */
	public void setMktPlaceMasterNo(String mktPlaceMasterNo) {
		this.mktPlaceMasterNo = mktPlaceMasterNo;
	}

	/**
	 * Gets the mkt place org name.
	 *
	 * @return the mkt place org name
	 */
	public String getMktPlaceOrgName() {
		return mktPlaceOrgName;
	}

	/**
	 * Sets the mkt place org name.
	 *
	 * @param mktPlaceOrgName the new mkt place org name
	 */
	public void setMktPlaceOrgName(String mktPlaceOrgName) {
		this.mktPlaceOrgName = mktPlaceOrgName;
	}

	/**
	 * Gets the supplier payment method.
	 *
	 * @return the supplier payment method
	 */
	public String getSupplierPaymentMethod() {
		return supplierPaymentMethod;
	}

	/**
	 * Sets the supplier payment method.
	 *
	 * @param supplierPaymentMethod the new supplier payment method
	 */
	public void setSupplierPaymentMethod(String supplierPaymentMethod) {
		this.supplierPaymentMethod = supplierPaymentMethod;
	}

	/**
	 * Gets the support branch id.
	 *
	 * @return the support branch id
	 */
	public String getSupportBranchId() {
		return supportBranchId;
	}

	/**
	 * Sets the support branch id.
	 *
	 * @param supportBranchId the new support branch id
	 */
	public void setSupportBranchId(String supportBranchId) {
		this.supportBranchId = supportBranchId;
	}

	/**
	 * Gets the mkt place payment method.
	 *
	 * @return the mkt place payment method
	 */
	public String getMktPlacePaymentMethod() {
		return mktPlacePaymentMethod;
	}

	/**
	 * Sets the mkt place payment method.
	 *
	 * @param mktPlacePaymentMethod the new mkt place payment method
	 */
	public void setMktPlacePaymentMethod(String mktPlacePaymentMethod) {
		this.mktPlacePaymentMethod = mktPlacePaymentMethod;
	}

	/**
	 * Gets the buyer acc iden.
	 *
	 * @return the buyer acc iden
	 */
	public String getBuyerAccIden() {
		return buyerAccIden;
	}

	/**
	 * Sets the buyer acc iden.
	 *
	 * @param buyerAccIden the new buyer acc iden
	 */
	public void setBuyerAccIden(String buyerAccIden) {
		this.buyerAccIden = buyerAccIden;
	}

	/**
	 * Gets the supplier acc iden.
	 *
	 * @return the supplier acc iden
	 */
	public String getSupplierAccIden() {
		return supplierAccIden;
	}

	/**
	 * Sets the supplier acc iden.
	 *
	 * @param supplierAccIden the new supplier acc iden
	 */
	public void setSupplierAccIden(String supplierAccIden) {
		this.supplierAccIden = supplierAccIden;
	}

	/**
	 * Gets the mrk place involved.
	 *
	 * @return the mrk place involved
	 */
	public String getMrkPlaceInvolved() {
		return mrkPlaceInvolved;
	}

	/**
	 * Sets the mrk place involved.
	 *
	 * @param mrkPlaceInvolved the new mrk place involved
	 */
	public void setMrkPlaceInvolved(String mrkPlaceInvolved) {
		this.mrkPlaceInvolved = mrkPlaceInvolved;
	}

	/**
	 * Gets the buyer txn amt.
	 *
	 * @return the buyer txn amt
	 */
	public BigDecimal getBuyerTxnAmt() {
		return buyerTxnAmt;
	}

	/**
	 * Sets the buyer txn amt.
	 *
	 * @param buyerTxnAmt the new buyer txn amt
	 */
	public void setBuyerTxnAmt(BigDecimal buyerTxnAmt) {
		this.buyerTxnAmt = buyerTxnAmt;
	}

	/**
	 * Gets the buyer cust ref no.
	 *
	 * @return the buyer cust ref no
	 */
	public String getBuyerCustRefNo() {
		return buyerCustRefNo;
	}

	/**
	 * Sets the buyer cust ref no.
	 *
	 * @param buyerCustRefNo the new buyer cust ref no
	 */
	public void setBuyerCustRefNo(String buyerCustRefNo) {
		this.buyerCustRefNo = buyerCustRefNo;
	}

	/**
	 * Gets the mkt place acc iden.
	 *
	 * @return the mkt place acc iden
	 */
	public String getMktPlaceAccIden() {
		return mktPlaceAccIden;
	}

	/**
	 * Sets the mkt place acc iden.
	 *
	 * @param mktPlaceAccIden the new mkt place acc iden
	 */
	public void setMktPlaceAccIden(String mktPlaceAccIden) {
		this.mktPlaceAccIden = mktPlaceAccIden;
	}

	/**
	 * Gets the mkt place org id.
	 *
	 * @return the mkt place org id
	 */
	public String getMktPlaceOrgId() {
		return mktPlaceOrgId;
	}

	/**
	 * Sets the mkt place org id.
	 *
	 * @param mktPlaceOrgId the new mkt place org id
	 */
	public void setMktPlaceOrgId(String mktPlaceOrgId) {
		this.mktPlaceOrgId = mktPlaceOrgId;
	}

	/**
	 * Gets the batch id.
	 *
	 * @return the batch id
	 */
	public String getBatchId() {
		return batchId;
	}

	/**
	 * Sets the batch id.
	 *
	 * @param batchId the new batch id
	 */
	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	/**
	 * Gets the payment id.
	 *
	 * @return the payment id
	 */
	public String getPaymentId() {
		return paymentId;
	}

	/**
	 * Sets the payment id.
	 *
	 * @param paymentId the new payment id
	 */
	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	/**
	 * Gets the payment ref no.
	 *
	 * @return the payment ref no
	 */
	public String getPaymentRefNo() {
		return paymentRefNo;
	}

	/**
	 * Sets the payment ref no.
	 *
	 * @param paymentRefNo the new payment ref no
	 */
	public void setPaymentRefNo(String paymentRefNo) {
		this.paymentRefNo = paymentRefNo;
	}

	/**
	 * Gets the payment init dt.
	 *
	 * @return the payment init dt
	 */
	public Date getPaymentInitDt() {
		return paymentInitDt;
	}

	/**
	 * Sets the payment init dt.
	 *
	 * @param paymentInitDt the new payment init dt
	 */
	public void setPaymentInitDt(Date paymentInitDt) {
		this.paymentInitDt = paymentInitDt;
	}

	/**
	 * Gets the payment due dt.
	 *
	 * @return the payment due dt
	 */
	public Date getPaymentDueDt() {
		return paymentDueDt;
	}

	/**
	 * Sets the payment due dt.
	 *
	 * @param paymentDueDt the new payment due dt
	 */
	public void setPaymentDueDt(Date paymentDueDt) {
		this.paymentDueDt = paymentDueDt;
	}

	/**
	 * Gets the payment value dt.
	 *
	 * @return the payment value dt
	 */
	public Date getPaymentValueDt() {
		return paymentValueDt;
	}

	/**
	 * Sets the payment value dt.
	 *
	 * @param paymentValueDt the new payment value dt
	 */
	public void setPaymentValueDt(Date paymentValueDt) {
		this.paymentValueDt = paymentValueDt;
	}

	/**
	 * Gets the payment amt.
	 *
	 * @return the payment amt
	 */
	public BigDecimal getPaymentAmt() {
		return paymentAmt;
	}

	/**
	 * Sets the payment amt.
	 *
	 * @param paymentAmt the new payment amt
	 */
	public void setPaymentAmt(BigDecimal paymentAmt) {
		this.paymentAmt = paymentAmt;
	}

	/**
	 * Gets the payment ccy.
	 *
	 * @return the payment ccy
	 */
	public String getPaymentCcy() {
		return paymentCcy;
	}

	/**
	 * Sets the payment ccy.
	 *
	 * @param paymentCcy the new payment ccy
	 */
	public void setPaymentCcy(String paymentCcy) {
		this.paymentCcy = paymentCcy;
	}

	/**
	 * Gets the input branch.
	 *
	 * @return the input branch
	 */
	public String getInputBranch() {
		return inputBranch;
	}

	/**
	 * Sets the input branch.
	 *
	 * @param inputBranch the new input branch
	 */
	public void setInputBranch(String inputBranch) {
		this.inputBranch = inputBranch;
	}

	/**
	 * Gets the input ccy.
	 *
	 * @return the input ccy
	 */
	public String getInputCcy() {
		return inputCcy;
	}

	/**
	 * Sets the input ccy.
	 *
	 * @param inputCcy the new input ccy
	 */
	public void setInputCcy(String inputCcy) {
		this.inputCcy = inputCcy;
	}

	/**
	 * Gets the input pymt mthd.
	 *
	 * @return the input pymt mthd
	 */
	public String getInputPymtMthd() {
		return inputPymtMthd;
	}

	/**
	 * Sets the input pymt mthd.
	 *
	 * @param inputPymtMthd the new input pymt mthd
	 */
	public void setInputPymtMthd(String inputPymtMthd) {
		this.inputPymtMthd = inputPymtMthd;
	}

	/**
	 * Gets the sch type.
	 *
	 * @return the sch type
	 */
	public String getSchType() {
		return schType;
	}

	/**
	 * Sets the sch type.
	 *
	 * @param schType the new sch type
	 */
	public void setSchType(String schType) {
		this.schType = schType;
	}

	/**
	 * Gets the debit details list.
	 *
	 * @return the debit details list
	 */
	public List<PaymentInitiateAccountVO> getDebitDetailsList() {
		return debitDetailsList;
	}

	/**
	 * Sets the debit details list.
	 *
	 * @param debitDetailsList the new debit details list
	 */
	public void setDebitDetailsList(
			List<PaymentInitiateAccountVO> debitDetailsList) {
		this.debitDetailsList = debitDetailsList;
	}

	/**
	 * Gets the credit detail list.
	 *
	 * @return the credit detail list
	 */
	public List<PaymentInitiateAccountVO> getCreditDetailList() {
		return creditDetailList;
	}

	/**
	 * Sets the credit detail list.
	 *
	 * @param creditDetailList the new credit detail list
	 */
	public void setCreditDetailList(
			List<PaymentInitiateAccountVO> creditDetailList) {
		this.creditDetailList = creditDetailList;
	}

	/**
	 * Gets the checks if is split pymt.
	 *
	 * @return the checks if is split pymt
	 */
	public String getIsSplitPymt() {
		return isSplitPymt;
	}

	/**
	 * Sets the checks if is split pymt.
	 *
	 * @param isSplitPymt the new checks if is split pymt
	 */
	public void setIsSplitPymt(String isSplitPymt) {
		this.isSplitPymt = isSplitPymt;
	}

	/**
	 * Gets the split pymt amt.
	 *
	 * @return the split pymt amt
	 */
	public BigDecimal getSplitPymtAmt() {
		return splitPymtAmt;
	}

	/**
	 * Sets the split pymt amt.
	 *
	 * @param splitPymtAmt the new split pymt amt
	 */
	public void setSplitPymtAmt(BigDecimal splitPymtAmt) {
		this.splitPymtAmt = splitPymtAmt;
	}

	/**
	 * Gets the checks if is offline pymt.
	 *
	 * @return the checks if is offline pymt
	 */
	public String getIsOfflinePymt() {
		return isOfflinePymt;
	}

	/**
	 * Sets the checks if is offline pymt.
	 *
	 * @param isOfflinePymt the new checks if is offline pymt
	 */
	public void setIsOfflinePymt(String isOfflinePymt) {
		this.isOfflinePymt = isOfflinePymt;
	}

	/**
	 * Gets the pymt status.
	 *
	 * @return the pymt status
	 */
	public String getPymtStatus() {
		return pymtStatus;
	}

	/**
	 * Sets the pymt status.
	 *
	 * @param pymtStatus the new pymt status
	 */
	public void setPymtStatus(String pymtStatus) {
		this.pymtStatus = pymtStatus;
	}

	/**
	 * Gets the map id.
	 *
	 * @return the map id
	 */
	public String getMapId() {
		return mapId;
	}

	/**
	 * Sets the map id.
	 *
	 * @param mapId the new map id
	 */
	public void setMapId(String mapId) {
		this.mapId = mapId;
	}

	/**
	 * Gets the buyer acc map id.
	 *
	 * @return the buyer acc map id
	 */
	public String getBuyerAccMapId() {
		return buyerAccMapId;
	}

	/**
	 * Sets the buyer acc map id.
	 *
	 * @param buyerAccMapId the new buyer acc map id
	 */
	public void setBuyerAccMapId(String buyerAccMapId) {
		this.buyerAccMapId = buyerAccMapId;
	}

	/**
	 * Gets the supplier acc map id.
	 *
	 * @return the supplier acc map id
	 */
	public String getSupplierAccMapId() {
		return supplierAccMapId;
	}

	/**
	 * Sets the supplier acc map id.
	 *
	 * @param supplierAccMapId the new supplier acc map id
	 */
	public void setSupplierAccMapId(String supplierAccMapId) {
		this.supplierAccMapId = supplierAccMapId;
	}

	/**
	 * Gets the mkt place acc map id.
	 *
	 * @return the mkt place acc map id
	 */
	public String getMktPlaceAccMapId() {
		return mktPlaceAccMapId;
	}

	/**
	 * Sets the mkt place acc map id.
	 *
	 * @param mktPlaceAccMapId the new mkt place acc map id
	 */
	public void setMktPlaceAccMapId(String mktPlaceAccMapId) {
		this.mktPlaceAccMapId = mktPlaceAccMapId;
	}

	/**
	 * Sets the remarks.
	 *
	 * @param remarks the new remarks
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * Gets the remarks.
	 *
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * Gets the hdr country.
	 *
	 * @return the hdr country
	 */
	public String getHdrCountry() {
		return hdrCountry;
	}

	/**
	 * Sets the hdr country.
	 *
	 * @param hdrCountry the new hdr country
	 */
	public void setHdrCountry(String hdrCountry) {
		this.hdrCountry = hdrCountry;
	}

	/**
	 * Gets the hdr bank code.
	 *
	 * @return the hdr bank code
	 */
	public String getHdrBankCode() {
		return hdrBankCode;
	}

	/**
	 * Sets the hdr bank code.
	 *
	 * @param hdrBankCode the new hdr bank code
	 */
	public void setHdrBankCode(String hdrBankCode) {
		this.hdrBankCode = hdrBankCode;
	}

	/**
	 * Gets the hdr branch code.
	 *
	 * @return the hdr branch code
	 */
	public String getHdrBranchCode() {
		return hdrBranchCode;
	}

	/**
	 * Sets the hdr branch code.
	 *
	 * @param hdrBranchCode the new hdr branch code
	 */
	public void setHdrBranchCode(String hdrBranchCode) {
		this.hdrBranchCode = hdrBranchCode;
	}

	public String getPayThrowMktPlace() {
		return payThrowMktPlace;
	}

	public void setPayThrowMktPlace(String payThrowMktPlace) {
		this.payThrowMktPlace = payThrowMktPlace;
	}

	
	
	
}
