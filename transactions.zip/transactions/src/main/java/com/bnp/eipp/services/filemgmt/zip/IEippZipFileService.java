/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   20 Sep 2012
 * 
 * Purpose:      IEippZipFileService
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 20 Sep 2012        Oracle Financial Services Software Ltd                  Initial Version   
 * 17 Oct 2012		  Prabakaran S											  Fix for ST Defect # 6793
************************************************************************************************************************************************************/
package com.bnp.eipp.services.filemgmt.zip;

import com.bnp.scm.services.common.ITransactionService;
import com.bnp.scm.services.common.exception.BNPApplicationException;

/**
 * @author prabakarans
 *
 */
public interface IEippZipFileService extends ITransactionService {
	
	void saveAttachments(long fileId, String fileType, 
				String userId)throws BNPApplicationException;

}
