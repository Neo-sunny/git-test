package com.bnp.eipp.services.matching.payment.bindingvo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for ErrorMessage complex type.
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ErrorMessage">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ErrorCode" type="{}Max35Text"/>
 *         &lt;element name="ErrorDesc" type="{}Max4000Text"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ErrorMessage", propOrder = { "errorCode", "errorDesc" })
public class ErrorMessage {

	@XmlElement(name = "ErrorCode", required = true)
	protected String errorCode;

	@XmlElement(name = "ErrorDesc", required = true)
	protected String errorDesc;

	/**
	 * Gets the value of the errorCode property.
	 * @return possible object is {@link String }
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * Sets the value of the errorCode property.
	 * @param value allowed object is {@link String }
	 */
	public void setErrorCode(String value) {
		this.errorCode = value;
	}

	/**
	 * Gets the value of the errorDesc property.
	 * @return possible object is {@link String }
	 */
	public String getErrorDesc() {
		return errorDesc;
	}

	/**
	 * Sets the value of the errorDesc property.
	 * @param value allowed object is {@link String }
	 */
	public void setErrorDesc(String value) {
		this.errorDesc = value;
	}

}
