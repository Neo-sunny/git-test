/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 22, 201210:43:18 PM
 * 
 * Purpose:      DisputeVO.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 22, 201210:43:18 PM        Oracle Financial Services Software Ltd                  Initial Version
 * 03 Aug 2012					  Reena S								Release 3.0		  EIPP PhaseII-Release File Inq Changes  
 * 26 Sep 2012					  Dinesh D								Release 3.0		  MFU - EIPP Disputes   
************************************************************************************************************************************************************/

package com.bnp.eipp.services.vo.dispute;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.bnp.eipp.services.invoice.vo.EippAuditVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.invoice.vo.EippTransactionVO;
import com.bnp.scm.services.common.util.CacheConstants;
import com.bnp.scm.services.common.vo.AttachmentVO;
import com.bnp.scm.services.txns.util.calendar.DateAdapter;

/**
 * The Class DisputeVO.
 */
public class DisputeVO extends EippTransactionVO {
	
	private static final long serialVersionUID = 1L;

	private long disputeId;
	
	private EippInvoiceVO eippInvoice;
	
	private String dispRefNo;
	
	private String custRefNo;
	
	private String dispReasonCode;
	
	private String otherReasons;
	
	private String supplierMemo;
	
	private String buyerMemo;
	
	private String dispStatus;
	
	private String resolvedBy;
	
	private String resolvedDate;
	
	private String raisedBy;
	
	private Date raisedDate;
	
	private String resolutionApprovedBy;
	
	private Date resolutionApprovedDate;
	
	private String disputeApprovedBy;
	
	private String disputeApprovedDate;
	
	private String disputedAt;

	private String buyerOrgId;
	
	private String buyerOrgName;
	
	private String supplierOrgName;
	
	private String billType;
	
	private List<String> disputeStatusList;
	
	private List<String> approverDepts;
	
	private List<String> approverUserIds;
	
	private int attachmentCount;
	
	private String lineItemNo;
	
	private BigDecimal oldNetAmt;
	
	private BigDecimal newNetAmt;
	
	private Timestamp processTimestamp;
	
	private String disputeCodeDesc;
	
	private List<AttachmentVO> attachments;
	
	private List<DisputeCustFieldsVO> custFieldsList;
	
	private String resolutionCode;
	
	private String otherResolutionReason;
	
	private String telephone;
	
	private String fax;
	
	private String forAttention;
	
	private String buyerAddress;
	
	private String actionRequired;
	
	private long lineItemId;
	
	private byte[] logoData;
	
	private List<DisputeAllocationMappingVO> existingAssignees;
	
	private List<AttachmentVO> supplierAttachments;
	
	private List<EippAuditVO> invoiceAuditList;
	
	private String deptId;
	
	private String itemDesc;
	
	private String orgRole;
	
	private String action;
	
	private String supplierMakerUserID;
	
	private String supplierApproverUserID;
	
	private String buyerMakerId;
	
	private String buyerApproverId;
	
	private String errorCode;
	
	private String errorDesc;
	
	private String newNetAmtCcy;
	
	private String oldNetAmtCcy;
	
	//Added for EIPP-Phase II :MFU-Raise Dispute
	private String invoiceRefNo;
	private Date invoiceRefDate;
	private String disputeType;
	
	
	private String refNo;
	private Date pymtFeedBkDate;
	private BigDecimal pymtAmt;
	private String pymtCcy;
	private String pymtStatus;
	
	private String codeType;
	
	/**
	 * Instantiates a new dispute vo.
	 */
	public DisputeVO() {
		this.eippInvoice = new EippInvoiceVO(); 
		this.setAttachments(new ArrayList<AttachmentVO>());
		this.setCustFieldsList(new ArrayList<DisputeCustFieldsVO>());
		this.supplierAttachments = new ArrayList<AttachmentVO>();
	}
	
	/**
	 * Gets the dispute id.
	 *
	 * @return the disputeId
	 */
	public long getDisputeId() {
		return disputeId;
	}

	/**
	 * Sets the dispute id.
	 *
	 * @param disputeId the disputeId to set
	 */
	public void setDisputeId(long disputeId) {
		this.disputeId = disputeId;
	}

	/**
	 * Gets the disp ref no.
	 *
	 * @return the dispRefNo
	 */
	public String getDispRefNo() {
		return dispRefNo;
	}

	/**
	 * Sets the disp ref no.
	 *
	 * @param dispRefNo the dispRefNo to set
	 */
	public void setDispRefNo(String dispRefNo) {
		this.dispRefNo = dispRefNo;
	}

	/**
	 * Gets the cust ref no.
	 *
	 * @return the custRefNo
	 */
	public String getCustRefNo() {
		return custRefNo;
	}

	/**
	 * Sets the cust ref no.
	 *
	 * @param custRefNo the custRefNo to set
	 */
	public void setCustRefNo(String custRefNo) {
		this.custRefNo = custRefNo;
	}

	/**
	 * Gets the disp reason code.
	 *
	 * @return the dispReasonCode
	 */
	public String getDispReasonCode() {
		return dispReasonCode;
	}

	/**
	 * Sets the disp reason code.
	 *
	 * @param dispReasonCode the dispReasonCode to set
	 */
	public void setDispReasonCode(String dispReasonCode) {
		this.dispReasonCode = dispReasonCode;
	}

	/**
	 * Gets the other reasons.
	 *
	 * @return the otherReasons
	 */
	public String getOtherReasons() {
		return otherReasons;
	}

	/**
	 * Sets the other reasons.
	 *
	 * @param otherReasons the otherReasons to set
	 */
	public void setOtherReasons(String otherReasons) {
		this.otherReasons = otherReasons;
	}

	/**
	 * Gets the supplier memo.
	 *
	 * @return the supplierMemo
	 */
	public String getSupplierMemo() {
		return supplierMemo;
	}

	/**
	 * Sets the supplier memo.
	 *
	 * @param supplierMemo the supplierMemo to set
	 */
	public void setSupplierMemo(String supplierMemo) {
		this.supplierMemo = supplierMemo;
	}

	/**
	 * Gets the buyer memo.
	 *
	 * @return the buyerMemo
	 */
	public String getBuyerMemo() {
		return buyerMemo;
	}

	/**
	 * Sets the buyer memo.
	 *
	 * @param buyerMemo the buyerMemo to set
	 */
	public void setBuyerMemo(String buyerMemo) {
		this.buyerMemo = buyerMemo;
	}

	/**
	 * Gets the disp status.
	 *
	 * @return the dispStatus
	 */
	public String getDispStatus() {
		return dispStatus;
	}

	/**
	 * Sets the disp status.
	 *
	 * @param dispStatus the dispStatus to set
	 */
	public void setDispStatus(String dispStatus) {
		this.dispStatus = dispStatus;
	}

	/**
	 * Gets the resolved by.
	 *
	 * @return the resolvedBy
	 */
	public String getResolvedBy() {
		return resolvedBy;
	}

	/**
	 * Sets the resolved by.
	 *
	 * @param resolvedBy the resolvedBy to set
	 */
	public void setResolvedBy(String resolvedBy) {
		this.resolvedBy = resolvedBy;
	}

	/**
	 * Gets the resolved date.
	 *
	 * @return the resolvedDate
	 */
	public String getResolvedDate() {
		return resolvedDate;
	}

	/**
	 * Sets the resolved date.
	 *
	 * @param resolvedDate the resolvedDate to set
	 */
	public void setResolvedDate(String resolvedDate) {
		this.resolvedDate = resolvedDate;
	}

	/**
	 * Gets the raised by.
	 *
	 * @return the raisedBy
	 */
	public String getRaisedBy() {
		return raisedBy;
	}

	/**
	 * Sets the raised by.
	 *
	 * @param raisedBy the raisedBy to set
	 */
	public void setRaisedBy(String raisedBy) {
		this.raisedBy = raisedBy;
	}

	/**
	 * Gets the raised date.
	 *
	 * @return the raisedDate
	 */
	public Date getRaisedDate() {
		return raisedDate;
	}

	/**
	 * Sets the raised date.
	 *
	 * @param raisedDate the raisedDate to set
	 */
	public void setRaisedDate(Date raisedDate) {
		this.raisedDate = raisedDate;
	}

	/**
	 * Gets the resolution approved by.
	 *
	 * @return the resolutionApprovedBy
	 */
	public String getResolutionApprovedBy() {
		return resolutionApprovedBy;
	}

	/**
	 * Sets the resolution approved by.
	 *
	 * @param resolutionApprovedBy the resolutionApprovedBy to set
	 */
	public void setResolutionApprovedBy(String resolutionApprovedBy) {
		this.resolutionApprovedBy = resolutionApprovedBy;
	}

	/**
	 * Gets the resolution approved date.
	 *
	 * @return the resolutionApprovedDate
	 */
	public Date getResolutionApprovedDate() {
		return resolutionApprovedDate;
	}

	/**
	 * Sets the resolution approved date.
	 *
	 * @param resolutionApprovedDate the resolutionApprovedDate to set
	 */
	public void setResolutionApprovedDate(Date resolutionApprovedDate) {
		this.resolutionApprovedDate = resolutionApprovedDate;
	}

	/**
	 * Gets the dispute approved by.
	 *
	 * @return the disputeApprovedBy
	 */
	public String getDisputeApprovedBy() {
		return disputeApprovedBy;
	}

	/**
	 * Sets the dispute approved by.
	 *
	 * @param disputeApprovedBy the disputeApprovedBy to set
	 */
	public void setDisputeApprovedBy(String disputeApprovedBy) {
		this.disputeApprovedBy = disputeApprovedBy;
	}

	/**
	 * Gets the dispute approved date.
	 *
	 * @return the disputeApprovedDate
	 */
	public String getDisputeApprovedDate() {
		return disputeApprovedDate;
	}

	/**
	 * Sets the dispute approved date.
	 *
	 * @param disputeApprovedDate the disputeApprovedDate to set
	 */
	public void setDisputeApprovedDate(String disputeApprovedDate) {
		this.disputeApprovedDate = disputeApprovedDate;
	}

	/**
	 * Gets the disputed at.
	 *
	 * @return the disputedAt
	 */
	public String getDisputedAt() {
		return disputedAt;
	}

	/**
	 * Sets the disputed at.
	 *
	 * @param disputedAt the disputedAt to set
	 */
	public void setDisputedAt(String disputedAt) {
		this.disputedAt = disputedAt;
	}

	/**
	 * Sets the buyer org id.
	 *
	 * @param buyerOrgId the buyerOrgId to set
	 */
	public void setBuyerOrgId(String buyerOrgId) {
		this.buyerOrgId = buyerOrgId;
	}

	/**
	 * Gets the buyer org id.
	 *
	 * @return the buyerOrgId
	 */
	public String getBuyerOrgId() {
		return buyerOrgId;
	}

	/**
	 * Gets the buyer org name.
	 *
	 * @return the buyerOrgName
	 */
	public String getBuyerOrgName() {
		return buyerOrgName;
	}

	/**
	 * Sets the buyer org name.
	 *
	 * @param buyerOrgName the buyerOrgName to set
	 */
	public void setBuyerOrgName(String buyerOrgName) {
		this.buyerOrgName = buyerOrgName;
	}

	/**
	 * Gets the supplier org name.
	 *
	 * @return the supplierOrgName
	 */
	public String getSupplierOrgName() {
		return supplierOrgName;
	}

	/**
	 * Sets the supplier org name.
	 *
	 * @param supplierOrgName the supplierOrgName to set
	 */
	public void setSupplierOrgName(String supplierOrgName) {
		this.supplierOrgName = supplierOrgName;
	}

	/**
	 * Gets the bill type.
	 *
	 * @return the billType
	 */
	public String getBillType() {
		return billType;
	}

	/**
	 * Sets the bill type.
	 *
	 * @param billType the billType to set
	 */
	public void setBillType(String billType) {
		this.billType = billType;
	}

	/**
	 * Gets the eipp invoice.
	 *
	 * @return the eipp invoice
	 */
	public EippInvoiceVO getEippInvoice() {
		return eippInvoice;
	}

	/**
	 * Sets the eipp invoice.
	 *
	 * @param eippInvoice the new eipp invoice
	 */
	public void setEippInvoice(EippInvoiceVO eippInvoice) {
		this.eippInvoice = eippInvoice;
	}

	/**
	 * Gets the dispute status list.
	 *
	 * @return the dispute status list
	 */
	public List<String> getDisputeStatusList() {
		return disputeStatusList;
	}

	/**
	 * Sets the dispute status list.
	 *
	 * @param disputeStatusList the new dispute status list
	 */
	public void setDisputeStatusList(List<String> disputeStatusList) {
		this.disputeStatusList = disputeStatusList;
	}

	/**
	 * Gets the attachment count.
	 *
	 * @return the attachment count
	 */
	public int getAttachmentCount() {
		return attachmentCount;
	}

	/**
	 * Sets the attachment count.
	 *
	 * @param attachmentCount the new attachment count
	 */
	public void setAttachmentCount(int attachmentCount) {
		this.attachmentCount = attachmentCount;
	}

	/**
	 * Gets the line item no.
	 *
	 * @return the line item no
	 */
	public String getLineItemNo() {
		return lineItemNo;
	}

	/**
	 * Sets the line item no.
	 *
	 * @param lineItemNo the new line item no
	 */
	public void setLineItemNo(String lineItemNo) {
		this.lineItemNo = lineItemNo;
	}

	/**
	 * Gets the approver depts.
	 *
	 * @return the approverDepts
	 */
	public List<String> getApproverDepts() {
		return approverDepts;
	}

	/**
	 * Sets the approver depts.
	 *
	 * @param approverDepts the approverDepts to set
	 */
	public void setApproverDepts(List<String> approverDepts) {
		this.approverDepts = approverDepts;
	}

	/**
	 * Gets the approver user ids.
	 *
	 * @return the approverUserIds
	 */
	public List<String> getApproverUserIds() {
		return approverUserIds;
	}

	/**
	 * Sets the approver user ids.
	 *
	 * @param approverUserIds the approverUserIds to set
	 */
	public void setApproverUserIds(List<String> approverUserIds) {
		this.approverUserIds = approverUserIds;
	}

	/**
	 * Gets the old net amt.
	 *
	 * @return the oldNetAmt
	 */
	public BigDecimal getOldNetAmt() {
		return oldNetAmt;
	}

	/**
	 * Sets the old net amt.
	 *
	 * @param oldNetAmt the oldNetAmt to set
	 */
	public void setOldNetAmt(BigDecimal oldNetAmt) {
		this.oldNetAmt = oldNetAmt;
	}

	/**
	 * Gets the new net amt.
	 *
	 * @return the newNetAmt
	 */
	public BigDecimal getNewNetAmt() {
		return newNetAmt;
	}

	/**
	 * Sets the new net amt.
	 *
	 * @param newNetAmt the newNetAmt to set
	 */
	public void setNewNetAmt(BigDecimal newNetAmt) {
		this.newNetAmt = newNetAmt;
	}

	/**
	 * Gets the process timestamp.
	 *
	 * @return the processTimestamp
	 */
	public Timestamp getProcessTimestamp() {
		return processTimestamp;
	}

	/**
	 * Sets the process timestamp.
	 *
	 * @param processTimestamp the processTimestamp to set
	 */
	public void setProcessTimestamp(Timestamp processTimestamp) {
		this.processTimestamp = processTimestamp;
	}

	
	/**
	 * Gets the line item id.
	 *
	 * @return the lineItemId
	 */
	public long getLineItemId() {
		return lineItemId;
	}

	
	/**
	 * Sets the line item id.
	 *
	 * @param lineItemId the lineItemId to set
	 */
	public void setLineItemId(long lineItemId) {
		this.lineItemId = lineItemId;
	}

	
	/**
	 * Gets the dispute code desc.
	 *
	 * @return the disputeCodeDesc
	 */
	public String getDisputeCodeDesc() {
		return disputeCodeDesc;
	}

	
	/**
	 * Sets the dispute code desc.
	 *
	 * @param disputeCodeDesc the disputeCodeDesc to set
	 */
	public void setDisputeCodeDesc(String disputeCodeDesc) {
		this.disputeCodeDesc = disputeCodeDesc;
	}

	/**
	 * Sets the attachments.
	 *
	 * @param attachments the attachments to set
	 */
	public void setAttachments(List<AttachmentVO> attachments) {
		this.attachments = attachments;
	}

	/**
	 * Gets the attachments.
	 *
	 * @return the attachments
	 */
	public List<AttachmentVO> getAttachments() {
		return attachments;
	}

	/**
	 * Sets the cust fields list.
	 *
	 * @param custFieldsList the custFieldsList to set
	 */
	public void setCustFieldsList(List<DisputeCustFieldsVO> custFieldsList) {
		this.custFieldsList = custFieldsList;
	}

	/**
	 * Gets the cust fields list.
	 *
	 * @return the custFieldsList
	 */
	public List<DisputeCustFieldsVO> getCustFieldsList() {
		return custFieldsList;
	}

	/**
	 * Gets the resolution code.
	 *
	 * @return the resolution code
	 */
	public String getResolutionCode() {
		return resolutionCode;
	}

	/**
	 * Sets the resolution code.
	 *
	 * @param resolutionCode the new resolution code
	 */
	public void setResolutionCode(String resolutionCode) {
		this.resolutionCode = resolutionCode;
	}

	/**
	 * Gets the other resolution reason.
	 *
	 * @return the other resolution reason
	 */
	public String getOtherResolutionReason() {
		return otherResolutionReason;
	}

	/**
	 * Sets the other resolution reason.
	 *
	 * @param otherResolutionReason the new other resolution reason
	 */
	public void setOtherResolutionReason(String otherResolutionReason) {
		this.otherResolutionReason = otherResolutionReason;
	}

	/**
	 * Gets the telephone.
	 *
	 * @return the telephone
	 */
	public String getTelephone() {
		return telephone;
	}

	/**
	 * Sets the telephone.
	 *
	 * @param telephone the new telephone
	 */
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	/**
	 * Gets the fax.
	 *
	 * @return the fax
	 */
	public String getFax() {
		return fax;
	}

	/**
	 * Sets the fax.
	 *
	 * @param fax the new fax
	 */
	public void setFax(String fax) {
		this.fax = fax;
	}

	/**
	 * Gets the for attention.
	 *
	 * @return the for attention
	 */
	public String getForAttention() {
		return forAttention;
	}

	/**
	 * Sets the for attention.
	 *
	 * @param forAttention the new for attention
	 */
	public void setForAttention(String forAttention) {
		this.forAttention = forAttention;
	}

	/**
	 * Gets the buyer address.
	 *
	 * @return the buyer address
	 */
	public String getBuyerAddress() {
		return buyerAddress;
	}

	/**
	 * Sets the buyer address.
	 *
	 * @param buyerAddress the new buyer address
	 */
	public void setBuyerAddress(String buyerAddress) {
		this.buyerAddress = buyerAddress;
	}

	/**
	 * Gets the action required.
	 *
	 * @return the action required
	 */
	public String getActionRequired() {
		return actionRequired;
	}

	/**
	 * Sets the action required.
	 *
	 * @param actionRequired the new action required
	 */
	public void setActionRequired(String actionRequired) {
		this.actionRequired = actionRequired;
	}

	/**
	 * Gets the logo data.
	 *
	 * @return the logo data
	 */
	public byte[] getLogoData() {
		return logoData;
	}

	/**
	 * Sets the logo data.
	 *
	 * @param logoData the new logo data
	 */
	public void setLogoData(byte[] logoData) {
		this.logoData = copyArray(logoData);
	}

	/**
	 * Gets the existing assignees.
	 *
	 * @return the existing assignees
	 */
	public List<DisputeAllocationMappingVO> getExistingAssignees() {
		return existingAssignees;
	}

	/**
	 * Sets the existing assignees.
	 *
	 * @param existingAssignees the new existing assignees
	 */
	public void setExistingAssignees(
			List<DisputeAllocationMappingVO> existingAssignees) {
		this.existingAssignees = existingAssignees;
	}

	/**
	 * Gets the supplier attachments.
	 *
	 * @return the supplier attachments
	 */
	public List<AttachmentVO> getSupplierAttachments() {
		return supplierAttachments;
	}

	/**
	 * Sets the supplier attachments.
	 *
	 * @param supplierAttachments the new supplier attachments
	 */
	public void setSupplierAttachments(List<AttachmentVO> supplierAttachments) {
		this.supplierAttachments = supplierAttachments;
	}
	
	/**
	 * @param invoiceAuditList the invoiceAuditList to set
	 */
	public void setInvoiceAuditList(List<EippAuditVO> invoiceAuditList) {
		this.invoiceAuditList = invoiceAuditList;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	public String getDeptId() {
		return deptId;
	}

	/**
	 * @return the invoiceAuditList
	 */
	public List<EippAuditVO> getInvoiceAuditList() {
		return invoiceAuditList;
	}

	public boolean addAttachment(AttachmentVO attachmentVO) {
		return attachments.add(attachmentVO);
	}
	
	public boolean addSupplierAttachment(AttachmentVO attachmentVO) {
		return supplierAttachments.add(attachmentVO);
	}

	/**
	 * @param itemDesc the itemDesc to set
	 */
	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	/**
	 * @return the itemDesc
	 */
	public String getItemDesc() {
		return itemDesc;
	}

	public void setOrgRole(String orgRole) {
		this.orgRole = orgRole;
	}

	public String getOrgRole() {
		return orgRole;
	}

	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}

	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public Date getPymtFeedBkDate() {
		return pymtFeedBkDate;
	}

	public void setPymtFeedBkDate(Date pymtFeedBkDate) {
		this.pymtFeedBkDate = pymtFeedBkDate;
	}

	public BigDecimal getPymtAmt() {
		return pymtAmt;
	}

	public void setPymtAmt(BigDecimal pymtAmt) {
		this.pymtAmt = pymtAmt;
	}

	public String getPymtCcy() {
		return pymtCcy;
	}

	public void setPymtCcy(String pymtCcy) {
		this.pymtCcy = pymtCcy;
	}

	public String getPymtStatus() {
		return pymtStatus;
	}

	public void setPymtStatus(String pymtStatus) {
		this.pymtStatus = pymtStatus;
	}



	public Date getInvoiceRefDate() {
		return invoiceRefDate;
	}

	public void setInvoiceRefDate(Date invoiceRefDate) {
		this.invoiceRefDate = invoiceRefDate;
	}

	public String getDisputeType() {
		return disputeType;
	}

	public void setDisputeType(String disputeType) {
		this.disputeType = disputeType;
	}

	public String getInvoiceRefNo() {
		return invoiceRefNo;
	}

	public void setInvoiceRefNo(String invoiceRefNo) {
		this.invoiceRefNo = invoiceRefNo;
	}
	
	public String getSupplierMakerUserID() {
		return supplierMakerUserID;
	}

	public void setSupplierMakerUserID(String supplierMakerUserID) {
		this.supplierMakerUserID = supplierMakerUserID;
	}

	public String getSupplierApproverUserID() {
		return supplierApproverUserID;
	}

	public void setSupplierApproverUserID(String supplierApproverUserID) {
		this.supplierApproverUserID = supplierApproverUserID;
	}

	public String getBuyerMakerId() {
		return buyerMakerId;
	}

	public void setBuyerMakerId(String buyerMakerId) {
		this.buyerMakerId = buyerMakerId;
	}

	public String getBuyerApproverId() {
		return buyerApproverId;
	}

	public void setBuyerApproverId(String buyerApproverId) {
		this.buyerApproverId = buyerApproverId;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	public String getNewNetAmtCcy() {
		return newNetAmtCcy;
	}

	public void setNewNetAmtCcy(String newNetAmtCcy) {
		this.newNetAmtCcy = newNetAmtCcy;
	}

	public String getOldNetAmtCcy() {
		return oldNetAmtCcy;
	}

	public void setOldNetAmtCcy(String oldNetAmtCcy) {
		this.oldNetAmtCcy = oldNetAmtCcy;
	}

	public String toDataString() {
		DateAdapter adapter = new DateAdapter();
		Calendar calendar = Calendar.getInstance();
		StringBuilder builder = new StringBuilder();
		builder.append( CacheConstants.EIPP_DISPUTE);
		builder.append(",");
		builder.append(this.eippInvoice.getRefNo());
		builder.append(",");
		builder.append( getSupplierOrgId());
		builder.append(",");
		builder.append( getBuyerOrgId());
		builder.append(",");
		if(getIssueDate() != null) {
			calendar.setTime(getIssueDate());
			builder.append( adapter.marshal(calendar));
			builder.append(",");
		} else {
			builder.append(",");
		}
		builder.append( getBillType());
		if(getRefDate() != null) {
			calendar.setTime(getRefDate());
			builder.append( adapter.marshal(calendar));
			builder.append(",");
		} else {
			builder.append(",");
		}
		return builder.toString();
	}

	public String getCodeType() {
		return codeType;
	}

	public void setCodeType(String codeType) {
		this.codeType = codeType;
	}		
}
