/** ************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 03, 2012
 * 
 * Purpose:      EippCntGroupProcessor.java 
 * 
 * Change History: 
 * Date                                                  Author                                                                                  Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 03, 2012                      Oracle Financial Services Software Ltd                                    Initial Version 
 * 07 Aug 2012						Vinoth Kumar M															  Sony Performance Tuning
 * 12 Oct 2012						Merdith 														  		Method Parameter changed for validating line item
 ***************************************************************************************************************************************************/

package com.bnp.eipp.services.invoice.group;


import java.util.ArrayList;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.invoice.bindingvo.AdditionalInformation1;
import com.bnp.eipp.services.invoice.bindingvo.AdditionalInformation6;
import com.bnp.eipp.services.invoice.bindingvo.DocumentIdentification25;
import com.bnp.eipp.services.invoice.bindingvo.FinancialCreditNoteV01;
import com.bnp.eipp.services.invoice.bindingvo.LineItem10;
import com.bnp.eipp.services.invoice.bindingvo.TradeDelivery1;
import com.bnp.eipp.services.invoice.vo.AddressVO;
import com.bnp.eipp.services.invoice.vo.EippCreditNoteVO;
import com.bnp.eipp.services.invoice.vo.EippCustFieldsVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.bindingvo.PostalAddress6;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;

@Component
@Scope ("prototype")
public class EippCntGroupProcessor<T> extends 
					EippGroupProcessor<EippCreditNoteVO> {
	
	public EippCntGroupProcessor(){
		super();
	}

	private List<FinancialCreditNoteV01> objectList;
	
	/**
	 * @return the objectList
	 */
	public List<FinancialCreditNoteV01> getObjectList() {
		return objectList;
	}

	/**
	 * @param objectList the objectList to set
	 */
	public void setObjectList(List<FinancialCreditNoteV01> objectList) {
		this.objectList = objectList;
	}
	
	private void populateMappingFiles() {
		mappingFiles = new ArrayList<String>();
		
		mappingFiles.add("mapper/EippCntMapper.xml");
		mappingFiles.add("mapper/EippInvMapper.xml");
		mappingFiles.add("mapper/EippLineItemMapper.xml");
		mappingFiles.add("mapper/EippCustFieldMapper.xml");
		mappingFiles.add("mapper/EippCustItmFldMapper.xml");
		mappingFiles.add("mapper/EippAddrMapper.xml"); 
		mappingFiles.add("mapper/EippAttachmentDataMapper.xml");
		
		beanMapper = new DozerBeanMapper(mappingFiles);
	}

	@Override
	public void processAndValidateData() throws BNPApplicationException {
		
		populateMappingFiles();
		
		List<EippCreditNoteVO> cntList = new ArrayList<EippCreditNoteVO>();
		for (FinancialCreditNoteV01 creditNoteObj : objectList) {
			
			EippCreditNoteVO eippCreditNoteVO = beanMapper.map(
					creditNoteObj, EippCreditNoteVO.class);
			
			populateInvcDetails(creditNoteObj.getTradSttlm().getInvcRefdDoc(), eippCreditNoteVO);
			
			if (creditNoteObj.getTradDlvry() != null) {
				populateAddressDetails(creditNoteObj.getTradDlvry(), eippCreditNoteVO);
			}
			
			for (AdditionalInformation6 customField : creditNoteObj.getCrNtHdr().getInclNote()) {
				EippCustFieldsVO custFieldVO = beanMapper.map(
						customField, EippCustFieldsVO.class);
				eippCreditNoteVO.getCustFields().add(custFieldVO);
			}
			
			for (LineItem10 lineItem : creditNoteObj.getLineItm()) {
				
				EippInvCntLineItemVO eippInvCntLineItemVO = beanMapper.map(
										lineItem, EippInvCntLineItemVO.class);
				
				for (AdditionalInformation1 customLtmField : lineItem.getInclNote()) {
					EippCustFieldsVO custItmFieldVO = beanMapper.map(
							customLtmField, EippCustFieldsVO.class);
					eippInvCntLineItemVO.getCustFields().add(custItmFieldVO);
				}
				eippCreditNoteVO.getLineItemList().add(eippInvCntLineItemVO);
			}
			cntList.add(eippCreditNoteVO);
		}
		validateCreditNotes(cntList);
		
	}
	
	private void populateInvcDetails(List<DocumentIdentification25> invcDocs,EippCreditNoteVO eippCreditNoteVO) {
		
		for (DocumentIdentification25 documentIdentification25 : invcDocs) {
			
			if (documentIdentification25.getRefType().equals("ORIGINAL")) {
				eippCreditNoteVO.setOrgInvBillType(documentIdentification25.getBillType());
				eippCreditNoteVO.setOrgInvRefNo(documentIdentification25.getId());
				eippCreditNoteVO.setOrgInvRefDate(documentIdentification25.getDtOfIsse().getTime());
			} else if (documentIdentification25.getRefType().equals("LINKED")) {
				eippCreditNoteVO.setLinkedInvBillType(documentIdentification25.getBillType());
				eippCreditNoteVO.setLinkedInvRefNo(documentIdentification25.getId());
				eippCreditNoteVO.setLinkedInvRefDate(documentIdentification25.getDtOfIsse().getTime());
			}
		}
	}
	
	private void populateAddressDetails(TradeDelivery1 tradeDelivery,EippCreditNoteVO eippCreditNoteVO) {
		
		if (tradeDelivery.getBillTo() != null && tradeDelivery.getBillTo().getPstlAdr() != null) {
			eippCreditNoteVO.setBillToAddr(getAddress(tradeDelivery.getBillTo().getPstlAdr()));
		}
		if (tradeDelivery.getShipTo() != null && tradeDelivery.getShipTo().getPstlAdr() != null) {
			eippCreditNoteVO.setShipToAddr(getAddress(tradeDelivery.getShipTo().getPstlAdr()));
		}
				
	}
	
	/**
	 * Validate credit notes.
	 *
	 * @param cntList the cnt list
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void validateCreditNotes(List<EippCreditNoteVO> cntList) throws BNPApplicationException {
		List<EippCreditNoteVO> transList = new ArrayList<EippCreditNoteVO>();
		
		for (EippCreditNoteVO eippCreditNoteVO : cntList) {
			boolean isInvalid = false;
			
			isInvalid = validateOrgData(eippCreditNoteVO);
			
			if (isInvalid) {
				validInvalidList.add(eippCreditNoteVO);
				continue;
			}
			
			if(detailsVO.getSenderOrgType().equals(BNPConstants.MARKET_PLACE)){
				isInvalid = checkAllRecordHasSameCustomer(cntList,eippCreditNoteVO) || isInvalid ;
			}
			
			isInvalid = validateLineItemsData(eippCreditNoteVO,null );// Added for validating line item amounts
			
			isInvalid = validateLinkedInvoiceDets(eippCreditNoteVO) || isInvalid;
			
			if (isIssueDateFutureDate(eippCreditNoteVO.getIssueDate(), detailsVO.getTimeZoneTZ())) {
				
				addToErrorDataList(eippCreditNoteVO.getTransactionType(), eippCreditNoteVO.toDataString(), 
						ErrorConstants.ISSUE_DATE_SHOULD_NOT_FUTURE, eippCreditNoteVO);
				isInvalid = true;
			}
			
			if (eippCreditNoteVO.getEffectiveDate() == null) {
				eippCreditNoteVO.setEffectiveDate(eippCreditNoteVO.getIssueDate());
			}
			if (eippCreditNoteVO.getRefDate() == null) {
				eippCreditNoteVO.setRefDate(eippCreditNoteVO.getIssueDate());
			}
			isInvalid = validateCreditNoteAmounts(eippCreditNoteVO) || isInvalid;
			isInvalid = validateUniqueReference(eippCreditNoteVO, transList) || isInvalid;
			isInvalid = validateLinkedInvCount(eippCreditNoteVO) || isInvalid;
			
			if (!isInvalid) {
				eippCreditNoteVO.setFractionalDigits(invoiceUploadService.getCurrencyDecimals
						(eippCreditNoteVO.getCcyCode()));
				eippCreditNoteVO.setRecordStatus("A");
				dataList.add(eippCreditNoteVO);
				validInvalidList.add(eippCreditNoteVO);
			} else {
				validInvalidList.add(eippCreditNoteVO);
			}
			
		}
	}
	
	/*
	 *This API checks for the availability of more than one linked invoice for a given credit note 
	 */
	private boolean validateLinkedInvCount(EippCreditNoteVO creditNoteVO) {
		boolean isInvalid = false;
		
		try {
			eippInvcUploadDAO.checkInvCountForCreditNote(creditNoteVO);
		} catch (BNPApplicationException e) {
			isInvalid = true;
			addToErrorDataList(creditNoteVO.getTransactionType(), creditNoteVO.toDataString(), 
					e.getErrorCode(), creditNoteVO);
		}
		return isInvalid;
	}
	
	private boolean validateUniqueReference(EippCreditNoteVO eippCreditNoteVO,List<EippCreditNoteVO> transList)
	throws BNPApplicationException {
		boolean isInvalid = false;
		if (eippInvcUploadDAO.isUniqueCheckEnabled(getCustomerOrgId(eippCreditNoteVO), 
				getCntpOrgId(eippCreditNoteVO), eippCreditNoteVO.getBillType())) {
			isInvalid = eippInvcUploadDAO.isCreditNoteExists(eippCreditNoteVO) ||
						checkUniqueReference(eippCreditNoteVO, transList);
			if (isInvalid) {
				addToErrorDataList(eippCreditNoteVO.getTransactionType(), eippCreditNoteVO.toDataString(), 
						ErrorConstants.CREDITNOTE_NOT_UNIQUE, eippCreditNoteVO);
			} else {
				transList.add(eippCreditNoteVO);
			}
		}
		return isInvalid;
	}
	
	private boolean checkUniqueReference(EippCreditNoteVO eippCreditNoteVO,List<EippCreditNoteVO> transList) {
		boolean isInvalid = false;
		for (EippCreditNoteVO transactionVO : transList) {
			if (eippCreditNoteVO.getCntRefNo().equals(transactionVO.getCntRefNo()) &&
				isSameDates(eippCreditNoteVO.getRefDate(), transactionVO.getRefDate()) &&
				eippCreditNoteVO.getSupplierOrgId().equals(transactionVO.getSupplierOrgId())) {
				isInvalid = true;
				break;
			}
		}
		
		return isInvalid;
	}
	
	private boolean validateCreditNoteAmounts(EippCreditNoteVO eippCreditNoteVO) {
		boolean isInvalid = false;
		
		if (eippCreditNoteVO.getCntOrgAmt().compareTo(getBigDecimalValue
				(eippCreditNoteVO.getCntUtilAmt())) < 0) {
			addToErrorDataList(eippCreditNoteVO.getTransactionType(), eippCreditNoteVO.toDataString(), 
					ErrorConstants.ORG_AMT_LESSER_THAN_UTIL_AMT, eippCreditNoteVO);
			isInvalid = true;
		}
		
		if (eippCreditNoteVO.getSubTotAmt() != null && eippCreditNoteVO.getTaxAmount() != null && (eippCreditNoteVO.getSubTotAmt().compareTo
				(eippCreditNoteVO.getCntOrgAmt().subtract(eippCreditNoteVO.getTaxAmount())) != 0 ||
				eippCreditNoteVO.getSubTotAmt().compareTo(eippCreditNoteVO.getCntOrgAmt()) > 0)) {
			addToErrorDataList(eippCreditNoteVO.getTransactionType(), eippCreditNoteVO.toDataString(), 
					ErrorConstants.EIPP_CNT_TOT_AMT_MISMATCH, eippCreditNoteVO);
			isInvalid = true;
		}else if(eippCreditNoteVO.getSubTotAmt() == null && eippCreditNoteVO.getTaxAmount() == null) {
			eippCreditNoteVO.setSubTotAmt(eippCreditNoteVO.getCntOrgAmt());
			eippCreditNoteVO.setSubTotAmtCcy(eippCreditNoteVO.getCcyCode());
		}else if(eippCreditNoteVO.getTaxAmount() != null && eippCreditNoteVO.getSubTotAmt() == null) {
			eippCreditNoteVO.setSubTotAmt(eippCreditNoteVO.getCntOrgAmt().subtract(eippCreditNoteVO.getTaxAmount()));
			eippCreditNoteVO.setSubTotAmtCcy(eippCreditNoteVO.getCcyCode());
		}else if(eippCreditNoteVO.getSubTotAmt() != null && eippCreditNoteVO.getTaxAmount() == null &&
				eippCreditNoteVO.getSubTotAmt().compareTo(eippCreditNoteVO.getCntOrgAmt()) <=0) {
			eippCreditNoteVO.setTaxAmount(eippCreditNoteVO.getCntOrgAmt().subtract(eippCreditNoteVO.getSubTotAmt()));
			eippCreditNoteVO.setTaxAmtCcy(eippCreditNoteVO.getCcyCode());
		}
		
		if ((eippCreditNoteVO.getSubTotAmtCcy() !=null && !eippCreditNoteVO.getCcyCode().equals(eippCreditNoteVO.getSubTotAmtCcy())) || 
				(eippCreditNoteVO.getTaxAmtCcy() != null && !eippCreditNoteVO.getCcyCode().equals(eippCreditNoteVO.getTaxAmtCcy()))) {
			addToErrorDataList(eippCreditNoteVO.getTransactionType(), eippCreditNoteVO.toDataString(), 
					ErrorConstants.EIPP_CNT_TOT_AMT_CCY_MISMATCH, eippCreditNoteVO);
			isInvalid = true;
		}
		
		if (eippCreditNoteVO.getCntUtilAmtCcy() != null && 
				!eippCreditNoteVO.getCcyCode().equals(eippCreditNoteVO.getCntUtilAmtCcy())) {
			
			addToErrorDataList(eippCreditNoteVO.getTransactionType(), eippCreditNoteVO.toDataString(), 
					ErrorConstants.ORG_AMT_CCY_UTIL_AMT_CCY_MISMATCH, eippCreditNoteVO);
			isInvalid = true;
		}
		eippCreditNoteVO.setCntRemAmt(eippCreditNoteVO.getCntOrgAmt().subtract
				(getBigDecimalValue(eippCreditNoteVO.getCntUtilAmt())));
		return isInvalid;
	}
	
	private boolean validateLinkedInvoiceDets(EippCreditNoteVO eippCreditNoteVO) throws BNPApplicationException {
		boolean isInvalid = false;
		boolean canConvertToUnlinked = eippInvcUploadDAO.canConvertToUnlinked(eippCreditNoteVO.getSupplierOrgId());
		
		if (!isNull(eippCreditNoteVO.getLinkedInvRefNo()) && !eippInvcUploadDAO.isLinkedInvoiceExists(eippCreditNoteVO)
				&& !canConvertToUnlinked) {
			addToErrorDataList(eippCreditNoteVO.getTransactionType(), eippCreditNoteVO.toDataString(), 
					ErrorConstants.LINKED_INVOICE_UNAVAILABLE, eippCreditNoteVO);
			isInvalid = true;
		}
		return isInvalid;
	}

	private AddressVO getAddress(PostalAddress6 postalAddress) {
		AddressVO addressVO = beanMapper.map(postalAddress, AddressVO.class);
		if (postalAddress.getAdrTp() != null) {
			addressVO.setAddrType(postalAddress.getAdrTp().value());
		}
		if (postalAddress.getAdrLine() != null && !postalAddress.getAdrLine().isEmpty()) {
			populateAddrLines(postalAddress.getAdrLine(), addressVO);
		}
		return addressVO;
	}
	
	private void populateAddrLines(List<String> addrLines,AddressVO addressVO) {
		if (addrLines.size() > 0 && !isNull(addrLines.get(0))) {
			addressVO.setAddress1(addrLines.get(0));
		}
		if (addrLines.size() > 1 && !isNull(addrLines.get(1))) {
			addressVO.setAddress2(addrLines.get(1));
		}
		if (addrLines.size() > 2 && !isNull(addrLines.get(2))) {
			addressVO.setAddress3(addrLines.get(2));
		}
	}
}
