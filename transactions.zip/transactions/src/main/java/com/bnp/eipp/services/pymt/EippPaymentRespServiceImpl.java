/****************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   27 Nov 2012
 * 
 * Purpose: Eipp Payment Response Message Service Implementation
 * 
 * Change History: 
 * Date                       	Author                                  		Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 27 Nov 2012              	Gangadharan R                      			Initial Version
 * 05 Dec 2012					Gangadharan R								Adhoc - Payment Response logic modification
 ********************************************************************************************************************************/

package com.bnp.eipp.services.pymt;

import java.util.ArrayList;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.invoice.util.EippAuditConstants;
import com.bnp.eipp.services.matching.payment.bindingvo.File;
import com.bnp.eipp.services.matching.payment.bindingvo.PymtRespDetails;
import com.bnp.eipp.services.pymt.dao.IEippPaymentMessageDao;
import com.bnp.eipp.services.vo.payment.EippPaymentMsgDetailVO;
import com.bnp.eipp.services.vo.payment.EippPymtVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.event.EventType;
import com.bnp.scm.services.common.event.IEventDelegate;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.common.vo.EventLogVO;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.invoice.IInvoiceUploadService;
import com.bnp.scm.services.txns.common.message.AbstractMsg;
import java.util.Locale;

/**
 * The Class EippPaymentRespServiceImpl.
 */
@Component
public class EippPaymentRespServiceImpl implements IEippPaymentRespService {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(EippPaymentRespServiceImpl.class);
	
	/** The Constant PYMT_RESP_MAPPER_FILE. */
	private static final String PYMT_RESP_MAPPER_FILE = "mapper/EippMatchingPymtRespMapper.xml";
	
	/** The Constant PYMT_REF_TYPE. */
	private static final String PYMT_REF_TYPE = "PAYMENT";
	
	/** The Constant BILL_PREFIX. */
	private static final String BILL_PREFIX = "BL";
	
	/** The Constant PYMT_AMT_NOT_MATCHING. */
	private static final String PYMT_AMT_NOT_MATCHING = "Payment Amount is not correct.";
	
	/** The Constant BUYR_ACCT_ID_MISMATCH. */
	private static final String BUYR_ACCT_ID_MISMATCH = "Buyer Account Identifier is not valid.";
	
	/** The Constant PYMT_AMT_BUY_ACC_ID_MISMATCH. */
	private static final String PYMT_AMT_BUY_ACC_ID_MISMATCH = "Buyer Account Identifier and Payment Amount are not valid.";
	
	/** The eipp payment message dao. */
	@Autowired
	private IEippPaymentMessageDao eippPaymentMessageDao;
	
	/** The invoice upload service. */
	@Autowired
	private IInvoiceUploadService invoiceUploadService;
	
	/** The property loader. */
	@Autowired 
	private BNPPropertyLoaderConfigurer propertyLoader;
	
	/** The event delegate impl. */
	@Autowired
	private IEventDelegate eventDelegateImpl;
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.IEippPaymentRespService#processMessage(com.bnp.scm.services.txns.common.message.AbstractMsg, com.bnp.scm.services.filemgmt.vo.FileDetailsVO)
	 */
	@Override
	public void processMessage(AbstractMsg<?> message) throws BNPApplicationException {
		List<String> mapperList = new ArrayList<String>(1);
		mapperList.add(PYMT_RESP_MAPPER_FILE);

		// Mapping JAXB object to custom VO object
		DozerBeanMapper mapper = new DozerBeanMapper();
		mapper.setMappingFiles(mapperList);

		List<PymtRespDetails> pymtRespDetailsList = ((File)message.getBody()).getDocument().getPymtStatusResp();
		for (PymtRespDetails pymtRespDetails : pymtRespDetailsList) {
			EippPymtVO pymtVO = mapper.map(pymtRespDetails, EippPymtVO.class);
			if(PYMT_REF_TYPE.equalsIgnoreCase(pymtVO.getDocType())){
				if(pymtVO.getRefNo() != null){
					setActionStatusValue(pymtVO);
					if(!pymtVO.getRefNo().toUpperCase(Locale.getDefault()).startsWith(BILL_PREFIX)){//a37126 - Added Fortify Issue - Portability Flaw: Locale Dependent Comparison
						/* Payment status update */
						EippPaymentMsgDetailVO pymtMsgDtlVO = getPaymentDetails(pymtVO);
						/*if(pymtMsgDtlVO == null){ //Commented for R5.0 - Sonar Fix - Feb21
							return;
						}*/
//						if(!validateAmtAndAcct(pymtMsgDtlVO, pymtVO, detailsVO)){
//							return;
//						}
						setPymtMsgDetail(pymtVO, pymtMsgDtlVO);

						if(StatusConstants.YES.equalsIgnoreCase(pymtMsgDtlVO.getIsSplitPymt())){
							if(!isSplitPaymentFailed(pymtMsgDtlVO)){
								updatePaymentStatus(pymtMsgDtlVO);
							}
						}else{
							updatePaymentStatus(pymtMsgDtlVO);
						}
					}else{
						/* Billing status update */
						updateBillingStatus(pymtVO);
					}
				}
			}
		}
	}
	
	/**
	 * Checks if is split payment failed.
	 *
	 * @param pymtMsgDtlVO the pymt msg dtl vo
	 * @return true, if is split payment failed
	 */
	private boolean isSplitPaymentFailed(EippPaymentMsgDetailVO pymtMsgDtlVO){
		try{
			return eippPaymentMessageDao.checkAnySplitPymtFailed(pymtMsgDtlVO);
		}catch(Exception excep){
			LOGGER.error("In EippPaymentRespServiceImpl isSplitPaymentFailed :", excep);
		}
		return true;
	}
	
	/**
	 * Sets the action status value.
	 *
	 * @param pymtVO the new action status value
	 */
	private void setActionStatusValue(EippPymtVO pymtVO){
		if(BNPConstants.EIPP_PMT_RESP_SUCC.equalsIgnoreCase(pymtVO.getStatus())){
			pymtVO.setStatus(StatusConstants.SUCCESS);
		}else if(BNPConstants.EIPP_PMT_RESP_FAIL.equalsIgnoreCase(pymtVO.getStatus())){
			pymtVO.setStatus(StatusConstants.FAILED);
		}
	}
	
	/**
	 * Update billing status.
	 *
	 * @param pymtVO the pymt vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void updateBillingStatus(EippPymtVO pymtVO) throws BNPApplicationException{
		EippPaymentMsgDetailVO pymtMsgDtlVO = null;
		String newStatus=null;
		try{
			 pymtMsgDtlVO = eippPaymentMessageDao.getBillingDetForUpdate(pymtVO.getRefNo());
			 if (pymtMsgDtlVO != null) {
				 if (!BNPConstants.INITIATED_BILL.equalsIgnoreCase(pymtMsgDtlVO.getPymtStatus())){
					 throw new BNPApplicationException(ErrorConstants.BILL_PYMT_STS_INVALID_MSG);
				 } else {
					 newStatus = getBillingStatusValue(pymtVO.getStatus(),pymtMsgDtlVO.getPymtStatus());
					 pymtMsgDtlVO.setRecordStatus(newStatus);
					 eippPaymentMessageDao.updateBillingStatusInMaster(pymtMsgDtlVO);
				 }
			 } else {
				 throw new BNPApplicationException(ErrorConstants.BILL_REF_NOT_AVAIL_MSG);
			 }
		}catch(BNPApplicationException bnpExcep){
			throw bnpExcep;
		}catch(Exception excep){
			LOGGER.error("In EippPaymentRespServiceImpl updateBillingStatus :", excep);
		}
	}
	
	/**
	 * Gets the billing status value.
	 *
	 * @param actionStatus the action status
	 * @param pymtStatus the pymt status
	 * @return the billing status value
	 */
	private String getBillingStatusValue(String actionStatus,String pymtStatus) {
		String newStatus=null;
		if(pymtStatus!=null){
			if(actionStatus!=null && StatusConstants.SUCCESS.equalsIgnoreCase(actionStatus)){
				newStatus = BNPConstants.BILL_PAID;
			}else{
				newStatus = BNPConstants.FAILED_BILL;
			}
		}
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("updateStatus -> newStatus ::"+newStatus);
		return newStatus;
	}	
	
	/**
	 * Sets the required details in payment message detail VO.
	 *
	 * @param pymtVO the pymt vo
	 * @param pymtMsgDtlVO the pymt msg dtl vo
	 */
	private void setPymtMsgDetail(EippPymtVO pymtVO, EippPaymentMsgDetailVO pymtMsgDtlVO){
		pymtMsgDtlVO.setUserId(BNPConstants.SYSTEM);
		pymtMsgDtlVO.setAction(EippAuditConstants.EIPP_PYMT_RESP_STATUS_UPDATE);
		pymtMsgDtlVO.setOrgId(pymtMsgDtlVO.getBuyerOrgId());
		pymtMsgDtlVO.setStatusCode(pymtVO.getStatus());
	}
	
	/**
	 * Gets the payment details.
	 *
	 * @param pymtVO the pymt vo
	 * @return the payment details
	 * @throws BNPApplicationException the bNP application exception
	 */
	private EippPaymentMsgDetailVO getPaymentDetails(
			EippPymtVO pymtVO) throws BNPApplicationException {
		
		EippPaymentMsgDetailVO pymtMsgDtlVO = null;
		try{
			pymtMsgDtlVO = eippPaymentMessageDao.getPaymentDetails(pymtVO.getRefNo());
			if(pymtMsgDtlVO != null){
				return pymtMsgDtlVO;
			}else{
				throw new BNPApplicationException(ErrorConstants.PYMT_REF_NOT_AVAIL_MSG);
			}
		}catch(BNPApplicationException bnpExcep){
			throw bnpExcep;
		}catch(Exception excep){
			LOGGER.error("In EippPaymentRespServiceImpl getPaymentDetails :", excep);
			throw new BNPApplicationException(ErrorConstants.PROCESSING_ERROR);
		}
	}

	/**
	 * Validate payment amount and buyer account identifier.
	 *
	 * @param pymtMsgDtlVO the pymt msg dtl vo
	 * @param pymtVO the pymt vo
	 * @param detailsVO the details vo
	 * @return true, if successful
	 */
	public boolean validateAmtAndAcct(EippPaymentMsgDetailVO pymtMsgDtlVO,
			EippPymtVO pymtVO, FileDetailsVO detailsVO) {
		try{
			if(!StatusConstants.YES.equalsIgnoreCase(pymtMsgDtlVO.getIsSplitPymt())){
				//Check Payment Amount (Amount from account)
				if(pymtVO.getPymtAmt() != null && pymtMsgDtlVO.getPaymentAmt() != null){
					if(pymtVO.getPymtAmt().compareTo(pymtMsgDtlVO.getPaymentAmt()) != 0){
						detailsVO.setErrorCode(Integer.toString(ErrorConstants.PYMT_AMT_NOT_CRRCT_MSG));
						detailsVO.setErrorDesc(PYMT_AMT_NOT_MATCHING);
						processFailureCase(detailsVO);
						return false;
					}
				}
				//Check buyer account identifier
				if(pymtVO.getBuyerAcctIdentifier() != null){
					if(!pymtVO.getBuyerAcctIdentifier().equalsIgnoreCase(pymtMsgDtlVO.getBuyerAccIden())){
						detailsVO.setErrorCode(Integer.toString(ErrorConstants.PYMT_BUYR_ACCT_ID_NOT_VALID_MSG));
						detailsVO.setErrorDesc(BUYR_ACCT_ID_MISMATCH);
						processFailureCase(detailsVO);
						return false;
					}
				}
			}else{
				/* Validation for split payment */
				try{
					pymtVO.setPymtId(Long.valueOf(pymtMsgDtlVO.getPaymentId()));
				}catch(Exception excep){
					LOGGER.error("In EippPaymentRespServiceImpl validateAmtAndAcct - converting payment id :", excep);
				}
				boolean isSplitPymtExist = eippPaymentMessageDao.checkSplitPymtExist(pymtVO);
				if(!isSplitPymtExist){
					detailsVO.setErrorCode(Integer.toString(ErrorConstants.PYMT_AMT_BUY_ACC_ID_NOT_VLD_MSG));
					detailsVO.setErrorDesc(PYMT_AMT_BUY_ACC_ID_MISMATCH);
					processFailureCase(detailsVO);
					return false;
				}
			}
		}catch(Exception excep){
			LOGGER.error("In EippPaymentRespServiceImpl validateAmtAndAcct - Exception :", excep);
			return false;
		}
		return true;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.IEippPaymentRespService#updatePaymentStatus(com.bnp.eipp.services.vo.payment.EippPaymentMsgDetailVO)
	 */
	@Override
	public void updatePaymentStatus(EippPaymentMsgDetailVO pymtMsgDtlVO) 
		throws BNPApplicationException {
		
		try{
			String newStatus = getPaymentStatusValue(pymtMsgDtlVO.getStatusCode(), 
					pymtMsgDtlVO.getPymtStatus());
			pymtMsgDtlVO.setRecordStatus(newStatus);
//			if(StatusConstants.YES.equalsIgnoreCase(pymtMsgDtlVO.getIsSplitPymt())){
//				eippPaymentMessageDao.updatePaymentStatusInSplit(pymtMsgDtlVO);
//				if(eippPaymentMessageDao.checkAllSplitPymtSuccess(pymtMsgDtlVO)){
//					updatePaymentStatusInMaster(pymtMsgDtlVO);
//				}
//			}else{
				updatePaymentStatusInMaster(pymtMsgDtlVO);
//			}
		}catch(BNPApplicationException bnpExcep){
			throw bnpExcep;
		} catch(Exception excep){
			LOGGER.error("In EippPaymentRespServiceImpl updatePaymentStatus - Exception:", excep);
		}
	}
	
	/**
	 * Process failure case.
	 *
	 * @param detailsVO the details vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	private void processFailureCase(FileDetailsVO detailsVO) throws BNPApplicationException{
		detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.validation.fail"));
		updateFileStatus(detailsVO);
		invoiceUploadService.triggerEventLog(detailsVO,"FAILURE");
	}
	

	/**
	 * Update file status.
	 * @param detailsVO the details vo
	 */
	private void updateFileStatus(FileDetailsVO detailsVO) {
		try {
			invoiceUploadService.updateFileStatus(detailsVO);
		}catch (Exception e) {
			LOGGER.error("In EippPaymentRespServiceImpl updateFileStatus :", e);
		}
	}
		
	/**
	 * Gets the payment status value.
	 *
	 * @param actionStatus the action status
	 * @param pymtStatus the pymt status
	 * @return the payment status value
	 */
	private String getPaymentStatusValue(String actionStatus, String pymtStatus) {
		String newStatus=null;
		if(pymtStatus!=null){
			if(StatusConstants.PAYMENT_INITIATED.equalsIgnoreCase(pymtStatus) || StatusConstants.PENDING_PAYMENT.equalsIgnoreCase(pymtStatus)){
				if(actionStatus!=null && StatusConstants.SUCCESS.equalsIgnoreCase(actionStatus)){
					newStatus = StatusConstants.PAYMENT_SUCCESSFUL;
				}else{
					newStatus = StatusConstants.PAYMENT_FAILED;
				}
			}else{
				if(actionStatus!=null && StatusConstants.SUCCESS.equalsIgnoreCase(actionStatus)){
					newStatus = StatusConstants.COLLECTION_SUCCESSFUL;
				}else{
					newStatus = StatusConstants.COLLECTION_FAILED;
				}
			}
		}
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("getPaymentStatusValue -> :" + newStatus);
		return newStatus;
	}
	
	/**
	 * Update payment status in master table.
	 *
	 * @param eippPaymentMsgDetailVO the eipp payment msg detail vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	public void updatePaymentStatusInMaster(
			EippPaymentMsgDetailVO eippPaymentMsgDetailVO)
			throws BNPApplicationException {

		eippPaymentMessageDao.updatePaymentStatusInMaster(eippPaymentMsgDetailVO);		
		processEvents(eippPaymentMsgDetailVO, eippPaymentMsgDetailVO.getRecordStatus());
	}
	
	/**
	 * Process events.
	 *
	 * @param data the data
	 * @param newStatus the new status
	 */
	private void processEvents(EippPaymentMsgDetailVO data,String newStatus) {
		try {
				EventType newEvent = null;
//				boolean isInvClosed=false;
				if(StatusConstants.PAYMENT_SUCCESSFUL.equalsIgnoreCase(newStatus)){
					newEvent = EventType.EIPP_PAYMENT_SUCCESSFUL;
//					isInvClosed=true;
				}else if(StatusConstants.COLLECTION_SUCCESSFUL.equalsIgnoreCase(newStatus)){
					newEvent = EventType.EIPP_COLLECTION_SUCCESSFUL;
//					isInvClosed=true;
				}else if(StatusConstants.COLLECTION_FAILED.equalsIgnoreCase(newStatus)){
					newEvent = EventType.EIPP_COLLECTION_FAILED;
//					isInvClosed=false;
				}/*else{ //Commented for R5.0 - Sonar Fix - Feb21
//					isInvClosed=false;
				}*/
				 insertEventLog(data,newEvent,data.getPaymentId());
				
//				if(isInvClosed){
//					List<Long> invIDList =manualStatusUpdateDao.getClosedInvIds(Long.valueOf(data.getPaymentId()));
//		        	 for(Long invID:invIDList){
//		        		 insertEventLog(data,EventType.EIPP_INV_CLOSED,String.valueOf(invID));
//		        	 }
//				}
		} catch (Exception e) {
			LOGGER.error("Error in EippPaymentRespServiceImpl processEvents: ", e );
		}
	}
	
	/**
	 * Insert event log.
	 *
	 * @param data the data
	 * @param eventType the event type
	 * @param refKey the ref key
	 */
	private void insertEventLog(EippPaymentMsgDetailVO data,EventType eventType,String refKey) {
		try {
			if(eventType!=null){
				EventLogVO eventVO = new EventLogVO();
				eventVO.setReferenceKey(refKey);
				eventVO.setEventType(eventType);
				eventVO.setBuyerOrgId(data.getBuyerOrgId());
				eventVO.setSellerOrgId(data.getSupplierOrgId());
				eventVO.setMktPlcOrgId(data.getMktPlaceOrgId());
				eventVO.setMarketPlaceOrgID(data.getMktPlaceOrgId());
				eventVO.setEventInitiator(data.getUserId());
				eventDelegateImpl.initEvents(eventVO);
			}
		}
		catch (BNPApplicationException e) {
			LOGGER.error("Error while raising event log : " + e );
		}
	}	

}
