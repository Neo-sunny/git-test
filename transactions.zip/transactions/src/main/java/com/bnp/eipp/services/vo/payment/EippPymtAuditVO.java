/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  03 Aug 2012
 * 
 * Purpose:      EippPymtAuditVO
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 03 Aug 2012       Oracle Financial Services Software Ltd                  Initial Version
 * 09 Nov 2012 		 Raja S													 Change Done for Audit Trail 
************************************************************************************************************************************************************/

package com.bnp.eipp.services.vo.payment;

import java.util.Date;

import com.bnp.scm.services.common.vo.AbstractVO;


// TODO: Auto-generated Javadoc
/**
 * The Class EippPymtAuditVO.
 */
public class EippPymtAuditVO  extends AbstractVO{
	
	/** The pymt id. */
	private long pymtId;
	
	/** The user id. */
	private String userId;
	
	/** The action. */
	private String action;
	
	/** The status. */
	private String status;
	
	/** The action date. */
	private Date actionDate;
	
	/** The auto pymt rule id. */
	private String autoPmtRuleId;
	
	/** The auto pymt rule desc. */
	private String autoPmtRuleDesc;
	
	/** The auto pymt effec date. */
	private Date autoPmtEffecDate;
	
	/** The pymt init date. */
	private Date pymtInitDate;
	
	/** The auto auth rule id. */
	private String autoAuthRuleId;
	
	/** The auto auth rule desc. */
	private String autoAuthRuleDesc;
	
	/** The auto auth effec date. */
	private Date autoAuthEffecDate;
	
	private String ruleId;
	
	

	/**
	 * Gets the pymt id.
	 *
	 * @return the pymt id
	 */
	public long getPymtId() {
		return pymtId;
	}

	/**
	 * Sets the pymt id.
	 *
	 * @param pymtId the new pymt id
	 */
	public void setPymtId(long pymtId) {
		this.pymtId = pymtId;
	}

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * Gets the action.
	 *
	 * @return the action
	 */
	public String getAction() {
		return action;
	}

	/**
	 * Sets the action.
	 *
	 * @param action the new action
	 */
	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the action date.
	 *
	 * @return the action date
	 */
	public Date getActionDate() {
		return actionDate;
	}

	/**
	 * Sets the action date.
	 *
	 * @param actionDate the new action date
	 */
	public void setActionDate(Date actionDate) {
		this.actionDate = actionDate;
	}

	/**
	 * Gets the auto pymt rule id.
	 *
	 * @return the auto pymt rule id
	 */
	public String getAutoPmtRuleId() {
		return autoPmtRuleId;
	}

	/**
	 * Sets the auto pymt rule id.
	 *
	 * @param autoPymtRuleId the new auto pymt rule id
	 */
	public void setAutoPmtRuleId(String autoPmtRuleId) {
		this.autoPmtRuleId = autoPmtRuleId;
	}

	/**
	 * Gets the auto pymt rule desc.
	 *
	 * @return the auto pymt rule desc
	 */
	public String getAutoPmtRuleDesc() {
		return autoPmtRuleDesc;
	}

	/**
	 * Sets the auto pymt rule desc.
	 *
	 * @param autoPymtRuleDesc the new auto pymt rule desc
	 */
	public void setAutoPmtRuleDesc(String autoPmtRuleDesc) {
		this.autoPmtRuleDesc = autoPmtRuleDesc;
	}

	/**
	 * Gets the auto pymt effec date.
	 *
	 * @return the auto pymt effec date
	 */
	public Date getAutoPymtEffecDate() {
		return autoPmtEffecDate;
	}

	/**
	 * Sets the auto pymt effec date.
	 *
	 * @param autoPymtEffecDate the new auto pymt effec date
	 */
	public void setAutoPmtEffecDate(Date autoPmtEffecDate) {
		this.autoPmtEffecDate = autoPmtEffecDate;
	}

	/**
	 * Gets the pymt init date.
	 *
	 * @return the pymt init date
	 */
	public Date getPymtInitDate() {
		return pymtInitDate;
	}

	/**
	 * Sets the pymt init date.
	 *
	 * @param pymtInitDate the new pymt init date
	 */
	public void setPymtInitDate(Date pymtInitDate) {
		this.pymtInitDate = pymtInitDate;
	}

	/**
	 * Gets the auto auth rule id.
	 *
	 * @return the auto auth rule id
	 */
	public String getAutoAuthRuleId() {
		return autoAuthRuleId;
	}

	/**
	 * Sets the auto auth rule id.
	 *
	 * @param autoAuthRuleId the new auto auth rule id
	 */
	public void setAutoAuthRuleId(String autoAuthRuleId) {
		this.autoAuthRuleId = autoAuthRuleId;
	}

	/**
	 * Gets the auto auth rule desc.
	 *
	 * @return the auto auth rule desc
	 */
	public String getAutoAuthRuleDesc() {
		return autoAuthRuleDesc;
	}

	/**
	 * Sets the auto auth rule desc.
	 *
	 * @param autoAuthRuleDesc the new auto auth rule desc
	 */
	public void setAutoAuthRuleDesc(String autoAuthRuleDesc) {
		this.autoAuthRuleDesc = autoAuthRuleDesc;
	}

	/**
	 * Gets the auto auth effec date.
	 *
	 * @return the auto auth effec date
	 */
	public Date getAutoAuthEffecDate() {
		return autoAuthEffecDate;
	}

	/**
	 * Sets the auto auth effec date.
	 *
	 * @param autoAuthEffecDate the new auto auth effec date
	 */
	public void setAutoAuthEffecDate(Date autoAuthEffecDate) {
		this.autoAuthEffecDate = autoAuthEffecDate;
	}

	public String getRuleId() {
		return ruleId;
	}

	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}
	
	}
