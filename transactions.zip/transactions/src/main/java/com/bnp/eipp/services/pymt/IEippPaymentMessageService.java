/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Jun 20, 2012
 * 
 * Purpose:      IAutoPaymentRuleService.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Jun 20, 2012	       		Sandhya R                						  Initial Version  
 * 22 OCT 2012				Sadhana A V						                  Rel 3.0 - Message monitoring changes
************************************************************************************************************************************************************/

package com.bnp.eipp.services.pymt;

import java.util.List;
import java.util.Map;

import com.bnp.eipp.services.vo.payment.EippPaymentMsgVO;
import com.bnp.eipp.services.vo.payment.EippPaymentMsgDetailVO;
import com.bnp.eipp.services.vo.payment.PaymentInitiateAccountVO;
import com.bnp.scm.services.common.IAbstractService;
import com.bnp.scm.services.common.exception.BNPApplicationException;

// TODO: Auto-generated Javadoc
/**
 * The Interface IEippPaymentMessageService.
 */
public interface IEippPaymentMessageService extends IAbstractService<EippPaymentMsgDetailVO>{
	
	/**
	 * Gets the payment messages.
	 *
	 * @param args the args
	 * @return the payment messages
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<Map<String,Object>> getPaymentMessages(String[] args)throws BNPApplicationException;
	
	/**
	 * Gets the collection messages.
	 *
	 * @param args the args
	 * @return the collection messages
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<Map<String,Object>> getCollectionMessages(String[] args)throws BNPApplicationException;
	
	/**
	 * Update payment message flag.
	 *
	 * @param pymtMsgVO the pymt msg vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void updatePaymentMessageFlag(EippPaymentMsgVO pymtMsgVO) throws BNPApplicationException;

	/**
	 * Update message info status.
	 *
	 * @param msgId the msg id
	 * @param status the status
	 * @param errorDesc the error desc
	 * @throws BNPApplicationException the bNP application exception
	 */
	void updateMessageInfoStatus(String msgId, String status,String errorDesc) throws BNPApplicationException;

	/**
	 * Gets the eipp pymt dets for regenerate.
	 *
	 * @param msgRef the msg ref
	 * @return the eipp pymt dets for regenerate
	 * @throws BNPApplicationException the bNP application exception
	 */
	EippPaymentMsgVO getEippPymtDetsForRegenerate(String msgRef,String msgId) throws BNPApplicationException;

	/**
	 * Update txn timestamp.
	 *
	 * @param eippPymtMsgVO the eipp pymt msg vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void updateTxnTimestamp(EippPaymentMsgVO eippPymtMsgVO) throws BNPApplicationException;

	/**
	 * Reset processing flag.
	 *
	 * @param eippPymtMsgVO the eipp pymt msg vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void resetProcessingFlag(EippPaymentMsgVO eippPymtMsgVO) throws BNPApplicationException;

	/**
	 * Gets the billdatas.
	 *
	 * @param strBranch the str branch
	 * @return the billdatas
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippPaymentMsgDetailVO> getBilldatas(String strBranch) throws BNPApplicationException;

	/**
	 * Pymt proc cre billing dets.
	 *
	 * @param payAccVo the pay acc vo
	 * @return the payment initiate account vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	PaymentInitiateAccountVO pymtProcCreBillingDets(EippPaymentMsgDetailVO payAccVo) throws BNPApplicationException;
	
	/**
	 * Pymt proc info population for buyr.
	 *
	 * @param singPayAccVo the sing pay acc vo
	 * @return the payment initiate account vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	PaymentInitiateAccountVO pymtProcInfoPopulationForBuyr(EippPaymentMsgDetailVO singPayAccVo) throws BNPApplicationException;

	/**
	 * Pymt proc info for suplr.
	 *
	 * @param singPayAccVo the sing pay acc vo
	 * @return the payment initiate account vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	PaymentInitiateAccountVO pymtProcInfoForSuplr(EippPaymentMsgDetailVO singPayAccVo) throws BNPApplicationException;

	/**
	 * Pymt proc info for mkt plc.
	 *
	 * @param singPayAccVo the sing pay acc vo
	 * @return the payment initiate account vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	PaymentInitiateAccountVO pymtProcInfoForMktPlc(EippPaymentMsgDetailVO singPayAccVo) throws BNPApplicationException;

	/**
	 * Process messages.
	 *
	 * @param allCollections the all collections
	 * @param schType the sch type
	 * @return the list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<Map<String, Object>> processMessages(List<EippPaymentMsgVO> allCollections, String schType) throws BNPApplicationException;

	/**
	 * Process billing messages.
	 *
	 * @param allMsg the all msg
	 * @param string the string
	 * @return the list
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<Map<String,Object>> processBillingMessages(List<EippPaymentMsgVO> allMsg, String string) throws BNPApplicationException;

	/**
	 * Gets the message id.
	 *
	 * @return the message id
	 * @throws BNPApplicationException the bNP application exception
	 */
	String getMessageId() throws BNPApplicationException;

	/**
	 * Update billing message flag.
	 *
	 * @param eippPayMsgVO the eipp pay msg vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void updateBillingMessageFlag(EippPaymentMsgVO eippPayMsgVO) throws BNPApplicationException;

	/**
	 * Gets the clr sys nm basedon country.
	 *
	 * @param hdrCountry the hdr country
	 * @param keyName the key name
	 * @return the clr sys nm basedon country
	 * @throws BNPApplicationException the bNP application exception
	 */
	String getClrSysNmBasedonCountry(String hdrCountry, String keyName)	throws BNPApplicationException;

	EippPaymentMsgVO preparePayMsgVO(EippPaymentMsgDetailVO payAccVo)	throws BNPApplicationException;

	EippPaymentMsgVO getEippPymtDetsForBillingRegenerate(String msgRef) throws BNPApplicationException;
}
