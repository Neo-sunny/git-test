/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   06 Feb 12
 * 
 * Purpose:      Invoice Upload
 * 
 * Change History: 
 * Date                                                  Author                      Version                                                            Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 06 Feb 12                      Oracle Financial Services Software Ltd                                  Initial version
 *12-July 2012                    Oracle Financial Services Software Ltd            EIPP Phase II - Cancel Invoice MFU
 *12 Oct 2012						Merdith 														  			Method Parameter changed for validating line item
 *17 Oct 2012					  Vinoth Kumar M									Pending Match Job
 *19 Oct 2012					  Merdith S 										ST - 6984 To allow disputing of Line Itm based on LinkorgforEIPP data
 *23 Oct 2012					Merdith 											ST Defect 6824
 ******************************************************************************************************************************************************************/

package com.bnp.eipp.services.invoice.dao;

import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.bnp.eipp.services.invoice.vo.EippCreditNoteVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceBusinessRulesVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceCancelVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.vo.dispute.DisputeVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;

/**
 * The Interface IEippInvcUploadDAO.
 */
public interface IEippInvcUploadDAO {
	
	
	/**
	 * Upload file.
	 *
	 * @param helperList the helper list
	 * @param detailsVO the details vo
	 * @throws BNPApplicationException the bNP application exception
	 * @Name : uploadFile
	 * @Description : This method is used to parse & upload the data file
	 */
	void uploadFile(List<EippInvCntVO> helperList, FileDetailsVO detailsVO) throws BNPApplicationException;
	
    /**
     * Insert history details from trans.
     *
     * @param fileId the file id
     * @throws BNPApplicationException the bNP application exception
     * @Name : insertHistoryDetailsFromTrans
     * @Description : This method is used to insert history details
     */    
    void insertHistoryDetailsFromTrans(long fileId) throws BNPApplicationException;
	
	/**
	 * Get the Seller ERP Id for the Buyer and buyer ERP id for seller.
	 *
	 * @param orgId the org id
	 * @param billType the bill type
	 * @return the seller ERP id list or buyer ERP id list
	 * @throws BNPApplicationException the bNP runtime exception
	 */
	List<String> getERPIDList(String orgId,String billType) throws BNPApplicationException;

	/**
	 * Get the counter party organization from link organization for EIPP.
	 *
	 * @param orgId is the customer organization
	 * @param billType the bill type
	 * @param cntpERPId the cntp erp id
	 * @return counter party organization
	 * @throws BNPApplicationException the bNP runtime exception
	 */
	List<String> getCounterPartyOrgId(String orgId, String billType,String cntpERPId)
	   throws BNPApplicationException;
	
	
	/**
	 * Get the counter party organization from bill type.
	 *
	 * @param billType the bill type
	 * @param custERPId the cust erp id
	 * @return customer organization
	 * @throws BNPApplicationException the bNP runtime exception
	 */
	List<String> getCustomerOrgId(String billType,String custERPId)
	throws BNPApplicationException;
	
	/**
	 * checks whether department available or not.
	 *
	 * @param orgId is the customer organization
	 * @param dept the dept
	 * @return true or false
	 * @throws BNPApplicationException the bNP runtime exception
	 */
	boolean isDepartmentAvailable(String orgId,String dept) throws BNPApplicationException;
	
	/**
	 * Check existing invoices.
	 *
	 * @param invRefNo the inv ref no
	 * @param orgId the org id
	 * @return true, if successful
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean checkExistingInvoices(String invRefNo,String orgId) throws BNPApplicationException;
	
	/**
	 * Check existing credit notes.
	 *
	 * @param cntRefNo the cnt ref no
	 * @param orgId the org id
	 * @return true, if successful
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean checkExistingCreditNotes(String cntRefNo,String orgId) throws BNPApplicationException;
	
	/**
	 * Get the model type of the organization.
	 *
	 * @param orgId the org id
	 * @return the model type
	 * @throws BNPApplicationException the bNP runtime exception
	 */
	
	String getModelTypeForOrganization(String orgId) throws BNPApplicationException;
	
	/**
	 * Get the time zone of the organization.
	 *
	 * @param orgId the org id
	 * @return the model type
	 * @throws BNPApplicationException the bNP runtime exception
	 */
	
	String getTimezoneForOrganization(String orgId) throws BNPApplicationException;
	
	
	/**
	 * check the partial upload flag enabled or not.
	 *
	 * @param orgId the org id
	 * @return true or false
	 * @throws BNPApplicationException the bNP runtime exception
	 */
	
	boolean canUploadPartialFile(String orgId) throws BNPApplicationException;
	
	/**
	 * checks the link organization for EIPP.
	 *
	 * @param custOrgId the cust org id
	 * @param cntpOrgId the cntp org id
	 * @param billType the bill type
	 * @return true or false
	 * @throws BNPApplicationException the bNP runtime exception
	 */
	
	boolean isBuyerSellerLinked(String custOrgId,String cntpOrgId,String billType) throws BNPApplicationException;
	
	/**
	 * checks the link organization for EIPP.
	 *
	 * @param custOrgId the cust org id
	 * @param cntpOrgId the cntp org id
	 * @param billType the bill type
	 * @return true or false
	 * @throws BNPApplicationException the bNP runtime exception
	 */
	
	boolean isAccountIdentifierRequired(String custOrgId,String cntpOrgId,String billType) throws BNPApplicationException;
	
	/**
	 * checks the link organization for EIPP.
	 *
	 * @param custOrgId the cust org id
	 * @param cntpOrgId the cntp org id
	 * @param billType the bill type
	 * @return true or false
	 * @throws BNPApplicationException the bNP runtime exception
	 */
	
	boolean isUniqueCheckEnabled(String custOrgId,String cntpOrgId,String billType) throws BNPApplicationException;

	
	/**
	 * checks the supplier account.
	 *
	 * @param custOrgId the cust org id
	 * @param acctIdnt the acct idnt
	 * @return true or false
	 * @throws BNPApplicationException the bNP runtime exception
	 */
	
	boolean isAccountIdentifierExists(String custOrgId,String acctIdnt) throws BNPApplicationException;
	
	/**
	 * checks the EIPP invoice table.
	 *
	 * @param eippCreditNoteVO the eipp credit note vo
	 * @return true or false
	 * @throws BNPApplicationException the bNP runtime exception
	 */
	
	boolean isLinkedInvoiceExists(EippCreditNoteVO eippCreditNoteVO) throws BNPApplicationException;
	
	/**
	 * checks the EIPP invoice table.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @return true or false
	 * @throws BNPApplicationException the bNP runtime exception
	 */
	
	boolean isInvoiceExists(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException;
	
	/**
	 * checks the EIPP credit note table.
	 *
	 * @param eippCreditNoteVO the eipp credit note vo
	 * @return true or false
	 * @throws BNPApplicationException the bNP runtime exception
	 */
	
	boolean isCreditNoteExists(EippCreditNoteVO eippCreditNoteVO) throws BNPApplicationException;
	
	/**
	 * Can convert to unlinked.
	 *
	 * @param orgId the org id
	 * @return true, if successful
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean canConvertToUnlinked(String orgId) throws BNPApplicationException;
	
	/**
	 * Check inv count for credit note.
	 *
	 * @param creditNote the credit note
	 * @throws BNPApplicationException the bNP application exception
	 */
	void checkInvCountForCreditNote(
			EippCreditNoteVO creditNote) throws BNPApplicationException;

	/**
	 * Update reprocess flag for old rejected records.
	 *
	 * @param detailsVO the details vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void updateReprocessFlagForOldRejectedRecords(
			FileDetailsVO detailsVO)throws BNPApplicationException;
	
	/**
	 * Insert cancel invoice list.
	 *
	 * @param invoiceCancelList the invoice cancel list
	 * @param fileVO the file vo
	 * @throws BNPApplicationException the bNP application exception
	 */
	void insertCancelInvoiceList(List<EippInvoiceCancelVO> invoiceCancelList,FileDetailsVO fileVO) throws BNPApplicationException;

	/**
	 * Gets the org type for organization.
	 *
	 * @param orgId the org id
	 * @return the org type for organization
	 * @throws BNPApplicationException the bNP application exception
	 */
	String getOrgTypeForOrganization(String orgId) throws BNPApplicationException;

	/**
	 * Checks if is bill through market place.
	 *
	 * @param billType the bill type
	 * @param marketPlaceOrgId the market place org id
	 * @return true, if is bill through market place
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean isBillThroughMarketPlace(String billType, String marketPlaceOrgId) throws BNPApplicationException;

	/**
	 * Check market place is parent org.
	 *
	 * @param orgId the org id
	 * @param marketPlaceOrgId the market place org id
	 * @return true, if successful
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean checkMarketPlaceIsParentOrg(String orgId,String marketPlaceOrgId) throws BNPApplicationException;
	
	/**
	 * Checks if is customer org linked to market place.
	 *
	 * @param orgId the org id
	 * @param marketPlaceOrgId the market place org id
	 * @return true, if is customer org linked to market place
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean isCustomerOrgLinkedToMarketPlace(String orgId,String marketPlaceOrgId) throws BNPApplicationException;
	
	/**
	 * Checks if is buyer seller linked to market place.
	 *
	 * @param custOrgId the cust org id
	 * @param cntpOrgId the cntp org id
	 * @param billType the bill type
	 * @param marketPlaceOrgId the market place org id
	 * @return true, if is buyer seller linked to market place
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean isBuyerSellerLinkedToMarketPlace(String custOrgId,String cntpOrgId, String billType, String marketPlaceOrgId)
			throws BNPApplicationException;

	/**
	 * Gets the rule type for discount rule id.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @return the rule type for discount rule id
	 * @throws BNPApplicationException the bNP application exception
	 */
	String getRuleTypeForDiscountRuleId(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException;

	/**
	 * Checks if is invoice available in system.
	 *
	 * @param params the params
	 * @return the int
	 * @throws BNPApplicationException the bNP application exception
	 */
	int isInvoiceAvailableInSystem(Properties params) throws BNPApplicationException;

	/**
	 * Checks if is default business rule enabled.
	 *
	 * @param custOrgId the cust org id
	 * @param cntpOrgId the cntp org id
	 * @param billType the bill type
	 * @return true, if is default business rule enabled
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean isDefaultBusinessRuleEnabled(String custOrgId, String cntpOrgId,
			String billType) throws BNPApplicationException;
	
	/**
	 * Gets the business processing rules from bill type.
	 *
	 * @param custOrgId the cust org id
	 * @param cntpOrgId the cntp org id
	 * @param billType the bill type
	 * @return the business processing rules from bill type
	 * @throws BNPApplicationException the bNP application exception
	 */
	EippInvoiceBusinessRulesVO getBusinessProcessingRulesFromBillType(String custOrgId,String cntpOrgId,String billType)throws BNPApplicationException;

	/**
	 * Gets the business processing rules from link org.
	 *
	 * @param custOrgId the cust org id
	 * @param cntpOrgId the cntp org id
	 * @param billType the bill type
	 * @return the business processing rules from link org
	 * @throws BNPApplicationException the bNP application exception
	 */
	EippInvoiceBusinessRulesVO getBusinessProcessingRulesFromLinkOrg(String custOrgId,String cntpOrgId,String billType)throws BNPApplicationException;

	/**
	 * Gets the invoice list for validation.
	 *
	 * @param params the params
	 * @return the invoice list for validation
	 * @throws BNPApplicationException the bNP application exception
	 */
	List<EippInvoiceVO> getInvoiceListForValidation(Map<String, Object> params) throws BNPApplicationException;

	/**
	 * Insert match hist dtls from trans.
	 *
	 * @param fileId the file id
	 * @throws BNPApplicationException the bNP application exception
	 */
	void insertMatchHistDtlsFromTrans(long fileId) throws BNPApplicationException;
	
	/**
	 * Checks if is match invoice exists.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @return true, if is match invoice exists
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean isMatchInvoiceExists(EippInvoiceVO eippInvoiceVO) throws BNPApplicationException;
	
	/**
	 * Checks if is bill type linked to market place.
	 *
	 * @param orgId the org id
	 * @param billType the bill type
	 * @return true, if is bill type linked to market place
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean isBillTypeLinkedToMarketPlace(String orgId, String billType) throws BNPApplicationException;
	
	/**
	 * Checks if is match credit note exists.
	 *
	 * @param eippCreditNoteVO the eipp credit note vo
	 * @return true, if is match credit note exists
	 * @throws BNPApplicationException the bNP application exception
	 */
	boolean isMatchCreditNoteExists(EippCreditNoteVO eippCreditNoteVO) throws BNPApplicationException;
	
	/**
	 * Match records.
	 *
	 * @param fileId the file id
	 * @return the string
	 * @throws BNPApplicationException the bNP application exception
	 */
	String matchRecords(long fileId) throws BNPApplicationException;

	/**
	 * Fetch alloc type.
	 *
	 * @param eippInvoiceVO the eipp invoice vo
	 * @return the string
	 * @throws BNPApplicationException the bNP application exception
	 */
	String fetchAllocType(EippInvoiceVO eippInvoiceVO)throws BNPApplicationException;

	/**
	 * Get pending match files
	 * @param orgId
	 * @return
	 * @throws BNPApplicationException
	 */
	List<Long> getPendingMatchFiles(final String orgId) throws BNPApplicationException;

	/**
	 * Chk valid inv l ifrom link org.
	 *
	 * @param invLIVO the inv livo
	 * @return true, if successful
	 */
	boolean chkValidInvLIfromLinkOrg(DisputeVO invLIVO);
	
	boolean isAttUploadedForExistingInvoices(FileDetailsVO detailsVO)
		throws BNPApplicationException;
	
	byte[] getAttachmentData(long fileId) throws BNPApplicationException;
}
