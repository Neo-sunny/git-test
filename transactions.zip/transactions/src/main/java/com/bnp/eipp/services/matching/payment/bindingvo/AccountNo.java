package com.bnp.eipp.services.matching.payment.bindingvo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for AccountNo complex type.
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AccountNo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;choice>
 *           &lt;element name="AcctNo" type="{}Max35Text"/>
 *           &lt;element name="AcctId" type="{}Max35Text"/>
 *         &lt;/choice>
 *         &lt;element name="AcctCcy" type="{}ActiveCurrencyCode" minOccurs="0"/>
 *         &lt;element name="AcctType" type="{}Max16Text" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AccountNo", propOrder = { "acctNo", "acctId", "acctCcy", "acctType" })
public class AccountNo {

	@XmlElement(name = "AcctNo")
	protected String acctNo;

	@XmlElement(name = "AcctId")
	protected String acctId;

	@XmlElement(name = "AcctCcy")
	protected String acctCcy;

	@XmlElement(name = "AcctType")
	protected String acctType;

	/**
	 * Gets the value of the acctNo property.
	 * @return possible object is {@link String }
	 */
	public String getAcctNo() {
		return acctNo;
	}

	/**
	 * Sets the value of the acctNo property.
	 * @param value allowed object is {@link String }
	 */
	public void setAcctNo(String value) {
		this.acctNo = value;
	}

	/**
	 * Gets the value of the acctId property.
	 * @return possible object is {@link String }
	 */
	public String getAcctId() {
		return acctId;
	}

	/**
	 * Sets the value of the acctId property.
	 * @param value allowed object is {@link String }
	 */
	public void setAcctId(String value) {
		this.acctId = value;
	}

	/**
	 * Gets the value of the acctCcy property.
	 * @return possible object is {@link String }
	 */
	public String getAcctCcy() {
		return acctCcy;
	}

	/**
	 * Sets the value of the acctCcy property.
	 * @param value allowed object is {@link String }
	 */
	public void setAcctCcy(String value) {
		this.acctCcy = value;
	}

	/**
	 * Gets the value of the acctType property.
	 * @return possible object is {@link String }
	 */
	public String getAcctType() {
		return acctType;
	}

	/**
	 * Sets the value of the acctType property.
	 * @param value allowed object is {@link String }
	 */
	public void setAcctType(String value) {
		this.acctType = value;
	}

}
