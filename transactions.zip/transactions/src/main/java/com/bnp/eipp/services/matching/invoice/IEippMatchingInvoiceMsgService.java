/****************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14 Oct 2012
 * 
 * Purpose: Eipp Matching Invoice Message Service
 * 
 * Change History: 
 * Date                       	Author                                  Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 14 Oct 2012              	Prabu P                      			Initial Version
 ********************************************************************************************************************************/

package com.bnp.eipp.services.matching.invoice;

import com.bnp.eipp.services.vo.common.EippMessageVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.txns.common.vo.MessageVO;

public interface IEippMatchingInvoiceMsgService {

	/**
	 * Create Match Invoice Message
	 * @param matchInvMsgVO
	 * @throws BNPApplicationException
	 */
	void createMessage(EippMessageVO matchInvMsgVO) throws BNPApplicationException;
	
	/**
	 * Save message into ERP table
	 * @param messageVO
	 * @throws BNPApplicationException
	 */
	void saveMessage(MessageVO messageVO)  throws BNPApplicationException;
	
	/**
	 * Send Email and H2H Message
	 * @param matchInvMsgVO
	 * @throws BNPApplicationException
	 */
	void sendEmailAndH2HMessage(EippMessageVO matchInvMsgVO) throws BNPApplicationException;
	
	/**
	 * Set Batch Reference Id
	 * @param matchInvMsgVO
	 */
	public void setBatchRefId(EippMessageVO matchInvMsgVO);
	
	/**
	 * Update message delivery status for invoices and credit notes
	 * @param matchInvMsgVO
	 */
	void updateMsgDeliveryStatus(EippMessageVO matchInvMsgVO);
}
