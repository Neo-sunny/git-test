/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   10 Aug 2012
 * 
 * Purpose:      EippInvoiceBusinessRules
 * 
 * Change History: 
 * Date                       				Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Aug 10th , 20127:55:00 PM        Oracle Financial Services Software Ltd                  Initial Version  
************************************************************************************************************************************************************/

package com.bnp.eipp.services.invoice.vo;

public class EippInvoiceBusinessRulesVO {
	
	/** Bill through market place. */
	private boolean billThrMrktPlace;
	
	/** Pay through market place. */
	private boolean payThrMrktPlace;
	
	/** The market place Id */
	private String marketPlaceOrgId;
	
	/** The allow fin processing. */
	private boolean  allowFinProcessing;
	
	/** The acc idenin invoice. */
	private boolean  accIdeninInvoice;
	
	/** The allow partial payment. */
	private String  allowPartialPayment;
	
	/** The allow payment adjts. */
	private String allowPaymentAdjts;
	
	/** The allow multiple payments. */
	private boolean allowMultiplePayments;
	
	/** The pay atline item only. */
	private boolean payAtlineItemOnly;
	
	/** The allow bulkingof invoice. */
	private boolean allowBulkingofInvoice;
	
	/** The allow c notes payment level. */
	private boolean allowCNotesPaymentLevel;
	
	/** The tax computedat line item. */
	private boolean taxComputedatLineItem;
	
	/** The rebate late payment fee. */
	private boolean rebateLatePaymentFee;
	
	/** The allow pymt items approved. */
	private boolean allowPymtItemsApproved;
	
	/** The allow future dated payment. */
	private boolean allowFutureDatedPayment;
	
	/** The max allowed fut datepayment. */
	private int maxAllowedFutDatepayment;
	
	/** The allow over payment. */
	private boolean allowOverPayment;
	
	/** The allow split payments. */
	private boolean allowSplitPayments;

	public boolean isBillThrMrktPlace() {
		return billThrMrktPlace;
	}

	public void setBillThrMrktPlace(boolean billThrMrktPlace) {
		this.billThrMrktPlace = billThrMrktPlace;
	}

	public boolean isPayThrMrktPlace() {
		return payThrMrktPlace;
	}

	public void setPayThrMrktPlace(boolean payThrMrktPlace) {
		this.payThrMrktPlace = payThrMrktPlace;
	}

	public String getMarketPlaceOrgId() {
		return marketPlaceOrgId;
	}

	public void setMarketPlaceOrgId(String marketPlaceOrgId) {
		this.marketPlaceOrgId = marketPlaceOrgId;
	}

	public boolean isAllowFinProcessing() {
		return allowFinProcessing;
	}

	public void setAllowFinProcessing(boolean allowFinProcessing) {
		this.allowFinProcessing = allowFinProcessing;
	}

	public boolean isAccIdeninInvoice() {
		return accIdeninInvoice;
	}

	public void setAccIdeninInvoice(boolean accIdeninInvoice) {
		this.accIdeninInvoice = accIdeninInvoice;
	}

	public String getAllowPartialPayment() {
		return allowPartialPayment;
	}

	public void setAllowPartialPayment(String allowPartialPayment) {
		this.allowPartialPayment = allowPartialPayment;
	}

	public String getAllowPaymentAdjts() {
		return allowPaymentAdjts;
	}

	public void setAllowPaymentAdjts(String allowPaymentAdjts) {
		this.allowPaymentAdjts = allowPaymentAdjts;
	}

	public boolean isAllowMultiplePayments() {
		return allowMultiplePayments;
	}

	public void setAllowMultiplePayments(boolean allowMultiplePayments) {
		this.allowMultiplePayments = allowMultiplePayments;
	}

	public boolean isPayAtlineItemOnly() {
		return payAtlineItemOnly;
	}

	public void setPayAtlineItemOnly(boolean payAtlineItemOnly) {
		this.payAtlineItemOnly = payAtlineItemOnly;
	}

	public boolean isAllowBulkingofInvoice() {
		return allowBulkingofInvoice;
	}

	public void setAllowBulkingofInvoice(boolean allowBulkingofInvoice) {
		this.allowBulkingofInvoice = allowBulkingofInvoice;
	}

	public boolean isAllowCNotesPaymentLevel() {
		return allowCNotesPaymentLevel;
	}

	public void setAllowCNotesPaymentLevel(boolean allowCNotesPaymentLevel) {
		this.allowCNotesPaymentLevel = allowCNotesPaymentLevel;
	}

	public boolean isTaxComputedatLineItem() {
		return taxComputedatLineItem;
	}

	public void setTaxComputedatLineItem(boolean taxComputedatLineItem) {
		this.taxComputedatLineItem = taxComputedatLineItem;
	}

	public boolean isRebateLatePaymentFee() {
		return rebateLatePaymentFee;
	}

	public void setRebateLatePaymentFee(boolean rebateLatePaymentFee) {
		this.rebateLatePaymentFee = rebateLatePaymentFee;
	}

	public boolean isAllowPymtItemsApproved() {
		return allowPymtItemsApproved;
	}

	public void setAllowPymtItemsApproved(boolean allowPymtItemsApproved) {
		this.allowPymtItemsApproved = allowPymtItemsApproved;
	}

	public boolean isAllowFutureDatedPayment() {
		return allowFutureDatedPayment;
	}

	public void setAllowFutureDatedPayment(boolean allowFutureDatedPayment) {
		this.allowFutureDatedPayment = allowFutureDatedPayment;
	}

	public int getMaxAllowedFutDatepayment() {
		return maxAllowedFutDatepayment;
	}

	public void setMaxAllowedFutDatepayment(int maxAllowedFutDatepayment) {
		this.maxAllowedFutDatepayment = maxAllowedFutDatepayment;
	}

	public boolean isAllowOverPayment() {
		return allowOverPayment;
	}

	public void setAllowOverPayment(boolean allowOverPayment) {
		this.allowOverPayment = allowOverPayment;
	}

	public boolean isAllowSplitPayments() {
		return allowSplitPayments;
	}

	public void setAllowSplitPayments(boolean allowSplitPayments) {
		this.allowSplitPayments = allowSplitPayments;
	}

}
