/****************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14 Oct 2012
 * 
 * Purpose: Eipp Matching Payment Response Message Service Impl
 * 
 * Change History: 
 * Date                       	Author                                  Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 14 Oct 2012              	Prabu P                      			Initial Version
 ********************************************************************************************************************************/

package com.bnp.eipp.services.matching.payment;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.invoice.IEippReleaseService;
import com.bnp.eipp.services.matching.dao.IEippMatchingMessageDAO;
import com.bnp.eipp.services.matching.payment.bindingvo.File;
import com.bnp.eipp.services.matching.payment.bindingvo.PymtRespDetails;
import com.bnp.eipp.services.vo.common.EippMessageVO;
import com.bnp.eipp.services.vo.payment.EippPymtVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.invoice.IInvoiceUploadService;
import com.bnp.scm.services.txns.common.message.AbstractMsg;
import com.bnp.scm.services.txns.common.message.dao.IMessageDAO;

@Component
public class EippMatchingPymtRespServiceImpl implements IEippMatchingPymtRespService {

	private static final Logger LOGGER = LoggerFactory.getLogger(EippMatchingPymtRespServiceImpl.class);

	@Autowired
	private IEippMatchingMessageDAO matchingMessageDAO;

	@Autowired
	private IEippReleaseService eippReleaseService;
	
	@Autowired
	private IInvoiceUploadService invoiceService;
	
	@Autowired 
	 private BNPPropertyLoaderConfigurer propertyLoader;

	@Autowired
	private IMessageDAO messageDAO;

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.matching.payment.IEippMatchingPymtRespService#processMessage(com.bnp.scm.services.txns.common.message.AbstractMsg)
	 */
	@Override
	public void processMessage(AbstractMsg<?> message, FileDetailsVO detailsVO) {

		List<String> mapperList = new ArrayList<String>(1);
		mapperList.add("mapper/EippMatchingPymtRespMapper.xml");

		// Mapping JAXB object to custom VO object
		DozerBeanMapper mapper = new DozerBeanMapper();
		mapper.setMappingFiles(mapperList);

		List<PymtRespDetails> pymtRespDetailsList = ((File)message.getBody()).getDocument().getPymtStatusResp();
		for (PymtRespDetails pymtRespDetails : pymtRespDetailsList) {
			EippPymtVO pymtVO = mapper.map(pymtRespDetails, EippPymtVO.class);
			try {
				pymtVO.setMakerId(BNPConstants.SYSTEM);
				pymtVO.setAuditRecordStatus(StatusConstants.CREATED_RECORD);
				pymtVO.setRequestStatus(StatusConstants.WAITING_FOR_APPROVAL_REQUEST);
				pymtVO.setFileId(detailsVO.getFileId());
				if(pymtVO.getSupplierAcctIdentifier() == null || pymtVO.getSupplierAcctIdentifier().isEmpty()) {
					pymtVO.setSupplierAcctIdentifier(pymtVO.getSupplierAcctNo());
				}
				matchingMessageDAO.insertPaymentDetails(pymtVO);
				approvePaymentDetails(pymtVO, detailsVO);
			}
			catch (BNPApplicationException e) {
				//FO 7.0 Fortify Issue Fix
				LOGGER.error(e.getErrorMessage());
			}
		}
	}

	/**
	 * Approve payment details
	 * @param pymtVO
	 * @param detailsVO
	 */
	private void approvePaymentDetails(EippPymtVO pymtVO, FileDetailsVO detailsVO) {
		try {
			boolean flag = eippReleaseService.insertIntoMasterIfAutoAuthorizationEnabled(detailsVO);
			// Commented due to avoid repeating the same logic
			/*
			if (flag) {
				/*pymtVO.setCheckerId(BNPConstants.SYSTEM);
				pymtVO.setAuditRecordStatus(StatusConstants.APPROVE_RECORD);
				pymtVO.setRequestStatus(StatusConstants.REQ_SATUS_NA);
				matchingMessageDAO.approvePaymentDetails(pymtVO);
				eippInvcUploadDAOImpl.matchRecords(detailsVO.getFileId());
				detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.release.ok"));
				invoiceService.updateFileStatus(detailsVO);
				invoiceService.triggerEventLog(detailsVO,"RELEASE");
			} */
			if (!flag) {
				detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.release.pending"));
				invoiceService.updateFileStatus(detailsVO);
				invoiceService.triggerEventLog(detailsVO,"SUCCESS");
			}
		}
		catch (BNPApplicationException e) {
			detailsVO.setErrorCode(Integer.toString(e.getErrorCode()));
			detailsVO.setErrorDesc("Error during file release...");
			detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.release.pending"));
			updateFileStatus(detailsVO);
		}
	}
	
	/**
	 * Update file status
	 * @param detailsVO
	 */
	private void updateFileStatus(FileDetailsVO detailsVO) {
		try {
			invoiceService.updateFileStatus(detailsVO);
		}
		catch (Exception e) {
			//FO 7.0 Fortify Issue Fix
			LOGGER.error(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.matching.payment.IEippMatchingPymtRespService#generateReconReminderMessage(java.lang.String)
	 */
	@Override
	public void generateReconReminderMessage(EippMessageVO eippMsgVO) {
		try {
			Map<String, String> headerMap = matchingMessageDAO.getHeaderDetails(eippMsgVO.getOrgId());
			List<EippPymtVO> pymtList = matchingMessageDAO.getUnmatchedPayments(eippMsgVO.getOrgId());
		
			EippReconReminderMessage message = new EippReconReminderMessage();
			eippMsgVO.setMsgId(messageDAO.getMessageId());
			eippMsgVO.setDataList(pymtList);
			eippMsgVO.setHeaderMap(headerMap);
			message.constructMessage(eippMsgVO);
			if(message.getXmlMessage() != null) {
				eippMsgVO.getMessageVO().setData(message.getXmlMessage().getBytes());
			}
		}
		catch (BNPApplicationException e) {
			//FO 7.0 Fortify Issue Fix
			LOGGER.error(e.getErrorMessage());
		}
	}
}
