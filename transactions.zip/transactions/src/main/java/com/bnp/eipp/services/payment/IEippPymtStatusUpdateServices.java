/*****************************************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:    24 August 2012  
 * 
 * Purpose:     EIPP Payment Status Update Interface
 * 
 * Change History: 
 * Date                        Author                             Version                   Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- ----------------------------------
 *24 Aug 2012                  Reena s                      Initial Version		   
 
 ****************************************************************************************************************************************************************************************/


package com.bnp.eipp.services.payment;

import java.util.List;

import org.dozer.DozerBeanMapper;

import com.bnp.eipp.services.filemgmt.IEippFileReleaseService;
import com.bnp.eipp.services.invoice.vo.EippPymtStatusUpdateVO;
import com.bnp.eipp.services.vo.payment.EippPaymentMsgDetailVO;
import com.bnp.scm.services.common.ITransactionService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;


public interface IEippPymtStatusUpdateServices extends ITransactionService,IEippFileReleaseService {

	void releasePymtStatusFile(AbstractMessage<?> message,
			FileDetailsVO detailsVO, List<EippPymtStatusUpdateVO> dataList,DozerBeanMapper beanMapper,
			List<EippPymtStatusUpdateVO> validData) throws BNPApplicationException;
	
	EippPymtStatusUpdateVO getDetailsForRefNo(String refNo)throws BNPApplicationException;
	
	EippPymtStatusUpdateVO getSplitPaymentDetails(EippPymtStatusUpdateVO statusVO)throws BNPApplicationException;
	
	void updatePaymentStatus(EippPymtStatusUpdateVO stsUpdVo,boolean fromAuth) throws BNPApplicationException;
	
	void updateBillingStatus(EippPymtStatusUpdateVO stsUpdVo) throws BNPApplicationException;
	
	void updatePaymentStatusInMaster(EippPaymentMsgDetailVO eippPaymentMsgDetailVO) throws BNPApplicationException;
}
