package com.bnp.eipp.services.matching.payment.bindingvo;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for PymtRespDetails complex type.
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PymtRespDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="OrgDtls" type="{}OrgDtls" minOccurs="0"/>
 *         &lt;element name="Reference" type="{}RefrenceDetails"/>
 *         &lt;element name="ChqDtls" type="{}ChqDetails" minOccurs="0"/>
 *         &lt;element name="PymtInfo" type="{}PymtIdentificationDetails"/>
 *         &lt;element name="AddlRefs" type="{}AdditionalReference" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Status" type="{}Max16Text" minOccurs="0"/>
 *         &lt;element name="InvoiceInfo" type="{}InvoiceInformation" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="ErrMsgs" type="{}ErrorMessages" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PymtRespDetails", propOrder = { "orgDtls", "reference", "chqDtls", "pymtInfo", "addlRefs", "status",
		"invoiceInfo", "errMsgs" })
public class PymtRespDetails {

	@XmlElement(name = "OrgDtls")
	protected OrgDtls orgDtls;

	@XmlElement(name = "Reference", required = true)
	protected RefrenceDetails reference;

	@XmlElement(name = "ChqDtls")
	protected ChqDetails chqDtls;

	@XmlElement(name = "PymtInfo", required = true)
	protected PymtIdentificationDetails pymtInfo;

	@XmlElement(name = "AddlRefs")
	protected List<AdditionalReference> addlRefs;

	@XmlElement(name = "Status")
	protected String status;

	@XmlElement(name = "InvoiceInfo")
	protected List<InvoiceInformation> invoiceInfo;

	@XmlElement(name = "ErrMsgs")
	protected ErrorMessages errMsgs;

	/**
	 * Gets the value of the orgDtls property.
	 * @return possible object is {@link OrgDtls }
	 */
	public OrgDtls getOrgDtls() {
		return orgDtls;
	}

	/**
	 * Sets the value of the orgDtls property.
	 * @param value allowed object is {@link OrgDtls }
	 */
	public void setOrgDtls(OrgDtls value) {
		this.orgDtls = value;
	}

	/**
	 * Gets the value of the reference property.
	 * @return possible object is {@link RefrenceDetails }
	 */
	public RefrenceDetails getReference() {
		return reference;
	}

	/**
	 * Sets the value of the reference property.
	 * @param value allowed object is {@link RefrenceDetails }
	 */
	public void setReference(RefrenceDetails value) {
		this.reference = value;
	}

	/**
	 * Gets the value of the chqDtls property.
	 * @return possible object is {@link ChqDetails }
	 */
	public ChqDetails getChqDtls() {
		return chqDtls;
	}

	/**
	 * Sets the value of the chqDtls property.
	 * @param value allowed object is {@link ChqDetails }
	 */
	public void setChqDtls(ChqDetails value) {
		this.chqDtls = value;
	}

	/**
	 * Gets the value of the pymtInfo property.
	 * @return possible object is {@link PymtIdentificationDetails }
	 */
	public PymtIdentificationDetails getPymtInfo() {
		return pymtInfo;
	}

	/**
	 * Sets the value of the pymtInfo property.
	 * @param value allowed object is {@link PymtIdentificationDetails }
	 */
	public void setPymtInfo(PymtIdentificationDetails value) {
		this.pymtInfo = value;
	}

	/**
	 * Gets the value of the addlRefs property.
	 * <p>
	 * This accessor method returns a reference to the live list, not a snapshot. Therefore any modification you make to the returned list will be present inside the JAXB object. This is why there is
	 * not a <CODE>set</CODE> method for the addlRefs property.
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
     *    getAddlRefs().add(newItem);
     * </pre>
	 * <p>
	 * Objects of the following type(s) are allowed in the list {@link AdditionalReference }
	 */
	public List<AdditionalReference> getAddlRefs() {
		if (addlRefs == null) {
			addlRefs = new ArrayList<AdditionalReference>();
		}
		return this.addlRefs;
	}

	/**
	 * Gets the value of the status property.
	 * @return possible object is {@link String }
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the value of the status property.
	 * @param value allowed object is {@link String }
	 */
	public void setStatus(String value) {
		this.status = value;
	}

	/**
	 * Gets the value of the invoiceInfo property.
	 * <p>
	 * This accessor method returns a reference to the live list, not a snapshot. Therefore any modification you make to the returned list will be present inside the JAXB object. This is why there is
	 * not a <CODE>set</CODE> method for the invoiceInfo property.
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
     *    getInvoiceInfo().add(newItem);
     * </pre>
	 * <p>
	 * Objects of the following type(s) are allowed in the list {@link InvoiceInformation }
	 */
	public List<InvoiceInformation> getInvoiceInfo() {
		if (invoiceInfo == null) {
			invoiceInfo = new ArrayList<InvoiceInformation>();
		}
		return this.invoiceInfo;
	}

	/**
	 * Gets the value of the errMsgs property.
	 * @return possible object is {@link ErrorMessages }
	 */
	public ErrorMessages getErrMsgs() {
		return errMsgs;
	}

	/**
	 * Sets the value of the errMsgs property.
	 * @param value allowed object is {@link ErrorMessages }
	 */
	public void setErrMsgs(ErrorMessages value) {
		this.errMsgs = value;
	}

}
