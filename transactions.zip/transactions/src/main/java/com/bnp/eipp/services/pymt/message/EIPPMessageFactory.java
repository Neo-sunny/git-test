package com.bnp.eipp.services.pymt.message;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.txns.common.message.AbstractMessage;
import com.bnp.scm.services.txns.common.message.IMessageResponse;
import com.bnp.scm.services.txns.common.message.IMessageService;

/**
 * @Author : Oracle Financial Services Software Limited
 * @Name : MessageFactory.java
 * @Description : This class is used to create message objects
 */
@Component("bnpEIPPMessageFactory")
public class EIPPMessageFactory implements IEIPPMessageFactory {

	@Autowired
	private BNPPropertyLoaderConfigurer propertyLoader;
	
	@Autowired
	private BeanFactory beanFactory;

	/**
	 * Get the message instance
	 * @param messageType
	 * @return AbstractMessage
	 * @throws BNPApplicationException
	 */
	public AbstractMessage<?> getMessageInstance(final String messageType) throws BNPApplicationException {
		if (messageType == null) {
			return null;
		}
		else if(messageType.equals(propertyLoader.getValue("message.type.eipp.payment.request"))){
			return new PaymentInitiateMessage();
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.IMessageFactory#getMessageService(java.lang.String)
	 */
	@Override
	public IMessageService getMessageService(String messageType) throws BNPApplicationException {
		if (messageType == null) {
			return null;
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.IMessageFactory#getMessageResponse(java.lang.String)
	 */
	@Override
	public IMessageResponse getMessageResponse(String messageType) throws BNPApplicationException {
		if (messageType == null) {
			return null;
		}
		return null;
	}
}
