/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 28, 20122:50:41 PM
 * 
 * Purpose:      DisputeDetailCustFieldsVO.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 28, 20122:50:41 PM        Oracle Financial Services Software Ltd                  Initial Version  
 * 26 Sep 2012    				 Dinesh D							                     MFU - EIPP Disputes 
************************************************************************************************************************************************************/

package com.bnp.eipp.services.vo.dispute;

import java.io.Serializable;
import java.math.BigDecimal;

public class DisputeCustFieldsVO implements Serializable {

	private long dispId;
	
	private long fkId;
	
	private String fieldName;
	
	private BigDecimal oldValue;
	
	private BigDecimal newValue;
	
	private long lineItemId;
	
	private String refNo;

	/**
	 * @return the dispId
	 */
	public long getDispId() {
		return dispId;
	}

	/**
	 * @param dispId the dispId to set
	 */
	public void setDispId(long dispId) {
		this.dispId = dispId;
	}

	/**
	 * @return the fieldName
	 */
	public String getFieldName() {
		return fieldName;
	}

	/**
	 * @param fieldName the fieldName to set
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	/**
	 * @return the oldValue
	 */
	public BigDecimal getOldValue() {
		return oldValue;
	}

	/**
	 * @param oldValue the oldValue to set
	 */
	public void setOldValue(BigDecimal oldValue) {
		this.oldValue = oldValue;
	}

	/**
	 * @return the newValue
	 */
	public BigDecimal getNewValue() {
		return newValue;
	}

	/**
	 * @param newValue the newValue to set
	 */
	public void setNewValue(BigDecimal newValue) {
		this.newValue = newValue;
	}

	/**
	 * @param fkId the fkId to set
	 */
	public void setFkId(long fkId) {
		this.fkId = fkId;
	}

	/**
	 * @return the fkId
	 */
	public long getFkId() {
		return fkId;
	}

	/**
	 * @return the refNo
	 */
	public String getRefNo() {
		return refNo;
	}


	/**
	 * @param refNo the refNo to set
	 */
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	/**
	 * @return the lineItemId
	 */
	public long getLineItemId() {
		return lineItemId;
	}

	/**
	 * @param lineItemId the lineItemId to set
	 */
	public void setLineItemId(long lineItemId) {
		this.lineItemId = lineItemId;
	}

	@Override
	public boolean equals(Object obj) {
		if(this==obj)
		{
			return true;
		}
		if(obj instanceof DisputeCustFieldsVO)
		{
			return this.refNo.equals(((DisputeCustFieldsVO) obj).getRefNo());
		}
		return false;
	}
	public int hashCode() {
		return this.refNo.hashCode();
	}
	
}
