/****************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14 Oct 2012
 * 
 * Purpose: Eipp Matching Payment Response Message
 * 
 * Change History: 
 * Date                       	Author                                  Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 14 Oct 2012              	Prabu P                      			Initial Version
 ********************************************************************************************************************************/

package com.bnp.eipp.services.matching.payment;

import com.bnp.eipp.services.matching.payment.bindingvo.ErrorDescription;
import com.bnp.eipp.services.matching.payment.bindingvo.File;
import com.bnp.eipp.services.matching.payment.bindingvo.Header;
import com.bnp.eipp.services.matching.payment.bindingvo.Message;
import com.bnp.eipp.services.matching.payment.bindingvo.ObjectFactory;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.AbstractVO;
import com.bnp.scm.services.txns.common.message.AbstractMsg;
import com.bnp.scm.services.txns.util.PropertiesReader;
import com.bnp.scm.services.txns.util.xml.XmlValidationEventHandler;

public class EippMatchingPymtRespMessage extends AbstractMsg<Message> {

	private ObjectFactory factory;

	/**
	 * Constructor to create basic objects for message
	 */
	@Override
	public void createInstance() throws BNPApplicationException {
		this.factory = new ObjectFactory();
		this.message = new Message();
		this.body = new File();
		this.header = new Header();
		this.errorDescription = new ErrorDescription();
	}

	/*
	 * (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.AbstractMessage#createHeader(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void createHeader(AbstractVO abstractVO) throws BNPApplicationException {

	}

	/*
	 * (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.AbstractMessage#createBody(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void createBody(AbstractVO abstractVO) throws BNPApplicationException {
	}

	/*
	 * (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.AbstractMessage#createBody(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void createErrorDescription(AbstractVO abstractVO) throws BNPApplicationException {

	}

	/*
	 * (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.AbstractMessage#createMessage(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void createMessage() throws BNPApplicationException {
		if (factory == null) {
			this.factory = new ObjectFactory();
		}
		Message message = (Message)this.getMessage();
		message.setHeader((Header)this.getHeader());
		this.setMessage(message);
		this.setJaxbElementObj(factory.createMsg(message));
	}

	/*
	 * (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.IMessage#setBindingProperties()
	 */
	@Override
	public void setBindingProperties() throws BNPApplicationException {
		this.properties.setBindingClass(Message.class);
		this.properties.setValidateXsd(true);
		this.properties.setXsdPath(PropertiesReader.getProperty("message.eipp.payment.status.response.xsd.path"));
		this.properties.setEventHandler(new XmlValidationEventHandler());
		this.setProperties(properties);
	}
}
