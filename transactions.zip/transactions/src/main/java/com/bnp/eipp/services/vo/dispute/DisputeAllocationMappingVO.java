/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Feb 22, 20127:55:00 PM
 * 
 * Purpose:      DisputeAllocationMappingVO.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 22, 20127:55:00 PM        Oracle Financial Services Software Ltd                  Initial Version  
************************************************************************************************************************************************************/

package com.bnp.eipp.services.vo.dispute;

import java.io.Serializable;

public class DisputeAllocationMappingVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5295040572785289594L;

	private String serialNo;
	
	private String disputeRefNo;
	
	private long deptId;
	
	private String userId;
	
	private String allocationType;
	
	private String active;
	
	private int level;
	
	private String status;
	
	private String reAssignedBy;
	
	private String reAssignedDate;
	
	private String approvedBy;
	
	private String approvedDate;
	
	private String approvalLevel;
	
	private String orgRole;
	
	private String deptName;
	
	/**
	 * @return the deptName
	 */
	public String getDeptName() {
		return deptName;
	}

	/**
	 * @param deptName the deptName to set
	 */
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	/**
	 * @return the disputeRefNo
	 */
	public String getDisputeRefNo() {
		return disputeRefNo;
	}

	/**
	 * @param disputeRefNo the disputeRefNo to set
	 */
	public void setDisputeRefNo(String disputeRefNo) {
		this.disputeRefNo = disputeRefNo;
	}

	/**
	 * @return the deptId
	 */
	public long getDeptId() {
		return deptId;
	}

	/**
	 * @param deptId the deptId to set
	 */
	public void setDeptId(long deptId) {
		this.deptId = deptId;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the allocationType
	 */
	public String getAllocationType() {
		return allocationType;
	}

	/**
	 * @param allocationType the allocationType to set
	 */
	public void setAllocationType(String allocationType) {
		this.allocationType = allocationType;
	}

	/**
	 * @return the active
	 */
	public String getActive() {
		return active;
	}

	/**
	 * @param active the active to set
	 */
	public void setActive(String active) {
		this.active = active;
	}

	/**
	 * @return the level
	 */
	public int getLevel() {
		return level;
	}

	/**
	 * @param level the level to set
	 */
	public void setLevel(int level) {
		this.level = level;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the reAssignedBy
	 */
	public String getReAssignedBy() {
		return reAssignedBy;
	}

	/**
	 * @param reAssignedBy the reAssignedBy to set
	 */
	public void setReAssignedBy(String reAssignedBy) {
		this.reAssignedBy = reAssignedBy;
	}

	/**
	 * @return the reAssignedDate
	 */
	public String getReAssignedDate() {
		return reAssignedDate;
	}

	/**
	 * @param reAssignedDate the reAssignedDate to set
	 */
	public void setReAssignedDate(String reAssignedDate) {
		this.reAssignedDate = reAssignedDate;
	}

	/**
	 * @return the approvedBy
	 */
	public String getApprovedBy() {
		return approvedBy;
	}

	/**
	 * @param approvedBy the approvedBy to set
	 */
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	/**
	 * @return the approvedDate
	 */
	public String getApprovedDate() {
		return approvedDate;
	}

	/**
	 * @param approvedDate the approvedDate to set
	 */
	public void setApprovedDate(String approvedDate) {
		this.approvedDate = approvedDate;
	}

	/**
	 * @return the approvalLevel
	 */
	public String getApprovalLevel() {
		return approvalLevel;
	}

	/**
	 * @param approvalLevel the approvalLevel to set
	 */
	public void setApprovalLevel(String approvalLevel) {
		this.approvalLevel = approvalLevel;
	}

	/**
	 * @return the orgRole
	 */
	public String getOrgRole() {
		return orgRole;
	}

	/**
	 * @param orgRole the orgRole to set
	 */
	public void setOrgRole(String orgRole) {
		this.orgRole = orgRole;
	}

	/**
	 * @return the serialNo
	 */
	public String getSerialNo() {
		return serialNo;
	}

	/**
	 * @param serialNo the serialNo to set
	 */
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}

}
