/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   18 July 2012
 * 
 * Purpose:      EippDataFileProcessor
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 July 2012        Oracle Financial Services Software Ltd                  Initial Version
 * 10 Aug 2012    				    Gangadharan R							   MFU - Payment Preparation
 * 15 Sep 2012    				    Prabakaran S							   Addressed SONAR violations   
 * 17 Oct 2012						Prabakaran S							   Fix for ST Defect # 6793
 * 22 OCT 2012					    Sadhana A V						           Validation error corrected   
************************************************************************************************************************************************************/

package com.bnp.eipp.services.filemgmt.processor;

import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnp.eipp.services.filemgmt.IFileProcessService;
import com.bnp.eipp.services.invoice.vo.EippTransactionVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.common.BNPPropertyLoaderConfigurer;
import com.bnp.scm.services.common.ILocaleMessageLoaderService;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.StatusConstants;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.invoice.vo.InvalidFileDataVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;
import com.bnp.scm.services.txns.common.message.bindingvo.RootXmlElement;

/**
 * This class serves as a base class for all EIPP file upload functionality.
 *  
 * @author prabakarans
 * @author sadhanav
 *
 * @param <X> - The JAXB class name of the root element of the corresponding XML. 
 * @param <V> - The value object used for the corresponding file upload
 */
public abstract class EippAbstractDataFileProcessor<X extends RootXmlElement, V extends EippTransactionVO> implements IEippAbstractDataFileProcessor<X , V> {
	
	protected static final Logger LOGGER = LoggerFactory.getLogger(EippAbstractDataFileProcessor.class);
	
	@Autowired
	protected IFileProcessService fileProcessService;
	
	@Autowired
	protected BNPPropertyLoaderConfigurer propertyLoader;
	
	@Autowired
	protected ILocaleMessageLoaderService localeMsgService;
	
	/**
	 * Holds the data objects from the XML
	 */
	protected List<X> xmlDataList;
	
	/**
	 * Holds the valid business value objects
	 */
	protected List<V> validDataList;
	
	/**
	 * Holds the invalid data
	 */
	protected List<InvalidFileDataVO> invalidDataList;
	
	/**
	 * Holds all the business value objects which will be used for generating functional ack
	 */
	protected List<V> dataList;

	/**
	 * Mapper class to map the values from JAXB object to Business value object
	 */
	protected DozerBeanMapper beanMapper;
	
	/**
	 * Holds the file details
	 */
	protected FileDetailsVO detailsVO;

	/**
	 * Default constructor
	 */
	protected EippAbstractDataFileProcessor() {
		invalidDataList = new ArrayList<InvalidFileDataVO>();
		validDataList = new ArrayList<V>();
		dataList = new ArrayList<V>();
		beanMapper = new DozerBeanMapper(getMappingFiles());
	}
	
	/**
	 * This API will return the list of mapping files that will be used to copy the 
	 * values from the JAXB objects to the business value objects
	 * @return a list of mapping files
	 */
	protected abstract List<String> getMappingFiles();
	
	/**
	 * This API processes the JAXB object and copies all the values from the JAXB to the corresponding
	 * business value object.
	 * @param xmlData - JAXB object
	 * @return the business value object with all the values copied
	 */
	protected abstract V getValueObject(X xmlData); 
	
	/**
	 * This API will be used to perform functional validations
	 * @param valueObj - Business value object on which the functional validations will be applied
	 * @return returns whether the value object is a valid oen or not
	 * @throws BNPApplicationException
	 */
	protected abstract boolean isValidData(V valueObj) throws BNPApplicationException;
	
	/**
	 * This API inserts the details of the business value objects into their corresponding trans table
	 * @param valueObjectList
	 * @throws BNPApplicationException
	 */
	protected abstract void insertFileDetailsIntoTrans(
			List<V> valueObjectList) throws BNPApplicationException;
	
	/**
	 * This API inserts the details of the business value objects from trans into history
	 * @param detailsVO
	 * @throws BNPApplicationException
	 */
	protected abstract void insertFileDetailsIntoHistFromTrans(
				FileDetailsVO detailsVO) throws BNPApplicationException;
	
	/**
	 * This API releases the file based on the load type flag
	 * @param msg - the Message object of the corresponding XML
	 * @param detailsVO - the details of the file
	 * @throws BNPApplicationException
	 */
	protected abstract void releaseFile(
			AbstractMessage<?> msg, FileDetailsVO detailsVO) throws BNPApplicationException;
	
	/**
	 * This API returns the list of JAXB objects extracted from the XML
	 * @param msg - the message object of the corresponding XML
	 * @return the list of JAXB objects
	 */
	protected abstract List<X> getXmlDataList(AbstractMessage<?> msg);
	
	/**
	 * This API processes the input file
	 * @param msg - the message object of the corresponding XML
	 * @param detailsVO
	 * @throws BNPApplicationException
	 */
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor = Exception.class)
	public void processFile(AbstractMessage<?> msg, FileDetailsVO detailsVO) 
							throws BNPApplicationException {
		
		this.xmlDataList = getXmlDataList(msg);
		this.detailsVO = detailsVO;
		
		V valueObj = null;
		for (X xmlData : xmlDataList) {
			valueObj = getValueObject(xmlData);
			valueObj.setUserType(detailsVO.getUserType());
			valueObj.setCurrentUserId(detailsVO.getUserId());
			if(valueObj.getOrgId()==null){
				valueObj.setOrgId(detailsVO.getSenderOrgId());
			}
			if (isValidData(valueObj)) {
				validDataList.add(valueObj);
			}
			dataList.add(valueObj);
		}
		
		if (validDataList == null || validDataList.isEmpty()) {
			detailsVO.setFileUploadStatus(StatusConstants.VALIDATION_FAILED);
			detailsVO.setFileStatus(StatusConstants.VALIDATION_FAILED);
			detailsVO.setErrorCode(Integer.toString(ErrorConstants.NO_VALID_EIPP_RECORDS_FOUND_IN_FILE));
			detailsVO.setErrorDesc("No valid records found");
			fileProcessService.updateFileStatus(detailsVO);
			fileProcessService.triggerEventLog(detailsVO,"FAILURE");
		}else{
			
			boolean canUploadPartialFile = fileProcessService.canUploadPartialFile(
							detailsVO.getSenderOrgId());
			
			insertFileDetailsIntoTrans(validDataList);
			insertFileDetailsIntoHistFromTrans(detailsVO);
			fileProcessService.updateReprocessFlag(invalidDataList, detailsVO);
			
			if (!canUploadPartialFile && !invalidDataList.isEmpty()) {
				detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.validation.fail"));
				detailsVO.setFileStatus(StatusConstants.VALIDATION_FAILED);
				detailsVO.setErrorDesc("Business validation failed for few records and " +
						"partial upload is not supported for the Organization " + detailsVO.getSenderOrgId());
				detailsVO.setCurrentUserId(BNPConstants.SYSTEM);				
				fileProcessService.deleteFile(detailsVO);
				validDataList.clear();
				fileProcessService.triggerEventLog(detailsVO,"FAILURE");
			} 
		}
		
		if (!invalidDataList.isEmpty()) {
			fileProcessService.insertInvalidRecords(invalidDataList);
		}
		
		boolean isAutoRelease = fileProcessService.isAutoReleaseEnabled(
				detailsVO.getSenderOrgId());
		
		if (isAutoRelease && !validDataList.isEmpty()) {
			detailsVO.setReleasedBy(BNPConstants.SYSTEM);
			releaseFile(msg, detailsVO);
		}
		else {
			if (validDataList != null && !validDataList.isEmpty()) {
				detailsVO.setFileUploadStatus(propertyLoader.getValue("file.status.release.pending"));
				fileProcessService.updateFileStatus(detailsVO);
				fileProcessService.triggerEventLog(detailsVO,"SUCCESS");
			}
		}
		
		uploadExitOperation();
	}
	
	/**
	 * This is used to hold the operations whatever required during the end of file upload process
	 */
	protected void uploadExitOperation() throws BNPApplicationException{
		//Implemented individually if required
	}
	
	protected boolean validateOrgData(EippTransactionVO eippTransactionVO) throws BNPApplicationException{
		boolean isInvalid = false;
		int errorCode=0;
		populateFileDetails(detailsVO);
		
		if (isNull(eippTransactionVO.getSupplierOrgId()) &&
				isNull(eippTransactionVO.getSupplierErpId())) {
			errorCode = ErrorConstants.SUPP_ORG_OR_ERP_MANDATORY;
			addToErrorDataList(eippTransactionVO.getTransactionType(), eippTransactionVO.toDataString(), errorCode, eippTransactionVO);
			isInvalid = true;
			return isInvalid;
		}
		
		if (isNull(eippTransactionVO.getBuyerOrgId()) && 
				isNull(eippTransactionVO.getBuyerErpId())) {
			errorCode = ErrorConstants.BUYER_ORG_OR_ERP_MANDATORY;
			addToErrorDataList(eippTransactionVO.getTransactionType(), eippTransactionVO.toDataString(), errorCode, eippTransactionVO);
			isInvalid = true;
			return isInvalid;
		}
		
		if(detailsVO.getSenderOrgType().equals(BNPConstants.MARKET_PLACE)){
			if (isNull(eippTransactionVO.getMarketPlaceOrgId())){
				errorCode = ErrorConstants.MARKET_PLACE_ORG_ID_IS_MANDATORY;
				addToErrorDataList(eippTransactionVO.getTransactionType(), eippTransactionVO.toDataString(), errorCode, eippTransactionVO);
				isInvalid = true;
				return isInvalid;
			}

			if (!isNull(eippTransactionVO.getMarketPlaceOrgId()) && !detailsVO.getSenderOrgId().equals(eippTransactionVO.getMarketPlaceOrgId())){
				errorCode = ErrorConstants.MARKET_PLACE_ORG_ID_SHOULD_BE_SENDER_ORG_ID;
				addToErrorDataList(eippTransactionVO.getTransactionType(), eippTransactionVO.toDataString(), errorCode, eippTransactionVO);
				isInvalid = true;
				return isInvalid;
			}
			
			if(!isBillThroughMarketPlace(eippTransactionVO.getBillType(), eippTransactionVO.getMarketPlaceOrgId())){
				errorCode = ErrorConstants.BILL_THRO_MARKET_PLACE_NOT_ENABLED;
				addToErrorDataList(eippTransactionVO.getTransactionType(), eippTransactionVO.toDataString(), errorCode, eippTransactionVO);
				isInvalid = true;
				return isInvalid;
			}
		}
		
		if (detailsVO.getModelType().equals(BNPConstants.MODEL_TYPE_SCM)) {
			isInvalid =  getSellerId(eippTransactionVO, detailsVO.getModelType()) || isInvalid;
			isInvalid = getBuyerId(eippTransactionVO, detailsVO.getModelType()) || isInvalid;
			isInvalid = checkBuyerSellerLinked(eippTransactionVO.getSupplierOrgId(), 
					eippTransactionVO.getBuyerOrgId(), eippTransactionVO.getBillType(), eippTransactionVO) || isInvalid;
		} else if(detailsVO.getModelType().equals(BNPConstants.MODEL_TYPE_BCM)) {
			isInvalid = getBuyerId(eippTransactionVO, detailsVO.getModelType()) || isInvalid;
			isInvalid = getSellerId(eippTransactionVO, detailsVO.getModelType()) || isInvalid;
			isInvalid = checkBuyerSellerLinked(eippTransactionVO.getBuyerOrgId(), 
					eippTransactionVO.getSupplierOrgId(), eippTransactionVO.getBillType(), eippTransactionVO) || isInvalid;
		}
		
		if ( (detailsVO.getModelType().equals(BNPConstants.MODEL_TYPE_BCM) 
				&& !(detailsVO.getSenderOrgType().equals(BNPConstants.MARKET_PLACE))) &&  
				!(detailsVO.getSenderOrgId().equals(eippTransactionVO.getBuyerOrgId()) || 
						detailsVO.getSenderOrgId().equals(eippTransactionVO.getSupplierOrgId())) ) {
			errorCode = ErrorConstants.INVALID_BCM_SENDER_ORG;
			addToErrorDataList(eippTransactionVO.getTransactionType(), eippTransactionVO.toDataString(), errorCode, eippTransactionVO);
			isInvalid = true;
		}
		
		errorCode = validateBuyerOnlyUpload(eippTransactionVO);
		isInvalid = errorCode > 0 || isInvalid;
		
		return isInvalid;
		
	}
	
	protected int validateBuyerOnlyUpload(EippTransactionVO eippTransactionVO){
		 int errorCode = 0;
		if ( (detailsVO.getModelType().equals(BNPConstants.MODEL_TYPE_SCM) 
				&& !(detailsVO.getSenderOrgType().equals(BNPConstants.MARKET_PLACE))) && 
				!(detailsVO.getSenderOrgId().equals(eippTransactionVO.getSupplierOrgId()))) {
			errorCode = ErrorConstants.INVALID_SCM_SENDER_ORG;
			addToErrorDataList(eippTransactionVO.getTransactionType(), eippTransactionVO.toDataString(), errorCode, eippTransactionVO);
		}
		return errorCode;
	}
	
	protected void populateFileDetails(FileDetailsVO detailsVO) throws BNPApplicationException{
		detailsVO.setModelType(fileProcessService.getModelTypeForOrganization(detailsVO.getSenderOrgId()));
		
		detailsVO.setSenderOrgType(fileProcessService.getOrgTypeForOrganization(detailsVO.getSenderOrgId()));
		
		String branchTimezone = fileProcessService.getTimezoneForOrganization(detailsVO.getSenderOrgId());
		detailsVO.setTimeZoneTZ(TimeZone.getTimeZone(branchTimezone));
	}
	
	protected boolean isNull(String userInput){
		if(userInput !=null && userInput.trim().length()>0){
			return false;	
		}else{
			return true;
		}
	}
	
	protected void addToErrorDataList (String transactionType , String errorData, int errorCode, EippTransactionVO eippTransactionVO) {
		InvalidFileDataVO invalidData = createInvalidFileDataVO(transactionType, errorData, errorCode,eippTransactionVO.getRefNo());
		invalidDataList.add(invalidData);
		eippTransactionVO.addToInvalidDataList(invalidData);
	}
	
	protected InvalidFileDataVO createInvalidFileDataVO(String transactionType,String errorData, 
			int errorCode, String refNo) {
		InvalidFileDataVO invalidData = new InvalidFileDataVO();
		invalidData.setFileID(detailsVO.getFileId());
		invalidData.setErrorMessage(String.valueOf(errorCode));
		invalidData.setErrorData(errorData);
		invalidData.setPaymentType(transactionType);
		invalidData.setErrorDescription(localeMsgService.getMessage("en_US", errorCode));
		invalidData.setRefNo(refNo);
		return invalidData;
	}
	
	protected boolean getSellerId(EippTransactionVO dataVO,String modelType) {
		boolean isInvalid = false;
		String sellerId = null;
		String buyerOrgId=dataVO.getBuyerOrgId();
		String sellerOrgId=dataVO.getSupplierOrgId();
		String sellerERPId=dataVO.getSupplierErpId();
		String billType = dataVO.getBillType();
		int errorCode=0;
		try {

			if (!isNull(sellerERPId)) {
					List<String> sellerIdList = null;
					if (modelType.equals(BNPConstants.MODEL_TYPE_SCM)) {
						sellerIdList = fileProcessService.getCustomerOrgId(billType, sellerERPId);
						
						try {
							sellerId = getCustomerOrgId(sellerIdList, sellerOrgId);
						} catch (BNPApplicationException e) {
							errorCode = e.getErrorCode();
						}
					} else {
						sellerIdList = fileProcessService.getCounterPartyOrgId(buyerOrgId, billType, sellerERPId);
						
						try {
							sellerId = getCounterPartyOrgId(sellerIdList, sellerOrgId);
						} catch (BNPApplicationException e) {
							errorCode = e.getErrorCode();
						}
					}
					if(isNull(sellerId) && errorCode == 0) {
							//Seller Organization does not exist for the Seller ERP id.
							errorCode=ErrorConstants.INVALID_SELLER_ERP;
					}
			}
			if (!isNull(sellerOrgId) && !isNull(sellerERPId) && !sellerOrgId.equals(sellerId)) {
				
				errorCode=ErrorConstants.ENTERED_SELLERORG_MISMATCH;
							
			}	
			if (errorCode>0) {
				addToErrorDataList(dataVO.getTransactionType(), dataVO.toDataString(),errorCode, dataVO);
				isInvalid = true;
			} else if(!isNull(sellerId)) {
				dataVO.setSupplierOrgId(sellerId);
			}

		} catch (BNPApplicationException e) {
			addToErrorDataList(dataVO.getTransactionType(), 
					dataVO.toDataString(), e.getErrorCode(), dataVO);
			isInvalid = true;

		}
		return isInvalid;
	}
	
	protected boolean getBuyerId(EippTransactionVO dataVO,String modelType) {
		boolean isInvalid = false;
		String buyerId = null;
		String buyerOrgId=dataVO.getBuyerOrgId();
		String sellerOrgId = dataVO.getSupplierOrgId();
		String buyerERPId = dataVO.getBuyerErpId();
		String billType = dataVO.getBillType();
		int errorCode=0;
		try {

			if (!isNull(buyerERPId)) {
					List<String> buyerIdList = null;
					if (modelType.equals(BNPConstants.MODEL_TYPE_BCM)) {
						 buyerIdList = fileProcessService.getCustomerOrgId(billType, buyerERPId);
						
						try {
							buyerId = getCustomerOrgId(buyerIdList, buyerOrgId);
						} catch (BNPApplicationException e) {
							errorCode = e.getErrorCode();
						}
					} else {
						buyerIdList = fileProcessService.getCounterPartyOrgId(sellerOrgId, billType, buyerERPId);
						
						try {
							buyerId = getCounterPartyOrgId(buyerIdList, buyerOrgId);
						} catch (BNPApplicationException e) {
							errorCode = e.getErrorCode();
						}
					}
					if(isNull(buyerId) && errorCode == 0) {
							//Seller Organization does not exist for the Seller ERP id.
							errorCode=ErrorConstants.INVALID_BUYER_ERP;
					}
			}
			
			if (!isNull(buyerOrgId) && !isNull(buyerERPId) && !buyerOrgId.equals(buyerId)) {
				
				errorCode=ErrorConstants.ENTERED_BUYERORG_MISMATCH;
							
			}	
			
			if (errorCode>0) {
				addToErrorDataList(dataVO.getTransactionType(), dataVO.toDataString(),errorCode, dataVO);
				isInvalid = true;
			} else if(!isNull(buyerId)) {
				dataVO.setBuyerOrgId(buyerId);
			}

		} catch (BNPApplicationException e) {
			addToErrorDataList(dataVO.getTransactionType(), 
					dataVO.toDataString(), e.getErrorCode(), dataVO);
			isInvalid = true;

		}
		return isInvalid;
	}
	
	private String getCustomerOrgId(List<String> orgIdList, 
			String orgIdInFile) throws BNPApplicationException {
		String orgId = null;
		if (orgIdInFile != null) {
			if (orgIdList != null && !orgIdList.isEmpty()) {
				if (orgIdList.indexOf(orgIdInFile) != -1) {
					orgId = orgIdInFile; 
				}
			} 
		} else {
			if (orgIdList != null && !orgIdList.isEmpty()) {
				if (orgIdList.size() > 1) {
					throw new BNPApplicationException(ErrorConstants.MULTIPLE_CUSTOMERS_WITH_SAME_ERP_ERROR);
				} else if (orgIdList.size() == 1) {
					orgId = orgIdList.get(0);
				}
			} 
		}
		return orgId;
	}
	
	private String getCounterPartyOrgId(
			List<String> cntOrgIdList, String orgIdInFile) throws BNPApplicationException {
		String cntrPartyId = null;
		
		if (orgIdInFile != null) {
			if (cntOrgIdList != null && !cntOrgIdList.isEmpty()) {
				if (cntOrgIdList.indexOf(orgIdInFile) != -1) {
					cntrPartyId = orgIdInFile; 
				}
			} 
		} else {
			if (cntOrgIdList != null && !cntOrgIdList.isEmpty()) {
				if (cntOrgIdList.size() > 1) {
					throw new BNPApplicationException(ErrorConstants.MULTIPLE_COUNTER_PARTY_WITH_SAME_ERP_ERROR);
				} else if (cntOrgIdList.size() == 1) {
					cntrPartyId = cntOrgIdList.get(0);
				}
			} 
		}
		return cntrPartyId;
	}
	
	protected boolean checkBuyerSellerLinked(String custOrgId,String cntpOrgId,String billType,EippTransactionVO eippTransactionVO) throws BNPApplicationException {
		boolean isInvalid = false;
		
		fileProcessService.isBuyerSellerLinkedToMarketPlace(custOrgId, cntpOrgId, billType, eippTransactionVO.getMarketPlaceOrgId());
		if(detailsVO.getSenderOrgType().equals(BNPConstants.MARKET_PLACE)){
			if (isNull(custOrgId) || isNull(cntpOrgId) || !fileProcessService.isBuyerSellerLinkedToMarketPlace(custOrgId, cntpOrgId, billType, eippTransactionVO.getMarketPlaceOrgId())) {
				addToErrorDataList(eippTransactionVO.getTransactionType(), eippTransactionVO.toDataString(), 
						ErrorConstants.BUYER_SELLER_NOT_LINKED_MARKET_PLACE, eippTransactionVO);
				isInvalid = true;
			}
		}
		else{
			if (isNull(custOrgId) || isNull(cntpOrgId) || !fileProcessService.isBuyerSellerLinked(custOrgId, cntpOrgId, billType)) {
				addToErrorDataList(eippTransactionVO.getTransactionType(), eippTransactionVO.toDataString(), 
						ErrorConstants.BUYER_SELLER_NOT_LINKED, eippTransactionVO);
				isInvalid = true;
			}
		}
		
		return isInvalid;
	}
	
	/**
	 * Validates whether bill through market place is enabled for the bill type 
	 * @param billType
	 * @param marketPlaceOrgId
	 * @return
	 * @throws BNPApplicationException 
	 */
	protected boolean isBillThroughMarketPlace(String billType, String marketPlaceOrgId) throws BNPApplicationException {
		return fileProcessService.isBillThroughMarketPlace(billType, marketPlaceOrgId);
	}
	/**
	 * Checks if is string empty.
	 *
	 * @param input the input
	 * @return true, if is string empty
	 */
	protected boolean isStringEmpty(String input){
		if(input == null || input.trim().length() == 0){
			return true;
		}
		return false;
	}
}
