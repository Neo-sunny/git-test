/* ************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  Jan 04, 2012
 * 
 * Purpose:     This class is used to handle validation for XML with XSD
 * 
 * Change History: 
 * Date                                                  Author                                                    Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * Jan 04, 2012                      Oracle Financial Services Software Ltd         Initial Version
 
 ***************************************************************************/
package com.bnp.eipp.services.pymt.message.xml;

import javax.xml.bind.ValidationEvent;

import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.txns.util.xml.XmlValidationEventHandler;

/**
 * @Author : Oracle Financial Services Software Limited
 * @Name : DiscountRequestEventHandler
 * @Description : This class is used to handle validation for XML with XSD
 */
public class PaymentInitiateEventHandler extends XmlValidationEventHandler {
	private StringBuilder errorCode = new StringBuilder();
	 private static final String ELEMENT = "element";
	 private static final String IS = "is";
    private static final String BRACE_START = "{";
    private static final String BRACE_END = "}";

    public StringBuilder getErrorLog() {
		return errorCode;
	}

	/*
	 * (non-Javadoc)
	 * @see javax.xml.bind.ValidationEventHandler#handleEvent(javax.xml.bind.ValidationEvent)
	 */
	@Override
	public boolean handleEvent(ValidationEvent event) {
		
		/* 976332 CSCDEV-2683 27-NOV-2014:START
		System.out.println("\nEVENT");
		//System.out.println("SEVERITY:  " + event.getSeverity());
		
		System.out.println("MESSAGE:  " + event.getMessage());
		System.out.println("LINKED EXCEPTION:  " + event.getLinkedException());
		System.out.println("OBJECT:  " + event.getLocator().getObject());
		976332 CSCDEV-2683 27-NOV-2014:END
		*/
		if (event.getSeverity()==ValidationEvent.FATAL_ERROR || event.getSeverity()==ValidationEvent.ERROR){
            String message = event.getMessage(); 
         	String tagName = "";
            if(message.contains("is expected")) {
            	tagName = message.substring(message.indexOf(BRACE_START) + 1, message.indexOf(BRACE_END));
            	if(getErrorCode(tagName) !=0){
            	errorCode.append(getErrorCode(tagName));
            	}
            	else{
            		errorCode.append(tagName + " is expected ");
            	}
            	errorCode.append(",");
            }
            if(message.contains("is not valid")) {
            	tagName = message.substring(message.indexOf(ELEMENT) + ELEMENT.length(), message.indexOf(IS));
            	errorCode.append( tagName + " is not valid");
            	errorCode.append(",");
            }
            else if(message.contains("Unparseable date")) {
            	errorCode.append( "Invalid date format");
            	errorCode.append(",");
            }
		}
		return true;
	}

	private int getErrorCode(String tagName) {
		int errorCode = 0;
		
		if(tagName.equalsIgnoreCase("BIC")){
			errorCode = ErrorConstants.BANK_ID_CODE_EXPECTED;
		}
		
		if(tagName.contains("Id")){
			errorCode = ErrorConstants.ACCOUNT_NUMBER_EXPECTED;
		}
		return errorCode;
	}
}
