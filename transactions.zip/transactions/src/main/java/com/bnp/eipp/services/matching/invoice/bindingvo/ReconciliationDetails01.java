package com.bnp.eipp.services.matching.invoice.bindingvo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for ReconciliationDetails01 complex type.
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ReconciliationDetails01">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="InvcDtls" type="{}InvoiceAndPODetails01" minOccurs="0"/>
 *         &lt;element name="CnDtls" type="{}CreditNoteDetails01" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReconciliationDetails01", propOrder = { "invcDtls", "cnDtls" })
public class ReconciliationDetails01 {

	@XmlElement(name = "InvcDtls")
	protected InvoiceAndPODetails01 invcDtls;

	@XmlElement(name = "CnDtls")
	protected CreditNoteDetails01 cnDtls;

	/**
	 * Gets the value of the invcDtls property.
	 * @return possible object is {@link InvoiceAndPODetails01 }
	 */
	public InvoiceAndPODetails01 getInvcDtls() {
		return invcDtls;
	}

	/**
	 * Sets the value of the invcDtls property.
	 * @param value allowed object is {@link InvoiceAndPODetails01 }
	 */
	public void setInvcDtls(InvoiceAndPODetails01 value) {
		this.invcDtls = value;
	}

	/**
	 * Gets the value of the cnDtls property.
	 * @return possible object is {@link CreditNoteDetails01 }
	 */
	public CreditNoteDetails01 getCnDtls() {
		return cnDtls;
	}

	/**
	 * Sets the value of the cnDtls property.
	 * @param value allowed object is {@link CreditNoteDetails01 }
	 */
	public void setCnDtls(CreditNoteDetails01 value) {
		this.cnDtls = value;
	}

}
