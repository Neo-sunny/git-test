/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   Jun 20, 2012
 * 
 * Purpose:      AutoPaymentRuleDaoImpl.java
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * Jun 20, 2012       		Sandhya R 						                Initial Version  
 * 22 OCT 2012				Sadhana A V						                Rel 3.0 - Message monitoring changes
 * 29 Nov 2012				Gangadharan R									EIPP - Payment Response logic added
************************************************************************************************************************************************************/

package com.bnp.eipp.services.pymt.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Component;

import com.bnp.eipp.services.vo.payment.EippPaymentMsgDetailVO;
import com.bnp.eipp.services.vo.payment.EippPaymentMsgVO;
import com.bnp.eipp.services.vo.payment.EippPymtVO;
import com.bnp.eipp.services.vo.payment.PaymentInitiateAccountVO;
import com.bnp.scm.services.common.dao.AbstractCommonDaoImpl;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.DBException;
import com.bnp.scm.services.common.exception.ErrorConstants;
import com.bnp.scm.services.common.util.ScreenConstants;
import com.bnp.scm.services.common.vo.NameValueVO;
import com.bnp.scm.services.txns.common.vo.MessageVO;
import com.ibatis.sqlmap.client.SqlMapExecutor;
import com.ibatis.sqlmap.engine.execution.BatchException;

/**
 * The Class EippPaymentMessageDaoImpl.
 */
@Component
public class EippPaymentMessageDaoImpl extends AbstractCommonDaoImpl<EippPaymentMsgDetailVO> implements IEippPaymentMessageDao{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(EippPaymentMessageDaoImpl.class);
	
	private static final String NAME_SPACE = "EippPaymentMessageNS.";
	
	private static final String GET_BUYSUPP_PAYMENTS_BYGROUP = "getBuySuppPaymentsByGroup";
	
	private static final String GET_BUYMKTPLC_PAYMENTS_BYGROUP = "getBuyMktPlcPaymentsByGroup";
	
	private static final String GET_PAYMENTS_FOR_BUYSUP = "getPaymentsForBuySup";
	
	private static final String GET_PAYMENTS_FOR_BUYMKTPLC = "getPaymentsForBuyMktPlc";
	
	private static final String GET_SPLIT_DETAILS_LIST = "getSplitDetailsList";
	
	private static final String GET_DEBIT_ACCOUNT_DETAILS = "getDebitAccountDetails";
	
	private static final String GET_CREDIT_ACCOUNT_DETAILS = "getCreditAccountDetails";
	
	private static final String INSERT_MESG_INFO = "insertMessageInfo";
	
	private static final String INSERT_MESG_DET_INFO =  "insertMessageDetailInfo";
	
	private static final String INSERT_MESG_INFO_IN_HISTORY = "insertMsgInfoInHistory";
	
	private static final String UPD_PAYMENT_MESSAGE_FLAG = "updatePaymentMessageFlag";
	
	private static final String UPD_MESSAGE_INFO_STATUS = "updateMessageInfoStatus";
	
	private static final String UPDATE_BATCHID_IN_MASTER = "updateBatchIdInMaster";

	private static final String ALL_REGEN_LIST = "allReGenList";
	
	private static final String INSERT_PYMT_AUDIT = "insertPymtAudit";
	
	private static final String UPDATE_TXN_TIMESTAMP="updateTxnTimestamp";
	
	private static final String RESET_PROCESSING_FLAG="resetProcessingFlag";
	
	private static final String GET_MKTPLCSUPP_PAYMENTS_BYGROUP = "getMktPlcSuppPaymentsByGroup";
	
	private static final String GET_PAYMENTS_FOR_MKTPLCSUPP = "getPaymentsForMktPlcSupp";
	
	private static final String GET_MESSAGE_ID = "getMessageId";
	
	private static final String GET_BATCH_ID = "getBatchId";
	
	private static final String GET_TAG_VALUE_BASED_ON_COUNTRY = "getTagValueBasedonCountry"; 
	
	private static final String ALL_BILL_LIST = "getBilldatas";
	
	private static final String PYMT_PROC_CRE_BILLING_DETS = "pymtProcCreBillingDets";
	
	private static final String ALL_BUYER_DETS = "pymtProcInfoPopulationForBuyr";
	
	private static final String ALL_SUPPLIER_DETS = "pymtProcInfoForSuplr";
	
	private static final String ALL_MKTPLC_DETS = "pymtProcInfoForMktPlc";
	
	private static final String UPD_BILLING_MESSAGE_FLAG = "updateBillingMessageFlag";	
	
	private static final String GET_BILLING_DETAILS = "getBillingDetails";
	
	private static final String GET_PAYMENT_DETAILS = "getAllPaymentDetForUpdate";
	
	private static final String CHECK_SPLIT_PYMT_EXIST = "checkSplitPmtExist";
	
	private static final String UPDATE_SPLIT_PYMT_STATUS = "updatePaymentStatusInSplit";
	
	private static final String CHECK_ALL_SPLIT_PYMT_SUCCESSFUL = "checkAllSplitPymtSuccess";
	
	private static final String UPDATE_PAYMENT_STATUS_IN_MASTER = "updatePaymentStatusInMaster";
	
	private static final String GET_BILLDET_FOR_UPDATE = "getBillingDetailsForUpdate";
	
	private static final String UPDATE_BILL_STATUS_IN_MASTER = "updateBillingStatusInMaster";
	
	private static final String CHECK_ANY_SPLIT_PMT_FAILED = "checkAnySplitFailed";
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.common.dao.AbstractDAOImpl#getNameSpace()
	 */
	@Override
	public String getNameSpace() {
		return NAME_SPACE;
	}
	
	@Override
	public List<EippPaymentMsgDetailVO> getBuySuppPaymentsByGroup(EippPaymentMsgDetailVO inputVO) throws BNPApplicationException {
		//CSCDEV-2683 :976332:13112014 :START
		//LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup Input: "+inputVO);
		LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup Input:");
		//CSCDEV-2683 :976332:13112014 :END
		List<EippPaymentMsgDetailVO> resultList=null;
		try{
			resultList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_BUYSUPP_PAYMENTS_BYGROUP), inputVO);
		}catch(DataAccessException e){
			LOGGER.error("Exception while fetching the records for Direct Debit Mandate records",e);
			throw new BNPApplicationException(ErrorConstants.ERROR_IN_SEARCH);
		}
		//CSCDEV-2683 :976332:13112014 :START
		//LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup output: "+resultList);
		LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup output: ");
		//CSCDEV-2683 :976332:13112014 :END
		return resultList;
	}
	
	@Override
	public List<EippPaymentMsgDetailVO> getBuyMktPlcPaymentsByGroup(EippPaymentMsgDetailVO inputVO) throws BNPApplicationException {
		//FO 7.0 Fortify Issue Fix
		//LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup Input: "+inputVO);
		LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup Input: ");
		List<EippPaymentMsgDetailVO> resultList=null;
		try{
			resultList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_BUYMKTPLC_PAYMENTS_BYGROUP), inputVO);
		}catch(DataAccessException e){
			LOGGER.error("Exception while fetching the records for Direct Debit Mandate records",e);
			throw new BNPApplicationException(ErrorConstants.ERROR_IN_SEARCH);
		}
		//976332 CSCDEV-2683 14-NOV-2014:START
		//LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup output: "+resultList);
		LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup output: ");
		//976332 CSCDEV-2683 14-NOV-2014:END
		return resultList;
	}
	
	@Override
	public List<EippPaymentMsgDetailVO> getPymtsForBuySup(EippPaymentMsgDetailVO buySup) throws BNPApplicationException {
		//LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup Input: "+buySup);
		LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup Input: ");
		List<EippPaymentMsgDetailVO> resultList=null;
		try{
			resultList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_PAYMENTS_FOR_BUYSUP), buySup);
		}catch(DataAccessException e){
			LOGGER.error("Exception while fetching the records for Direct Debit Mandate records",e);
			throw new BNPApplicationException(ErrorConstants.ERROR_IN_SEARCH);
		}
		//CSCDEV-2683 :976332:13112014 :START
		//LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup output: "+resultList);
		LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup output: ");
		//CSCDEV-2683 :976332:13112014 :END
		return resultList;
	}
	
	@Override
	public List<EippPaymentMsgDetailVO> getPymtsForBuyMktPlc(EippPaymentMsgDetailVO buyMktPlc) throws BNPApplicationException {
		//CSCDEV-2683 :976332:13112014 :START
		//LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup Input: "+buyMktPlc);
		//CSCDEV-2683 :976332:13112014 :END
		List<EippPaymentMsgDetailVO> resultList=null;
		try{
			resultList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_PAYMENTS_FOR_BUYMKTPLC), buyMktPlc);
		}catch(DataAccessException e){
			LOGGER.error("Exception while fetching the records for Direct Debit Mandate records",e);
			throw new BNPApplicationException(ErrorConstants.ERROR_IN_SEARCH);
		}
		//FO 7.0 Fortify Issue Fix
		//LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup output: "+resultList);
		return resultList;
	}
	
	@Override
	public String getMessageId() throws BNPApplicationException {
		try{
			return  (String) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_MESSAGE_ID));
		} catch (DataAccessException e) {
			logger.error("Error while retrieving BatchId for payment request message formation " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public String getBatchId() throws BNPApplicationException {
		try{
			return  (String) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_BATCH_ID));
		} catch (DataAccessException e) {
			logger.error("Error while retrieving MessageId for discount request message formation " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public List<EippPaymentMsgDetailVO> getSplitDetailsList(EippPaymentMsgDetailVO allPayBuySupp) throws BNPApplicationException {
		//CSCDEV-2683 :976332:13112014 :START
		//LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup Input: "+allPayBuySupp);
		LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup Input: ");
		//CSCDEV-2683 :976332:13112014 :END
		List<EippPaymentMsgDetailVO> resultList=null;
		try{
			resultList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_SPLIT_DETAILS_LIST), allPayBuySupp);
		}catch(DataAccessException e){
			LOGGER.error("Exception while fetching the records for Direct Debit Mandate records",e);
			throw new BNPApplicationException(ErrorConstants.ERROR_IN_SEARCH);
		}
		//CSCDEV-2683 :976332:13112014 :START
		//LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup output :"+resultList);
		LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup output :");
		//CSCDEV-2683 :976332:13112014 :END
		return resultList;
	}

	@Override
	public PaymentInitiateAccountVO getDebitAccountDetails(EippPaymentMsgDetailVO getBuyDet) throws BNPApplicationException {
		//CSCDEV-2683 :976332:13112014 :START
		//LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup Input: "+getBuyDet);
		//CSCDEV-2683 :976332:13112014 :END
		PaymentInitiateAccountVO result=null;
		try{
			result = (PaymentInitiateAccountVO) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_DEBIT_ACCOUNT_DETAILS), getBuyDet);
		}catch(DataAccessException e){
			LOGGER.error("Exception while fetching the records for Direct Debit Mandate records",e);
			throw new BNPApplicationException(ErrorConstants.ERROR_IN_SEARCH);
		}
		//CSCDEV-2683 :976332:13112014 :START
		//LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup output: "+result);
		LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup output: ");
		//CSCDEV-2683 :976332:13112014 :END
		return result;
	}

	@Override
	public PaymentInitiateAccountVO getCreditAccountDetails(EippPaymentMsgDetailVO allPayBuySupp) throws BNPApplicationException {
		//CSCDEV-2683 :976332:13112014 :START
		//LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup Input: "+allPayBuySupp);
		LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup Input: ");
		//CSCDEV-2683 :976332:13112014 :END
		PaymentInitiateAccountVO result=null;
		try{
			result = (PaymentInitiateAccountVO) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_CREDIT_ACCOUNT_DETAILS), allPayBuySupp);
		}catch(DataAccessException e){
			LOGGER.error("Exception while fetching the records for Direct Debit Mandate records",e);
			throw new BNPApplicationException(ErrorConstants.ERROR_IN_SEARCH);
		}
		//CSCDEV-2683 :976332:13112014 :START
		//LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup output: "+result);
		LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup output: ");
		//CSCDEV-2683 :976332:13112014 :END
		return result;
	}
	
	@Override
	public MessageVO insertMessageInfo(MessageVO messageVO)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_MESG_INFO), messageVO);
			if(messageVO.getMessageDetail() != null && messageVO.getMessageDetail().getMsg() != null && messageVO.getMessageDetail().getMsg().length > 0){
				insertMessageDetails(messageVO);
			}
			//Insert into History table
			insertMessageInfoInHistory(messageVO);
		 } catch (DataAccessException e) {
			 logger.error("Error while insertMessageInfo for discount request message formation " + e.getMessage());
			 throw new DBException(ErrorConstants.DATABASE_ERROR);
		 }
		 return messageVO;
	}
	
	@Override
	public void insertMessageDetails(MessageVO messageVO) throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_MESG_DET_INFO), messageVO);
		} catch (DataAccessException e) {
			logger.error("Error in insertMessageDetails  "
					+ e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public void insertMessageInfoInHistory(MessageVO messageVO)
			throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_MESG_INFO_IN_HISTORY), messageVO);
		 } catch (DataAccessException e) {
			 logger.error("Error in insertMessageInfoInHistory " + e.getMessage());
			 throw new DBException(ErrorConstants.DATABASE_ERROR);
		 }
	}
	
	@Override
	public void updatePaymentMessageFlag(EippPaymentMsgVO pymtMsgVO) throws BNPApplicationException{
		try{
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPD_PAYMENT_MESSAGE_FLAG), pymtMsgVO);
		} catch (DataAccessException e) {
			logger.error("Error while updating settlement message sent flag " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	@Override
	public void updateMessageInfoStatus(String msgId,String status,String errorDesc) throws BNPApplicationException{
		try{
			Map<String, String> params = new HashMap<String, String>();
			params.put("msgId", msgId);
			params.put("status", status);
			params.put("errorDesc", errorDesc);
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPD_MESSAGE_INFO_STATUS), params);
		} catch (DataAccessException e) {
			logger.error("Error while updating status in message info table " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public void updateBatchIdInMaster(EippPaymentMsgDetailVO creDeb)	throws BNPApplicationException {
		try{
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_BATCHID_IN_MASTER), creDeb);	
		} catch (DataAccessException e) {
			logger.error("Error while updating batchid in master table " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}

	@Override
	public List<EippPaymentMsgDetailVO> getMktPlcSuppPaymentsByGroup(EippPaymentMsgDetailVO inputVO) throws BNPApplicationException {
		//CSCDEV-2683 :976332:13112014 :START
		//LOGGER.info("Inside PaymentInitiateDaoImpl.getMktPlcSuppPaymentsByGroup Input: "+inputVO);
		//CSCDEV-2683 :976332:13112014 :END
		List<EippPaymentMsgDetailVO> resultList=null;
		try{
			resultList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_MKTPLCSUPP_PAYMENTS_BYGROUP), inputVO);
		}catch(DataAccessException e){
			LOGGER.error("Exception while fetching the records for Direct Debit Mandate records",e);
			throw new BNPApplicationException(ErrorConstants.ERROR_IN_SEARCH);
		}
		//CSCDEV-2683 :976332:13112014 :START
		//LOGGER.info("Inside PaymentInitiateDaoImpl.getMktPlcSuppPaymentsByGroup output: "+resultList);
		LOGGER.info("Inside PaymentInitiateDaoImpl.getMktPlcSuppPaymentsByGroup output: ");
		//CSCDEV-2683 :976332:13112014 :END
		return resultList;
	}

	@Override
	public List<EippPaymentMsgDetailVO> getPymtsForMktPlcSupp(EippPaymentMsgDetailVO mktPlcSupp) throws BNPApplicationException {
		//CSCDEV-2683 :976332:13112014 :START
		//LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup Input: "+mktPlcSupp);
		//CSCDEV-2683 :976332:13112014 :END
		List<EippPaymentMsgDetailVO> resultList=null;
		try{
			resultList = getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_PAYMENTS_FOR_MKTPLCSUPP), mktPlcSupp);
		}catch(DataAccessException e){
			LOGGER.error("Exception while fetching the records for Direct Debit Mandate records",e);
			throw new BNPApplicationException(ErrorConstants.ERROR_IN_SEARCH);
		}
		//FO 7.0 Fortify Issue Fix
        //LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup output: "+resultList);
		LOGGER.info("Inside PaymentInitiateDaoImpl.getPaymentsByGroup output: ");
		return resultList;
	}

	@Override
	public List<EippPaymentMsgDetailVO> allReGenList(String msgRef) throws BNPApplicationException {
		List<EippPaymentMsgDetailVO> allReGenList = null;
		try{
			allReGenList =  getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(ALL_REGEN_LIST), msgRef);
		} catch (DataAccessException e) {
			LOGGER.error("Error in getResendSuppressDetailList " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		//976332 CSCDEV-2683 20-NOV-2014:START
		//LOGGER.debug("pymtIdList :" + allReGenList);
		//976332 CSCDEV-2683 20-NOV-2014:END
		return allReGenList;
	}

	@Override
	public void insertPymtAudit(EippPaymentMsgDetailVO singPymtMsgVo) throws BNPApplicationException {
		try {
			getSqlMapClientTemplate().insert(getQueryNameWithNameSpace(INSERT_PYMT_AUDIT), singPymtMsgVo);
		 } catch (DataAccessException e) {
			 logger.error("Error while insertMessageInfo for discount request message formation " + e.getMessage());
			 throw new DBException(ErrorConstants.DATABASE_ERROR);
		 }
	}

	@Override
	public int updateTxnTimestamp(EippPaymentMsgVO eippPymtMsgVO) throws BNPApplicationException {
		final List<String> lst = new ArrayList<String>();
		final List<EippPaymentMsgDetailVO> eippPymtMsgDetVoList = eippPymtMsgVO.getPaymentMsgDetVO();
		if( eippPymtMsgDetVoList!=null && eippPymtMsgDetVoList.size()>0){
			getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
			public List doInSqlMapClient(SqlMapExecutor executor)throws SQLException {
							List list = null;
							try {
								executor.startBatch();
								for (EippPaymentMsgDetailVO eippMsgDetVO : eippPymtMsgDetVoList ) {
									executor.update(getQueryNameWithNameSpace(UPDATE_TXN_TIMESTAMP), eippMsgDetVO);										
								}
								list = executor.executeBatchDetailed();
								int count = executor.executeBatch();
								lst.add("" + count );
							} catch (BatchException e) {
								LOGGER.error("updateTxnTimestamp in a batch failed");
								throw new SQLException("Error in updateTxnTimestamp");
							}
							return list;
						}
					});
		}
		// get the count
		if( lst !=null && lst.size() > 0 ){
			if( (String)lst.get(0) !=null && !((String)lst.get(0)).equals(ScreenConstants.EMPTY_STRING)){
				return Integer.parseInt((String)lst.get(0));
			}
		}
		return 0;
	}

	@Override
	public void resetProcessingFlag(EippPaymentMsgVO eippPymtMsgVO) throws BNPApplicationException {
		final List<EippPaymentMsgDetailVO> eippPymtMsgDetVoList = eippPymtMsgVO.getPaymentMsgDetVO();
		if( eippPymtMsgDetVoList!=null && eippPymtMsgDetVoList.size()>0){
			getSqlMapClientTemplate().execute(new SqlMapClientCallback<List>() {
			public List doInSqlMapClient(SqlMapExecutor executor)throws SQLException {
							List list = null;
							try {
								executor.startBatch();
								for (EippPaymentMsgDetailVO eippMsgDetVO : eippPymtMsgDetVoList ) {
									executor.update(getQueryNameWithNameSpace(RESET_PROCESSING_FLAG), eippMsgDetVO);										
								}
								list = executor.executeBatchDetailed();
							} catch (BatchException e) {
								LOGGER.error("updateTxnTimestamp in a batch failed");
								throw new SQLException("Error in updateTxnTimestamp");
							}
							return list;
						}
					});
		}
	}
	
	@Override
	public List<NameValueVO> getTagValueBasedonCountry(String country) throws BNPApplicationException {
		List<NameValueVO> ctryList = null;
		try{
			ctryList =  getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(GET_TAG_VALUE_BASED_ON_COUNTRY),country) ;
		} catch (DataAccessException e) {
			LOGGER.error("Error in getResendSuppressDetailList " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		//976332 CSCDEV-2683 20-NOV-2014:START
		//LOGGER.debug("ctryList :" + ctryList);
		//976332 CSCDEV-2683 20-NOV-2014:END
		return ctryList;
		
	}

	@Override
	public List<EippPaymentMsgDetailVO> getBilldatas(String inputBranch) throws BNPApplicationException {
		List<EippPaymentMsgDetailVO> allBillList = null;
		try{
			allBillList =  getSqlMapClientTemplate().queryForList(getQueryNameWithNameSpace(ALL_BILL_LIST),inputBranch);
		} catch (DataAccessException e) {
			LOGGER.error("Error in getResendSuppressDetailList " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}catch (Exception e) {
			LOGGER.error("Error in getResendSuppressDetailList " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		//976332 CSCDEV-2683 19-NOV-2014:START
		//LOGGER.debug("allBillList :" + allBillList);
		//976332 CSCDEV-2683 19-NOV-2014:END
		return allBillList;
	}
	
	@Override
	public PaymentInitiateAccountVO pymtProcCreBillingDets(EippPaymentMsgDetailVO payAccVo) throws BNPApplicationException {
		PaymentInitiateAccountVO payInitAccVO = null;
		try{
			payInitAccVO = (PaymentInitiateAccountVO) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(PYMT_PROC_CRE_BILLING_DETS),payAccVo);
		} catch (DataAccessException e) {
			LOGGER.error("Error in pymtProcCreBillingDets " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		//976332 CSCDEV-2683 20-NOV-2014:START
		//LOGGER.debug("payInitAccVO :" + payInitAccVO);
		//976332 CSCDEV-2683 20-NOV-2014:END
		return payInitAccVO;
	}

	@Override
	public PaymentInitiateAccountVO pymtProcInfoPopulationForBuyr(EippPaymentMsgDetailVO dataVO) throws BNPApplicationException {
		PaymentInitiateAccountVO payInitAccVO = null;
		try{
			payInitAccVO = (PaymentInitiateAccountVO) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(ALL_BUYER_DETS),dataVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error in getResendSuppressDetailList " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("payInitAccVO :" + payInitAccVO);
		return payInitAccVO;
	}

	@Override
	public PaymentInitiateAccountVO pymtProcInfoForSuplr(EippPaymentMsgDetailVO dataVO) throws BNPApplicationException {
		PaymentInitiateAccountVO payInitAccVO = null;
		try{
			payInitAccVO = (PaymentInitiateAccountVO) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(ALL_SUPPLIER_DETS),dataVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error in getResendSuppressDetailList " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("payInitAccVO :" + payInitAccVO);
		return payInitAccVO;
	}

	@Override
	public PaymentInitiateAccountVO pymtProcInfoForMktPlc(EippPaymentMsgDetailVO dataVO) throws BNPApplicationException {
		PaymentInitiateAccountVO payInitAccVO = null;
		try{
			payInitAccVO = (PaymentInitiateAccountVO) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(ALL_MKTPLC_DETS),dataVO);
		} catch (DataAccessException e) {
			LOGGER.error("Error in getResendSuppressDetailList " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("payInitAccVO :" + payInitAccVO);
		return payInitAccVO;
	}

	

	@Override
	public void updateBillingMessageFlag(EippPaymentMsgVO eippPayMsgVO) throws BNPApplicationException {
		try{
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPD_BILLING_MESSAGE_FLAG), eippPayMsgVO);
		} catch (DataAccessException e) {
			logger.error("Error while updating settlement message sent flag " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		
	}
	
	@Override
	public EippPaymentMsgDetailVO getBillingDetails(String msgRef) throws BNPApplicationException {
		EippPaymentMsgDetailVO billingPayDetails = null;
		try{
			billingPayDetails =  (EippPaymentMsgDetailVO) getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(GET_BILLING_DETAILS),msgRef);
		} catch (DataAccessException e) {
			LOGGER.error("Error in getBillingDetails " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}catch (Exception e) {
			LOGGER.error("Error in getBillingDetails " + e.getMessage());
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		//FO 7.0 Fortify Issue Fix
		//LOGGER.debug("billingPaymentDetails :" + billingPayDetails);
		return billingPayDetails;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.dao.IEippPaymentMessageDao#getPaymentDetails(java.lang.String)
	 */
	@Override
	public EippPaymentMsgDetailVO getPaymentDetails(String pymtRefNo)
			throws BNPApplicationException {
		EippPaymentMsgDetailVO paymentDetails = null;
		try{
			paymentDetails =  (EippPaymentMsgDetailVO) getSqlMapClientTemplate().queryForObject(
					getQueryNameWithNameSpace(GET_PAYMENT_DETAILS),pymtRefNo);
		} catch (DataAccessException e) {
			LOGGER.error("DataAccessException in EippPaymentMessageDaoImpl getPaymentDetails: ", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}catch (Exception e) {
			LOGGER.error("Exception in EippPaymentMessageDaoImpl getPaymentDetails: ", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
		return paymentDetails;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.dao.IEippPaymentMessageDao#checkSplitPymtExist(com.bnp.eipp.services.vo.payment.EippPymtVO)
	 */
	@Override
	public boolean checkSplitPymtExist(EippPymtVO pymtVO)
			throws BNPApplicationException {
		int splitPymtCnt = 0;
		try{
			Object objData  = getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(
					CHECK_SPLIT_PYMT_EXIST), pymtVO);
			if(objData != null && objData instanceof Integer){
				splitPymtCnt = (Integer)objData;
			}
			
			if(splitPymtCnt > 0){
				return true;
			}
		}catch(Exception e){
			LOGGER.error("Exception in EippPaymentMessageDaoImpl checkSplitPymtExist :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return false;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.dao.IEippPaymentMessageDao#updatePaymentStatusInSplit(com.bnp.eipp.services.vo.payment.EippPaymentMsgDetailVO)
	 */
	@Override
	public void updatePaymentStatusInSplit(EippPaymentMsgDetailVO eippPayMsgDtlVO)
			throws BNPApplicationException {
		try{
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_SPLIT_PYMT_STATUS), eippPayMsgDtlVO);
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EippPaymentMessageDaoImpl updatePaymentStatusInSplit :", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.dao.IEippPaymentMessageDao#checkAllSplitPymtSuccess(com.bnp.eipp.services.vo.payment.EippPaymentMsgDetailVO)
	 */
	@Override
	public boolean checkAllSplitPymtSuccess(EippPaymentMsgDetailVO eippPayMsgDtlVO)
			throws BNPApplicationException {
		int splitPymtSuccCnt = 0;
		try{
			Object objData  = getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(
					CHECK_ALL_SPLIT_PYMT_SUCCESSFUL), eippPayMsgDtlVO);
			if(objData != null && objData instanceof Integer){
				splitPymtSuccCnt = (Integer)objData;
			}
			
			if(splitPymtSuccCnt > 0){
				return true;
			}
		}catch(Exception e){
			LOGGER.error("Exception in EippPaymentMessageDaoImpl checkAllSplitPymtSuccess :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return false;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.dao.IEippPaymentMessageDao#updatePaymentStatusInMaster(com.bnp.eipp.services.vo.payment.EippPaymentMsgDetailVO)
	 */
	@Override
	public void updatePaymentStatusInMaster(EippPaymentMsgDetailVO allDet) throws BNPApplicationException {
		try{
			String error = null;
			Map <String,Object> map = new HashMap<String,Object>();
			map.put("orgId", allDet.getOrgId());
			map.put("paymentId" , new java.lang.Long(allDet.getPaymentId()));
			map.put("paymentAmt" , allDet.getPaymentAmt()); 
			map.put("paymentCcy" , allDet.getPaymentCcy());
			map.put("paymentStatus" , allDet.getRecordStatus());
			map.put("userId" , allDet.getUserId());
			map.put("action" , allDet.getAction());
			map.put("remarks", allDet.getRemarks());
			getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(
					UPDATE_PAYMENT_STATUS_IN_MASTER), map);
			if(map.containsKey("currentRecordStatus")){
				error = (String) map.get("currentRecordStatus");
				//FO 7.0 Fortify Issue Fix
				//logger.debug("Error::"+error);
				if(error != null && !error.isEmpty()){
					throw new DBException(error);
				}
			}
		}catch (DataAccessException e) {
			LOGGER.error("Exception in EippPaymentMessageDaoImpl updatePaymentStatusInMaster: ", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.dao.IEippPaymentMessageDao#getBillingDetForUpdate(java.lang.String)
	 */
	@Override
	public EippPaymentMsgDetailVO getBillingDetForUpdate(String pymtRefNo)
			throws BNPApplicationException {
		EippPaymentMsgDetailVO pymtMsgDtlVO = null;
		try {
			pymtMsgDtlVO = (EippPaymentMsgDetailVO) getSqlMapClientTemplate().queryForObject(
					getQueryNameWithNameSpace(GET_BILLDET_FOR_UPDATE),pymtRefNo);
		 } catch (DataAccessException e) {
			 LOGGER.error("Exception in EippPaymentMessageDaoImpl updatePaymentStatusInMaster: ", e);
			 throw new DBException(ErrorConstants.DATABASE_ERROR);
		 }
		 return pymtMsgDtlVO;
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.dao.IEippPaymentMessageDao#updateBillingStatusInMaster(com.bnp.eipp.services.vo.payment.EippPaymentMsgDetailVO)
	 */
	@Override
	public void updateBillingStatusInMaster(EippPaymentMsgDetailVO eippPayMsgDtlVO) 
		throws BNPApplicationException {
		try{
			getSqlMapClientTemplate().update(getQueryNameWithNameSpace(UPDATE_BILL_STATUS_IN_MASTER), 
					eippPayMsgDtlVO);
		} catch (DataAccessException e) {
			LOGGER.error("Exception in EippPaymentMessageDaoImpl updatePaymentStatusInMaster: ", e);
			throw new DBException(ErrorConstants.DATABASE_ERROR);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.eipp.services.pymt.dao.IEippPaymentMessageDao#checkAnySplitPymtFailed(com.bnp.eipp.services.vo.payment.EippPaymentMsgDetailVO)
	 */
	@Override
	public boolean checkAnySplitPymtFailed(EippPaymentMsgDetailVO eippPayMsgDtlVO)
			throws BNPApplicationException {
		int splitPymtFailedCnt = 0;
		try{
			Object objData  = getSqlMapClientTemplate().queryForObject(getQueryNameWithNameSpace(
					CHECK_ANY_SPLIT_PMT_FAILED), eippPayMsgDtlVO);
			if(objData != null && objData instanceof Integer){
				splitPymtFailedCnt = (Integer)objData;
			}
			
			if(splitPymtFailedCnt > 0){
				return true;
			}
		}catch(Exception e){
			LOGGER.error("Exception in EippPaymentMessageDaoImpl checkAnySplitPymtFailed :", e);
			throw new BNPApplicationException(ErrorConstants.DATABASE_ERROR);
		}
		return false;
	}
}
