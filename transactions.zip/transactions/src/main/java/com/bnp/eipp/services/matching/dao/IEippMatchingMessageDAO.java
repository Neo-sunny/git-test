/****************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14 Oct 2012
 * 
 * Purpose: Eipp Matching Message DAO
 * 
 * Change History: 
 * Date                       	Author                                  Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 14 Oct 2012              	Prabu P                      			Initial Version
 ********************************************************************************************************************************/

package com.bnp.eipp.services.matching.dao;

import java.util.List;
import java.util.Map;

import com.bnp.eipp.services.invoice.vo.EippCreditNoteVO;
import com.bnp.eipp.services.invoice.vo.EippCustFieldsVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.invoice.vo.EippTransactionVO;
import com.bnp.eipp.services.vo.common.EippMessageVO;
import com.bnp.eipp.services.vo.payment.EippPymtVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;

public interface IEippMatchingMessageDAO {

	/**
	 * Get header details
	 * @param orgId
	 * @return Map<String, String>
	 * @throws BNPApplicationException
	 */
	Map<String, String> getHeaderDetails(String orgId) throws BNPApplicationException;

	/**
	 * Insert payment details
	 * @param eippPymtVO
	 * @throws BNPApplicationException
	 */
	void insertPaymentDetails(EippPymtVO eippPymtVO) throws BNPApplicationException;
	
	/**
	 * Approve payment details
	 * @param eippPymtVO
	 * @throws BNPApplicationException
	 */
	void approvePaymentDetails(EippPymtVO eippPymtVO) throws BNPApplicationException;

	/**
	 * Get match record grouping list
	 * @param EippMatchInvoiceMsgVO
	 * @return List<EippInvCntVO>
	 * @throws BNPApplicationException
	 */
	List<EippInvCntVO> getMatchRecGroupList(EippMessageVO invoiceMsgVO) throws BNPApplicationException;

	/**
	 * Get the matching invoice list
	 * @param EippInvCntVO
	 * @return List<EippInvoiceVO>
	 * @throws BNPApplicationException
	 */
	List<EippInvoiceVO> getMatchingInvoiceList(EippInvCntVO eippInvCntVO) throws BNPApplicationException;

	/**
	 * Get Matching linked credit note list
	 * @param invcList
	 * @return List<EippCreditNoteVO>
	 * @throws BNPApplicationException
	 */
	List<EippCreditNoteVO> getMatchingCreditNoteList(List<EippInvoiceVO> invcList) throws BNPApplicationException;

	/**
	 * Get matching unlinked credit note list
	 * @param EippInvCntVO
	 * @return List<EippCreditNoteVO>
	 * @throws BNPApplicationException
	 */
	List<EippCreditNoteVO> getMatchingUnlinkedCreditNoteList(EippInvCntVO eippInvCntVO) throws BNPApplicationException;
	
	/**
	 * Get the list of unmatched payment records
	 * @param orgId
	 * @return List<EippPymtVO>
	 * @throws BNPApplicationException
	 */
	List<EippPymtVO> getUnmatchedPayments(String orgId) throws BNPApplicationException;
	
	/**
	 * Get matched file id for given file id
	 * @param fileId
	 * @return List<String>
	 * @throws BNPApplicationException
	 */
	List<String> getFileIdList(String fileId) throws BNPApplicationException;
	
	/**
	 * Get the message batch reference id
	 * @return String
	 * @throws BNPApplicationException
	 */
	String getMatchingMsgBatchRefId() throws BNPApplicationException;
	
	/**
	 * Update message delivery status
	 * @param eippMessageVO
	 * @throws BNPApplicationException
	 */
	void updateMsgDeliveryStatus(EippMessageVO eippMessageVO) throws BNPApplicationException;
	
	/**
	 * Get custom fields 
	 * @param transactionVO
	 * @return List<EippCustFieldsVO>
	 * @throws BNPApplicationException
	 */
	List<EippCustFieldsVO> getCustomFieldList(EippTransactionVO transactionVO) throws BNPApplicationException;
}
