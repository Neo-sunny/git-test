package com.bnp.eipp.services.txns.util.file;

import java.util.Properties;


public enum FileProcessorEnum {
	
	CANCEL_INV_PROCESSOR("EIPP Invoice Cancellation", 
			"eippCancelInvoiceFileProcessor"),	
	PYMT_PREP_PROCESSOR("EIPPPymtPrep","eippPymtPrepFileProcessor"),
	RESOLVE_DISPUTE_PROCESSOR("EIPPResolveDispute","eippResolveDisputeFileProcessor"),
	RAISE_DISPUTE_PROCESSOR("EIPPRaiseDispute","eippRaiseDisputeFileProcessor"),
	PYMTSTATUS_UPDATE_PROCESSOR("EIPP-PymtStatusUpdate","eippPymtStatusUpdateProcessor"),	
	BILLING_COUNT_PROCESSOR("EIPP-BillingCount","eippBillingChargeCountProcessor"),
	RATE_REFRESH_PROCESSOR("SCM-RefreshRate","rateRefreshDataFileProcessor"),
	DISC_CONFIRM_PROCESSOR("DiscountConfirmation","discountConfirmationMfuProcessor"),
	TP_DISCCONFIRM_PROCESSOR("TPParticipationConfirmation","tpDiscConfirmFileProcessor"),
	UPD_SETTLEMENTS_PROCESSOR("UpdateSettlements","updSettlementFileProcessor");
	
	private String fileType;
	
	private String processorClass;
	
	public String getFileType() {
		return fileType;
	}


	public void setFileType(String fileType) {
		this.fileType = fileType;
	}


	public String getProcessorClass() {
		return processorClass;
	}

	public void setProcessorClass(String processorClass) {
		this.processorClass = processorClass;
	}

	private static Properties classProps = new Properties();
	
	static {
		for (FileProcessorEnum enumType : FileProcessorEnum.values()) {
			classProps.put(enumType.getFileType(), enumType.getProcessorClass());
		}
	}
	
	private FileProcessorEnum(String fileType, String processorClassName) {
		this.fileType = fileType;
		this.processorClass = processorClassName;
	}
	
	public static String getProcessorName(String fileType) {
		String processorClass = classProps.getProperty(fileType);
		
		return processorClass;
	}
	

}
