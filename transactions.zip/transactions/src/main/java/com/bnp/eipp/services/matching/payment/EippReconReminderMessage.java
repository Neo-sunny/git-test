/****************************************************************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   14 Oct 2012
 * 
 * Purpose: Eipp Matching Recon Reminder Message
 * 
 * Change History: 
 * Date                       	Author                                  Reason 
 * ------------------------------------------------------------------------------------------------------------------------------ 
 * 14 Oct 2012              	Prabu P                      			Initial Version
 ********************************************************************************************************************************/

package com.bnp.eipp.services.matching.payment;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import org.dozer.DozerBeanMapper;

import com.bnp.eipp.services.matching.payment.bindingvo.ErrorDescription;
import com.bnp.eipp.services.matching.payment.bindingvo.File;
import com.bnp.eipp.services.matching.payment.bindingvo.Header;
import com.bnp.eipp.services.matching.payment.bindingvo.Message;
import com.bnp.eipp.services.matching.payment.bindingvo.ObjectFactory;
import com.bnp.eipp.services.matching.payment.bindingvo.PaymentResponse;
import com.bnp.eipp.services.matching.payment.bindingvo.PymtRespDetails;
import com.bnp.eipp.services.vo.common.EippMessageVO;
import com.bnp.eipp.services.vo.payment.EippPymtVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.AbstractVO;
import com.bnp.scm.services.txns.common.message.AbstractMsg;
import com.bnp.scm.services.txns.common.vo.MessageVO;
import com.bnp.scm.services.txns.util.PropertiesReader;
import com.bnp.scm.services.txns.util.xml.XmlValidationEventHandler;

public class EippReconReminderMessage extends AbstractMsg<Message> {

	private ObjectFactory factory;

	/**
	 * Constructor to create basic objects for message
	 */
	@Override
	public void createInstance() throws BNPApplicationException {
		this.factory = new ObjectFactory();
		this.message = new Message();
		this.body = new File();
		this.header = new Header();
		this.errorDescription = new ErrorDescription();
	}

	/*
	 * (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.AbstractMessage#createHeader(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void createHeader(AbstractVO abstractVO) throws BNPApplicationException {
		try {
			if (abstractVO instanceof EippMessageVO) {
				EippMessageVO eippMsgVO = (EippMessageVO)abstractVO;
				MessageVO messageVO = new MessageVO();
				messageVO.setMsgId(eippMsgVO.getMsgId());
				messageVO.setOrgId(eippMsgVO.getOrgId());
				eippMsgVO.setMessageVO(messageVO);
				
				Map<String, String> headerMap = eippMsgVO.getHeaderMap();
				GregorianCalendar greCal = new GregorianCalendar();
				header.setCountry(headerMap.get("COUNTRY_CODE"));
				header.setBankCode(headerMap.get("BANK_CODE"));
				header.setBranchCode(headerMap.get("BRANCH_CODE"));
				header.setSCMOrgId(eippMsgVO.getOrgId());
				header.setCntType(PropertiesReader.getProperty("message.content.type.xml"));
				header.setMsgFileSts(PropertiesReader.getProperty("message.type.na"));
				header.setSrcRefId(eippMsgVO.getMsgId());
				header.setCustFileName(PropertiesReader.getProperty("message.type.na"));
				header.setOrgin(PropertiesReader.getProperty("txns.label.fo"));
				
				header.setDestination(PropertiesReader.getProperty("txns.label.erp"));
				header.setMsgFileType(PropertiesReader.getProperty("message.type.matching.eipp.recon.reminder.erp"));
				
				messageVO.setMsgType(header.getMsgFileType());
				messageVO.setTransportType(header.getDestination());
				messageVO.setSupportBranchId(headerMap.get("SUPPORT_BRANCH_ID"));
				header.setCustFileRecvTime(greCal);
				header.setSendTime(greCal);
				this.setHeader(header);
			}
		}
		catch (Exception exception) {
			throw new BNPApplicationException(exception.getMessage(), exception);
		}
	}

	/*
	 * (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.AbstractMessage#createBody(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void createBody(AbstractVO abstractVO) throws BNPApplicationException {
		if (abstractVO instanceof EippMessageVO) {
			EippMessageVO eippMsgVO = (EippMessageVO)abstractVO;
			List<String> mapperList = new ArrayList<String>(1);
			mapperList.add("mapper/EippMatchingPymtRespMapper.xml");
	
			// Mapping JAXB object to custom VO object
			DozerBeanMapper mapper = new DozerBeanMapper();
			mapper.setMappingFiles(mapperList);
	
			PaymentResponse pymtResp = factory.createPaymentResponse();			
			List<EippPymtVO> pmtList = (List<EippPymtVO>)eippMsgVO.getDataList();
			
			for (EippPymtVO eippPymtVO : pmtList) {				
				PymtRespDetails pymtRespDetail = mapper.map(eippPymtVO, PymtRespDetails.class);
				pymtRespDetail.getReference().setRefType("PAYMENT");
				pymtResp.getPymtStatusResp().add(pymtRespDetail);
			}
			
			((File)this.getBody()).setDocument(pymtResp);
		}
	}

	/*
	 * (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.AbstractMessage#createBody(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void createErrorDescription(AbstractVO abstractVO) throws BNPApplicationException {

	}

	/*
	 * (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.AbstractMessage#createMessage(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void createMessage() throws BNPApplicationException {
		if (factory == null) {
			this.factory = new ObjectFactory();
		}
		Message message = (Message)this.getMessage();
		message.setHeader((Header)this.getHeader());
		message.setFile((File)this.getBody());
		this.setMessage(message);
		this.setJaxbElementObj(factory.createMsg(message));
	}

	/*
	 * (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.IMessage#setBindingProperties()
	 */
	@Override
	public void setBindingProperties() throws BNPApplicationException {
		this.properties.setBindingClass(Message.class);
		this.properties.setValidateXsd(true);
		this.properties.setXsdPath(PropertiesReader.getProperty("message.eipp.payment.status.response.xsd.path"));
		this.properties.setEventHandler(new XmlValidationEventHandler());
		this.setProperties(properties);
	}
}
