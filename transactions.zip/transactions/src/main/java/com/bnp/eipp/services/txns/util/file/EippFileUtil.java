/* ************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  Feb 07, 2012
 * 
 * Purpose:     This class is used to do conversions with file content
 * 
 * Change History: 
 * Date                                                  Author                                                    Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * Feb 07, 2012                      Oracle Financial Services Software Ltd         Initial Version
 * 12-July 2012                      Oracle Financial Services Software Ltd         EIPP Phase II - Cancel Invoice MFU
 ****************************************************************************/
package com.bnp.eipp.services.txns.util.file;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.dozer.DozerBeanMapper;

import com.bnp.eipp.services.invoice.bindingvo.AdditionalInformation1;
import com.bnp.eipp.services.invoice.bindingvo.AdditionalInformation6;
import com.bnp.eipp.services.invoice.bindingvo.AddressType2Code;
import com.bnp.eipp.services.invoice.bindingvo.Document;
import com.bnp.eipp.services.invoice.bindingvo.ErrorMessage;
import com.bnp.eipp.services.invoice.bindingvo.ErrorMessages;
import com.bnp.eipp.services.invoice.bindingvo.FinancialCreditNoteV01;
import com.bnp.eipp.services.invoice.bindingvo.FinancialInvoiceV01;
import com.bnp.eipp.services.invoice.bindingvo.LineItem10;
import com.bnp.eipp.services.invoice.bindingvo.PartyIdentification46;
import com.bnp.eipp.services.invoice.bindingvo.PostalAddress6;
import com.bnp.eipp.services.invoice.bindingvo.TradeDelivery1;
import com.bnp.eipp.services.invoice.vo.AddressVO;
import com.bnp.eipp.services.invoice.vo.EippCreditNoteVO;
import com.bnp.eipp.services.invoice.vo.EippCustFieldsVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntLineItemVO;
import com.bnp.eipp.services.invoice.vo.EippInvCntVO;
import com.bnp.eipp.services.invoice.vo.EippInvoiceVO;
import com.bnp.eipp.services.invoice.vo.EippTransactionVO;
import com.bnp.scm.services.common.BNPConstants;
import com.bnp.scm.services.invoice.vo.InvalidFileDataVO;

public class EippFileUtil {
	private static Logger LOGGER = LoggerFactory.getLogger(EippFileUtil.class);
	
	private static ErrorMessages getErrorMessages(List<InvalidFileDataVO> invalidDataList,DozerBeanMapper mapper){
		
		ErrorMessages ermsgs = new ErrorMessages();
		
			for (InvalidFileDataVO invalidFileDataVO : invalidDataList) {
				ErrorMessage errorMessage = mapper.map(invalidFileDataVO, ErrorMessage.class);
				ermsgs.getErrMsg().add(errorMessage);
			}
		
		return ermsgs;
		
	}
	
	private static List<FinancialInvoiceV01> createInvoices(List<EippInvoiceVO> invoiceList,DozerBeanMapper mapper){
		
		List<FinancialInvoiceV01> invoices = new ArrayList<FinancialInvoiceV01>();
		
			for(EippInvoiceVO eippInvoiceVO : invoiceList){
				FinancialInvoiceV01 invoice = mapper.map(eippInvoiceVO, FinancialInvoiceV01.class);	
				populateInvCustomFields(eippInvoiceVO, mapper, invoice);
				populatePaymentTerms(eippInvoiceVO.getPymtTerms(),invoice);
				populateInvcAddress(eippInvoiceVO, mapper,invoice);
				for (EippInvCntLineItemVO lineItmVO : eippInvoiceVO.getLineItemList()) {
					LineItem10 lineItem10 = mapper.map(lineItmVO, LineItem10.class);
					populateCustomItmFields(lineItmVO, mapper,lineItem10);
					invoice.getLineItm().add(lineItem10);
				}
				if (!isEmptyList(eippInvoiceVO.getInvalidFileDataList())){
					invoice.setErrMsgs(getErrorMessages(eippInvoiceVO.getInvalidFileDataList(),mapper));
					invoice.setStatus(BNPConstants.VALIDATION_FAILED);
				}
				else {
					invoice.setStatus(BNPConstants.VALIDATION_SUCCESS);
				}
				invoices.add(invoice);
			}
		
		return invoices;
		
	}
	private static void populateInvcAddress(EippInvoiceVO eippInvoiceVO,DozerBeanMapper mapper,
			FinancialInvoiceV01 invoice) {
		TradeDelivery1 tradeDelivery = null;
		if (invoice.getTradDlvry() != null) {
			tradeDelivery = invoice.getTradDlvry();
		} else {
			tradeDelivery = new TradeDelivery1();
		}
		if (eippInvoiceVO.getRemitToAddr() != null) {
			tradeDelivery.setRemitTo(getAddress(eippInvoiceVO.getRemitToAddr(), mapper));
		}
		if (eippInvoiceVO.getBillToAddr() != null) {
			tradeDelivery.setBillTo(getAddress(eippInvoiceVO.getBillToAddr(), mapper));
		}
		if (eippInvoiceVO.getShipToAddr() != null) {
			tradeDelivery.setShipTo(getAddress(eippInvoiceVO.getShipToAddr(), mapper));
		}
		invoice.setTradDlvry(tradeDelivery);
		
	}
	
	private static void populateCrntAddress(EippCreditNoteVO eippCreditNoteVO,DozerBeanMapper mapper,
			FinancialCreditNoteV01 creditNote) {
		TradeDelivery1 tradeDelivery = null;
		if (creditNote.getTradDlvry() != null) {
			tradeDelivery = creditNote.getTradDlvry();
		} else {
			tradeDelivery = new TradeDelivery1();
		}
		if (eippCreditNoteVO.getShipToAddr() != null) {
			tradeDelivery.setShipTo(getAddress(eippCreditNoteVO.getShipToAddr(), mapper));
		}
		if (eippCreditNoteVO.getBillToAddr() != null) {
			tradeDelivery.setBillTo(getAddress(eippCreditNoteVO.getBillToAddr(), mapper));
		}
		creditNote.setTradDlvry(tradeDelivery);
	}
	private static void populateAddressLine(AddressVO addressVO ,PostalAddress6 postalAddress) {
		
		if (addressVO.getAddress1() != null) {
			postalAddress.getAdrLine().add(addressVO.getAddress1());
		}
		if (addressVO.getAddress2() != null) {
			postalAddress.getAdrLine().add(addressVO.getAddress2());
		}
		if (addressVO.getAddress3() != null) {
			postalAddress.getAdrLine().add(addressVO.getAddress3());
		}
		
	}
	private static PartyIdentification46 getAddress(AddressVO addressVO,DozerBeanMapper mapper) {
		PartyIdentification46 partyIdentification = new PartyIdentification46();
		PostalAddress6 postalAddress = mapper.map(addressVO, PostalAddress6.class);
		
		if (addressVO.getAddrType() != null) {
			postalAddress.setAdrTp(AddressType2Code.fromValue(addressVO.getAddrType()));
		}
		
		populateAddressLine(addressVO, postalAddress);
		partyIdentification.setPstlAdr(postalAddress);
		return partyIdentification; 
	}
	private static void populatePaymentTerms(String desc,FinancialInvoiceV01 invoice) {
		
		if (desc != null) {
			invoice.getTradSttlm().getPmtTerms().getDesc().add(desc);
		}
	}
	private static void populateInvCustomFields(EippTransactionVO eippTransactionVO,DozerBeanMapper mapper,
			FinancialInvoiceV01 invoice) {
		
		for (EippCustFieldsVO eippCustFieldsVO : eippTransactionVO.getCustFields()) {
			AdditionalInformation6 custField = mapper.map(eippCustFieldsVO, AdditionalInformation6.class);	
			invoice.getInvcHdr().getInclNote().add(custField);
		}

	}
	
	private static void populateCntCustomFields(EippTransactionVO eippTransactionVO,DozerBeanMapper mapper,
			FinancialCreditNoteV01 creditNote) {

		for (EippCustFieldsVO eippCustFieldsVO : eippTransactionVO.getCustFields()) {
			AdditionalInformation6 custField = mapper.map(eippCustFieldsVO, AdditionalInformation6.class);	
			creditNote.getCrNtHdr().getInclNote().add(custField);
		}

	}
	
	private static void populateCustomItmFields(EippTransactionVO eippTransactionVO,DozerBeanMapper mapper,
			LineItem10 lineItem10) {
		for (EippCustFieldsVO eippCustFieldsVO : eippTransactionVO.getCustFields()) {
			AdditionalInformation1 custField = mapper.map(eippCustFieldsVO, AdditionalInformation1.class);	
			lineItem10.getInclNote().add(custField);
		}
	}
	
	private static List<FinancialCreditNoteV01> createCreditNotes(List<EippCreditNoteVO> cntList,DozerBeanMapper mapper){
		
		List<FinancialCreditNoteV01> cnts = new ArrayList<FinancialCreditNoteV01>();
		
		for(EippCreditNoteVO eippCreditNoteVO : cntList){
			FinancialCreditNoteV01 creditNote = mapper.map(eippCreditNoteVO, FinancialCreditNoteV01.class);
			populateCntCustomFields(eippCreditNoteVO, mapper,creditNote);
			populateCrntAddress(eippCreditNoteVO, mapper,creditNote);
			for (EippInvCntLineItemVO lineItmVO : eippCreditNoteVO.getLineItemList()) {
				LineItem10 lineItem10 = mapper.map(lineItmVO, LineItem10.class);
				populateCustomItmFields(lineItmVO, mapper,lineItem10);
				creditNote.getLineItm().add(lineItem10);
			}
			if (!isEmptyList(eippCreditNoteVO.getInvalidFileDataList())){
				creditNote.setErrMsgs(getErrorMessages(eippCreditNoteVO.getInvalidFileDataList(),mapper));
				creditNote.setStatus(BNPConstants.VALIDATION_FAILED);
			}
			else {
				creditNote.setStatus(BNPConstants.VALIDATION_SUCCESS);
			}
			cnts.add(creditNote);
		}
		
		return cnts;
		
	}
	
	public static boolean isEmptyList(List<? extends Object> objectList){
		if (objectList != null && !objectList.isEmpty())
			return false;
		else
			return true;
	}
	public static Document mapVOToJAXB(List<EippInvCntVO> transList) {
		Document document = new Document();
		List<String> mappingFiles = new ArrayList<String>();

		mappingFiles.add("mapper/EippCntMapper.xml");
		mappingFiles.add("mapper/EippInvMapper.xml");
		mappingFiles.add("mapper/EippLineItemMapper.xml");
		mappingFiles.add("mapper/EippCustFieldMapper.xml");
		mappingFiles.add("mapper/EippCustItmFldMapper.xml");
		mappingFiles.add("mapper/EippErrorMsgMapper.xml");
		mappingFiles.add("mapper/EippAddrMapper.xml");
		
		DozerBeanMapper mapper = new DozerBeanMapper();
		mapper.setMappingFiles(mappingFiles);
		for (EippInvCntVO eippInvCntVO : transList) {
				if(!isEmptyList(eippInvCntVO.getInvoiceList())){
					document.getFinInvc().addAll(createInvoices
							(eippInvCntVO.getInvoiceList(),mapper));
				}
				if (!isEmptyList(eippInvCntVO.getCntList())){
					document.getFinCrNt().addAll(createCreditNotes
							(eippInvCntVO.getCntList(), mapper));
				}
		}
		
		return document;
	}
	
	
}
