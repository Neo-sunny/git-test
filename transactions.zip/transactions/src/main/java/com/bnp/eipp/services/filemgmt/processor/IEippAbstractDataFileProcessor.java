/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   17 Oct 2012
 * 
 * Purpose:      IEippAbstractDataFileProcessor
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 17 Oct 2012        Oracle Financial Services Software Ltd                  Initial Version    
************************************************************************************************************************************************************/
package com.bnp.eipp.services.filemgmt.processor;

import com.bnp.eipp.services.invoice.vo.EippTransactionVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;
import com.bnp.scm.services.txns.common.message.bindingvo.RootXmlElement;

public interface IEippAbstractDataFileProcessor<R extends RootXmlElement, T extends EippTransactionVO> {
	
	void processFile(AbstractMessage<?> msg, FileDetailsVO detailsVO) 
						throws BNPApplicationException;

}
