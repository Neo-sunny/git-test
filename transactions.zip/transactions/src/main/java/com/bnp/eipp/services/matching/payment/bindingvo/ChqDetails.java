package com.bnp.eipp.services.matching.payment.bindingvo;

import java.util.Calendar;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.bnp.scm.services.txns.util.calendar.DateAdapter;

/**
 * <p>
 * Java class for ChqDetails complex type.
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ChqDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ChqNo" type="{}Max20Text"/>
 *         &lt;element name="ChqDate" type="{}Date" minOccurs="0"/>
 *         &lt;element name="BankCode" type="{}Max20Text" minOccurs="0"/>
 *         &lt;element name="AccountNo" type="{}Max35Text" minOccurs="0"/>
 *         &lt;element name="BranchCode" type="{}Max20Text" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ChqDetails", propOrder = { "chqNo", "chqDate", "bankCode", "accountNo", "branchCode" })
public class ChqDetails {

	@XmlElement(name = "ChqNo", required = true)
	protected String chqNo;

	@XmlElement(name = "ChqDate", type = String.class)
	@XmlJavaTypeAdapter(DateAdapter.class)
	protected Calendar chqDate;

	@XmlElement(name = "BankCode")
	protected String bankCode;

	@XmlElement(name = "AccountNo")
	protected String accountNo;

	@XmlElement(name = "BranchCode")
	protected String branchCode;

	/**
	 * Gets the value of the chqNo property.
	 * @return possible object is {@link String }
	 */
	public String getChqNo() {
		return chqNo;
	}

	/**
	 * Sets the value of the chqNo property.
	 * @param value allowed object is {@link String }
	 */
	public void setChqNo(String value) {
		this.chqNo = value;
	}

	/**
	 * Gets the value of the chqDate property.
	 * @return possible object is {@link String }
	 */
	public Calendar getChqDate() {
		return chqDate;
	}

	/**
	 * Sets the value of the chqDate property.
	 * @param value allowed object is {@link String }
	 */
	public void setChqDate(Calendar value) {
		this.chqDate = value;
	}

	/**
	 * Gets the value of the bankCode property.
	 * @return possible object is {@link String }
	 */
	public String getBankCode() {
		return bankCode;
	}

	/**
	 * Sets the value of the bankCode property.
	 * @param value allowed object is {@link String }
	 */
	public void setBankCode(String value) {
		this.bankCode = value;
	}

	/**
	 * Gets the value of the accountNo property.
	 * @return possible object is {@link String }
	 */
	public String getAccountNo() {
		return accountNo;
	}

	/**
	 * Sets the value of the accountNo property.
	 * @param value allowed object is {@link String }
	 */
	public void setAccountNo(String value) {
		this.accountNo = value;
	}

	/**
	 * Gets the value of the branchCode property.
	 * @return possible object is {@link String }
	 */
	public String getBranchCode() {
		return branchCode;
	}

	/**
	 * Sets the value of the branchCode property.
	 * @param value allowed object is {@link String }
	 */
	public void setBranchCode(String value) {
		this.branchCode = value;
	}

}
