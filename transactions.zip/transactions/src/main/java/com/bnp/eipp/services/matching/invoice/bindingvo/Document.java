package com.bnp.eipp.services.matching.invoice.bindingvo;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for Document complex type.
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Document">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="MatchingDtls" type="{}SourceAndMatchDtls01" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Document", propOrder = { "matchingDtls" })
public class Document {

	@XmlElement(name = "MatchingDtls", required = true)
	protected List<SourceAndMatchDtls01> matchingDtls;

	/**
	 * Gets the value of the matchingDtls property.
	 * <p>
	 * This accessor method returns a reference to the live list, not a snapshot. Therefore any modification you make to the returned list will be present inside the JAXB object. This is why there is
	 * not a <CODE>set</CODE> method for the matchingDtls property.
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
     *    getMatchingDtls().add(newItem);
     * </pre>
	 * <p>
	 * Objects of the following type(s) are allowed in the list {@link SourceAndMatchDtls01 }
	 */
	public List<SourceAndMatchDtls01> getMatchingDtls() {
		if (matchingDtls == null) {
			matchingDtls = new ArrayList<SourceAndMatchDtls01>();
		}
		return this.matchingDtls;
	}

}
