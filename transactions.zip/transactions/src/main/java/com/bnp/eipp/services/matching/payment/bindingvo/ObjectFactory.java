package com.bnp.eipp.services.matching.payment.bindingvo;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

/**
 * This object contains factory methods for each Java content interface and Java element interface generated in the com.bnp.eipp.services.matching.payment.bindingvo package.
 * <p>
 * An ObjectFactory allows you to programatically construct new instances of the Java representation for XML content. The Java representation of XML content can consist of schema derived interfaces
 * and classes representing the binding of schema type definitions, element declarations and model groups. Factory methods for each of these are provided in this class.
 */
@XmlRegistry
public class ObjectFactory {

	private final static QName _ErrorDescription_QNAME = new QName("", "ErrorDescription");

	private final static QName _Msg_QNAME = new QName("", "Msg");

	/**
	 * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.bnp.eipp.services.matching.payment.bindingvo
	 */
	public ObjectFactory() {
	}

	/**
	 * Create an instance of {@link PymtRespDetails }
	 */
	public PymtRespDetails createPymtRespDetails() {
		return new PymtRespDetails();
	}

	/**
	 * Create an instance of {@link ChqDetails }
	 */
	public ChqDetails createChqDetails() {
		return new ChqDetails();
	}

	/**
	 * Create an instance of {@link Message }
	 */
	public Message createMessage() {
		return new Message();
	}

	/**
	 * Create an instance of {@link OrgDetails }
	 */
	public OrgDetails createOrgDetails() {
		return new OrgDetails();
	}

	/**
	 * Create an instance of {@link RefrenceDetails }
	 */
	public RefrenceDetails createRefrenceDetails() {
		return new RefrenceDetails();
	}

	/**
	 * Create an instance of {@link AdditionalReference }
	 */
	public AdditionalReference createAdditionalReference() {
		return new AdditionalReference();
	}

	/**
	 * Create an instance of {@link AccountInfo }
	 */
	public AccountInfo createAccountInfo() {
		return new AccountInfo();
	}

	/**
	 * Create an instance of {@link File }
	 */
	public File createFile() {
		return new File();
	}

	/**
	 * Create an instance of {@link ErrorMessage }
	 */
	public ErrorMessage createErrorMessage() {
		return new ErrorMessage();
	}

	/**
	 * Create an instance of {@link PymtIdentificationDetails }
	 */
	public PymtIdentificationDetails createPymtIdentificationDetails() {
		return new PymtIdentificationDetails();
	}

	/**
	 * Create an instance of {@link PaymentResponse }
	 */
	public PaymentResponse createPaymentResponse() {
		return new PaymentResponse();
	}

	/**
	 * Create an instance of {@link OrgDtls }
	 */
	public OrgDtls createOrgDtls() {
		return new OrgDtls();
	}

	/**
	 * Create an instance of {@link ErrorDescription }
	 */
	public ErrorDescription createErrorDescription() {
		return new ErrorDescription();
	}

	/**
	 * Create an instance of {@link InvoiceInformation }
	 */
	public InvoiceInformation createInvoiceInformation() {
		return new InvoiceInformation();
	}

	/**
	 * Create an instance of {@link ErrorMessages }
	 */
	public ErrorMessages createErrorMessages() {
		return new ErrorMessages();
	}

	/**
	 * Create an instance of {@link MarketPlace }
	 */
	public MarketPlace createMarketPlace() {
		return new MarketPlace();
	}

	/**
	 * Create an instance of {@link AccountNo }
	 */
	public AccountNo createAccountNo() {
		return new AccountNo();
	}

	/**
	 * Create an instance of {@link Header }
	 */
	public Header createHeader() {
		return new Header();
	}

	/**
	 * Create an instance of {@link ActiveCurrencyAndAmount }
	 */
	public ActiveCurrencyAndAmount createActiveCurrencyAndAmount() {
		return new ActiveCurrencyAndAmount();
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link ErrorDescription }{@code >}
	 */
	@XmlElementDecl(namespace = "", name = "ErrorDescription")
	public JAXBElement<ErrorDescription> createErrorDescription(ErrorDescription value) {
		return new JAXBElement<ErrorDescription>(_ErrorDescription_QNAME, ErrorDescription.class, null, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link Message }{@code >}
	 */
	@XmlElementDecl(namespace = "", name = "Msg")
	public JAXBElement<Message> createMsg(Message value) {
		return new JAXBElement<Message>(_Msg_QNAME, Message.class, null, value);
	}

}
