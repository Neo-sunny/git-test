/* ************************************************************************** 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:  Dec 27, 2011
 * 
 * Purpose:      Payment Request Message
 * 
 * Change History: 
 * Date                                                  Author                                                    Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * Dec 27, 2011                      Oracle Financial Services Software Ltd         Initial Version
 * 
 ***************************************************************************/
package com.bnp.eipp.services.pymt.message;

import java.util.GregorianCalendar;


import com.bnp.eipp.services.pymt.paymentinitiate.bindingvo.Document;
import com.bnp.eipp.services.pymt.message.xml.PaymentInitiateEventHandler;
import com.bnp.eipp.services.pymt.paymentinitiate.bindingvo.File;
import com.bnp.eipp.services.pymt.paymentinitiate.bindingvo.Header;
import com.bnp.eipp.services.pymt.paymentinitiate.bindingvo.ObjectFactory;
import com.bnp.eipp.services.pymt.paymentinitiate.bindingvo.Message;
import com.bnp.eipp.services.pymt.util.PaymentInitiateMessageUtil;
import com.bnp.eipp.services.vo.payment.EippPaymentMsgVO;
import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.vo.AbstractVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;
import com.bnp.scm.services.txns.util.PropertiesReader;

public class PaymentInitiateMessage extends AbstractMessage<Message> {
	
	private ObjectFactory factory;

	/**
	 * @return the factory
	 */
	public ObjectFactory getFactory() {
		return factory;
	}

	/**
	 * @param factory the factory to set
	 */
	public void setFactory(ObjectFactory factory) {
		this.factory = factory;
	}

	@Override
	public void createInstance() throws BNPApplicationException {
		this.factory = new ObjectFactory();
		this.message = new Message();
		this.body = new File();
		this.header = new Header();
		
	}
	
	/* (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.AbstractMessage#createMessage(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void createMessage() throws BNPApplicationException {
		
		if( factory==null){
			this.factory = new ObjectFactory();	
		}
		Message paymentmessage = (Message)this.getMessage();
		paymentmessage.setFile((File)this.getBody());
		paymentmessage.setHeader((Header)this.getHeader());
		this.setMessage(paymentmessage);
		this.setJaxbElementObj(factory.createMsg(paymentmessage));
	}

	
	@Override
	public void setBindingProperties() throws BNPApplicationException {
		this.properties.setBindingClass(Message.class);
		this.properties.setValidateXsd(true);
		this.properties.setXsdPath(PropertiesReader.getProperty("message.eipppmtinitiate.xsd.path"));
		this.properties.setEventHandler(new PaymentInitiateEventHandler());
		this.setProperties(properties);
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.AbstractMessage#createHeader(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void createHeader(AbstractVO abstractVO) throws BNPApplicationException {
		try {
			if(abstractVO instanceof EippPaymentMsgVO){
				EippPaymentMsgVO paymentInitiateVO = (EippPaymentMsgVO)abstractVO;
				header.setCountry(paymentInitiateVO.getCountry());
				header.setBankCode(paymentInitiateVO.getBankCode());
				header.setBranchCode(paymentInitiateVO.getBranchCode());
				header.setSCMOrgId(paymentInitiateVO.getScmOrgId());
				header.setMsgFileType(paymentInitiateVO.getMsgType());
				header.setCntType(PropertiesReader.getProperty("message.content.type.xml"));
				header.setMsgFileSts(PropertiesReader.getProperty("message.type.na"));
				header.setCustFileName(PropertiesReader.getProperty("message.type.na"));
				header.setOrgin(PropertiesReader.getProperty("txns.label.fo"));
				header.setDestination(paymentInitiateVO.getDestination());
				header.setSendTime(new GregorianCalendar());
				header.setSrcRefId(paymentInitiateVO.getMsgId());
				this.setHeader(header);
			}
		}
		catch (Exception exception) {
			throw new BNPApplicationException(exception.getMessage(), exception);
		}
	}
	
	
	/*
	 * (non-Javadoc)
	 * @see com.bnp.scm.services.txns.common.message.AbstractMessage#createBody(com.bnp.scm.services.common.vo.AbstractVO)
	 */
	@Override
	public void createBody(AbstractVO abstractVO) throws BNPApplicationException {
		if(abstractVO instanceof EippPaymentMsgVO){ 
			EippPaymentMsgVO eIPPPaymentMessageVO = (EippPaymentMsgVO)abstractVO;
			Document document = PaymentInitiateMessageUtil.mapVOToJAXB(eIPPPaymentMessageVO);
			((File)body).setDocument(document);
			this.setBody(body);
		}			
	}

}

