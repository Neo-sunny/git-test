/*****************************************************************************************************************************************************************
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   11 Apr 2012
 * 
 * Purpose:    Message Factory Interface
 * 
 * Change History: 
 * Date                                                  Author                                     Reason 
 * ---------------------------------------------------------------------------------------------------------------------------------------------------- 
 * 11 Apr 2012                                           Prabu P                                    Initial Version
 * 20 Apr 2012                                           Prabu P                                    Added method for getting Message Response Instance    
 ******************************************************************************************************************************************************************/

package com.bnp.eipp.services.pymt.message;

import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.txns.common.message.AbstractMessage;
import com.bnp.scm.services.txns.common.message.IMessageResponse;
import com.bnp.scm.services.txns.common.message.IMessageService;

public interface IEIPPMessageFactory {

	/**
	 * Get the message instance
	 * @param messageType
	 * @return AbstractMessage
	 * @throws BNPApplicationException
	 */
	AbstractMessage<?> getMessageInstance(final String messageType) throws BNPApplicationException;

	/**
	 * Get Message service instance
	 * @param messageType
	 * @return IMessageService
	 * @throws BNPApplicationException
	 */
	IMessageService getMessageService(final String messageType) throws BNPApplicationException;
	
	/**
	 * Get Message response instance
	 * @param messageType
	 * @return IMessageResponse
	 * @throws BNPApplicationException
	 */
	IMessageResponse getMessageResponse(final String messageType) throws BNPApplicationException;

}