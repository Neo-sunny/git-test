package com.bnp.eipp.services.matching.invoice.bindingvo;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for Address01 complex type.
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Address01">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PstCd" type="{}Max16Text" minOccurs="0"/>
 *         &lt;element name="TwnNm" type="{}Max35Text" minOccurs="0"/>
 *         &lt;element name="State" type="{}Max35Text" minOccurs="0"/>
 *         &lt;element name="Ctry" type="{}CountryCode" minOccurs="0"/>
 *         &lt;element name="AdrLine" type="{}Max70Text" maxOccurs="7" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Address01", propOrder = { "pstCd", "twnNm", "state", "ctry", "adrLine" })
public class Address01 {

	@XmlElement(name = "PstCd")
	protected String pstCd;

	@XmlElement(name = "TwnNm")
	protected String twnNm;

	@XmlElement(name = "State")
	protected String state;

	@XmlElement(name = "Ctry")
	protected String ctry;

	@XmlElement(name = "AdrLine")
	protected List<String> adrLine;

	/**
	 * Gets the value of the pstCd property.
	 * @return possible object is {@link String }
	 */
	public String getPstCd() {
		return pstCd;
	}

	/**
	 * Sets the value of the pstCd property.
	 * @param value allowed object is {@link String }
	 */
	public void setPstCd(String value) {
		this.pstCd = value;
	}

	/**
	 * Gets the value of the twnNm property.
	 * @return possible object is {@link String }
	 */
	public String getTwnNm() {
		return twnNm;
	}

	/**
	 * Sets the value of the twnNm property.
	 * @param value allowed object is {@link String }
	 */
	public void setTwnNm(String value) {
		this.twnNm = value;
	}

	/**
	 * Gets the value of the state property.
	 * @return possible object is {@link String }
	 */
	public String getState() {
		return state;
	}

	/**
	 * Sets the value of the state property.
	 * @param value allowed object is {@link String }
	 */
	public void setState(String value) {
		this.state = value;
	}

	/**
	 * Gets the value of the ctry property.
	 * @return possible object is {@link String }
	 */
	public String getCtry() {
		return ctry;
	}

	/**
	 * Sets the value of the ctry property.
	 * @param value allowed object is {@link String }
	 */
	public void setCtry(String value) {
		this.ctry = value;
	}

	/**
	 * Gets the value of the adrLine property.
	 * <p>
	 * This accessor method returns a reference to the live list, not a snapshot. Therefore any modification you make to the returned list will be present inside the JAXB object. This is why there is
	 * not a <CODE>set</CODE> method for the adrLine property.
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
     *    getAdrLine().add(newItem);
     * </pre>
	 * <p>
	 * Objects of the following type(s) are allowed in the list {@link String }
	 */
	public List<String> getAdrLine() {
		if (adrLine == null) {
			adrLine = new ArrayList<String>();
		}
		return this.adrLine;
	}

}
