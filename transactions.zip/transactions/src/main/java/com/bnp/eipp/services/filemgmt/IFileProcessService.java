/* ******************************************************************************************************************************************************* 
 * Copyright (c) 2011-2020 BNP Paribas SA. All rights reserved.
 * 
 * Author: Oracle Financial Services Software Ltd for BNP Paribas SA.
 * 
 * Created on:   18 July 2012
 * 
 * Purpose:      IFileProcessService
 * 
 * Change History: 
 * Date                       Author                                            Reason 
 * ----------------------------------------------------------------------------------------------------------------------------------------------- 
 * 18 July 2012        Oracle Financial Services Software Ltd                  Initial Version  
************************************************************************************************************************************************************/

package com.bnp.eipp.services.filemgmt;

import java.util.List;
import java.util.Map;

import com.bnp.scm.services.common.exception.BNPApplicationException;
import com.bnp.scm.services.common.exception.BNPRuntimeException;
import com.bnp.scm.services.filemgmt.vo.FileDetailsVO;
import com.bnp.scm.services.invoice.vo.InvalidFileDataVO;
import com.bnp.scm.services.txns.common.message.AbstractMessage;

public interface IFileProcessService {
	
	void checkForDuplicateFile(FileDetailsVO detailsVO) throws BNPApplicationException;
	
	void saveFileDetails(FileDetailsVO detailsVO) throws BNPApplicationException;
	
	void triggerEventLog(FileDetailsVO detailsVO, String action) throws BNPApplicationException;
	
	FileDetailsVO getHeaderDetails(FileDetailsVO detailsVO) throws BNPApplicationException;
	
	void insertFileUploadMessageDetails(FileDetailsVO detailsVO) throws BNPApplicationException;
	
	String getMessageId() throws BNPApplicationException;
	
	void updateFileStatus(FileDetailsVO detailsVO) throws BNPApplicationException;
	
	void updateERPDownloadForCustomFile(FileDetailsVO detailsVO, String status) throws BNPApplicationException;
	
	<T> void sendMessage(AbstractMessage<T> message, String queueName, 
			Map<String,String> jmsProperties) throws BNPApplicationException;
	
	boolean canUploadPartialFile(String senderOrgId) throws BNPApplicationException;
	
	void insertInvalidRecords(List<InvalidFileDataVO> invalidList) throws BNPApplicationException;

	/**
	 * @param billType
	 * @param custERPId
	 * @return 
	 * @throws BNPApplicationException
	 */
	List<String> getCustomerOrgId(String billType, String custERPId) throws BNPApplicationException;

	/**
	 * @param detailsVO
	 * @param invoiceMessage
	 * @param uploadVO
	 * @throws BNPApplicationException 
	 */
	void processAndReleaseFile(FileDetailsVO detailsVO,	AbstractMessage<?> invoiceMessage) throws BNPApplicationException;

	/**
	 * @param senderOrgId
	 * @return
	 * @throws BNPApplicationException 
	 */
	String getModelTypeForOrganization(String senderOrgId) throws BNPApplicationException;

	/**
	 * @param senderOrgId
	 * @return
	 * @throws BNPApplicationException 
	 */
	String getTimezoneForOrganization(String senderOrgId) throws BNPApplicationException;

	/**
	 * @param buyerOrgId
	 * @param billType
	 * @param sellerERPId
	 * @return
	 * @throws BNPRuntimeException 
	 */
	List<String> getCounterPartyOrgId(String orgId, String billType,String cntpERPId) throws BNPApplicationException;

	/**
	 * @param custOrgId
	 * @param cntpOrgId
	 * @param billType
	 */
	boolean isBuyerSellerLinked(String custOrgId,String cntpOrgId,String billType) throws BNPApplicationException;

	/**
	 * @param detailsVO
	 * @throws BNPApplicationException
	 */
	void deleteFile(FileDetailsVO detailsVO) throws BNPApplicationException;

	/**
	 * @param invalidDataList
	 * @param detailsVO
	 * @throws BNPApplicationException 
	 */
	void updateReprocessFlag(List<InvalidFileDataVO> invalidDataList,
			FileDetailsVO detailsVO) throws BNPApplicationException;
	
	boolean isAutoReleaseEnabled(String senderOrgId) throws BNPApplicationException;

	/**
	 * @param orgId
	 * @return
	 * @throws BNPApplicationException 
	 */
	String getOrganizationType(String orgId) throws BNPApplicationException;

	/**
	 * @param senderOrgId
	 * @return
	 */
	String getOrgTypeForOrganization(String senderOrgId) throws BNPApplicationException;
	
	/**
	 * @param billType
	 * @param marketPlaceOrgId
	 * @return
	 * @throws BNPApplicationException 
	 */
	boolean isBillThroughMarketPlace(String billType, String marketPlaceOrgId) throws BNPApplicationException;

	/**
	 * @param custOrgId
	 * @param cntpOrgId
	 * @param billType
	 * @param marketPlaceOrgId
	 * @return boolean
	 * @throws BNPApplicationException 
	 */
	boolean isBuyerSellerLinkedToMarketPlace(String custOrgId, String cntpOrgId,
			String billType, String marketPlaceOrgId) throws BNPApplicationException;

}
